package android.net.http;

class Request {
    Request() {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }

    public void handleSslErrorResponse(boolean proceed) {
        throw new RuntimeException("Stub!");
    }
}
