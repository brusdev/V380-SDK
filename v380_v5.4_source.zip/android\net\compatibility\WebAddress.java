package android.net.compatibility;

public class WebAddress {
    public WebAddress(String address) throws IllegalArgumentException {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }

    public void setScheme(String scheme) {
        throw new RuntimeException("Stub!");
    }

    public String getScheme() {
        throw new RuntimeException("Stub!");
    }

    public void setHost(String host) {
        throw new RuntimeException("Stub!");
    }

    public String getHost() {
        throw new RuntimeException("Stub!");
    }

    public void setPort(int port) {
        throw new RuntimeException("Stub!");
    }

    public int getPort() {
        throw new RuntimeException("Stub!");
    }

    public void setPath(String path) {
        throw new RuntimeException("Stub!");
    }

    public String getPath() {
        throw new RuntimeException("Stub!");
    }

    public void setAuthInfo(String authInfo) {
        throw new RuntimeException("Stub!");
    }

    public String getAuthInfo() {
        throw new RuntimeException("Stub!");
    }
}
