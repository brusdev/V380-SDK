package android.support.v7.app;

@Deprecated
public class ActionBarActivity extends AppCompatActivity {
}
