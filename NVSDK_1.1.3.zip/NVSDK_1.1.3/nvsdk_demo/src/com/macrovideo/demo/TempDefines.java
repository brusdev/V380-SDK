package com.macrovideo.demo;

import java.util.ArrayList;
import java.util.List;

import com.macrovideo.sdk.custom.RecordFileInfo;

 
import android.app.Application;

public class TempDefines extends Application{
	public static List<RecordFileInfo> listMapPlayerBackFile = new ArrayList<RecordFileInfo>();
}
 