package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.common.BitArray;
import com.tencent.android.tpush.common.Constants;
import com.tencent.mid.api.MidConstants;

final class AI01320xDecoder extends AI013x0xDecoder {
    AI01320xDecoder(BitArray information) {
        super(information);
    }

    protected void addWeightCode(StringBuilder buf, int weight) {
        if (weight < Constants.ERRORCODE_UNKNOWN) {
            buf.append("(3202)");
        } else {
            buf.append("(3203)");
        }
    }

    protected int checkWeight(int weight) {
        return weight < Constants.ERRORCODE_UNKNOWN ? weight : weight + MidConstants.ERROR_ARGUMENT;
    }
}
