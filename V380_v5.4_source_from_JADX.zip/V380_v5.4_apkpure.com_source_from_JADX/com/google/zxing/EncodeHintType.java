package com.google.zxing;

public enum EncodeHintType {
    ERROR_CORRECTION,
    CHARACTER_SET
}
