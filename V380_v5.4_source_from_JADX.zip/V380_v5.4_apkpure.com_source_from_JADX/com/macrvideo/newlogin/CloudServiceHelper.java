package com.macrvideo.newlogin;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.media.TransportMediator;
import android.util.Log;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.custom.RecordFileInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.media.IRecFileCallback;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.DialogTipCode;
import com.macrovideo.v380.LocalDefines;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

public class CloudServiceHelper {
    public static final int HANDLE_MSG_CODE_ACTIVE_BIND_SERVICE = 78;
    public static final int HANDLE_MSG_CODE_GET_DEVICE_TOKEN = 77;
    private static final int NV_IPC_DEVICE_TOKEN_GET_REQUEST = 145;
    private static final int NV_IPC_DEVICE_TOKEN_GET_RESPONSE = 245;
    private static final int NV_IPC_ENABLE_SERVICE_BIND_GET_REQUEST = 146;
    private static final int NV_IPC_ENABLE_SERVICE_BIND_GET_RESPONSE = 246;
    private static final int RECORD_BUFFER_READ_SIZE = 128;
    private static int _nSearchID = 0;
    private static byte[] buffer = new byte[65536];

    public static int cancelOperation() {
        _nSearchID++;
        return 1;
    }

    public static LoginHandle getRecordOPHandle(DeviceInfo device) {
        _nSearchID++;
        int nSearchID = _nSearchID;
        LoginHandle loginHandle = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (Functions.isIpAddress(device.getStrIP())) {
                loginHandle = getRecordHandleServer(nSearchID, device);
            }
            if (loginHandle == null || loginHandle.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                loginHandle = getRecordHandleMRServer(nSearchID, device);
            }
            if (loginHandle != null && loginHandle.getnResult() == 256) {
                loginHandle.setnDeviceID(device.getnDevID());
                loginHandle.setStrUsername(device.getStrUsername());
                loginHandle.setStrPassword(device.getStrPassword());
                loginHandle.setStrDomain(device.getStrDomain());
            }
        }
        return loginHandle;
    }

    private static LoginHandle getRecordHandleServer(int nSearchID, DeviceInfo device) {
        OutputStream writer = null;
        InputStream reader = null;
        byte[] buffer = new byte[128];
        LoginHandle loginHandle = new LoginHandle();
        loginHandle.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToServer(device.getStrIP(), device.getnPort(), Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        loginHandle.setnResult(-102);
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.CMD_LOGIN_EX, buffer, 0);
                        if (device.getStrUsername() != null && device.getStrUsername().length() > 0) {
                            System.arraycopy(device.getStrUsername().getBytes(), 0, buffer, 4, device.getStrUsername().getBytes().length);
                        }
                        if (device.getStrPassword() != null && device.getStrPassword().length() > 0) {
                            System.arraycopy(device.getStrPassword().getBytes(), 0, buffer, 36, device.getStrPassword().getBytes().length);
                        }
                        Functions.IntToBytes((long) device.getnDevID(), buffer, 68);
                        try {
                            writer.write(buffer, 0, 128);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        int tryTimes = 0;
                        boolean bReadOK = false;
                        do {
                            try {
                                if (reader.available() >= 8) {
                                    Arrays.fill(buffer, (byte) 0);
                                    reader.read(buffer, 0, 8);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(200);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                tryTimes++;
                                if (tryTimes < 50) {
                                    if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            } catch (IOException e6) {
                                bReadOK = false;
                            }
                        } while (nSearchID == _nSearchID);
                        if (bReadOK && Functions.BytesToInt(buffer, 0) == 254) {
                            long lHandle = (long) Functions.BytesToInt(buffer, 4);
                            if (lHandle <= 0) {
                                switch ((int) lHandle) {
                                    case -1003:
                                        loginHandle.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                        break;
                                    case -1002:
                                        loginHandle.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                        break;
                                    case -1001:
                                        loginHandle.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                        break;
                                    default:
                                        break;
                                }
                            }
                            loginHandle.setnResult(256);
                            loginHandle.setlHandle(lHandle);
                            loginHandle.setMRMode(false);
                            loginHandle.setStrIP(device.getStrIP());
                            loginHandle.setStrLanIP(device.getStrIP());
                            loginHandle.setnPort(device.getnPort());
                        }
                    } else {
                        loginHandle.setnResult(-102);
                    }
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e7) {
                            e7.printStackTrace();
                        }
                    }
                    if (reader != null) {
                        reader.close();
                    }
                    if (sSocket != null) {
                        sSocket.close();
                    }
                }
            } catch (IOException e8) {
                isConnectOK = false;
            }
        }
        return loginHandle;
    }

    private static LoginHandle getRecordHandleMRServer(int nSearchID, DeviceInfo device) {
        System.out.println("getRecordHandleMRServer 1");
        OutputStream writer = null;
        InputStream reader = null;
        byte[] buffer = new byte[256];
        LoginHandle loginHandle = new LoginHandle();
        loginHandle.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToMRServer(null, 0, 8000, device.getnDevID());
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        loginHandle.setnResult(-102);
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 1017, buffer, 0);
                        Functions.IntToBytes((long) 1002, buffer, 4);
                        if (device.getStrDomain() != null && device.getStrDomain().length() > 0) {
                            System.arraycopy(device.getStrDomain().getBytes(), 0, buffer, 8, device.getStrDomain().getBytes().length);
                        }
                        Functions.IntToBytes((long) device.getnPort(), buffer, 58);
                        if (device.getStrUsername() != null && device.getStrUsername().length() > 0) {
                            System.arraycopy(device.getStrUsername().getBytes(), 0, buffer, 62, device.getStrUsername().getBytes().length);
                        }
                        if (device.getStrPassword() != null && device.getStrPassword().length() > 0) {
                            System.arraycopy(device.getStrPassword().getBytes(), 0, buffer, 112, device.getStrPassword().getBytes().length);
                        }
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        int tryTimes = 0;
                        boolean bReadOK = false;
                        do {
                            if (reader.available() >= 16) {
                                Arrays.fill(buffer, (byte) 0);
                                reader.read(buffer, 0, 16);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e6) {
                                    bReadOK = false;
                                }
                            }
                            tryTimes++;
                            if (tryTimes < 50) {
                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                    break;
                                }
                            } else {
                                break;
                            }
                        } while (nSearchID == _nSearchID);
                        if (bReadOK) {
                            int nCMD = Functions.BytesToInt(buffer, 0);
                            int nResultCode = Functions.BytesToInt(buffer, 4);
                            if (nCMD == 2017) {
                                System.out.println("Get Record Login ::" + nResultCode + "  :::  " + 1000);
                                if (nResultCode != 1000) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case -1003:
                                            loginHandle.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        case -1002:
                                            loginHandle.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case -1001:
                                            loginHandle.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                loginHandle.setlHandle((long) Functions.BytesToInt(buffer, 8));
                                loginHandle.setnResult(256);
                                loginHandle.setMRMode(true);
                                loginHandle.setStrMRServer(sSocket.getInetAddress().toString());
                                loginHandle.setnMRPort(sSocket.getPort());
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e7) {
                                e7.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e8) {
                isConnectOK = false;
            }
        }
        return loginHandle;
    }

    private static int getRecordFileServerCallback(int nSearchID, IRecFileCallback handler, long lHandle, String strIP, int nPort, int nSearcgChn, int nSearchType, short nYear, short nMonth, short nDay, short nStartHour, short nStartMin, short nStartSec, short nEndHour, short nEndMin, short nEndSec) {
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                nResult = 259;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) Defines.REC_FILE_SEARCH, buffer, 0);
                Functions.IntToBytes(lHandle, buffer, 4);
                buffer[8] = (byte) nSearcgChn;
                buffer[9] = (byte) nSearchType;
                Functions.ShortToBytes(nYear, buffer, 10);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 12);
                Functions.ShortToBytes(nDay, buffer, 14);
                Functions.ShortToBytes(nStartHour, buffer, 16);
                Functions.ShortToBytes(nStartMin, buffer, 18);
                Functions.ShortToBytes(nStartSec, buffer, 20);
                Functions.ShortToBytes(nYear, buffer, 30);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 32);
                Functions.ShortToBytes(nDay, buffer, 34);
                Functions.ShortToBytes(nEndHour, buffer, 36);
                Functions.ShortToBytes(nEndMin, buffer, 38);
                Functions.ShortToBytes(nEndSec, buffer, 40);
                Functions.IntToBytes((long) 0, buffer, 50);
                Functions.IntToBytes((long) 0, buffer, 54);
                buffer[58] = (byte) 1;
                try {
                    writer.write(buffer, 0, 128);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                boolean bReadOK = false;
                int nFileCount = 0;
                ArrayList<RecordFileInfo> fileList = new ArrayList();
                while (nSearchID == _nSearchID && tryTimes < 50) {
                    fileList.clear();
                    do {
                        try {
                            if (reader.available() >= 16) {
                                Arrays.fill(buffer, (byte) 0);
                                reader.read(buffer, 0, 16);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e5) {
                                e5.printStackTrace();
                            }
                            tryTimes++;
                            if (tryTimes < 50) {
                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                    break;
                                }
                            } else {
                                break;
                            }
                        } catch (IOException e6) {
                        }
                    } while (nSearchID == _nSearchID);
                    if (bReadOK) {
                        nResult = 256;
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int RecTotalCount = Functions.BytesToInt(buffer, 4);
                        int SendTotal = Functions.BytesToInt(buffer, 8);
                        int FileCount = Functions.BytesToInt(buffer, 12);
                        if (nCMD == 260) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e52) {
                                e52.printStackTrace();
                            }
                        } else {
                            if (nCMD == 250 && FileCount > 0 && FileCount < 40) {
                                if (fileList != null && fileList.size() > 0) {
                                    fileList.clear();
                                }
                                for (int i = 0; i < FileCount; i++) {
                                    do {
                                        if (reader.available() >= 48) {
                                            Arrays.fill(buffer, (byte) 0);
                                            reader.read(buffer, 0, 48);
                                            bReadOK = true;
                                            break;
                                        }
                                        try {
                                            Thread.sleep(200);
                                        } catch (InterruptedException e522) {
                                            e522.printStackTrace();
                                        }
                                        tryTimes++;
                                        if (tryTimes < 50) {
                                            try {
                                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                                }
                                            } catch (IOException e7) {
                                            }
                                        }
                                        System.out.println("tryTimes>=25");
                                        break;
                                    } while (nSearchID == _nSearchID);
                                    RecordFileInfo recordFileInfo = new RecordFileInfo();
                                    recordFileInfo.setnFileID(Functions.BytesToInt(buffer, 0));
                                    recordFileInfo.setnFileSize(Functions.BytesToInt(buffer, 4));
                                    StringBuilder sb = new StringBuilder();
                                    int len = 0;
                                    while (len < 32 && len + 8 < buffer.length && ((char) buffer[len + 8]) != '\u0000') {
                                        sb.append((char) buffer[len + 8]);
                                        len++;
                                    }
                                    recordFileInfo.setuStartHour(Functions.BytesToShort(buffer, 40));
                                    recordFileInfo.setuStartMin(Functions.BytesToShort(buffer, 42));
                                    recordFileInfo.setuStartSec(Functions.BytesToShort(buffer, 44));
                                    recordFileInfo.setuFileTimeLen(Functions.BytesToShort(buffer, 46));
                                    recordFileInfo.setStrFileName(new String(sb.toString()));
                                    fileList.add(recordFileInfo);
                                }
                            }
                            if (nSearchID == _nSearchID && handler != null) {
                                nFileCount += fileList.size();
                                new ArrayList().addAll(fileList);
                                nFileCount += fileList.size();
                                handler.onReceiveFile(nFileCount, fileList.size(), fileList);
                            }
                            if (RecTotalCount == -1 || RecTotalCount == SendTotal + FileCount) {
                                nResult = 256;
                                break;
                            }
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e8) {
                    e8.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return nResult;
        } catch (IOException e9) {
            isConnectOK = false;
            nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
    }

    private static int getRecordFileMRServerCallback(int nSearchID, IRecFileCallback handler, long lHandle, String strDomain, int nPort, int nSearchChn, int nSearchType, short nYear, short nMonth, short nDay, short nStartHour, short nStartMin, short nStartSec, short nEndHour, short nEndMin, short nEndSec, int nDeviceId) {
        int nResult = 0;
        OutputStream writer = null;
        InputStream reader = null;
        Socket sSocket = Functions.connectToMRServer(null, 0, 8000, nDeviceId);
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                System.out.println("Get Record File Socket Connect OK");
                nResult = 259;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 1015, buffer, 0);
                Functions.IntToBytes((long) 1002, buffer, 4);
                System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                Functions.IntToBytes((long) nPort, buffer, 58);
                Functions.IntToBytes(lHandle, buffer, 62);
                buffer[66] = (byte) nSearchChn;
                buffer[67] = (byte) nSearchType;
                Functions.ShortToBytes(nYear, buffer, 68);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 70);
                Functions.ShortToBytes(nDay, buffer, 72);
                Functions.ShortToBytes(nStartHour, buffer, 74);
                Functions.ShortToBytes(nStartMin, buffer, 76);
                Functions.ShortToBytes(nStartSec, buffer, 78);
                Functions.ShortToBytes(nYear, buffer, 88);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 90);
                Functions.ShortToBytes(nDay, buffer, 92);
                Functions.ShortToBytes(nEndHour, buffer, 94);
                Functions.ShortToBytes(nEndMin, buffer, 96);
                Functions.ShortToBytes(nEndSec, buffer, 98);
                Functions.IntToBytes((long) 0, buffer, 108);
                Functions.IntToBytes((long) 0, buffer, 112);
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                boolean bReadOK = false;
                int nFileCount = 0;
                ArrayList<RecordFileInfo> fileList = new ArrayList();
                while (nSearchID == _nSearchID && tryTimes < 50) {
                    do {
                        try {
                            if (reader.available() >= 16) {
                                Arrays.fill(buffer, (byte) 0);
                                reader.read(buffer, 0, 16);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e5) {
                                e5.printStackTrace();
                            }
                            tryTimes++;
                            if (tryTimes < 50) {
                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                    break;
                                }
                            } else {
                                break;
                            }
                        } catch (IOException e6) {
                        }
                    } while (nSearchID == _nSearchID);
                    if (bReadOK) {
                        nResult = 256;
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int RecTotalCount = Functions.BytesToInt(buffer, 4);
                        int SendTotal = Functions.BytesToInt(buffer, 8);
                        int FileCount = Functions.BytesToInt(buffer, 12);
                        if (nCMD == 2000) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e52) {
                                e52.printStackTrace();
                            }
                        } else {
                            if (nCMD == 250 && FileCount > 0 && FileCount < 40) {
                                if (fileList != null && fileList.size() > 0) {
                                    fileList.clear();
                                }
                                for (int i = 0; i < FileCount; i++) {
                                    do {
                                        if (reader.available() >= 48) {
                                            Arrays.fill(buffer, (byte) 0);
                                            reader.read(buffer, 0, 48);
                                            bReadOK = true;
                                            break;
                                        }
                                        try {
                                            Thread.sleep(200);
                                        } catch (InterruptedException e522) {
                                            e522.printStackTrace();
                                        }
                                        tryTimes++;
                                        if (tryTimes < 50) {
                                            try {
                                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                                }
                                            } catch (IOException e7) {
                                            }
                                        }
                                        System.out.println("tryTimes>=25");
                                        break;
                                    } while (nSearchID == _nSearchID);
                                    RecordFileInfo recordFileInfo = new RecordFileInfo();
                                    recordFileInfo.setnFileID(Functions.BytesToInt(buffer, 0));
                                    recordFileInfo.setnFileSize(Functions.BytesToInt(buffer, 4));
                                    StringBuilder sb = new StringBuilder();
                                    int len = 0;
                                    while (len < 32 && len + 8 < buffer.length && ((char) buffer[len + 8]) != '\u0000') {
                                        sb.append((char) buffer[len + 8]);
                                        len++;
                                    }
                                    recordFileInfo.setuStartHour(Functions.BytesToShort(buffer, 40));
                                    recordFileInfo.setuStartMin(Functions.BytesToShort(buffer, 42));
                                    recordFileInfo.setuStartSec(Functions.BytesToShort(buffer, 44));
                                    recordFileInfo.setuFileTimeLen(Functions.BytesToShort(buffer, 46));
                                    recordFileInfo.setStrFileName(new String(sb.toString()));
                                    fileList.add(recordFileInfo);
                                }
                                if (nSearchID == _nSearchID && handler != null) {
                                    nFileCount += fileList.size();
                                    ArrayList<RecordFileInfo> recfileList = new ArrayList();
                                    recfileList.addAll(fileList);
                                    nFileCount += fileList.size();
                                    handler.onReceiveFile(nFileCount, recfileList.size(), recfileList);
                                }
                            }
                            if (RecTotalCount == -1 || RecTotalCount == SendTotal + FileCount) {
                                nResult = 256;
                                break;
                            }
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e8) {
                    e8.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return nResult;
        } catch (IOException e9) {
            isConnectOK = false;
            nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
    }

    private static int getRecordFileServer(int nSearchID, Handler handler, long lHandle, String strIP, int nPort, int nSearcgChn, int nSearchType, short nYear, short nMonth, short nDay, short nStartHour, short nStartMin, short nStartSec, short nEndHour, short nEndMin, short nEndSec) {
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                nResult = 259;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) Defines.REC_FILE_SEARCH, buffer, 0);
                Functions.IntToBytes(lHandle, buffer, 4);
                buffer[8] = (byte) nSearcgChn;
                buffer[9] = (byte) nSearchType;
                Functions.ShortToBytes(nYear, buffer, 10);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 12);
                Functions.ShortToBytes(nDay, buffer, 14);
                Functions.ShortToBytes(nStartHour, buffer, 16);
                Functions.ShortToBytes(nStartMin, buffer, 18);
                Functions.ShortToBytes(nStartSec, buffer, 20);
                Functions.ShortToBytes(nYear, buffer, 30);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 32);
                Functions.ShortToBytes(nDay, buffer, 34);
                Functions.ShortToBytes(nEndHour, buffer, 36);
                Functions.ShortToBytes(nEndMin, buffer, 38);
                Functions.ShortToBytes(nEndSec, buffer, 40);
                Functions.IntToBytes((long) 0, buffer, 50);
                Functions.IntToBytes((long) 0, buffer, 54);
                buffer[58] = (byte) 1;
                try {
                    writer.write(buffer, 0, 128);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                boolean bReadOK = false;
                int nFileCount = 0;
                ArrayList<RecordFileInfo> fileList = new ArrayList();
                while (nSearchID == _nSearchID && tryTimes < 50) {
                    do {
                        try {
                            if (reader.available() >= 16) {
                                Arrays.fill(buffer, (byte) 0);
                                reader.read(buffer, 0, 16);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e5) {
                                e5.printStackTrace();
                            }
                            tryTimes++;
                            if (tryTimes < 50) {
                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                    break;
                                }
                            } else {
                                break;
                            }
                        } catch (IOException e6) {
                        }
                    } while (nSearchID == _nSearchID);
                    if (bReadOK) {
                        nResult = 256;
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int RecTotalCount = Functions.BytesToInt(buffer, 4);
                        int SendTotal = Functions.BytesToInt(buffer, 8);
                        int FileCount = Functions.BytesToInt(buffer, 12);
                        if (nCMD == 260) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e52) {
                                e52.printStackTrace();
                            }
                        } else {
                            Message msg;
                            if (nCMD != 250 || FileCount <= 0 || FileCount >= 40) {
                                msg = handler.obtainMessage();
                                msg.arg1 = 262;
                                msg.arg2 = 0;
                                handler.sendMessage(msg);
                            } else {
                                for (int i = 0; i < FileCount; i++) {
                                    do {
                                        if (reader.available() >= 48) {
                                            Arrays.fill(buffer, (byte) 0);
                                            reader.read(buffer, 0, 48);
                                            bReadOK = true;
                                            break;
                                        }
                                        try {
                                            Thread.sleep(200);
                                        } catch (InterruptedException e522) {
                                            e522.printStackTrace();
                                        }
                                        tryTimes++;
                                        if (tryTimes < 50) {
                                            try {
                                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                                }
                                            } catch (IOException e7) {
                                            }
                                        }
                                        System.out.println("tryTimes>=25");
                                        break;
                                    } while (nSearchID == _nSearchID);
                                    RecordFileInfo recordFileInfo = new RecordFileInfo();
                                    recordFileInfo.setnFileID(Functions.BytesToInt(buffer, 0));
                                    recordFileInfo.setnFileSize(Functions.BytesToInt(buffer, 4));
                                    StringBuilder sb = new StringBuilder();
                                    int len = 0;
                                    while (len < 32 && len + 8 < buffer.length && ((char) buffer[len + 8]) != '\u0000') {
                                        sb.append((char) buffer[len + 8]);
                                        len++;
                                    }
                                    recordFileInfo.setuStartHour(Functions.BytesToShort(buffer, 40));
                                    recordFileInfo.setuStartMin(Functions.BytesToShort(buffer, 42));
                                    recordFileInfo.setuStartSec(Functions.BytesToShort(buffer, 44));
                                    recordFileInfo.setuFileTimeLen(Functions.BytesToShort(buffer, 46));
                                    recordFileInfo.setStrFileName(new String(sb.toString()));
                                    fileList.add(recordFileInfo);
                                }
                                if (nSearchID == _nSearchID) {
                                    nFileCount += fileList.size();
                                    ArrayList<RecordFileInfo> recfileList = new ArrayList();
                                    recfileList.addAll(fileList);
                                    msg = handler.obtainMessage();
                                    msg.arg1 = 262;
                                    msg.arg2 = nFileCount;
                                    Bundle data = new Bundle();
                                    data.putParcelableArrayList(Defines.RECORD_FILE_RETURN_MESSAGE, recfileList);
                                    msg.setData(data);
                                    handler.sendMessage(msg);
                                }
                            }
                            if (RecTotalCount == -1 || RecTotalCount == SendTotal + FileCount) {
                                nResult = 256;
                                break;
                            }
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e8) {
                    e8.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return nResult;
        } catch (IOException e9) {
            isConnectOK = false;
            nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
    }

    private static int getRecordFileMRServer(int nSearchID, Handler handler, long lHandle, String strDomain, int nPort, int nSearchChn, int nSearchType, short nYear, short nMonth, short nDay, short nStartHour, short nStartMin, short nStartSec, short nEndHour, short nEndMin, short nEndSec, int nDeviceId) {
        int nResult = 0;
        OutputStream writer = null;
        InputStream reader = null;
        Socket sSocket = Functions.connectToMRServer(null, 0, 8000, nDeviceId);
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                System.out.println("Get Record File Socket Connect OK");
                nResult = 259;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 1015, buffer, 0);
                Functions.IntToBytes((long) 1002, buffer, 4);
                System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                Functions.IntToBytes((long) nPort, buffer, 58);
                Functions.IntToBytes(lHandle, buffer, 62);
                buffer[66] = (byte) nSearchChn;
                buffer[67] = (byte) nSearchType;
                Functions.ShortToBytes(nYear, buffer, 68);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 70);
                Functions.ShortToBytes(nDay, buffer, 72);
                Functions.ShortToBytes(nStartHour, buffer, 74);
                Functions.ShortToBytes(nStartMin, buffer, 76);
                Functions.ShortToBytes(nStartSec, buffer, 78);
                Functions.ShortToBytes(nYear, buffer, 88);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 90);
                Functions.ShortToBytes(nDay, buffer, 92);
                Functions.ShortToBytes(nEndHour, buffer, 94);
                Functions.ShortToBytes(nEndMin, buffer, 96);
                Functions.ShortToBytes(nEndSec, buffer, 98);
                Functions.IntToBytes((long) 0, buffer, 108);
                Functions.IntToBytes((long) 0, buffer, 112);
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                boolean bReadOK = false;
                int nFileCount = 0;
                ArrayList<RecordFileInfo> fileList = new ArrayList();
                while (nSearchID == _nSearchID && tryTimes < 50) {
                    do {
                        try {
                            if (reader.available() >= 16) {
                                Arrays.fill(buffer, (byte) 0);
                                reader.read(buffer, 0, 16);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e5) {
                                e5.printStackTrace();
                            }
                            tryTimes++;
                            if (tryTimes < 50) {
                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                    break;
                                }
                            } else {
                                break;
                            }
                        } catch (IOException e6) {
                        }
                    } while (nSearchID == _nSearchID);
                    if (bReadOK) {
                        nResult = 256;
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int RecTotalCount = Functions.BytesToInt(buffer, 4);
                        int SendTotal = Functions.BytesToInt(buffer, 8);
                        int FileCount = Functions.BytesToInt(buffer, 12);
                        if (nCMD == 2000) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e52) {
                                e52.printStackTrace();
                            }
                        } else {
                            Message msg;
                            if (nCMD != 250 || FileCount <= 0 || FileCount >= 40) {
                                msg = handler.obtainMessage();
                                msg.arg1 = 262;
                                msg.arg2 = 0;
                                handler.sendMessage(msg);
                            } else {
                                for (int i = 0; i < FileCount; i++) {
                                    do {
                                        if (reader.available() >= 48) {
                                            Arrays.fill(buffer, (byte) 0);
                                            reader.read(buffer, 0, 48);
                                            bReadOK = true;
                                            break;
                                        }
                                        try {
                                            Thread.sleep(200);
                                        } catch (InterruptedException e522) {
                                            e522.printStackTrace();
                                        }
                                        tryTimes++;
                                        if (tryTimes < 50) {
                                            try {
                                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                                }
                                            } catch (IOException e7) {
                                            }
                                        }
                                        System.out.println("tryTimes>=25");
                                        break;
                                    } while (nSearchID == _nSearchID);
                                    RecordFileInfo recordFileInfo = new RecordFileInfo();
                                    recordFileInfo.setnFileID(Functions.BytesToInt(buffer, 0));
                                    recordFileInfo.setnFileSize(Functions.BytesToInt(buffer, 4));
                                    StringBuilder sb = new StringBuilder();
                                    int len = 0;
                                    while (len < 32 && len + 8 < buffer.length && ((char) buffer[len + 8]) != '\u0000') {
                                        sb.append((char) buffer[len + 8]);
                                        len++;
                                    }
                                    recordFileInfo.setuStartHour(Functions.BytesToShort(buffer, 40));
                                    recordFileInfo.setuStartMin(Functions.BytesToShort(buffer, 42));
                                    recordFileInfo.setuStartSec(Functions.BytesToShort(buffer, 44));
                                    recordFileInfo.setuFileTimeLen(Functions.BytesToShort(buffer, 46));
                                    recordFileInfo.setStrFileName(new String(sb.toString()));
                                    fileList.add(recordFileInfo);
                                }
                                if (nSearchID == _nSearchID) {
                                    nFileCount += fileList.size();
                                    ArrayList<RecordFileInfo> recfileList = new ArrayList();
                                    recfileList.addAll(fileList);
                                    msg = handler.obtainMessage();
                                    msg.arg1 = 262;
                                    msg.arg2 = nFileCount;
                                    Bundle data = new Bundle();
                                    data.putParcelableArrayList(Defines.RECORD_FILE_RETURN_MESSAGE, recfileList);
                                    msg.setData(data);
                                    handler.sendMessage(msg);
                                }
                            }
                            if (RecTotalCount == -1 || RecTotalCount == SendTotal + FileCount) {
                                nResult = 256;
                                break;
                            }
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e8) {
                    e8.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return nResult;
        } catch (IOException e9) {
            isConnectOK = false;
            nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
    }

    public static int Cloud_getDeviceToken(int nSearchID, int DevID, String Username, String Password, String accesstoken, int account_id, int SeviceID, Handler handler, DeviceInfo mDevice) {
        String strIP = mDevice.getStrIP();
        int nPort = mDevice.getnPort();
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        System.out.println("set server IP:" + strIP + "Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            Log.d("dqx", "isConnectOK = " + isConnectOK);
            if (isConnectOK) {
                nResult = 259;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) NV_IPC_DEVICE_TOKEN_GET_REQUEST, buffer, 0);
                Functions.IntToBytes((long) DevID, buffer, 4);
                if (Username != null) {
                    System.arraycopy(Username.getBytes(), 0, buffer, 8, Username.getBytes().length);
                }
                if (Password != null) {
                    System.arraycopy(Password.getBytes(), 0, buffer, 40, Password.getBytes().length);
                }
                if (accesstoken != null) {
                    System.arraycopy(accesstoken.getBytes(), 0, buffer, 72, accesstoken.getBytes().length);
                }
                Functions.IntToBytes((long) account_id, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_REQUEST);
                Functions.IntToBytes((long) SeviceID, buffer, Defines.NV_IPC_ALIVE);
                try {
                    writer.write(buffer, 0, 412);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                boolean bReadOK = false;
                while (nSearchID == _nSearchID && tryTimes < 50) {
                    do {
                        if (reader.available() >= 16) {
                            Arrays.fill(buffer, (byte) 0);
                            reader.read(buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(200);
                        } catch (InterruptedException e5) {
                            e5.printStackTrace();
                        }
                        tryTimes++;
                        if (tryTimes >= 50) {
                            break;
                        }
                        try {
                            if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                break;
                            }
                        } catch (IOException e6) {
                        }
                    } while (nSearchID == _nSearchID);
                    Log.d("dqx", "bReadOK = " + bReadOK);
                    if (bReadOK) {
                        nResult = 256;
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int result = Functions.BytesToInt(buffer, 4);
                        int devicetoken = Functions.BytesToInt(buffer, 8);
                        if (nCMD == 260) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e52) {
                                e52.printStackTrace();
                            }
                        } else if (nCMD == NV_IPC_DEVICE_TOKEN_GET_RESPONSE) {
                            if (nSearchID == _nSearchID) {
                                msg = handler.obtainMessage();
                                msg.what = 77;
                                msg.arg1 = result;
                                msg.arg2 = devicetoken;
                                handler.sendMessage(msg);
                                break;
                            }
                        } else if (nCMD == -100) {
                            if (nSearchID == _nSearchID) {
                                msg = handler.obtainMessage();
                                msg.what = 77;
                                msg.arg1 = result;
                                msg.arg2 = nCMD;
                                handler.sendMessage(msg);
                                break;
                            }
                        } else if (nSearchID == _nSearchID) {
                            msg = handler.obtainMessage();
                            msg.what = 77;
                            msg.arg1 = result;
                            msg.arg2 = nCMD;
                            handler.sendMessage(msg);
                            break;
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e7) {
                    e7.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return nResult;
        } catch (IOException e8) {
            isConnectOK = false;
            nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
    }

    public static int Cloud_getDeviceTokenMR(int nSearchID, int DevID, String Username, String Password, String accesstoken, int account_id, int SeviceID, Handler handler, DeviceInfo mDevice) {
        String strDomain = mDevice.getStrDomain();
        int nPort = mDevice.getnPort();
        String strMRServerIP = mDevice.getStrMRServer();
        int nMRPort = mDevice.getnMRPort();
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        System.out.println("set server IP:" + strMRServerIP + "Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, Defines.CMD_MR_WAIT, mDevice.getnDevID());
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                nResult = 259;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 881, buffer, 0);
                Functions.IntToBytes((long) 1002, buffer, 4);
                if (strDomain != null) {
                    System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                }
                Functions.IntToBytes((long) nPort, buffer, 58);
                if (Username != null) {
                    System.arraycopy(Username.getBytes(), 0, buffer, 62, Username.getBytes().length);
                }
                if (Password != null) {
                    System.arraycopy(Password.getBytes(), 0, buffer, 94, Password.getBytes().length);
                }
                Functions.IntToBytes((long) DevID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                Functions.IntToBytes((long) NV_IPC_DEVICE_TOKEN_GET_REQUEST, buffer, 130);
                if (accesstoken != null) {
                    System.arraycopy(accesstoken.getBytes(), 0, buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST, accesstoken.getBytes().length);
                }
                Functions.IntToBytes((long) account_id, buffer, 198);
                Functions.IntToBytes((long) SeviceID, buffer, 202);
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                boolean bReadOK = false;
                while (nSearchID == _nSearchID && tryTimes < 50) {
                    do {
                        if (reader.available() >= 16) {
                            Arrays.fill(buffer, (byte) 0);
                            reader.read(buffer, 0, 64);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(200);
                        } catch (InterruptedException e5) {
                            e5.printStackTrace();
                        }
                        tryTimes++;
                        if (tryTimes >= 50) {
                            break;
                        }
                        try {
                            if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                break;
                            }
                        } catch (IOException e6) {
                        }
                    } while (nSearchID == _nSearchID);
                    Log.d("dqx", "MRbReadOK = " + bReadOK);
                    if (bReadOK) {
                        nResult = 256;
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int result = Functions.BytesToInt(buffer, 4);
                        int devicetoken = Functions.BytesToInt(buffer, 8);
                        if (nCMD == 260) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e52) {
                                e52.printStackTrace();
                            }
                        } else if (nCMD == NV_IPC_DEVICE_TOKEN_GET_RESPONSE) {
                            if (nSearchID == _nSearchID) {
                                msg = handler.obtainMessage();
                                msg.what = 77;
                                msg.arg1 = result;
                                msg.arg2 = devicetoken;
                                handler.sendMessage(msg);
                                break;
                            }
                        } else if (nCMD == -100) {
                            if (nSearchID == _nSearchID) {
                                msg = handler.obtainMessage();
                                msg.what = 77;
                                msg.arg1 = result;
                                msg.arg2 = nCMD;
                                handler.sendMessage(msg);
                                break;
                            }
                        } else if (nSearchID == _nSearchID) {
                            msg = handler.obtainMessage();
                            msg.what = 77;
                            msg.arg1 = result;
                            msg.arg2 = nCMD;
                            handler.sendMessage(msg);
                            break;
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e7) {
                    e7.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return nResult;
        } catch (IOException e8) {
            isConnectOK = false;
            nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
    }

    public static int Cloud_ActivateDevice(int nSearchID, int DevID, String Username, String Password, String accesstoken, int account_id, int SeviceID, Handler handler, DeviceInfo mDevice) {
        String strIP = mDevice.getStrIP();
        int nPort = mDevice.getnPort();
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        System.out.println("set server IP:" + strIP + "Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                System.out.println("socket连接成功");
                nResult = 259;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) NV_IPC_ENABLE_SERVICE_BIND_GET_REQUEST, buffer, 0);
                Functions.IntToBytes((long) DevID, buffer, 4);
                if (Username != null) {
                    System.arraycopy(Username.getBytes(), 0, buffer, 8, Username.getBytes().length);
                }
                if (Password != null) {
                    System.arraycopy(Password.getBytes(), 0, buffer, 40, Password.getBytes().length);
                }
                if (accesstoken != null) {
                    System.arraycopy(accesstoken.getBytes(), 0, buffer, 72, accesstoken.getBytes().length);
                }
                Functions.IntToBytes((long) account_id, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_REQUEST);
                Functions.IntToBytes((long) SeviceID, buffer, Defines.NV_IPC_ALIVE);
                try {
                    writer.write(buffer, 0, 412);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                boolean bReadOK = false;
                while (nSearchID == _nSearchID && tryTimes < 50) {
                    do {
                        if (reader.available() >= 16) {
                            Arrays.fill(buffer, (byte) 0);
                            reader.read(buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(200);
                        } catch (InterruptedException e5) {
                            e5.printStackTrace();
                        }
                        tryTimes++;
                        if (tryTimes >= 50) {
                            break;
                        }
                        try {
                            if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                break;
                            }
                        } catch (IOException e6) {
                        }
                    } while (nSearchID == _nSearchID);
                    if (bReadOK) {
                        nResult = 256;
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int result = Functions.BytesToInt(buffer, 4);
                        int timeStamp = BytesToInt_8Byte(buffer, 8);
                        if (nCMD == 260) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e52) {
                                e52.printStackTrace();
                            }
                        } else if (nCMD == NV_IPC_ENABLE_SERVICE_BIND_GET_RESPONSE) {
                            if (nSearchID == _nSearchID) {
                                msg = handler.obtainMessage();
                                msg.what = 78;
                                msg.arg1 = result;
                                msg.arg2 = timeStamp;
                                handler.sendMessage(msg);
                                break;
                            }
                        } else if (nSearchID == _nSearchID) {
                            msg = handler.obtainMessage();
                            msg.what = 78;
                            msg.arg1 = result;
                            handler.sendMessage(msg);
                            break;
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e7) {
                    e7.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return nResult;
        } catch (IOException e8) {
            isConnectOK = false;
            nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
    }

    public static int Cloud_ActivateDeviceMR(int nSearchID, int DevID, String Username, String Password, String accesstoken, int account_id, int SeviceID, Handler handler, DeviceInfo mDevice) {
        String strDomain = mDevice.getStrDomain();
        int nPort = mDevice.getnPort();
        String strMRServerIP = mDevice.getStrMRServer();
        int nMRPort = mDevice.getnMRPort();
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        System.out.println("set server IP:" + strMRServerIP + "Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, Defines.CMD_MR_WAIT, mDevice.getnDevID());
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                nResult = 259;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 881, buffer, 0);
                Functions.IntToBytes((long) 1002, buffer, 4);
                if (strDomain != null) {
                    System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                }
                Functions.IntToBytes((long) nPort, buffer, 58);
                if (Username != null) {
                    System.arraycopy(Username.getBytes(), 0, buffer, 62, Username.getBytes().length);
                }
                if (Password != null) {
                    System.arraycopy(Password.getBytes(), 0, buffer, 94, Password.getBytes().length);
                }
                Functions.IntToBytes((long) DevID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                Functions.IntToBytes((long) NV_IPC_ENABLE_SERVICE_BIND_GET_REQUEST, buffer, 130);
                if (accesstoken != null) {
                    System.arraycopy(accesstoken.getBytes(), 0, buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST, accesstoken.getBytes().length);
                }
                Functions.IntToBytes((long) account_id, buffer, 198);
                Functions.IntToBytes((long) SeviceID, buffer, 202);
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                boolean bReadOK = false;
                while (nSearchID == _nSearchID && tryTimes < 50) {
                    do {
                        if (reader.available() >= 16) {
                            Arrays.fill(buffer, (byte) 0);
                            reader.read(buffer, 0, 64);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(200);
                        } catch (InterruptedException e5) {
                            e5.printStackTrace();
                        }
                        tryTimes++;
                        if (tryTimes >= 50) {
                            break;
                        }
                        try {
                            if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                break;
                            }
                        } catch (IOException e6) {
                        }
                    } while (nSearchID == _nSearchID);
                    if (bReadOK) {
                        nResult = 256;
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int result = Functions.BytesToInt(buffer, 4);
                        int timeStamp = BytesToInt_8Byte(buffer, 8);
                        if (nCMD == 260) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e52) {
                                e52.printStackTrace();
                            }
                        } else if (nCMD == NV_IPC_ENABLE_SERVICE_BIND_GET_RESPONSE) {
                            if (nSearchID == _nSearchID) {
                                msg = handler.obtainMessage();
                                msg.what = 78;
                                msg.arg1 = result;
                                msg.arg2 = timeStamp;
                                handler.sendMessage(msg);
                                break;
                            }
                        } else if (nSearchID == _nSearchID) {
                            msg = handler.obtainMessage();
                            msg.what = 78;
                            msg.arg1 = result;
                            handler.sendMessage(msg);
                            break;
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e7) {
                    e7.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return nResult;
        } catch (IOException e8) {
            isConnectOK = false;
            nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
    }

    public static int getDeviceToken(int nSearchID, int DevID, String Username, String Password, String accesstoken, int account_id, int SeviceID, Handler handler, DeviceInfo mDevice) {
        System.out.println("accesstoken == " + accesstoken);
        int result = Cloud_getDeviceToken(nSearchID, DevID, Username, Password, accesstoken, account_id, SeviceID, handler, mDevice);
        if (result == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
            return Cloud_getDeviceTokenMR(nSearchID, DevID, Username, Password, accesstoken, account_id, SeviceID, handler, mDevice);
        }
        return result;
    }

    public static int activateService(int nSearchID, int DevID, String Username, String Password, String accesstoken, int account_id, int SeviceID, Handler handler, DeviceInfo mDevice) {
        int result = Cloud_ActivateDevice(nSearchID, DevID, Username, Password, accesstoken, account_id, SeviceID, handler, mDevice);
        if (result == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
            return Cloud_ActivateDeviceMR(nSearchID, DevID, Username, Password, accesstoken, account_id, SeviceID, handler, mDevice);
        }
        return result;
    }

    public static int Cloud_getRecordFileServer(int nSearchID, String token, int account_id, Handler handler, long lHandle, String strIP, int nPort, int nSearcgChn, int nSearchType, short nYear, short nMonth, short nDay, short nStartHour, short nStartMin, short nStartSec, short nEndHour, short nEndMin, short nEndSec) {
        byte[] bytetoken = null;
        try {
            bytetoken = token.getBytes("utf-8");
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        }
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                nResult = 259;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) Defines.REC_FILE_SEARCH, buffer, 0);
                Functions.IntToBytes((long) account_id, buffer, 4);
                System.arraycopy(bytetoken, 0, buffer, 8, bytetoken.length);
                Functions.IntToBytes(lHandle, buffer, 72);
                buffer[76] = (byte) nSearcgChn;
                buffer[77] = (byte) nSearchType;
                Functions.ShortToBytes(nYear, buffer, 78);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 80);
                Functions.ShortToBytes(nDay, buffer, 82);
                Functions.ShortToBytes(nStartHour, buffer, 84);
                Functions.ShortToBytes(nStartMin, buffer, 86);
                Functions.ShortToBytes(nStartSec, buffer, 88);
                Functions.ShortToBytes(nYear, buffer, 98);
                Functions.ShortToBytes((short) (nMonth + 1), buffer, 100);
                Functions.ShortToBytes(nDay, buffer, 102);
                Functions.ShortToBytes(nEndHour, buffer, DialogTipCode.PHONE_NUMBER_IS_NOT_STANDARDLIZED);
                Functions.ShortToBytes(nEndMin, buffer, 106);
                Functions.ShortToBytes(nEndSec, buffer, 108);
                Functions.IntToBytes((long) 0, buffer, Defines.NV_IPC_USERINFO_SET_REQUEST);
                Functions.IntToBytes((long) 0, buffer, Defines.NV_IP_SWITCH_SET_REQUEST);
                buffer[TransportMediator.KEYCODE_MEDIA_PLAY] = (byte) 1;
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e3) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e4) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e5) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                boolean bReadOK = false;
                int nFileCount = 0;
                ArrayList<RecordFileInfo> fileList = new ArrayList();
                ArrayList<RecordFileInfo> recfileList = new ArrayList();
                LoginHandle loginHandle = new LoginHandle();
                int RecTotalCount = 0;
                int FileCount = 0;
                while (nSearchID == _nSearchID && tryTimes < 50) {
                    do {
                        if (reader.available() >= 16) {
                            Arrays.fill(buffer, (byte) 0);
                            reader.read(buffer, 0, 16);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(200);
                        } catch (InterruptedException e6) {
                            e6.printStackTrace();
                        }
                        tryTimes++;
                        if (tryTimes >= 50) {
                            break;
                        }
                        try {
                            if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                break;
                            }
                        } catch (IOException e7) {
                        }
                    } while (nSearchID == _nSearchID);
                    if (bReadOK) {
                        nResult = 256;
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        if (nCMD == 350) {
                            RecTotalCount = Functions.BytesToInt(buffer, 4);
                            int SendTotal = Functions.BytesToInt(buffer, 8);
                            FileCount = Functions.BytesToInt(buffer, 12);
                        }
                        if (nCMD == 260) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e62) {
                                e62.printStackTrace();
                            }
                        } else if (nCMD == 351) {
                            int camType = buffer[4];
                            int panoX = Functions.BytesToShort(buffer, 5);
                            int panoY = Functions.BytesToShort(buffer, 7);
                            int panoRad = Functions.BytesToShort(buffer, 9);
                            loginHandle.setCamType(camType);
                            loginHandle.setPanoX(panoX);
                            loginHandle.setPanoY(panoY);
                            loginHandle.setPanoRad(panoRad);
                        } else {
                            if (nCMD == 350 && FileCount > 0 && FileCount < 40 && RecTotalCount > 0) {
                                for (int i = 0; i < FileCount; i++) {
                                    do {
                                        if (reader.available() >= 48) {
                                            Arrays.fill(buffer, (byte) 0);
                                            reader.read(buffer, 0, 48);
                                            bReadOK = true;
                                            break;
                                        }
                                        try {
                                            Thread.sleep(200);
                                        } catch (InterruptedException e622) {
                                            e622.printStackTrace();
                                        }
                                        tryTimes++;
                                        if (tryTimes >= 50) {
                                            break;
                                        }
                                        try {
                                            if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                                break;
                                            }
                                        } catch (IOException e8) {
                                        }
                                    } while (nSearchID == _nSearchID);
                                    RecordFileInfo recordFileInfo = new RecordFileInfo();
                                    recordFileInfo.setnFileID(Functions.BytesToInt(buffer, 0));
                                    recordFileInfo.setnFileSize(Functions.BytesToInt(buffer, 4));
                                    StringBuilder sb = new StringBuilder();
                                    int len = 0;
                                    while (len < 32 && len + 8 < buffer.length && ((char) buffer[len + 8]) != '\u0000') {
                                        sb.append((char) buffer[len + 8]);
                                        len++;
                                    }
                                    recordFileInfo.setuStartHour(buffer[40]);
                                    recordFileInfo.setuStartMin(buffer[41]);
                                    recordFileInfo.setuStartSec(buffer[42]);
                                    recordFileInfo.setuEndHour(buffer[43]);
                                    recordFileInfo.setuEndMin(buffer[44]);
                                    recordFileInfo.setuEndSec(buffer[45]);
                                    recordFileInfo.setuFileTimeLen(Functions.BytesToShort(buffer, 46));
                                    recordFileInfo.setStrFileName(new String(sb.toString()));
                                    fileList.add(recordFileInfo);
                                }
                                if (nSearchID == _nSearchID) {
                                    nFileCount += fileList.size();
                                    if (recfileList == null) {
                                        recfileList = new ArrayList();
                                    } else {
                                        recfileList.clear();
                                    }
                                    recfileList.addAll(fileList);
                                }
                            }
                            Message msg;
                            if (RecTotalCount == -1) {
                                nResult = 256;
                                msg = handler.obtainMessage();
                                msg.arg1 = 262;
                                msg.arg2 = 0;
                                handler.sendMessage(msg);
                                break;
                            } else if (RecTotalCount == -2) {
                                nResult = 256;
                                msg = handler.obtainMessage();
                                msg.arg1 = 262;
                                msg.arg2 = nFileCount;
                                Bundle data = new Bundle();
                                data.putParcelableArrayList(Defines.RECORD_FILE_RETURN_MESSAGE, recfileList);
                                data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, loginHandle);
                                msg.setData(data);
                                handler.sendMessage(msg);
                                break;
                            }
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e9) {
                    e9.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return nResult;
        } catch (IOException e10) {
            isConnectOK = false;
            nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
    }

    public static int BytesToInt_8Byte(byte[] buf, int offset) {
        try {
            return (((((((0 + (buf[offset + 0] & 255)) + ((buf[offset + 1] & 255) << 8)) + ((buf[offset + 2] & 255) << 16)) + ((buf[offset + 3] & 255) << 24)) + ((buf[offset + 4] & 255) << 32)) + ((buf[offset + 5] & 255) << 40)) + ((buf[offset + 6] & 255) << 48)) + ((buf[offset + 7] & 255) << 56);
        } catch (ArrayIndexOutOfBoundsException e) {
            return 0;
        }
    }
}
