package com.macrovideo.software.update;

import android.app.Application;
import android.content.pm.PackageManager.NameNotFoundException;

public class MyApplication extends Application {
    public static String downloadDir = "v380";
    public static int localVersion = 0;
    public static int serverVersion = 2;

    public void onCreate() {
        super.onCreate();
        try {
            localVersion = getApplicationContext().getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
    }
}
