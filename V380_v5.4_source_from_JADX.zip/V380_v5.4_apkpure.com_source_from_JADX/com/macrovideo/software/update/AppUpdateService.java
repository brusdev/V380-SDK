package com.macrovideo.software.update;

import android.app.DownloadManager;
import android.app.DownloadManager.Request;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Environment;
import android.os.IBinder;
import android.os.Process;

public class AppUpdateService extends Service {
    private DownloadManager manager;
    private DownloadCompleteReceiver receiver;
    private String strURI = null;

    class DownloadCompleteReceiver extends BroadcastReceiver {
        DownloadCompleteReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("android.intent.action.DOWNLOAD_COMPLETE")) {
                installAPK(AppUpdateService.this.manager.getUriForDownloadedFile(intent.getLongExtra("extra_download_id", -1)));
                AppUpdateService.this.stopSelf();
            }
        }

        private void installAPK(Uri apk) {
            Intent intents = new Intent();
            intents.setAction("android.intent.action.VIEW");
            intents.addCategory("android.intent.category.DEFAULT");
            intents.setType("application/vnd.android.package-archive");
            intents.setData(apk);
            intents.setDataAndType(apk, "application/vnd.android.package-archive");
            intents.setFlags(268435456);
            Process.killProcess(Process.myPid());
            AppUpdateService.this.startActivity(intents);
        }
    }

    public AppUpdateService(String strURI) {
        this.strURI = strURI;
    }

    private void initDownManager() {
        this.manager = (DownloadManager) getSystemService("download");
        this.receiver = new DownloadCompleteReceiver();
        Request down = new Request(Uri.parse(this.strURI));
        down.setAllowedNetworkTypes(3);
        down.setNotificationVisibility(0);
        down.setVisibleInDownloadsUi(true);
        down.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "baidumusic.apk");
        this.manager.enqueue(down);
        registerReceiver(this.receiver, new IntentFilter("android.intent.action.DOWNLOAD_COMPLETE"));
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        initDownManager();
        return super.onStartCommand(intent, flags, startId);
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onDestroy() {
        if (this.receiver != null) {
            unregisterReceiver(this.receiver);
        }
        super.onDestroy();
    }
}
