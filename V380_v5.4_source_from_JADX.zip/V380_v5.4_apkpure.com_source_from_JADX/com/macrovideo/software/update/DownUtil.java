package com.macrovideo.software.update;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownUtil {
    private static final int TIMEOUT = 10000;

    public void downloadUpdateFile(String down_url, String file) throws Exception {
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(down_url).openConnection();
        httpURLConnection.setConnectTimeout(10000);
        httpURLConnection.setReadTimeout(10000);
        int totalSize = httpURLConnection.getContentLength();
        if (httpURLConnection.getResponseCode() == 404) {
            throw new Exception("fail!");
        }
        InputStream inputStream = httpURLConnection.getInputStream();
        OutputStream outputStream = new FileOutputStream(file, false);
        byte[] buffer = new byte[1024];
        while (true) {
            int readsize = inputStream.read(buffer);
            if (readsize != -1) {
                outputStream.write(buffer, 0, readsize);
                totalSize += readsize;
                if (0 != 0) {
                    int i = (totalSize * 100) / totalSize;
                }
            } else {
                return;
            }
        }
    }
}
