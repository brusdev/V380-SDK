package com.macrovideo.software.update;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.NotificationCompat.Builder;
import android.util.Log;
import android.widget.RemoteViews;
import com.macrovideo.v380.C0470R;
import com.macrovideo.v380.HomePageActivity;
import com.tencent.android.tpush.common.Constants;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class UpdateService extends Service {
    private static final int DOWN_ERROR = 0;
    private static final int DOWN_OK = 1;
    private static final int TIMEOUT = 10000;
    private String app_name = "V380";
    private Builder builder = null;
    RemoteViews contentView;
    private String down_url = Constants.MAIN_VERSION_TAG;
    final Handler handler = new C02441();
    private NotificationManager mNotificationManager = null;
    private Notification notification = null;
    private int notification_id = 0;
    private PendingIntent pendingIntent;
    private Intent updateIntent;

    class C02441 extends Handler {
        C02441() {
        }

        public void handleMessage(Message msg) {
            UpdateService.this.mNotificationManager.cancel(UpdateService.this.notification_id);
            switch (msg.what) {
                case 0:
                    UpdateService.this.builder.setContentTitle(UpdateService.this.app_name);
                    UpdateService.this.builder.setContentText(UpdateService.this.getString(C0470R.string.downFail));
                    UpdateService.this.builder.setTicker(UpdateService.this.getString(C0470R.string.downFail));
                    return;
                case 1:
                    Log.w("SS", "DOWN_OK");
                    UpdateService.this.installAPK(FileUtil.strUpdateFile);
                    UpdateService.this.builder.setSmallIcon(C0470R.drawable.download_pressed);
                    UpdateService.this.builder.setDefaults(0);
                    UpdateService.this.builder.setContentTitle(UpdateService.this.app_name);
                    UpdateService.this.builder.setContentText(UpdateService.this.getString(C0470R.string.downWin));
                    UpdateService.this.builder.setTicker(UpdateService.this.getString(C0470R.string.downWin));
                    UpdateService.this.mNotificationManager.cancel(UpdateService.this.notification_id);
                    UpdateService.this.mNotificationManager.notify(UpdateService.this.notification_id, UpdateService.this.builder.build());
                    UpdateService.this.stopSelf();
                    return;
                default:
                    UpdateService.this.stopService(UpdateService.this.updateIntent);
                    return;
            }
        }
    }

    class C02452 implements Runnable {
        C02452() {
        }

        public void run() {
            Message msg;
            try {
                if (UpdateService.this.downloadUpdateFile(UpdateService.this.down_url, FileUtil.strUpdateFile) > 0) {
                    msg = UpdateService.this.handler.obtainMessage();
                    msg.what = 1;
                    UpdateService.this.handler.sendMessage(msg);
                }
            } catch (Exception e) {
                msg = UpdateService.this.handler.obtainMessage();
                msg.what = 0;
                UpdateService.this.handler.sendMessage(msg);
            }
        }
    }

    public IBinder onBind(Intent arg0) {
        return null;
    }

    @SuppressLint({"InlinedApi"})
    public int onStartCommand(Intent intent, int flags, int startId) {
        this.down_url = intent.getStringExtra("updateSite");
        this.app_name = intent.getStringExtra("app_name");
        FileUtil.initFile(this.app_name);
        createNotification();
        startDownLoad();
        return 0;
    }

    public void startDownLoad() {
        new Thread(new C02452()).start();
    }

    public void createNotification() {
        this.mNotificationManager = (NotificationManager) getSystemService("notification");
        this.builder = new Builder(getApplicationContext());
        this.builder.setSmallIcon(C0470R.drawable.download_pressed);
        this.builder.setDefaults(0);
        this.contentView = new RemoteViews(getPackageName(), C0470R.layout.app_update_notification);
        this.contentView.setTextViewText(C0470R.id.notificationTitle, getString(C0470R.string.Downing));
        this.contentView.setTextViewText(C0470R.id.notificationPercent, "0%");
        this.contentView.setProgressBar(C0470R.id.notificationProgress, 100, 0, false);
        this.notification = this.builder.build();
        this.notification.contentView = this.contentView;
        this.updateIntent = new Intent(this, HomePageActivity.class);
        this.updateIntent.addFlags(536870912);
        this.pendingIntent = PendingIntent.getActivity(this, 0, this.updateIntent, 0);
        this.notification.contentIntent = this.pendingIntent;
        this.mNotificationManager.notify(this.notification_id, this.notification);
    }

    public long downloadUpdateFile(String down_url, String file) throws Exception {
        int downloadCount = 0;
        int updateCount = 0;
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(down_url).openConnection();
        httpURLConnection.setConnectTimeout(10000);
        httpURLConnection.setReadTimeout(10000);
        int totalSize = httpURLConnection.getContentLength();
        if (httpURLConnection.getResponseCode() == 404) {
            throw new Exception("fail!");
        }
        InputStream inputStream = httpURLConnection.getInputStream();
        OutputStream outputStream = new FileOutputStream(file, false);
        byte[] buffer = new byte[1024];
        while (true) {
            int readsize = inputStream.read(buffer);
            if (readsize == -1) {
                break;
            }
            outputStream.write(buffer, 0, readsize);
            downloadCount += readsize;
            if (updateCount == 0 || ((downloadCount * 100) / totalSize) - 1 >= updateCount) {
                updateCount++;
                this.contentView.setTextViewText(C0470R.id.notificationPercent, new StringBuilder(String.valueOf(updateCount)).append("%").toString());
                this.contentView.setProgressBar(C0470R.id.notificationProgress, 100, updateCount, false);
                this.notification = this.builder.build();
                this.notification.contentView = this.contentView;
                this.mNotificationManager.notify(this.notification_id, this.notification);
            }
        }
        if (httpURLConnection != null) {
            httpURLConnection.disconnect();
        }
        inputStream.close();
        outputStream.close();
        return (long) downloadCount;
    }

    private void installAPK(String strSavePath) {
        Intent i = new Intent();
        i.putExtra("apk_path", strSavePath);
        i.setFlags(268435456);
        i.setClass(getApplicationContext(), InstallAppActivity.class);
        startActivity(i);
    }
}
