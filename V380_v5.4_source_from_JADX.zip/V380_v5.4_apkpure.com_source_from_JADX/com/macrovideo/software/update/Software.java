package com.macrovideo.software.update;

public class Software {
    private int nAppID = 0;
    private int nForceUdate = 0;
    private int nSize = 0;
    private int nSystemID = 0;
    private int nSystemVer = 0;
    private int nVersionNum;
    private String strCompany = null;
    private String strDescription = null;
    private String strName = null;
    private String strReleaseDate = null;
    private String strSite = null;
    private String strVersionName;

    public int getnAppID() {
        return this.nAppID;
    }

    public void setnAppID(int nAppID) {
        this.nAppID = nAppID;
    }

    public String getStrName() {
        return this.strName;
    }

    public void setStrName(String strName) {
        this.strName = strName;
    }

    public int getnSize() {
        return this.nSize;
    }

    public void setnSize(int nSize) {
        this.nSize = nSize;
    }

    public String getStrReleaseDate() {
        return this.strReleaseDate;
    }

    public void setStrReleaseDate(String strReleaseDate) {
        this.strReleaseDate = strReleaseDate;
    }

    public int getnVersionNum() {
        return this.nVersionNum;
    }

    public void setnVersionNum(int nVersionNum) {
        this.nVersionNum = nVersionNum;
    }

    public String getStrVersionName() {
        return this.strVersionName;
    }

    public void setStrVersionName(String strVersionName) {
        this.strVersionName = strVersionName;
    }

    public String getStrCompany() {
        return this.strCompany;
    }

    public void setStrCompany(String strCompany) {
        this.strCompany = strCompany;
    }

    public String getStrSite() {
        return this.strSite;
    }

    public void setStrSite(String strSite) {
        this.strSite = strSite;
    }

    public String getStrDescription() {
        return this.strDescription;
    }

    public void setStrDescription(String strDescription) {
        this.strDescription = strDescription;
    }

    public int getnSystemID() {
        return this.nSystemID;
    }

    public void setnSystemID(int nSystemID) {
        this.nSystemID = nSystemID;
    }

    public int getnSystemVer() {
        return this.nSystemVer;
    }

    public void setnSystemVer(int nSystemVer) {
        this.nSystemVer = nSystemVer;
    }

    public int getnForceUdate() {
        return this.nForceUdate;
    }

    public void setnForceUdate(int nForceUdate) {
        this.nForceUdate = nForceUdate;
    }
}
