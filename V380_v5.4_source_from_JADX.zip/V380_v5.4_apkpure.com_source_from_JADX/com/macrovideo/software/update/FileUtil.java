package com.macrovideo.software.update;

import android.os.Environment;
import android.util.Log;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.LocalDefines;
import java.io.File;
import java.io.IOException;

public class FileUtil {
    public static String strUpdateDir = null;
    public static String strUpdateFile = null;
    public static File updateDir = null;
    public static File updateFile = null;

    public static void createFile1(String name) {
        if ("mounted".equals(Environment.getExternalStorageState())) {
            strUpdateDir = Environment.getExternalStorageDirectory() + "/" + MyApplication.downloadDir;
            strUpdateFile = strUpdateDir + name + ".apk";
            updateDir = new File(strUpdateDir);
            updateFile = new File(strUpdateFile);
            Log.w("createFile", updateFile.toString());
            if (!updateDir.exists()) {
                updateDir.mkdirs();
            }
            if (!updateFile.exists()) {
                try {
                    updateFile.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void initFile(String name) {
        if ("mounted".equals(Environment.getExternalStorageState())) {
            strUpdateDir = Functions.GetSDPath() + File.separator + LocalDefines.SDCardPath + File.separator + LocalDefines.DownAPPDir;
            strUpdateFile = strUpdateDir + File.separator + name + ".apk";
            updateDir = new File(strUpdateDir);
            updateFile = new File(strUpdateFile);
            if (!updateDir.exists()) {
                updateDir.mkdirs();
            }
            if (updateFile.exists()) {
                updateFile.delete();
            }
            try {
                updateFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
