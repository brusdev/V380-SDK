package com.macrovideo.software.update;

public class Cache {
    public static boolean check = true;
}
