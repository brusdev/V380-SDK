package com.macrovideo.software.update;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import com.macrovideo.v380.C0470R;
import java.io.File;

public class InstallAppActivity extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        super.onCreate(savedInstanceState);
        setContentView(C0470R.layout.activity_wellcome);
        File apkfile = new File(getIntent().getStringExtra("apk_path"));
        if (apkfile.exists()) {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setDataAndType(Uri.parse("file://" + apkfile.toString()), "application/vnd.android.package-archive");
            try {
                startActivity(i);
            } catch (Error e) {
                Log.w("ee", e.toString());
            }
            Process.killProcess(Process.myPid());
            finish();
        }
    }

    public void onStop() {
        super.onStop();
    }

    public void onResume() {
        super.onResume();
    }

    protected void onDestroy() {
        super.onDestroy();
    }
}
