package com.macrovideo.materialshowcaseview;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.graphics.Point;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import com.macrovideo.materialshowcaseview.IAnimationFactory.AnimationEndListener;
import com.macrovideo.materialshowcaseview.IAnimationFactory.AnimationStartListener;

public class AnimationFactory implements IAnimationFactory {
    private static final String ALPHA = "alpha";
    private static final float INVISIBLE = 0.0f;
    private static final float VISIBLE = 1.0f;
    private final AccelerateDecelerateInterpolator interpolator = new AccelerateDecelerateInterpolator();

    public void fadeInView(View target, long duration, final AnimationStartListener listener) {
        ObjectAnimator oa = ObjectAnimator.ofFloat(target, ALPHA, new float[]{0.0f, 1.0f});
        oa.setDuration(duration).addListener(new AnimatorListener() {
            public void onAnimationStart(Animator animator) {
                listener.onAnimationStart();
            }

            public void onAnimationEnd(Animator animator) {
            }

            public void onAnimationCancel(Animator animator) {
            }

            public void onAnimationRepeat(Animator animator) {
            }
        });
        oa.start();
    }

    public void fadeOutView(View target, long duration, final AnimationEndListener listener) {
        ObjectAnimator oa = ObjectAnimator.ofFloat(target, ALPHA, new float[]{0.0f});
        oa.setDuration(duration).addListener(new AnimatorListener() {
            public void onAnimationStart(Animator animator) {
            }

            public void onAnimationEnd(Animator animator) {
                listener.onAnimationEnd();
            }

            public void onAnimationCancel(Animator animator) {
            }

            public void onAnimationRepeat(Animator animator) {
            }
        });
        oa.start();
    }

    public void animateTargetToPoint(MaterialShowcaseView showcaseView, Point point) {
        AnimatorSet set = new AnimatorSet();
        ObjectAnimator xAnimator = ObjectAnimator.ofInt(showcaseView, "showcaseX", new int[]{point.x});
        ObjectAnimator yAnimator = ObjectAnimator.ofInt(showcaseView, "showcaseY", new int[]{point.y});
        set.playTogether(new Animator[]{xAnimator, yAnimator});
        set.setInterpolator(this.interpolator);
        set.start();
    }
}
