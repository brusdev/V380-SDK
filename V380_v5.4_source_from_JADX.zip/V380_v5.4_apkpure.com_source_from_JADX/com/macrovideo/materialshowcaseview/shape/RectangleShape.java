package com.macrovideo.materialshowcaseview.shape;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import com.macrovideo.materialshowcaseview.target.Target;

public class RectangleShape implements Shape {
    private boolean adjustToTarget;
    private boolean fullWidth;
    private int height;
    private Rect rect;
    private int width;

    public RectangleShape(int width, int height) {
        this.fullWidth = false;
        this.width = 0;
        this.height = 0;
        this.adjustToTarget = true;
        this.width = width;
        this.height = height;
        init();
    }

    public RectangleShape(Rect bounds) {
        this(bounds, false);
    }

    public RectangleShape(Rect bounds, boolean fullWidth) {
        this.fullWidth = false;
        this.width = 0;
        this.height = 0;
        this.adjustToTarget = true;
        this.fullWidth = fullWidth;
        this.height = bounds.height();
        if (fullWidth) {
            this.width = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        } else {
            this.width = bounds.width();
        }
        init();
    }

    public boolean isAdjustToTarget() {
        return this.adjustToTarget;
    }

    public void setAdjustToTarget(boolean adjustToTarget) {
        this.adjustToTarget = adjustToTarget;
    }

    private void init() {
        this.rect = new Rect((-this.width) / 2, (-this.height) / 2, this.width / 2, this.height / 2);
    }

    public void draw(Canvas canvas, Paint paint, int x, int y, int padding) {
        if (!this.rect.isEmpty()) {
            canvas.drawRect((float) ((this.rect.left + x) - padding), (float) ((this.rect.top + y) - padding), (float) ((this.rect.right + x) + padding), (float) ((this.rect.bottom + y) + padding), paint);
        }
    }

    public void updateTarget(Target target) {
        if (this.adjustToTarget) {
            Rect bounds = target.getBounds();
            this.height = bounds.height();
            if (this.fullWidth) {
                this.width = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
            } else {
                this.width = bounds.width();
            }
            init();
        }
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }
}
