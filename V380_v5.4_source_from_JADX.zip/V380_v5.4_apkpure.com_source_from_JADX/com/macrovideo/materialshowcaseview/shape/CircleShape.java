package com.macrovideo.materialshowcaseview.shape;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import com.macrovideo.materialshowcaseview.target.Target;

public class CircleShape implements Shape {
    private boolean adjustToTarget;
    private int radius;

    public CircleShape() {
        this.radius = 200;
        this.adjustToTarget = true;
    }

    public CircleShape(int radius) {
        this.radius = 200;
        this.adjustToTarget = true;
        this.radius = radius;
    }

    public CircleShape(Rect bounds) {
        this(getPreferredRadius(bounds));
    }

    public CircleShape(Target target) {
        this(target.getBounds());
    }

    public void setAdjustToTarget(boolean adjustToTarget) {
        this.adjustToTarget = adjustToTarget;
    }

    public boolean isAdjustToTarget() {
        return this.adjustToTarget;
    }

    public int getRadius() {
        return this.radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public void draw(Canvas canvas, Paint paint, int x, int y, int padding) {
        if (this.radius > 0) {
            canvas.drawCircle((float) x, (float) y, (float) (this.radius + padding), paint);
        }
    }

    public void updateTarget(Target target) {
        if (this.adjustToTarget) {
            this.radius = getPreferredRadius(target.getBounds());
        }
    }

    public int getWidth() {
        return this.radius * 2;
    }

    public int getHeight() {
        return this.radius * 2;
    }

    public static int getPreferredRadius(Rect bounds) {
        return Math.max(bounds.width(), bounds.height()) / 2;
    }
}
