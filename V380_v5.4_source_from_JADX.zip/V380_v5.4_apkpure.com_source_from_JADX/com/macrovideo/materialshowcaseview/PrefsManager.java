package com.macrovideo.materialshowcaseview;

import android.content.Context;

public class PrefsManager {
    private static final String PREFS_NAME = "material_showcaseview_prefs";
    public static int SEQUENCE_FINISHED = -1;
    public static int SEQUENCE_NEVER_STARTED = 0;
    private static final String STATUS = "status_";
    private Context context;
    private String showcaseID = null;

    public PrefsManager(Context context, String showcaseID) {
        this.context = context;
        this.showcaseID = showcaseID;
    }

    boolean hasFired() {
        return getSequenceStatus() == SEQUENCE_FINISHED;
    }

    void setFired() {
        setSequenceStatus(SEQUENCE_FINISHED);
    }

    int getSequenceStatus() {
        return this.context.getSharedPreferences(PREFS_NAME, 0).getInt(new StringBuilder(STATUS).append(this.showcaseID).toString(), SEQUENCE_NEVER_STARTED);
    }

    void setSequenceStatus(int status) {
        this.context.getSharedPreferences(PREFS_NAME, 0).edit().putInt(new StringBuilder(STATUS).append(this.showcaseID).toString(), status).apply();
    }

    public void resetShowcase() {
        resetShowcase(this.context, this.showcaseID);
    }

    static void resetShowcase(Context context, String showcaseID) {
        context.getSharedPreferences(PREFS_NAME, 0).edit().putInt(new StringBuilder(STATUS).append(showcaseID).toString(), SEQUENCE_NEVER_STARTED).apply();
    }

    public static void resetAll(Context context) {
        context.getSharedPreferences(PREFS_NAME, 0).edit().clear().apply();
    }

    public void close() {
        this.context = null;
    }
}
