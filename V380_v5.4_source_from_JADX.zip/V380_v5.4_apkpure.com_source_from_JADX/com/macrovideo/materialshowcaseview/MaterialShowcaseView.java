package com.macrovideo.materialshowcaseview;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Handler;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.macrovideo.materialshowcaseview.IAnimationFactory.AnimationEndListener;
import com.macrovideo.materialshowcaseview.IAnimationFactory.AnimationStartListener;
import com.macrovideo.materialshowcaseview.shape.CircleShape;
import com.macrovideo.materialshowcaseview.shape.NoShape;
import com.macrovideo.materialshowcaseview.shape.RectangleShape;
import com.macrovideo.materialshowcaseview.shape.Shape;
import com.macrovideo.materialshowcaseview.target.Target;
import com.macrovideo.materialshowcaseview.target.ViewTarget;
import com.macrovideo.v380.C0470R;
import java.util.ArrayList;
import java.util.List;

public class MaterialShowcaseView extends FrameLayout implements OnTouchListener, OnClickListener {
    private AnimationFactory mAnimationFactory;
    private Bitmap mBitmap;
    private int mBottomMargin = 0;
    private Canvas mCanvas;
    private int mContentBottomMargin;
    private View mContentBox;
    private int mContentTextGravity;
    private TextView mContentTextView;
    private int mContentTopMargin;
    private long mDelayInMillis = 0;
    private IDetachedListener mDetachedListener;
    private TextView mDismissButton;
    private boolean mDismissOnTouch = false;
    private Paint mEraser;
    private long mFadeDurationInMillis = 300;
    private int mGravity;
    private int mGravity_center = 17;
    private int mGravity_left = 3;
    private int mGravity_right = 5;
    private Handler mHandler;
    private int mImageGravity;
    private ImageView mIvDown;
    private ImageView mIvTop;
    private LinearLayout mLLDown;
    private LinearLayout mLLTop;
    private UpdateOnGlobalLayout mLayoutListener;
    List<IShowcaseListener> mListeners;
    private int mMaskColour;
    private int mOldHeight;
    private int mOldWidth;
    private PrefsManager mPrefsManager;
    private Shape mShape;
    private int mShapePadding = 10;
    private boolean mShouldAnimate = true;
    private boolean mShouldRender = false;
    private boolean mSingleUse = false;
    private Target mTarget;
    private boolean mWasDismissed = false;
    private int mXPosition;
    private int mYPosition;

    class C02231 implements Runnable {
        C02231() {
        }

        public void run() {
            if (MaterialShowcaseView.this.mShouldAnimate) {
                MaterialShowcaseView.this.fadeIn();
                return;
            }
            MaterialShowcaseView.this.setVisibility(0);
            MaterialShowcaseView.this.notifyOnDisplayed();
        }
    }

    public static class Builder {
        private static final int CIRCLE_SHAPE = 0;
        private static final int NO_SHAPE = 2;
        private static final int RECTANGLE_SHAPE = 1;
        private final Activity activity;
        private boolean fullWidth = false;
        private int shapeType = 0;
        final MaterialShowcaseView showcaseView;

        public Builder(Activity activity) {
            this.activity = activity;
            this.showcaseView = new MaterialShowcaseView(activity);
        }

        public Builder setTarget(View target) {
            this.showcaseView.setTarget(new ViewTarget(target));
            return this;
        }

        public Builder setDismissText(int resId) {
            return setDismissText(this.activity.getString(resId));
        }

        public Builder setDismissText(CharSequence dismissText) {
            this.showcaseView.setDismissText(dismissText);
            return this;
        }

        public Builder setContentText(int resId) {
            return setContentText(this.activity.getString(resId));
        }

        public Builder setContentText(CharSequence text) {
            this.showcaseView.setContentText(text);
            return this;
        }

        public Builder setDismissOnTouch(boolean dismissOnTouch) {
            this.showcaseView.setDismissOnTouch(dismissOnTouch);
            return this;
        }

        public Builder setMaskColour(int maskColour) {
            this.showcaseView.setMaskColour(maskColour);
            return this;
        }

        public Builder setContentTextColor(int textColour) {
            this.showcaseView.setContentTextColor(textColour);
            return this;
        }

        public Builder setDismissTextColor(int textColour) {
            this.showcaseView.setDismissTextColor(textColour);
            return this;
        }

        public Builder setDelay(int delayInMillis) {
            this.showcaseView.setDelay((long) delayInMillis);
            return this;
        }

        public Builder setFadeDuration(int fadeDurationInMillis) {
            this.showcaseView.setFadeDuration((long) fadeDurationInMillis);
            return this;
        }

        public Builder setListener(IShowcaseListener listener) {
            this.showcaseView.addShowcaseListener(listener);
            return this;
        }

        public Builder singleUse(String showcaseID) {
            this.showcaseView.singleUse(showcaseID);
            return this;
        }

        public Builder setShape(Shape shape) {
            this.showcaseView.setShape(shape);
            return this;
        }

        public Builder withCircleShape() {
            this.shapeType = 0;
            return this;
        }

        public Builder withoutShape() {
            this.shapeType = 2;
            return this;
        }

        public Builder setShapePadding(int padding) {
            this.showcaseView.setShapePadding(padding);
            return this;
        }

        public Builder withRectangleShape() {
            return withRectangleShape(false);
        }

        public Builder withRectangleShape(boolean fullWidth) {
            this.shapeType = 1;
            this.fullWidth = fullWidth;
            return this;
        }

        public MaterialShowcaseView build() {
            if (this.showcaseView.mShape == null) {
                switch (this.shapeType) {
                    case 0:
                        this.showcaseView.setShape(new CircleShape(this.showcaseView.mTarget));
                        break;
                    case 1:
                        this.showcaseView.setShape(new RectangleShape(this.showcaseView.mTarget.getBounds(), this.fullWidth));
                        break;
                    case 2:
                        this.showcaseView.setShape(new NoShape());
                        break;
                    default:
                        throw new IllegalArgumentException("Unsupported shape type: " + this.shapeType);
                }
            }
            return this.showcaseView;
        }

        public MaterialShowcaseView show() {
            build().show(this.activity);
            return this.showcaseView;
        }
    }

    private class UpdateOnGlobalLayout implements OnGlobalLayoutListener {
        private UpdateOnGlobalLayout() {
        }

        public void onGlobalLayout() {
            MaterialShowcaseView.this.setTarget(MaterialShowcaseView.this.mTarget);
        }
    }

    class C08322 implements AnimationStartListener {
        C08322() {
        }

        public void onAnimationStart() {
            MaterialShowcaseView.this.setVisibility(0);
            MaterialShowcaseView.this.notifyOnDisplayed();
        }
    }

    class C08333 implements AnimationEndListener {
        C08333() {
        }

        public void onAnimationEnd() {
            MaterialShowcaseView.this.setVisibility(4);
            MaterialShowcaseView.this.removeFromWindow();
        }
    }

    public MaterialShowcaseView(Context context) {
        super(context);
        init(context);
    }

    public MaterialShowcaseView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public MaterialShowcaseView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    @TargetApi(21)
    public MaterialShowcaseView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(Context context) {
        setWillNotDraw(false);
        this.mAnimationFactory = new AnimationFactory();
        this.mListeners = new ArrayList();
        this.mLayoutListener = new UpdateOnGlobalLayout();
        getViewTreeObserver().addOnGlobalLayoutListener(this.mLayoutListener);
        setOnTouchListener(this);
        this.mMaskColour = Color.parseColor(ShowcaseConfig.DEFAULT_MASK_COLOUR);
        setVisibility(4);
        View contentView = LayoutInflater.from(getContext()).inflate(C0470R.layout.showcase_content, this, true);
        this.mContentBox = contentView.findViewById(C0470R.id.content_box);
        this.mContentTextView = (TextView) contentView.findViewById(C0470R.id.tv_content);
        this.mDismissButton = (TextView) contentView.findViewById(C0470R.id.tv_dismiss);
        this.mDismissButton.setOnClickListener(this);
        this.mLLTop = (LinearLayout) contentView.findViewById(C0470R.id.ll_guide_top);
        this.mLLDown = (LinearLayout) contentView.findViewById(C0470R.id.ll_guide_down);
        this.mIvTop = (ImageView) contentView.findViewById(C0470R.id.iv_guide_top);
        this.mIvDown = (ImageView) contentView.findViewById(C0470R.id.iv_guide_down);
    }

    public void setTopImage(int bg, int imageGravity) {
        this.mIvTop.setVisibility(0);
        this.mIvDown.setVisibility(8);
        this.mIvTop.setImageResource(bg);
        this.mLLTop.setGravity(imageGravity);
    }

    public void setDownImage(int bg, int imageGravity) {
        this.mIvTop.setVisibility(8);
        this.mIvDown.setVisibility(0);
        this.mIvDown.setImageResource(bg);
        this.mLLDown.setGravity(imageGravity);
    }

    public void setContentTextGravity(int ContentTextGravity) {
        this.mContentTextView.setGravity(ContentTextGravity);
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        WindowManager wm = (WindowManager) getContext().getSystemService("window");
        setMeasuredDimension(wm.getDefaultDisplay().getWidth(), wm.getDefaultDisplay().getHeight());
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.mShouldRender) {
            int width = getMeasuredWidth();
            int height = getMeasuredHeight();
            if (this.mBitmap == null || this.mCanvas == null || this.mOldHeight != height || this.mOldWidth != width) {
                if (this.mBitmap != null) {
                    this.mBitmap.recycle();
                }
                this.mBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
                this.mCanvas = new Canvas(this.mBitmap);
            }
            this.mOldWidth = width;
            this.mOldHeight = height;
            this.mCanvas.drawColor(0, Mode.CLEAR);
            this.mCanvas.drawColor(this.mMaskColour);
            if (this.mEraser == null) {
                this.mEraser = new Paint();
                this.mEraser.setColor(-1);
                this.mEraser.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
                this.mEraser.setFlags(1);
            }
            this.mShape.draw(this.mCanvas, this.mEraser, this.mXPosition, this.mYPosition, this.mShapePadding);
            canvas.drawBitmap(this.mBitmap, 0.0f, 0.0f, null);
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (!(this.mWasDismissed || !this.mSingleUse || this.mPrefsManager == null)) {
            this.mPrefsManager.resetShowcase();
        }
        notifyOnDismissed();
    }

    public boolean onTouch(View v, MotionEvent event) {
        if (this.mDismissOnTouch) {
            hide();
        }
        return true;
    }

    private void notifyOnDisplayed() {
        for (IShowcaseListener listener : this.mListeners) {
            listener.onShowcaseDisplayed(this);
        }
    }

    private void notifyOnDismissed() {
        if (this.mListeners != null) {
            for (IShowcaseListener listener : this.mListeners) {
                listener.onShowcaseDismissed(this);
            }
            this.mListeners.clear();
            this.mListeners = null;
        }
        if (this.mDetachedListener != null) {
            this.mDetachedListener.onShowcaseDetached(this, this.mWasDismissed);
        }
    }

    public void onClick(View v) {
        hide();
    }

    public void setTarget(Target target) {
        this.mTarget = target;
        updateDismissButton();
        if (this.mTarget != null) {
            if (VERSION.SDK_INT >= 21) {
                this.mBottomMargin = getSoftButtonsBarSizePort((Activity) getContext());
                LayoutParams contentLP = (LayoutParams) getLayoutParams();
                if (!(contentLP == null || contentLP.bottomMargin == this.mBottomMargin)) {
                    contentLP.bottomMargin = this.mBottomMargin;
                }
            }
            Point targetPoint = this.mTarget.getPoint();
            Rect targetBounds = this.mTarget.getBounds();
            setPosition(targetPoint);
            int height = getMeasuredHeight();
            int midPoint = height / 2;
            int yPos = targetPoint.y;
            int radius = Math.max(targetBounds.height(), targetBounds.width()) / 2;
            if (this.mShape != null) {
                this.mShape.updateTarget(this.mTarget);
                radius = this.mShape.getHeight() / 2;
            }
            if (yPos > midPoint) {
                this.mContentTopMargin = 0;
                this.mContentBottomMargin = ((height - yPos) + radius) + this.mShapePadding;
                this.mGravity = 80;
            } else {
                this.mContentTopMargin = (yPos + radius) + this.mShapePadding;
                this.mContentBottomMargin = 0;
                this.mGravity = 48;
            }
        }
        applyLayoutParams();
    }

    private void applyLayoutParams() {
        if (this.mContentBox != null && this.mContentBox.getLayoutParams() != null) {
            LayoutParams contentLP = (LayoutParams) this.mContentBox.getLayoutParams();
            boolean layoutParamsChanged = false;
            if (contentLP.bottomMargin != this.mContentBottomMargin) {
                contentLP.bottomMargin = this.mContentBottomMargin;
                layoutParamsChanged = true;
            }
            if (contentLP.topMargin != this.mContentTopMargin) {
                contentLP.topMargin = this.mContentTopMargin;
                layoutParamsChanged = true;
            }
            if (contentLP.gravity != this.mGravity) {
                contentLP.gravity = this.mGravity;
                layoutParamsChanged = true;
            }
            if (layoutParamsChanged) {
                this.mContentBox.setLayoutParams(contentLP);
            }
        }
    }

    void setPosition(Point point) {
        setPosition(point.x, point.y);
    }

    void setPosition(int x, int y) {
        this.mXPosition = x;
        this.mYPosition = y;
    }

    private void setContentText(CharSequence contentText) {
        if (this.mContentTextView != null) {
            this.mContentTextView.setText(contentText);
        }
    }

    private void setDismissText(CharSequence dismissText) {
        if (this.mDismissButton != null) {
            this.mDismissButton.setText(dismissText);
            updateDismissButton();
        }
    }

    private void setContentTextColor(int textColour) {
        if (this.mContentTextView != null) {
            this.mContentTextView.setTextColor(textColour);
        }
    }

    private void setDismissTextColor(int textColour) {
        if (this.mDismissButton != null) {
            this.mDismissButton.setTextColor(textColour);
        }
    }

    private void setShapePadding(int padding) {
        this.mShapePadding = padding;
    }

    private void setDismissOnTouch(boolean dismissOnTouch) {
        this.mDismissOnTouch = dismissOnTouch;
    }

    private void setShouldRender(boolean shouldRender) {
        this.mShouldRender = shouldRender;
    }

    private void setMaskColour(int maskColour) {
        this.mMaskColour = maskColour;
    }

    private void setDelay(long delayInMillis) {
        this.mDelayInMillis = delayInMillis;
    }

    private void setFadeDuration(long fadeDurationInMillis) {
        this.mFadeDurationInMillis = fadeDurationInMillis;
    }

    public void addShowcaseListener(IShowcaseListener showcaseListener) {
        this.mListeners.add(showcaseListener);
    }

    public void removeShowcaseListener(MaterialShowcaseSequence showcaseListener) {
        if (this.mListeners.contains(showcaseListener)) {
            this.mListeners.remove(showcaseListener);
        }
    }

    void setDetachedListener(IDetachedListener detachedListener) {
        this.mDetachedListener = detachedListener;
    }

    public void setShape(Shape mShape) {
        this.mShape = mShape;
    }

    public void setConfig(ShowcaseConfig config) {
        setDelay(config.getDelay());
        setFadeDuration(config.getFadeDuration());
        setContentTextColor(config.getContentTextColor());
        setDismissTextColor(config.getDismissTextColor());
        setMaskColour(config.getMaskColor());
        setShape(config.getShape());
        setShapePadding(config.getShapePadding());
    }

    private void updateDismissButton() {
        if (this.mDismissButton == null) {
            return;
        }
        if (TextUtils.isEmpty(this.mDismissButton.getText())) {
            this.mDismissButton.setVisibility(8);
        } else {
            this.mDismissButton.setVisibility(0);
        }
    }

    public boolean hasFired() {
        return this.mPrefsManager.hasFired();
    }

    private void singleUse(String showcaseID) {
        this.mSingleUse = true;
        this.mPrefsManager = new PrefsManager(getContext(), showcaseID);
    }

    public void removeFromWindow() {
        if (getParent() != null && (getParent() instanceof ViewGroup)) {
            ((ViewGroup) getParent()).removeView(this);
        }
        if (this.mBitmap != null) {
            this.mBitmap.recycle();
            this.mBitmap = null;
        }
        this.mEraser = null;
        this.mAnimationFactory = null;
        this.mCanvas = null;
        this.mHandler = null;
        getViewTreeObserver().removeGlobalOnLayoutListener(this.mLayoutListener);
        this.mLayoutListener = null;
        if (this.mPrefsManager != null) {
            this.mPrefsManager.close();
        }
        this.mPrefsManager = null;
    }

    public boolean show(Activity activity) {
        if (this.mSingleUse) {
            if (this.mPrefsManager.hasFired()) {
                return false;
            }
            this.mPrefsManager.setFired();
        }
        ((ViewGroup) activity.getWindow().getDecorView()).addView(this);
        setShouldRender(true);
        this.mHandler = new Handler();
        this.mHandler.postDelayed(new C02231(), this.mDelayInMillis);
        updateDismissButton();
        return true;
    }

    public void hide() {
        this.mWasDismissed = true;
        if (this.mShouldAnimate) {
            fadeOut();
        } else {
            removeFromWindow();
        }
    }

    public void fadeIn() {
        setVisibility(4);
        this.mAnimationFactory.fadeInView(this, this.mFadeDurationInMillis, new C08322());
    }

    public void fadeOut() {
        if (this.mAnimationFactory != null) {
            this.mAnimationFactory.fadeOutView(this, this.mFadeDurationInMillis, new C08333());
        }
    }

    public void resetSingleUse() {
        if (this.mSingleUse && this.mPrefsManager != null) {
            this.mPrefsManager.resetShowcase();
        }
    }

    public static void resetSingleUse(Context context, String showcaseID) {
        PrefsManager.resetShowcase(context, showcaseID);
    }

    public static void resetAll(Context context) {
        PrefsManager.resetAll(context);
    }

    public static int getSoftButtonsBarSizePort(Activity activity) {
        if (VERSION.SDK_INT < 17) {
            return 0;
        }
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int usableHeight = metrics.heightPixels;
        activity.getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        int realHeight = metrics.heightPixels;
        if (realHeight > usableHeight) {
            return realHeight - usableHeight;
        }
        return 0;
    }
}
