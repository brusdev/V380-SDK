package com.macrovideo.materialshowcaseview;

public interface IShowcaseListener {
    void onShowcaseDismissed(MaterialShowcaseView materialShowcaseView);

    void onShowcaseDisplayed(MaterialShowcaseView materialShowcaseView);
}
