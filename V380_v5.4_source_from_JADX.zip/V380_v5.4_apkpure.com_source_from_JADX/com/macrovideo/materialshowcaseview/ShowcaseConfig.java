package com.macrovideo.materialshowcaseview;

import android.graphics.Color;
import com.macrovideo.materialshowcaseview.shape.CircleShape;
import com.macrovideo.materialshowcaseview.shape.Shape;

public class ShowcaseConfig {
    public static final long DEFAULT_DELAY = 0;
    public static final long DEFAULT_FADE_TIME = 300;
    public static final String DEFAULT_MASK_COLOUR = "#99000000";
    public static final Shape DEFAULT_SHAPE = new CircleShape();
    public static final int DEFAULT_SHAPE_PADDING = 10;
    private int mContentTextColor = Color.parseColor("#ffffff");
    private long mDelay = 0;
    private int mDismissTextColor = Color.parseColor("#ffffff");
    private long mFadeDuration = 300;
    private int mMaskColour = Color.parseColor(DEFAULT_MASK_COLOUR);
    private Shape mShape = DEFAULT_SHAPE;
    private int mShapePadding = 10;

    public long getDelay() {
        return this.mDelay;
    }

    public void setDelay(long delay) {
        this.mDelay = delay;
    }

    public int getMaskColor() {
        return this.mMaskColour;
    }

    public void setMaskColor(int maskColor) {
        this.mMaskColour = maskColor;
    }

    public int getContentTextColor() {
        return this.mContentTextColor;
    }

    public void setContentTextColor(int mContentTextColor) {
        this.mContentTextColor = mContentTextColor;
    }

    public int getDismissTextColor() {
        return this.mDismissTextColor;
    }

    public void setDismissTextColor(int dismissTextColor) {
        this.mDismissTextColor = dismissTextColor;
    }

    public long getFadeDuration() {
        return this.mFadeDuration;
    }

    public void setFadeDuration(long fadeDuration) {
        this.mFadeDuration = fadeDuration;
    }

    public Shape getShape() {
        return this.mShape;
    }

    public void setShape(Shape shape) {
        this.mShape = shape;
    }

    public void setShapePadding(int padding) {
        this.mShapePadding = padding;
    }

    public int getShapePadding() {
        return this.mShapePadding;
    }
}
