package com.macrovideo.materialshowcaseview;

public interface IDetachedListener {
    void onShowcaseDetached(MaterialShowcaseView materialShowcaseView, boolean z);
}
