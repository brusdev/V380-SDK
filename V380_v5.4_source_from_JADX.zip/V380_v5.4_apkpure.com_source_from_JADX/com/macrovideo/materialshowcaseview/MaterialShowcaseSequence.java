package com.macrovideo.materialshowcaseview;

import android.app.Activity;
import android.view.View;
import com.macrovideo.materialshowcaseview.MaterialShowcaseView.Builder;
import java.util.LinkedList;
import java.util.Queue;

public class MaterialShowcaseSequence implements IDetachedListener {
    Activity mActivity;
    private ShowcaseConfig mConfig;
    private OnSequenceItemDismissedListener mOnItemDismissedListener;
    private OnSequenceItemShownListener mOnItemShownListener;
    PrefsManager mPrefsManager;
    private int mSequencePosition;
    Queue<MaterialShowcaseView> mShowcaseQueue;
    private boolean mSingleUse;

    public interface OnSequenceItemDismissedListener {
        void onDismiss(MaterialShowcaseView materialShowcaseView, int i);
    }

    public interface OnSequenceItemShownListener {
        void onShow(MaterialShowcaseView materialShowcaseView, int i);
    }

    public MaterialShowcaseSequence(Activity activity) {
        this.mSingleUse = false;
        this.mSequencePosition = 0;
        this.mOnItemShownListener = null;
        this.mOnItemDismissedListener = null;
        this.mActivity = activity;
        this.mShowcaseQueue = new LinkedList();
    }

    public MaterialShowcaseSequence(Activity activity, String sequenceID) {
        this(activity);
        singleUse(sequenceID);
    }

    public MaterialShowcaseSequence addSequenceItem(View targetView, String content, String dismissText) {
        MaterialShowcaseView sequenceItem = new Builder(this.mActivity).setTarget(targetView).setDismissText((CharSequence) dismissText).setContentText((CharSequence) content).build();
        if (this.mConfig != null) {
            sequenceItem.setConfig(this.mConfig);
        }
        this.mShowcaseQueue.add(sequenceItem);
        return this;
    }

    public MaterialShowcaseSequence addSequenceItem(MaterialShowcaseView sequenceItem) {
        this.mShowcaseQueue.add(sequenceItem);
        return this;
    }

    public MaterialShowcaseSequence singleUse(String sequenceID) {
        this.mSingleUse = true;
        this.mPrefsManager = new PrefsManager(this.mActivity, sequenceID);
        return this;
    }

    public void setOnItemShownListener(OnSequenceItemShownListener listener) {
        this.mOnItemShownListener = listener;
    }

    public void setOnItemDismissedListener(OnSequenceItemDismissedListener listener) {
        this.mOnItemDismissedListener = listener;
    }

    public boolean hasFired() {
        if (this.mPrefsManager.getSequenceStatus() == PrefsManager.SEQUENCE_FINISHED) {
            return true;
        }
        return false;
    }

    public void start() {
        if (this.mSingleUse) {
            if (!hasFired()) {
                this.mSequencePosition = this.mPrefsManager.getSequenceStatus();
                if (this.mSequencePosition > 0) {
                    for (int i = 0; i < this.mSequencePosition; i++) {
                        this.mShowcaseQueue.poll();
                    }
                }
            } else {
                return;
            }
        }
        if (this.mShowcaseQueue.size() > 0) {
            showNextItem();
        }
    }

    private void showNextItem() {
        if (this.mShowcaseQueue.size() > 0 && !this.mActivity.isFinishing()) {
            MaterialShowcaseView sequenceItem = (MaterialShowcaseView) this.mShowcaseQueue.remove();
            sequenceItem.setDetachedListener(this);
            sequenceItem.show(this.mActivity);
            if (this.mOnItemShownListener != null) {
                this.mOnItemShownListener.onShow(sequenceItem, this.mSequencePosition);
            }
        } else if (this.mSingleUse) {
            this.mPrefsManager.setFired();
        }
    }

    public void onShowcaseDetached(MaterialShowcaseView showcaseView, boolean wasDismissed) {
        showcaseView.setDetachedListener(null);
        if (wasDismissed) {
            if (this.mOnItemDismissedListener != null) {
                this.mOnItemDismissedListener.onDismiss(showcaseView, this.mSequencePosition);
            }
            if (this.mPrefsManager != null) {
                this.mSequencePosition++;
                this.mPrefsManager.setSequenceStatus(this.mSequencePosition);
            }
            showNextItem();
        }
    }

    public void setConfig(ShowcaseConfig config) {
        this.mConfig = config;
    }
}
