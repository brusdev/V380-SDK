package com.macrovideo.photo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.C0470R;
import com.macrovideo.v380.LocalDefines;
import com.tencent.android.tpush.SettingsContentProvider;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressLint({"SdCardPath"})
public class PhotoActivity extends Activity implements OnClickListener, OnItemClickListener, OnItemLongClickListener {
    private boolean bDelete = false;
    private boolean bDeleteChoose = true;
    private DeviceListViewAdapter deviceListItemAdapter;
    private GridView gridView;
    private Handler handler = new C02241();
    private ImageView ivDeleteChoose;
    private ImageView ivDeletePhoto;
    private ImageView ivDeviceImageBack;
    private ImageView ivSharePhoto;
    private List<Map<String, Object>> list = null;
    private LinearLayout llDelete;
    private LinearLayout llDeletePhoto;
    private LinearLayout llSelect;
    private LinearLayout llShare;
    private ProgressBar progressBarPhoto;
    private TextView tvDeviceImage;

    class C02241 extends Handler {
        C02241() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 == 100) {
                PhotoActivity.this.gridView.setEnabled(true);
                PhotoActivity.this.progressBarPhoto.setVisibility(8);
                PhotoActivity.this.updateDemoListView();
            } else if (msg.arg1 == 200) {
                new ImageViewThread().start();
                PhotoActivity.this.gridView.setEnabled(true);
                PhotoActivity.this.ivDeviceImageBack.setImageResource(C0470R.drawable.back_btn);
                PhotoActivity.this.tvDeviceImage.setText(PhotoActivity.this.getString(C0470R.string.PhotoManage));
                PhotoActivity.this.bDelete = false;
                PhotoActivity.this.llDeletePhoto.setVisibility(8);
                PhotoActivity.this.deviceListItemAdapter.notifyDataSetChanged();
            }
        }
    }

    private class DeviceListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private List<Map<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        class C02251 implements OnLongClickListener {
            C02251() {
            }

            public boolean onLongClick(View arg0) {
                if (PhotoActivity.this.bDelete) {
                    PhotoActivity.this.llDeletePhoto.setVisibility(8);
                    PhotoActivity.this.bDelete = false;
                } else {
                    PhotoActivity.this.bDelete = true;
                    PhotoActivity.this.llDeletePhoto.setVisibility(0);
                }
                PhotoActivity.this.updateDemoListView();
                return true;
            }
        }

        private class ItemViewHolder {
            ImageView btnFace;
            ImageView ivDelete;

            private ItemViewHolder() {
            }
        }

        class ListViewButtonListener implements OnClickListener {
            private boolean bResult = true;
            private ImageView imageView;
            private int position;

            ListViewButtonListener(int pos, ImageView v) {
                this.position = pos;
                this.imageView = v;
            }

            public void onClick(View v) {
                if (v.getId() == DeviceListViewAdapter.this.holder.ivDelete.getId() && this.position >= 0 && this.position < PhotoActivity.this.list.size()) {
                    Map<String, Object> map = (Map) PhotoActivity.this.list.get(this.position);
                    this.bResult = ((Boolean) map.get(SettingsContentProvider.BOOLEAN_TYPE)).booleanValue();
                    if (map != null && map.size() > 0) {
                        if (this.bResult) {
                            this.bResult = false;
                            map.put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(false));
                            this.imageView.setImageResource(C0470R.drawable.delete_choose_1);
                            return;
                        }
                        this.bResult = true;
                        map.put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(true));
                        this.imageView.setImageResource(C0470R.drawable.delete_choose_2);
                    }
                }
            }
        }

        public DeviceListViewAdapter(Context c, List<Map<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.photo_gridview_item, null);
                this.holder = new ItemViewHolder();
                this.holder.btnFace = (ImageView) convertView.findViewById(this.valueViewID[0]);
                this.holder.ivDelete = (ImageView) convertView.findViewById(this.valueViewID[1]);
                this.holder.ivDelete.setTag(Integer.valueOf(position));
                convertView.setTag(this.holder);
            }
            Map<String, Object> map = (Map) this.mAppList.get(position);
            if (map != null && map.size() > 0) {
                Bitmap bitmap = (Bitmap) map.get("image");
                if (bitmap != null) {
                    this.holder.btnFace.setImageDrawable(new BitmapDrawable(bitmap));
                } else {
                    this.holder.btnFace.setImageDrawable(null);
                }
                if (PhotoActivity.this.bDelete) {
                    this.holder.ivDelete.setVisibility(0);
                } else {
                    this.holder.ivDelete.setVisibility(8);
                }
                if (((Boolean) map.get(SettingsContentProvider.BOOLEAN_TYPE)).booleanValue()) {
                    this.holder.ivDelete.setImageResource(C0470R.drawable.delete_choose_2);
                } else {
                    this.holder.ivDelete.setImageResource(C0470R.drawable.delete_choose_1);
                }
                this.holder.ivDelete.setOnClickListener(new ListViewButtonListener(position, this.holder.ivDelete));
                this.holder.ivDelete.setOnLongClickListener(new C02251());
            }
            return convertView;
        }
    }

    private class ImageDeleteThread extends Thread {
        private ImageDeleteThread() {
        }

        public void run() {
            super.run();
            if (PhotoActivity.this.list != null && PhotoActivity.this.list.size() > 0) {
                for (int i = 0; i < PhotoActivity.this.list.size(); i++) {
                    Map<String, Object> map = (Map) PhotoActivity.this.list.get(i);
                    if (((Boolean) map.get(SettingsContentProvider.BOOLEAN_TYPE)).booleanValue()) {
                        File file = new File(map.get("imagePath"));
                        if (file.exists()) {
                            file.delete();
                        }
                    }
                }
                Message msg = PhotoActivity.this.handler.obtainMessage();
                msg.arg1 = 200;
                PhotoActivity.this.handler.sendMessage(msg);
            }
        }
    }

    private class ImageViewThread extends Thread {
        private ImageViewThread() {
        }

        public void run() {
            super.run();
            imageViewList();
            Message msg = PhotoActivity.this.handler.obtainMessage();
            msg.arg1 = 100;
            PhotoActivity.this.handler.sendMessage(msg);
        }

        private void imageViewList() {
            PhotoActivity.this.list = new ArrayList();
            Bitmap bitmap = null;
            List<String> strImageList = ImageViewView.getImagePathFromSD(new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().toString())).append("/").append(LocalDefines.SDCardPath).toString());
            if (strImageList != null && strImageList.size() > 0) {
                for (int i = 0; i < strImageList.size(); i++) {
                    if (bitmap != null && bitmap.isRecycled()) {
                        bitmap.recycle();
                        bitmap = null;
                        System.gc();
                    }
                    String strImagePath = (String) strImageList.get(i);
                    if (strImagePath != null && strImagePath.length() > 0) {
                        try {
                            bitmap = ImageViewView.getImage(strImagePath);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Map<String, Object> map = new HashMap();
                        map.put("image", bitmap);
                        map.put("imagePath", strImagePath);
                        map.put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(false));
                        PhotoActivity.this.list.add(map);
                    }
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            }
            StaticUtil._list = null;
            StaticUtil._list = PhotoActivity.this.list;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.photo_activity);
        initView();
        new ImageViewThread().start();
    }

    private void initView() {
        this.gridView = (GridView) findViewById(C0470R.id.gridView);
        this.ivDeletePhoto = (ImageView) findViewById(C0470R.id.ivDeletePhoto);
        this.ivDeleteChoose = (ImageView) findViewById(C0470R.id.ivDeleteChoose);
        this.ivDeviceImageBack = (ImageView) findViewById(C0470R.id.ivDeviceImageBack);
        this.ivDeviceImageBack.setOnClickListener(this);
        this.llDeletePhoto = (LinearLayout) findViewById(C0470R.id.llDeletePhoto);
        this.llDeletePhoto.setVisibility(8);
        this.tvDeviceImage = (TextView) findViewById(C0470R.id.tvDeviceImage);
        this.progressBarPhoto = (ProgressBar) findViewById(C0470R.id.progressBarPhoto);
        this.progressBarPhoto.setVisibility(0);
        this.ivSharePhoto = (ImageView) findViewById(C0470R.id.ivSharePhoto);
        this.llShare = (LinearLayout) findViewById(C0470R.id.ll_share);
        this.llShare.setOnClickListener(this);
        this.llDelete = (LinearLayout) findViewById(C0470R.id.ll_delete);
        this.llDelete.setOnClickListener(this);
        this.llSelect = (LinearLayout) findViewById(C0470R.id.ll_select);
        this.llSelect.setOnClickListener(this);
    }

    public void updateDemoListView() {
        this.deviceListItemAdapter = new DeviceListViewAdapter(this, this.list, C0470R.layout.photo_gridview_item, new String[]{"ItemBtnFace", "ItemTitleName"}, new int[]{C0470R.id.imageView, C0470R.id.ivDelete});
        if (this.gridView != null) {
            this.gridView.setCacheColorHint(0);
            this.gridView.setAdapter(this.deviceListItemAdapter);
            this.gridView.setOnItemClickListener(this);
            this.gridView.setOnItemLongClickListener(this);
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
        if (this.bDelete) {
            setIvDeleteCheckState(arg1, arg2);
            return;
        }
        StaticUtil.POSITION = arg2;
        startActivity(new Intent(this, ViewPagerActivity.class));
    }

    public void onClick(View arg0) {
        if (arg0.getId() == C0470R.id.ll_delete) {
            this.progressBarPhoto.setVisibility(0);
            this.gridView.setEnabled(false);
            new ImageDeleteThread().start();
        } else if (arg0.getId() == C0470R.id.ivDeviceImageBack) {
            if (this.llDeletePhoto.getVisibility() == 8) {
                finish();
                return;
            }
            this.bDelete = false;
            this.llDeletePhoto.setVisibility(8);
            this.ivDeviceImageBack.setImageResource(C0470R.drawable.back_btn);
            this.tvDeviceImage.setText(getString(C0470R.string.PhotoManage));
            if (this.list != null && this.list.size() > 0) {
                for (i = 0; i < this.list.size(); i++) {
                    ((Map) this.list.get(i)).put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(false));
                }
            }
            this.deviceListItemAdapter.notifyDataSetChanged();
        } else if (arg0.getId() == C0470R.id.ll_select) {
            if (this.list != null && this.list.size() > 0) {
                for (i = 0; i < this.list.size(); i++) {
                    map = (Map) this.list.get(i);
                    if (this.bDeleteChoose) {
                        map.put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(true));
                    } else {
                        map.put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(false));
                    }
                }
            }
            if (this.bDeleteChoose) {
                this.bDeleteChoose = false;
            } else {
                this.bDeleteChoose = true;
            }
            this.deviceListItemAdapter.notifyDataSetChanged();
        } else if (arg0.getId() == C0470R.id.ll_share) {
            int listNum = this.list.size();
            if (this.list == null || listNum <= 0) {
                Toast.makeText(this, getResources().getString(C0470R.string.str_photo_activity), 0).show();
                return;
            }
            List<String> listPath = new ArrayList();
            for (i = 0; i < listNum; i++) {
                map = (Map) this.list.get(i);
                if (((Boolean) map.get(SettingsContentProvider.BOOLEAN_TYPE)).booleanValue()) {
                    listPath.add(map.get("imagePath"));
                }
            }
            Functions.SharePhoto(listPath, this);
        }
    }

    public boolean onItemLongClick(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
        if (this.bDelete) {
            this.llDeletePhoto.setVisibility(8);
            this.bDelete = false;
            this.tvDeviceImage.setText(getString(C0470R.string.PhotoManage));
            this.ivDeviceImageBack.setImageResource(C0470R.drawable.back_btn);
            for (int i = 0; i < this.list.size(); i++) {
                ((Map) this.list.get(i)).put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(false));
            }
        } else {
            this.bDelete = true;
            this.llDeletePhoto.setVisibility(0);
            this.tvDeviceImage.setText(getString(C0470R.string.PhotoManage));
            this.ivDeviceImageBack.setImageResource(C0470R.drawable.delete_cancel_btn);
            setIvDeleteCheckState(arg1, arg2);
        }
        this.deviceListItemAdapter.notifyDataSetChanged();
        return true;
    }

    private void setIvDeleteCheckState(View view, int position) {
        ImageView imageView = (ImageView) view.findViewWithTag(Integer.valueOf(position));
        if (imageView != null && position >= 0 && position < this.list.size()) {
            Map<String, Object> map = (Map) this.list.get(position);
            boolean bResult = ((Boolean) map.get(SettingsContentProvider.BOOLEAN_TYPE)).booleanValue();
            if (map != null && map.size() > 0) {
                if (bResult) {
                    map.put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(false));
                    imageView.setImageResource(C0470R.drawable.delete_choose_1);
                    return;
                }
                map.put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(true));
                imageView.setImageResource(C0470R.drawable.delete_choose_2);
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.bDelete) {
                this.llDeletePhoto.setVisibility(8);
                this.bDelete = false;
                this.tvDeviceImage.setText(getString(C0470R.string.PhotoManage));
                this.ivDeviceImageBack.setImageResource(C0470R.drawable.back_btn);
                if (this.list != null && this.list.size() > 0) {
                    for (int i = 0; i < this.list.size(); i++) {
                        ((Map) this.list.get(i)).put(SettingsContentProvider.BOOLEAN_TYPE, Boolean.valueOf(false));
                    }
                }
            } else {
                finish();
            }
        }
        return true;
    }
}
