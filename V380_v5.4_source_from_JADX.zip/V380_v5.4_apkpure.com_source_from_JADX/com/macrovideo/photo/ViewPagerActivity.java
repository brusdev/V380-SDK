package com.macrovideo.photo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.C0470R;
import com.macrovideo.v380.LocalDefines;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ViewPagerActivity extends Activity implements OnClickListener {
    private static final int HANDLE_DELETE_FAIL = 2;
    private static final int HANDLE_DELETE_OK = 1;
    private static final String KEY_PHOTO_POSITION = "position";
    private SamplePagerAdapter mAdapter;
    private LinearLayout mBtnDelete;
    private LinearLayout mBtnShare;
    private Handler mHandler = new C02281();
    private ImageView mImageViewBack;
    private boolean mIsDeleted = false;
    private int mPosition;
    private ProgressBar mProgressBar;
    private TextView mTvPhotoInfo;
    private ViewPager mViewPager;
    private List<String> shareList = new ArrayList();

    class C02281 extends Handler {
        C02281() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    ViewPagerActivity.this.mProgressBar.setVisibility(8);
                    StaticUtil._photoPaths.remove(ViewPagerActivity.this.mViewPager.getCurrentItem());
                    if (StaticUtil._photoPaths.size() == 0) {
                        ViewPagerActivity.this.mTvPhotoInfo.setText(new StringBuilder(String.valueOf(ViewPagerActivity.this.mPosition)).append("/").append(StaticUtil._photoPaths.size()).toString());
                    } else {
                        ViewPagerActivity.this.mTvPhotoInfo.setText(new StringBuilder(String.valueOf(ViewPagerActivity.this.mPosition + 1)).append("/").append(StaticUtil._photoPaths.size()).toString());
                    }
                    ViewPagerActivity.this.mAdapter.notifyDataSetChanged();
                    return;
                case 2:
                    ViewPagerActivity.this.mProgressBar.setVisibility(8);
                    Toast.makeText(ViewPagerActivity.this, ViewPagerActivity.this.getString(C0470R.string.deleteFail), 0).show();
                    return;
                default:
                    return;
            }
        }
    }

    class DeletePhotoThread extends Thread {
        DeletePhotoThread() {
        }

        public void run() {
            super.run();
            boolean isOk = false;
            File file = new File((String) StaticUtil._photoPaths.get(ViewPagerActivity.this.mViewPager.getCurrentItem()));
            if (file.exists()) {
                isOk = file.delete();
            }
            if (isOk) {
                ViewPagerActivity.this.mIsDeleted = true;
                Message msg = ViewPagerActivity.this.mHandler.obtainMessage();
                msg.what = 1;
                ViewPagerActivity.this.mHandler.sendMessage(msg);
                return;
            }
            msg = ViewPagerActivity.this.mHandler.obtainMessage();
            msg.what = 2;
            ViewPagerActivity.this.mHandler.sendMessage(msg);
        }
    }

    class C08352 implements OnPageChangeListener {
        C08352() {
        }

        public void onPageSelected(int position) {
            ViewPagerActivity.this.mPosition = position;
            ViewPagerActivity.this.mTvPhotoInfo.setText((position + 1) + "/" + StaticUtil._photoPaths.size());
        }

        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        public void onPageScrollStateChanged(int arg0) {
        }
    }

    static class SamplePagerAdapter extends PagerAdapter {
        SamplePagerAdapter() {
        }

        public int getCount() {
            return StaticUtil._photoPaths.size();
        }

        public int getItemPosition(Object object) {
            return -2;
        }

        public View instantiateItem(ViewGroup container, int position) {
            PhotoView photoView = new PhotoView(container.getContext());
            Bitmap bitmap = ViewPagerActivity.generateBitmap((String) StaticUtil._photoPaths.get(position));
            if (bitmap != null) {
                photoView.setImageBitmap(bitmap);
            }
            container.addView(photoView, -1, -1);
            return photoView;
        }

        public void destroyItem(ViewGroup container, int position, Object object) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) ((PhotoView) object).getDrawable();
            if (bitmapDrawable != null) {
                Bitmap bitmap = bitmapDrawable.getBitmap();
                if (!(bitmap == null || bitmap.isRecycled())) {
                    bitmap.recycle();
                    System.gc();
                }
            }
            container.removeView((View) object);
        }

        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_viewpager);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            this.mPosition = bundle.getInt(KEY_PHOTO_POSITION);
        }
        initViews();
    }

    private void initViews() {
        this.mViewPager = (ViewPager) findViewById(C0470R.id.hackyViewPager);
        this.mTvPhotoInfo = (TextView) findViewById(C0470R.id.tv_info);
        this.mTvPhotoInfo.setText(new StringBuilder(String.valueOf(this.mPosition + 1)).append("/").append(StaticUtil._photoPaths.size()).toString());
        this.mViewPager.addOnPageChangeListener(new C08352());
        this.mAdapter = new SamplePagerAdapter();
        this.mViewPager.setAdapter(this.mAdapter);
        this.mViewPager.setCurrentItem(this.mPosition);
        this.mImageViewBack = (ImageView) findViewById(C0470R.id.ivBack);
        this.mImageViewBack.setOnClickListener(this);
        this.mBtnShare = (LinearLayout) findViewById(C0470R.id.photo_share);
        this.mBtnShare.setOnClickListener(this);
        this.mBtnDelete = (LinearLayout) findViewById(C0470R.id.photo_delete);
        this.mBtnDelete.setOnClickListener(this);
        this.mProgressBar = (ProgressBar) findViewById(C0470R.id.photo_progressbar);
    }

    public static Bitmap generateBitmap(String filePath) {
        Options bfOptions = new Options();
        bfOptions.inDither = false;
        bfOptions.inPurgeable = true;
        bfOptions.inTempStorage = new byte[Defines.PARAM_NONE];
        bfOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, bfOptions);
        if (bfOptions.outWidth == 640 && bfOptions.outHeight == LocalDefines._YUVHeight) {
            bfOptions.inSampleSize = 1;
        } else {
            bfOptions.inSampleSize = 2;
        }
        FileInputStream fs = null;
        try {
            fs = new FileInputStream(new File(filePath));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Bitmap bmp = null;
        if (fs != null) {
            try {
                bfOptions.inJustDecodeBounds = false;
                bmp = BitmapFactory.decodeFileDescriptor(fs.getFD(), null, bfOptions);
                if (fs != null) {
                    try {
                        fs.close();
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
            } catch (IOException e22) {
                e22.printStackTrace();
                if (fs != null) {
                    try {
                        fs.close();
                    } catch (IOException e222) {
                        e222.printStackTrace();
                    }
                }
            } catch (Throwable th) {
                if (fs != null) {
                    try {
                        fs.close();
                    } catch (IOException e2222) {
                        e2222.printStackTrace();
                    }
                }
            }
        }
        return bmp;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.ivBack:
                setResult(-1, new Intent().putExtra("IsDeleted", this.mIsDeleted));
                finish();
                return;
            case C0470R.id.photo_share:
                if (StaticUtil._photoPaths != null && StaticUtil._photoPaths.size() > 0) {
                    if (this.shareList == null) {
                        this.shareList = new ArrayList();
                    } else {
                        this.shareList.clear();
                    }
                    this.shareList.add((String) StaticUtil._photoPaths.get(this.mViewPager.getCurrentItem()));
                    Functions.SharePhoto(this.shareList, this);
                    return;
                }
                return;
            case C0470R.id.photo_delete:
                if (StaticUtil._photoPaths != null && StaticUtil._photoPaths.size() > 0) {
                    this.mProgressBar.setVisibility(0);
                    new DeletePhotoThread().start();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            setResult(-1, new Intent().putExtra("IsDeleted", this.mIsDeleted));
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }

    protected void onDestroy() {
        super.onDestroy();
    }
}
