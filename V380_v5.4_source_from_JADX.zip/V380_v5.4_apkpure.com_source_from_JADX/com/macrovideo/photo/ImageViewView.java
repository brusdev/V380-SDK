package com.macrovideo.photo;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@SuppressLint({"DefaultLocale"})
public class ImageViewView {
    static Bitmap bitmap = null;

    public static List<String> getImagePathFromSD(String imagePath) {
        List<String> picList = new ArrayList();
        File mfile = new File(imagePath);
        if (!mfile.exists()) {
            mfile.mkdir();
        }
        File[] files = mfile.listFiles();
        if (files != null && files.length > 0) {
            for (File file : files) {
                if (checkIsImageFile(file.getPath())) {
                    picList.add(file.getPath());
                }
            }
        }
        return picList;
    }

    private static boolean checkIsImageFile(String fName) {
        String FileEnd = fName.substring(fName.lastIndexOf(".") + 1, fName.length()).toLowerCase();
        if (FileEnd.equals("jpg") || FileEnd.equals("gif") || FileEnd.equals("png") || FileEnd.equals("jpeg") || FileEnd.equals("bmp")) {
            return true;
        }
        return false;
    }

    public static Bitmap decodeUrlToBitmap(String path) {
        bitmap = null;
        System.gc();
        if (!new File(path).exists()) {
            return null;
        }
        bitmap = BitmapFactory.decodeFile(path);
        return bitmap;
    }

    public static Bitmap getImage(String url) throws Exception {
        byte[] imagebytes = getBytes(new FileInputStream(new File(url)));
        Options opt = new Options();
        opt.inPreferredConfig = Config.RGB_565;
        opt.inInputShareable = true;
        opt.inPurgeable = true;
        return BitmapFactory.decodeByteArray(imagebytes, 0, imagebytes.length, opt);
    }

    public static byte[] getBytes(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        while (true) {
            int len = in.read(buffer);
            if (len == -1) {
                in.close();
                bos.flush();
                return bos.toByteArray();
            }
            bos.write(buffer, 0, len);
        }
    }

    public static Bitmap decodeStringtoBitmap(String string) {
        try {
            byte[] bitmapArray = Base64.decode(string, 0);
            return BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            return null;
        }
    }
}
