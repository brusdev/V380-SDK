package com.macrovideo.photo;

import java.util.List;
import java.util.Map;

public class StaticUtil {
    public static int POSITION = 0;
    public static List<Map<String, Object>> _list = null;
    public static List<String> _photoPaths = null;
}
