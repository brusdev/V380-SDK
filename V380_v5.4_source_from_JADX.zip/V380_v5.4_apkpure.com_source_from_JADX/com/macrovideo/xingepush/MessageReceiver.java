package com.macrovideo.xingepush;

import android.annotation.SuppressLint;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat.Builder;
import android.util.Base64;
import android.util.Log;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.C0470R;
import com.macrovideo.v380.DatabaseManager;
import com.macrovideo.v380.HomePageActivity;
import com.macrovideo.v380.LocalDefines;
import com.tencent.android.tpush.XGPushBaseReceiver;
import com.tencent.android.tpush.XGPushClickedResult;
import com.tencent.android.tpush.XGPushRegisterResult;
import com.tencent.android.tpush.XGPushShowedResult;
import com.tencent.android.tpush.XGPushTextMessage;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.common.MessageKey;
import java.text.SimpleDateFormat;
import org.json.JSONException;
import org.json.JSONObject;

@SuppressLint({"SimpleDateFormat"})
public class MessageReceiver extends XGPushBaseReceiver {
    public static final String LogTag = "TPushReceiver";
    static final long[] pattern = new long[]{200, 3000, 500, 1000};
    public static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private void show(Context context, String text) {
    }

    public void onNotifactionShowedResult(Context context, XGPushShowedResult notifiShowedRlt) {
        if (context != null && notifiShowedRlt != null) {
            Log.w(LogTag, "onNotifactionShowedResult: " + notifiShowedRlt.getContent());
        }
    }

    public void onUnregisterResult(Context context, int errorCode) {
        if (context != null) {
        }
    }

    public void onSetTagResult(Context context, int errorCode, String tagName) {
        if (context != null) {
        }
    }

    public void onDeleteTagResult(Context context, int errorCode, String tagName) {
        if (context != null) {
            String text = Constants.MAIN_VERSION_TAG;
            if (errorCode == 0) {
                text = "\"" + tagName + "\"删除成功";
            } else {
                text = "\"" + tagName + "\"删除失败,错误码：" + errorCode;
            }
            Log.d(LogTag, text);
            show(context, text);
        }
    }

    public void onNotifactionClickedResult(Context context, XGPushClickedResult message) {
        if (context != null && message != null) {
        }
    }

    public void onRegisterResult(Context context, int errorCode, XGPushRegisterResult message) {
        if (context != null && message != null && errorCode == 0) {
            Log.w(LogTag, "onRegisterResult: 注册成功");
        }
    }

    public void onTextMessage(Context context, XGPushTextMessage message) {
        String customContent = message.getCustomContent();
        String strTitle = message.getTitle();
        if (customContent != null && customContent.length() != 0) {
            try {
                String str = new String(Base64.decode(new JSONObject(customContent).getString(MessageKey.MSG_CONTENT), 1));
                if (str != null && str.length() > 0) {
                    JSONObject json = new JSONObject(str);
                    String strT = json.getString("T");
                    int nT = 0;
                    if (strT != null && strT.length() > 0) {
                        nT = Integer.parseInt(strT);
                    }
                    String strB = json.getString("B");
                    if (strB != null && strB.length() > 0) {
                        JSONObject jSONObject = new JSONObject(strB);
                        if (nT == 1) {
                            int nAlarmType = jSONObject.getInt("aty");
                            long lAlarmTime = jSONObject.getLong("att");
                            int nDevID = jSONObject.getInt("did");
                            String strAc = jSONObject.getString("ac");
                            int nDeviceIndex = -1;
                            String strDateTime = null;
                            if (lAlarmTime > 0) {
                                strDateTime = sdf.format(Long.valueOf(lAlarmTime));
                            }
                            DatabaseManager.UpdateServerInfoMsgFreshTime(nDevID, lAlarmTime);
                            if (LocalDefines.IsSoftwareRunning) {
                                if (LocalDefines._severInfoWithoutImageListData != null) {
                                    if (nDevID > 0) {
                                        for (int i = LocalDefines._severInfoWithoutImageListData.size() - 1; i >= 0; i--) {
                                            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoWithoutImageListData.get(i);
                                            if (info != null && info.getnDevID() == nDevID) {
                                                nDeviceIndex = i;
                                                break;
                                            }
                                        }
                                    }
                                    if (nDeviceIndex < 0 && nDeviceIndex >= LocalDefines._severInfoListData.size()) {
                                        return;
                                    }
                                }
                                if (!LocalDefines.isRecvMsg) {
                                    return;
                                }
                                if (LocalDefines.IsSoftwareOpen) {
                                    LocalDefines.playNoticeSound(nAlarmType);
                                    Bundle data = new Bundle();
                                    data.putInt(LocalDefines.PUSH_ID, nDevID);
                                    data.putInt(LocalDefines.PUSH_TYPE, nAlarmType);
                                    data.putLong(LocalDefines.PUSH_TIME, lAlarmTime);
                                    data.putString(LocalDefines.PUSH_MSG, strAc);
                                    data.putString(LocalDefines.PUSH_TITLE, strTitle);
                                    Intent intent = new Intent();
                                    intent.setAction(LocalDefines.PUSH_RECEIVER);
                                    intent.putExtras(data);
                                    context.sendBroadcast(intent);
                                    return;
                                }
                                promtsAlarm(context, nDevID, strTitle, strDateTime, nAlarmType);
                                return;
                            }
                            promtsAlarm(context, nDevID, strTitle, strDateTime, nAlarmType);
                        }
                    }
                }
            } catch (JSONException e) {
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    private void promtsAlarm(Context context, int nDevID, String strTitle, String strDateTime, int nAlarmType) {
        NotificationManager mNotificationManager = (NotificationManager) context.getSystemService("notification");
        Builder builder = new Builder(context.getApplicationContext());
        if (VERSION.SDK_INT >= 23) {
            builder.setSmallIcon(C0470R.drawable.my_device_3);
            builder.setLargeIcon(Functions.readBitMap(context, C0470R.drawable.icon));
        } else {
            builder.setSmallIcon(C0470R.drawable.icon_1);
        }
        builder.setDefaults(0);
        builder.setAutoCancel(true);
        builder.setContentTitle(strTitle);
        builder.setContentText(context.getString(C0470R.string.deviceAlarmTime) + strDateTime);
        builder.setTicker(context.getString(C0470R.string.baiduDevice) + nDevID + context.getString(C0470R.string.deviceHaveAlarmMsg));
        Intent intent = new Intent(context.getApplicationContext(), HomePageActivity.class);
        intent.setFlags(270532608);
        builder.setContentIntent(PendingIntent.getActivity(context.getApplicationContext(), 0, intent, 0));
        boolean isSound = false;
        boolean isVibrate = false;
        SharedPreferences alarmSettingSharedPreferences = context.getSharedPreferences(LocalDefines.ALARM_SETTINGS, 32768);
        if (alarmSettingSharedPreferences != null) {
            isVibrate = alarmSettingSharedPreferences.getBoolean("alarm_shake", false);
            isSound = alarmSettingSharedPreferences.getBoolean("alarm_sound", true);
        }
        Log.w(LogTag, new StringBuilder(String.valueOf(nAlarmType)).append("Defines.isSound = ").append(LocalDefines.isSound).append("_ ").append(isSound).append(", Defines.isVibrate = ").append(LocalDefines.isVibrate).append("_ ").append(isVibrate).toString());
        if (isSound) {
            String strURI = "android.resource://" + context.getPackageName() + "/" + C0470R.raw.alarm_notice;
            if (nAlarmType == 100 || nAlarmType == 300 || nAlarmType == 400 || nAlarmType == 500 || nAlarmType == 600) {
                strURI = "android.resource://" + context.getPackageName() + "/" + C0470R.raw.alarm_warm;
            }
            builder.setSound(Uri.parse(strURI));
        }
        if (isVibrate) {
            builder.setVibrate(pattern);
        }
        mNotificationManager.cancel(1000);
        mNotificationManager.notify(1000, builder.build());
    }
}
