package com.macrovideo.xingepush;

import android.os.Handler;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.LocalDefines;
import com.tencent.android.tpush.common.Constants;
import org.json.JSONException;
import org.json.JSONObject;

public class RegistClientWithDeviceToServer extends Thread {
    private DeviceInfo info = null;
    Handler lHandler = null;

    public RegistClientWithDeviceToServer(DeviceInfo info, Handler lHandler) {
        this.info = info;
        this.lHandler = lHandler;
    }

    public void run() {
        if (this.info != null && LocalDefines.strClientID != null && LocalDefines.strClientID.length() == 40) {
            JSONObject jsObject = new JSONObject();
            String strUsername = this.info.getStrUsername();
            String strPassword = this.info.getStrPassword();
            try {
                jsObject.put("client_id", LocalDefines.strClientID);
                jsObject.put("dev_id", this.info.getnDevID());
                if (this.info.isRecvMsg()) {
                    jsObject.put("recv_msg_pri", 1);
                } else {
                    jsObject.put("recv_msg_pri", 0);
                }
                if (strUsername == null || strUsername.length() <= 0) {
                    jsObject.put("username", Constants.MAIN_VERSION_TAG);
                } else {
                    jsObject.put("username", strUsername);
                }
                String requestResult;
                if (strPassword == null || strPassword.length() <= 0) {
                    jsObject.put("password", Constants.MAIN_VERSION_TAG);
                    requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strAlarmServerSend, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_REGIST_CLIENT).append(jsObject.toString()).toString());
                    if (requestResult != null || requestResult.length() <= 0) {
                        System.out.println("�豸����ʧ��");
                    }
                    try {
                        JSONObject objStr = new JSONObject(requestResult);
                        if (objStr != null && objStr.getInt("result") > 0) {
                            System.out.println("�豸����OK");
                            return;
                        }
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                }
                jsObject.put("password", strPassword);
                requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strAlarmServerSend, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_REGIST_CLIENT).append(jsObject.toString()).toString());
                if (requestResult != null) {
                }
                System.out.println("�豸����ʧ��");
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
        }
    }
}
