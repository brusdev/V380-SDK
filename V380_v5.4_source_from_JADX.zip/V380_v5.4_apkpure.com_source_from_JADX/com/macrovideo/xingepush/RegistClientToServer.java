package com.macrovideo.xingepush;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.LocalDefines;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.common.MessageKey;
import org.json.JSONException;
import org.json.JSONObject;

public class RegistClientToServer extends Thread {
    public static String mStrRegistServer = null;
    private Context context;
    private Editor editor = null;
    private int nClientRegistThreadID = 0;
    private SharedPreferences sharedPreferences;

    public RegistClientToServer(Context context, int nThreadID) {
        this.context = context;
        this.nClientRegistThreadID = nThreadID;
    }

    public void run() {
        if (LocalDefines.strClientID == null || LocalDefines.strClientID.length() != 40) {
            LocalDefines.strClientID = XGPushConfig.getToken(this.context);
            if (LocalDefines.strClientID == null || LocalDefines.strClientID.length() != 40) {
                return;
            }
        }
        this.sharedPreferences = this.context.getSharedPreferences(LocalDefines.DEVICE_MESSAGE_RECEIVE, 32768);
        this.editor = this.sharedPreferences.edit();
        JSONObject jsObject = new JSONObject();
        try {
            jsObject.put("client_id", LocalDefines.strClientID);
            jsObject.put("phone_type", 1002);
            jsObject.put("phone_num", LocalDefines.strPhoneNumber);
            jsObject.put("apikey", LocalDefines.strApiKey);
            jsObject.put("secretkey", LocalDefines.strSecretKey);
            jsObject.put("channel_id", LocalDefines.lChannelID);
            jsObject.put("user_id", LocalDefines.strUserID);
            if (LocalDefines.isVibrate) {
                jsObject.put(MessageKey.MSG_VIBRATE, 1);
            } else {
                jsObject.put(MessageKey.MSG_VIBRATE, 0);
            }
            if (LocalDefines.isSound) {
                jsObject.put("sound", 1);
            } else {
                jsObject.put("sound", 0);
            }
            jsObject.put("sound_file", LocalDefines.strSoundFile);
            if (LocalDefines.isRecvMsg) {
                jsObject.put("recv_msg_pri", 1);
            } else {
                jsObject.put("recv_msg_pri", 0);
            }
            String requestResult;
            int i;
            String server;
            if (LocalDefines.strSysLan == null || LocalDefines.strSysLan.length() <= 0) {
                jsObject.put("sys_lan", "cn");
                requestResult = null;
                if (mStrRegistServer != null) {
                    requestResult = Functions.GetJsonStringFromServerByHTTP(mStrRegistServer, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_REGIST_CLIENT).append(jsObject.toString()).toString());
                }
                if (requestResult == null || requestResult.length() <= 0) {
                    for (i = 0; i < 3; i++) {
                        server = LocalDefines.getAlarmServerByIndex(i);
                        requestResult = Functions.GetJsonStringFromServerByHTTP(server, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_REGIST_CLIENT).append(jsObject.toString()).toString());
                        if (requestResult == null && requestResult.length() > 0) {
                            mStrRegistServer = server;
                            break;
                        }
                    }
                }
                if (requestResult != null || requestResult.length() <= 0) {
                    Log.w("XG1", "requestResult == null");
                    this.editor.putBoolean(LocalDefines.ALARM_DEVICE_LOGIN, false);
                    this.editor.commit();
                }
                try {
                    JSONObject objStr = new JSONObject(requestResult);
                    if (objStr == null) {
                        this.editor.putBoolean(LocalDefines.ALARM_DEVICE_LOGIN, false);
                        this.editor.commit();
                        return;
                    } else if (objStr.getInt("result") > 0) {
                        LocalDefines.isClientRegisted = true;
                        this.editor.putBoolean(LocalDefines.ALARM_DEVICE_LOGIN, true);
                        this.editor.commit();
                        return;
                    } else {
                        return;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
            }
            jsObject.put("sys_lan", LocalDefines.strSysLan);
            requestResult = null;
            if (mStrRegistServer != null) {
                requestResult = Functions.GetJsonStringFromServerByHTTP(mStrRegistServer, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_REGIST_CLIENT).append(jsObject.toString()).toString());
            }
            for (i = 0; i < 3; i++) {
                server = LocalDefines.getAlarmServerByIndex(i);
                requestResult = Functions.GetJsonStringFromServerByHTTP(server, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_REGIST_CLIENT).append(jsObject.toString()).toString());
                if (requestResult == null) {
                }
            }
            if (requestResult != null) {
            }
            Log.w("XG1", "requestResult == null");
            this.editor.putBoolean(LocalDefines.ALARM_DEVICE_LOGIN, false);
            this.editor.commit();
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
    }
}
