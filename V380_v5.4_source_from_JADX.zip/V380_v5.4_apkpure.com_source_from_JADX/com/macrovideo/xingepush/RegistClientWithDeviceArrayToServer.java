package com.macrovideo.xingepush;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.os.Handler;
import android.util.Log;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.LocalDefines;
import com.tencent.android.tpush.common.Constants;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RegistClientWithDeviceArrayToServer extends Thread {
    private Context context;
    private Editor editor = null;
    Handler lHandler = null;
    private int nThreadID = 0;

    public RegistClientWithDeviceArrayToServer(Handler lHandler, int nThreadID) {
        this.lHandler = lHandler;
        this.nThreadID = nThreadID;
    }

    public RegistClientWithDeviceArrayToServer(Context context, int nThreadID) {
        this.context = context;
        this.nThreadID = nThreadID;
    }

    public void run() {
        if (!LocalDefines.isDeviceListSet) {
            while (this.nThreadID == LocalDefines.nClientDeviceSettingThreadID) {
                if (LocalDefines.isClientRegisted) {
                    break;
                }
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (LocalDefines._severInfoWithoutImageListData != null && LocalDefines._severInfoWithoutImageListData.size() > 0 && LocalDefines.strClientID != null && LocalDefines.strClientID.length() == 40 && this.nThreadID == LocalDefines.nClientDeviceSettingThreadID) {
                JSONObject jsObject = new JSONObject();
                jsObject.put("client_id", LocalDefines.strClientID);
                JSONArray jsArray = new JSONArray();
                int i = LocalDefines._severInfoWithoutImageListData.size() - 1;
                while (i >= 0) {
                    try {
                        DeviceInfo info = (DeviceInfo) LocalDefines._severInfoWithoutImageListData.get(i);
                        if (info != null && info.getnDevID() > 0) {
                            JSONObject jsDev = new JSONObject();
                            String strUsername = info.getStrUsername();
                            String strPassword = info.getStrPassword();
                            jsDev.put("dev_id", info.getnDevID());
                            if (info.isRecvMsg()) {
                                jsDev.put("recv_msg_pri", 1);
                            } else {
                                jsDev.put("recv_msg_pri", 0);
                            }
                            if (strUsername == null || strUsername.length() <= 0) {
                                jsDev.put("username", Constants.MAIN_VERSION_TAG);
                            } else {
                                jsDev.put("username", strUsername);
                            }
                            if (strPassword == null || strPassword.length() <= 0) {
                                jsDev.put("password", Constants.MAIN_VERSION_TAG);
                            } else {
                                jsDev.put("password", strPassword);
                            }
                            jsArray.put(jsDev);
                        }
                        i--;
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }
                }
                jsObject.put("dev_list", jsArray);
                String requestResult = null;
                if (RegistClientToServer.mStrRegistServer != null) {
                    requestResult = Functions.GetJsonStringFromServerByHTTP(RegistClientToServer.mStrRegistServer, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_SET_DEVICE_ARRAY_ALARM).append(jsObject.toString()).toString());
                }
                if (requestResult == null || requestResult.length() <= 0) {
                    for (i = 0; i < 3; i++) {
                        String server = LocalDefines.getAlarmServerByIndex(i);
                        requestResult = Functions.GetJsonStringFromServerByHTTP(server, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_SET_DEVICE_ARRAY_ALARM).append(jsObject.toString()).toString());
                        if (requestResult != null && requestResult.length() > 0) {
                            RegistClientToServer.mStrRegistServer = server;
                            break;
                        }
                    }
                }
                if (requestResult == null || requestResult.length() <= 0) {
                    Log.w("XG2", "requestResult == null");
                    return;
                }
                try {
                    JSONObject objStr = new JSONObject(requestResult);
                    if (objStr != null && objStr.getInt("result") > 0) {
                        LocalDefines.isDeviceListSet = true;
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }
}
