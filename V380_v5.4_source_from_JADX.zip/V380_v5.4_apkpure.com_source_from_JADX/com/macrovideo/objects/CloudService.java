package com.macrovideo.objects;

public class CloudService {
    private String begin_time;
    private int bind_status;
    private String bind_status_name;
    private String device_id;
    private String end_time;
    private String introduction;
    private int product_id;
    private int record_resolution;
    private String record_resolution_name;
    private int record_save_day;
    private int service_id;

    public CloudService(int service_id, int product_id, String begin_time, String end_time, int record_save_day, int record_resolution, String record_resolution_name, String device_id, int bind_status, String bind_status_name, String introduction) {
        this.service_id = service_id;
        this.product_id = product_id;
        this.begin_time = begin_time;
        this.end_time = end_time;
        this.record_save_day = record_save_day;
        this.record_resolution = record_resolution;
        this.record_resolution_name = record_resolution_name;
        this.device_id = device_id;
        this.bind_status = bind_status;
        this.bind_status_name = bind_status_name;
        this.introduction = introduction;
    }

    public int getService_id() {
        return this.service_id;
    }

    public void setService_id(int service_id) {
        this.service_id = service_id;
    }

    public int getProduct_id() {
        return this.product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public String getBegin_time() {
        return this.begin_time;
    }

    public void setBegin_time(String begin_time) {
        this.begin_time = begin_time;
    }

    public String getEnd_time() {
        return this.end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public int getRecord_save_day() {
        return this.record_save_day;
    }

    public void setRecord_save_day(int record_save_day) {
        this.record_save_day = record_save_day;
    }

    public int getRecord_resolution() {
        return this.record_resolution;
    }

    public void setRecord_resolution(int record_resolution) {
        this.record_resolution = record_resolution;
    }

    public String getRecord_resolution_name() {
        return this.record_resolution_name;
    }

    public void setRecord_resolution_name(String record_resolution_name) {
        this.record_resolution_name = record_resolution_name;
    }

    public String getDevice_id() {
        return this.device_id;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public int getBind_status() {
        return this.bind_status;
    }

    public void setBind_status(int bind_status) {
        this.bind_status = bind_status;
    }

    public String getBind_status_name() {
        return this.bind_status_name;
    }

    public void setBind_status_name(String bind_status_name) {
        this.bind_status_name = bind_status_name;
    }

    public String getIntroduction() {
        return this.introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }
}
