package com.macrovideo.animate;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import com.macrovideo.photo.PhotoViewAttacher;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.C0470R;

public class TweenAnimate extends BaseView {
    private Animation alphaAnimation = null;
    private Bitmap bitmap;
    private Animation rotateAnimation = null;
    private Animation scaleAnimation = null;
    private Animation translateAnimation = null;

    public TweenAnimate(Context context) {
        super(context);
        initBitmap();
    }

    public TweenAnimate(Context context, AttributeSet attrs) {
        super(context, attrs);
        initBitmap();
    }

    public TweenAnimate(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initBitmap();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Log.e("Tween", "onDraw");
        canvas.drawBitmap(this.bitmap, 0.0f, 0.0f, null);
    }

    private void initBitmap() {
        if (this.bitmap == null) {
            this.bitmap = Bitmap.createBitmap(Functions.readBitMap(this.context, C0470R.drawable.radar_fan));
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.e("Tween", "onKeyDown");
        return true;
    }

    public boolean onKeyUp(int keyCode, KeyEvent event) {
        Log.e("Tween", "onKeyDown");
        switch (keyCode) {
            case 19:
                Log.e("Tween", "onKeyDown - KEYCODE_DPAD_UP");
                this.alphaAnimation = new AlphaAnimation(0.1f, PhotoViewAttacher.DEFAULT_MIN_SCALE);
                this.alphaAnimation.setDuration(3000);
                startAnimation(this.alphaAnimation);
                break;
            case 20:
                Log.e("Tween", "onKeyDown - KEYCODE_DPAD_DOWN");
                this.rotateAnimation = new RotateAnimation(0.0f, 360.0f);
                this.rotateAnimation.setDuration(1000);
                startAnimation(this.rotateAnimation);
                break;
            case 21:
                Log.e("Tween", "onKeyDown - KEYCODE_DPAD_LEFT");
                this.scaleAnimation = new ScaleAnimation(0.1f, PhotoViewAttacher.DEFAULT_MIN_SCALE, 0.1f, PhotoViewAttacher.DEFAULT_MIN_SCALE);
                this.scaleAnimation.setDuration(500);
                startAnimation(this.scaleAnimation);
                break;
            case 22:
                Log.e("Tween", "onKeyDown - KEYCODE_DPAD_RIGHT");
                this.translateAnimation = new TranslateAnimation(0.1f, 100.0f, 0.1f, 100.0f);
                this.translateAnimation.setDuration(1000);
                startAnimation(this.translateAnimation);
                break;
            case 23:
                Log.e("Tween", "onKeyDown - KEYCODE_DPAD_CENTER");
                this.translateAnimation = new TranslateAnimation(0.1f, 100.0f, 0.1f, 100.0f);
                this.alphaAnimation = new AlphaAnimation(0.1f, PhotoViewAttacher.DEFAULT_MIN_SCALE);
                AnimationSet set = new AnimationSet(true);
                set.addAnimation(this.translateAnimation);
                set.addAnimation(this.alphaAnimation);
                set.setDuration(1000);
                startAnimation(set);
                break;
        }
        return true;
    }
}
