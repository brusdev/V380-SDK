package com.macrovideo.animate;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.C0470R;

public class RadarView extends BaseView {
    public static final boolean f1172D = false;
    public static final String TAG = "SearchDevicesView";
    private long TIME_DIFF = 2000;
    int[] argColor = new int[]{Defines.NV_IPC_IP_CONFIG_SET_RESPONSE, Defines.NV_IPC_IP_CONFIG_SET_RESPONSE, Defines.REC_FILE_SEARCH_RESP};
    private Bitmap bitmap;
    private Bitmap bitmap2;
    int[] innerCircle0 = new int[]{185, 255, 255};
    int[] innerCircle1 = new int[]{Defines.REC_FILE_SEARCH_EX_RESP, 255, 255};
    int[] innerCircle2 = new int[]{Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_RESPONSE, 255, 255};
    private boolean isSearching = false;
    int[] lineColor = new int[]{123, 123, 123};
    private float offsetArgs = 0.0f;

    public boolean isSearching() {
        return this.isSearching;
    }

    public void startAnimate() {
        this.isSearching = true;
        this.offsetArgs = 0.0f;
        invalidate();
    }

    public void stopAnimate() {
        this.isSearching = false;
        this.offsetArgs = 0.0f;
        invalidate();
    }

    public RadarView(Context context) {
        super(context);
        initBitmap();
    }

    public RadarView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initBitmap();
    }

    public RadarView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initBitmap();
    }

    private void initBitmap() {
        if (this.bitmap == null) {
            this.bitmap = Bitmap.createBitmap(Functions.readBitMap(this.context, C0470R.drawable.radar_area));
        }
        if (this.bitmap2 == null) {
            this.bitmap2 = Bitmap.createBitmap(BitmapFactory.decodeResource(this.context.getResources(), C0470R.drawable.radar_fan));
        }
    }

    public void recycleBitmap() {
        if (!(this.bitmap == null || this.bitmap.isRecycled())) {
            this.bitmap.recycle();
        }
        if (this.bitmap2 != null && !this.bitmap2.isRecycled()) {
            this.bitmap2.recycle();
        }
    }

    @SuppressLint({"DrawAllocation"})
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Rect dst = new Rect(0, (getHeight() - getWidth()) / 2, getWidth(), (getHeight() + getWidth()) / 2);
        canvas.drawBitmap(this.bitmap, null, dst, null);
        if (this.isSearching) {
            canvas.rotate(this.offsetArgs, (float) (getWidth() / 2), (float) (getHeight() / 2));
            canvas.drawBitmap(this.bitmap2, null, dst, null);
            this.offsetArgs += 3.0f;
        } else {
            canvas.drawBitmap(this.bitmap2, (float) ((getWidth() / 2) - this.bitmap2.getWidth()), (float) (getHeight() / 2), null);
        }
        if (this.isSearching) {
            invalidate();
        }
    }
}
