package com.macrovideo.pull.lib;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Handler;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.macrovideo.photo.PhotoViewAttacher;
import com.macrovideo.pull.lib.internal.LoadingLayout;
import com.macrovideo.v380.C0470R;

public abstract class PullToRefreshBase<T extends View> extends LinearLayout {
    static final float FRICTION = 2.0f;
    static final int MANUAL_REFRESHING = 3;
    public static final int MODE_BOTH = 3;
    public static final int MODE_PULL_DOWN_TO_REFRESH = 1;
    public static final int MODE_PULL_UP_TO_REFRESH = 2;
    static final int PULL_TO_REFRESH = 0;
    static final int REFRESHING = 2;
    static final int RELEASE_TO_REFRESH = 1;
    private int currentMode;
    private SmoothScrollRunnable currentSmoothScrollRunnable;
    private boolean disableScrollingWhileRefreshing = true;
    private LoadingLayout footerLayout;
    private final Handler handler = new Handler();
    private int headerHeight;
    private LoadingLayout headerLayout;
    private float initialMotionY;
    private boolean isBeingDragged = false;
    private boolean isPullToRefreshEnabled = true;
    private float lastMotionX;
    private float lastMotionY;
    private int mode = 1;
    private int nVisiable = 8;
    private OnRefreshListener onRefreshListener;
    T refreshableView;
    private int state = 0;
    private int touchSlop;

    public interface OnLastItemVisibleListener {
        void onLastItemVisible();
    }

    public interface OnRefreshListener {
        void onRefresh();
    }

    final class SmoothScrollRunnable implements Runnable {
        static final int ANIMATION_DURATION_MS = 190;
        static final int ANIMATION_FPS = 16;
        private boolean continueRunning = true;
        private int currentY = -1;
        private final Handler handler;
        private final Interpolator interpolator;
        private final int scrollFromY;
        private final int scrollToY;
        private long startTime = -1;

        public SmoothScrollRunnable(Handler handler, int fromY, int toY) {
            this.handler = handler;
            this.scrollFromY = fromY;
            this.scrollToY = toY;
            this.interpolator = new AccelerateDecelerateInterpolator();
        }

        public void run() {
            if (this.startTime == -1) {
                this.startTime = System.currentTimeMillis();
            } else {
                this.currentY = this.scrollFromY - Math.round(((float) (this.scrollFromY - this.scrollToY)) * this.interpolator.getInterpolation(((float) Math.max(Math.min(((System.currentTimeMillis() - this.startTime) * 1000) / 190, 1000), 0)) / 1000.0f));
                PullToRefreshBase.this.setHeaderScroll(this.currentY);
            }
            if (this.continueRunning && this.scrollToY != this.currentY) {
                this.handler.postDelayed(this, 16);
            }
        }

        public void stop() {
            this.continueRunning = false;
            this.handler.removeCallbacks(this);
        }
    }

    protected abstract T createRefreshableView(Context context, AttributeSet attributeSet);

    protected abstract boolean isReadyForPullDown();

    protected abstract boolean isReadyForPullUp();

    public void SetText(String releaseLabel, String pullLabel, String refreshingLabel) {
        this.headerLayout.SetText(releaseLabel, pullLabel, refreshingLabel);
    }

    public void visibleHeaderLayout(boolean bVisible) {
        if (bVisible) {
            this.headerLayout.setVisibility(0);
        } else {
            this.headerLayout.setVisibility(4);
        }
    }

    public PullToRefreshBase(Context context) {
        super(context);
        init(context, null);
    }

    public PullToRefreshBase(Context context, int mode) {
        super(context);
        this.mode = mode;
        init(context, null);
    }

    public PullToRefreshBase(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public final T getAdapterView() {
        return this.refreshableView;
    }

    public final T getRefreshableView() {
        return this.refreshableView;
    }

    public final boolean isPullToRefreshEnabled() {
        return this.isPullToRefreshEnabled;
    }

    public final boolean isDisableScrollingWhileRefreshing() {
        return this.disableScrollingWhileRefreshing;
    }

    public final boolean isRefreshing() {
        return this.state == 2 || this.state == 3;
    }

    public final void setDisableScrollingWhileRefreshing(boolean disableScrollingWhileRefreshing) {
        this.disableScrollingWhileRefreshing = disableScrollingWhileRefreshing;
    }

    public final void onRefreshComplete() {
        if (this.state != 0) {
            resetHeader();
        }
    }

    public final void setOnRefreshListener(OnRefreshListener listener) {
        this.onRefreshListener = listener;
    }

    public final void setPullToRefreshEnabled(boolean enable) {
        this.isPullToRefreshEnabled = enable;
    }

    public void setReleaseLabel(String releaseLabel) {
        if (this.headerLayout != null) {
            this.headerLayout.setReleaseLabel(releaseLabel);
        }
        if (this.footerLayout != null) {
            this.footerLayout.setReleaseLabel(releaseLabel);
        }
    }

    public void setPullLabel(String pullLabel) {
        if (this.headerLayout != null) {
            this.headerLayout.setPullLabel(pullLabel);
        }
        if (this.footerLayout != null) {
            this.footerLayout.setPullLabel(pullLabel);
        }
    }

    public void setRefreshingLabel(String refreshingLabel) {
        if (this.headerLayout != null) {
            this.headerLayout.setRefreshingLabel(refreshingLabel);
        }
        if (this.footerLayout != null) {
            this.footerLayout.setRefreshingLabel(refreshingLabel);
        }
    }

    public final void setRefreshing() {
        setRefreshing(true);
    }

    public final void setRefreshing(boolean doScroll) {
        if (!isRefreshing()) {
            setRefreshingInternal(doScroll);
            this.state = 3;
        }
    }

    public final boolean hasPullFromTop() {
        return this.currentMode != 2;
    }

    public final boolean onTouchEvent(MotionEvent event) {
        if (!this.isPullToRefreshEnabled) {
            return false;
        }
        if (isRefreshing() && this.disableScrollingWhileRefreshing) {
            return true;
        }
        if (event.getAction() == 0 && event.getEdgeFlags() != 0) {
            return false;
        }
        switch (event.getAction()) {
            case 0:
                if (!isReadyForPull()) {
                    return false;
                }
                float y = event.getY();
                this.initialMotionY = y;
                this.lastMotionY = y;
                return true;
            case 1:
            case 3:
                if (!this.isBeingDragged) {
                    return false;
                }
                this.isBeingDragged = false;
                if (this.state != 1 || this.onRefreshListener == null) {
                    smoothScrollTo(0);
                    this.nVisiable = 8;
                } else {
                    setRefreshingInternal(true);
                    this.onRefreshListener.onRefresh();
                }
                return true;
            case 2:
                if (!this.isBeingDragged) {
                    return false;
                }
                this.lastMotionY = event.getY();
                pullEvent();
                return true;
            default:
                return false;
        }
    }

    public final boolean onInterceptTouchEvent(MotionEvent event) {
        if (!this.isPullToRefreshEnabled) {
            return false;
        }
        if (isRefreshing() && this.disableScrollingWhileRefreshing) {
            return true;
        }
        int action = event.getAction();
        if (action == 3 || action == 1) {
            this.isBeingDragged = false;
            return false;
        } else if (action != 0 && this.isBeingDragged) {
            return true;
        } else {
            switch (action) {
                case 0:
                    if (isReadyForPull()) {
                        float y = event.getY();
                        this.initialMotionY = y;
                        this.lastMotionY = y;
                        this.lastMotionX = event.getX();
                        this.isBeingDragged = false;
                        break;
                    }
                    break;
                case 2:
                    if (isReadyForPull()) {
                        float y2 = event.getY();
                        float dy = y2 - this.lastMotionY;
                        float yDiff = Math.abs(dy);
                        float xDiff = Math.abs(event.getX() - this.lastMotionX);
                        if (yDiff > ((float) this.touchSlop) && yDiff > xDiff) {
                            if ((this.mode != 1 && this.mode != 3) || dy < 1.0E-4f || !isReadyForPullDown()) {
                                if ((this.mode == 2 || this.mode == 3) && dy <= 1.0E-4f && isReadyForPullUp()) {
                                    this.lastMotionY = y2;
                                    this.isBeingDragged = true;
                                    if (this.mode == 3) {
                                        this.currentMode = 2;
                                        break;
                                    }
                                }
                            }
                            this.lastMotionY = y2;
                            this.isBeingDragged = true;
                            if (this.mode == 3) {
                                this.currentMode = 1;
                                break;
                            }
                        }
                    }
                    break;
            }
            return this.isBeingDragged;
        }
    }

    protected void addRefreshableView(Context context, T refreshableView) {
        addView(refreshableView, new LayoutParams(-1, 0, PhotoViewAttacher.DEFAULT_MIN_SCALE));
    }

    protected final int getCurrentMode() {
        return this.currentMode;
    }

    protected final LoadingLayout getFooterLayout() {
        return this.footerLayout;
    }

    protected final LoadingLayout getHeaderLayout() {
        return this.headerLayout;
    }

    protected final int getHeaderHeight() {
        return this.headerHeight;
    }

    protected final int getMode() {
        return this.mode;
    }

    protected void resetHeader() {
        this.state = 0;
        this.isBeingDragged = false;
        if (this.headerLayout != null) {
            this.headerLayout.reset();
        }
        if (this.footerLayout != null) {
            this.footerLayout.reset();
        }
        smoothScrollTo(0);
    }

    protected void setRefreshingInternal(boolean doScroll) {
        this.state = 2;
        if (this.headerLayout != null) {
            this.headerLayout.refreshing();
        }
        if (this.footerLayout != null) {
            this.footerLayout.refreshing();
        }
        if (doScroll) {
            smoothScrollTo(this.currentMode == 1 ? -this.headerHeight : this.headerHeight);
        }
    }

    protected final void setHeaderScroll(int y) {
        scrollTo(0, y);
    }

    protected final void smoothScrollTo(int y) {
        if (this.currentSmoothScrollRunnable != null) {
            this.currentSmoothScrollRunnable.stop();
        }
        if (getScrollY() != y) {
            this.currentSmoothScrollRunnable = new SmoothScrollRunnable(this.handler, getScrollY(), y);
            this.handler.post(this.currentSmoothScrollRunnable);
        }
    }

    private void init(Context context, AttributeSet attrs) {
        setOrientation(1);
        this.touchSlop = ViewConfiguration.getTouchSlop();
        TypedArray a = context.obtainStyledAttributes(attrs, C0470R.styleable.PullToRefresh);
        if (a.hasValue(3)) {
            this.mode = a.getInteger(3, 1);
        }
        this.refreshableView = createRefreshableView(context, attrs);
        addRefreshableView(context, this.refreshableView);
        String pullLabel = context.getString(C0470R.string.pull_to_refresh_pull_label);
        String refreshingLabel = context.getString(C0470R.string.pull_to_refresh_refreshing_label);
        String releaseLabel = context.getString(C0470R.string.pull_to_refresh_release_label);
        if (this.mode == 1 || this.mode == 3) {
            this.headerLayout = new LoadingLayout(context, 1, releaseLabel, pullLabel, refreshingLabel);
            addView(this.headerLayout, 0, new LayoutParams(-1, -2));
            measureView(this.headerLayout);
            this.headerHeight = this.headerLayout.getMeasuredHeight();
        }
        if (this.mode == 2 || this.mode == 3) {
            this.footerLayout = new LoadingLayout(context, 2, releaseLabel, pullLabel, refreshingLabel);
            addView(this.footerLayout, new LayoutParams(-1, -2));
            measureView(this.footerLayout);
            this.headerHeight = this.footerLayout.getMeasuredHeight();
        }
        if (a.hasValue(2)) {
            int color = a.getColor(2, ViewCompat.MEASURED_STATE_MASK);
            if (this.headerLayout != null) {
                this.headerLayout.setTextColor(color);
            }
            if (this.footerLayout != null) {
                this.footerLayout.setTextColor(color);
            }
        }
        if (a.hasValue(1)) {
            setBackgroundResource(a.getResourceId(1, -1));
        }
        if (a.hasValue(0)) {
            this.refreshableView.setBackgroundResource(a.getResourceId(0, -1));
        }
        a.recycle();
        switch (this.mode) {
            case 2:
                setPadding(0, 0, 0, -this.headerHeight);
                break;
            case 3:
                setPadding(0, -this.headerHeight, 0, -this.headerHeight);
                break;
            default:
                setPadding(0, -this.headerHeight, 0, 0);
                break;
        }
        if (this.mode != 3) {
            this.currentMode = this.mode;
        }
    }

    private void measureView(View child) {
        int childHeightSpec;
        ViewGroup.LayoutParams p = child.getLayoutParams();
        if (p == null) {
            p = new ViewGroup.LayoutParams(-1, -2);
        }
        int childWidthSpec = ViewGroup.getChildMeasureSpec(0, 0, p.width);
        int lpHeight = p.height;
        if (lpHeight > 0) {
            childHeightSpec = MeasureSpec.makeMeasureSpec(lpHeight, 1073741824);
        } else {
            childHeightSpec = MeasureSpec.makeMeasureSpec(0, 0);
        }
        child.measure(childWidthSpec, childHeightSpec);
    }

    private boolean pullEvent() {
        int newHeight;
        int oldHeight = getScrollY();
        switch (this.currentMode) {
            case 2:
                newHeight = Math.round(Math.max(this.initialMotionY - this.lastMotionY, 0.0f) / FRICTION);
                break;
            default:
                newHeight = Math.round(Math.min(this.initialMotionY - this.lastMotionY, 0.0f) / FRICTION);
                break;
        }
        setHeaderScroll(newHeight);
        if (newHeight != 0) {
            if (this.state == 0 && this.headerHeight < Math.abs(newHeight)) {
                this.state = 1;
                switch (this.currentMode) {
                    case 1:
                        this.headerLayout.releaseToRefresh();
                        return true;
                    case 2:
                        this.footerLayout.releaseToRefresh();
                        return true;
                    default:
                        return true;
                }
            } else if (this.state == 1 && this.headerHeight >= Math.abs(newHeight)) {
                this.state = 0;
                switch (this.currentMode) {
                    case 1:
                        this.headerLayout.pullToRefresh();
                        return true;
                    case 2:
                        this.footerLayout.pullToRefresh();
                        return true;
                    default:
                        return true;
                }
            }
        }
        if (oldHeight == newHeight) {
            return false;
        }
        return true;
    }

    private boolean isReadyForPull() {
        switch (this.mode) {
            case 1:
                return isReadyForPullDown();
            case 2:
                return isReadyForPullUp();
            case 3:
                return isReadyForPullUp() || isReadyForPullDown();
            default:
                return false;
        }
    }

    public void setLongClickable(boolean longClickable) {
        getRefreshableView().setLongClickable(longClickable);
    }
}
