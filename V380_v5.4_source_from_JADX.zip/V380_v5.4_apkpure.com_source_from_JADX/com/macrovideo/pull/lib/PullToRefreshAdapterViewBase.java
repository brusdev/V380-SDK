package com.macrovideo.pull.lib;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import com.macrovideo.photo.PhotoViewAttacher;
import com.macrovideo.pull.lib.PullToRefreshBase.OnLastItemVisibleListener;
import com.macrovideo.pull.lib.internal.EmptyViewMethodAccessor;

public abstract class PullToRefreshAdapterViewBase<T extends AbsListView> extends PullToRefreshBase<T> implements OnScrollListener {
    private View emptyView;
    private int lastSavedFirstVisibleItem = -1;
    private ImageView mTopImageView;
    private OnLastItemVisibleListener onLastItemVisibleListener;
    private OnScrollListener onScrollListener;
    private FrameLayout refreshableViewHolder;

    class C02301 implements OnClickListener {
        C02301() {
        }

        public void onClick(View v) {
            if (PullToRefreshAdapterViewBase.this.refreshableView instanceof ListView) {
                ((ListView) PullToRefreshAdapterViewBase.this.refreshableView).setSelection(0);
            } else if (PullToRefreshAdapterViewBase.this.refreshableView instanceof GridView) {
                ((GridView) PullToRefreshAdapterViewBase.this.refreshableView).setSelection(0);
            }
        }
    }

    public abstract ContextMenuInfo getContextMenuInfo();

    public PullToRefreshAdapterViewBase(Context context) {
        super(context);
        ((AbsListView) this.refreshableView).setOnScrollListener(this);
    }

    public PullToRefreshAdapterViewBase(Context context, int mode) {
        super(context, mode);
        ((AbsListView) this.refreshableView).setOnScrollListener(this);
    }

    public PullToRefreshAdapterViewBase(Context context, AttributeSet attrs) {
        super(context, attrs);
        ((AbsListView) this.refreshableView).setOnScrollListener(this);
    }

    public final void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (this.onLastItemVisibleListener != null && visibleItemCount > 0 && firstVisibleItem + visibleItemCount == totalItemCount && firstVisibleItem != this.lastSavedFirstVisibleItem) {
            this.lastSavedFirstVisibleItem = firstVisibleItem;
            this.onLastItemVisibleListener.onLastItemVisible();
        }
        if (this.onScrollListener != null) {
            this.onScrollListener.onScroll(view, firstVisibleItem, visibleItemCount, totalItemCount);
        }
    }

    public final void onScrollStateChanged(AbsListView view, int scrollState) {
        if (this.onScrollListener != null) {
            this.onScrollListener.onScrollStateChanged(view, scrollState);
        }
    }

    public void setBackToTopView(ImageView mTopImageView) {
        this.mTopImageView = mTopImageView;
        if (mTopImageView != null) {
            mTopImageView.setOnClickListener(new C02301());
        }
    }

    public void showBackToTopView(boolean bShow) {
        if (this.mTopImageView != null) {
            if (bShow) {
                this.mTopImageView.setVisibility(0);
            } else {
                this.mTopImageView.setVisibility(8);
            }
        }
    }

    public final void setEmptyView(View newEmptyView) {
        if (this.emptyView != null) {
            this.refreshableViewHolder.removeView(this.emptyView);
        }
        if (newEmptyView != null) {
            ViewParent newEmptyViewParent = newEmptyView.getParent();
            if (newEmptyViewParent != null && (newEmptyViewParent instanceof ViewGroup)) {
                ((ViewGroup) newEmptyViewParent).removeView(newEmptyView);
            }
            this.refreshableViewHolder.addView(newEmptyView, -1, -1);
        }
        if (this.refreshableView instanceof EmptyViewMethodAccessor) {
            ((EmptyViewMethodAccessor) this.refreshableView).setEmptyViewInternal(newEmptyView);
        } else {
            ((AbsListView) this.refreshableView).setEmptyView(newEmptyView);
        }
    }

    public final void setOnLastItemVisibleListener(OnLastItemVisibleListener listener) {
        this.onLastItemVisibleListener = listener;
    }

    public final void setOnScrollListener(OnScrollListener listener) {
        this.onScrollListener = listener;
    }

    protected void addRefreshableView(Context context, T refreshableView) {
        this.refreshableViewHolder = new FrameLayout(context);
        this.refreshableViewHolder.addView(refreshableView, -1, -1);
        addView(this.refreshableViewHolder, new LayoutParams(-1, 0, PhotoViewAttacher.DEFAULT_MIN_SCALE));
    }

    protected boolean isReadyForPullDown() {
        return isFirstItemVisible();
    }

    protected boolean isReadyForPullUp() {
        return isLastItemVisible();
    }

    private boolean isFirstItemVisible() {
        if (((AbsListView) this.refreshableView).getCount() == 0) {
            return true;
        }
        if (((AbsListView) this.refreshableView).getFirstVisiblePosition() == 0) {
            View firstVisibleChild = ((AbsListView) this.refreshableView).getChildAt(0);
            if (firstVisibleChild != null) {
                return firstVisibleChild.getTop() >= ((AbsListView) this.refreshableView).getTop();
            }
        }
        return false;
    }

    private boolean isLastItemVisible() {
        int count = ((AbsListView) this.refreshableView).getCount();
        int lastVisiblePosition = ((AbsListView) this.refreshableView).getLastVisiblePosition();
        if (count == 0) {
            return true;
        }
        if (lastVisiblePosition == count - 1) {
            View lastVisibleChild = ((AbsListView) this.refreshableView).getChildAt(lastVisiblePosition - ((AbsListView) this.refreshableView).getFirstVisiblePosition());
            if (lastVisibleChild != null) {
                return lastVisibleChild.getBottom() <= ((AbsListView) this.refreshableView).getBottom();
            }
        }
        return false;
    }
}
