package com.macrovideo.pull.lib;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.os.Handler;
import android.support.v4.view.ViewCompat;
import android.view.View;
import java.util.Timer;
import java.util.TimerTask;

public class SectorView extends View {
    int currentAngle = 0;
    boolean flag = true;
    Handler handler;
    int height;
    private RectF oval2;
    private Paint paint;
    int startAngle;
    int sweetAngle;
    private TimerTask task = new C02311();
    Timer timer;
    int width;

    class C02311 extends TimerTask {
        C02311() {
        }

        public void run() {
            SectorView sectorView = SectorView.this;
            sectorView.currentAngle += 5;
            SectorView.this.postInvalidate();
        }
    }

    class C02322 implements Runnable {
        C02322() {
        }

        public void run() {
            SectorView sectorView = SectorView.this;
            sectorView.currentAngle += 3;
            SectorView.this.invalidate();
            SectorView.this.handler.postDelayed(this, 80);
        }
    }

    public SectorView(Context context) {
        super(context);
        setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.paint = new Paint();
        this.timer = new Timer();
        this.handler = new Handler();
        this.width = context.getResources().getDisplayMetrics().widthPixels;
        this.height = context.getResources().getDisplayMetrics().heightPixels;
        this.paint.setColor(-7829368);
        this.paint.setAlpha(255);
        this.paint.setAntiAlias(true);
        this.paint.setStrokeWidth(5.0f);
        this.handler.post(new C02322());
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawCirCle(canvas);
        drawSertor(canvas);
    }

    public void drawCirCle(Canvas canvas) {
        this.paint.setStyle(Style.STROKE);
        for (int r = 20; r < this.height / 2; r += 100) {
            canvas.drawCircle((float) (this.width / 2), (float) (this.height / 2), (float) r, this.paint);
        }
    }

    public void drawSertor(Canvas canvas) {
        this.paint.setStyle(Style.FILL);
        this.oval2 = new RectF(0.0f, (float) ((this.height - this.width) / 2), (float) this.width, (float) (this.width + ((this.height - this.width) / 2)));
        int[] iArr = new int[2];
        iArr[0] = -16711936;
        this.paint.setShader(new LinearGradient(0.0f, 0.0f, 1000.0f, 1000.0f, iArr, null, TileMode.REPEAT));
        canvas.drawArc(this.oval2, (float) this.currentAngle, 65.0f, true, this.paint);
    }
}
