package com.macrovideo.pull.lib.internal;

import android.view.View;

public interface EmptyViewMethodAccessor {
    void setEmptyView(View view);

    void setEmptyViewInternal(View view);
}
