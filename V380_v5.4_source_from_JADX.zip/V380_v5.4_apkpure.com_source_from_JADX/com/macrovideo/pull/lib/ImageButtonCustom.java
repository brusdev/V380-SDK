package com.macrovideo.pull.lib;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ImageButtonCustom extends LinearLayout {
    private ImageView imageViewbutton;
    private TextView textView;

    public ImageButtonCustom(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.imageViewbutton = new ImageView(context, attrs);
        this.imageViewbutton.setPadding(0, 0, 0, 0);
        this.textView = new TextView(context, attrs);
        this.textView.setGravity(1);
        this.textView.setPadding(0, 0, 0, 0);
        setClickable(true);
        setFocusable(true);
        setBackgroundResource(17301508);
        setOrientation(1);
        addView(this.imageViewbutton);
        addView(this.textView);
    }
}
