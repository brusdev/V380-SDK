package com.macrovideo.Zxing.Demo.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import com.google.zxing.ResultPoint;
import com.macrovideo.Zxing.Demo.camera.CameraManager;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.v380.C0470R;
import java.util.Collection;
import java.util.HashSet;

public final class ViewfinderView extends View {
    private static final long ANIMATION_DELAY = 100;
    private static final int CORNER_WIDTH = 5;
    private static final int OPAQUE = 255;
    private static final int[] SCANNER_ALPHA;
    private static final int TEXT_PADDING_TOP = 40;
    private static final int TEXT_SIZE = 15;
    private static float density;
    public int ScreenRate;
    private final int frameColor;
    private final int laserColor;
    private Collection<ResultPoint> lastPossibleResultPoints;
    private final int maskColor;
    private final Paint paint;
    private Collection<ResultPoint> possibleResultPoints;
    private Bitmap resultBitmap;
    private final int resultColor;
    private final int resultPointColor;
    private int scannerAlpha;
    private int yDelta = 0;

    static {
        int[] iArr = new int[8];
        iArr[1] = 64;
        iArr[2] = 128;
        iArr[3] = 192;
        iArr[4] = 255;
        iArr[5] = 192;
        iArr[6] = 128;
        iArr[7] = 64;
        SCANNER_ALPHA = iArr;
    }

    public ViewfinderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = context.getResources().getDisplayMetrics().density;
        this.ScreenRate = (int) (20.0f * density);
        this.paint = new Paint();
        Resources resources = getResources();
        this.maskColor = resources.getColor(C0470R.color.viewfinder_mask);
        this.resultColor = resources.getColor(C0470R.color.result_view);
        this.frameColor = resources.getColor(C0470R.color.viewfinder_frame);
        this.laserColor = resources.getColor(C0470R.color.result_points);
        this.resultPointColor = resources.getColor(C0470R.color.possible_result_points);
        this.scannerAlpha = 0;
        this.possibleResultPoints = new HashSet(5);
    }

    public void onDraw(Canvas canvas) {
        Rect frame = CameraManager.get().getFramingRect();
        if (frame != null) {
            int i;
            int width = canvas.getWidth();
            int height = canvas.getHeight();
            Paint paint = this.paint;
            if (this.resultBitmap != null) {
                i = this.resultColor;
            } else {
                i = this.maskColor;
            }
            paint.setColor(i);
            canvas.drawRect(0.0f, 0.0f, (float) width, (float) frame.top, this.paint);
            canvas.drawRect(0.0f, (float) frame.top, (float) frame.left, (float) (frame.bottom + 1), this.paint);
            canvas.drawRect((float) (frame.right + 1), (float) frame.top, (float) width, (float) (frame.bottom + 1), this.paint);
            canvas.drawRect(0.0f, (float) (frame.bottom + 1), (float) width, (float) height, this.paint);
            if (this.resultBitmap != null) {
                this.paint.setAlpha(255);
                canvas.drawBitmap(this.resultBitmap, (float) frame.left, (float) frame.top, this.paint);
                return;
            }
            this.paint.setColor(-1);
            canvas.drawRect((float) frame.left, (float) frame.top, (float) (frame.right + 1), (float) (frame.top + 2), this.paint);
            canvas.drawRect((float) frame.left, (float) (frame.top + 2), (float) (frame.left + 2), (float) (frame.bottom - 1), this.paint);
            canvas.drawRect((float) (frame.right - 1), (float) frame.top, (float) (frame.right + 1), (float) (frame.bottom - 1), this.paint);
            canvas.drawRect((float) frame.left, (float) (frame.bottom - 1), (float) (frame.right + 1), (float) (frame.bottom + 1), this.paint);
            this.paint.setColor(-16711936);
            canvas.drawRect((float) frame.left, (float) frame.top, (float) (frame.left + this.ScreenRate), (float) (frame.top + 5), this.paint);
            canvas.drawRect((float) frame.left, (float) frame.top, (float) (frame.left + 5), (float) (frame.top + this.ScreenRate), this.paint);
            canvas.drawRect((float) (frame.right - this.ScreenRate), (float) frame.top, (float) frame.right, (float) (frame.top + 5), this.paint);
            canvas.drawRect((float) (frame.right - 5), (float) frame.top, (float) frame.right, (float) (frame.top + this.ScreenRate), this.paint);
            canvas.drawRect((float) frame.left, (float) (frame.bottom - 5), (float) (frame.left + this.ScreenRate), (float) frame.bottom, this.paint);
            canvas.drawRect((float) frame.left, (float) (frame.bottom - this.ScreenRate), (float) (frame.left + 5), (float) frame.bottom, this.paint);
            canvas.drawRect((float) (frame.right - this.ScreenRate), (float) (frame.bottom - 5), (float) frame.right, (float) frame.bottom, this.paint);
            canvas.drawRect((float) (frame.right - 5), (float) (frame.bottom - this.ScreenRate), (float) frame.right, (float) frame.bottom, this.paint);
            this.paint.setColor(this.laserColor);
            this.paint.setAlpha(SCANNER_ALPHA[this.scannerAlpha]);
            this.scannerAlpha = (this.scannerAlpha + 1) % SCANNER_ALPHA.length;
            int middle = this.yDelta + frame.top;
            canvas.drawRect((float) frame.left, (float) (middle - 1), (float) (frame.right - 2), (float) (middle + 1), this.paint);
            this.yDelta += 6;
            if (this.yDelta >= frame.height() - 6) {
                this.yDelta = 0;
            }
            this.paint.setColor(-1);
            this.paint.setTextSize(15.0f * density);
            this.paint.setAlpha(Defines.NV_IPC_TIME_GET_RESPONSE);
            this.paint.setTypeface(Typeface.create("System", 1));
            float leftX1 = (((float) width) - this.paint.measureText(getResources().getString(C0470R.string.str_qr_code1))) / 2.0f;
            Rect strRect = new Rect();
            this.paint.getTextBounds(getResources().getString(C0470R.string.str_qr_code1), 0, 1, strRect);
            float height1 = (float) strRect.height();
            float leftX2 = (((float) width) - this.paint.measureText(getResources().getString(C0470R.string.str_qr_code2))) / 2.0f;
            canvas.drawText(getResources().getString(C0470R.string.str_qr_code1), leftX1, ((float) frame.bottom) + (40.0f * density), this.paint);
            canvas.drawText(getResources().getString(C0470R.string.str_qr_code2), leftX2, ((((float) frame.bottom) + (40.0f * density)) + height1) + 10.0f, this.paint);
            Collection<ResultPoint> currentPossible = this.possibleResultPoints;
            Collection<ResultPoint> currentLast = this.lastPossibleResultPoints;
            if (currentPossible.isEmpty()) {
                this.lastPossibleResultPoints = null;
            } else {
                this.possibleResultPoints = new HashSet(5);
                this.lastPossibleResultPoints = currentPossible;
                this.paint.setAlpha(255);
                this.paint.setColor(this.resultPointColor);
                for (ResultPoint point : currentPossible) {
                    canvas.drawCircle(((float) frame.left) + point.getX(), ((float) frame.top) + point.getY(), 6.0f, this.paint);
                }
            }
            if (currentLast != null) {
                this.paint.setAlpha(127);
                this.paint.setColor(this.resultPointColor);
                for (ResultPoint point2 : currentLast) {
                    canvas.drawCircle(((float) frame.left) + point2.getX(), ((float) frame.top) + point2.getY(), 3.0f, this.paint);
                }
            }
            postInvalidateDelayed(ANIMATION_DELAY, frame.left, frame.top, frame.right, frame.bottom);
        }
    }

    public void drawViewfinder() {
        this.resultBitmap = null;
        invalidate();
    }

    public void drawResultBitmap(Bitmap barcode) {
        this.resultBitmap = barcode;
        invalidate();
    }

    public void addPossibleResultPoint(ResultPoint point) {
        this.possibleResultPoints.add(point);
    }
}
