package com.macrovideo.lock;

public class Constants {
    public static final int POINT_STATE_NORMAL = 0;
    public static final int POINT_STATE_SELECTED = 1;
    public static final int POINT_STATE_WRONG = 2;
}
