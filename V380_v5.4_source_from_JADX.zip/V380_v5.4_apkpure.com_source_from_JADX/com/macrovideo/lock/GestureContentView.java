package com.macrovideo.lock;

import android.content.Context;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import com.macrovideo.lock.GestureDrawline.GestureCallBack;
import com.macrovideo.v380.C0470R;
import java.util.ArrayList;
import java.util.List;

public class GestureContentView extends ViewGroup {
    private int baseNum = 6;
    private int blockWidth;
    private Context context;
    private GestureDrawline gestureDrawline;
    private boolean isVerify;
    private List<GesturePoint> list;
    private int[] screenDispaly;

    public GestureContentView(Context context, boolean isVerify, String passWord, GestureCallBack callBack) {
        super(context);
        this.screenDispaly = AppUtil.getScreenDispaly(context);
        this.blockWidth = this.screenDispaly[0] / 3;
        this.list = new ArrayList();
        this.context = context;
        this.isVerify = isVerify;
        addChild();
        this.gestureDrawline = new GestureDrawline(context, this.list, isVerify, passWord, callBack);
    }

    private void addChild() {
        for (int i = 0; i < 9; i++) {
            ImageView image = new ImageView(this.context);
            image.setBackgroundResource(C0470R.drawable.password_1);
            addView(image);
            invalidate();
            int row = i / 3;
            int col = i % 3;
            this.list.add(new GesturePoint((this.blockWidth * col) + (this.blockWidth / this.baseNum), ((this.blockWidth * col) + this.blockWidth) - (this.blockWidth / this.baseNum), (this.blockWidth * row) + (this.blockWidth / this.baseNum), ((this.blockWidth * row) + this.blockWidth) - (this.blockWidth / this.baseNum), image, i + 1));
        }
    }

    public void setParentView(ViewGroup parent) {
        int width = this.screenDispaly[0];
        LayoutParams layoutParams = new LayoutParams(width, width);
        setLayoutParams(layoutParams);
        this.gestureDrawline.setLayoutParams(layoutParams);
        parent.addView(this.gestureDrawline);
        parent.addView(this);
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        for (int i = 0; i < getChildCount(); i++) {
            int row = i / 3;
            int col = i % 3;
            getChildAt(i).layout((this.blockWidth * col) + (this.blockWidth / this.baseNum), (this.blockWidth * row) + (this.blockWidth / this.baseNum), ((this.blockWidth * col) + this.blockWidth) - (this.blockWidth / this.baseNum), ((this.blockWidth * row) + this.blockWidth) - (this.blockWidth / this.baseNum));
        }
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        for (int i = 0; i < getChildCount(); i++) {
            getChildAt(i).measure(widthMeasureSpec, heightMeasureSpec);
        }
    }

    public void clearDrawlineState(long delayTime) {
        this.gestureDrawline.clearDrawlineState(delayTime);
    }

    public void isPasswordEnable(boolean isEnable) {
        this.gestureDrawline.isPasswordEnable(isEnable);
    }
}
