package com.macrovideo.lock;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.lock.GestureDrawline.GestureCallBack;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.C0470R;
import com.macrovideo.v380.HomePageActivity;
import com.macrovideo.v380.LocalDefines;
import com.tencent.android.tpush.common.Constants;
import java.util.Date;

public class GestureVerifyActivity extends Activity implements OnClickListener {
    public static final String PARAM_INTENT_CODE = "PARAM_INTENT_CODE";
    public static final String PARAM_PHONE_NUMBER = "PARAM_PHONE_NUMBER";
    private static String PASSWORD_ERROR_TIME = "PASSWORD_ERROR_TIME";
    private static String STR_NUM = "STR_NUM";
    private ImageView btnLoginPasswordBack;
    private Date date;
    private Editor editor = null;
    private int mCount = 60;
    private long mExitTime = 0;
    private FrameLayout mGestureContainer;
    private GestureContentView mGestureContentView;
    private Handler mHandler;
    private ImageView mImgUserLogo;
    private int mParamIntentCode;
    private String mParamPhoneNumber;
    private Runnable mTask;
    private TextView mTextCancel;
    private TextView mTextForget;
    private TextView mTextOther;
    private TextView mTextPhoneNumber;
    private TextView mTextTip;
    private TextView mTextTitle;
    private RelativeLayout mTopLayout;
    private int nNum = 5;
    private SharedPreferences preferences = null;
    private RelativeLayout rlPassword;

    class C02191 implements Runnable {

        class C02181 implements Runnable {
            C02181() {
            }

            public void run() {
                GestureVerifyActivity.this.mTextTip.setText(Html.fromHtml("<font color='#c70c1e'>" + GestureVerifyActivity.this.getString(C0470R.string.inputPasswordErrorMore) + "(" + GestureVerifyActivity.this.mCount + "s)" + "</font>"));
            }
        }

        C02191() {
        }

        public void run() {
            if (GestureVerifyActivity.this.mCount <= 0) {
                GestureVerifyActivity.this.mTextTip.setVisibility(4);
                GestureVerifyActivity.this.mGestureContentView.isPasswordEnable(false);
                GestureVerifyActivity.this.mCount = 60;
                GestureVerifyActivity.this.mTextTip.setVisibility(4);
                GestureVerifyActivity.this.editor.putInt(GestureVerifyActivity.STR_NUM, 5);
                GestureVerifyActivity.this.editor.putLong(GestureVerifyActivity.PASSWORD_ERROR_TIME, 0);
                GestureVerifyActivity.this.editor.commit();
                GestureVerifyActivity.this.nNum = 5;
                return;
            }
            GestureVerifyActivity gestureVerifyActivity = GestureVerifyActivity.this;
            gestureVerifyActivity.mCount = gestureVerifyActivity.mCount - 1;
            GestureVerifyActivity.this.runOnUiThread(new C02181());
            GestureVerifyActivity.this.mHandler.postDelayed(GestureVerifyActivity.this.mTask, 1000);
        }
    }

    class C08312 implements GestureCallBack {
        C08312() {
        }

        public void onGestureCodeInput(String inputCode) {
        }

        public void checkedSuccess() {
            GestureVerifyActivity.this.mGestureContentView.clearDrawlineState(0);
            GestureVerifyActivity.this.editor.putInt(GestureVerifyActivity.STR_NUM, 5);
            GestureVerifyActivity.this.editor.putLong(GestureVerifyActivity.PASSWORD_ERROR_TIME, 0);
            GestureVerifyActivity.this.editor.commit();
            if (LocalDefines.B_OFF_PASSWORD) {
                if (LocalDefines.SOFTWARE_PASSWORD_OPEN) {
                    GestureVerifyActivity.this.editor.putBoolean(LocalDefines.SOFTWARE_PASSWORD_STATE, true);
                    GestureVerifyActivity.this.editor.commit();
                    GestureVerifyActivity.this.ToastHint(GestureVerifyActivity.this.getString(C0470R.string.passwrodOn));
                } else {
                    GestureVerifyActivity.this.editor.putBoolean(LocalDefines.SOFTWARE_PASSWORD_STATE, false);
                    GestureVerifyActivity.this.editor.commit();
                    GestureVerifyActivity.this.ToastHint(GestureVerifyActivity.this.getString(C0470R.string.passwrodOff));
                }
                GestureVerifyActivity.this.startActivity(new Intent(GestureVerifyActivity.this, SoftwarePasswordActivity.class));
                LocalDefines.B_OFF_PASSWORD = false;
            } else if (LocalDefines.B_ALTER_PASSWORD) {
                GestureVerifyActivity.this.startActivity(new Intent(GestureVerifyActivity.this, GestureEditActivity.class));
                LocalDefines.B_ALTER_PASSWORD = false;
            } else if (LocalDefines.B_DELETE_PASSWORD) {
                GestureVerifyActivity.this.ToastHint(GestureVerifyActivity.this.getString(C0470R.string.passwrodDeleteSucceed));
                GestureVerifyActivity.this.editor.putString(GestureEditActivity.PARAM_LOCK_PASSWORD_KEY, null);
                GestureVerifyActivity.this.editor.commit();
                GestureVerifyActivity.this.startActivity(new Intent(GestureVerifyActivity.this, SoftwarePasswordActivity.class));
                LocalDefines.B_DELETE_PASSWORD = false;
            } else if (LocalDefines.B_INTENT_ACTIVITY) {
                SharedPreferences shareAppMode = GestureVerifyActivity.this.getSharedPreferences("ShareAPPMODE", 0);
                GestureVerifyActivity.this.startActivity(new Intent(GestureVerifyActivity.this, HomePageActivity.class));
            } else {
                GestureVerifyActivity.this.startActivity(new Intent(GestureVerifyActivity.this, HomePageActivity.class));
            }
            GestureVerifyActivity.this.finish();
        }

        public void checkedFail() {
            GestureVerifyActivity gestureVerifyActivity = GestureVerifyActivity.this;
            gestureVerifyActivity.nNum = gestureVerifyActivity.nNum - 1;
            GestureVerifyActivity.this.mGestureContentView.clearDrawlineState(1300);
            GestureVerifyActivity.this.mTextTip.setVisibility(0);
            GestureVerifyActivity.this.mTextTip.setText(Html.fromHtml("<font color='#c70c1e'>" + GestureVerifyActivity.this.getString(C0470R.string.inputPasswordError) + GestureVerifyActivity.this.nNum + GestureVerifyActivity.this.getString(C0470R.string.passwordOrder) + "</font>"));
            GestureVerifyActivity.this.mTextTip.startAnimation(AnimationUtils.loadAnimation(GestureVerifyActivity.this, C0470R.anim.shake));
            GestureVerifyActivity.this.editor.putInt(GestureVerifyActivity.STR_NUM, GestureVerifyActivity.this.nNum);
            GestureVerifyActivity.this.editor.commit();
            if (GestureVerifyActivity.this.nNum < 1) {
                GestureVerifyActivity.this.mTextTip.setVisibility(0);
                GestureVerifyActivity.this.mGestureContentView.isPasswordEnable(true);
                GestureVerifyActivity.this.date = new Date();
                GestureVerifyActivity.this.editor.putLong(GestureVerifyActivity.PASSWORD_ERROR_TIME, GestureVerifyActivity.this.date.getTime());
                GestureVerifyActivity.this.editor.commit();
                GestureVerifyActivity.this.mHandler.postDelayed(GestureVerifyActivity.this.mTask, 1000);
            }
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_gesture_verify);
        this.preferences = getSharedPreferences(GestureEditActivity.PARAM_LOCK_PASSWORD, 0);
        this.editor = this.preferences.edit();
        this.rlPassword = (RelativeLayout) findViewById(C0470R.id.rlPassword);
        this.rlPassword.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.bg_login)));
        this.mHandler = new Handler();
        this.mTask = new C02191();
        ObtainExtraData();
        setUpViews();
        setUpListeners();
        if (LocalDefines.B_OFF_PASSWORD) {
            this.mTopLayout.setVisibility(0);
            if (LocalDefines.SOFTWARE_PASSWORD_OPEN) {
                this.mTextTitle.setText(getString(C0470R.string.OnPassword));
            } else {
                this.mTextTitle.setText(getString(C0470R.string.OffPassword));
            }
        } else if (LocalDefines.B_ALTER_PASSWORD) {
            this.mTopLayout.setVisibility(0);
            this.mTextTitle.setText(getString(C0470R.string.alterPassword));
        } else if (LocalDefines.B_DELETE_PASSWORD) {
            this.mTopLayout.setVisibility(0);
            this.mTextTitle.setText(getString(C0470R.string.deleteSoftwarePassword));
        } else {
            this.mTopLayout.setVisibility(8);
        }
    }

    protected void onStart() {
        super.onStart();
        int nErrorNum = this.preferences.getInt(STR_NUM, 9);
        this.nNum = nErrorNum;
        if (nErrorNum != 9) {
            if (nErrorNum == 0) {
                this.mGestureContentView.isPasswordEnable(true);
                this.mTextTip.setVisibility(0);
            } else if (nErrorNum > 0 && nErrorNum < 5) {
                this.mGestureContentView.isPasswordEnable(false);
                this.mTextTip.setVisibility(0);
                this.mTextTip.setText(Html.fromHtml("<font color='#c70c1e'>" + getString(C0470R.string.inputPasswordError) + nErrorNum + getString(C0470R.string.passwordOrder) + "</font>"));
                this.nNum = nErrorNum;
            } else if (nErrorNum == 5) {
                this.mTextTip.setVisibility(4);
            }
        }
        long lErrorTime = this.preferences.getLong(PASSWORD_ERROR_TIME, 0);
        if (lErrorTime > 0) {
            this.date = new Date();
            long lResultTime = this.date.getTime() - lErrorTime;
            if (lResultTime > 60000) {
                this.mGestureContentView.isPasswordEnable(false);
                this.mCount = 60;
                this.mTextTip.setVisibility(4);
                this.editor.putInt(STR_NUM, 5);
                this.editor.putLong(PASSWORD_ERROR_TIME, 0);
                this.editor.commit();
                this.nNum = 5;
                return;
            }
            this.mHandler.removeCallbacks(this.mTask);
            this.mCount = 60 - ((int) ((((double) lResultTime) * 1.0d) / 1000.0d));
            if (this.mCount > 0) {
                this.mHandler.postDelayed(this.mTask, 1000);
            }
        }
    }

    private void ObtainExtraData() {
        this.mParamPhoneNumber = getIntent().getStringExtra("PARAM_PHONE_NUMBER");
        this.mParamIntentCode = getIntent().getIntExtra("PARAM_INTENT_CODE", 0);
    }

    private void setUpViews() {
        this.btnLoginPasswordBack = (ImageView) findViewById(C0470R.id.btnLoginPasswordBack);
        this.btnLoginPasswordBack.setOnClickListener(this);
        this.mTopLayout = (RelativeLayout) findViewById(C0470R.id.top_layout);
        this.mTextTitle = (TextView) findViewById(C0470R.id.text_title);
        this.mTextCancel = (TextView) findViewById(C0470R.id.text_cancel);
        this.mImgUserLogo = (ImageView) findViewById(C0470R.id.user_logo);
        this.mTextPhoneNumber = (TextView) findViewById(C0470R.id.text_phone_number);
        this.mTextTip = (TextView) findViewById(C0470R.id.text_tip);
        this.mGestureContainer = (FrameLayout) findViewById(C0470R.id.gesture_container);
        this.mTextForget = (TextView) findViewById(C0470R.id.text_forget_gesture);
        this.mTextOther = (TextView) findViewById(C0470R.id.text_other_account);
        this.mGestureContentView = new GestureContentView(this, true, this.preferences.getString(GestureEditActivity.PARAM_LOCK_PASSWORD_KEY, null), new C08312());
        this.mGestureContentView.setParentView(this.mGestureContainer);
    }

    private void setUpListeners() {
        this.mTextCancel.setOnClickListener(this);
        this.mTextForget.setOnClickListener(this);
        this.mTextOther.setOnClickListener(this);
    }

    private String getProtectedMobile(String phoneNumber) {
        if (TextUtils.isEmpty(phoneNumber) || phoneNumber.length() < 11) {
            return Constants.MAIN_VERSION_TAG;
        }
        StringBuilder builder = new StringBuilder();
        builder.append(phoneNumber.subSequence(0, 3));
        builder.append("****");
        builder.append(phoneNumber.subSequence(7, 11));
        return builder.toString();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.text_cancel:
                finish();
                return;
            case C0470R.id.btnLoginPasswordBack:
                startActivity(new Intent(this, SoftwarePasswordActivity.class));
                finish();
                return;
            default:
                return;
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (!LocalDefines.B_INTENT_ACTIVITY && (LocalDefines.B_DELETE_PASSWORD || LocalDefines.B_ALTER_PASSWORD || LocalDefines.B_CREATE_PASSWORD)) {
                startActivity(new Intent(this, SoftwarePasswordActivity.class));
            }
            finish();
        }
        return false;
    }

    public void ToastHint(String message) {
        Toast.makeText(this, message, 0).show();
    }

    protected void onDestroy() {
        BitmapDrawable rlPasswords = (BitmapDrawable) this.rlPassword.getBackground();
        this.rlPassword.setBackgroundResource(0);
        rlPasswords.setCallback(null);
        if (rlPasswords.getBitmap() != null) {
            rlPasswords.getBitmap().recycle();
        }
        if (this.mTask != null) {
            this.mHandler.removeCallbacks(this.mTask);
        }
        super.onDestroy();
    }
}
