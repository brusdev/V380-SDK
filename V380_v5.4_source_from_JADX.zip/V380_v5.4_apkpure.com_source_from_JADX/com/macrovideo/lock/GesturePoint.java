package com.macrovideo.lock;

import android.widget.ImageView;
import com.macrovideo.v380.C0470R;

public class GesturePoint {
    private int bottomY;
    private int centerX;
    private int centerY;
    private ImageView image;
    private int leftX;
    private int num;
    private int pointState;
    private int rightX;
    private int topY;

    public GesturePoint(int leftX, int rightX, int topY, int bottomY, ImageView image, int num) {
        this.leftX = leftX;
        this.rightX = rightX;
        this.topY = topY;
        this.bottomY = bottomY;
        this.image = image;
        this.centerX = (leftX + rightX) / 2;
        this.centerY = (topY + bottomY) / 2;
        this.num = num;
    }

    public int getLeftX() {
        return this.leftX;
    }

    public void setLeftX(int leftX) {
        this.leftX = leftX;
    }

    public int getRightX() {
        return this.rightX;
    }

    public void setRightX(int rightX) {
        this.rightX = rightX;
    }

    public int getTopY() {
        return this.topY;
    }

    public void setTopY(int topY) {
        this.topY = topY;
    }

    public int getBottomY() {
        return this.bottomY;
    }

    public void setBottomY(int bottomY) {
        this.bottomY = bottomY;
    }

    public ImageView getImage() {
        return this.image;
    }

    public void setImage(ImageView image) {
        this.image = image;
    }

    public int getCenterX() {
        return this.centerX;
    }

    public void setCenterX(int centerX) {
        this.centerX = centerX;
    }

    public int getCenterY() {
        return this.centerY;
    }

    public void setCenterY(int centerY) {
        this.centerY = centerY;
    }

    public int getPointState() {
        return this.pointState;
    }

    public void setPointState(int state) {
        this.pointState = state;
        switch (state) {
            case 0:
                this.image.setBackgroundResource(C0470R.drawable.password_1);
                return;
            case 1:
                this.image.setBackgroundResource(C0470R.drawable.password_2);
                return;
            case 2:
                this.image.setBackgroundResource(C0470R.drawable.password_3);
                return;
            default:
                return;
        }
    }

    public int getNum() {
        return this.num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int hashCode() {
        return ((((((((this.bottomY + 31) * 31) + (this.image == null ? 0 : this.image.hashCode())) * 31) + this.leftX) * 31) + this.rightX) * 31) + this.topY;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        GesturePoint other = (GesturePoint) obj;
        if (this.bottomY != other.bottomY) {
            return false;
        }
        if (this.image == null) {
            if (other.image != null) {
                return false;
            }
        } else if (!this.image.equals(other.image)) {
            return false;
        }
        if (this.leftX != other.leftX) {
            return false;
        }
        if (this.rightX != other.rightX) {
            return false;
        }
        if (this.topY != other.topY) {
            return false;
        }
        return true;
    }

    public String toString() {
        return "Point [leftX=" + this.leftX + ", rightX=" + this.rightX + ", topY=" + this.topY + ", bottomY=" + this.bottomY + "]";
    }
}
