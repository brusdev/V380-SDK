package com.macrovideo.lock;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.drawable.Drawable;
import android.support.v4.view.ViewCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import com.macrovideo.v380.C0470R;

public class LockIndicator extends View {
    private int f15f;
    private int f16g;
    private String lockPassStr;
    private int numColum;
    private int numRow;
    private Paint paint;
    private int patternHeight;
    private Drawable patternNoraml;
    private Drawable patternPressed;
    private int patternWidth;
    private int strokeWidth;

    public LockIndicator(Context paramContext) {
        super(paramContext);
        this.numRow = 3;
        this.numColum = 3;
        this.patternWidth = 40;
        this.patternHeight = 40;
        this.f15f = 5;
        this.f16g = 5;
        this.strokeWidth = 3;
        this.paint = null;
        this.patternNoraml = null;
        this.patternPressed = null;
    }

    public LockIndicator(Context paramContext, AttributeSet paramAttributeSet) {
        super(paramContext, paramAttributeSet, 0);
        this.numRow = 3;
        this.numColum = 3;
        this.patternWidth = 40;
        this.patternHeight = 40;
        this.f15f = 5;
        this.f16g = 5;
        this.strokeWidth = 3;
        this.paint = null;
        this.patternNoraml = null;
        this.patternPressed = null;
        this.paint = new Paint();
        this.paint.setAntiAlias(true);
        this.paint.setStrokeWidth((float) this.strokeWidth);
        this.paint.setStyle(Style.STROKE);
        this.patternNoraml = getResources().getDrawable(C0470R.drawable.baise);
        this.patternPressed = getResources().getDrawable(C0470R.drawable.lanse);
        if (this.patternPressed != null) {
            this.patternWidth = this.patternPressed.getIntrinsicWidth();
            this.patternHeight = this.patternPressed.getIntrinsicHeight();
            this.f15f = this.patternWidth / 4;
            this.f16g = this.patternHeight / 4;
            this.patternPressed.setBounds(0, 0, this.patternWidth, this.patternHeight);
            this.patternNoraml.setBounds(0, 0, this.patternWidth, this.patternHeight);
        }
    }

    protected void onDraw(Canvas canvas) {
        if (this.patternPressed != null && this.patternNoraml != null) {
            for (int i = 0; i < this.numRow; i++) {
                for (int j = 0; j < this.numColum; j++) {
                    this.paint.setColor(ViewCompat.MEASURED_STATE_MASK);
                    int i1 = (this.patternHeight * j) + (this.f16g * j);
                    int i2 = (this.patternWidth * i) + (this.f15f * i);
                    canvas.save();
                    canvas.translate((float) i1, (float) i2);
                    String curNum = String.valueOf((this.numColum * i) + (j + 1));
                    if (TextUtils.isEmpty(this.lockPassStr)) {
                        this.patternNoraml.draw(canvas);
                    } else if (this.lockPassStr.indexOf(curNum) == -1) {
                        this.patternNoraml.draw(canvas);
                    } else {
                        this.patternPressed.draw(canvas);
                    }
                    canvas.restore();
                }
            }
        }
    }

    protected void onMeasure(int paramInt1, int paramInt2) {
        if (this.patternPressed != null) {
            setMeasuredDimension((this.numColum * this.patternHeight) + (this.f16g * (this.numColum - 1)), (this.numRow * this.patternWidth) + (this.f15f * (this.numRow - 1)));
        }
    }

    public void setPath(String paramString) {
        this.lockPassStr = paramString;
        invalidate();
    }
}
