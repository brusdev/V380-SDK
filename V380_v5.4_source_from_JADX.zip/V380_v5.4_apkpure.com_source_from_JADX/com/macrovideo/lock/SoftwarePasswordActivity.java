package com.macrovideo.lock;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.macrovideo.pull.lib.CheckSwitchButton;
import com.macrovideo.v380.C0470R;
import com.macrovideo.v380.LocalDefines;

public class SoftwarePasswordActivity extends Activity implements OnClickListener {
    private static final String TAG = "MainActivity";
    private boolean bIntent = false;
    private boolean bOpenPassword = false;
    private CheckSwitchButton btnSoftwarePassword;
    private Editor editor = null;
    private ImageView ivSoftwarePassword;
    private LinearLayout llDivider;
    private LinearLayout llFoundAndDeletePassword;
    private LinearLayout llPassword;
    private SharedPreferences preferences;
    private TextView tvFoundAndDeletePassword;

    class C02201 implements OnCheckedChangeListener {
        C02201() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isCheck) {
            if (isCheck) {
                if (!SoftwarePasswordActivity.this.bOpenPassword || SoftwarePasswordActivity.this.bIntent) {
                    SoftwarePasswordActivity.this.editor.putBoolean(LocalDefines.SOFTWARE_PASSWORD_STATE, true);
                    SoftwarePasswordActivity.this.editor.commit();
                } else {
                    SoftwarePasswordActivity.this.startActivity(new Intent(SoftwarePasswordActivity.this, GestureVerifyActivity.class));
                    LocalDefines.B_OFF_PASSWORD = true;
                    LocalDefines.B_ALTER_PASSWORD = false;
                    LocalDefines.B_TESTING_PASSWORD = false;
                    LocalDefines.SOFTWARE_PASSWORD_OPEN = true;
                    SoftwarePasswordActivity.this.finish();
                }
                SoftwarePasswordActivity.this.bIntent = false;
                return;
            }
            if (!SoftwarePasswordActivity.this.bOpenPassword || SoftwarePasswordActivity.this.bIntent) {
                SoftwarePasswordActivity.this.editor.putBoolean(LocalDefines.SOFTWARE_PASSWORD_STATE, true);
                SoftwarePasswordActivity.this.editor.commit();
            } else {
                SoftwarePasswordActivity.this.startActivity(new Intent(SoftwarePasswordActivity.this, GestureVerifyActivity.class));
                LocalDefines.B_OFF_PASSWORD = true;
                LocalDefines.B_ALTER_PASSWORD = false;
                LocalDefines.SOFTWARE_PASSWORD_OPEN = false;
                SoftwarePasswordActivity.this.finish();
            }
            SoftwarePasswordActivity.this.bIntent = false;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_nvplayer_software_password);
        initView();
        this.preferences = getSharedPreferences(GestureEditActivity.PARAM_LOCK_PASSWORD, 0);
        this.editor = this.preferences.edit();
        String lockPattenString = this.preferences.getString(GestureEditActivity.PARAM_LOCK_PASSWORD_KEY, null);
        boolean bIsPasswordOpen = this.preferences.getBoolean(LocalDefines.SOFTWARE_PASSWORD_STATE, false);
        this.bIntent = true;
        if (lockPattenString != null) {
            this.bOpenPassword = true;
            this.llPassword.setVisibility(0);
            this.llDivider.setVisibility(0);
            this.tvFoundAndDeletePassword.setText(getString(C0470R.string.deleteSoftwarePassword));
        } else {
            this.bOpenPassword = false;
            this.tvFoundAndDeletePassword.setText(getString(C0470R.string.foundSoftwarePassword));
            this.llPassword.setVisibility(8);
            this.llDivider.setVisibility(8);
        }
        if (bIsPasswordOpen) {
            this.btnSoftwarePassword.setChecked(true);
            this.bIntent = false;
            return;
        }
        this.btnSoftwarePassword.setChecked(false);
        this.bIntent = false;
    }

    public void initView() {
        this.btnSoftwarePassword = (CheckSwitchButton) findViewById(C0470R.id.btnSoftwarePassword);
        this.btnSoftwarePassword.setOnCheckedChangeListener(new C02201());
        this.llPassword = (LinearLayout) findViewById(C0470R.id.llAlterPassoword);
        this.llPassword.setOnClickListener(this);
        this.ivSoftwarePassword = (ImageView) findViewById(C0470R.id.ivSoftwarePassword);
        this.ivSoftwarePassword.setOnClickListener(this);
        this.llFoundAndDeletePassword = (LinearLayout) findViewById(C0470R.id.llFoundAndDeletePassword);
        this.llFoundAndDeletePassword.setOnClickListener(this);
        this.tvFoundAndDeletePassword = (TextView) findViewById(C0470R.id.tvFoundAndDeletePassword);
        this.llDivider = (LinearLayout) findViewById(C0470R.id.id_divider);
    }

    protected void onResume() {
        super.onResume();
        boolean bIsPasswordOpen = this.preferences.getBoolean(LocalDefines.SOFTWARE_PASSWORD_STATE, false);
        if (this.preferences.getString(GestureEditActivity.PARAM_LOCK_PASSWORD_KEY, null) != null) {
            this.bOpenPassword = true;
            this.llPassword.setVisibility(0);
            this.llDivider.setVisibility(0);
            this.tvFoundAndDeletePassword.setText(getString(C0470R.string.deleteSoftwarePassword));
        } else {
            this.bOpenPassword = false;
            this.llPassword.setVisibility(8);
            this.llDivider.setVisibility(8);
            this.tvFoundAndDeletePassword.setText(getString(C0470R.string.foundSoftwarePassword));
        }
        if (bIsPasswordOpen) {
            this.btnSoftwarePassword.setChecked(true);
            this.bIntent = false;
            return;
        }
        this.btnSoftwarePassword.setChecked(false);
        this.bIntent = false;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.ivSoftwarePassword:
                finish();
                return;
            case C0470R.id.llFoundAndDeletePassword:
                if (this.bOpenPassword) {
                    startActivity(new Intent(this, GestureVerifyActivity.class));
                    this.bOpenPassword = false;
                    LocalDefines.B_OFF_PASSWORD = false;
                    LocalDefines.B_DELETE_PASSWORD = true;
                    LocalDefines.B_ALTER_PASSWORD = false;
                    LocalDefines.B_TESTING_PASSWORD = false;
                    finish();
                    return;
                }
                startActivity(new Intent(this, GestureEditActivity.class));
                LocalDefines.B_CREATE_PASSWORD = true;
                finish();
                return;
            case C0470R.id.llAlterPassoword:
                if (this.bOpenPassword) {
                    startActivity(new Intent(this, GestureVerifyActivity.class));
                    LocalDefines.B_ALTER_PASSWORD = true;
                    LocalDefines.B_OFF_PASSWORD = false;
                    LocalDefines.B_TESTING_PASSWORD = false;
                    finish();
                    return;
                }
                return;
            default:
                return;
        }
    }
}
