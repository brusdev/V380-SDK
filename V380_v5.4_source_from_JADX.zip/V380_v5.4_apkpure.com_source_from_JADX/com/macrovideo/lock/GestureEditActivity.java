package com.macrovideo.lock;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.lock.GestureDrawline.GestureCallBack;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.C0470R;
import com.tencent.android.tpush.common.Constants;

public class GestureEditActivity extends Activity implements OnClickListener {
    public static final String PARAM_INTENT_CODE = "PARAM_INTENT_CODE";
    public static final String PARAM_IS_FIRST_ADVICE = "PARAM_IS_FIRST_ADVICE";
    public static final String PARAM_LOCK_PASSWORD = "PARAM_LOCK_PASSWORD";
    public static final String PARAM_LOCK_PASSWORD_KEY = "PARAM_LOCK_PASSWORD_KEY";
    public static final String PARAM_PHONE_NUMBER = "PARAM_PHONE_NUMBER";
    private ImageView btnCreatePasswordBack;
    private Editor editor = null;
    private String mFirstPassword = null;
    private FrameLayout mGestureContainer;
    private GestureContentView mGestureContentView;
    private boolean mIsFirstInput = true;
    private LockIndicator mLockIndicator;
    private TextView mTextCancel;
    private TextView mTextReset;
    private TextView mTextTip;
    private SharedPreferences preferences = null;
    private RelativeLayout rlSoftwarePassword;

    class C08301 implements GestureCallBack {
        C08301() {
        }

        public void onGestureCodeInput(String inputCode) {
            if (GestureEditActivity.this.isInputPassValidate(inputCode)) {
                if (GestureEditActivity.this.mIsFirstInput) {
                    GestureEditActivity.this.mFirstPassword = inputCode;
                    GestureEditActivity.this.updateCodeList(inputCode);
                    GestureEditActivity.this.mGestureContentView.clearDrawlineState(0);
                    GestureEditActivity.this.mTextReset.setClickable(true);
                    GestureEditActivity.this.mTextReset.setText(GestureEditActivity.this.getString(C0470R.string.resetInputPassword));
                    GestureEditActivity.this.mTextTip.setText(GestureEditActivity.this.getString(C0470R.string.affirmPassern));
                } else if (inputCode.equals(GestureEditActivity.this.mFirstPassword)) {
                    Toast.makeText(GestureEditActivity.this, GestureEditActivity.this.getString(C0470R.string.setPasswordSucceed), 0).show();
                    GestureEditActivity.this.mGestureContentView.clearDrawlineState(0);
                    GestureEditActivity.this.editor.putString(GestureEditActivity.PARAM_LOCK_PASSWORD_KEY, GestureEditActivity.this.mFirstPassword);
                    GestureEditActivity.this.editor.commit();
                    GestureEditActivity.this.startActivity(new Intent(GestureEditActivity.this, SoftwarePasswordActivity.class));
                    GestureEditActivity.this.finish();
                } else {
                    GestureEditActivity.this.mTextTip.setText(Html.fromHtml("<font color='#c70c1e'>" + GestureEditActivity.this.getString(C0470R.string.setPasswordLastDifferent) + "</font>"));
                    GestureEditActivity.this.mTextTip.startAnimation(AnimationUtils.loadAnimation(GestureEditActivity.this, C0470R.anim.shake));
                    GestureEditActivity.this.mGestureContentView.clearDrawlineState(1300);
                }
                GestureEditActivity.this.mIsFirstInput = false;
                return;
            }
            GestureEditActivity.this.mTextTip.setText(Html.fromHtml("<font color='#c70c1e'>" + GestureEditActivity.this.getString(C0470R.string.leastInputPoint) + "</font>"));
            GestureEditActivity.this.mGestureContentView.clearDrawlineState(0);
        }

        public void checkedSuccess() {
        }

        public void checkedFail() {
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_gesture_edit);
        setUpViews();
        this.preferences = getSharedPreferences(PARAM_LOCK_PASSWORD, 0);
        this.editor = this.preferences.edit();
        this.rlSoftwarePassword = (RelativeLayout) findViewById(C0470R.id.rlSoftwarePassword);
        this.rlSoftwarePassword.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.bg_login)));
    }

    private void setUpViews() {
        this.btnCreatePasswordBack = (ImageView) findViewById(C0470R.id.btnCreatePasswordBack);
        this.btnCreatePasswordBack.setOnClickListener(this);
        this.mTextCancel = (TextView) findViewById(C0470R.id.text_cancel);
        this.mTextReset = (TextView) findViewById(C0470R.id.text_reset);
        this.mTextCancel.setOnClickListener(this);
        this.mTextReset.setOnClickListener(this);
        this.mTextReset.setClickable(false);
        this.mLockIndicator = (LockIndicator) findViewById(C0470R.id.lock_indicator);
        this.mTextTip = (TextView) findViewById(C0470R.id.text_tip);
        this.mGestureContainer = (FrameLayout) findViewById(C0470R.id.gesture_container);
        this.mGestureContentView = new GestureContentView(this, false, Constants.MAIN_VERSION_TAG, new C08301());
        this.mGestureContentView.setParentView(this.mGestureContainer);
        updateCodeList(Constants.MAIN_VERSION_TAG);
    }

    private void updateCodeList(String inputCode) {
        this.mLockIndicator.setPath(inputCode);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.btnCreatePasswordBack:
                startActivity(new Intent(this, SoftwarePasswordActivity.class));
                finish();
                return;
            case C0470R.id.text_cancel:
                finish();
                return;
            case C0470R.id.text_reset:
                this.mIsFirstInput = true;
                updateCodeList(Constants.MAIN_VERSION_TAG);
                this.mTextTip.setText(getString(C0470R.string.drawDelockingPattern));
                this.mTextReset.setText(getString(C0470R.string.setPasswordPreventSee));
                return;
            default:
                return;
        }
    }

    private boolean isInputPassValidate(String inputPassword) {
        if (TextUtils.isEmpty(inputPassword) || inputPassword.length() < 4) {
            return false;
        }
        return true;
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            startActivity(new Intent(this, SoftwarePasswordActivity.class));
            finish();
        }
        return false;
    }

    protected void onDestroy() {
        BitmapDrawable rlSoftwarePasswords = (BitmapDrawable) this.rlSoftwarePassword.getBackground();
        this.rlSoftwarePassword.setBackgroundResource(0);
        rlSoftwarePasswords.setCallback(null);
        if (rlSoftwarePasswords.getBitmap() != null) {
            rlSoftwarePasswords.getBitmap().recycle();
        }
        super.onDestroy();
    }
}
