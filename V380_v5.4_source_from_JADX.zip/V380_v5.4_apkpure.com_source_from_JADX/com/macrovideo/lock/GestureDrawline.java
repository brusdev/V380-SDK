package com.macrovideo.lock;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff.Mode;
import android.os.Handler;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import com.macrovideo.sdk.defines.Defines;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GestureDrawline extends View {
    private Map<String, GesturePoint> autoCheckPointMap;
    private Bitmap bitmap;
    private GestureCallBack callBack;
    private Canvas canvas;
    private GesturePoint currentPoint;
    private boolean isDrawEnable = true;
    private boolean isLockEnable = false;
    private boolean isVerify;
    private List<Pair<GesturePoint, GesturePoint>> lineList;
    private List<GesturePoint> list;
    private int mov_x;
    private int mov_y;
    private Paint paint;
    private String passWord;
    private StringBuilder passWordSb;
    private int[] screenDispaly;

    public interface GestureCallBack {
        void checkedFail();

        void checkedSuccess();

        void onGestureCodeInput(String str);
    }

    final class clearStateRunnable implements Runnable {
        clearStateRunnable() {
        }

        public void run() {
            GestureDrawline.this.passWordSb = new StringBuilder();
            GestureDrawline.this.lineList.clear();
            GestureDrawline.this.clearScreenAndDrawList();
            for (GesturePoint p : GestureDrawline.this.list) {
                p.setPointState(0);
            }
            GestureDrawline.this.invalidate();
            GestureDrawline.this.isDrawEnable = true;
        }
    }

    public GestureDrawline(Context context, List<GesturePoint> list, boolean isVerify, String passWord, GestureCallBack callBack) {
        super(context);
        this.screenDispaly = AppUtil.getScreenDispaly(context);
        this.paint = new Paint(4);
        this.bitmap = Bitmap.createBitmap(this.screenDispaly[0], this.screenDispaly[0], Config.ARGB_8888);
        this.canvas = new Canvas();
        this.canvas.setBitmap(this.bitmap);
        this.paint.setStyle(Style.STROKE);
        this.paint.setStrokeWidth(10.0f);
        this.paint.setColor(Color.parseColor("#0091e2"));
        this.paint.setAntiAlias(true);
        this.list = list;
        this.lineList = new ArrayList();
        initAutoCheckPointMap();
        this.callBack = callBack;
        this.isVerify = isVerify;
        this.passWordSb = new StringBuilder();
        this.passWord = passWord;
    }

    private void initAutoCheckPointMap() {
        this.autoCheckPointMap = new HashMap();
        this.autoCheckPointMap.put("1,3", getGesturePointByNum(2));
        this.autoCheckPointMap.put("1,7", getGesturePointByNum(4));
        this.autoCheckPointMap.put("1,9", getGesturePointByNum(5));
        this.autoCheckPointMap.put("2,8", getGesturePointByNum(5));
        this.autoCheckPointMap.put("3,7", getGesturePointByNum(5));
        this.autoCheckPointMap.put("3,9", getGesturePointByNum(6));
        this.autoCheckPointMap.put("4,6", getGesturePointByNum(5));
        this.autoCheckPointMap.put("7,9", getGesturePointByNum(8));
    }

    private GesturePoint getGesturePointByNum(int num) {
        for (GesturePoint point : this.list) {
            if (point.getNum() == num) {
                return point;
            }
        }
        return null;
    }

    protected void onDraw(Canvas canvas) {
        canvas.drawBitmap(this.bitmap, 0.0f, 0.0f, null);
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (this.isDrawEnable && !this.isLockEnable) {
            this.paint.setColor(Color.parseColor("#0091e2"));
            switch (event.getAction()) {
                case 0:
                    this.mov_x = (int) event.getX();
                    this.mov_y = (int) event.getY();
                    this.currentPoint = getPointAt(this.mov_x, this.mov_y);
                    if (this.currentPoint != null) {
                        this.currentPoint.setPointState(1);
                        this.passWordSb.append(this.currentPoint.getNum());
                    }
                    invalidate();
                    break;
                case 1:
                    if (this.isVerify) {
                        if (!this.passWord.equals(this.passWordSb.toString())) {
                            this.callBack.checkedFail();
                            break;
                        }
                        this.callBack.checkedSuccess();
                        break;
                    }
                    this.callBack.onGestureCodeInput(this.passWordSb.toString());
                    break;
                case 2:
                    clearScreenAndDrawList();
                    GesturePoint pointAt = getPointAt((int) event.getX(), (int) event.getY());
                    if (!(this.currentPoint == null && pointAt == null)) {
                        if (this.currentPoint == null) {
                            this.currentPoint = pointAt;
                            this.currentPoint.setPointState(1);
                            this.passWordSb.append(this.currentPoint.getNum());
                        }
                        if (pointAt == null || this.currentPoint.equals(pointAt) || 1 == pointAt.getPointState()) {
                            this.canvas.drawLine((float) this.currentPoint.getCenterX(), (float) this.currentPoint.getCenterY(), event.getX(), event.getY(), this.paint);
                        } else {
                            this.canvas.drawLine((float) this.currentPoint.getCenterX(), (float) this.currentPoint.getCenterY(), (float) pointAt.getCenterX(), (float) pointAt.getCenterY(), this.paint);
                            pointAt.setPointState(1);
                            GesturePoint betweenPoint = getBetweenCheckPoint(this.currentPoint, pointAt);
                            if (betweenPoint == null || 1 == betweenPoint.getPointState()) {
                                this.lineList.add(new Pair(this.currentPoint, pointAt));
                                this.passWordSb.append(pointAt.getNum());
                                this.currentPoint = pointAt;
                            } else {
                                this.lineList.add(new Pair(this.currentPoint, betweenPoint));
                                this.passWordSb.append(betweenPoint.getNum());
                                this.lineList.add(new Pair(betweenPoint, pointAt));
                                this.passWordSb.append(pointAt.getNum());
                                betweenPoint.setPointState(1);
                                this.currentPoint = pointAt;
                            }
                        }
                        invalidate();
                        break;
                    }
                    break;
                default:
                    break;
            }
        }
        return true;
    }

    public void clearDrawlineState(long delayTime) {
        if (delayTime > 0) {
            this.isDrawEnable = false;
            drawErrorPathTip();
        }
        new Handler().postDelayed(new clearStateRunnable(), delayTime);
    }

    private GesturePoint getPointAt(int x, int y) {
        for (GesturePoint point : this.list) {
            int leftX = point.getLeftX();
            int rightX = point.getRightX();
            if (x >= leftX && x < rightX) {
                int topY = point.getTopY();
                int bottomY = point.getBottomY();
                if (y < topY) {
                    continue;
                } else if (y < bottomY) {
                    return point;
                }
            }
        }
        return null;
    }

    private GesturePoint getBetweenCheckPoint(GesturePoint pointStart, GesturePoint pointEnd) {
        String key;
        int startNum = pointStart.getNum();
        int endNum = pointEnd.getNum();
        if (startNum < endNum) {
            key = new StringBuilder(String.valueOf(startNum)).append(",").append(endNum).toString();
        } else {
            key = new StringBuilder(String.valueOf(endNum)).append(",").append(startNum).toString();
        }
        return (GesturePoint) this.autoCheckPointMap.get(key);
    }

    private void clearScreenAndDrawList() {
        this.canvas.drawColor(0, Mode.CLEAR);
        for (Pair<GesturePoint, GesturePoint> pair : this.lineList) {
            this.canvas.drawLine((float) ((GesturePoint) pair.first).getCenterX(), (float) ((GesturePoint) pair.first).getCenterY(), (float) ((GesturePoint) pair.second).getCenterX(), (float) ((GesturePoint) pair.second).getCenterY(), this.paint);
        }
    }

    private void drawErrorPathTip() {
        this.canvas.drawColor(0, Mode.CLEAR);
        this.paint.setColor(Color.rgb(Defines.CMD_LOGIN_EX, 7, 21));
        for (Pair<GesturePoint, GesturePoint> pair : this.lineList) {
            ((GesturePoint) pair.first).setPointState(2);
            ((GesturePoint) pair.second).setPointState(2);
            this.canvas.drawLine((float) ((GesturePoint) pair.first).getCenterX(), (float) ((GesturePoint) pair.first).getCenterY(), (float) ((GesturePoint) pair.second).getCenterX(), (float) ((GesturePoint) pair.second).getCenterY(), this.paint);
        }
        invalidate();
    }

    public void isPasswordEnable(boolean isEnable) {
        this.isLockEnable = isEnable;
    }
}
