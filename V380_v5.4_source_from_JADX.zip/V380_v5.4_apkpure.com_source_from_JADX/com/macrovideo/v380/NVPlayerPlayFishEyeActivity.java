package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.OnScaleGestureListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.example.hyfisheyepano.GLFisheyeView;
import com.macrovideo.custom.RoundCornerImageView;
import com.macrovideo.photo.PhotoViewAttacher;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.media.ITimeTextCallback;
import com.macrovideo.sdk.media.LibContext;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrovideo.sdk.media.NVPanoPlayer;
import com.macrovideo.sdk.media.Player;
import com.macrovideo.sdk.objects.PTZXPoint;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.sdk.tools.SpSaveList;
import com.tencent.android.tpush.common.Constants;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressLint({"NewApi"})
public class NVPlayerPlayFishEyeActivity extends Activity implements OnClickListener, OnTouchListener, OnItemClickListener {
    private static int BTN_SCREENSHOT = 10010;
    static final int CMD_ACCEPT = 37124;
    static final int CMD_AFFIRM = 37122;
    static final int CMD_ASKFORCNLNUM = 37128;
    static final int CMD_CHECKPSW = 37129;
    static final int CMD_CONNECTINFO = 37125;
    static final int CMD_EXIT = 37123;
    static final int CMD_REQUEST = 37121;
    static final int CMD_STREAMHEAD = 37126;
    static final int CMD_UDPSHAKE = 37127;
    private static final int MY_PERMISSIONS_REQUEST_MICROPHONE = 2;
    private static final int MY_PERMISSION_REQUEST_STORAGE = 3;
    private static final int PTZX_RESULT_FAIL = 1112;
    private static final int PTZX_RESULT_OK = 1111;
    static final int SEND_BUFFER_DATA_SIZE = 504;
    static final int SEND_BUFFER_HEADER_SIZE = 8;
    static final int SEND_BUFFER_SIZE = 512;
    static final int SESSION_FRAME_BUFFER_SIZE = 65536;
    static final short SHOWCODE_HAS_DATA = (short) 3001;
    static final short SHOWCODE_LOADING = (short) 1001;
    static final short SHOWCODE_NEW_IMAGE = (short) 1002;
    static final short SHOWCODE_STOP = (short) 2001;
    static final short SHOWCODE_VIDEO = (short) 1004;
    static final int SIZE_CMDPACKET = 128;
    static final int SP_DATA = 127;
    static final short STAT_CONNECTING = (short) 2001;
    static final short STAT_DECODE = (short) 2003;
    static final short STAT_DISCONNECT = (short) 2005;
    static final short STAT_LOADING = (short) 2002;
    static final short STAT_MR_BUSY = (short) 2007;
    static final short STAT_MR_DISCONNECT = (short) 2008;
    static final short STAT_RESTART = (short) 2006;
    static final short STAT_STOP = (short) 2004;
    private ArrayList<Integer> ALL_area_alarmlist;
    private int FLING_MAX_DISTANCE = this.FLING_MIN_DISTANCE;
    private int FLING_MIN_DISTANCE = 10;
    private int FLING_MIN_VELOCITY = 80;
    private Map<Integer, Integer> LocalAreaSelectmap;
    private final int PlayerMode0 = 0;
    private final int PlayerMode1 = 4;
    private final int PlayerMode11 = 11;
    private final int PlayerMode12 = 12;
    private final int PlayerMode3 = 3;
    private final int PlayerMode6 = 6;
    private final int PlayerMode7 = 7;
    private LinearLayout RlVertical;
    private ArrayList<Integer> SelectAreaList;
    private ArrayList<String> Viewlist;
    private SelectAreaAdapter adapter;
    private boolean bAnyway = true;
    private boolean bIsDownPressed = false;
    private boolean bIsLeftPressed = false;
    private boolean bIsRightPressed = false;
    private boolean bIsUpPressed = false;
    Bitmap bm = null;
    private Button btnCancelImageView = null;
    private Button btnCanelAllArea;
    private ImageView btnPresetConfig;
    private Button btnSaveAlarmArea = null;
    private Button btnSelectAllArea;
    private Button btn_saveSelectArea = null;
    private int camType;
    LinearLayout container = null;
    private LoginHandle deviceParam = null;
    private float fScaleSize = PhotoViewAttacher.DEFAULT_MIN_SCALE;
    String folderName = "iCamSeeImages";
    private Handler handler = new C03991();
    private View iamgeViewConctentView = null;
    private Dialog iamgeViewDialog = null;
    private Button imgCSMode5;
    private Button imgCSModeInversion;
    private Button imgCSModeOriginal;
    private Button imgCylindric;
    private Button imgMode4;
    private Button imgModeInversionCeil;
    private Button imgModeInversionWall;
    private Button imgModeLongLatUD;
    private Button imgModeViewAngle;
    private Button imgOriginal;
    private Button imgQuad;
    private Button imgWallOriginal;
    private boolean isAllArea = false;
    boolean isCheck = false;
    private boolean isSelectArea = false;
    private long lScaleTime = 0;
    private RelativeLayout layoutBottomBar;
    private LinearLayout layoutCrossScreenMode;
    private LinearLayout layoutTopBar = null;
    private LinearLayout llLandscape;
    private LinearLayout llPlayTalkback;
    private LinearLayout llVertical;
    private LinearLayout ll_alarmArea_explain = null;
    private ListView lvPreset;
    private ImageView mBtnBack;
    private Button mBtnDeviceMode;
    private Button mBtnExpandMode;
    private Button mBtnMic = null;
    private Button mBtnMic2 = null;
    private Button mBtnReverse2 = null;
    private Button mBtnScreenShot = null;
    private Button mBtnScreenShot2 = null;
    private Button mBtnSound;
    private Button mBtnSound2;
    private GestureDetector mGestureDetector = null;
    private GridView mGridView;
    private boolean mIsPlaying = false;
    private boolean mIsReverse = false;
    private boolean mIsSpeaking = false;
    NVPanoPlayer mNVPanoPlayer = null;
    private int mPlayMode = 0;
    private boolean mPlaySound = false;
    private int mPlayingChn = -1;
    private PopupWindow mPopupDeviceMode;
    private PopupWindow mPopupExpandMode;
    private PopupWindow mPopupExpandMode2;
    private boolean mQLHD = true;
    private CloseActivityReceiver mReceiver;
    private ScaleGestureDetector mScaleGestureDetector = null;
    int mScreenHeight = 0;
    int mScreenWidth = 0;
    private int mStreamType = 0;
    TextView mTvDisplayRealTime = null;
    private boolean m_bFinish = false;
    private boolean m_bPTZ = false;
    private boolean m_bPTZX = false;
    private boolean m_bReversePRI = true;
    private boolean m_bSpeak = false;
    private int m_nAddType = 0;
    private int m_nDeviceID = 0;
    private int m_nID = 0;
    private int m_nPTZXCount = 0;
    private int m_nPTZXID = 0;
    private int m_nThreadID = 0;
    private String m_strName = "IPC";
    private String m_strPassword = "1";
    private String m_strUsername = "1";
    private Map<Integer, ArrayList<Integer>> map_Select_area;
    private int nScreenOrientation = 1;
    private int nToolsViewShowTickCount = 8;
    private int panoRad;
    private int panoX;
    private int panoY;
    private PopupWindow popupWindowMore;
    private ProgressBar progressBarPresetConfig;
    private int ptzTimerThreadID = 0;
    private PTZXPiontAdapter ptzxAdapter = null;
    private Dialog screenshotDialog = null;
    private ProgressBar spinner_0 = null;
    private int timerThreadID = 0;
    private TextView tvPlayDeviceID;

    class C03991 extends Handler {
        C03991() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 == NVPlayerPlayFishEyeActivity.BTN_SCREENSHOT) {
                NVPlayerPlayFishEyeActivity.this.mBtnScreenShot.setEnabled(true);
                NVPlayerPlayFishEyeActivity.this.mBtnScreenShot2.setEnabled(true);
            } else if (msg.arg1 == NVPlayerPlayFishEyeActivity.PTZX_RESULT_OK) {
                NVPlayerPlayFishEyeActivity.this.progressBarPresetConfig.setVisibility(8);
                int nPTZXID = msg.arg2;
                if (nPTZXID >= 0 && nPTZXID < 9) {
                    boolean isSetOK = LocalDefines.updatePTZXPoints(NVPlayerPlayFishEyeActivity.this.m_nDeviceID, nPTZXID, NVPlayerPlayFishEyeActivity.this.getPTZXImage());
                }
                Toast.makeText(NVPlayerPlayFishEyeActivity.this, NVPlayerPlayFishEyeActivity.this.getString(C0470R.string.presetOK), 0).show();
                if (NVPlayerPlayFishEyeActivity.this.ptzxAdapter != null) {
                    NVPlayerPlayFishEyeActivity.this.ptzxAdapter.notifyDataSetChanged();
                }
            } else if (msg.arg1 == NVPlayerPlayFishEyeActivity.PTZX_RESULT_FAIL) {
                NVPlayerPlayFishEyeActivity.this.progressBarPresetConfig.setVisibility(8);
                Toast.makeText(NVPlayerPlayFishEyeActivity.this, NVPlayerPlayFishEyeActivity.this.getString(C0470R.string.presetFail), 0).show();
            } else if (msg.arg1 == 4) {
                NVPlayerPlayFishEyeActivity.this.ScreenShot();
            } else if (msg.arg1 != 3) {
                switch (msg.arg2) {
                    case 0:
                        if (msg.arg1 == 1) {
                            Player.ShowProgressBar(0, true);
                            return;
                        } else {
                            Player.ShowProgressBar(0, false);
                            return;
                        }
                    default:
                        return;
                }
            } else if (!NVPlayerPlayFishEyeActivity.this.mIsSpeaking && NVPlayerPlayFishEyeActivity.this.nScreenOrientation == 2) {
                if (NVPlayerPlayFishEyeActivity.this.popupWindowMore == null || !NVPlayerPlayFishEyeActivity.this.popupWindowMore.isShowing()) {
                    NVPlayerPlayFishEyeActivity.this.hideToolsViews();
                } else {
                    NVPlayerPlayFishEyeActivity.this.nToolsViewShowTickCount = 5;
                }
            }
        }
    }

    class C04002 implements OnShowListener {
        C04002() {
        }

        public void onShow(DialogInterface dialog) {
            Message msg = NVPlayerPlayFishEyeActivity.this.handler.obtainMessage();
            msg.arg1 = 4;
            NVPlayerPlayFishEyeActivity.this.handler.sendMessage(msg);
        }
    }

    class C04013 implements OnDismissListener {
        C04013() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class C04024 implements DialogInterface.OnClickListener {
        C04024() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            NVPlayerPlayFishEyeActivity.this.setResult(-1);
        }
    }

    class C04046 implements OnTouchListener {
        C04046() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            float x;
            float y;
            int i;
            switch (event.getAction()) {
                case 0:
                    x = event.getX();
                    y = event.getY();
                    for (i = 0; i < NVPlayerPlayFishEyeActivity.this.SelectAreaList.size(); i++) {
                        ((Integer) NVPlayerPlayFishEyeActivity.this.SelectAreaList.get(i)).intValue();
                    }
                    int item = NVPlayerPlayFishEyeActivity.this.mGridView.pointToPosition((int) x, (int) y);
                    if (item != -1) {
                        if (((Integer) NVPlayerPlayFishEyeActivity.this.SelectAreaList.get(item)).intValue() == 0) {
                            NVPlayerPlayFishEyeActivity.this.isCheck = false;
                            NVPlayerPlayFishEyeActivity.this.SelectAreaList.remove(item);
                            NVPlayerPlayFishEyeActivity.this.SelectAreaList.add(item, Integer.valueOf(1));
                            NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(item).setBackgroundColor(Color.parseColor("#ff0000"));
                            NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(item).getBackground().setAlpha(51);
                        } else {
                            NVPlayerPlayFishEyeActivity.this.isCheck = true;
                            NVPlayerPlayFishEyeActivity.this.SelectAreaList.remove(item);
                            NVPlayerPlayFishEyeActivity.this.SelectAreaList.add(item, Integer.valueOf(0));
                            NVPlayerPlayFishEyeActivity.this.LocalAreaSelectmap.clear();
                            NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(item).setBackgroundColor(Color.parseColor("#000000"));
                            NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(item).getBackground().setAlpha(20);
                        }
                    }
                    return true;
                case 2:
                    x = event.getX();
                    y = event.getY();
                    Rect rect;
                    if (NVPlayerPlayFishEyeActivity.this.isCheck) {
                        for (i = 0; i < LocalDefines.alarmrows * LocalDefines.alarmcolumns; i++) {
                            rect = new Rect();
                            NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(i).getHitRect(rect);
                            if (rect.contains((int) x, (int) y)) {
                                NVPlayerPlayFishEyeActivity.this.SelectAreaList.remove(i);
                                NVPlayerPlayFishEyeActivity.this.SelectAreaList.add(i, Integer.valueOf(0));
                                NVPlayerPlayFishEyeActivity.this.LocalAreaSelectmap.clear();
                                NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(i).setBackgroundColor(Color.parseColor("#000000"));
                                NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(i).getBackground().setAlpha(20);
                            }
                        }
                    } else {
                        for (i = 0; i < LocalDefines.alarmrows * LocalDefines.alarmcolumns; i++) {
                            rect = new Rect();
                            NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(i).getHitRect(rect);
                            if (rect.contains((int) x, (int) y)) {
                                NVPlayerPlayFishEyeActivity.this.SelectAreaList.remove(i);
                                NVPlayerPlayFishEyeActivity.this.SelectAreaList.add(i, Integer.valueOf(1));
                                NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(i).setBackgroundColor(Color.parseColor("#ff0000"));
                                NVPlayerPlayFishEyeActivity.this.mGridView.getChildAt(i).getBackground().setAlpha(51);
                            }
                        }
                    }
                    return true;
                default:
                    return false;
            }
        }
    }

    class C04057 implements OnClickListener {
        C04057() {
        }

        public void onClick(View v) {
            NVPlayerPlayFishEyeActivity.this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
            NVPlayerPlayFishEyeActivity.this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
            NVPlayerPlayFishEyeActivity.this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
            NVPlayerPlayFishEyeActivity.this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
            NVPlayerPlayFishEyeActivity.this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
            NVPlayerPlayFishEyeActivity.this.mPopupExpandMode.dismiss();
            NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.getGLFisheyeView().setMode(0);
            NVPlayerPlayFishEyeActivity.this.mPlayMode = 0;
            NVPlayerPlayFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode1_btn);
        }
    }

    class C04068 implements OnClickListener {
        C04068() {
        }

        public void onClick(View v) {
            NVPlayerPlayFishEyeActivity.this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
            NVPlayerPlayFishEyeActivity.this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_bg_click);
            NVPlayerPlayFishEyeActivity.this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
            NVPlayerPlayFishEyeActivity.this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
            NVPlayerPlayFishEyeActivity.this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
            NVPlayerPlayFishEyeActivity.this.mPopupExpandMode.dismiss();
            NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.getGLFisheyeView().setMode(3);
            NVPlayerPlayFishEyeActivity.this.mPlayMode = 3;
            NVPlayerPlayFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode2_btn);
        }
    }

    class C04079 implements OnClickListener {
        C04079() {
        }

        public void onClick(View v) {
            NVPlayerPlayFishEyeActivity.this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
            NVPlayerPlayFishEyeActivity.this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
            NVPlayerPlayFishEyeActivity.this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_bg_click);
            NVPlayerPlayFishEyeActivity.this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
            NVPlayerPlayFishEyeActivity.this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
            NVPlayerPlayFishEyeActivity.this.mPopupExpandMode.dismiss();
            NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.getGLFisheyeView().setMode(7);
            NVPlayerPlayFishEyeActivity.this.mPlayMode = 7;
            NVPlayerPlayFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode3_btn);
        }
    }

    class CloseActivityReceiver extends BroadcastReceiver {
        CloseActivityReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = LocalDefines.getReceiverActionString(NVPlayerPlayFishEyeActivity.this);
            if (intent != null && intent.getAction().equals(action)) {
                NVPlayerPlayFishEyeActivity.this.stopCurrentActivityFromBroadcast();
            }
        }
    }

    class PTZGestureListener extends SimpleOnGestureListener {
        PTZGestureListener(Context context) {
        }

        public boolean onSingleTapConfirmed(MotionEvent e) {
            if (NVPlayerPlayFishEyeActivity.this.layoutBottomBar.getVisibility() != 0 || NVPlayerPlayFishEyeActivity.this.layoutCrossScreenMode.getVisibility() != 0) {
                NVPlayerPlayFishEyeActivity.this.showToolsViews();
            } else if (NVPlayerPlayFishEyeActivity.this.nScreenOrientation == 2) {
                NVPlayerPlayFishEyeActivity.this.hideToolsViews();
            }
            return false;
        }
    }

    class PTZTimerThread extends Thread {
        int mThreadID = 0;

        public PTZTimerThread(int nThreadID) {
            this.mThreadID = nThreadID;
        }

        public void run() {
            while (this.mThreadID == NVPlayerPlayFishEyeActivity.this.ptzTimerThreadID) {
                boolean bLeft = NVPlayerPlayFishEyeActivity.this.bIsLeftPressed;
                boolean bRight = NVPlayerPlayFishEyeActivity.this.bIsRightPressed;
                boolean bUp = NVPlayerPlayFishEyeActivity.this.bIsUpPressed;
                boolean bDown = NVPlayerPlayFishEyeActivity.this.bIsDownPressed;
                if (bLeft && bRight) {
                    bLeft = false;
                    bRight = false;
                }
                if (bUp && bDown) {
                    bUp = false;
                    bDown = false;
                }
                if (bLeft || bRight || bUp || bDown) {
                    NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.SendPTZAction(bLeft, bRight, bUp, bDown, 0);
                    try {
                        sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        sleep(50);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }
    }

    private class PTZXPiontAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<Bitmap> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            RoundCornerImageView btnPTZXSet;
            ImageView ivPresetImage;
            TextView tvIDText;
            TextView tvPresetText;

            private ItemViewHolder() {
            }
        }

        class ListViewButtonListener implements OnClickListener {
            private int position;

            ListViewButtonListener(int pos) {
                this.position = pos;
            }

            public void onClick(View v) {
                if (v.getId() == PTZXPiontAdapter.this.holder.ivPresetImage.getId()) {
                    NVPlayerPlayFishEyeActivity.this.locationPTZXPoint(this.position);
                    if (NVPlayerPlayFishEyeActivity.this.popupWindowMore != null) {
                        NVPlayerPlayFishEyeActivity.this.popupWindowMore.dismiss();
                    }
                } else if (v.getId() == PTZXPiontAdapter.this.holder.btnPTZXSet.getId()) {
                    NVPlayerPlayFishEyeActivity.this.progressBarPresetConfig.setVisibility(0);
                    NVPlayerPlayFishEyeActivity.this.startPTZXConfig(NVPlayerPlayFishEyeActivity.this.deviceParam, this.position, 102, NVPlayerPlayFishEyeActivity.this.deviceParam.getnDeviceID());
                }
            }
        }

        public PTZXPiontAdapter(Context c, ArrayList<Bitmap> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.preset_count_item, null);
                this.holder = new ItemViewHolder();
                this.holder.ivPresetImage = (ImageView) convertView.findViewById(this.valueViewID[0]);
                this.holder.btnPTZXSet = (RoundCornerImageView) convertView.findViewById(this.valueViewID[1]);
                this.holder.tvPresetText = (TextView) convertView.findViewById(this.valueViewID[2]);
                this.holder.tvIDText = (TextView) convertView.findViewById(this.valueViewID[3]);
                convertView.setTag(this.holder);
            }
            PTZXPoint ptzxPoint = null;
            Bitmap image = null;
            if (LocalDefines._PTZXPointDevID == NVPlayerPlayFishEyeActivity.this.m_nDeviceID) {
                ptzxPoint = (PTZXPoint) LocalDefines._ptzxPointList.get(Integer.valueOf(position));
            }
            if (ptzxPoint != null) {
                image = ptzxPoint.getFaceImage();
            }
            if (image != null) {
                this.holder.ivPresetImage.setImageBitmap(image);
                this.holder.tvPresetText.setVisibility(8);
            } else {
                this.holder.tvPresetText.setVisibility(0);
                this.holder.ivPresetImage.setImageBitmap(null);
            }
            ListViewButtonListener listener = new ListViewButtonListener(position);
            this.holder.tvIDText.setText((position + 1));
            this.holder.ivPresetImage.setOnClickListener(listener);
            this.holder.btnPTZXSet.setOnClickListener(listener);
            return convertView;
        }
    }

    private class PTZXThread extends Thread {
        private Handler handler;
        LoginHandle lhandle = null;
        private int m_ThreadConfigID = 0;
        private int m_ThreadPTZXAction = 0;
        private int m_ThreadPTZXID = 0;
        private int m_nDeviceId = 0;

        public PTZXThread(Handler handler, int configID, LoginHandle lhandle, int nPTZXID, int nPTZXAction, int nDeviceId) {
            this.m_ThreadConfigID = configID;
            this.handler = handler;
            this.lhandle = lhandle;
            this.m_ThreadPTZXID = nPTZXID;
            this.m_ThreadPTZXAction = nPTZXAction;
            this.m_nDeviceId = nDeviceId;
        }

        public void run() {
            int nConfigResult = NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.SetPTZXLocationID(this.m_ThreadPTZXID, this.lhandle, this.m_nDeviceId);
            Message msg;
            if (NVPlayerPlayFishEyeActivity.this.m_nPTZXID == this.m_ThreadConfigID && nConfigResult == 256) {
                msg = this.handler.obtainMessage();
                msg.arg1 = NVPlayerPlayFishEyeActivity.PTZX_RESULT_OK;
                msg.arg2 = this.m_ThreadPTZXID;
                this.handler.sendMessage(msg);
            } else if (NVPlayerPlayFishEyeActivity.this.m_nPTZXID == this.m_ThreadConfigID) {
                msg = this.handler.obtainMessage();
                msg.arg1 = NVPlayerPlayFishEyeActivity.PTZX_RESULT_FAIL;
                msg.arg2 = nConfigResult;
                this.handler.sendMessage(msg);
            }
        }
    }

    class ScaleGestureListener implements OnScaleGestureListener {
        ScaleGestureListener() {
        }

        public boolean onScale(ScaleGestureDetector detector) {
            NVPlayerPlayFishEyeActivity nVPlayerPlayFishEyeActivity;
            if (detector.getScaleFactor() > PhotoViewAttacher.DEFAULT_MIN_SCALE) {
                nVPlayerPlayFishEyeActivity = NVPlayerPlayFishEyeActivity.this;
                nVPlayerPlayFishEyeActivity.fScaleSize = nVPlayerPlayFishEyeActivity.fScaleSize - 0.008f;
                if (((double) NVPlayerPlayFishEyeActivity.this.fScaleSize) < 0.2d) {
                    NVPlayerPlayFishEyeActivity.this.fScaleSize = 0.2f;
                } else {
                    NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.scale(NVPlayerPlayFishEyeActivity.this.fScaleSize, NVPlayerPlayFishEyeActivity.this.fScaleSize);
                }
            } else if (detector.getScaleFactor() < PhotoViewAttacher.DEFAULT_MIN_SCALE) {
                nVPlayerPlayFishEyeActivity = NVPlayerPlayFishEyeActivity.this;
                nVPlayerPlayFishEyeActivity.fScaleSize = nVPlayerPlayFishEyeActivity.fScaleSize + 0.05f;
                if (NVPlayerPlayFishEyeActivity.this.fScaleSize > PhotoViewAttacher.DEFAULT_MIN_SCALE) {
                    NVPlayerPlayFishEyeActivity.this.fScaleSize = PhotoViewAttacher.DEFAULT_MIN_SCALE;
                } else {
                    NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.scale(NVPlayerPlayFishEyeActivity.this.fScaleSize, NVPlayerPlayFishEyeActivity.this.fScaleSize);
                }
            }
            NVPlayerPlayFishEyeActivity.this.lScaleTime = System.currentTimeMillis();
            return false;
        }

        public boolean onScaleBegin(ScaleGestureDetector detector) {
            return true;
        }

        public void onScaleEnd(ScaleGestureDetector detector) {
        }
    }

    public class SelectAreaAdapter extends BaseAdapter {
        public int ROW_NUMBER = 4;
        Context context;
        ArrayList<Integer> listDate;
        GridView mGv;

        public SelectAreaAdapter(GridView gv, Context mContext, ArrayList<Integer> list) {
            this.context = mContext;
            this.mGv = gv;
            this.listDate = list;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = LayoutInflater.from(this.context).inflate(C0470R.layout.draggable_grid_item, null);
            if (this.listDate != null) {
                for (int i = 0; i < this.listDate.size(); i++) {
                    int isSelect = ((Integer) this.listDate.get(i)).intValue();
                    if (position == i) {
                        if (isSelect == 1) {
                            convertView.setBackgroundColor(Color.parseColor("#ff0000"));
                            convertView.getBackground().setAlpha(51);
                        } else {
                            convertView.setBackgroundColor(Color.parseColor("#000000"));
                            convertView.getBackground().setAlpha(20);
                        }
                    }
                }
            }
            convertView.setLayoutParams(new LayoutParams(-1, ((int) ((((double) (NVPlayerPlayFishEyeActivity.this.mScreenHeight - LocalDefines.getStatusBarHeight(NVPlayerPlayFishEyeActivity.this))) * 0.6d) - ((double) ((int) ((42.0f * NVPlayerPlayFishEyeActivity.this.getResources().getDisplayMetrics().density) + 0.5f))))) / LocalDefines.alarmrows));
            return convertView;
        }

        public int getCount() {
            return this.listDate.size();
        }

        public Object getItem(int position) {
            return this.listDate.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }
    }

    private class ThreadBtnScreenShot extends Thread {
        private int nThreadID = 0;

        public ThreadBtnScreenShot(int nThreadID) {
            this.nThreadID = nThreadID;
        }

        public void run() {
            super.run();
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (NVPlayerPlayFishEyeActivity.this.m_nThreadID == this.nThreadID) {
                Message msg = NVPlayerPlayFishEyeActivity.this.handler.obtainMessage();
                msg.arg1 = NVPlayerPlayFishEyeActivity.BTN_SCREENSHOT;
                NVPlayerPlayFishEyeActivity.this.handler.sendMessage(msg);
            }
        }
    }

    class TimerThread extends Thread {
        int mThreadID = 0;

        public TimerThread(int nThreadID) {
            this.mThreadID = nThreadID;
        }

        public void run() {
            while (this.mThreadID == NVPlayerPlayFishEyeActivity.this.timerThreadID) {
                NVPlayerPlayFishEyeActivity nVPlayerPlayFishEyeActivity = NVPlayerPlayFishEyeActivity.this;
                nVPlayerPlayFishEyeActivity.nToolsViewShowTickCount = nVPlayerPlayFishEyeActivity.nToolsViewShowTickCount - 1;
                if (NVPlayerPlayFishEyeActivity.this.nToolsViewShowTickCount <= 0 && this.mThreadID == NVPlayerPlayFishEyeActivity.this.timerThreadID) {
                    Message message = new Message();
                    message.arg1 = 3;
                    NVPlayerPlayFishEyeActivity.this.handler.sendMessage(message);
                    NVPlayerPlayFishEyeActivity.this.nToolsViewShowTickCount = 0;
                }
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    class C08375 implements ITimeTextCallback {
        C08375() {
        }

        public void setTimeText(final String strTime) {
            NVPlayerPlayFishEyeActivity.this.runOnUiThread(new Runnable() {
                public void run() {
                    NVPlayerPlayFishEyeActivity.this.mTvDisplayRealTime.setText(strTime);
                }
            });
        }
    }

    private void createDialogs() {
        this.iamgeViewConctentView = LayoutInflater.from(this).inflate(C0470R.layout.screenshotdialog, null);
        this.screenshotDialog = new Dialog(this, C0470R.style.progressDialog);
        this.screenshotDialog.setContentView(this.iamgeViewConctentView);
        this.screenshotDialog.setOnShowListener(new C04002());
        this.screenshotDialog.setOnDismissListener(new C04013());
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.isSelectArea) {
                finish();
            } else {
                exitPlayFisheye();
            }
        }
        return false;
    }

    private void readSystemParam() {
        this.mPlaySound = getSharedPreferences(Defines._fileName, 0).getBoolean("sounds", true);
    }

    public boolean writeSystemParam() {
        Editor editer = getSharedPreferences(Defines._fileName, 0).edit();
        editer.putBoolean("sounds", this.mPlaySound);
        editer.commit();
        return true;
    }

    private void ShowAlert(String title, String msg) {
        try {
            new Builder(this).setTitle(title).setMessage(msg).setIcon(C0470R.drawable.icon).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C04024()).show();
        } catch (Exception e) {
        }
    }

    public void onPause() {
        OnPlayersPuase();
        super.onPause();
    }

    public void onResume() {
        OnPlayersResume();
        this.nToolsViewShowTickCount = 8;
        this.timerThreadID++;
        new TimerThread(this.timerThreadID).start();
        if (this.mIsPlaying) {
            startPlay();
        } else {
            stopPlay(true);
        }
        this.m_bFinish = false;
        ((NotificationManager) getSystemService("notification")).cancel(257);
        this.nScreenOrientation = getResources().getConfiguration().orientation;
        super.onResume();
    }

    public void OnPlayersResume() {
        if (this.mNVPanoPlayer != null) {
            this.mNVPanoPlayer.getGLFisheyeView().onResume();
        }
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onStop() {
        this.timerThreadID++;
        this.m_nThreadID++;
        if (this.m_bFinish) {
            LibContext.stopAll();
            LibContext.ClearContext();
        } else {
            NotificationManager notiManager = (NotificationManager) getSystemService("notification");
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
            builder.setContentTitle(getString(C0470R.string.app_name)).setContentText(getString(C0470R.string.app_notice)).setTicker(getString(C0470R.string.app_name)).setWhen(System.currentTimeMillis());
            int currentapiVersion = VERSION.SDK_INT;
            if (VERSION.SDK_INT >= 23) {
                builder.setSmallIcon(C0470R.drawable.my_device_3);
                builder.setLargeIcon(Functions.readBitMap(this, C0470R.drawable.icon));
            } else {
                builder.setSmallIcon(C0470R.drawable.icon_1);
            }
            Intent intent = new Intent(this, NVPlayerPlayFishEyeActivity.class);
            Bundle data = new Bundle();
            data.putString("name", this.m_strName);
            if (this.mIsPlaying) {
                data.putBoolean("isplaying", true);
                data.putInt("playing_chn", this.mPlayingChn);
            }
            data.putParcelable(Constants.MAIN_VERSION_TAG, this.deviceParam);
            intent.putExtras(data);
            intent.setFlags(335544320);
            PendingIntent contentIntent = PendingIntent.getActivity(this, 257, intent, 134217728);
            notiManager.notify(257, builder.build());
            LibContext.stopAll();
        }
        this.m_bFinish = true;
        super.onStop();
    }

    private void ShowLandscapeView() {
        synchronized (this) {
            this.mGridView.setVisibility(8);
            this.llVertical.setVisibility(8);
            if (this.mPopupExpandMode != null && this.mPopupExpandMode.isShowing()) {
                this.mPopupExpandMode.dismiss();
            }
            if (this.mPopupExpandMode2 != null && this.mPopupExpandMode2.isShowing()) {
                this.mPopupExpandMode2.dismiss();
            }
            if (this.mPopupDeviceMode != null && this.mPopupDeviceMode.isShowing()) {
                this.mPopupDeviceMode.dismiss();
            }
            this.bAnyway = false;
            this.nToolsViewShowTickCount = 5;
            if (this.popupWindowMore != null) {
                this.popupWindowMore.dismiss();
            }
            hideToolsViews();
            this.nScreenOrientation = 2;
            if (this.mNVPanoPlayer != null) {
                this.mNVPanoPlayer.onOreintationChange(this.nScreenOrientation);
                this.mNVPanoPlayer.getGLFisheyeView().setMode(12);
            }
            this.container.setPadding(0, 0, 0, 0);
        }
    }

    private void ShowPortrailView() {
        synchronized (this) {
            if (this.mScreenWidth > this.mScreenHeight) {
                ShowLandscapeView();
            } else {
                int nHeight;
                RelativeLayout.LayoutParams rlp;
                float scale = getResources().getDisplayMetrics().density;
                int padding_in_px_top = (int) ((((float) 45) * scale) + 0.5f);
                int padding_in_px = (int) ((40.0f * scale) + 0.5f);
                int padding_in_px_progress = (int) ((80.0f * scale) + 0.5f);
                int padding_in_px_bottom = (int) ((((float) 75) * scale) + 0.5f);
                this.bAnyway = true;
                showToolsViews();
                int nWidth = this.mScreenWidth;
                int statusBarHeight = LocalDefines.getStatusBarHeight(this);
                if (this.isSelectArea) {
                    nHeight = (int) ((((double) (this.mScreenHeight - statusBarHeight)) * 0.6d) - ((double) padding_in_px));
                } else {
                    nHeight = ((this.mScreenHeight - padding_in_px_top) - padding_in_px_bottom) - statusBarHeight;
                }
                this.nScreenOrientation = 1;
                if (this.mNVPanoPlayer != null) {
                    this.mNVPanoPlayer.onOreintationChange(this.nScreenOrientation);
                    this.mNVPanoPlayer.getGLFisheyeView().setMode(this.mPlayMode);
                }
                if (this.RlVertical != null) {
                    rlp = new RelativeLayout.LayoutParams(this.mScreenWidth, (int) (((double) (this.mScreenHeight - statusBarHeight)) * 0.4d));
                    rlp.addRule(12, -1);
                    this.RlVertical.setLayoutParams(rlp);
                }
                int padding = (int) ((30.0f * getResources().getDisplayMetrics().density) + 0.5f);
                if (this.isSelectArea) {
                    rlp = new RelativeLayout.LayoutParams(nWidth, nHeight);
                    rlp.addRule(10, -1);
                    this.container.setLayoutParams(rlp);
                    RelativeLayout.LayoutParams rlp2 = new RelativeLayout.LayoutParams(padding_in_px_progress, padding_in_px_progress);
                    rlp2.setMargins((this.mScreenWidth / 2) - (padding_in_px_progress / 2), (int) (((double) (this.mScreenHeight - statusBarHeight)) * 0.2d), 0, 0);
                    this.spinner_0.setLayoutParams(rlp2);
                } else {
                    padding = (int) ((((double) nHeight) - (((double) nWidth) * 1.1d)) / 2.0d);
                    if (padding > 0) {
                        this.container.setPadding(0, padding, 0, padding);
                    }
                }
            }
        }
    }

    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        this.mScreenWidth = dm.widthPixels;
        this.mScreenHeight = dm.heightPixels;
        LocalDefines.loadResource(getResources());
        if (config.orientation == 2) {
            if (this.camType == 2) {
                this.layoutCrossScreenMode.setVisibility(8);
            } else if (this.camType == 1) {
                this.layoutCrossScreenMode.setVisibility(0);
                if (this.m_bReversePRI) {
                    this.imgCSModeInversion.setVisibility(0);
                    if (this.mIsReverse) {
                        this.imgCSModeInversion.setBackgroundResource(C0470R.drawable.mode_inversion_bg_click);
                    } else {
                        this.imgCSModeInversion.setBackgroundResource(C0470R.drawable.mode_inversion_transparent);
                    }
                } else {
                    this.imgCSModeInversion.setVisibility(8);
                }
            }
            ShowLandscapeView();
        } else if (config.orientation == 1) {
            this.layoutCrossScreenMode.setVisibility(8);
            ShowPortrailView();
        }
    }

    public void InitGLContainers() {
        this.container = (LinearLayout) findViewById(C0470R.id.playContainer1);
        this.mTvDisplayRealTime = (TextView) findViewById(C0470R.id.tv_display_real_time1);
    }

    public void InitGLViewPlayer() {
        if (this.mNVPanoPlayer == null) {
            this.mNVPanoPlayer = new NVPanoPlayer(this);
            if (this.camType == 1) {
                this.mNVPanoPlayer.setFixType(1);
            } else if (this.camType == 2) {
                this.mNVPanoPlayer.setFixType(0);
            }
            this.mNVPanoPlayer.setTvTimeOSD(new C08375());
            GLFisheyeView fisheyeView = new GLFisheyeView(getApplication());
            fisheyeView.setOnTouchListener(this);
            fisheyeView.setMode(this.mPlayMode);
            this.mNVPanoPlayer.setGlFishView(fisheyeView);
        }
    }

    public void OnPlayersPuase() {
        if (this.mNVPanoPlayer != null) {
            this.mNVPanoPlayer.getGLFisheyeView().onPause();
        }
    }

    public void ConnectGLViewToPlayer() {
        this.container.addView(this.mNVPanoPlayer.getGLFisheyeView());
    }

    public void InitGLViewProgressbar() {
        Player.GetProgressBars((ProgressBar) findViewById(C0470R.id.spinner_0), 0);
    }

    public void SetGLViewPlayerMessageHandler() {
        if (this.mNVPanoPlayer != null && this.handler != null) {
            this.mNVPanoPlayer.GetHandler(this.handler);
        }
    }

    private boolean saveToSDCard(Bitmap image, String strFileName) {
        boolean bResult = false;
        if (image == null) {
            return 0;
        }
        try {
            File file = new File(Functions.GetSDPath() + File.separator + LocalDefines.SDCardPath);
            if (!file.exists()) {
                file.mkdir();
            }
            FileOutputStream out = new FileOutputStream(new File(file.getAbsolutePath() + File.separator + strFileName));
            image.compress(CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
            bResult = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return bResult;
    }

    private Bitmap getPTZXImage() {
        this.bm = this.mNVPanoPlayer.Screenshot();
        float deltaW = Defines._PTZXWidth / ((float) Defines._capWidth);
        float deltaH = Defines._PTZXHeight / ((float) Defines._capHeight);
        Matrix matrix = new Matrix();
        matrix.postScale(deltaW, deltaH);
        return Bitmap.createBitmap(this.bm, 0, 0, this.bm.getWidth(), this.bm.getHeight(), matrix, true);
    }

    private void ScreenShot() {
        this.m_nThreadID++;
        this.mBtnScreenShot.setEnabled(false);
        this.mBtnScreenShot2.setEnabled(false);
        new ThreadBtnScreenShot(this.m_nThreadID).start();
        String strSavePath = Functions.GetSDPath();
        if (strSavePath == null) {
            this.screenshotDialog.dismiss();
            Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeSDCardNotExist), 0).show();
            return;
        }
        this.bm = this.mNVPanoPlayer.Screenshot();
        if (this.bm != null) {
            String strFileName = new StringBuilder(String.valueOf(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()))).append("(").append(this.m_strName).append(")").append(".jpg").toString();
            if (saveToSDCard(this.bm, strFileName)) {
                this.screenshotDialog.dismiss();
                Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeFileSaveToAlbumsOK), 0).show();
                return;
            }
            if (saveToSDCard(this.bm, new StringBuilder(String.valueOf(strSavePath)).append("/").append(strFileName).toString())) {
                this.screenshotDialog.dismiss();
                Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotOK), 0).show();
                return;
            }
            this.screenshotDialog.dismiss();
            Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotFail), 0).show();
            return;
        }
        this.screenshotDialog.dismiss();
        Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotFail), 0).show();
    }

    public void onCreate(Bundle savedInstanceState) {
        int i;
        super.onCreate(savedInstanceState);
        getWindow().setFlags(128, 128);
        ((NotificationManager) getSystemService("notification")).cancel(257);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_nvplayer_fisheye_playview);
        setRequestedOrientation(10);
        registerReceiver(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        this.mScreenWidth = dm.widthPixels;
        this.mScreenHeight = dm.heightPixels;
        LocalDefines.loadResource(getResources());
        this.FLING_MAX_DISTANCE = this.mScreenWidth / 3;
        this.tvPlayDeviceID = (TextView) findViewById(C0470R.id.tvPlayDeviceID);
        this.llPlayTalkback = (LinearLayout) findViewById(C0470R.id.llPlayTalkback);
        this.Viewlist = new ArrayList();
        this.SelectAreaList = new ArrayList();
        this.map_Select_area = new HashMap();
        this.ALL_area_alarmlist = new ArrayList();
        Bundle data = getIntent().getExtras();
        if (data != null) {
            this.m_strName = data.getString("name");
            this.deviceParam = (LoginHandle) data.getParcelable(Defines.RECORD_FILE_RETURN_MESSAGE);
            this.isSelectArea = data.getBoolean("isSelectArea");
            this.m_bReversePRI = this.deviceParam.isbReversePRI();
            this.m_bPTZ = this.deviceParam.isbPTZ();
            this.m_bPTZX = this.deviceParam.isbPTZX();
            this.m_nPTZXCount = this.deviceParam.getnPTZXCount();
            this.m_nDeviceID = this.deviceParam.getnDeviceID();
            this.m_strUsername = data.getString("username");
            this.m_strPassword = data.getString("password");
            this.m_bSpeak = this.deviceParam.isbSpeak();
            this.camType = this.deviceParam.getCamType();
            this.panoX = this.deviceParam.getPanoX();
            this.panoY = this.deviceParam.getPanoY();
            this.panoRad = this.deviceParam.getPanoRad();
        }
        this.RlVertical = (LinearLayout) findViewById(C0470R.id.RlVertical);
        this.spinner_0 = (ProgressBar) findViewById(C0470R.id.spinner_0);
        if (this.isSelectArea) {
            this.RlVertical.setVisibility(0);
            setRequestedOrientation(1);
        } else {
            this.RlVertical.setVisibility(8);
            setRequestedOrientation(10);
        }
        LocalDefines.loadPTZXPoints(this.deviceParam.getnDeviceID());
        this.mGestureDetector = new GestureDetector(this, new PTZGestureListener(this));
        this.mScaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureListener());
        this.tvPlayDeviceID.setText(this.m_strName);
        this.layoutTopBar = (LinearLayout) findViewById(C0470R.id.linearLayoutTopBar);
        this.layoutBottomBar = (RelativeLayout) findViewById(C0470R.id.linearLayoutBottomBar);
        this.layoutCrossScreenMode = (LinearLayout) findViewById(C0470R.id.cross_screen_mode);
        this.imgCSModeOriginal = (Button) findViewById(C0470R.id.iv_cross_screen_expand_normal);
        this.imgCSModeOriginal.setOnClickListener(this);
        this.imgCSMode5 = (Button) findViewById(C0470R.id.iv_cross_screen_expand_mode5);
        this.imgCSMode5.setOnClickListener(this);
        this.imgCSModeInversion = (Button) findViewById(C0470R.id.iv_cross_screen_expand_inversion);
        this.imgCSModeInversion.setOnClickListener(this);
        this.llLandscape = (LinearLayout) findViewById(C0470R.id.llLandscape);
        this.llLandscape.getBackground().setAlpha(95);
        this.llVertical = (LinearLayout) findViewById(C0470R.id.llVertical);
        this.btn_saveSelectArea = (Button) findViewById(C0470R.id.btn_saveSelectArea);
        this.btn_saveSelectArea.setOnClickListener(this);
        this.btnSelectAllArea = (Button) findViewById(C0470R.id.btnSelectAllArea);
        this.btnSelectAllArea.setOnClickListener(this);
        this.btnCanelAllArea = (Button) findViewById(C0470R.id.btnCanelAllArea);
        this.btnCanelAllArea.setOnClickListener(this);
        InitGLContainers();
        InitGLViewProgressbar();
        InitGLViewPlayer();
        ConnectGLViewToPlayer();
        SetGLViewPlayerMessageHandler();
        LibContext.SetContext(this.mNVPanoPlayer, null, null, null);
        Player.SelectWindow(0);
        ShowPortrailView();
        this.mBtnBack = (ImageView) findViewById(C0470R.id.buttonBackToLogin);
        this.mBtnBack.setOnClickListener(this);
        this.mBtnExpandMode = (Button) findViewById(C0470R.id.btn_mode);
        this.mBtnExpandMode.setOnClickListener(this);
        this.mBtnDeviceMode = (Button) findViewById(C0470R.id.btn_devicemode);
        this.mBtnDeviceMode.setOnClickListener(this);
        switch (this.mPlayMode) {
            case 0:
                this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode1_btn);
                break;
            case 3:
                this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode2_btn);
                break;
            case 4:
                this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode6_btn);
                break;
            case 6:
                this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode5_btn);
                break;
            case 7:
                this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode3_btn);
                break;
            case 11:
                this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode4_btn);
                break;
        }
        this.mBtnSound = (Button) findViewById(C0470R.id.buttonSound);
        this.mBtnSound.setOnClickListener(this);
        this.mBtnMic = (Button) findViewById(C0470R.id.buttonMic);
        this.mBtnMic.setOnTouchListener(this);
        this.mBtnScreenShot = (Button) findViewById(C0470R.id.buttonScreenShot);
        this.mBtnScreenShot.setOnClickListener(this);
        this.mBtnScreenShot2 = (Button) findViewById(C0470R.id.buttonScreenShot2);
        this.mBtnScreenShot2.setOnClickListener(this);
        this.mBtnMic2 = (Button) findViewById(C0470R.id.buttonMic2);
        this.mBtnMic2.setOnTouchListener(this);
        this.mBtnReverse2 = (Button) findViewById(C0470R.id.buttonReverse2);
        this.mBtnReverse2.setOnClickListener(this);
        this.mBtnSound2 = (Button) findViewById(C0470R.id.buttonSound2);
        this.mBtnSound2.setOnClickListener(this);
        if (this.m_bSpeak) {
            findViewById(C0470R.id.layoutMicBtn).setVisibility(0);
            findViewById(C0470R.id.layoutMicBtn2).setVisibility(0);
        } else {
            findViewById(C0470R.id.layoutMicBtn).setVisibility(8);
            findViewById(C0470R.id.layoutMicBtn2).setVisibility(8);
        }
        this.mGridView = (GridView) findViewById(C0470R.id.gv2);
        int nWidth = this.mScreenWidth;
        int statusBarHeight = LocalDefines.getStatusBarHeight(this);
        if (this.isSelectArea) {
            int nHeight = (int) (((double) (this.mScreenHeight - statusBarHeight)) * 0.6d);
        }
        this.mGridView.setNumColumns(LocalDefines.alarmcolumns);
        if (this.isSelectArea) {
            DeviceAlarmAndPromptSettingFragment deviceAlarmAndPromptSettingFragment = new DeviceAlarmAndPromptSettingFragment();
            if (DeviceAlarmAndPromptSettingFragment.isSaveArea) {
                for (i = 0; i < LocalDefines.alarmrows * LocalDefines.alarmcolumns; i++) {
                    this.SelectAreaList.add(i, Integer.valueOf(((Integer) LocalDefines.LocalAlarmAreaList.get(i)).intValue()));
                }
                this.adapter = new SelectAreaAdapter(this.mGridView, getApplicationContext(), this.SelectAreaList);
            } else {
                for (i = 0; i < LocalDefines.alarmrows * LocalDefines.alarmcolumns; i++) {
                    this.SelectAreaList.add(i, Integer.valueOf(((Integer) LocalDefines.ServerAlarmAreaList.get(i)).intValue()));
                }
                this.adapter = new SelectAreaAdapter(this.mGridView, getApplicationContext(), this.SelectAreaList);
            }
        }
        this.mGridView.setOnTouchListener(new C04046());
        this.mGridView.setAdapter(this.adapter);
        for (i = 0; i < LocalDefines.alarmcolumns * LocalDefines.alarmrows; i++) {
            this.Viewlist.add(Constants.MAIN_VERSION_TAG);
            this.ALL_area_alarmlist.add(i, Integer.valueOf(1));
        }
        this.LocalAreaSelectmap = new HashMap();
        if (this.isSelectArea) {
            this.mGridView.setVisibility(0);
            this.btn_saveSelectArea.setVisibility(0);
            this.llVertical.setVisibility(8);
        } else {
            this.llVertical.setVisibility(0);
            this.mGridView.setVisibility(8);
            this.btn_saveSelectArea.setVisibility(8);
        }
        readSystemParam();
        onSoundChange();
        this.mPlayingChn = 1;
        this.mIsPlaying = true;
        createDialogs();
    }

    private void presetList() {
        if (this.m_nPTZXCount > 0) {
            ArrayList<Bitmap> listItem = new ArrayList();
            for (int i = 0; i < this.m_nPTZXCount; i++) {
                listItem.add(Functions.readBitMap(this, C0470R.drawable.alarm_icon));
            }
            this.ptzxAdapter = new PTZXPiontAdapter(this, listItem, C0470R.layout.preset_count_item, new String[]{"ItemPresetImage", "ItemPresetSetImage", "ItemPresetText", "ItemIDText"}, new int[]{C0470R.id.ivPresetImage, C0470R.id.btnPTZXSet, C0470R.id.tvPresetText, C0470R.id.tvPTZXID});
            if (this.lvPreset != null) {
                this.lvPreset.setCacheColorHint(0);
                this.lvPreset.setAdapter(this.ptzxAdapter);
                this.lvPreset.setOnItemClickListener(this);
            }
        }
    }

    private void stopPlay(boolean bFlag) {
        this.ptzTimerThreadID++;
        if (this.m_nAddType != Defines.SERVER_SAVE_TYPE_DEMO) {
            this.bm = this.mNVPanoPlayer.Screenshot();
            if (this.bm != null) {
                Bitmap image = Functions.zoomBitmap(this.bm, Defines.SYSTEM_ID_WIN8, 240);
                if (this.m_nDeviceID > 0) {
                    DatabaseManager.setFaceForDevID(this.m_nDeviceID, image, this.m_strUsername, this.m_strPassword);
                } else {
                    DatabaseManager.setFaceForID(this.m_nID, image);
                }
            }
        }
        this.mIsPlaying = false;
        this.tvPlayDeviceID.setText(this.m_strName);
        this.mPlayingChn = -1;
        this.mNVPanoPlayer.scale(PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE);
        this.mNVPanoPlayer.StopPlay();
        Player.ShowProgressBar(0, false);
    }

    private void startPlay() {
        if (this.m_strName == null || this.m_strName.trim().length() <= 0) {
            this.tvPlayDeviceID.setText(getString(C0470R.string.Notification_Playing_Chn) + " " + this.m_strName);
        } else {
            this.tvPlayDeviceID.setText(getString(C0470R.string.Notification_Playing_Chn) + " " + this.m_strName);
        }
        this.mNVPanoPlayer.setnServerID(this.deviceParam.getnDeviceID());
        if (Player.CurrentSelPlayer() < 4) {
            Player.setPlaying(Player.CurrentSelPlayer(), true);
            this.mNVPanoPlayer.EnableRender();
            Defines._capWidth = 0;
            Defines._capHeight = 0;
            this.mNVPanoPlayer.StartPlay(0, 0, 1, this.mPlaySound, this.deviceParam);
            this.mNVPanoPlayer.setReverse(this.mIsReverse);
            this.mNVPanoPlayer.playAudio();
        }
        this.ptzTimerThreadID++;
        if (this.m_bPTZ) {
            new PTZTimerThread(this.ptzTimerThreadID).start();
        }
        this.mIsPlaying = true;
    }

    private void onStreamTypeChange(int nType) {
        if (this.mStreamType != nType) {
            this.mStreamType = nType;
            if (this.mIsPlaying) {
                stopPlay(false);
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                startPlay();
            }
        }
    }

    private void onSoundChange() {
        if (this.mPlaySound) {
            this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn));
            this.mBtnSound2.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal));
        } else {
            this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_3));
            this.mBtnSound2.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal2));
        }
        this.mNVPanoPlayer.SetAudioParam(this.mPlaySound);
        writeSystemParam();
    }

    private void showPopWinPlayerMode(View v) {
        int PopWinWidth;
        View playerModeView = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.popup_expand_mode_layout, null);
        this.imgOriginal = (Button) playerModeView.findViewById(C0470R.id.iv_expand_normal);
        this.imgCylindric = (Button) playerModeView.findViewById(C0470R.id.iv_expand_mode1);
        this.imgQuad = (Button) playerModeView.findViewById(C0470R.id.iv_expand_mode2);
        this.imgMode4 = (Button) playerModeView.findViewById(C0470R.id.iv_expand_mode3);
        this.imgModeLongLatUD = (Button) playerModeView.findViewById(C0470R.id.iv_expand_mode4);
        this.imgModeInversionCeil = (Button) playerModeView.findViewById(C0470R.id.iv_expand_inversion);
        if (this.m_bReversePRI) {
            PopWinWidth = 240;
            this.imgModeInversionCeil.setVisibility(0);
            if (this.mIsReverse) {
                this.imgModeInversionCeil.setBackgroundResource(C0470R.drawable.mode_inversion_bg_click);
            } else {
                this.imgModeInversionCeil.setBackgroundResource(C0470R.drawable.mode_inversion_transparent);
            }
        } else {
            PopWinWidth = 200;
            this.imgModeInversionCeil.setVisibility(8);
        }
        switch (this.mPlayMode) {
            case 0:
                this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                break;
            case 3:
                this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_bg_click);
                this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                break;
            case 4:
                this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                break;
            case 6:
                this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_bg_click);
                break;
            case 7:
                this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_bg_click);
                this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                break;
            case 11:
                this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_bg_click);
                this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                break;
        }
        this.imgOriginal.setOnClickListener(new C04057());
        this.imgCylindric.setOnClickListener(new C04068());
        this.imgQuad.setOnClickListener(new C04079());
        this.imgMode4.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlayFishEyeActivity.this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                NVPlayerPlayFishEyeActivity.this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                NVPlayerPlayFishEyeActivity.this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                NVPlayerPlayFishEyeActivity.this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_bg_click);
                NVPlayerPlayFishEyeActivity.this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                NVPlayerPlayFishEyeActivity.this.mPopupExpandMode.dismiss();
                NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.getGLFisheyeView().setMode(11);
                NVPlayerPlayFishEyeActivity.this.mPlayMode = 11;
                NVPlayerPlayFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode4_btn);
            }
        });
        this.imgModeLongLatUD.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlayFishEyeActivity.this.imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                NVPlayerPlayFishEyeActivity.this.imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                NVPlayerPlayFishEyeActivity.this.imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                NVPlayerPlayFishEyeActivity.this.imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                NVPlayerPlayFishEyeActivity.this.imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_bg_click);
                NVPlayerPlayFishEyeActivity.this.mPopupExpandMode.dismiss();
                NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.getGLFisheyeView().setMode(6);
                NVPlayerPlayFishEyeActivity.this.mPlayMode = 6;
                NVPlayerPlayFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode5_btn);
            }
        });
        this.imgModeInversionCeil.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (NVPlayerPlayFishEyeActivity.this.m_bReversePRI) {
                    if (NVPlayerPlayFishEyeActivity.this.mIsReverse) {
                        NVPlayerPlayFishEyeActivity.this.imgModeInversionCeil.setBackgroundResource(C0470R.drawable.mode_inversion_transparent);
                    } else {
                        NVPlayerPlayFishEyeActivity.this.imgModeInversionCeil.setBackgroundResource(C0470R.drawable.mode_inversion_bg_click);
                    }
                    NVPlayerPlayFishEyeActivity.this.mIsReverse = !NVPlayerPlayFishEyeActivity.this.mIsReverse;
                    NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.SetCamImageOrientation(1000);
                    NVPlayerPlayFishEyeActivity.this.mPopupExpandMode.dismiss();
                }
            }
        });
        float density = getResources().getDisplayMetrics().density;
        this.mPopupExpandMode = new PopupWindow(playerModeView, (int) ((((float) PopWinWidth) * density) + 0.5f), (int) ((50.0f * density) + 0.5f));
        this.mPopupExpandMode.setTouchable(true);
        this.mPopupExpandMode.setFocusable(true);
        this.mPopupExpandMode.setBackgroundDrawable(new BitmapDrawable());
        this.mPopupExpandMode.setAnimationStyle(C0470R.style.popupwindow_expand_mode);
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        this.mPopupExpandMode.showAtLocation(v, 0, (int) ((((float) location[0]) + (((float) this.mPopupExpandMode.getWidth()) * density)) + 0.5f), (int) ((((float) (location[1] - this.mPopupExpandMode.getHeight())) - (25.0f * density)) + 0.5f));
    }

    private void showPopWinWallPlayerMode(View v) {
        int PopWinWidth;
        View playerModeView = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.popup_wall_expand_mode_layout, null);
        this.imgModeViewAngle = (Button) playerModeView.findViewById(C0470R.id.iv_wall_expand_mode5);
        this.imgWallOriginal = (Button) playerModeView.findViewById(C0470R.id.iv_wall_expand_normal);
        this.imgModeInversionWall = (Button) playerModeView.findViewById(C0470R.id.iv_wall_expand_inversion);
        if (this.m_bReversePRI) {
            PopWinWidth = 120;
            this.imgModeInversionWall.setVisibility(0);
            if (this.mIsReverse) {
                this.imgModeInversionWall.setBackgroundResource(C0470R.drawable.mode_inversion_bg_click);
            } else {
                this.imgModeInversionWall.setBackgroundResource(C0470R.drawable.mode_inversion_transparent);
            }
        } else {
            PopWinWidth = 80;
            this.imgModeInversionWall.setVisibility(8);
        }
        switch (this.mPlayMode) {
            case 0:
                this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                break;
            case 4:
                this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                break;
            default:
                this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                break;
        }
        this.imgWallOriginal.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlayFishEyeActivity.this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                NVPlayerPlayFishEyeActivity.this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlayFishEyeActivity.this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                NVPlayerPlayFishEyeActivity.this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlayFishEyeActivity.this.mPopupExpandMode2.dismiss();
                NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.getGLFisheyeView().setMode(0);
                NVPlayerPlayFishEyeActivity.this.mPlayMode = 0;
                NVPlayerPlayFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode1_btn);
            }
        });
        this.imgModeViewAngle.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlayFishEyeActivity.this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                NVPlayerPlayFishEyeActivity.this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                NVPlayerPlayFishEyeActivity.this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                NVPlayerPlayFishEyeActivity.this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                NVPlayerPlayFishEyeActivity.this.mPopupExpandMode2.dismiss();
                NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.getGLFisheyeView().setMode(4);
                NVPlayerPlayFishEyeActivity.this.mPlayMode = 4;
                NVPlayerPlayFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode6_btn);
            }
        });
        this.imgModeInversionWall.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (NVPlayerPlayFishEyeActivity.this.m_bReversePRI) {
                    if (NVPlayerPlayFishEyeActivity.this.mIsReverse) {
                        NVPlayerPlayFishEyeActivity.this.imgModeInversionWall.setBackgroundResource(C0470R.drawable.mode_inversion_transparent);
                    } else {
                        NVPlayerPlayFishEyeActivity.this.imgModeInversionWall.setBackgroundResource(C0470R.drawable.mode_inversion_bg_click);
                    }
                    NVPlayerPlayFishEyeActivity.this.mIsReverse = !NVPlayerPlayFishEyeActivity.this.mIsReverse;
                    NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.SetCamImageOrientation(1000);
                    NVPlayerPlayFishEyeActivity.this.mPopupExpandMode2.dismiss();
                }
            }
        });
        float density = getResources().getDisplayMetrics().density;
        this.mPopupExpandMode2 = new PopupWindow(playerModeView, (int) ((((float) PopWinWidth) * density) + 0.5f), (int) ((50.0f * density) + 0.5f));
        this.mPopupExpandMode2.setTouchable(true);
        this.mPopupExpandMode2.setFocusable(true);
        this.mPopupExpandMode2.setBackgroundDrawable(new BitmapDrawable());
        this.mPopupExpandMode2.setAnimationStyle(C0470R.style.popupwindow_expand_mode);
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        this.mPopupExpandMode2.showAtLocation(v, 0, (int) ((((float) location[0]) + (((float) this.mPopupExpandMode2.getWidth()) * density)) + 0.5f), (int) ((((float) (location[1] - this.mPopupExpandMode2.getHeight())) - (25.0f * density)) + 0.5f));
    }

    private void showPopWinDeviceMode(View v) {
        View devicerModeView = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.popup_device_mode_layout, null);
        final Button btnCeiling = (Button) devicerModeView.findViewById(C0470R.id.iv_device_ceiling);
        final Button btnWall = (Button) devicerModeView.findViewById(C0470R.id.iv_device_wall);
        switch (this.camType) {
            case 1:
                btnCeiling.setBackgroundResource(C0470R.drawable.ceiling_transparent);
                btnWall.setBackgroundResource(C0470R.drawable.wall_bg_click);
                break;
            case 2:
                btnCeiling.setBackgroundResource(C0470R.drawable.ceiling_bg_click);
                btnWall.setBackgroundResource(C0470R.drawable.wall_transparent);
                break;
        }
        btnCeiling.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlayFishEyeActivity.this.camType = 2;
                NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.setFixType(0);
                btnCeiling.setBackgroundResource(C0470R.drawable.ceiling_bg_click);
                btnWall.setBackgroundResource(C0470R.drawable.wall_transparent);
                NVPlayerPlayFishEyeActivity.this.mBtnDeviceMode.setBackgroundResource(C0470R.drawable.device_ceiling_btn);
                NVPlayerPlayFishEyeActivity.this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                NVPlayerPlayFishEyeActivity.this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.getGLFisheyeView().setMode(0);
                NVPlayerPlayFishEyeActivity.this.mPlayMode = 0;
                NVPlayerPlayFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode1_btn);
                NVPlayerPlayFishEyeActivity.this.mPopupDeviceMode.dismiss();
            }
        });
        btnWall.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlayFishEyeActivity.this.camType = 1;
                NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.setFixType(1);
                btnCeiling.setBackgroundResource(C0470R.drawable.ceiling_transparent);
                btnWall.setBackgroundResource(C0470R.drawable.wall_bg_click);
                NVPlayerPlayFishEyeActivity.this.mBtnDeviceMode.setBackgroundResource(C0470R.drawable.device_wall_btn);
                NVPlayerPlayFishEyeActivity.this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                NVPlayerPlayFishEyeActivity.this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlayFishEyeActivity.this.mNVPanoPlayer.getGLFisheyeView().setMode(0);
                NVPlayerPlayFishEyeActivity.this.mPlayMode = 0;
                NVPlayerPlayFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode1_btn);
                NVPlayerPlayFishEyeActivity.this.mPopupDeviceMode.dismiss();
            }
        });
        float density = getResources().getDisplayMetrics().density;
        this.mPopupDeviceMode = new PopupWindow(devicerModeView, (int) ((((float) 80) * density) + 0.5f), (int) ((50.0f * density) + 0.5f));
        this.mPopupDeviceMode.setTouchable(true);
        this.mPopupDeviceMode.setFocusable(true);
        this.mPopupDeviceMode.setBackgroundDrawable(new BitmapDrawable());
        this.mPopupDeviceMode.setAnimationStyle(C0470R.style.popupwindow_expand_mode);
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        this.mPopupDeviceMode.showAtLocation(v, 0, (int) (((double) this.mScreenWidth) * 0.6d), (int) ((((float) (location[1] - this.mPopupDeviceMode.getHeight())) - (25.0f * density)) + 0.5f));
    }

    public void onClick(View v) {
        int i;
        this.nToolsViewShowTickCount = 5;
        if (v == this.btnSelectAllArea) {
            this.SelectAreaList.clear();
            for (i = 0; i < LocalDefines.alarmcolumns * LocalDefines.alarmrows; i++) {
                this.SelectAreaList.add(i, Integer.valueOf(1));
            }
            this.isAllArea = true;
            this.adapter = new SelectAreaAdapter(this.mGridView, getApplicationContext(), this.SelectAreaList);
            this.mGridView.setAdapter(this.adapter);
        }
        if (v == this.btnCanelAllArea) {
            this.SelectAreaList.clear();
            for (i = 0; i < LocalDefines.alarmcolumns * LocalDefines.alarmrows; i++) {
                this.SelectAreaList.add(i, Integer.valueOf(0));
            }
            this.isAllArea = false;
            this.adapter = new SelectAreaAdapter(this.mGridView, getApplicationContext(), this.SelectAreaList);
            this.mGridView.setAdapter(this.adapter);
        }
        if (v == this.btn_saveSelectArea) {
            DeviceAlarmAndPromptSettingFragment deviceAlarmAndPromptSettingFragment = new DeviceAlarmAndPromptSettingFragment();
            DeviceAlarmAndPromptSettingFragment.isSaveArea = true;
            LocalDefines.shouldUpdateSelectArea = true;
            LocalDefines.Localmap_Update_area.put(Integer.valueOf(this.deviceParam.getnDeviceID()), Boolean.valueOf(LocalDefines.shouldUpdateSelectArea));
            LocalDefines.LocalAlarmAreaList = this.SelectAreaList;
            List splist = new ArrayList();
            SharedPreferences mySharedPreferences = getSharedPreferences("scenelist", 0);
            Editor edit = mySharedPreferences.edit();
            try {
                edit.putString("spArea_list_for" + this.deviceParam.getnDeviceID(), SpSaveList.SceneList2String(LocalDefines.LocalAlarmAreaList));
                edit.commit();
                splist = SpSaveList.String2SceneList(mySharedPreferences.getString("spArea_list_for" + this.deviceParam.getnDeviceID(), Constants.MAIN_VERSION_TAG));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e2) {
                e2.printStackTrace();
            }
            LocalDefines.Localmap_Select_area.put(Integer.valueOf(this.deviceParam.getnDeviceID()), LocalDefines.LocalAlarmAreaList);
            if (LocalDefines.Localmap_Select_area != null) {
                LocalDefines.LocalAlarmAreaList = (ArrayList) LocalDefines.Localmap_Select_area.get(Integer.valueOf(this.deviceParam.getnDeviceID()));
            }
            finish();
        }
        if (v == this.mBtnExpandMode) {
            if (this.camType == 2) {
                showPopWinPlayerMode(v);
            } else if (this.camType == 1) {
                showPopWinWallPlayerMode(v);
            }
        }
        if (v == this.mBtnDeviceMode) {
            showPopWinDeviceMode(v);
        }
        if (v == this.btnCancelImageView) {
            this.iamgeViewDialog.dismiss();
        } else if (v == this.mBtnScreenShot) {
            if (!this.mIsPlaying) {
                return;
            }
            if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                this.screenshotDialog.show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 3);
            }
        } else if (v == this.mBtnScreenShot2) {
            if (!this.mIsPlaying) {
                return;
            }
            if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                this.screenshotDialog.show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 3);
            }
        } else if (v == this.mBtnSound) {
            v.setEnabled(false);
            if (this.mPlaySound) {
                this.mPlaySound = false;
            } else {
                this.mPlaySound = true;
            }
            onSoundChange();
            v.setEnabled(true);
        } else if (v == this.mBtnSound2) {
            v.setEnabled(false);
            if (this.mPlaySound) {
                this.mPlaySound = false;
            } else {
                this.mPlaySound = true;
            }
            onSoundChange();
            v.setEnabled(true);
        } else if (v == this.mBtnBack) {
            if (this.isSelectArea) {
                finish();
            } else {
                exitPlayFisheye();
            }
        } else if (v == this.imgCSModeOriginal) {
            this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
            this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_transparent);
            this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.mode1_bg_click);
            this.mNVPanoPlayer.getGLFisheyeView().setMode(0);
            this.mPlayMode = 0;
        } else if (v == this.imgCSMode5) {
            this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
            this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_bg_click);
            this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.mode6_bg_click);
            this.mNVPanoPlayer.getGLFisheyeView().setMode(4);
            this.mPlayMode = 4;
        } else if (v == this.imgCSModeInversion && this.m_bReversePRI) {
            if (this.mIsReverse) {
                this.imgCSModeInversion.setBackgroundResource(C0470R.drawable.mode_inversion_transparent);
            } else {
                this.imgCSModeInversion.setBackgroundResource(C0470R.drawable.mode_inversion_bg_click);
            }
            this.mIsReverse = !this.mIsReverse;
            this.mNVPanoPlayer.SetCamImageOrientation(1000);
        }
    }

    public void ShowNotic(String title, String msg) {
        Toast toast = Toast.makeText(getApplicationContext(), title, 0);
        toast.setGravity(17, 0, 0);
        toast.show();
    }

    public boolean onTouch(View v, MotionEvent event) {
        if (v == this.mNVPanoPlayer.getGLFisheyeView()) {
            this.mScaleGestureDetector.onTouchEvent(event);
            if (System.currentTimeMillis() - this.lScaleTime <= 500) {
                return false;
            }
            this.mGestureDetector.onTouchEvent(event);
            return false;
        } else if (v == this.mBtnMic) {
            return intercom(event, false);
        } else {
            if (v == this.mBtnMic2) {
                return intercom(event, true);
            }
            return false;
        }
    }

    private boolean intercom(MotionEvent event, boolean isBtn2) {
        if (this.mIsPlaying) {
            Button btn = isBtn2 ? this.mBtnMic2 : this.mBtnMic;
            switch (event.getAction()) {
                case 0:
                    if (!shouldRemind()) {
                        setIntercomViewValue(btn, isBtn2 ? C0470R.drawable.cross_screen_btn_talk_click : C0470R.drawable.btn_talk_click, true, 0, true);
                        this.mNVPanoPlayer.StartSpeak();
                        break;
                    }
                    break;
                case 1:
                    setIntercomViewValue(btn, isBtn2 ? C0470R.drawable.cross_screen_btn_talk : C0470R.drawable.btn_talk, false, 8, true);
                    this.mNVPanoPlayer.StopSpeak();
                    break;
                case 2:
                    setIntercomViewValue(btn, isBtn2 ? C0470R.drawable.cross_screen_btn_talk_click : C0470R.drawable.btn_talk_click, true, 0, false);
                    break;
                case 3:
                    setIntercomViewValue(btn, isBtn2 ? C0470R.drawable.cross_screen_btn_talk : C0470R.drawable.btn_talk, false, 8, true);
                    this.mNVPanoPlayer.StopSpeak();
                    break;
                default:
                    break;
            }
        }
        return true;
    }

    private boolean shouldRemind() {
        if (!this.m_bSpeak) {
            Toast.makeText(this, getString(C0470R.string.str_do_not_support_mic), 0).show();
            return true;
        } else if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0) {
            return false;
        } else {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.RECORD_AUDIO"}, 2);
            return true;
        }
    }

    private void setIntercomViewValue(Button btn, int btnMicBgId, boolean isSpeaking, int llPlayTalkbackVisible, boolean isSleep) {
        btn.setBackgroundResource(btnMicBgId);
        this.llPlayTalkback.setVisibility(llPlayTalkbackVisible);
        this.mIsSpeaking = isSpeaking;
        if (isSleep) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void showToolsViews() {
        if (this.popupWindowMore != null) {
            this.popupWindowMore.dismiss();
        }
        this.nToolsViewShowTickCount = 5;
        if (this.bAnyway) {
            this.layoutTopBar.setVisibility(0);
            this.llVertical.setVisibility(0);
            this.llLandscape.setVisibility(8);
            return;
        }
        this.layoutBottomBar.setVisibility(0);
        if (this.camType == 1) {
            this.layoutCrossScreenMode.setVisibility(0);
        }
        this.layoutTopBar.setVisibility(8);
        this.llVertical.setVisibility(8);
        this.llLandscape.setVisibility(0);
    }

    private void hideToolsViews() {
        this.nToolsViewShowTickCount = 0;
        this.layoutBottomBar.setVisibility(8);
        this.layoutCrossScreenMode.setVisibility(8);
        this.layoutTopBar.setVisibility(8);
        this.llLandscape.setVisibility(8);
        this.llVertical.setVisibility(8);
    }

    private void startPTZXConfig(LoginHandle lhandle, int nPTZXID, int nPTZXAction, int nDeviceId) {
        this.m_nPTZXID++;
        new PTZXThread(this.handler, this.m_nPTZXID, lhandle, nPTZXID, nPTZXAction, nDeviceId).start();
    }

    private void locationPTZXPoint(int nPTZXID) {
        this.mNVPanoPlayer.CallPTZXLocationID(nPTZXID, this.deviceParam);
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long arg3) {
        if (((Integer) this.SelectAreaList.get(position)).intValue() == 0) {
            view.setBackgroundColor(Color.parseColor("#ff0000"));
            this.SelectAreaList.remove(position);
            this.SelectAreaList.add(position, Integer.valueOf(1));
            this.LocalAreaSelectmap.clear();
            view.getBackground().setAlpha(51);
            return;
        }
        view.setBackgroundColor(Color.parseColor("#000000"));
        view.getBackground().setAlpha(20);
        this.SelectAreaList.remove(position);
        this.SelectAreaList.add(position, Integer.valueOf(0));
        this.LocalAreaSelectmap.clear();
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 2 && !(permissions[0].equals("android.permission.RECORD_AUDIO") && grantResults[0] == 0)) {
            new Builder(this).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_microphone2)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent();
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", NVPlayerPlayFishEyeActivity.this.getPackageName(), null));
                    NVPlayerPlayFishEyeActivity.this.startActivity(intent);
                }
            }).show();
        }
        if (requestCode != 3) {
            return;
        }
        if (!permissions[0].equals("android.permission.WRITE_EXTERNAL_STORAGE") || grantResults[0] != 0) {
            new Builder(this).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_storage1)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent();
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", NVPlayerPlayFishEyeActivity.this.getPackageName(), null));
                    NVPlayerPlayFishEyeActivity.this.startActivity(intent);
                }
            }).show();
        }
    }

    private void exitPlayFisheye() {
        if (this.mIsPlaying) {
            View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
            ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.alert_stop_play));
            ((TextView) view.findViewById(C0470R.id.tv_content)).setVisibility(8);
            new Builder(this).setView(view).setNegativeButton(getString(C0470R.string.alert_btn_NO), null).setPositiveButton(getString(C0470R.string.alert_btn_YES), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    try {
                        NVPlayerPlayFishEyeActivity.this.stopPlay(false);
                    } catch (Exception e) {
                    }
                    NVPlayerPlayFishEyeActivity.this.setResult(-1);
                    NVPlayerPlayFishEyeActivity.this.mIsPlaying = false;
                    Intent intent = new Intent(NVPlayerPlayFishEyeActivity.this, HomePageActivity.class);
                    NVPlayerPlayFishEyeActivity.this.m_bFinish = true;
                    NVPlayerPlayFishEyeActivity.this.startActivity(intent);
                    LocalDefines.B_UPDATE_LISTVIEW = true;
                    NVPlayerPlayFishEyeActivity.this.unRegisterReceiver();
                    NVPlayerPlayFishEyeActivity.this.finish();
                    NVPlayerPlayFishEyeActivity.this.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                }
            }).show();
            return;
        }
        stopPlay(false);
        Intent intent = new Intent(this, HomePageActivity.class);
        this.m_bFinish = true;
        startActivity(intent);
        LocalDefines.B_UPDATE_LISTVIEW = true;
        unRegisterReceiver();
        finish();
        overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
    }

    private void registerReceiver(Context context) {
        IntentFilter filter = new IntentFilter();
        filter.addAction(LocalDefines.getReceiverActionString(context));
        this.mReceiver = new CloseActivityReceiver();
        registerReceiver(this.mReceiver, filter);
    }

    private void unRegisterReceiver() {
        if (this.mReceiver != null) {
            unregisterReceiver(this.mReceiver);
        }
    }

    private void stopCurrentActivityFromBroadcast() {
        if (this.mIsPlaying) {
            setResult(-1);
            stopPlay(false);
            this.m_bFinish = true;
            LocalDefines.B_UPDATE_LISTVIEW = true;
            unRegisterReceiver();
            finish();
            return;
        }
        stopPlay(false);
        this.m_bFinish = true;
        LocalDefines.B_UPDATE_LISTVIEW = true;
        unRegisterReceiver();
        finish();
    }
}
