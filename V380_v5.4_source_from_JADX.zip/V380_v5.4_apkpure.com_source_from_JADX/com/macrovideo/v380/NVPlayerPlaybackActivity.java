package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.sdk.custom.RecordFileInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.media.LibContext;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrovideo.sdk.media.NVMediaPlayer;
import com.macrovideo.sdk.media.Player;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@SuppressLint({"NewApi"})
public class NVPlayerPlaybackActivity extends Activity implements OnClickListener, OnTouchListener, OnSeekBarChangeListener {
    static final int CMD_ACCEPT = 37124;
    static final int CMD_AFFIRM = 37122;
    static final int CMD_ASKFORCNLNUM = 37128;
    static final int CMD_CHECKPSW = 37129;
    static final int CMD_CONNECTINFO = 37125;
    static final int CMD_EXIT = 37123;
    static final int CMD_REQUEST = 37121;
    static final int CMD_STREAMHEAD = 37126;
    static final int CMD_UDPSHAKE = 37127;
    private static final int MY_PERMISSION_REQUEST_STORAGE = 0;
    static final int SEND_BUFFER_DATA_SIZE = 504;
    static final int SEND_BUFFER_HEADER_SIZE = 8;
    static final int SEND_BUFFER_SIZE = 512;
    static final int SESSION_FRAME_BUFFER_SIZE = 65536;
    static final short SHOWCODE_HAS_DATA = (short) 3001;
    static final short SHOWCODE_LOADING = (short) 1001;
    static final short SHOWCODE_NEW_IMAGE = (short) 1002;
    static final short SHOWCODE_STOP = (short) 2001;
    static final short SHOWCODE_VIDEO = (short) 1004;
    static final int SIZE_CMDPACKET = 128;
    static final int SP_DATA = 127;
    static final short STAT_CONNECTING = (short) 2001;
    static final short STAT_DECODE = (short) 2003;
    static final short STAT_DISCONNECT = (short) 2005;
    static final short STAT_LOADING = (short) 2002;
    static final short STAT_MR_BUSY = (short) 2007;
    static final short STAT_MR_DISCONNECT = (short) 2008;
    static final short STAT_RESTART = (short) 2006;
    static final short STAT_STOP = (short) 2004;
    static String endTimetxt;
    static String startTimetxt;
    static int time_display;
    static int totaltime;
    private LinearLayout LayoutSeekBar;
    private RelativeLayout RlPlayerDevice;
    private TextView Time_display_view;
    private boolean bAnyway = true;
    Bitmap bm = null;
    private RelativeLayout bottomButton;
    private LinearLayout bottomButtonHorizontal;
    private Button btnCatpure;
    private Button btnCatpureHorizontal;
    private Button btnLastFile;
    private Button btnLastFileHorizontal;
    private Button btnNextFile;
    private Button btnNextFileHorizontal;
    private Button btnRepeat = null;
    LinearLayout container = null;
    LinearLayout[] containers = new LinearLayout[4];
    private LoginHandle deviceParam = null;
    String folderName = "iCamSeeImages";
    NVMediaPlayer[] glViews = new NVMediaPlayer[4];
    private Handler handler = new C04081();
    private View iamgeViewConctentView = null;
    private ImageView[] img_v = new ImageView[4];
    private LinearLayout layoutBottomBar;
    private LinearLayout layoutCenter = null;
    private LinearLayout layoutTopBar = null;
    private int listID = 0;
    private LinearLayout llVideoPalyBakc;
    private LinearLayout llVideoPalyBakcHorizontal;
    private ImageView mBtnBack;
    private ImageView mBtnBackHorizontal;
    private Button mBtnSound;
    private Button mBtnSoundHorizontal;
    private Button mBtnStopAndPlay;
    private Button mBtnStopAndPlayHorizontal;
    private boolean mIsFinish = false;
    private boolean mIsOnDropUp = true;
    private boolean mIsPlaying = false;
    private boolean mIsToPlay = false;
    private boolean mPlaySound = true;
    private CloseActivityReceiver mReceiver;
    int mScreenHeight = 0;
    int mScreenWidth = 0;
    private TextView mTVTopServer = null;
    private boolean m_bFinish = false;
    private int m_nMRPort = 80;
    private int m_nPort = 5050;
    private String m_strFileName = Constants.MAIN_VERSION_TAG;
    private String m_strIP = "127.0.0.1";
    private String m_strLanIP = "127.0.0.1";
    private String m_strMRServer = Constants.MAIN_VERSION_TAG;
    private String m_strPassword = Constants.MAIN_VERSION_TAG;
    private String m_strUsername = "admin";
    private NVMediaPlayer mvMediaPlayer = null;
    private int nPlayerFileTime;
    private int nPlayerTime = 0;
    private int nScreenOrientation = 1;
    private int nToolsViewShowTickCount = 8;
    private View[] parentContainers = new View[4];
    private Activity relateAtivity = null;
    private Dialog screenshotDialog = null;
    private SeekBar seekBarPlayProgress = null;
    private SeekBar seekBarPlayProgressHorizontal = null;
    private int timerThreadID = 0;
    private View[] top_bottom = new View[2];
    private TextView tvStartTime;
    private TextView tvStartTimeHorizontal;
    private TextView tvStopTime;
    private TextView tvStopTimeHorizontal;

    class C04081 extends Handler {
        C04081() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 != 4) {
                if (msg.arg1 == 3) {
                    if (NVPlayerPlaybackActivity.this.nScreenOrientation == 2) {
                        NVPlayerPlaybackActivity.this.hideToolsViews();
                    }
                } else if (msg.arg1 == 2) {
                    String strPlayer;
                    NVPlayerPlaybackActivity.this.mIsOnDropUp = false;
                    NVPlayerPlaybackActivity.this.seekBarPlayProgress.setProgress(msg.arg2);
                    NVPlayerPlaybackActivity.this.seekBarPlayProgressHorizontal.setProgress(msg.arg2);
                    NVPlayerPlaybackActivity nVPlayerPlaybackActivity = NVPlayerPlaybackActivity.this;
                    nVPlayerPlaybackActivity.nPlayerTime = nVPlayerPlaybackActivity.nPlayerTime + 1;
                    if (NVPlayerPlaybackActivity.this.nPlayerTime >= 60) {
                        strPlayer = new StringBuilder(String.valueOf(NVPlayerPlaybackActivity.this.nPlayerTime / 60)).append(":").append(NVPlayerPlaybackActivity.this.nPlayerTime % 60).toString();
                    } else {
                        strPlayer = "00:" + NVPlayerPlaybackActivity.this.nPlayerTime;
                    }
                    NVPlayerPlaybackActivity.startTimetxt = strPlayer;
                    NVPlayerPlaybackActivity.this.tvStartTime.setText(strPlayer);
                    NVPlayerPlaybackActivity.this.tvStartTimeHorizontal.setText(strPlayer);
                }
            }
        }
    }

    class C04092 implements DialogInterface.OnClickListener {
        C04092() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            NVPlayerPlaybackActivity.this.setResult(-1);
        }
    }

    class C04103 implements OnTouchListener {
        private long firstTouch = 0;
        private boolean isFullScreen = false;
        private long secondTouch = 0;

        C04103() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case 0:
                    this.secondTouch = event.getDownTime();
                    if (this.secondTouch - this.firstTouch <= 350) {
                        if (!this.isFullScreen) {
                            this.isFullScreen = true;
                            NVPlayerPlaybackActivity.this.FullScreenMode(0);
                            LibContext.SwitchPlayingMode(0, this.isFullScreen);
                            break;
                        }
                        this.isFullScreen = false;
                        NVPlayerPlaybackActivity.this.ExitFullScreenMode(0);
                        LibContext.SwitchPlayingMode(0, this.isFullScreen);
                        break;
                    }
                    this.firstTouch = this.secondTouch;
                    if (Player.isWindowSelected(0)) {
                        Player.isWindowPlaying(0);
                        break;
                    }
                    break;
            }
            return false;
        }
    }

    class C04114 implements OnTouchListener {
        private long firstTouch = 0;
        private boolean isFullScreen = false;
        private long secondTouch = 0;

        C04114() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case 0:
                    this.secondTouch = event.getDownTime();
                    if (this.secondTouch - this.firstTouch <= 350) {
                        if (!this.isFullScreen) {
                            this.isFullScreen = true;
                            NVPlayerPlaybackActivity.this.FullScreenMode(1);
                            LibContext.SwitchPlayingMode(1, this.isFullScreen);
                            break;
                        }
                        this.isFullScreen = false;
                        NVPlayerPlaybackActivity.this.ExitFullScreenMode(1);
                        LibContext.SwitchPlayingMode(1, this.isFullScreen);
                        break;
                    }
                    this.firstTouch = this.secondTouch;
                    if (Player.isWindowSelected(1)) {
                        Player.isWindowPlaying(1);
                        break;
                    }
                    break;
            }
            return false;
        }
    }

    class C04125 implements OnTouchListener {
        private long firstTouch = 0;
        private boolean isFullScreen = false;
        private long secondTouch = 0;

        C04125() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case 0:
                    this.secondTouch = event.getDownTime();
                    if (this.secondTouch - this.firstTouch <= 350) {
                        if (!this.isFullScreen) {
                            this.isFullScreen = true;
                            NVPlayerPlaybackActivity.this.FullScreenMode(2);
                            LibContext.SwitchPlayingMode(2, this.isFullScreen);
                            break;
                        }
                        this.isFullScreen = false;
                        NVPlayerPlaybackActivity.this.ExitFullScreenMode(2);
                        LibContext.SwitchPlayingMode(2, this.isFullScreen);
                        break;
                    }
                    this.firstTouch = this.secondTouch;
                    if (Player.isWindowSelected(2)) {
                        Player.isWindowPlaying(2);
                        break;
                    }
                    break;
            }
            return false;
        }
    }

    class C04136 implements OnTouchListener {
        private long firstTouch = 0;
        private boolean isFullScreen = false;
        private long secondTouch = 0;

        C04136() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case 0:
                    this.secondTouch = event.getDownTime();
                    if (this.secondTouch - this.firstTouch <= 350) {
                        if (!this.isFullScreen) {
                            this.isFullScreen = true;
                            NVPlayerPlaybackActivity.this.FullScreenMode(3);
                            LibContext.SwitchPlayingMode(3, this.isFullScreen);
                            break;
                        }
                        this.isFullScreen = false;
                        NVPlayerPlaybackActivity.this.ExitFullScreenMode(3);
                        LibContext.SwitchPlayingMode(3, this.isFullScreen);
                        break;
                    }
                    this.firstTouch = this.secondTouch;
                    if (Player.isWindowSelected(3)) {
                        Player.isWindowPlaying(3);
                        break;
                    }
                    break;
            }
            return false;
        }
    }

    class C04147 implements OnTouchListener {
        C04147() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            Log.d("close", "close player 0");
            Player.ClearGLESScreen(NVPlayerPlaybackActivity.this.glViews, false, 0);
            return false;
        }
    }

    class C04158 implements OnTouchListener {
        C04158() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            Log.d("close", "close player 1");
            Player.ClearGLESScreen(NVPlayerPlaybackActivity.this.glViews, false, 1);
            return false;
        }
    }

    class C04169 implements OnTouchListener {
        C04169() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            Log.d("close", "close player 2");
            Player.ClearGLESScreen(NVPlayerPlaybackActivity.this.glViews, false, 2);
            return false;
        }
    }

    class CloseActivityReceiver extends BroadcastReceiver {
        CloseActivityReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = LocalDefines.getReceiverActionString(NVPlayerPlaybackActivity.this);
            if (intent != null && intent.getAction().equals(action)) {
                NVPlayerPlaybackActivity.this.stopCurrentActivityFromBroadcast();
            }
        }
    }

    class TimerThread extends Thread {
        int mThreadID = 0;

        public TimerThread(int nThreadID) {
            this.mThreadID = nThreadID;
        }

        public void run() {
            while (this.mThreadID == NVPlayerPlaybackActivity.this.timerThreadID) {
                NVPlayerPlaybackActivity nVPlayerPlaybackActivity = NVPlayerPlaybackActivity.this;
                nVPlayerPlaybackActivity.nToolsViewShowTickCount = nVPlayerPlaybackActivity.nToolsViewShowTickCount - 1;
                if (NVPlayerPlaybackActivity.this.nToolsViewShowTickCount <= 0 && this.mThreadID == NVPlayerPlaybackActivity.this.timerThreadID) {
                    Message message = new Message();
                    message.arg1 = 3;
                    NVPlayerPlaybackActivity.this.handler.sendMessage(message);
                    NVPlayerPlaybackActivity.this.nToolsViewShowTickCount = 0;
                }
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            exitCurrentActivity();
        }
        return false;
    }

    public boolean writeSystemParam() {
        Editor editer = getSharedPreferences(Defines._fileName, 0).edit();
        editer.putBoolean("sound", this.mPlaySound);
        editer.commit();
        return true;
    }

    private void ShowAlert(String title, String msg) {
        try {
            new Builder(this).setTitle(title).setMessage(msg).setIcon(C0470R.drawable.icon).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C04092()).show();
        } catch (Exception e) {
        }
    }

    public void onPause() {
        if (this.mIsPlaying) {
            PausePlay();
        }
        OnPlayersPuase();
        super.onPause();
    }

    protected void onStart() {
        super.onStart();
    }

    public void onResume() {
        super.onResume();
        this.nToolsViewShowTickCount = 8;
        this.timerThreadID++;
        new TimerThread(this.timerThreadID).start();
        if (!this.mIsFinish) {
            if (this.mIsPlaying) {
                ResumePlay();
            } else if (this.mIsToPlay) {
                startPlay();
            } else {
                stopPlay(true);
            }
        }
        OnPlayersResume();
        this.m_bFinish = false;
        ((NotificationManager) getSystemService("notification")).cancelAll();
    }

    public void onDestroy() {
        this.mvMediaPlayer = null;
        super.onDestroy();
    }

    public void onStop() {
        this.timerThreadID++;
        if (this.m_bFinish) {
            LibContext.stopAll();
            LibContext.ClearContext();
        } else {
            NotificationManager notiManager = (NotificationManager) getSystemService("notification");
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
            builder.setContentTitle(getString(C0470R.string.app_name)).setContentText(getString(C0470R.string.app_notice)).setTicker(getString(C0470R.string.app_name)).setWhen(System.currentTimeMillis()).setOngoing(false);
            if (VERSION.SDK_INT >= 23) {
                builder.setSmallIcon(C0470R.drawable.my_device_3);
                builder.setLargeIcon(Functions.readBitMap(this, C0470R.drawable.icon));
            } else {
                builder.setSmallIcon(C0470R.drawable.icon_1);
            }
            notiManager.notify(257, builder.build());
            Intent intent = new Intent(this, NVPlayerPlaybackActivity.class);
            Bundle data = new Bundle();
            data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, this.deviceParam);
            data.putInt("play_index", this.listID);
            intent.putExtras(data);
            intent.setFlags(335544320);
            LibContext.stopAll();
        }
        this.m_bFinish = true;
        super.onStop();
    }

    private void ShowLandscapeView() {
        this.seekBarPlayProgress.setVisibility(8);
        this.tvStartTime.setVisibility(8);
        this.tvStopTime.setVisibility(8);
        synchronized (this) {
            this.nToolsViewShowTickCount = 5;
            this.bAnyway = false;
            showToolsViews();
            int nWidth = this.mScreenWidth;
            int nHeight = this.mScreenHeight;
            double dWidth = ((double) nHeight) * 1.7777777d;
            if (dWidth < ((double) nWidth)) {
                nWidth = (int) dWidth;
            }
            if (this.layoutCenter != null) {
                LayoutParams rlp = new LayoutParams(nWidth, nHeight);
                rlp.addRule(13, -1);
                this.layoutCenter.setLayoutParams(rlp);
                this.layoutCenter.setPadding(0, 0, 0, 0);
            }
            this.container.setPadding(0, 0, 0, 0);
            this.nScreenOrientation = 2;
            this.mvMediaPlayer.onOreintationChange(this.nScreenOrientation);
        }
    }

    private void ShowPortrailView() {
        this.seekBarPlayProgress.setVisibility(0);
        synchronized (this) {
            float scale = getResources().getDisplayMetrics().density;
            int padding_in_px = (int) ((((float) 45) * scale) + 0.5f);
            this.bAnyway = true;
            showToolsViews();
            int nWidth = this.mScreenWidth;
            int nHeight = (int) ((((float) this.mScreenHeight) - ((185.0f * scale) + 0.5f)) - ((float) LocalDefines.getStatusBarHeight(this)));
            if (this.layoutCenter != null) {
                LayoutParams rlp = new LayoutParams(nWidth, nHeight);
                rlp.addRule(10, -1);
                this.layoutCenter.setLayoutParams(rlp);
                this.layoutCenter.setPadding(0, padding_in_px, 0, 0);
            }
            int padding = (int) ((((double) (nHeight - padding_in_px)) - (((double) nWidth) * 0.85d)) / 2.0d);
            if (padding > 0) {
                this.container.setPadding(0, padding, 0, padding);
            }
            this.nScreenOrientation = 1;
            this.mvMediaPlayer.onOreintationChange(this.nScreenOrientation);
        }
    }

    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        this.mScreenWidth = dm.widthPixels;
        this.mScreenHeight = dm.heightPixels;
        LocalDefines.loadResource(getResources());
        if (config.orientation == 2) {
            ShowLandscapeView();
        } else if (config.orientation == 1) {
            ShowPortrailView();
        }
    }

    void SetCloseButtonVisible(boolean isVisible) {
        if (isVisible) {
            this.img_v[0].setVisibility(0);
            this.img_v[1].setVisibility(0);
            this.img_v[2].setVisibility(0);
            this.img_v[3].setVisibility(0);
            return;
        }
        this.img_v[0].setVisibility(8);
        this.img_v[1].setVisibility(8);
        this.img_v[2].setVisibility(8);
        this.img_v[3].setVisibility(8);
    }

    public void InitGLViewPlayer() {
        for (int i = 0; i < 4; i++) {
            this.glViews[i] = new NVMediaPlayer(getApplication(), this.nScreenOrientation, i);
            this.glViews[i].setRenderMode(0);
        }
    }

    public void ReleaseGLViewPlayer() {
        if (this.mvMediaPlayer != null) {
            this.mvMediaPlayer.DisableRender();
            this.mvMediaPlayer = null;
        }
    }

    public void OnPlayersPuase() {
        for (int i = 0; i < 4; i++) {
            if (this.glViews[i] != null) {
                this.glViews[i].onPause();
            }
        }
    }

    public void OnPlayersResume() {
        for (int i = 0; i < 4; i++) {
            if (this.glViews[i] != null) {
                this.glViews[i].onResume();
            }
        }
    }

    private void InitGLViewTouchEvent() {
        this.glViews[0].setOnTouchListener(new C04103());
        this.glViews[1].setOnTouchListener(new C04114());
        this.glViews[2].setOnTouchListener(new C04125());
        this.glViews[3].setOnTouchListener(new C04136());
        this.img_v[0].setOnTouchListener(new C04147());
        this.img_v[1].setOnTouchListener(new C04158());
        this.img_v[2].setOnTouchListener(new C04169());
        this.img_v[3].setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                Log.d("close", "close player 3");
                Player.ClearGLESScreen(NVPlayerPlaybackActivity.this.glViews, false, 3);
                return false;
            }
        });
    }

    public void FullScreenMode(int WndID) {
        switch (WndID) {
            case 0:
                this.top_bottom[0].setVisibility(0);
                this.parentContainers[1].setVisibility(8);
                this.containers[1].setVisibility(8);
                this.glViews[1].setVisibility(8);
                this.top_bottom[1].setVisibility(8);
                this.parentContainers[2].setVisibility(8);
                this.containers[2].setVisibility(8);
                this.glViews[2].setVisibility(8);
                this.parentContainers[3].setVisibility(8);
                this.containers[3].setVisibility(8);
                this.glViews[3].setVisibility(8);
                return;
            case 1:
                this.top_bottom[0].setVisibility(0);
                this.parentContainers[0].setVisibility(8);
                this.containers[0].setVisibility(8);
                this.glViews[0].setVisibility(8);
                this.top_bottom[1].setVisibility(8);
                this.parentContainers[2].setVisibility(8);
                this.containers[2].setVisibility(8);
                this.glViews[2].setVisibility(8);
                this.parentContainers[3].setVisibility(8);
                this.containers[3].setVisibility(8);
                this.glViews[3].setVisibility(8);
                return;
            case 2:
                this.top_bottom[0].setVisibility(8);
                this.parentContainers[0].setVisibility(8);
                this.containers[0].setVisibility(8);
                this.glViews[0].setVisibility(8);
                this.parentContainers[1].setVisibility(8);
                this.containers[1].setVisibility(8);
                this.glViews[1].setVisibility(8);
                this.top_bottom[1].setVisibility(0);
                this.parentContainers[3].setVisibility(8);
                this.containers[3].setVisibility(8);
                this.glViews[3].setVisibility(8);
                return;
            case 3:
                this.top_bottom[0].setVisibility(8);
                this.parentContainers[0].setVisibility(8);
                this.containers[0].setVisibility(8);
                this.glViews[0].setVisibility(8);
                this.parentContainers[1].setVisibility(8);
                this.containers[1].setVisibility(8);
                this.glViews[1].setVisibility(8);
                this.top_bottom[1].setVisibility(0);
                this.parentContainers[2].setVisibility(8);
                this.containers[2].setVisibility(8);
                this.glViews[2].setVisibility(8);
                return;
            default:
                return;
        }
    }

    public void ExitFullScreenMode(int WndID) {
        this.top_bottom[0].setVisibility(0);
        this.parentContainers[0].setVisibility(0);
        this.containers[0].setVisibility(0);
        this.glViews[0].setVisibility(0);
        this.parentContainers[1].setVisibility(0);
        this.containers[1].setVisibility(0);
        this.glViews[1].setVisibility(0);
        this.top_bottom[1].setVisibility(0);
        this.parentContainers[2].setVisibility(0);
        this.containers[2].setVisibility(0);
        this.glViews[2].setVisibility(0);
        this.parentContainers[3].setVisibility(0);
        this.containers[3].setVisibility(0);
        this.glViews[3].setVisibility(0);
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(128, 128);
        requestWindowFeature(1);
        setRequestedOrientation(1);
        ((NotificationManager) getSystemService("notification")).cancel(257);
        setContentView(C0470R.layout.activity_nvplayer_playbackview);
        registerReceiver(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        this.mScreenWidth = dm.widthPixels;
        this.mScreenHeight = dm.heightPixels;
        init();
        Bundle data = getIntent().getExtras();
        if (data != null) {
            this.listID = data.getInt("play_index");
            this.deviceParam = (LoginHandle) data.getParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE);
        }
        this.mTVTopServer = (TextView) findViewById(C0470R.id.tvPlayerDevice);
        this.mTVTopServer.setText(this.m_strFileName);
        this.layoutTopBar = (LinearLayout) findViewById(C0470R.id.linearLayoutTopBar);
        this.layoutCenter = (LinearLayout) findViewById(C0470R.id.playbackContainer);
        this.layoutBottomBar = (LinearLayout) findViewById(C0470R.id.linearLayoutBottomBar);
        this.LayoutSeekBar = (LinearLayout) findViewById(C0470R.id.bg_seekbar);
        this.LayoutSeekBar.getBackground().setAlpha(95);
        this.container = (LinearLayout) findViewById(C0470R.id.playbackContainer1);
        this.mvMediaPlayer = new NVMediaPlayer(getApplication(), this.nScreenOrientation, 0);
        this.mvMediaPlayer.setRenderMode(0);
        this.mvMediaPlayer.GetHandler(this.handler);
        this.mvMediaPlayer.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                if (NVPlayerPlaybackActivity.this.getResources().getConfiguration().orientation == 2) {
                    if (NVPlayerPlaybackActivity.this.bottomButtonHorizontal.getVisibility() == 0) {
                        NVPlayerPlaybackActivity.this.hideToolsViews();
                    } else {
                        NVPlayerPlaybackActivity.this.showToolsViews();
                    }
                }
                return false;
            }
        });
        this.container.addView(this.mvMediaPlayer);
        InitGLViewPlayer();
        LibContext.SetContext(this.mvMediaPlayer, null, null, null);
        Player.SelectWindow(0);
        this.btnRepeat = (Button) findViewById(C0470R.id.btnRepeat1);
        this.btnRepeat.setOnClickListener(this);
        this.btnRepeat.setVisibility(8);
        this.mBtnBack = (ImageView) findViewById(C0470R.id.btnPBBackToLogin);
        this.mBtnBack.setOnClickListener(this);
        this.mBtnBackHorizontal = (ImageView) findViewById(C0470R.id.btnPBBackToLoginHprizontal);
        this.mBtnBackHorizontal.setOnClickListener(this);
        this.mBtnStopAndPlay = (Button) findViewById(C0470R.id.btnPBStopAndPlay);
        this.mBtnStopAndPlay.setOnClickListener(this);
        this.mBtnStopAndPlayHorizontal = (Button) findViewById(C0470R.id.btnPBStopAndPlayHorizontal);
        this.mBtnStopAndPlayHorizontal.setOnClickListener(this);
        this.mBtnSound = (Button) findViewById(C0470R.id.btnPBAudio);
        this.mBtnSound.setOnClickListener(this);
        this.mBtnSoundHorizontal = (Button) findViewById(C0470R.id.btnPBAudioHorizontal);
        this.mBtnSoundHorizontal.setOnClickListener(this);
        if (this.mPlaySound) {
            this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn));
            this.mBtnSoundHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal));
        } else {
            this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn2));
            this.mBtnSoundHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal2));
        }
        this.seekBarPlayProgress = (SeekBar) findViewById(C0470R.id.seekBarPlayProgress);
        this.seekBarPlayProgress.setOnSeekBarChangeListener(this);
        this.seekBarPlayProgress.setMax(100);
        this.seekBarPlayProgress.setProgress(0);
        this.seekBarPlayProgressHorizontal = (SeekBar) findViewById(C0470R.id.seekBarPlayProgressHorizontal);
        this.seekBarPlayProgressHorizontal.setOnSeekBarChangeListener(this);
        this.seekBarPlayProgressHorizontal.setMax(100);
        this.seekBarPlayProgressHorizontal.setProgress(0);
        this.mIsPlaying = false;
        this.mIsToPlay = true;
        ShowPortrailView();
        createDialogs();
    }

    private void init() {
        this.tvStartTime = (TextView) findViewById(C0470R.id.tvStartTime);
        this.tvStopTime = (TextView) findViewById(C0470R.id.tvStopTime);
        this.tvStartTimeHorizontal = (TextView) findViewById(C0470R.id.tvStartTimeHorizontal);
        this.tvStopTimeHorizontal = (TextView) findViewById(C0470R.id.tvStopTimeHorizontal);
        this.btnLastFile = (Button) findViewById(C0470R.id.btnLastFlie);
        this.btnLastFile.setOnClickListener(this);
        this.btnLastFileHorizontal = (Button) findViewById(C0470R.id.btnLastFlieHorizontal);
        this.btnLastFileHorizontal.setOnClickListener(this);
        this.btnNextFile = (Button) findViewById(C0470R.id.btnNextFile);
        this.btnNextFile.setOnClickListener(this);
        this.btnNextFileHorizontal = (Button) findViewById(C0470R.id.btnNextFileHorizontal);
        this.btnNextFileHorizontal.setOnClickListener(this);
        this.btnCatpure = (Button) findViewById(C0470R.id.btnCatpure);
        this.btnCatpure.setOnClickListener(this);
        this.btnCatpureHorizontal = (Button) findViewById(C0470R.id.btnCatpureHorizontal);
        this.btnCatpureHorizontal.setOnClickListener(this);
        this.bottomButtonHorizontal = (LinearLayout) findViewById(C0470R.id.bottomButtonHorizontal);
        this.bottomButtonHorizontal.getBackground().setAlpha(95);
        this.bottomButton = (RelativeLayout) findViewById(C0470R.id.bottomButton);
        this.llVideoPalyBakc = (LinearLayout) findViewById(C0470R.id.llVideoPalyBakc);
        this.llVideoPalyBakcHorizontal = (LinearLayout) findViewById(C0470R.id.llVideoPalyBakcHorizontal);
        this.RlPlayerDevice = (RelativeLayout) findViewById(C0470R.id.RlPlayerDevice);
        this.Time_display_view = (TextView) findViewById(C0470R.id.Time_display);
        this.Time_display_view.getBackground().setAlpha(95);
    }

    private void stopPlay(boolean bFlag) {
        if (this.seekBarPlayProgress != null) {
            this.seekBarPlayProgress.setProgress(0);
            this.seekBarPlayProgress.setEnabled(false);
        }
        if (this.seekBarPlayProgressHorizontal != null) {
            this.seekBarPlayProgressHorizontal.setProgress(0);
            this.seekBarPlayProgressHorizontal.setEnabled(false);
        }
        this.mIsFinish = false;
        this.mIsPlaying = false;
        this.mTVTopServer.setText(this.m_strFileName);
        this.mvMediaPlayer.StopPlayBack();
        this.mvMediaPlayer.pauseAudio();
        this.mBtnStopAndPlay.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn));
        this.mBtnStopAndPlayHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn_horziontal));
        this.mIsFinish = true;
    }

    private void startPlay() {
        this.mIsFinish = false;
        if (this.btnRepeat != null) {
            this.btnRepeat.setVisibility(8);
        }
        setRequestedOrientation(4);
        this.mvMediaPlayer.pauseAudio();
        this.mTVTopServer.setText(this.m_strFileName);
        if (Player.CurrentSelPlayer() < 4) {
            Player.setPlaying(Player.CurrentSelPlayer(), true);
            this.mvMediaPlayer.EnableRender();
            this.seekBarPlayProgress.setProgress(0);
            this.seekBarPlayProgressHorizontal.setProgress(0);
            RecordFileInfo recFile = (RecordFileInfo) LocalDefines.listMapPlayerBackFile.get(this.listID);
            if (recFile != null) {
                this.m_strFileName = recFile.getStrFileName();
                this.mTVTopServer.setText(this.m_strFileName);
                this.nPlayerFileTime = recFile.getuFileTimeLen();
                String strTime = Constants.MAIN_VERSION_TAG;
                this.nPlayerTime = 0;
                if (this.nPlayerFileTime >= 60) {
                    strTime = new StringBuilder(String.valueOf(this.nPlayerFileTime / 60)).append(":").append(this.nPlayerFileTime % 60).toString();
                    endTimetxt = strTime;
                    totaltime = totalSeconds("00:00", endTimetxt);
                } else {
                    strTime = "00:" + this.nPlayerFileTime;
                    endTimetxt = strTime;
                    totaltime = totalSeconds("00:00", endTimetxt);
                }
                this.tvStopTime.setText(strTime);
                this.tvStopTimeHorizontal.setText(strTime);
                if (this.mvMediaPlayer.StartPlayBack(0, this.deviceParam, recFile, this.mPlaySound)) {
                    this.mvMediaPlayer.playAudio();
                    this.mBtnStopAndPlay.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_stop_btn));
                    this.mBtnStopAndPlayHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_stop_btn_horziontal));
                    this.mIsPlaying = true;
                }
                if (this.seekBarPlayProgress != null) {
                    this.seekBarPlayProgress.setEnabled(true);
                }
                if (this.seekBarPlayProgressHorizontal != null) {
                    this.seekBarPlayProgressHorizontal.setEnabled(true);
                }
            }
        }
    }

    private void PausePlay() {
        if (this.seekBarPlayProgress != null) {
            this.seekBarPlayProgress.setProgress(0);
            this.seekBarPlayProgress.setEnabled(false);
        }
        if (this.seekBarPlayProgressHorizontal != null) {
            this.seekBarPlayProgressHorizontal.setProgress(0);
            this.seekBarPlayProgressHorizontal.setEnabled(false);
        }
        this.mIsFinish = false;
        this.mIsPlaying = false;
        this.mBtnStopAndPlay.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn));
        this.mBtnStopAndPlayHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn_horziontal));
        this.btnRepeat.setVisibility(0);
        this.mIsPlaying = false;
        this.mIsPlaying = false;
        this.mTVTopServer.setText(this.m_strFileName);
        this.mvMediaPlayer.pauseAudio();
        this.mvMediaPlayer.FinishPlayback();
        this.mIsFinish = true;
    }

    private void ResumePlay() {
    }

    public void onClick(View v) {
        boolean z = false;
        this.nToolsViewShowTickCount = 5;
        if (v != null) {
            final Handler han;
            switch (v.getId()) {
                case C0470R.id.btnRepeat1:
                    stopPlay(true);
                    startPlay();
                    return;
                case C0470R.id.btnCatpure:
                case C0470R.id.btnCatpureHorizontal:
                    if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                        this.screenshotDialog.show();
                        ScreenShot();
                        return;
                    }
                    ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 0);
                    return;
                case C0470R.id.btnLastFlie:
                case C0470R.id.btnLastFlieHorizontal:
                    if (this.listID - 1 >= 0) {
                        this.listID--;
                        stopPlay(false);
                        han = new Handler();
                        han.postDelayed(new Runnable() {
                            public void run() {
                                if (NVPlayerPlaybackActivity.this.mIsFinish) {
                                    NVPlayerPlaybackActivity.this.startPlay();
                                } else {
                                    han.postDelayed(this, 1000);
                                }
                            }
                        }, 1000);
                        return;
                    }
                    Toast.makeText(this, getString(C0470R.string.FileFirst), 0).show();
                    return;
                case C0470R.id.btnPBStopAndPlay:
                case C0470R.id.btnPBStopAndPlayHorizontal:
                    if (!this.mIsPlaying) {
                        z = true;
                    }
                    this.mIsPlaying = z;
                    if (this.mIsPlaying) {
                        startPlay();
                        return;
                    } else {
                        stopPlay(true);
                        return;
                    }
                case C0470R.id.btnNextFile:
                case C0470R.id.btnNextFileHorizontal:
                    if (this.listID + 1 < LocalDefines.listMapPlayerBackFile.size()) {
                        this.listID++;
                        stopPlay(true);
                        han = new Handler();
                        han.postDelayed(new Runnable() {
                            public void run() {
                                if (NVPlayerPlaybackActivity.this.mIsFinish) {
                                    NVPlayerPlaybackActivity.this.startPlay();
                                } else {
                                    han.postDelayed(this, 1000);
                                }
                            }
                        }, 1000);
                        return;
                    }
                    Toast.makeText(this, getString(C0470R.string.FileFinally), 0).show();
                    return;
                case C0470R.id.btnPBAudio:
                case C0470R.id.btnPBAudioHorizontal:
                    if (!this.mPlaySound) {
                        z = true;
                    }
                    this.mPlaySound = z;
                    if (this.mPlaySound) {
                        this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn));
                        this.mBtnSoundHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal));
                        this.mvMediaPlayer.playAudio();
                    } else {
                        this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn2));
                        this.mBtnSoundHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal2));
                        this.mvMediaPlayer.pauseAudio();
                    }
                    int nChn = Player.CurrentSelPlayer();
                    if (nChn >= 0 && nChn < 4) {
                        this.mvMediaPlayer.SetAudioParam(this.mPlaySound);
                    }
                    writeSystemParam();
                    return;
                case C0470R.id.btnPBBackToLogin:
                case C0470R.id.btnPBBackToLoginHprizontal:
                    exitCurrentActivity();
                    return;
                default:
                    return;
            }
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != 0) {
            return;
        }
        if (!permissions[0].equals("android.permission.WRITE_EXTERNAL_STORAGE") || grantResults[0] != 0) {
            new Builder(this).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_storage1)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent();
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", NVPlayerPlaybackActivity.this.getPackageName(), null));
                    NVPlayerPlaybackActivity.this.startActivity(intent);
                }
            }).show();
        }
    }

    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        this.Time_display_view.setText(getCheckTimeBySeconds((totaltime * progress) / 100, "00:00"));
        if (!this.mIsOnDropUp && this.mIsPlaying && progress >= 100) {
            this.mIsFinish = false;
            this.mIsPlaying = false;
            this.mBtnStopAndPlay.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn));
            this.mBtnStopAndPlayHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn_horziontal));
            this.seekBarPlayProgress.setEnabled(false);
            this.seekBarPlayProgressHorizontal.setEnabled(false);
            this.btnRepeat.setVisibility(0);
            this.mTVTopServer.setText(this.m_strFileName);
            this.mvMediaPlayer.pauseAudio();
            this.mvMediaPlayer.FinishPlayback();
            this.mIsFinish = true;
        }
        if (this.seekBarPlayProgress != null && this.seekBarPlayProgress.getProgress() == 100) {
            this.Time_display_view.setVisibility(8);
            this.seekBarPlayProgress.setProgress(0);
        }
        if (this.seekBarPlayProgressHorizontal != null && this.seekBarPlayProgressHorizontal.getProgress() == 100) {
            this.Time_display_view.setVisibility(8);
            this.seekBarPlayProgressHorizontal.setProgress(0);
        }
        this.mIsOnDropUp = true;
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        this.Time_display_view.setVisibility(0);
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
        this.Time_display_view.setVisibility(8);
        this.mvMediaPlayer.SetPlayIndex(seekBar.getProgress());
    }

    private void showToolsViews() {
        this.nToolsViewShowTickCount = 5;
        this.layoutBottomBar.setVisibility(0);
        this.layoutTopBar.setVisibility(0);
        if (this.bAnyway) {
            this.bottomButton.setVisibility(0);
            this.bottomButtonHorizontal.setVisibility(8);
            this.llVideoPalyBakc.setVisibility(0);
            this.llVideoPalyBakcHorizontal.setVisibility(8);
            this.RlPlayerDevice.setVisibility(0);
            return;
        }
        this.bottomButtonHorizontal.setVisibility(0);
        this.bottomButton.setVisibility(8);
        this.llVideoPalyBakc.setVisibility(8);
        this.llVideoPalyBakcHorizontal.setVisibility(0);
        this.RlPlayerDevice.setVisibility(8);
    }

    private void hideToolsViews() {
        this.nToolsViewShowTickCount = 0;
        this.layoutBottomBar.setVisibility(8);
        this.layoutTopBar.setVisibility(8);
        this.bottomButtonHorizontal.setVisibility(8);
        this.bottomButton.setVisibility(8);
    }

    private void createDialogs() {
        this.iamgeViewConctentView = LayoutInflater.from(this).inflate(C0470R.layout.screenshotdialog, null);
        this.screenshotDialog = new Dialog(this, C0470R.style.progressDialog);
        this.screenshotDialog.setContentView(this.iamgeViewConctentView);
        this.screenshotDialog.setOnShowListener(new OnShowListener() {
            public void onShow(DialogInterface dialog) {
                Message msg = NVPlayerPlaybackActivity.this.handler.obtainMessage();
                msg.arg1 = 4;
                NVPlayerPlaybackActivity.this.handler.sendMessage(msg);
            }
        });
        this.screenshotDialog.setOnDismissListener(new OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
            }
        });
    }

    @SuppressLint({"SimpleDateFormat"})
    private void ScreenShot() {
        String strSavePath = Functions.GetSDPath();
        if (strSavePath == null) {
            this.screenshotDialog.dismiss();
            Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeSDCardNotExist), 0).show();
            return;
        }
        this.bm = this.mvMediaPlayer.Screenshot();
        if (this.bm != null) {
            this.bm.recycle();
            this.bm = null;
            this.bm = Bitmap.createBitmap(Defines._capWidth, Defines._capHeight, Config.RGB_565);
            this.bm.copyPixelsFromBuffer(Defines._capbuffer);
            Defines._capbuffer.position(0);
        }
        if (this.bm != null) {
            String strFileName = new StringBuilder(String.valueOf(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()))).append("(").append(this.m_strFileName).append(")").append(".jpg").toString();
            if (saveToSDCard(this.bm, strFileName)) {
                this.screenshotDialog.dismiss();
                Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeFileSaveToAlbumsOK), 0).show();
                return;
            }
            if (saveToSDCard(this.bm, new StringBuilder(String.valueOf(strSavePath)).append("/").append(strFileName).toString())) {
                this.screenshotDialog.dismiss();
                Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotOK), 0).show();
                return;
            }
            this.screenshotDialog.dismiss();
            Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotFail), 0).show();
            return;
        }
        this.screenshotDialog.dismiss();
        Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotFail), 0).show();
    }

    private boolean saveToSDCard(Bitmap image, String strFileName) {
        boolean bResult = false;
        if (image == null) {
            return 0;
        }
        try {
            File file = new File(Functions.GetSDPath() + File.separator + LocalDefines.SDCardPath);
            if (!file.exists()) {
                file.mkdir();
            }
            FileOutputStream out = new FileOutputStream(new File(file.getAbsolutePath() + File.separator + strFileName));
            image.compress(CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
            bResult = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return bResult;
    }

    public boolean onTouch(View v, MotionEvent event) {
        return false;
    }

    private static String getCheckTimeBySeconds(int progress, String startTime) {
        String return_h = Constants.MAIN_VERSION_TAG;
        String return_m = Constants.MAIN_VERSION_TAG;
        String return_s = Constants.MAIN_VERSION_TAG;
        String[] st = startTime.split(":");
        int st_m = Integer.valueOf(st[0]).intValue();
        int st_s = Integer.valueOf(st[1]).intValue();
        int m = (progress % 3600) / 60;
        int s = progress % 60;
        if (s + st_s >= 60) {
            int tmpSecond = (s + st_s) % 60;
            m++;
            if (tmpSecond >= 10) {
                return_s = new StringBuilder(String.valueOf(tmpSecond)).toString();
            } else {
                return_s = "0" + tmpSecond;
            }
        } else if (s + st_s >= 10) {
            return_s = new StringBuilder(String.valueOf(s + st_s)).toString();
        } else {
            return_s = "0" + (s + st_s);
        }
        if (m + st_m >= 60) {
            int tmpMin = (m + st_m) % 60;
            if (tmpMin >= 10) {
                return_m = new StringBuilder(String.valueOf(tmpMin)).toString();
            } else {
                return_m = "0" + tmpMin;
            }
        } else if (m + st_m >= 10) {
            return_m = new StringBuilder(String.valueOf(m + st_m)).toString();
        } else {
            return_m = "0" + (m + st_m);
        }
        return new StringBuilder(String.valueOf(return_m)).append(":").append(return_s).toString();
    }

    private static int totalSeconds(String startTime, String endTime) {
        String[] st = startTime.split(":");
        String[] et = endTime.split(":");
        int st_m = Integer.valueOf(st[0]).intValue();
        int st_s = Integer.valueOf(st[1]).intValue();
        return ((Integer.valueOf(et[0]).intValue() - st_m) * 60) + (Integer.valueOf(et[1]).intValue() - st_s);
    }

    private void exitCurrentActivity() {
        if (this.mIsPlaying) {
            View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
            ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.alert_stop_play));
            ((TextView) view.findViewById(C0470R.id.tv_content)).setVisibility(8);
            new Builder(this).setView(view).setNegativeButton(getString(C0470R.string.alert_btn_Cancel), null).setPositiveButton(getString(C0470R.string.alert_btn_OK), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    try {
                        NVPlayerPlaybackActivity.this.stopPlay(false);
                    } catch (Exception e) {
                    }
                    NVPlayerPlaybackActivity.this.setResult(-1);
                    NVPlayerPlaybackActivity.this.mIsPlaying = false;
                    Intent intent = new Intent(NVPlayerPlaybackActivity.this, HomePageActivity.class);
                    NVPlayerPlaybackActivity.this.m_bFinish = true;
                    Bundle data = new Bundle();
                    data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, NVPlayerPlaybackActivity.this.deviceParam);
                    data.putInt("play_index", NVPlayerPlaybackActivity.this.listID);
                    data.putBoolean("is_file_list_visible", true);
                    data.putBoolean("rec_load_from_db", true);
                    intent.putExtras(data);
                    NVPlayerPlaybackActivity.this.startActivity(intent);
                    LocalDefines.PLAY_BACK_BACK = true;
                    NVPlayerPlaybackActivity.this.unRegisterReceiver();
                    NVPlayerPlaybackActivity.this.finish();
                    NVPlayerPlaybackActivity.this.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                }
            }).show();
            return;
        }
        stopPlay(false);
        Intent intent = new Intent(this, HomePageActivity.class);
        this.m_bFinish = true;
        Bundle data = new Bundle();
        data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, this.deviceParam);
        data.putInt("play_index", this.listID);
        data.putBoolean("is_file_list_visible", true);
        data.putBoolean("rec_load_from_db", true);
        intent.putExtras(data);
        startActivity(intent);
        LocalDefines.PLAY_BACK_BACK = true;
        unRegisterReceiver();
        finish();
        overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
    }

    private void registerReceiver(Context context) {
        IntentFilter filter = new IntentFilter();
        filter.addAction(LocalDefines.getReceiverActionString(context));
        this.mReceiver = new CloseActivityReceiver();
        registerReceiver(this.mReceiver, filter);
    }

    private void unRegisterReceiver() {
        if (this.mReceiver != null) {
            unregisterReceiver(this.mReceiver);
        }
    }

    private void stopCurrentActivityFromBroadcast() {
        if (this.mIsPlaying) {
            try {
                stopPlay(false);
            } catch (Exception e) {
            }
            setResult(-1);
            this.mIsPlaying = false;
            this.m_bFinish = true;
            LocalDefines.PLAY_BACK_BACK = true;
            unRegisterReceiver();
            finish();
            return;
        }
        stopPlay(false);
        this.m_bFinish = true;
        LocalDefines.PLAY_BACK_BACK = true;
        unRegisterReceiver();
        finish();
    }
}
