package com.macrovideo.v380.wxapi;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.Toast;
import com.macrovideo.v380.C0470R;
import com.macrovideo.v380.LocalDefines;
import com.macrovideo.v380.WeChatPayActivity;
import com.macrovideo.v380.WeChatWebViewActivity;
import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import net.sourceforge.simcpux.Constants;

public class WXPayEntryActivity extends Activity implements IWXAPIEventHandler {
    private IWXAPI api;
    Builder builder;
    private int m_nActiveID = 0;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0470R.layout.pay_result);
        this.api = WXAPIFactory.createWXAPI(this, Constants.APP_ID);
        this.api.handleIntent(getIntent(), this);
    }

    protected void onStop() {
        this.m_nActiveID++;
        super.onStop();
    }

    protected void onResume() {
        super.onResume();
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        this.api.handleIntent(intent, this);
    }

    public void onReq(BaseReq req) {
    }

    public void onResp(BaseResp resp) {
        if (resp.getType() != 5) {
            return;
        }
        Intent intent;
        if (resp.errCode == 0) {
            intent = new Intent(this, WeChatWebViewActivity.class);
            intent.putExtra("url", new StringBuilder(LocalDefines.CLOUD_STORE_URL).append(WeChatWebViewActivity.mAccesstoken).append("&ver=").append(1).toString());
            startActivity(intent);
            finish();
            Toast.makeText(this, C0470R.string.str_wechatpay_successful, 0).show();
        } else if (resp.errCode == -1) {
            intent = new Intent(this, WeChatWebViewActivity.class);
            intent.putExtra("url", new StringBuilder(LocalDefines.CLOUD_STORE_URL).append(WeChatWebViewActivity.mAccesstoken).append("&ver=").append(1).toString());
            startActivity(intent);
            finish();
            Toast.makeText(this, C0470R.string.str_wechatpay_failed, 0).show();
        } else {
            intent = new Intent(this, WeChatPayActivity.class);
            intent.putExtra("paytocanel", true);
            intent.putExtra("WeChatData", com.tencent.android.tpush.common.Constants.MAIN_VERSION_TAG);
            startActivity(intent);
            finish();
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            this.m_nActiveID++;
            startActivity(new Intent(this, WeChatWebViewActivity.class));
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
