package com.macrovideo.v380;

public class ServerInfoForAlarm {
    long lLastMsgFreshTime = 0;
    long lLastMsgGetTime = 0;
    int nDevID = 0;
    int nID = -1;
    int nNewAlarmMsg = 0;
    String strPassword = null;
    String strUsername = null;

    public int getnID() {
        return this.nID;
    }

    public void setnID(int nID) {
        this.nID = nID;
    }

    public int getnDevID() {
        return this.nDevID;
    }

    public void setnDevID(int nDevID) {
        this.nDevID = nDevID;
    }

    public String getStrUsername() {
        return this.strUsername;
    }

    public void setStrUsername(String strUsername) {
        this.strUsername = strUsername;
    }

    public String getStrPassword() {
        return this.strPassword;
    }

    public void setStrPassword(String strPassword) {
        this.strPassword = strPassword;
    }

    public long getlLastMsgFreshTime() {
        return this.lLastMsgFreshTime;
    }

    public void setlLastMsgFreshTime(long lLastMsgFreshTime) {
        this.lLastMsgFreshTime = lLastMsgFreshTime;
    }

    public long getlLastMsgGetTime() {
        return this.lLastMsgGetTime;
    }

    public void setlLastMsgGetTime(long lLastMsgGetTime) {
        this.lLastMsgGetTime = lLastMsgGetTime;
    }

    public int getnNewAlarmMsg() {
        return this.nNewAlarmMsg;
    }

    public void setnNewAlarmMsg(int nNewAlarmMsg) {
        this.nNewAlarmMsg = nNewAlarmMsg;
    }

    public boolean isMatch(int nDevID, String strUsername, String strPassword) {
        if (this.nDevID != nDevID) {
            return false;
        }
        if ((this.strUsername == null || strUsername == null) && (this.strUsername != null || strUsername != null)) {
            return false;
        }
        if ((this.strPassword == null || strPassword == null) && (this.strPassword != null || strPassword != null)) {
            return false;
        }
        if (this.strUsername == null && strUsername == null && this.strPassword == null && strPassword == null) {
            return true;
        }
        if (this.strUsername == null && strUsername == null) {
            if (this.strPassword.equals(strPassword)) {
                return true;
            }
            return false;
        } else if (this.strPassword == null && strPassword == null) {
            if (this.strUsername.equals(strUsername)) {
                return true;
            }
            return false;
        } else if (this.strUsername.equals(strUsername) && this.strPassword.equals(strPassword)) {
            return true;
        } else {
            return false;
        }
    }

    public ServerInfoForAlarm(int nID, int nDevID, int nNewAlarmMsg, String strUsername, String strPassword, long lLastMsgFreshTime, long lLastMsgGetTime) {
        this.nID = nID;
        this.nDevID = nDevID;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.lLastMsgFreshTime = lLastMsgFreshTime;
        this.lLastMsgGetTime = lLastMsgGetTime;
        this.nNewAlarmMsg = nNewAlarmMsg;
    }
}
