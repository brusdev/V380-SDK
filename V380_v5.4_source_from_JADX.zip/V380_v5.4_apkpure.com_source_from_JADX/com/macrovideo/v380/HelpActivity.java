package com.macrovideo.v380;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ProgressBar;

public class HelpActivity extends Activity implements OnClickListener {
    private boolean isZh;
    private ImageView mIvBack;
    private ProgressBar mProgressBar;
    private WebView mWebViewHelp;
    private String urlConfigen = "http://www.av380.cn/seten.php";
    private String urlConfigzh = "http://www.av380.cn/set.php";
    private String urlEn;
    private String urlPlayBacken = "http://www.av380.cn/playbacken.php";
    private String urlPlayBackzh = "http://www.av380.cn/playback.php";
    private String urlZh;

    class C03601 extends WebViewClient {
        C03601() {
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
        }
    }

    class C03612 extends WebChromeClient {
        C03612() {
        }

        public void onProgressChanged(WebView view, int newProgress) {
            if (newProgress == 100) {
                HelpActivity.this.mProgressBar.setVisibility(8);
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_help);
        this.urlZh = getIntent().getStringExtra("urlZh");
        this.urlEn = getIntent().getStringExtra("urlEn");
        this.isZh = LocalDefines.isZh(this);
        InitViews();
    }

    private void InitViews() {
        this.mProgressBar = (ProgressBar) findViewById(C0470R.id.pb_activity_help);
        this.mIvBack = (ImageView) findViewById(C0470R.id.ivHelpBack);
        this.mIvBack.setOnClickListener(this);
        setWebView();
    }

    private void setWebView() {
        this.mWebViewHelp = (WebView) findViewById(C0470R.id.webView_help);
        this.mWebViewHelp.getSettings().setJavaScriptEnabled(true);
        this.mProgressBar.setVisibility(0);
        if (this.isZh) {
            this.mWebViewHelp.loadUrl(this.urlZh);
        } else {
            this.mWebViewHelp.loadUrl(this.urlEn);
        }
        this.mWebViewHelp.setWebViewClient(new C03601());
        this.mWebViewHelp.setWebChromeClient(new C03612());
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.mProgressBar.getVisibility() == 0) {
                this.mProgressBar.setVisibility(8);
                return super.onKeyDown(keyCode, event);
            } else if (this.mWebViewHelp.canGoBack()) {
                if (!this.mWebViewHelp.getUrl().contains("#top")) {
                    this.mWebViewHelp.goBack();
                } else if (this.mWebViewHelp.getUrl().contains(this.urlConfigen) || this.mWebViewHelp.getUrl().contains(this.urlConfigzh) || this.mWebViewHelp.getUrl().contains(this.urlPlayBacken) || this.mWebViewHelp.getUrl().contains(this.urlPlayBackzh)) {
                    finish();
                } else {
                    this.mWebViewHelp.goBackOrForward(-2);
                }
                return true;
            } else {
                finish();
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    public void onClick(View v) {
        if (v.getId() == C0470R.id.ivHelpBack) {
            if (this.mProgressBar.getVisibility() == 0) {
                this.mProgressBar.setVisibility(8);
            }
            if (!this.mWebViewHelp.canGoBack()) {
                finish();
            } else if (!this.mWebViewHelp.getUrl().contains("#top")) {
                this.mWebViewHelp.goBack();
            } else if (this.mWebViewHelp.getUrl().contains(this.urlConfigen) || this.mWebViewHelp.getUrl().contains(this.urlConfigzh) || this.mWebViewHelp.getUrl().contains(this.urlPlayBacken) || this.mWebViewHelp.getUrl().contains(this.urlPlayBackzh)) {
                finish();
            } else {
                this.mWebViewHelp.goBackOrForward(-2);
            }
        }
    }
}
