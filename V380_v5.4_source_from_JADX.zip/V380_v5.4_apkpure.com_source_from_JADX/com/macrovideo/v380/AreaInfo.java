package com.macrovideo.v380;

public class AreaInfo {
    private String area;
    private String country;

    public void setArea(String area) {
        this.area = area;
    }

    public String getArea() {
        return this.area;
    }

    public void setCountry(String Country) {
        this.country = Country;
    }

    public String getCountry() {
        return this.country;
    }
}
