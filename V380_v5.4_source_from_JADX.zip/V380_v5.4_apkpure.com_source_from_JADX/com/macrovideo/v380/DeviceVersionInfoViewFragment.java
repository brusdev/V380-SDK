package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.setting.DeviceVersionInfoAndUpdate;
import com.macrovideo.sdk.setting.VersionInfoAndUpdateInfo;
import com.tencent.android.tpush.common.Constants;

@SuppressLint({"ValidFragment"})
public class DeviceVersionInfoViewFragment extends Fragment implements OnClickListener {
    private static int BUTTON_TEXT = 546;
    private static int DEVICE_UPDATE = 0;
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    private Button btnNewVersion;
    private ImageView btnVerBack = null;
    private View contentView = null;
    private Handler handler = new C03501();
    private IntentFilter intentFilter;
    private boolean isActive = false;
    private boolean isGetFinish = false;
    private Dialog loadingDialog;
    private View loadingView;
    private boolean mIsNeedFresh = true;
    private int mLoadType = 1;
    private DeviceInfo mServerInfo = null;
    private int m_nVerInfoID = 0;
    private int nID = -1;
    private ProgressDialog progerDialog;
    private ProgressDialog progressDialog;
    private TabBroadcastReceiver receiver;
    private Activity relateAtivity = null;
    private TextView tvAPPVersion = null;
    private TextView tvHWVersion = null;
    private TextView tvKerVersion = null;
    private TextView tvVersionNotice = null;
    private VersionInfoAndUpdateInfo verInfo = new VersionInfoAndUpdateInfo();

    class C03501 extends Handler {
        C03501() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            if (msg.arg1 == DeviceVersionInfoViewFragment.BUTTON_TEXT) {
                DeviceVersionInfoViewFragment.this.btnNewVersion.setText(DeviceVersionInfoViewFragment.this.getString(C0470R.string.SoftwareeVersionNew));
                DeviceVersionInfoViewFragment.this.btnNewVersion.setEnabled(true);
                DeviceVersionInfoViewFragment.this.mServerInfo.setCanUpdateDevice(false);
                ((HomePageActivity) DeviceVersionInfoViewFragment.this.relateAtivity).setCanUpdateDeviceNum(((HomePageActivity) DeviceVersionInfoViewFragment.this.relateAtivity).getCanUpdateDeviceNum() - 1);
                DatabaseManager.UpdateServerInfoStateAndCanUpdateInfo(DeviceVersionInfoViewFragment.this.mServerInfo);
                Log.e("test", "update complete!");
                if (DeviceVersionInfoViewFragment.this.progerDialog != null) {
                    DeviceVersionInfoViewFragment.this.progerDialog.dismiss();
                }
            }
            if (DeviceVersionInfoViewFragment.this.progressDialog != null) {
                DeviceVersionInfoViewFragment.this.progressDialog.dismiss();
            }
            if (DeviceVersionInfoViewFragment.this.isActive) {
                DeviceVersionInfoViewFragment.this.mIsNeedFresh = false;
                VersionInfoAndUpdateInfo deviceVersion;
                if (msg.arg1 == 257) {
                    DeviceVersionInfoViewFragment.this.loadingDialog.dismiss();
                    String strAPPVersion = null;
                    String strAPPVersionDate = null;
                    String strKernalVersion = null;
                    String strKernalVersionDate = null;
                    String strHardwareVersion = null;
                    String strHardwareVersionnDate = null;
                    int n_DeviceVersionUpdateInformation = 0;
                    int n_DeviceVersionUpdate = 0;
                    String strDeviceNewVersionName = null;
                    DeviceVersionInfoViewFragment.this.tvVersionNotice.setText(DeviceVersionInfoViewFragment.this.getString(C0470R.string.getting_version_info_fail));
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceVersionInfoViewFragment.this.ShowAlert(DeviceVersionInfoViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceVersionInfoViewFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            DeviceVersionInfoViewFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceVersionInfoViewFragment.this.tvVersionNotice.setVisibility(8);
                            DeviceVersionInfoViewFragment.this.ShowAlert(DeviceVersionInfoViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceVersionInfoViewFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            DeviceVersionInfoViewFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceVersionInfoViewFragment.this.ShowAlert(DeviceVersionInfoViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceVersionInfoViewFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            DeviceVersionInfoViewFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceVersionInfoViewFragment.this.ShowAlert(DeviceVersionInfoViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceVersionInfoViewFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            DeviceVersionInfoViewFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceVersionInfoViewFragment.this.ShowAlert(DeviceVersionInfoViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceVersionInfoViewFragment.this.getString(C0470R.string.notice_Result_NetError));
                            DeviceVersionInfoViewFragment.this.ShowConfigSetting();
                            return;
                        case 256:
                            DeviceVersionInfoViewFragment.this.tvVersionNotice.setVisibility(8);
                            DeviceVersionInfoViewFragment.this.tvVersionNotice.setText(DeviceVersionInfoViewFragment.this.getString(C0470R.string.getting_version_info));
                            Bundle data = msg.getData();
                            if (data == null) {
                                DeviceVersionInfoViewFragment.this.ShowAlert(Constants.MAIN_VERSION_TAG, DeviceVersionInfoViewFragment.this.getString(C0470R.string.notice_Result_BadResult));
                                return;
                            }
                            DeviceVersionInfoViewFragment.this.isGetFinish = false;
                            deviceVersion = (VersionInfoAndUpdateInfo) data.get("device_version");
                            if (deviceVersion != null) {
                                int nDeviceID = DeviceVersionInfoViewFragment.this.mServerInfo.getnDevID();
                                strAPPVersion = deviceVersion.getStrAPPVersion();
                                strAPPVersionDate = deviceVersion.getStrAPPVersionDate();
                                strKernalVersion = deviceVersion.getStrKelVersion();
                                strKernalVersionDate = deviceVersion.getStrKelVersionDate();
                                strHardwareVersion = deviceVersion.getStrHWVersion();
                                strHardwareVersionnDate = deviceVersion.getStrHWVersionDate();
                                n_DeviceVersionUpdateInformation = deviceVersion.getnDeviceVersionUpdateInformation();
                                n_DeviceVersionUpdate = deviceVersion.getnDeviceVersionUpdate();
                                strDeviceNewVersionName = deviceVersion.getStrDeviceNewVersionName();
                            }
                            DeviceVersionInfoViewFragment.this.nID = DeviceVersionInfoViewFragment.this.mServerInfo.getnID();
                            DeviceVersionInfoViewFragment.this.verInfo.setStrAPPVersion(strAPPVersion);
                            DeviceVersionInfoViewFragment.this.verInfo.setStrAPPVersionDate(strAPPVersionDate);
                            DeviceVersionInfoViewFragment.this.verInfo.setStrKelVersion(strKernalVersion);
                            DeviceVersionInfoViewFragment.this.verInfo.setStrKelVersionDate(strKernalVersionDate);
                            DeviceVersionInfoViewFragment.this.verInfo.setStrHWVersion(strHardwareVersion);
                            DeviceVersionInfoViewFragment.this.verInfo.setStrHWVersionDate(strHardwareVersionnDate);
                            DeviceVersionInfoViewFragment.this.verInfo.setnDeviceVersionUpdateInformation(n_DeviceVersionUpdateInformation);
                            DeviceVersionInfoViewFragment.this.verInfo.setnDeviceVersionUpdate(n_DeviceVersionUpdate);
                            DeviceVersionInfoViewFragment.this.verInfo.setStrDeviceNewVersionName(strDeviceNewVersionName);
                            DeviceVersionInfoViewFragment.this.initUI();
                            return;
                        default:
                            DeviceVersionInfoViewFragment.this.tvVersionNotice.setVisibility(8);
                            DeviceVersionInfoViewFragment.this.ShowAlert(DeviceVersionInfoViewFragment.this.getString(C0470R.string.alert_get_config_fail), DeviceVersionInfoViewFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            DeviceVersionInfoViewFragment.this.ShowConfigSetting();
                            return;
                    }
                } else if (msg.arg1 == 227) {
                    DeviceVersionInfoViewFragment.this.loadingDialog.dismiss();
                    if (msg.arg2 == 256) {
                        deviceVersion = (VersionInfoAndUpdateInfo) msg.getData().get(Defines.RECORD_FILE_RETURN_MESSAGE);
                        int nOldVersionNum = deviceVersion.getnOldVersionNum();
                        String strOldVersionName = deviceVersion.getStrOldVersionName();
                        String strOldUpdateData = deviceVersion.getStrOldVersionUpdateTime();
                        int nNewVersionNum = deviceVersion.getnNewVersionNum();
                        String strNewVersionName = deviceVersion.getStrNewVersionName();
                        String strNewUpdateData = deviceVersion.getStrNewVersionUpdateTime();
                        String strNewFunction = deviceVersion.getStrNewVersionFunction();
                        DeviceVersionInfoViewFragment.DEVICE_UPDATE = 100;
                        DeviceVersionInfoViewFragment.this.tvVersionNotice.setVisibility(8);
                        DeviceVersionInfoViewFragment.this.btnNewVersion.setText(strNewVersionName);
                    } else if (msg.arg2 == 1019) {
                        DeviceVersionInfoViewFragment.DEVICE_UPDATE = 200;
                        Toast.makeText(DeviceVersionInfoViewFragment.this.getActivity(), DeviceVersionInfoViewFragment.this.getString(C0470R.string.NotNewVersion), 0).show();
                        DeviceVersionInfoViewFragment.this.btnNewVersion.setText(DeviceVersionInfoViewFragment.this.getString(C0470R.string.SoftwareUpdate));
                        DeviceVersionInfoViewFragment.this.tvVersionNotice.setVisibility(8);
                    } else if (msg.arg2 == 1020) {
                        Toast.makeText(DeviceVersionInfoViewFragment.this.getActivity(), DeviceVersionInfoViewFragment.this.getString(C0470R.string.NotNewVersion), 0).show();
                        DeviceVersionInfoViewFragment.DEVICE_UPDATE = 200;
                        DeviceVersionInfoViewFragment.this.tvVersionNotice.setVisibility(8);
                    } else if (msg.arg2 == 1021) {
                        DeviceVersionInfoViewFragment.this.btnNewVersion.setText(DeviceVersionInfoViewFragment.this.getString(C0470R.string.deviceUpdate));
                        DeviceVersionInfoViewFragment.this.btnNewVersion.setEnabled(false);
                        DeviceVersionInfoViewFragment.this.progerDialog = new ProgressDialog(DeviceVersionInfoViewFragment.this.getActivity());
                        DeviceVersionInfoViewFragment.this.progerDialog.setProgressStyle(0);
                        DeviceVersionInfoViewFragment.this.progerDialog.setMessage(new StringBuilder(String.valueOf(DeviceVersionInfoViewFragment.this.getString(C0470R.string.deviceUpdate))).append("...").toString());
                        DeviceVersionInfoViewFragment.this.progerDialog.setCanceledOnTouchOutside(false);
                        DeviceVersionInfoViewFragment.this.progerDialog.show();
                        new ThreadButton().start();
                        DeviceVersionInfoViewFragment.DEVICE_UPDATE = 200;
                        DeviceVersionInfoViewFragment.this.tvVersionNotice.setVisibility(8);
                    } else {
                        DeviceVersionInfoViewFragment.DEVICE_UPDATE = 200;
                        Toast.makeText(DeviceVersionInfoViewFragment.this.getActivity(), DeviceVersionInfoViewFragment.this.getString(C0470R.string.NotNewVersion), 0).show();
                        DeviceVersionInfoViewFragment.this.btnNewVersion.setText(DeviceVersionInfoViewFragment.this.getString(C0470R.string.SoftwareUpdate));
                        DeviceVersionInfoViewFragment.this.tvVersionNotice.setVisibility(8);
                    }
                }
            }
        }
    }

    class C03512 implements DialogInterface.OnClickListener {
        C03512() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            DeviceVersionInfoViewFragment.this.getVersionUpdate(DeviceVersionInfoViewFragment.this.mServerInfo);
            DeviceVersionInfoViewFragment.this.progressDialog.setMessage(Constants.MAIN_VERSION_TAG);
            DeviceVersionInfoViewFragment.this.progressDialog.show();
        }
    }

    class C03523 implements OnShowListener {
        C03523() {
        }

        public void onShow(DialogInterface dialog) {
            TextView tv = (TextView) DeviceVersionInfoViewFragment.this.loadingView.findViewById(C0470R.id.loginText);
            if (DeviceVersionInfoViewFragment.this.mLoadType == 1) {
                tv.setText(DeviceVersionInfoViewFragment.this.getString(C0470R.string.loading));
            } else if (DeviceVersionInfoViewFragment.this.mLoadType == 2) {
                tv.setText(DeviceVersionInfoViewFragment.this.getString(C0470R.string.str_saving));
            }
        }
    }

    class C03534 implements OnDismissListener {
        C03534() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class TabBroadcastReceiver extends BroadcastReceiver {
        TabBroadcastReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            intent.getAction().equals("TAB1_ACTION");
        }
    }

    private class ThreadButton extends Thread {
        private ThreadButton() {
        }

        public void run() {
            super.run();
            try {
                sleep(60000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message msg = DeviceVersionInfoViewFragment.this.handler.obtainMessage();
            msg.arg1 = DeviceVersionInfoViewFragment.BUTTON_TEXT;
            DeviceVersionInfoViewFragment.this.handler.sendMessage(msg);
        }
    }

    private class VersionInfoThread extends Thread {
        public void run() {
            VersionInfoAndUpdateInfo deviceVersion = DeviceVersionInfoAndUpdate.getVersionInfo(DeviceVersionInfoViewFragment.this.mServerInfo);
            if (deviceVersion != null) {
                int nConfigResult = deviceVersion.getnResult();
                Message msg;
                if (nConfigResult == 256) {
                    msg = DeviceVersionInfoViewFragment.this.handler.obtainMessage();
                    msg.arg1 = 257;
                    msg.arg2 = nConfigResult;
                    Bundle data = new Bundle();
                    data.putParcelable("device_version", deviceVersion);
                    msg.setData(data);
                    DeviceVersionInfoViewFragment.this.handler.sendMessage(msg);
                    return;
                }
                msg = DeviceVersionInfoViewFragment.this.handler.obtainMessage();
                msg.arg1 = 257;
                msg.arg2 = nConfigResult;
                DeviceVersionInfoViewFragment.this.handler.sendMessage(msg);
            }
        }
    }

    private class VersionUpateThread extends Thread {
        private Handler handler;

        public VersionUpateThread(Handler handler, int configID, int nDeviceID, String domain, String server, int port, String username, String password, int nServerType) {
            this.handler = handler;
        }

        public void run() {
            super.run();
            VersionInfoAndUpdateInfo deviceVersion;
            int nResult;
            Message msg;
            Bundle data;
            if (DeviceVersionInfoViewFragment.DEVICE_UPDATE == 100) {
                deviceVersion = DeviceVersionInfoAndUpdate.setVersionUpdate(DeviceVersionInfoViewFragment.this.mServerInfo);
                if (deviceVersion != null) {
                    nResult = deviceVersion.getnResult();
                    msg = this.handler.obtainMessage();
                    msg.arg1 = Defines.NV_IP_UPDATE_CHECK_RESPONSE;
                    msg.arg2 = nResult;
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceVersion);
                    msg.setData(data);
                    this.handler.sendMessage(msg);
                }
            } else if (DeviceVersionInfoViewFragment.DEVICE_UPDATE == 200) {
                deviceVersion = DeviceVersionInfoAndUpdate.getVersionUpdate(DeviceVersionInfoViewFragment.this.mServerInfo);
                if (deviceVersion != null) {
                    nResult = deviceVersion.getnResult();
                    msg = this.handler.obtainMessage();
                    msg.arg1 = Defines.NV_IP_UPDATE_CHECK_RESPONSE;
                    msg.arg2 = nResult;
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceVersion);
                    msg.setData(data);
                    this.handler.sendMessage(msg);
                }
            }
        }
    }

    public DeviceVersionInfoViewFragment(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public boolean isGetFinish() {
        return this.isGetFinish;
    }

    public VersionInfoAndUpdateInfo getVerInfo() {
        if (this.isGetFinish) {
            return this.verInfo;
        }
        return null;
    }

    public void setVerInfo(VersionInfoAndUpdateInfo verInfo) {
        if (this.verInfo == null) {
            this.verInfo = new VersionInfoAndUpdateInfo();
        }
        if (verInfo != null) {
            this.verInfo.setStrAPPVersion(verInfo.getStrAPPVersion());
            this.verInfo.setStrKelVersion(verInfo.getStrKelVersion());
            this.verInfo.setStrHWVersion(verInfo.getStrHWVersion());
            this.verInfo.setStrAPPVersionDate(verInfo.getStrAPPVersionDate());
            this.verInfo.setStrKelVersionDate(verInfo.getStrKelVersionDate());
            this.verInfo.setStrHWVersionDate(verInfo.getStrHWVersionDate());
        }
        this.verInfo = verInfo;
    }

    public void setServerInfo(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public void setNeedFreshInterface(boolean bNeedFresh) {
        this.mIsNeedFresh = bNeedFresh;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_version_info, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        InitSubView();
        this.progressDialog = new ProgressDialog(getActivity());
        this.progressDialog.setProgressStyle(0);
        this.progressDialog.setCanceledOnTouchOutside(false);
        return v;
    }

    public void onStop() {
        super.onStop();
        this.relateAtivity = null;
        this.isActive = false;
    }

    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(this.receiver);
    }

    public void onResume() {
        super.onResume();
        this.receiver = new TabBroadcastReceiver();
        getActivity().registerReceiver(this.receiver, getIntentFilter());
        this.relateAtivity = getActivity();
        this.isActive = true;
    }

    private IntentFilter getIntentFilter() {
        if (this.intentFilter == null) {
            this.intentFilter = new IntentFilter();
            this.intentFilter.addAction("TAB1_ACTION");
        }
        return this.intentFilter;
    }

    private void InitSubView() {
        createLoadingDialog();
        this.btnVerBack = (ImageView) this.contentView.findViewById(C0470R.id.btnVersionBack);
        this.btnVerBack.setOnClickListener(this);
        this.tvVersionNotice = (TextView) this.contentView.findViewById(C0470R.id.tvVerNotice);
        this.tvVersionNotice.setVisibility(8);
        this.tvAPPVersion = (TextView) this.contentView.findViewById(C0470R.id.tvAPPVer);
        this.tvKerVersion = (TextView) this.contentView.findViewById(C0470R.id.tvKelVer);
        this.tvHWVersion = (TextView) this.contentView.findViewById(C0470R.id.tvHWVer);
        if (this.mServerInfo == null || !this.mIsNeedFresh) {
            initUI();
        } else {
            getVersionInfo(this.mServerInfo);
        }
        this.btnNewVersion = (Button) this.contentView.findViewById(C0470R.id.btnNewVersion);
        this.btnNewVersion.setOnClickListener(this);
    }

    private void initUI() {
        if (this.verInfo != null) {
            this.tvAPPVersion.setText(new StringBuilder(String.valueOf(this.verInfo.getStrAPPVersion())).append("_").append(this.verInfo.getStrAPPVersionDate()).toString());
            this.tvKerVersion.setText(new StringBuilder(String.valueOf(this.verInfo.getStrKelVersion())).append("_").append(this.verInfo.getStrKelVersionDate()).toString());
            this.tvHWVersion.setText(new StringBuilder(String.valueOf(this.verInfo.getStrHWVersion())).append("_").append(this.verInfo.getStrHWVersionDate()).toString());
            if (this.verInfo.getnDeviceVersionUpdateInformation() > 0) {
                this.btnNewVersion.setVisibility(0);
                int nDeviceVersionUpdate = this.verInfo.getnDeviceVersionUpdate();
                if (nDeviceVersionUpdate == 1001) {
                    DEVICE_UPDATE = 200;
                    this.btnNewVersion.setText(getString(C0470R.string.SoftwareUpdate));
                    return;
                } else if (nDeviceVersionUpdate == 1000) {
                    DEVICE_UPDATE = 100;
                    String strDeviceVersionName = this.verInfo.getStrDeviceNewVersionName();
                    if (strDeviceVersionName == null || strDeviceVersionName.length() <= 0) {
                        this.btnNewVersion.setText(getString(C0470R.string.SoftwareNewVersion));
                        return;
                    } else {
                        this.btnNewVersion.setText(strDeviceVersionName);
                        return;
                    }
                } else {
                    return;
                }
            }
            this.btnNewVersion.setVisibility(4);
        }
    }

    public void ShowAlert(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowAlert(title, msg);
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.btnVersionBack:
                this.isGetFinish = false;
                ShowConfigSetting();
                return;
            case C0470R.id.btnNewVersion:
                if (DEVICE_UPDATE == 100) {
                    View view = View.inflate(getActivity(), C0470R.layout.show_alert_dialog, null);
                    ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.SoftwareversionUpdate));
                    ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.NewVersionUpdateOnOrOff));
                    new Builder(getActivity()).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C03512()).setNegativeButton(getString(C0470R.string.alert_btn_Cancel), null).show();
                    return;
                }
                getVersionUpdate(this.mServerInfo);
                this.progressDialog.setMessage(getString(C0470R.string.querySoftwareing) + "...");
                this.progressDialog.show();
                return;
            default:
                return;
        }
    }

    private void ShowConfigSetting() {
        this.m_nVerInfoID++;
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ChangeFragment(16, 13, this.mServerInfo);
        }
    }

    private void getVersionInfo(DeviceInfo info) {
        if (info != null) {
            this.m_nVerInfoID++;
            this.mLoadType = 1;
            this.loadingDialog.show();
            this.tvVersionNotice.setVisibility(0);
            this.tvVersionNotice.setText(getString(C0470R.string.getting_version_info));
            this.isGetFinish = false;
            new VersionInfoThread().start();
        }
    }

    private void getVersionUpdate(DeviceInfo info) {
        if (info != null) {
            this.m_nVerInfoID++;
            this.tvVersionNotice.setVisibility(0);
            this.tvVersionNotice.setText(getString(C0470R.string.getting_version_info));
            new VersionUpateThread(this.handler, this.m_nVerInfoID, info.getnDevID(), info.getStrDomain(), info.getStrIP(), info.getnPort(), info.getStrUsername(), info.getStrPassword(), info.getnSaveType()).start();
        }
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C03523());
        this.loadingDialog.setOnDismissListener(new C03534());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }
}
