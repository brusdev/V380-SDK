package com.macrovideo.v380;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.photo.ImageViewView;
import com.macrovideo.photo.StaticUtil;
import com.macrovideo.photo.ViewPagerActivity;
import com.macrovideo.sdk.tools.Functions;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PhotoFragment extends Fragment implements OnClickListener, OnItemClickListener {
    private static final int HANDLE_PHOTO_DELETE = 2;
    private static final int HANDLE_PHOTO_GET = 1;
    private static final String KEY_BITMAP = "image";
    private static final String KEY_IS_DELETE = "boolean";
    private static final String KEY_PHOTO_PATH = "imagePath";
    private static final String KEY_PHOTO_POSITION = "position";
    private static final int REQUEST_CODE_INTENT = 11;
    private static final int TYPE_DELETING = 2;
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SHARING = 3;
    public boolean bDelete = false;
    private boolean isLoadDataCompleted;
    private boolean isViewCreated;
    private LinearLayout llDelete;
    private LinearLayout llDeletePhoto;
    private LinearLayout llSelectAll;
    private LinearLayout llShare;
    private Dialog loadingDialog;
    private View loadingView;
    private PhotoManagerActivity mAttachActivity;
    private View mContentView;
    private GridView mGridView;
    private Handler mHandler = new C04421();
    boolean mIsSelectAll = false;
    private int mLoadType = 1;
    private PhotoAdapter mPhotoAdapter;
    private List<Map<String, Object>> mPhotoList = new ArrayList();

    class C04421 extends Handler {
        C04421() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    PhotoFragment.this.loadingDialog.dismiss();
                    PhotoFragment.this.isLoadDataCompleted = true;
                    PhotoFragment.this.mAttachActivity.hidePhotoSelectState();
                    return;
                case 2:
                    PhotoFragment.this.loadingDialog.dismiss();
                    PhotoFragment.this.mGridView.setEnabled(true);
                    PhotoFragment.this.mLoadType = 2;
                    PhotoFragment.this.loadingDialog.show();
                    new GetPhotosThread().start();
                    return;
                default:
                    return;
            }
        }
    }

    class C04432 implements OnShowListener {
        C04432() {
        }

        public void onShow(DialogInterface dialog) {
            TextView tv = (TextView) PhotoFragment.this.loadingView.findViewById(C0470R.id.loginText);
            if (PhotoFragment.this.mLoadType == 1) {
                tv.setText(PhotoFragment.this.getString(C0470R.string.loading));
            } else if (PhotoFragment.this.mLoadType == 2) {
                tv.setText(PhotoFragment.this.getString(C0470R.string.str_deleting));
            } else if (PhotoFragment.this.mLoadType == 3) {
                tv.setText(PhotoFragment.this.getString(C0470R.string.str_sharing));
            }
        }
    }

    class C04443 implements OnDismissListener {
        C04443() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    private class DeletePhotoThread extends Thread {
        private DeletePhotoThread() {
        }

        public void run() {
            if (PhotoFragment.this.mPhotoList != null && PhotoFragment.this.mPhotoList.size() > 0) {
                for (int i = 0; i < PhotoFragment.this.mPhotoList.size(); i++) {
                    Map<String, Object> map = (Map) PhotoFragment.this.mPhotoList.get(i);
                    if (((Boolean) map.get("boolean")).booleanValue()) {
                        File file = new File((String) map.get(PhotoFragment.KEY_PHOTO_PATH));
                        if (file.exists()) {
                            file.delete();
                        }
                    }
                }
                Message msg = PhotoFragment.this.mHandler.obtainMessage();
                msg.what = 2;
                PhotoFragment.this.mHandler.sendMessage(msg);
            }
        }
    }

    class GetPhotosThread extends Thread {
        GetPhotosThread() {
        }

        public void run() {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            if (PhotoFragment.this.mPhotoList == null) {
                PhotoFragment.this.mPhotoList = new ArrayList();
            } else {
                PhotoFragment.this.mPhotoList.clear();
            }
            Bitmap bitmap = null;
            List<String> photoPaths = ImageViewView.getImagePathFromSD(new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().toString())).append(File.separator).append(LocalDefines.SDCardPath).toString());
            if (photoPaths != null && photoPaths.size() > 0) {
                for (int i = 0; i < photoPaths.size(); i++) {
                    String photoPath = (String) photoPaths.get(i);
                    if (photoPath != null && photoPath.length() > 0) {
                        try {
                            Options options = new Options();
                            options.inJustDecodeBounds = true;
                            options.inPreferredConfig = Config.RGB_565;
                            BitmapFactory.decodeFile(photoPath, options);
                            options.inSampleSize = PhotoFragment.this.calculateInSampleSize(options, LocalDefines.dip2px(PhotoFragment.this.getActivity(), 60.0f), LocalDefines.dip2px(PhotoFragment.this.getActivity(), 45.0f));
                            options.inJustDecodeBounds = false;
                            bitmap = BitmapFactory.decodeFile(photoPath, options);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Map<String, Object> map = new HashMap();
                        map.put(PhotoFragment.KEY_BITMAP, bitmap);
                        map.put(PhotoFragment.KEY_PHOTO_PATH, photoPath);
                        map.put("boolean", Boolean.valueOf(false));
                        PhotoFragment.this.mPhotoList.add(map);
                    }
                }
            }
            StaticUtil._photoPaths = null;
            StaticUtil._photoPaths = photoPaths;
            Message msg = PhotoFragment.this.mHandler.obtainMessage();
            msg.what = 1;
            PhotoFragment.this.mHandler.sendMessage(msg);
        }
    }

    private class PhotoAdapter extends BaseAdapter {
        private ViewHolder holder;
        private String[] keyString;
        private List<Map<String, Object>> mAppList;
        private Context mContext;
        private int[] valueViewID;

        class ViewHolder {
            ImageView btnFace;
            ImageView ivDelete;

            ViewHolder() {
            }
        }

        public PhotoAdapter(Context context, List<Map<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = context;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(this.mContext, C0470R.layout.photo_gridview_item, null);
                this.holder = new ViewHolder();
                this.holder.btnFace = (ImageView) convertView.findViewById(this.valueViewID[0]);
                this.holder.ivDelete = (ImageView) convertView.findViewById(this.valueViewID[1]);
                convertView.setTag(this.holder);
            } else {
                this.holder = (ViewHolder) convertView.getTag();
            }
            Map<String, Object> map = (Map) this.mAppList.get(position);
            if (map != null && map.size() > 0) {
                Bitmap bitmap = (Bitmap) map.get(PhotoFragment.KEY_BITMAP);
                if (bitmap != null) {
                    this.holder.btnFace.setImageDrawable(new BitmapDrawable(bitmap));
                } else {
                    this.holder.btnFace.setImageDrawable(null);
                }
                if (PhotoFragment.this.bDelete) {
                    this.holder.ivDelete.setVisibility(0);
                } else {
                    this.holder.ivDelete.setVisibility(8);
                }
                if (((Boolean) map.get("boolean")).booleanValue()) {
                    this.holder.ivDelete.setImageResource(C0470R.drawable.delete_choose_2);
                } else {
                    this.holder.ivDelete.setImageResource(C0470R.drawable.delete_choose_1);
                }
            }
            return convertView;
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.mAttachActivity = (PhotoManagerActivity) getActivity();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        this.mContentView = inflater.inflate(C0470R.layout.fragment_photo_manager, container, false);
        initView();
        return this.mContentView;
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.isViewCreated = true;
    }

    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && this.isViewCreated && !this.isLoadDataCompleted) {
            LoadPhotos();
        }
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getUserVisibleHint()) {
            LoadPhotos();
        }
    }

    void LoadPhotos() {
        this.mLoadType = 1;
        this.loadingDialog.show();
        new GetPhotosThread().start();
    }

    public static PhotoFragment newInstance() {
        return new PhotoFragment();
    }

    private void initView() {
        this.mGridView = (GridView) this.mContentView.findViewById(C0470R.id.gv_photo);
        this.mGridView.setOnItemClickListener(this);
        this.llDeletePhoto = (LinearLayout) this.mContentView.findViewById(C0470R.id.llDeletePhoto);
        this.llDeletePhoto.setVisibility(8);
        this.llShare = (LinearLayout) this.mContentView.findViewById(C0470R.id.ll_share);
        this.llShare.setOnClickListener(this);
        this.llDelete = (LinearLayout) this.mContentView.findViewById(C0470R.id.ll_delete);
        this.llDelete.setOnClickListener(this);
        this.llSelectAll = (LinearLayout) this.mContentView.findViewById(C0470R.id.ll_select);
        this.llSelectAll.setOnClickListener(this);
        createLoadingDialog();
    }

    public void onClick(View v) {
        int i;
        Map<String, Object> map;
        switch (v.getId()) {
            case C0470R.id.ll_share:
                int listNum = this.mPhotoList.size();
                if (this.mPhotoList != null && listNum > 0) {
                    List<String> listPath = new ArrayList();
                    for (i = 0; i < listNum; i++) {
                        map = (Map) this.mPhotoList.get(i);
                        if (((Boolean) map.get("boolean")).booleanValue()) {
                            listPath.add((String) map.get(KEY_PHOTO_PATH));
                        }
                    }
                    if (listPath.size() == 0) {
                        Toast.makeText(this.mAttachActivity, getResources().getString(C0470R.string.str_photo_activity), 0).show();
                        return;
                    }
                    Functions.SharePhoto(listPath, this.mAttachActivity);
                    this.mAttachActivity.hidePhotoSelectState();
                    return;
                }
                return;
            case C0470R.id.ll_select:
                if (this.mPhotoList != null && this.mPhotoList.size() > 0) {
                    this.llSelectAll.setEnabled(false);
                    if (this.mIsSelectAll) {
                        this.mIsSelectAll = false;
                    } else {
                        this.mIsSelectAll = true;
                    }
                    for (i = 0; i < this.mPhotoList.size(); i++) {
                        map = (Map) this.mPhotoList.get(i);
                        if (this.mIsSelectAll) {
                            map.put("boolean", Boolean.valueOf(true));
                        } else {
                            map.put("boolean", Boolean.valueOf(false));
                        }
                    }
                    this.llSelectAll.setEnabled(true);
                    updatePhotoGridView();
                    return;
                }
                return;
            case C0470R.id.ll_delete:
                if (checkIsSelectedState()) {
                    this.mGridView.setEnabled(false);
                    this.mLoadType = 2;
                    this.loadingDialog.show();
                    new DeletePhotoThread().start();
                    return;
                }
                Toast.makeText(this.mAttachActivity, getResources().getString(C0470R.string.str_photo_activity), 0).show();
                return;
            default:
                return;
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        if (this.bDelete) {
            setImageCheckState(view, position);
            return;
        }
        StaticUtil.POSITION = position;
        Intent intent = new Intent(getActivity(), ViewPagerActivity.class);
        intent.putExtra(KEY_PHOTO_POSITION, position);
        startActivityForResult(intent, 11);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 11 && resultCode == -1 && data.getBooleanExtra("IsDeleted", false)) {
            LoadPhotos();
        }
    }

    private void setImageCheckState(View view, int position) {
        ImageView imageView = (ImageView) view.findViewById(C0470R.id.ivDelete);
        if (imageView != null && position >= 0 && position < this.mPhotoList.size()) {
            Map<String, Object> map = (Map) this.mPhotoList.get(position);
            boolean bResult = ((Boolean) map.get("boolean")).booleanValue();
            if (map != null && map.size() > 0) {
                if (bResult) {
                    map.put("boolean", Boolean.valueOf(false));
                    imageView.setImageResource(C0470R.drawable.delete_choose_1);
                    return;
                }
                map.put("boolean", Boolean.valueOf(true));
                imageView.setImageResource(C0470R.drawable.delete_choose_2);
            }
        }
    }

    public void updatePhotoGridView() {
        if (this.mPhotoAdapter == null) {
            this.mPhotoAdapter = new PhotoAdapter(getContext(), this.mPhotoList, C0470R.layout.photo_gridview_item, new String[]{"ItemBtnFace", "ItemTitleName"}, new int[]{C0470R.id.imageView, C0470R.id.ivDelete});
            this.mGridView.setAdapter(this.mPhotoAdapter);
            return;
        }
        this.mPhotoAdapter.notifyDataSetChanged();
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(getActivity()).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(getActivity(), C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C04432());
        this.loadingDialog.setOnDismissListener(new C04443());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(false);
    }

    private int calculateInSampleSize(Options opt, int reqWidth, int reqHeight) {
        int height = opt.outHeight;
        int width = opt.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            int halfHeight = height / 2;
            int halfWidth = width / 2;
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    public void setImageCheckStateFalse() {
        for (int i = 0; i < this.mPhotoList.size(); i++) {
            ((Map) this.mPhotoList.get(i)).put("boolean", Boolean.valueOf(false));
        }
    }

    public void setBottomBarVisibility(int visibility) {
        this.llDeletePhoto.setVisibility(visibility);
    }

    private boolean checkIsSelectedState() {
        boolean isSelected = false;
        if (this.mPhotoList != null && this.mPhotoList.size() > 0) {
            for (int i = 0; i < this.mPhotoList.size(); i++) {
                if (((Boolean) ((Map) this.mPhotoList.get(i)).get("boolean")).booleanValue()) {
                    isSelected = true;
                }
            }
        }
        return isSelected;
    }

    public void onDetach() {
        if (this.mPhotoList != null && this.mPhotoList.size() > 0) {
            for (int i = 0; i < this.mPhotoList.size(); i++) {
                Bitmap bitmap = (Bitmap) ((Map) this.mPhotoList.get(i)).get(KEY_BITMAP);
                if (bitmap != null) {
                    bitmap.recycle();
                }
            }
            this.mPhotoList = null;
        }
        super.onDetach();
    }
}
