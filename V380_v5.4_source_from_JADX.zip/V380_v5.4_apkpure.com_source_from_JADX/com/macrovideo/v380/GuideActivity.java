package com.macrovideo.v380;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.macrovideo.sdk.tools.Functions;

public class GuideActivity extends Activity implements OnPageChangeListener {
    private Button mBtnEnter;
    private Bundle mBundle;
    private LinearLayout mGuideIndicator;
    private GuidePagerAdapter mGuidePagerAdapter;
    private int[] mImagePages = new int[]{C0470R.drawable.guide1, C0470R.drawable.guide2, C0470R.drawable.guide3, C0470R.drawable.guide4};
    private int mPrePosition;
    private ViewPager mVpGuide;

    class C03591 implements OnClickListener {
        C03591() {
        }

        public void onClick(View v) {
            Intent intent = new Intent(GuideActivity.this, HomePageActivity.class);
            intent.putExtras(GuideActivity.this.mBundle);
            intent.putExtra(LocalDefines.IS_FIRST_IN, true);
            GuideActivity.this.startActivity(intent);
            GuideActivity.this.finish();
        }
    }

    class GuidePagerAdapter extends PagerAdapter {
        GuidePagerAdapter() {
        }

        public int getCount() {
            return GuideActivity.this.mImagePages.length;
        }

        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        public Object instantiateItem(ViewGroup container, int position) {
            ImageView imageView = new ImageView(GuideActivity.this);
            imageView.setBackground(new BitmapDrawable(Functions.readBitMap(GuideActivity.this, GuideActivity.this.mImagePages[position])));
            imageView.setScaleType(ScaleType.FIT_XY);
            container.addView(imageView);
            return imageView;
        }

        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((ImageView) object);
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_guide);
        this.mBundle = getIntent().getExtras();
        setViewPager();
        setIndicator();
        setButton();
    }

    private void setButton() {
        this.mBtnEnter = (Button) findViewById(C0470R.id.btn_enter);
        this.mBtnEnter.setOnClickListener(new C03591());
    }

    private void setViewPager() {
        this.mVpGuide = (ViewPager) findViewById(C0470R.id.vp_guideViewPager);
        this.mGuidePagerAdapter = new GuidePagerAdapter();
        this.mVpGuide.setAdapter(this.mGuidePagerAdapter);
        this.mVpGuide.setOnPageChangeListener(this);
    }

    private void setIndicator() {
        this.mGuideIndicator = (LinearLayout) findViewById(C0470R.id.ll_guideIndicator);
        LayoutParams params = new LayoutParams(20, 20);
        params.rightMargin = 15;
        for (int i = 0; i < this.mImagePages.length; i++) {
            View dot = new View(this);
            dot.setBackgroundResource(C0470R.drawable.guide_indicator_bg);
            dot.setEnabled(false);
            dot.setLayoutParams(params);
            this.mGuideIndicator.addView(dot);
        }
        this.mGuideIndicator.getChildAt(this.mPrePosition).setEnabled(true);
    }

    public void onPageScrollStateChanged(int arg0) {
    }

    public void onPageScrolled(int arg0, float arg1, int arg2) {
    }

    public void onPageSelected(int position) {
        setIndicatorDotState(position);
        setButtonVisible(position);
    }

    private void setButtonVisible(int position) {
        if (position == this.mImagePages.length - 1) {
            this.mBtnEnter.setVisibility(0);
        } else {
            this.mBtnEnter.setVisibility(8);
        }
    }

    private void setIndicatorDotState(int position) {
        this.mGuideIndicator.getChildAt(this.mPrePosition).setEnabled(false);
        this.mGuideIndicator.getChildAt(position).setEnabled(true);
        this.mPrePosition = position;
    }
}
