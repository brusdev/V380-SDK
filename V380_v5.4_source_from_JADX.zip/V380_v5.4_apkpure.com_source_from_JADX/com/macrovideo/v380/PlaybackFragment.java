package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StatFs;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;
import android.widget.Toast;
import com.macrovideo.materialshowcaseview.MaterialShowcaseView;
import com.macrovideo.materialshowcaseview.ShowcaseConfig;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.custom.RecordFileInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.media.IDownloadCallback;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrovideo.sdk.media.LoginHelperEX;
import com.macrovideo.sdk.media.RecFileDownloader;
import com.macrovideo.sdk.media.RecordFileHelper;
import com.macrovideo.sdk.tools.Functions;
import com.macrvideo.newlogin.CloudServiceHelper;
import com.tencent.android.tpush.common.Constants;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlaybackFragment extends Fragment implements OnClickListener, OnItemClickListener {
    static final int DATETIME_MODE_DATE = 100;
    static final int DATETIME_MODE_ENDTIME = 102;
    static final int DATETIME_MODE_STARTTIME = 101;
    static final int DATETIME_MODE_UNDEFINE = 0;
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    private int REC_FILE_FAIL = 10010;
    private LoginHandle _deviceParam = null;
    private boolean bIsRecFileSearching = false;
    private boolean bSearchType = true;
    private Button btnDatetimeSelectCancel = null;
    private Button btnDatetimeSelectOK = null;
    private ImageView btnDeviceSelectBack;
    private ImageView btnDeviceSelectBack_Cloud;
    private Button btnDeviceSelectCancel = null;
    private Button btnListVisible = null;
    private Button btnSearch;
    private Button btnStartSearch = null;
    private Button btnStartSearchCloud;
    private View contentView = null;
    private View datetimeSelectConctentView = null;
    private View datetimeSelectConctentViewCloud;
    private Dialog datetimeSelectDialog = null;
    private Dialog datetimeSelectDialogCloud = null;
    private DeviceInfo deviceInfo = null;
    private View deviceSelectConctentView = null;
    private Dialog deviceSelectDialog = null;
    private ArrayList<RecordFileInfo> fileList = new ArrayList();
    private Handler handler = new C04461();
    private boolean isActive = false;
    private boolean isCloudFileList = false;
    boolean isInit = false;
    private boolean isListVisible = false;
    private boolean isLoadFromDatabase = false;
    private boolean isSearchCloudRec = false;
    boolean isZh = true;
    private ImageView ivNvplayerBack;
    private ImageView ivPlayerBackType;
    private ImageView ivPlayerBackType2;
    private ImageView ivTypeAlarm;
    private ImageView ivTypeAlarm_non_CN;
    private ImageView ivTypeAll;
    private ImageView ivTypeAll_non_CN;
    private ImageView ivTypeAuto;
    private ImageView ivTypeAuto_non_CN;
    private LinearLayout layoutDatePicker = null;
    private LinearLayout layoutDatePickerCloud = null;
    private LinearLayout layoutDevice = null;
    private LinearLayout layoutRecFileList = null;
    private LinearLayout layoutSearchDate = null;
    private LinearLayout layoutSearchEndTime = null;
    private RelativeLayout layoutSearchParam = null;
    private LinearLayout layoutSearchStartTime = null;
    private LinearLayout layoutTimePicker = null;
    private LinearLayout layoutTimePickerCloud = null;
    private LinearLayout llAll;
    private LinearLayout llCloudRec;
    private LinearLayout llPlayBackTitle;
    private LinearLayout llPlayerBackType;
    private LinearLayout llPlayerBackType_non_CN;
    private LinearLayout llSearchType;
    private LinearLayout llTFCardRec;
    private LinearLayout llTypeAlarm;
    private LinearLayout llTypeAlarm_non_CN;
    private LinearLayout llTypeAll;
    private LinearLayout llTypeAll_non_CN;
    private LinearLayout llTypeAuto;
    private LinearLayout llTypeAuto_non_CN;
    private LinearLayout ll_SearchType_CN = null;
    private LinearLayout ll_SearchType_Non_CN;
    private LinearLayout ll_cloud_record;
    private LinearLayout ll_search_date;
    private LinearLayout ll_search_end_time;
    private LinearLayout ll_search_start_time;
    private Dialog loadingDialog;
    private View loadingView;
    private String mAccesstoken;
    private int mDLFileListPosition = -1;
    private String mDLFilePath;
    private String mEcsIP;
    private String mEcsIP2;
    private int mEcsPort;
    private int mEcsPort2;
    private int mGetRecFileId = 0;
    private int mLoadType = 1;
    private RecFileDownloader mRecFileDownloader;
    private List<Integer> mRecFileDownloaderList;
    Map<Integer, RecFileDownloader> mRecFileDownloaderMap;
    private DatePicker mSelectDatePicker = null;
    private DatePicker mSelectDatePickerCloud = null;
    private TimePicker mSelectTimePicker = null;
    private TimePicker mSelectTimePickerCloud = null;
    private int mUserId;
    private int m_nLoginExID = 0;
    private int m_nThreadID = 0;
    private int nDatetimeMode = 0;
    private short nDay = (short) 0;
    private short nDay_Cloud = (short) 0;
    private short nEndHour = (short) 23;
    private short nEndHour_Cloud = (short) 23;
    private short nEndMin = (short) 59;
    private short nEndMin_Cloud = (short) 59;
    private short nEndSec = (short) 0;
    private short nEndSec_Cloud = (short) 0;
    private short nMonth = (short) 0;
    private short nMonth_Cloud = (short) 0;
    private int nSearchChn = 0;
    private int nSearchType = 0;
    private short nStartHour = (short) 0;
    private short nStartHour_Cloud = (short) 0;
    private short nStartMin = (short) 0;
    private short nStartMin_Cloud = (short) 0;
    private short nStartSec = (short) 0;
    private short nStartSec_Cloud = (short) 0;
    private int nThreadID = 0;
    private short nYear = (short) 2000;
    private short nYear_Cloud = (short) 2000;
    private int optOf;
    private PopupWindow popupListView;
    private ListView recFileListView = null;
    private Activity relateAtivity = null;
    private ListView serverlistView = null;
    private TextView textViewDate = null;
    private TextView textViewDevice = null;
    private TextView textViewEndTime = null;
    private TextView textViewStartTime = null;
    private TextView tvCloudVideo;
    private TextView tvDate = null;
    private TextView tvDateTimeCurrent = null;
    private TextView tvDateTimeTitle = null;
    private TextView tvDeviceId;
    private TextView tvEndTime = null;
    private TextView tvPlayerBackType;
    private TextView tvPlayerBackType2;
    private TextView tvStartTime = null;
    private TextView tvTFVideo;

    class C04461 extends Handler {
        C04461() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            if (msg.arg1 == PlaybackFragment.this.REC_FILE_FAIL) {
                PlaybackFragment.this.bSearchType = false;
                PlaybackFragment.this.llPlayerBackType.setVisibility(0);
            }
            if (msg.arg1 == 262) {
                PlaybackFragment.this.bIsRecFileSearching = false;
                if (msg.arg2 != 0) {
                    Bundle data = msg.getData();
                    if (data == null) {
                        System.out.println("data is null");
                        return;
                    }
                    PlaybackFragment.this.fileList = data.getParcelableArrayList(Defines.RECORD_FILE_RETURN_MESSAGE);
                    if (PlaybackFragment.this.isCloudFileList) {
                        if (PlaybackFragment.this.fileList != null && PlaybackFragment.this.fileList.size() > 0) {
                            PlaybackFragment.this.SaveRecFileListToDatabase();
                        }
                        PlaybackFragment.this.refleshCloudRecFileList();
                    } else {
                        if (PlaybackFragment.this.fileList != null && PlaybackFragment.this.fileList.size() > 0) {
                            PlaybackFragment.this.SaveRecFileListToDatabase();
                        }
                        if (PlaybackFragment.this.isActive) {
                            try {
                                PlaybackFragment.this.refleshRecFileList();
                            } catch (Exception e) {
                            }
                        }
                    }
                    PlaybackFragment.this.loadingDialog.dismiss();
                } else if (PlaybackFragment.this.recFileListView.getAdapter() == null) {
                    PlaybackFragment.this.isListVisible = false;
                    PlaybackFragment.this.layoutSearchParam.setVisibility(0);
                    PlaybackFragment.this.layoutRecFileList.setVisibility(8);
                    LocalDefines.bIsBackPlay = false;
                    ((HomePageActivity) PlaybackFragment.this.relateAtivity).setGuideBarVisible(true);
                    Toast toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.noticRecOKNOFiles), 0);
                    toast.setGravity(17, 0, 0);
                    toast.show();
                    PlaybackFragment.this.loadingDialog.dismiss();
                    if (msg.getData() != null) {
                        PlaybackFragment.this.SaveRecFileListToDatabase();
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            if (msg.arg1 == 259) {
                PlaybackFragment.this.bIsRecFileSearching = false;
                PlaybackFragment.this.loadingDialog.dismiss();
                switch (msg.arg2) {
                    case LocalDefines.REC_FILE_SEARCH_RESULT_CODE_FAIL_USER_NOEXIST /*-4117*/:
                        if (PlaybackFragment.this.isActive) {
                            try {
                                toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.notice_Result_UserNoExist), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                break;
                            } catch (Exception e2) {
                                break;
                            }
                        }
                        break;
                    case LocalDefines.REC_FILE_SEARCH_RESULT_CODE_FAIL_VERIFY_FAILED /*-4116*/:
                        if (PlaybackFragment.this.isActive) {
                            try {
                                toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.notice_Result_VerifyFailed), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                break;
                            } catch (Exception e3) {
                                break;
                            }
                        }
                        break;
                    case LocalDefines.REC_FILE_SEARCH_RESULT_CODE_FAIL_NET_POOL /*-4114*/:
                        if (PlaybackFragment.this.isActive) {
                            try {
                                toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.noticRecConnectFail), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                break;
                            } catch (Exception e4) {
                                break;
                            }
                        }
                        break;
                    case LocalDefines.REC_FILE_SEARCH_RESULT_CODE_FAIL_NET_DOWN /*-4113*/:
                        if (PlaybackFragment.this.isActive) {
                            try {
                                toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.noticRecConnectFail), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                break;
                            } catch (Exception e5) {
                                break;
                            }
                        }
                        break;
                    case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                        if (PlaybackFragment.this.isActive) {
                            try {
                                toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.notice_Result_PWDError), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                break;
                            } catch (Exception e6) {
                                break;
                            }
                        }
                        break;
                    case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                        if (PlaybackFragment.this.isActive) {
                            try {
                                toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.noticRecConnectFail), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                break;
                            } catch (Exception e7) {
                                break;
                            }
                        }
                        break;
                    case 256:
                        if (PlaybackFragment.this.fileList.size() > 0) {
                            if (PlaybackFragment.this.isActive) {
                                try {
                                    PlaybackFragment.this.refleshRecFileList();
                                    break;
                                } catch (Exception e8) {
                                    break;
                                }
                            }
                        }
                        toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.noticRecOKNOFiles), 0);
                        toast.setGravity(17, 0, 0);
                        toast.show();
                        break;
                        break;
                    case 259:
                        if (PlaybackFragment.this.isActive) {
                            try {
                                toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.noticRecConnectFail), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                break;
                            } catch (Exception e9) {
                                break;
                            }
                        }
                        break;
                    default:
                        if (PlaybackFragment.this.isActive) {
                            try {
                                toast = Toast.makeText(PlaybackFragment.this.relateAtivity.getApplicationContext(), PlaybackFragment.this.getString(C0470R.string.noticRecConnectFail), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                break;
                            } catch (Exception e10) {
                                break;
                            }
                        }
                        break;
                }
                if (PlaybackFragment.this.fileList.size() <= 0) {
                    PlaybackFragment.this.isListVisible = false;
                    PlaybackFragment.this.layoutSearchParam.setVisibility(0);
                    PlaybackFragment.this.layoutRecFileList.setVisibility(8);
                    LocalDefines.bIsBackPlay = false;
                    ((HomePageActivity) PlaybackFragment.this.relateAtivity).setGuideBarVisible(true);
                    try {
                        Thread.sleep(400);
                    } catch (InterruptedException e11) {
                        e11.printStackTrace();
                    }
                }
            }
        }
    }

    class C04472 implements OnDismissListener {
        C04472() {
        }

        public void onDismiss() {
            PlaybackFragment.this.btnListVisible.setVisibility(0);
        }
    }

    class C04483 implements OnShowListener {
        C04483() {
        }

        public void onShow(DialogInterface dialog) {
            PlaybackFragment.this.btnDeviceSelectCancel = (Button) PlaybackFragment.this.deviceSelectConctentView.findViewById(C0470R.id.btnDeviceSelectCancel);
            PlaybackFragment.this.btnDeviceSelectCancel.setOnClickListener(PlaybackFragment.this);
        }
    }

    class C04494 implements DialogInterface.OnDismissListener {
        C04494() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class C04535 implements OnShowListener {

        class C04501 implements OnDateChangedListener {
            C04501() {
            }

            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                if (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1 < 10 && PlaybackFragment.this.mSelectDatePicker.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePicker.getYear() + "-0" + (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1) + "-0" + PlaybackFragment.this.mSelectDatePicker.getDayOfMonth());
                } else if (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1 >= 10 && PlaybackFragment.this.mSelectDatePicker.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePicker.getYear() + "-" + (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1) + "-0" + PlaybackFragment.this.mSelectDatePicker.getDayOfMonth());
                } else if (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1 >= 10 || PlaybackFragment.this.mSelectDatePicker.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePicker.getYear() + "-" + (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1) + "-" + PlaybackFragment.this.mSelectDatePicker.getDayOfMonth());
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePicker.getYear() + "-0" + (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1) + "-" + PlaybackFragment.this.mSelectDatePicker.getDayOfMonth());
                }
            }
        }

        class C04512 implements OnTimeChangedListener {
            C04512() {
            }

            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                if (hourOfDay < 10 && minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 && minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 || minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":" + minute);
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":" + minute);
                }
            }
        }

        class C04523 implements OnTimeChangedListener {
            C04523() {
            }

            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                if (hourOfDay < 10 && minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 && minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 || minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":" + minute);
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":" + minute);
                }
            }
        }

        C04535() {
        }

        public void onShow(DialogInterface dialog) {
            PlaybackFragment.this.tvDateTimeTitle = (TextView) PlaybackFragment.this.datetimeSelectConctentView.findViewById(C0470R.id.tvDateTimeTitle);
            PlaybackFragment.this.tvDateTimeCurrent = (TextView) PlaybackFragment.this.datetimeSelectConctentView.findViewById(C0470R.id.tvDateTimeCurrent);
            PlaybackFragment.this.mSelectDatePicker = (DatePicker) PlaybackFragment.this.datetimeSelectConctentView.findViewById(C0470R.id.mSelectDatePicker);
            PlaybackFragment.this.mSelectTimePicker = (TimePicker) PlaybackFragment.this.datetimeSelectConctentView.findViewById(C0470R.id.mSelectTimePicker);
            PlaybackFragment.this.layoutDatePicker = (LinearLayout) PlaybackFragment.this.datetimeSelectConctentView.findViewById(C0470R.id.layoutDatePicker);
            PlaybackFragment.this.layoutTimePicker = (LinearLayout) PlaybackFragment.this.datetimeSelectConctentView.findViewById(C0470R.id.layoutTimePicker);
            PlaybackFragment.this.btnDatetimeSelectCancel = (Button) PlaybackFragment.this.datetimeSelectConctentView.findViewById(C0470R.id.btnDatetimeSelectCancel);
            PlaybackFragment.this.btnDatetimeSelectOK = (Button) PlaybackFragment.this.datetimeSelectConctentView.findViewById(C0470R.id.btnDatetimeSelectOK);
            PlaybackFragment.this.btnDatetimeSelectOK.setOnClickListener(PlaybackFragment.this);
            PlaybackFragment.this.btnDatetimeSelectCancel.setOnClickListener(PlaybackFragment.this);
            if (PlaybackFragment.this.nDatetimeMode == 100) {
                PlaybackFragment.this.tvDateTimeTitle.setText(C0470R.string.lblDate2);
                PlaybackFragment.this.layoutDatePicker.setVisibility(0);
                PlaybackFragment.this.layoutTimePicker.setVisibility(8);
                PlaybackFragment.this.mSelectDatePicker.init(PlaybackFragment.this.nYear, PlaybackFragment.this.nMonth, PlaybackFragment.this.nDay, new C04501());
                if (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1 < 10 && PlaybackFragment.this.mSelectDatePicker.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePicker.getYear() + "-0" + (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1) + "-0" + PlaybackFragment.this.mSelectDatePicker.getDayOfMonth());
                } else if (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1 >= 10 && PlaybackFragment.this.mSelectDatePicker.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePicker.getYear() + "-" + (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1) + "-0" + PlaybackFragment.this.mSelectDatePicker.getDayOfMonth());
                } else if (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1 >= 10 || PlaybackFragment.this.mSelectDatePicker.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePicker.getYear() + "-" + (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1) + "-" + PlaybackFragment.this.mSelectDatePicker.getDayOfMonth());
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePicker.getYear() + "-0" + (PlaybackFragment.this.mSelectDatePicker.getMonth() + 1) + "-" + PlaybackFragment.this.mSelectDatePicker.getDayOfMonth());
                }
            } else if (PlaybackFragment.this.nDatetimeMode == 101) {
                PlaybackFragment.this.tvDateTimeTitle.setText(C0470R.string.lblStartTime2);
                PlaybackFragment.this.layoutDatePicker.setVisibility(8);
                PlaybackFragment.this.layoutTimePicker.setVisibility(0);
                PlaybackFragment.this.mSelectTimePicker.setIs24HourView(Boolean.valueOf(true));
                PlaybackFragment.this.mSelectTimePicker.setCurrentHour(Integer.valueOf(PlaybackFragment.this.nStartHour));
                PlaybackFragment.this.mSelectTimePicker.setCurrentMinute(Integer.valueOf(PlaybackFragment.this.nStartMin));
                PlaybackFragment.this.mSelectTimePicker.setOnTimeChangedListener(new C04512());
                if (PlaybackFragment.this.mSelectTimePicker.getCurrentHour().intValue() < 10 && PlaybackFragment.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + PlaybackFragment.this.mSelectTimePicker.getCurrentHour() + ":0" + PlaybackFragment.this.mSelectTimePicker.getCurrentMinute());
                } else if (PlaybackFragment.this.mSelectTimePicker.getCurrentHour().intValue() >= 10 && PlaybackFragment.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectTimePicker.getCurrentHour() + ":0" + PlaybackFragment.this.mSelectTimePicker.getCurrentMinute());
                } else if (PlaybackFragment.this.mSelectTimePicker.getCurrentHour().intValue() >= 10 || PlaybackFragment.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectTimePicker.getCurrentHour() + ":" + PlaybackFragment.this.mSelectTimePicker.getCurrentMinute());
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + PlaybackFragment.this.mSelectTimePicker.getCurrentHour() + ":" + PlaybackFragment.this.mSelectTimePicker.getCurrentMinute());
                }
            } else if (PlaybackFragment.this.nDatetimeMode == 102) {
                PlaybackFragment.this.tvDateTimeTitle.setText(C0470R.string.lblEndTime2);
                PlaybackFragment.this.layoutDatePicker.setVisibility(8);
                PlaybackFragment.this.layoutTimePicker.setVisibility(0);
                PlaybackFragment.this.mSelectTimePicker.setIs24HourView(Boolean.valueOf(true));
                PlaybackFragment.this.mSelectTimePicker.setCurrentHour(Integer.valueOf(PlaybackFragment.this.nEndHour));
                PlaybackFragment.this.mSelectTimePicker.setCurrentMinute(Integer.valueOf(PlaybackFragment.this.nEndMin));
                PlaybackFragment.this.mSelectTimePicker.setOnTimeChangedListener(new C04523());
                if (PlaybackFragment.this.mSelectTimePicker.getCurrentHour().intValue() < 10 && PlaybackFragment.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + PlaybackFragment.this.mSelectTimePicker.getCurrentHour() + ":0" + PlaybackFragment.this.mSelectTimePicker.getCurrentMinute());
                } else if (PlaybackFragment.this.mSelectTimePicker.getCurrentHour().intValue() >= 10 && PlaybackFragment.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectTimePicker.getCurrentHour() + ":0" + PlaybackFragment.this.mSelectTimePicker.getCurrentMinute());
                } else if (PlaybackFragment.this.mSelectTimePicker.getCurrentHour().intValue() >= 10 || PlaybackFragment.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectTimePicker.getCurrentHour() + ":" + PlaybackFragment.this.mSelectTimePicker.getCurrentMinute());
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + PlaybackFragment.this.mSelectTimePicker.getCurrentHour() + ":" + PlaybackFragment.this.mSelectTimePicker.getCurrentMinute());
                }
            }
        }
    }

    class C04546 implements DialogInterface.OnDismissListener {
        C04546() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class C04557 implements OnShowListener {
        C04557() {
        }

        public void onShow(DialogInterface dialog) {
            PlaybackFragment.this.btnDeviceSelectCancel = (Button) PlaybackFragment.this.deviceSelectConctentView.findViewById(C0470R.id.btnDeviceSelectCancel);
            PlaybackFragment.this.btnDeviceSelectCancel.setOnClickListener(PlaybackFragment.this);
        }
    }

    class C04568 implements DialogInterface.OnDismissListener {
        C04568() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class C04609 implements OnShowListener {

        class C04571 implements OnDateChangedListener {
            C04571() {
            }

            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                if (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1 < 10 && PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePickerCloud.getYear() + "-0" + (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1) + "-0" + PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth());
                } else if (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1 >= 10 && PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePickerCloud.getYear() + "-" + (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1) + "-0" + PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth());
                } else if (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1 >= 10 || PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePickerCloud.getYear() + "-" + (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1) + "-" + PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth());
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePickerCloud.getYear() + "-0" + (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1) + "-" + PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth());
                }
            }
        }

        class C04582 implements OnTimeChangedListener {
            C04582() {
            }

            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                if (hourOfDay < 10 && minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 && minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 || minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":" + minute);
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":" + minute);
                }
            }
        }

        class C04593 implements OnTimeChangedListener {
            C04593() {
            }

            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                if (hourOfDay < 10 && minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 && minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 || minute < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":" + minute);
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":" + minute);
                }
            }
        }

        C04609() {
        }

        public void onShow(DialogInterface dialog) {
            PlaybackFragment.this.tvDateTimeTitle = (TextView) PlaybackFragment.this.datetimeSelectConctentViewCloud.findViewById(C0470R.id.tvDateTimeTitleCloud);
            PlaybackFragment.this.tvDateTimeCurrent = (TextView) PlaybackFragment.this.datetimeSelectConctentViewCloud.findViewById(C0470R.id.tvDateTimeCurrentCloud);
            PlaybackFragment.this.mSelectDatePickerCloud = (DatePicker) PlaybackFragment.this.datetimeSelectConctentViewCloud.findViewById(C0470R.id.mSelectDatePickerCloud);
            PlaybackFragment.this.mSelectTimePickerCloud = (TimePicker) PlaybackFragment.this.datetimeSelectConctentViewCloud.findViewById(C0470R.id.mSelectTimePickerCloud);
            PlaybackFragment.this.layoutDatePickerCloud = (LinearLayout) PlaybackFragment.this.datetimeSelectConctentViewCloud.findViewById(C0470R.id.layoutDatePickerCloud);
            PlaybackFragment.this.layoutTimePickerCloud = (LinearLayout) PlaybackFragment.this.datetimeSelectConctentViewCloud.findViewById(C0470R.id.layoutTimePickerCloud);
            PlaybackFragment.this.btnDatetimeSelectCancel = (Button) PlaybackFragment.this.datetimeSelectConctentViewCloud.findViewById(C0470R.id.btnDatetimeSelectCancelCloud);
            PlaybackFragment.this.btnDatetimeSelectOK = (Button) PlaybackFragment.this.datetimeSelectConctentViewCloud.findViewById(C0470R.id.btnDatetimeSelectOKCloud);
            PlaybackFragment.this.btnDatetimeSelectOK.setOnClickListener(PlaybackFragment.this);
            PlaybackFragment.this.btnDatetimeSelectCancel.setOnClickListener(PlaybackFragment.this);
            if (PlaybackFragment.this.nDatetimeMode == 100) {
                PlaybackFragment.this.tvDateTimeTitle.setText(C0470R.string.lblDate2);
                PlaybackFragment.this.layoutDatePickerCloud.setVisibility(0);
                PlaybackFragment.this.layoutTimePickerCloud.setVisibility(8);
                PlaybackFragment.this.mSelectDatePickerCloud.init(PlaybackFragment.this.nYear_Cloud, PlaybackFragment.this.nMonth_Cloud, PlaybackFragment.this.nDay_Cloud, new C04571());
                if (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1 < 10 && PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePickerCloud.getYear() + "-0" + (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1) + "-0" + PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth());
                } else if (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1 >= 10 && PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePickerCloud.getYear() + "-" + (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1) + "-0" + PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth());
                } else if (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1 >= 10 || PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePickerCloud.getYear() + "-" + (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1) + "-" + PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth());
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectDatePickerCloud.getYear() + "-0" + (PlaybackFragment.this.mSelectDatePickerCloud.getMonth() + 1) + "-" + PlaybackFragment.this.mSelectDatePickerCloud.getDayOfMonth());
                }
            } else if (PlaybackFragment.this.nDatetimeMode == 101) {
                PlaybackFragment.this.tvDateTimeTitle.setText(C0470R.string.lblStartTime2);
                PlaybackFragment.this.layoutDatePickerCloud.setVisibility(8);
                PlaybackFragment.this.layoutTimePickerCloud.setVisibility(0);
                PlaybackFragment.this.mSelectTimePickerCloud.setIs24HourView(Boolean.valueOf(true));
                PlaybackFragment.this.mSelectTimePickerCloud.setCurrentHour(Integer.valueOf(PlaybackFragment.this.nStartHour));
                PlaybackFragment.this.mSelectTimePickerCloud.setCurrentMinute(Integer.valueOf(PlaybackFragment.this.nStartMin));
                PlaybackFragment.this.mSelectTimePickerCloud.setOnTimeChangedListener(new C04582());
                if (PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour().intValue() < 10 && PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour() + ":0" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute());
                } else if (PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour().intValue() >= 10 && PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour() + ":0" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute());
                } else if (PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour().intValue() >= 10 || PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour() + ":" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute());
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour() + ":" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute());
                }
            } else if (PlaybackFragment.this.nDatetimeMode == 102) {
                PlaybackFragment.this.tvDateTimeTitle.setText(C0470R.string.lblEndTime2);
                PlaybackFragment.this.layoutDatePickerCloud.setVisibility(8);
                PlaybackFragment.this.layoutTimePickerCloud.setVisibility(0);
                PlaybackFragment.this.mSelectTimePickerCloud.setIs24HourView(Boolean.valueOf(true));
                PlaybackFragment.this.mSelectTimePickerCloud.setCurrentHour(Integer.valueOf(PlaybackFragment.this.nEndHour));
                PlaybackFragment.this.mSelectTimePickerCloud.setCurrentMinute(Integer.valueOf(PlaybackFragment.this.nEndMin));
                PlaybackFragment.this.mSelectTimePickerCloud.setOnTimeChangedListener(new C04593());
                if (PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour().intValue() < 10 && PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour() + ":0" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute());
                } else if (PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour().intValue() >= 10 && PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour() + ":0" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute());
                } else if (PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour().intValue() >= 10 || PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute().intValue() < 10) {
                    PlaybackFragment.this.tvDateTimeCurrent.setText(PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour() + ":" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute());
                } else {
                    PlaybackFragment.this.tvDateTimeCurrent.setText("0" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentHour() + ":" + PlaybackFragment.this.mSelectTimePickerCloud.getCurrentMinute());
                }
            }
        }
    }

    private class DeviceListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageView ivDeviceSelect;
            TextView tvName;

            private ItemViewHolder() {
            }
        }

        public DeviceListViewAdapter(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.player_back_device_select_item, null);
                this.holder = new ItemViewHolder();
                this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[0]);
                this.holder.ivDeviceSelect = (ImageView) convertView.findViewById(this.valueViewID[1]);
                convertView.setTag(this.holder);
            }
            HashMap<String, Object> map = (HashMap) this.mAppList.get(position);
            if (map != null) {
                if (position == PlaybackFragment.this.optOf) {
                    this.holder.tvName.setTextColor(-16776961);
                    this.holder.ivDeviceSelect.setImageResource(C0470R.drawable.play_back_choose_2);
                } else {
                    this.holder.tvName.setTextColor(Color.parseColor("#666666"));
                    this.holder.ivDeviceSelect.setImageResource(C0470R.drawable.play_back_choose_1);
                }
                this.holder.tvName.setText((String) map.get("ItemTitleName"));
            }
            return convertView;
        }
    }

    private class RecFileListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ProgressBar pbDownloadBar;
            RelativeLayout rlDownload;
            TextView tvDownloadPro;
            TextView tvDownloadState;
            TextView tvInfo;
            TextView tvName;
            TextView tvSize;
            TextView tvTimeLen;

            private ItemViewHolder() {
            }
        }

        public RecFileListViewAdapter(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.recfile_list_item, null);
                this.holder = new ItemViewHolder();
                convertView.setTag(this.holder);
            }
            this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[0]);
            this.holder.tvInfo = (TextView) convertView.findViewById(this.valueViewID[1]);
            this.holder.tvSize = (TextView) convertView.findViewById(this.valueViewID[2]);
            this.holder.tvTimeLen = (TextView) convertView.findViewById(this.valueViewID[3]);
            this.holder.rlDownload = (RelativeLayout) convertView.findViewById(this.valueViewID[4]);
            this.holder.tvDownloadState = (TextView) convertView.findViewById(this.valueViewID[5]);
            this.holder.tvDownloadPro = (TextView) convertView.findViewById(this.valueViewID[6]);
            this.holder.pbDownloadBar = (ProgressBar) convertView.findViewById(this.valueViewID[7]);
            HashMap<String, Object> map = (HashMap) this.mAppList.get(position);
            if (map != null) {
                String strSize = (String) map.get("FileSize");
                String strTimeLen = (String) map.get("FileTimeLen");
                String info = (String) map.get("FileName");
                this.holder.tvName.setText((String) map.get("FileStartTime"));
                this.holder.tvTimeLen.setText(strTimeLen);
                this.holder.tvSize.setText(strSize);
                this.holder.tvInfo.setText(info);
                int fileDownloadState = ((Integer) map.get("FileDownloadState")).intValue();
                int fileDownloadProgress = ((Integer) map.get("FileDownloadProgress")).intValue();
                if (fileDownloadState == 2) {
                    this.holder.tvDownloadState.setText(PlaybackFragment.this.getString(C0470R.string.showDown));
                    this.holder.tvDownloadPro.setVisibility(4);
                    this.holder.pbDownloadBar.setVisibility(4);
                } else if (fileDownloadState == 1) {
                    this.holder.tvDownloadState.setText(PlaybackFragment.this.getString(C0470R.string.str_rec_file_download_finish));
                    this.holder.tvDownloadPro.setVisibility(0);
                    this.holder.pbDownloadBar.setVisibility(0);
                    this.holder.tvDownloadPro.setText("100%");
                    this.holder.pbDownloadBar.setProgress(100);
                } else if (fileDownloadState == 0) {
                    this.holder.tvDownloadState.setText(C0470R.string.str_rec_file_stop_download);
                    this.holder.tvDownloadPro.setVisibility(0);
                    this.holder.pbDownloadBar.setVisibility(0);
                    this.holder.tvDownloadPro.setText(new StringBuilder(String.valueOf(fileDownloadProgress)).append("%").toString());
                    this.holder.pbDownloadBar.setProgress(fileDownloadProgress);
                } else if (fileDownloadState == -1) {
                    this.holder.tvDownloadState.setText(PlaybackFragment.this.getString(C0470R.string.str_rec_file_redownload));
                    this.holder.tvDownloadPro.setVisibility(0);
                    this.holder.pbDownloadBar.setVisibility(0);
                    this.holder.tvDownloadPro.setText(new StringBuilder(String.valueOf(fileDownloadProgress)).append("%").toString());
                    this.holder.pbDownloadBar.setProgress(fileDownloadProgress);
                } else if (fileDownloadState == -2) {
                    this.holder.tvDownloadState.setText(PlaybackFragment.this.getString(C0470R.string.str_rec_file_download_connecting));
                    this.holder.tvDownloadPro.setVisibility(4);
                    this.holder.pbDownloadBar.setVisibility(4);
                }
            }
            this.holder.rlDownload.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    int fileDownloadState = ((Integer) ((HashMap) RecFileListViewAdapter.this.mAppList.get(position)).get("FileDownloadState")).intValue();
                    String strSDcardPath;
                    RecordFileInfo recFile;
                    String strSavePath;
                    File fileDiir;
                    String fileName;
                    String strFilePath;
                    final File file;
                    boolean result;
                    final File file1;
                    final RecFileDownloader recFileDownloader;
                    final int i;
                    if (fileDownloadState == 2 || fileDownloadState == -1) {
                        strSDcardPath = Functions.GetSDPath();
                        if (strSDcardPath == null) {
                            Toast.makeText(PlaybackFragment.this.relateAtivity, PlaybackFragment.this.getString(C0470R.string.noticeSDCardNotExist), 0).show();
                            return;
                        }
                        recFile = (RecordFileInfo) PlaybackFragment.this.fileList.get(position);
                        if (new StatFs(strSDcardPath).getAvailableBytes() - ((long) recFile.getnFileSize()) > 0) {
                            strSavePath = new StringBuilder(String.valueOf(strSDcardPath)).append(File.separator).append(LocalDefines.SDCardPath).toString();
                            fileDiir = new File(strSavePath);
                            if (!fileDiir.exists()) {
                                fileDiir.mkdir();
                            }
                            fileName = recFile.getStrFileName();
                            strFilePath = new StringBuilder(String.valueOf(strSavePath)).append(File.separator).append(LocalDefines._nDeviceID).append("_").append(fileName.substring(0, fileName.length() - 4)).append(".mp4").toString();
                            file = new File(strFilePath);
                            if (file.exists()) {
                                Toast.makeText(PlaybackFragment.this.relateAtivity, PlaybackFragment.this.getString(C0470R.string.str_rec_file_exist), 0).show();
                                return;
                            }
                            if (!(PlaybackFragment.this.mRecFileDownloader == null || !PlaybackFragment.this.mRecFileDownloader.isDownloading() || PlaybackFragment.this.mDLFileListPosition == -1 || PlaybackFragment.this.mDLFilePath == null)) {
                                result = PlaybackFragment.this.mRecFileDownloader.StopDownloadRecFile();
                                ((HashMap) RecFileListViewAdapter.this.mAppList.get(PlaybackFragment.this.mDLFileListPosition)).put("FileDownloadState", Integer.valueOf(2));
                                ((HashMap) RecFileListViewAdapter.this.mAppList.get(PlaybackFragment.this.mDLFileListPosition)).put("FileDownloadProgress", Integer.valueOf(0));
                                file1 = new File(PlaybackFragment.this.mDLFilePath);
                                if (file1.exists()) {
                                    new Thread(new Runnable() {
                                        public void run() {
                                            boolean deleteResult = file1.delete();
                                        }
                                    }).start();
                                }
                                PlaybackFragment.this.mDLFileListPosition = -1;
                                PlaybackFragment.this.mDLFilePath = null;
                            }
                            recFileDownloader = new RecFileDownloader();
                            i = position;
                            if (recFileDownloader.StartDownloadRecFile(new IDownloadCallback() {

                                class C04632 implements Runnable {
                                    C04632() {
                                    }

                                    public void run() {
                                        if (PlaybackFragment.this.recFileListView.getAdapter() != null) {
                                            ((RecFileListViewAdapter) PlaybackFragment.this.recFileListView.getAdapter()).notifyDataSetChanged();
                                        }
                                    }
                                }

                                public void onDownloadProcess(Object arg0, int state, int progress) {
                                    ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadState", Integer.valueOf(state));
                                    ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadProgress", Integer.valueOf(progress));
                                    boolean stopResult;
                                    if (state == 1 || progress == 100) {
                                        stopResult = recFileDownloader.StopDownloadRecFile();
                                        ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadState", Integer.valueOf(1));
                                        ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadProgress", Integer.valueOf(0));
                                    } else if (state == -1) {
                                        stopResult = recFileDownloader.StopDownloadRecFile();
                                        ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadState", Integer.valueOf(-1));
                                        ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadProgress", Integer.valueOf(0));
                                        if (file.exists()) {
                                            final File file = file;
                                            new Thread(new Runnable() {
                                                public void run() {
                                                    boolean deleteResult = file.delete();
                                                }
                                            }).start();
                                        }
                                    }
                                    PlaybackFragment.this.getActivity().runOnUiThread(new C04632());
                                }
                            }, strFilePath, LocalDefines.Device_LoginHandle, recFile)) {
                                ((HashMap) RecFileListViewAdapter.this.mAppList.get(position)).put("FileDownloadState", Integer.valueOf(-2));
                                PlaybackFragment.this.mDLFileListPosition = position;
                                PlaybackFragment.this.mDLFilePath = strFilePath;
                                PlaybackFragment.this.mRecFileDownloader = recFileDownloader;
                                if (PlaybackFragment.this.recFileListView.getAdapter() != null) {
                                    ((RecFileListViewAdapter) PlaybackFragment.this.recFileListView.getAdapter()).notifyDataSetChanged();
                                    return;
                                }
                                return;
                            }
                            Toast.makeText(PlaybackFragment.this.relateAtivity, PlaybackFragment.this.getString(C0470R.string.downFail), 0).show();
                            return;
                        }
                        Toast.makeText(PlaybackFragment.this.relateAtivity, PlaybackFragment.this.getString(C0470R.string.str_storage_not_enough), 0).show();
                    } else if (fileDownloadState == 1) {
                        recFile = (RecordFileInfo) PlaybackFragment.this.fileList.get(position);
                        fileName = recFile.getStrFileName();
                        strSavePath = Functions.GetSDPath() + File.separator + LocalDefines.SDCardPath;
                        strFilePath = new StringBuilder(String.valueOf(strSavePath)).append(File.separator).append(LocalDefines._nDeviceID).append("_").append(fileName.substring(0, fileName.length() - 4)).append(".mp4").toString();
                        file = new File(strFilePath);
                        if (file.exists()) {
                            Toast.makeText(PlaybackFragment.this.relateAtivity, PlaybackFragment.this.getString(C0470R.string.str_rec_file_exist), 0).show();
                            return;
                        }
                        strSDcardPath = Functions.GetSDPath();
                        if (strSDcardPath == null) {
                            Toast.makeText(PlaybackFragment.this.relateAtivity, PlaybackFragment.this.getString(C0470R.string.noticeSDCardNotExist), 0).show();
                            return;
                        }
                        if (new StatFs(strSDcardPath).getAvailableBytes() - ((long) recFile.getnFileSize()) > 0) {
                            fileDiir = new File(strSavePath);
                            if (!fileDiir.exists()) {
                                fileDiir.mkdir();
                            }
                            if (!(PlaybackFragment.this.mRecFileDownloader == null || !PlaybackFragment.this.mRecFileDownloader.isDownloading() || PlaybackFragment.this.mDLFileListPosition == -1 || PlaybackFragment.this.mDLFilePath == null)) {
                                result = PlaybackFragment.this.mRecFileDownloader.StopDownloadRecFile();
                                ((HashMap) RecFileListViewAdapter.this.mAppList.get(PlaybackFragment.this.mDLFileListPosition)).put("FileDownloadState", Integer.valueOf(2));
                                ((HashMap) RecFileListViewAdapter.this.mAppList.get(PlaybackFragment.this.mDLFileListPosition)).put("FileDownloadProgress", Integer.valueOf(0));
                                file1 = new File(PlaybackFragment.this.mDLFilePath);
                                if (file1.exists()) {
                                    new Thread(new Runnable() {
                                        public void run() {
                                            boolean deleteResult = file1.delete();
                                        }
                                    }).start();
                                }
                                PlaybackFragment.this.mDLFileListPosition = -1;
                                PlaybackFragment.this.mDLFilePath = null;
                            }
                            recFileDownloader = new RecFileDownloader();
                            i = position;
                            if (recFileDownloader.StartDownloadRecFile(new IDownloadCallback() {

                                class C04662 implements Runnable {
                                    C04662() {
                                    }

                                    public void run() {
                                        if (PlaybackFragment.this.recFileListView.getAdapter() != null) {
                                            ((RecFileListViewAdapter) PlaybackFragment.this.recFileListView.getAdapter()).notifyDataSetChanged();
                                        }
                                    }
                                }

                                public void onDownloadProcess(Object arg0, int state, int progress) {
                                    ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadState", Integer.valueOf(state));
                                    ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadProgress", Integer.valueOf(progress));
                                    boolean stopResult;
                                    if (state == 1 || progress == 100) {
                                        stopResult = recFileDownloader.StopDownloadRecFile();
                                        ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadState", Integer.valueOf(1));
                                        ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadProgress", Integer.valueOf(0));
                                    } else if (state == -1) {
                                        stopResult = recFileDownloader.StopDownloadRecFile();
                                        ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadState", Integer.valueOf(-1));
                                        ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadProgress", Integer.valueOf(0));
                                        if (file.exists()) {
                                            final File file = file;
                                            new Thread(new Runnable() {
                                                public void run() {
                                                    boolean deleteResult = file.delete();
                                                }
                                            }).start();
                                        }
                                    }
                                    PlaybackFragment.this.getActivity().runOnUiThread(new C04662());
                                }
                            }, strFilePath, LocalDefines.Device_LoginHandle, recFile)) {
                                ((HashMap) RecFileListViewAdapter.this.mAppList.get(position)).put("FileDownloadState", Integer.valueOf(-2));
                                PlaybackFragment.this.mDLFileListPosition = position;
                                PlaybackFragment.this.mDLFilePath = strFilePath;
                                PlaybackFragment.this.mRecFileDownloader = recFileDownloader;
                                if (PlaybackFragment.this.recFileListView.getAdapter() != null) {
                                    ((RecFileListViewAdapter) PlaybackFragment.this.recFileListView.getAdapter()).notifyDataSetChanged();
                                    return;
                                }
                                return;
                            }
                            Toast.makeText(PlaybackFragment.this.relateAtivity, PlaybackFragment.this.getString(C0470R.string.downFail), 0).show();
                            return;
                        }
                        Toast.makeText(PlaybackFragment.this.relateAtivity, PlaybackFragment.this.getString(C0470R.string.str_storage_not_enough), 0).show();
                    } else if (fileDownloadState == 0 || fileDownloadState == -2) {
                        View viewDialog = View.inflate(PlaybackFragment.this.getActivity(), C0470R.layout.show_alert_dialog, null);
                        ((TextView) viewDialog.findViewById(C0470R.id.tv_title)).setText(PlaybackFragment.this.getString(C0470R.string.str_rec_file_cancle1));
                        ((TextView) viewDialog.findViewById(C0470R.id.tv_content)).setVisibility(8);
                        Builder negativeButton = new Builder(PlaybackFragment.this.getActivity()).setView(viewDialog).setNegativeButton(PlaybackFragment.this.getString(C0470R.string.alert_btn_NO), null);
                        CharSequence string = PlaybackFragment.this.getString(C0470R.string.alert_btn_YES);
                        i = position;
                        negativeButton.setPositiveButton(string, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                PlaybackFragment.this.mRecFileDownloader.StopDownloadRecFile();
                                ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadState", Integer.valueOf(2));
                                ((HashMap) RecFileListViewAdapter.this.mAppList.get(i)).put("FileDownloadProgress", Integer.valueOf(0));
                                if (PlaybackFragment.this.recFileListView.getAdapter() != null) {
                                    ((RecFileListViewAdapter) PlaybackFragment.this.recFileListView.getAdapter()).notifyDataSetChanged();
                                }
                                final File file = new File(PlaybackFragment.this.mDLFilePath);
                                if (file.exists()) {
                                    new Thread(new Runnable() {
                                        public void run() {
                                            boolean deleteResult = file.delete();
                                        }
                                    }).start();
                                }
                            }
                        }).show();
                    }
                }
            });
            return convertView;
        }
    }

    private class RecFileListViewAdapterCloud extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            TextView tvInfo;
            TextView tvName;
            TextView tvSize;
            TextView tvTimeLen;

            private ItemViewHolder() {
            }
        }

        public RecFileListViewAdapterCloud(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.recfile_list_item_cloud, null);
                this.holder = new ItemViewHolder();
                convertView.setTag(this.holder);
            }
            this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[0]);
            this.holder.tvInfo = (TextView) convertView.findViewById(this.valueViewID[1]);
            this.holder.tvSize = (TextView) convertView.findViewById(this.valueViewID[2]);
            this.holder.tvTimeLen = (TextView) convertView.findViewById(this.valueViewID[3]);
            HashMap<String, Object> map = (HashMap) this.mAppList.get(position);
            if (map != null) {
                String strSize = (String) map.get("FileSize");
                String strTimeLen = (String) map.get("FileTimeLen");
                String info = (String) map.get("FileName");
                this.holder.tvName.setText((String) map.get("FileStartTime"));
                this.holder.tvTimeLen.setText(strTimeLen);
                this.holder.tvSize.setText(strSize);
                this.holder.tvInfo.setText(info);
            }
            return convertView;
        }
    }

    public class RecFileSearcher extends Thread {
        private DeviceInfo info = null;
        private int m_nSearchID = 0;
        private int nThreadID = 0;

        public RecFileSearcher(DeviceInfo info, int nSearchID, int nThreadID) {
            this.m_nSearchID = nSearchID;
            this.info = info;
            this.nThreadID = nThreadID;
        }

        public void run() {
            PlaybackFragment playbackFragment = PlaybackFragment.this;
            playbackFragment.m_nLoginExID = playbackFragment.m_nLoginExID + 1;
            long lTimeNow = new Date().getTime();
            boolean isAccountChange = false;
            if (LocalDefines._nDeviceID != this.info.getnDevID()) {
                isAccountChange = true;
            } else if (LocalDefines._strUserName == null && this.info.getStrUsername() != null) {
                isAccountChange = true;
            } else if (LocalDefines._strPassword == null && this.info.getStrPassword() != null) {
                isAccountChange = true;
            } else if (!(LocalDefines._strUserName.equals(this.info.getStrUsername()) && LocalDefines._strPassword.equals(this.info.getStrPassword()))) {
                isAccountChange = true;
            }
            if (isAccountChange || LocalDefines._lHandle <= 0 || lTimeNow - LocalDefines._lHandleGetTime > 30000) {
                PlaybackFragment.this._deviceParam = null;
                PlaybackFragment.this._deviceParam = LoginHelperEX.getDeviceParamRecordFileEX(this.info);
                long lHandle = PlaybackFragment.this._deviceParam.getlHandle();
                LocalDefines.Device_LoginHandle = PlaybackFragment.this._deviceParam;
                LocalDefines._nDeviceID = this.info.getnDevID();
                LocalDefines._strUserName = this.info.getStrUsername();
                LocalDefines._strUserName = this.info.getStrPassword();
                LocalDefines._isMRMode = PlaybackFragment.this._deviceParam.isMRMode();
                LocalDefines._lHandle = lHandle;
            }
            if (Defines._lHandle > 0) {
                Defines._lHandleGetTime = new Date().getTime();
            }
            if (PlaybackFragment.this._deviceParam != null && PlaybackFragment.this._deviceParam.getnResult() == 256 && PlaybackFragment.this.m_nThreadID == this.nThreadID) {
                RecordFileHelper.getRecordFiles(PlaybackFragment.this._deviceParam, PlaybackFragment.this.handler, PlaybackFragment.this.nSearchChn, this.m_nSearchID, PlaybackFragment.this.nYear, PlaybackFragment.this.nMonth, PlaybackFragment.this.nDay, PlaybackFragment.this.nStartHour, PlaybackFragment.this.nStartMin, PlaybackFragment.this.nStartSec, PlaybackFragment.this.nEndHour, PlaybackFragment.this.nEndMin, PlaybackFragment.this.nEndSec, this.info.getnDevID());
            } else if (PlaybackFragment.this._deviceParam != null && PlaybackFragment.this.m_nThreadID == this.nThreadID) {
                msg = PlaybackFragment.this.handler.obtainMessage();
                msg = PlaybackFragment.this.handler.obtainMessage();
                msg.arg1 = 259;
                msg.arg2 = PlaybackFragment.this._deviceParam.getnResult();
                PlaybackFragment.this.handler.sendMessage(msg);
            } else if (PlaybackFragment.this.m_nThreadID == this.nThreadID) {
                msg = PlaybackFragment.this.handler.obtainMessage();
                msg = PlaybackFragment.this.handler.obtainMessage();
                msg.arg1 = 259;
                msg.arg2 = ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL;
                PlaybackFragment.this.handler.sendMessage(msg);
            }
        }
    }

    public class RecFileSearcherCloud extends Thread {
        private DeviceInfo info = null;
        private int nSearchType = 0;
        private int nThreadID = 0;

        public RecFileSearcherCloud(DeviceInfo info, int nSearchType, int nThreadID) {
            this.nSearchType = nSearchType;
            this.info = info;
            this.nThreadID = nThreadID;
        }

        public void run() {
            long lHandle = (long) PlaybackFragment.this.deviceInfo.getnDevID();
            LocalDefines.Device_LoginHandle = LoginHelperEX.getDeviceParamRecordFileEX(this.info);
            int nResult = CloudServiceHelper.Cloud_getRecordFileServer(0, PlaybackFragment.this.mAccesstoken, PlaybackFragment.this.mUserId, PlaybackFragment.this.handler, lHandle, PlaybackFragment.this.mEcsIP, PlaybackFragment.this.mEcsPort, 0, this.nSearchType, PlaybackFragment.this.nYear, PlaybackFragment.this.nMonth, PlaybackFragment.this.nDay, PlaybackFragment.this.nStartHour, PlaybackFragment.this.nStartMin, PlaybackFragment.this.nStartSec, PlaybackFragment.this.nEndHour, PlaybackFragment.this.nEndMin, PlaybackFragment.this.nEndSec);
            if (nResult != 256 && PlaybackFragment.this.m_nThreadID == PlaybackFragment.this.mGetRecFileId) {
                Message msg = PlaybackFragment.this.handler.obtainMessage();
                msg.arg1 = 259;
                msg.arg2 = nResult;
                PlaybackFragment.this.handler.sendMessage(msg);
            }
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!this.isInit) {
            Calendar calendar = Calendar.getInstance();
            this.nYear = (short) calendar.get(1);
            this.nMonth = (short) calendar.get(2);
            this.nDay = (short) calendar.get(5);
            this.nYear_Cloud = (short) calendar.get(1);
            this.nMonth_Cloud = (short) calendar.get(2);
            this.nDay_Cloud = (short) calendar.get(5);
            this.nStartHour = (short) 0;
            this.nStartMin = (short) 0;
            this.nStartSec = (short) 0;
            this.nStartHour_Cloud = (short) 0;
            this.nStartMin_Cloud = (short) 0;
            this.nStartSec_Cloud = (short) 0;
            this.nEndHour = (short) 23;
            this.nEndMin = (short) 59;
            this.nEndSec = (short) 0;
            this.nEndHour_Cloud = (short) 23;
            this.nEndMin_Cloud = (short) 59;
            this.nEndSec_Cloud = (short) 0;
            this.isInit = true;
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_playback, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        this.mAccesstoken = getActivity().getSharedPreferences("SaveSign", 0).getString("saveToken", Constants.MAIN_VERSION_TAG);
        this.mUserId = getActivity().getSharedPreferences("SaveSign", 0).getInt("saveServeruserid", -101);
        this.mEcsIP = getActivity().getSharedPreferences("SaveSign", 0).getString("saveloginEcsIp", Constants.MAIN_VERSION_TAG);
        this.mEcsPort = getActivity().getSharedPreferences("SaveSign", 0).getInt("saveloginEcsport", 0);
        this.mEcsIP2 = getActivity().getSharedPreferences("SaveSign", 0).getString("saveloginEcsIp2", Constants.MAIN_VERSION_TAG);
        this.mEcsPort2 = getActivity().getSharedPreferences("SaveSign", 0).getInt("saveloginEcsport2", 0);
        InitSubView();
        createDialogs();
        createDialogsCloud();
        presentShowcaseSequence();
        return v;
    }

    public void onPause() {
        super.onPause();
        this.isActive = false;
        this.bIsRecFileSearching = false;
    }

    public void onResume() {
        super.onResume();
        this.isActive = true;
    }

    public void onDestroy() {
        stopCurrentDownloadTask();
        System.gc();
        this.m_nThreadID++;
        super.onDestroy();
    }

    private void InitSubView() {
        this.llPlayBackTitle = (LinearLayout) this.contentView.findViewById(C0470R.id.llPlayBackTitle);
        createLoadingDialog();
        this.ll_SearchType_Non_CN = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_SearchType_Non_CN);
        this.ll_SearchType_CN = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_SearchType_CN);
        this.llSearchType = (LinearLayout) this.contentView.findViewById(C0470R.id.llSearchType);
        this.llSearchType.setOnClickListener(this);
        this.llPlayerBackType_non_CN = (LinearLayout) this.contentView.findViewById(C0470R.id.llPlayerBackType_non_CN);
        this.isZh = LocalDefines.isZh(getActivity());
        if (this.isZh) {
            this.ll_SearchType_CN.setVisibility(0);
            this.ll_SearchType_Non_CN.setVisibility(8);
        } else {
            this.ll_SearchType_CN.setVisibility(8);
            this.ll_SearchType_Non_CN.setVisibility(0);
        }
        this.tvCloudVideo = (TextView) this.contentView.findViewById(C0470R.id.txt_Cloud_video);
        this.tvTFVideo = (TextView) this.contentView.findViewById(C0470R.id.txt_TF_Video);
        this.ll_cloud_record = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_cloud_record);
        this.ll_search_date = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_search_date);
        this.ll_search_date.setOnClickListener(this);
        this.ll_search_start_time = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_search_start_time);
        this.ll_search_start_time.setOnClickListener(this);
        this.ll_search_end_time = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_search_end_time);
        this.ll_search_end_time.setOnClickListener(this);
        this.ivNvplayerBack = (ImageView) this.contentView.findViewById(C0470R.id.ivNvplayerBack);
        this.ivNvplayerBack.setOnClickListener(this);
        this.ivPlayerBackType = (ImageView) this.contentView.findViewById(C0470R.id.ivPlayer_back_type);
        this.ivPlayerBackType2 = (ImageView) this.contentView.findViewById(C0470R.id.ivPlayer_back_type2);
        this.llAll = (LinearLayout) this.contentView.findViewById(C0470R.id.llAll);
        LinearLayout view = (LinearLayout) View.inflate(getActivity(), C0470R.layout.popup_window_listview2, null);
        this.serverlistView = (ListView) view.findViewById(C0470R.id.lvPlayer_back);
        this.popupListView = new PopupWindow(view, -1, -2);
        this.popupListView.setFocusable(true);
        this.popupListView.setOutsideTouchable(true);
        this.popupListView.setAnimationStyle(C0470R.style.popupwindow_device_list);
        this.popupListView.setBackgroundDrawable(new BitmapDrawable());
        this.popupListView.setOnDismissListener(new C04472());
        this.btnStartSearchCloud = (Button) this.contentView.findViewById(C0470R.id.btnStartSearchCloud);
        this.btnStartSearchCloud.setOnClickListener(this);
        this.btnSearch = (Button) this.contentView.findViewById(C0470R.id.btnSearch);
        this.btnSearch.setOnClickListener(this);
        this.btnDeviceSelectBack_Cloud = (ImageView) this.contentView.findViewById(C0470R.id.btnDeviceSelectBack_Cloud);
        this.btnDeviceSelectBack_Cloud.setOnClickListener(this);
        this.llPlayerBackType = (LinearLayout) this.contentView.findViewById(C0470R.id.llPlayerBackType);
        this.llCloudRec = (LinearLayout) this.contentView.findViewById(C0470R.id.llCloudRec);
        this.llCloudRec.setOnClickListener(this);
        this.llTFCardRec = (LinearLayout) this.contentView.findViewById(C0470R.id.llTFCardRec);
        this.llTFCardRec.setOnClickListener(this);
        this.tvPlayerBackType = (TextView) this.contentView.findViewById(C0470R.id.txt_TF_Video);
        this.tvPlayerBackType2 = (TextView) this.contentView.findViewById(C0470R.id.tvPlayer_back_type);
        this.layoutSearchParam = (RelativeLayout) this.contentView.findViewById(C0470R.id.layoutSearchParam);
        this.layoutRecFileList = (LinearLayout) this.contentView.findViewById(C0470R.id.layoutRecFileList);
        this.btnStartSearch = (Button) this.contentView.findViewById(C0470R.id.btnStartSearch);
        this.btnStartSearch.setOnClickListener(this);
        this.btnListVisible = (Button) this.contentView.findViewById(C0470R.id.btnListVisible);
        this.btnListVisible.setOnClickListener(this);
        this.btnDeviceSelectBack = (ImageView) this.contentView.findViewById(C0470R.id.btnDeviceSelectBack);
        this.btnDeviceSelectBack.setOnClickListener(this);
        this.recFileListView = (ListView) this.contentView.findViewById(C0470R.id.recfile_list);
        this.recFileListView.setOnItemClickListener(this);
        setListviewOnScrollListener();
        this.layoutDevice = (LinearLayout) this.contentView.findViewById(C0470R.id.layoutDevice);
        this.layoutDevice.setOnClickListener(this);
        this.layoutSearchDate = (LinearLayout) this.contentView.findViewById(C0470R.id.layoutSearchDate);
        this.layoutSearchDate.setOnClickListener(this);
        this.layoutSearchEndTime = (LinearLayout) this.contentView.findViewById(C0470R.id.layoutSearchEndTime);
        this.layoutSearchEndTime.setOnClickListener(this);
        this.layoutSearchStartTime = (LinearLayout) this.contentView.findViewById(C0470R.id.layoutSearchStartTime);
        this.layoutSearchStartTime.setOnClickListener(this);
        this.textViewDevice = (TextView) this.contentView.findViewById(C0470R.id.textViewDevice);
        this.textViewDate = (TextView) this.contentView.findViewById(C0470R.id.textViewDate);
        this.textViewStartTime = (TextView) this.contentView.findViewById(C0470R.id.textViewStartTime);
        this.textViewEndTime = (TextView) this.contentView.findViewById(C0470R.id.textViewEndTime);
        this.tvDate = (TextView) this.contentView.findViewById(C0470R.id.tvDate);
        this.tvStartTime = (TextView) this.contentView.findViewById(C0470R.id.tvStartTime);
        this.tvEndTime = (TextView) this.contentView.findViewById(C0470R.id.tvEndTime);
        if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
            this.textViewDevice.setText(getString(C0470R.string.noDevice));
        } else {
            if (LocalDefines._PlatbackListviewSelectedPosition < 0 || LocalDefines._PlatbackListviewSelectedPosition >= LocalDefines._severInfoListData.size()) {
                LocalDefines._PlatbackListviewSelectedPosition = 0;
            }
            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(LocalDefines._PlatbackListviewSelectedPosition);
            if (!(info == null || this.textViewDevice == null)) {
                this.textViewDevice.setText(info.getStrName());
                this.deviceInfo = info;
            }
        }
        if (this.isListVisible) {
            this.layoutSearchParam.setVisibility(8);
            this.layoutRecFileList.setVisibility(0);
            if (this.isLoadFromDatabase) {
                GetRecFileListFromDatabase();
            } else {
                refleshRecFileList();
            }
        } else {
            this.layoutSearchParam.setVisibility(0);
            this.layoutRecFileList.setVisibility(8);
            if (this.isLoadFromDatabase) {
                GetRecFileListFromDatabase();
            }
        }
        if (this.nMonth < (short) 9 && this.nDay < (short) 10) {
            this.textViewDate.setText(this.nYear + "-0" + (this.nMonth + 1) + "-0" + this.nDay);
        } else if (this.nMonth >= (short) 9 && this.nDay < (short) 10) {
            this.textViewDate.setText(this.nYear + "-" + (this.nMonth + 1) + "-0" + this.nDay);
        } else if (this.nMonth >= (short) 9 || this.nDay < (short) 10) {
            this.textViewDate.setText(this.nYear + "-" + (this.nMonth + 1) + "-" + this.nDay);
        } else {
            this.textViewDate.setText(this.nYear + "-0" + (this.nMonth + 1) + "-" + this.nDay);
        }
        if (this.nStartHour <= (short) 9 && this.nStartMin <= (short) 9) {
            this.textViewStartTime.setText("0" + this.nStartHour + ":0" + this.nStartMin);
        } else if (this.nStartHour <= (short) 9 && this.nStartMin > (short) 9) {
            this.textViewStartTime.setText("0" + this.nStartHour + ":" + this.nStartMin);
        } else if (this.nStartHour <= (short) 9 || this.nStartMin > (short) 9) {
            this.textViewStartTime.setText(this.nStartHour + ":" + this.nStartMin);
        } else {
            this.textViewStartTime.setText(this.nStartHour + ":0" + this.nStartMin);
        }
        if (this.nEndHour <= (short) 9 && this.nStartMin <= (short) 9) {
            this.textViewEndTime.setText("0" + this.nEndHour + ":0" + this.nEndMin);
        } else if (this.nEndHour <= (short) 9 && this.nStartMin > (short) 9) {
            this.textViewEndTime.setText("0" + this.nEndHour + ":" + this.nEndMin);
        } else if (this.nEndHour <= (short) 9 || this.nEndMin > (short) 9) {
            this.textViewEndTime.setText(this.nEndHour + ":" + this.nEndMin);
        } else {
            this.textViewEndTime.setText(this.nEndHour + ":0" + this.nEndMin);
        }
        if (this.nMonth_Cloud < (short) 9 && this.nDay_Cloud < (short) 10) {
            this.tvDate.setText(this.nYear_Cloud + "-0" + (this.nMonth_Cloud + 1) + "-0" + this.nDay_Cloud);
        } else if (this.nMonth_Cloud >= (short) 9 && this.nDay < (short) 10) {
            this.tvDate.setText(this.nYear_Cloud + "-" + (this.nMonth_Cloud + 1) + "-0" + this.nDay_Cloud);
        } else if (this.nMonth_Cloud >= (short) 9 || this.nDay_Cloud < (short) 10) {
            this.tvDate.setText(this.nYear_Cloud + "-" + (this.nMonth_Cloud + 1) + "-" + this.nDay_Cloud);
        } else {
            this.tvDate.setText(this.nYear_Cloud + "-0" + (this.nMonth_Cloud + 1) + "-" + this.nDay_Cloud);
        }
        if (this.nStartHour_Cloud <= (short) 9 && this.nStartMin_Cloud <= (short) 9) {
            this.tvStartTime.setText("0" + this.nStartHour_Cloud + ":0" + this.nStartMin_Cloud);
        } else if (this.nStartHour_Cloud <= (short) 9 && this.nStartMin_Cloud > (short) 9) {
            this.tvStartTime.setText("0" + this.nStartHour_Cloud + ":" + this.nStartMin_Cloud);
        } else if (this.nStartHour_Cloud <= (short) 9 || this.nStartMin_Cloud > (short) 9) {
            this.tvStartTime.setText(this.nStartHour_Cloud + ":" + this.nStartMin_Cloud);
        } else {
            this.tvStartTime.setText(this.nStartHour_Cloud + ":0" + this.nStartMin_Cloud);
        }
        if (this.nEndHour_Cloud <= (short) 9 && this.nStartMin_Cloud <= (short) 9) {
            this.tvEndTime.setText("0" + this.nEndHour_Cloud + ":0" + this.nEndMin_Cloud);
        } else if (this.nEndHour_Cloud <= (short) 9 && this.nStartMin_Cloud > (short) 9) {
            this.tvEndTime.setText("0" + this.nEndHour_Cloud + ":" + this.nEndMin_Cloud);
        } else if (this.nEndHour_Cloud <= (short) 9 || this.nEndMin_Cloud > (short) 9) {
            this.tvEndTime.setText(this.nEndHour_Cloud + ":" + this.nEndMin_Cloud);
        } else {
            this.tvEndTime.setText(this.nEndHour_Cloud + ":0" + this.nEndMin_Cloud);
        }
        this.tvDeviceId = (TextView) this.contentView.findViewById(C0470R.id.tv_device_id);
        String strRecordFileHintText = getString(C0470R.string.str_cloud_record_search);
        if (this.deviceInfo != null) {
            this.tvDeviceId.setText(String.valueOf(new StringBuilder(String.valueOf(strRecordFileHintText)).append(this.deviceInfo.getnDevID()).toString()));
        }
        this.llTypeAll = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_type_all);
        this.llTypeAuto = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_type_auto);
        this.llTypeAlarm = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_type_alarm);
        this.llTypeAuto.setOnClickListener(this);
        this.llTypeAll.setOnClickListener(this);
        this.llTypeAlarm.setOnClickListener(this);
        this.llTypeAll_non_CN = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_type_all_non_CN);
        this.llTypeAuto_non_CN = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_type_auto_non_CN);
        this.llTypeAlarm_non_CN = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_type_alarm_non_CN);
        this.llTypeAll_non_CN.setOnClickListener(this);
        this.llTypeAuto_non_CN.setOnClickListener(this);
        this.llTypeAlarm_non_CN.setOnClickListener(this);
        this.ivTypeAll = (ImageView) this.contentView.findViewById(C0470R.id.iv_type_all);
        this.ivTypeAuto = (ImageView) this.contentView.findViewById(C0470R.id.iv_type_auto);
        this.ivTypeAlarm = (ImageView) this.contentView.findViewById(C0470R.id.iv_type_alarm);
        this.ivTypeAll_non_CN = (ImageView) this.contentView.findViewById(C0470R.id.iv_type_all_non_CN);
        this.ivTypeAuto_non_CN = (ImageView) this.contentView.findViewById(C0470R.id.iv_type_auto_non_CN);
        this.ivTypeAlarm_non_CN = (ImageView) this.contentView.findViewById(C0470R.id.iv_type_alarm_non_CN);
        switch (this.nSearchType) {
            case 0:
                this.ivTypeAll.setImageResource(C0470R.drawable.radio_select_check);
                this.ivTypeAuto.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAlarm.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAll_non_CN.setImageResource(C0470R.drawable.radio_select_check);
                this.ivTypeAuto_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAlarm_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                return;
            case 1:
                this.ivTypeAll.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAuto.setImageResource(C0470R.drawable.radio_select_check);
                this.ivTypeAlarm.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAll_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAuto_non_CN.setImageResource(C0470R.drawable.radio_select_check);
                this.ivTypeAlarm_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                return;
            case 3:
                this.ivTypeAll.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAuto.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAlarm.setImageResource(C0470R.drawable.radio_select_check);
                this.ivTypeAll_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAuto_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAlarm_non_CN.setImageResource(C0470R.drawable.radio_select_check);
                return;
            default:
                return;
        }
    }

    private void createDialogs() {
        this.deviceSelectConctentView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.devices_select_dialog, null);
        this.deviceSelectDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.deviceSelectDialog.setContentView(this.deviceSelectConctentView);
        this.deviceSelectDialog.setOnShowListener(new C04483());
        this.deviceSelectDialog.setOnDismissListener(new C04494());
        this.datetimeSelectConctentView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.datetime_select_dialog, null);
        this.datetimeSelectDialog = new Dialog(this.relateAtivity, C0470R.style.dialog_bg_transparent);
        this.datetimeSelectDialog.setContentView(this.datetimeSelectConctentView);
        this.datetimeSelectDialog.setOnShowListener(new C04535());
        this.datetimeSelectDialog.setOnDismissListener(new C04546());
    }

    private void createDialogsCloud() {
        this.deviceSelectConctentView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.devices_select_dialog, null);
        this.deviceSelectDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.deviceSelectDialog.setContentView(this.deviceSelectConctentView);
        this.deviceSelectDialog.setOnShowListener(new C04557());
        this.deviceSelectDialog.setOnDismissListener(new C04568());
        this.datetimeSelectConctentViewCloud = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.datetime_cloud_select_dialog, null);
        this.datetimeSelectDialogCloud = new Dialog(this.relateAtivity, C0470R.style.dialog_bg_transparent);
        this.datetimeSelectDialogCloud.setContentView(this.datetimeSelectConctentViewCloud);
        this.datetimeSelectDialogCloud.setOnShowListener(new C04609());
        this.datetimeSelectDialogCloud.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
            }
        });
    }

    public void backPlayBack() {
        if (this.mRecFileDownloader == null || !this.mRecFileDownloader.isDownloading() || this.mDLFileListPosition == -1 || this.mDLFilePath == null) {
            this.layoutSearchParam.setVisibility(0);
            this.layoutRecFileList.setVisibility(8);
            LocalDefines.bIsBackPlay = false;
            ((HomePageActivity) this.relateAtivity).setGuideBarVisible(true);
            return;
        }
        View viewDialog = View.inflate(getActivity(), C0470R.layout.show_alert_dialog, null);
        ((TextView) viewDialog.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.str_rec_file_cancle1));
        ((TextView) viewDialog.findViewById(C0470R.id.tv_content)).setVisibility(8);
        new Builder(getActivity()).setView(viewDialog).setNegativeButton(getString(C0470R.string.alert_btn_NO), null).setPositiveButton(getString(C0470R.string.alert_btn_YES), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                boolean result = PlaybackFragment.this.mRecFileDownloader.StopDownloadRecFile();
                final File file1 = new File(PlaybackFragment.this.mDLFilePath);
                if (file1.exists()) {
                    new Thread(new Runnable() {
                        public void run() {
                            boolean deleteResult = file1.delete();
                        }
                    }).start();
                }
                PlaybackFragment.this.mDLFileListPosition = -1;
                PlaybackFragment.this.mDLFilePath = null;
                PlaybackFragment.this.layoutSearchParam.setVisibility(0);
                PlaybackFragment.this.layoutRecFileList.setVisibility(8);
                LocalDefines.bIsBackPlay = false;
                ((HomePageActivity) PlaybackFragment.this.relateAtivity).setGuideBarVisible(true);
            }
        }).show();
    }

    public void onClick(View v) {
        Toast toast;
        switch (v.getId()) {
            case C0470R.id.llSearchType:
                this.isSearchCloudRec = false;
                if (this.bSearchType) {
                    this.bSearchType = false;
                    this.llPlayerBackType_non_CN.setVisibility(0);
                    this.ivPlayerBackType2.setImageResource(C0470R.drawable.play_back_video_back_1);
                    return;
                }
                this.bSearchType = true;
                this.llPlayerBackType_non_CN.setVisibility(8);
                this.ivPlayerBackType2.setImageResource(C0470R.drawable.play_back_video_back_2);
                return;
            case C0470R.id.ll_type_all:
                this.nSearchType = 0;
                this.isZh = LocalDefines.isZh(getActivity());
                this.ivTypeAll.setImageResource(C0470R.drawable.radio_select_check);
                this.ivTypeAuto.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAlarm.setImageResource(C0470R.drawable.radio_select_uncheck);
                return;
            case C0470R.id.ll_type_auto:
                this.nSearchType = 1;
                this.isZh = LocalDefines.isZh(getActivity());
                this.ivTypeAll.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAuto.setImageResource(C0470R.drawable.radio_select_check);
                this.ivTypeAlarm.setImageResource(C0470R.drawable.radio_select_uncheck);
                return;
            case C0470R.id.ll_type_alarm:
                this.nSearchType = 3;
                this.isZh = LocalDefines.isZh(getActivity());
                this.ivTypeAll.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAuto.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAlarm.setImageResource(C0470R.drawable.radio_select_check);
                return;
            case C0470R.id.ll_search_date:
                ShowDateSelectViewCloud();
                return;
            case C0470R.id.ll_search_start_time:
                ShowStartTimeSelectViewCloud();
                return;
            case C0470R.id.ll_search_end_time:
                ShowEndTimeSelectViewCloud();
                return;
            case C0470R.id.ivNvplayerBack:
                if (this.popupListView == null || !this.popupListView.isShowing()) {
                    ((HomePageActivity) this.relateAtivity).ChangeFragment(10, 10, null);
                    return;
                }
                this.popupListView.dismiss();
                this.bSearchType = true;
                this.btnListVisible.setVisibility(0);
                return;
            case C0470R.id.btnListVisible:
                if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
                    Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                    return;
                }
                this.isListVisible = true;
                this.layoutSearchParam.setVisibility(8);
                this.layoutRecFileList.setVisibility(0);
                ((HomePageActivity) this.relateAtivity).setGuideBarVisible(false);
                GetRecFileListFromDatabase();
                return;
            case C0470R.id.layoutDevice:
                if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
                    Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                    return;
                }
                this.bSearchType = true;
                this.popupListView.showAsDropDown(this.layoutDevice, 0, -10);
                this.btnListVisible.setVisibility(4);
                updateServerListView();
                return;
            case C0470R.id.ll_type_all_non_CN:
                this.nSearchType = 0;
                this.tvPlayerBackType2.setText(getString(C0470R.string.AllPlayBack));
                this.ivTypeAll_non_CN.setImageResource(C0470R.drawable.radio_select_check);
                this.ivTypeAuto_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAlarm_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                return;
            case C0470R.id.ll_type_auto_non_CN:
                this.nSearchType = 1;
                this.tvPlayerBackType2.setText(getString(C0470R.string.record_auto_record_title));
                this.ivTypeAll_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAuto_non_CN.setImageResource(C0470R.drawable.radio_select_check);
                this.ivTypeAlarm_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                return;
            case C0470R.id.ll_type_alarm_non_CN:
                this.nSearchType = 3;
                this.tvPlayerBackType2.setText(getString(C0470R.string.strAlarm));
                this.ivTypeAll_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAuto_non_CN.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.ivTypeAlarm_non_CN.setImageResource(C0470R.drawable.radio_select_check);
                return;
            case C0470R.id.llCloudRec:
                this.bSearchType = true;
                this.llPlayerBackType.setVisibility(8);
                this.ivPlayerBackType.setImageResource(C0470R.drawable.play_back_video_back_2);
                this.isZh = LocalDefines.isZh(getActivity());
                if (!this.isZh) {
                    return;
                }
                if (HomePageActivity.AppMode != 1) {
                    Toast.makeText(getActivity(), getString(C0470R.string.str_please_login_to_use), 0).show();
                    return;
                } else if (this.deviceInfo.getnProductId() > 0) {
                    this.isSearchCloudRec = true;
                    this.tvTFVideo.setTextColor(getResources().getColor(C0470R.color.font_color_gray));
                    this.tvCloudVideo.setTextColor(getResources().getColor(C0470R.color.font_color_sky_blue2));
                    return;
                } else if (this.deviceInfo.getnProductId() == 0) {
                    Toast.makeText(getActivity(), getString(C0470R.string.str_bind_to_use), 0).show();
                    return;
                } else {
                    Toast.makeText(getActivity(), getString(C0470R.string.str_bind_to_use), 0).show();
                    return;
                }
            case C0470R.id.llTFCardRec:
                this.isSearchCloudRec = false;
                this.tvTFVideo.setTextColor(getResources().getColor(C0470R.color.font_color_sky_blue2));
                this.tvCloudVideo.setTextColor(getResources().getColor(C0470R.color.font_color_gray));
                if (this.bSearchType) {
                    this.bSearchType = false;
                    this.llPlayerBackType.setVisibility(0);
                    this.ivPlayerBackType.setImageResource(C0470R.drawable.play_back_video_back_1);
                    return;
                }
                this.bSearchType = true;
                this.llPlayerBackType.setVisibility(8);
                this.ivPlayerBackType.setImageResource(C0470R.drawable.play_back_video_back_2);
                return;
            case C0470R.id.layoutSearchDate:
                ShowDateSelectView();
                return;
            case C0470R.id.layoutSearchStartTime:
                ShowStartTimeSelectView();
                return;
            case C0470R.id.layoutSearchEndTime:
                ShowEndTimeSelectView();
                return;
            case C0470R.id.btnStartSearch:
                if (this.isSearchCloudRec) {
                    this.isCloudFileList = true;
                    this.isListVisible = true;
                    this.layoutSearchParam.setVisibility(8);
                    this.layoutRecFileList.setVisibility(0);
                    GetCloudRecFileList();
                    return;
                }
                this.isCloudFileList = false;
                DatabaseManager.ClearRecInfos();
                this.fileList.clear();
                if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
                    Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                    return;
                } else if (LocalDefines._PlatbackListviewSelectedPosition < 0 || LocalDefines._PlatbackListviewSelectedPosition >= LocalDefines._severInfoListData.size()) {
                    toast = Toast.makeText(this.relateAtivity.getApplicationContext(), getString(C0470R.string.noticNoDeviceSelect), 0);
                    toast.setGravity(17, 0, 0);
                    toast.show();
                    return;
                } else {
                    this.isListVisible = true;
                    this.layoutSearchParam.setVisibility(8);
                    this.layoutRecFileList.setVisibility(0);
                    GetRecFileList();
                    return;
                }
            case C0470R.id.btnStartSearchCloud:
                this.isCloudFileList = true;
                this.isListVisible = true;
                this.layoutSearchParam.setVisibility(8);
                this.layoutRecFileList.setVisibility(0);
                GetCloudRecFileList();
                return;
            case C0470R.id.btnDeviceSelectBack:
                this.isListVisible = false;
                backPlayBack();
                return;
            case C0470R.id.btnDeviceSelectBack_Cloud:
                this.layoutSearchParam.setVisibility(0);
                this.ll_cloud_record.setVisibility(8);
                return;
            case C0470R.id.btnDatetimeSelectCancel:
                this.nDatetimeMode = 0;
                if (this.datetimeSelectDialog != null && this.datetimeSelectDialog.isShowing()) {
                    this.datetimeSelectDialog.dismiss();
                    return;
                }
                return;
            case C0470R.id.btnDatetimeSelectOK:
                String strHour;
                String strMinute;
                switch (this.nDatetimeMode) {
                    case 100:
                        this.nYear = (short) this.mSelectDatePicker.getYear();
                        this.nMonth = (short) this.mSelectDatePicker.getMonth();
                        this.nDay = (short) this.mSelectDatePicker.getDayOfMonth();
                        if (this.nMonth >= (short) 9 || this.nDay >= (short) 10) {
                            if (this.nMonth < (short) 9 || this.nDay >= (short) 10) {
                                if (this.nMonth < (short) 9 && this.nDay >= (short) 10) {
                                    this.textViewDate.setText(this.nYear + "-0" + (this.nMonth + 1) + "-" + this.nDay);
                                    break;
                                } else {
                                    this.textViewDate.setText(this.nYear + "-" + (this.nMonth + 1) + "-" + this.nDay);
                                    break;
                                }
                            }
                            this.textViewDate.setText(this.nYear + "-" + (this.nMonth + 1) + "-0" + this.nDay);
                            break;
                        }
                        this.textViewDate.setText(this.nYear + "-0" + (this.nMonth + 1) + "-0" + this.nDay);
                        break;
                        break;
                    case 101:
                        if (this.mSelectTimePicker.getCurrentHour().intValue() <= this.nEndHour && (this.mSelectTimePicker.getCurrentHour().intValue() != this.nEndHour || this.mSelectTimePicker.getCurrentMinute().intValue() <= this.nEndMin)) {
                            this.nStartHour = (short) this.mSelectTimePicker.getCurrentHour().intValue();
                            this.nStartMin = (short) this.mSelectTimePicker.getCurrentMinute().intValue();
                            this.nStartSec = (short) 0;
                            strHour = Constants.MAIN_VERSION_TAG;
                            strMinute = Constants.MAIN_VERSION_TAG;
                            if (this.nStartHour < (short) 10) {
                                strHour = "0" + this.nStartHour;
                            } else {
                                strHour = this.nStartHour;
                            }
                            if (this.nStartMin < (short) 10) {
                                strMinute = "0" + this.nStartMin;
                            } else {
                                strMinute = this.nStartMin;
                            }
                            this.textViewStartTime.setText(new StringBuilder(String.valueOf(strHour)).append(":").append(strMinute).toString());
                            break;
                        }
                        toast = Toast.makeText(this.relateAtivity.getApplicationContext(), getString(C0470R.string.noticStartlargeThanEnd), 0);
                        toast.setGravity(17, 0, 0);
                        toast.show();
                        break;
                        break;
                    case 102:
                        if (this.mSelectTimePicker.getCurrentHour().intValue() >= this.nStartHour && (this.mSelectTimePicker.getCurrentHour().intValue() != this.nStartHour || this.mSelectTimePicker.getCurrentMinute().intValue() >= this.nStartMin)) {
                            this.nEndHour = (short) this.mSelectTimePicker.getCurrentHour().intValue();
                            this.nEndMin = (short) this.mSelectTimePicker.getCurrentMinute().intValue();
                            this.nEndSec = (short) 0;
                            strHour = Constants.MAIN_VERSION_TAG;
                            strMinute = Constants.MAIN_VERSION_TAG;
                            if (this.nEndHour < (short) 10) {
                                strHour = "0" + this.nEndHour;
                            } else {
                                strHour = this.nEndHour;
                            }
                            if (this.nEndMin < (short) 10) {
                                strMinute = "0" + this.nEndMin;
                            } else {
                                strMinute = this.nEndMin;
                            }
                            this.textViewEndTime.setText(new StringBuilder(String.valueOf(strHour)).append(":").append(strMinute).toString());
                            break;
                        }
                        toast = Toast.makeText(this.relateAtivity.getApplicationContext(), getString(C0470R.string.noticEndLessThanStart), 0);
                        toast.setGravity(17, 0, 0);
                        toast.show();
                        break;
                        break;
                }
                this.nDatetimeMode = 0;
                if (this.datetimeSelectDialog != null && this.datetimeSelectDialog.isShowing()) {
                    this.datetimeSelectDialog.dismiss();
                    return;
                }
                return;
            case C0470R.id.btnDeviceSelectCancel:
                if (this.deviceSelectDialog != null && this.deviceSelectDialog.isShowing()) {
                    this.deviceSelectDialog.dismiss();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void ShowRecFileList() {
        if (this.layoutSearchParam != null) {
            this.layoutSearchParam.setVisibility(8);
        }
        if (this.layoutRecFileList != null) {
            this.layoutRecFileList.setVisibility(0);
        }
    }

    public void HideRecFileList() {
        if (this.layoutSearchParam != null) {
            this.layoutSearchParam.setVisibility(0);
        }
        if (this.layoutRecFileList != null) {
            this.layoutRecFileList.setVisibility(8);
        }
    }

    public boolean isListVisible() {
        return this.isListVisible;
    }

    public void setListVisible(boolean isListVisible) {
        this.isListVisible = isListVisible;
        try {
            if (this.isListVisible) {
                ShowRecFileList();
            } else {
                HideRecFileList();
            }
        } catch (Exception e) {
        }
    }

    private void ShowDateSelectView() {
        this.nDatetimeMode = 100;
        this.datetimeSelectDialog.show();
    }

    private void ShowDateSelectViewCloud() {
        this.nDatetimeMode = 100;
        this.datetimeSelectDialogCloud.show();
    }

    private void ShowStartTimeSelectView() {
        this.nDatetimeMode = 101;
        this.datetimeSelectDialog.show();
    }

    private void ShowStartTimeSelectViewCloud() {
        this.nDatetimeMode = 101;
        this.datetimeSelectDialogCloud.show();
    }

    private void ShowEndTimeSelectView() {
        this.nDatetimeMode = 102;
        this.datetimeSelectDialog.show();
    }

    private void ShowEndTimeSelectViewCloud() {
        this.nDatetimeMode = 102;
        this.datetimeSelectDialogCloud.show();
    }

    private void sortRecFile(List<RecordFileInfo> list) {
        Collections.sort(list, new Comparator<RecordFileInfo>() {
            public int compare(RecordFileInfo lhs, RecordFileInfo rhs) {
                int result = lhs.getnFileID() - rhs.getnFileID();
                if (result < 0) {
                    return -1;
                }
                if (result > 0) {
                    return 1;
                }
                return 0;
            }
        });
    }

    public void refleshRecFileList() {
        String strInfo = Constants.MAIN_VERSION_TAG;
        if (this.fileList.size() > 0) {
            sortRecFile(this.fileList);
            ArrayList<HashMap<String, Object>> listItem = new ArrayList();
            for (int i = 0; i < this.fileList.size(); i++) {
                RecordFileInfo fileInfo = (RecordFileInfo) this.fileList.get(i);
                HashMap<String, Object> map = new HashMap();
                map.put("ItemTitleName", Integer.valueOf(C0470R.id.ItemFileName));
                map.put("ItemTitleInfo", Integer.valueOf(C0470R.id.ItemFileInfo));
                map.put("FileName", fileInfo.getStrFileName());
                int nFileSize = fileInfo.getnFileSize();
                String strSize = getString(C0470R.string.strFileSize);
                double fFileSize;
                if (nFileSize > 1024000) {
                    fFileSize = ((double) nFileSize) / 1048576.0d;
                    if (fFileSize >= 100.0d) {
                        strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.0f", new Object[]{Double.valueOf(fFileSize)})).append(" MB").toString();
                    } else if (fFileSize >= 1.0d) {
                        strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.1f", new Object[]{Double.valueOf(fFileSize)})).append(" MB").toString();
                    } else {
                        strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.2f", new Object[]{Double.valueOf(fFileSize)})).append(" MB").toString();
                    }
                } else if (nFileSize > 1024) {
                    fFileSize = ((double) nFileSize) / 1024.0d;
                    strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.0f", new Object[]{Double.valueOf(fFileSize)})).append(" KB").toString();
                } else {
                    strSize = new StringBuilder(String.valueOf(strSize)).append(nFileSize).append(" B").toString();
                }
                String strStartTime = getString(C0470R.string.strStartTime);
                if (fileInfo.getuStartHour() >= 10) {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(fileInfo.getuStartHour()).toString();
                } else {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append("0").append(fileInfo.getuStartHour()).toString();
                }
                if (fileInfo.getuStartMin() >= 10) {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":").append(fileInfo.getuStartMin()).toString();
                } else {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":0").append(fileInfo.getuStartMin()).toString();
                }
                if (fileInfo.getuStartSec() >= 10) {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":").append(fileInfo.getuStartSec()).toString();
                } else {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":0").append(fileInfo.getuStartSec()).toString();
                }
                String strTimeLen = getString(C0470R.string.strTimeLen);
                double nTimeLen;
                if (fileInfo.getuFileTimeLen() >= 3600) {
                    nTimeLen = ((double) fileInfo.getuFileTimeLen()) / 3600.0d;
                    strTimeLen = new StringBuilder(String.valueOf(strTimeLen)).append(String.format("%.1f", new Object[]{Double.valueOf(nTimeLen)})).append(getString(C0470R.string.strHour)).toString();
                } else if (fileInfo.getuFileTimeLen() >= 60) {
                    nTimeLen = ((double) fileInfo.getuFileTimeLen()) / 60.0d;
                    strTimeLen = new StringBuilder(String.valueOf(strTimeLen)).append(String.format("%.1f", new Object[]{Double.valueOf(nTimeLen)})).append(getString(C0470R.string.strMin)).toString();
                } else {
                    nTimeLen = (double) fileInfo.getuFileTimeLen();
                    strTimeLen = new StringBuilder(String.valueOf(strTimeLen)).append(String.format("%.0f", new Object[]{Double.valueOf(nTimeLen)})).append(getString(C0470R.string.strSec)).toString();
                }
                map.put("FileInfo", new StringBuilder(String.valueOf(strStartTime)).append(" ").append(strTimeLen).append(" ").append(strSize).toString());
                map.put("FileSize", strSize);
                map.put("FileStartTime", strStartTime);
                map.put("FileTimeLen", strTimeLen);
                map.put("FileDownloadState", Integer.valueOf(fileInfo.getnFileState()));
                map.put("FileDownloadProgress", Integer.valueOf(fileInfo.getnFileDownloadProgress()));
                listItem.add(map);
            }
            RecFileListViewAdapter recFileListItemAdapter = new RecFileListViewAdapter(this.relateAtivity, listItem, C0470R.layout.recfile_list_item, new String[]{"ItemTitleName", "ItemTitleInfo", "ItemSize", "ItemTimeLen", "ItemDownload", "ItemDownloadState", "ItemDownloadPro", "ItemDownloadBar"}, new int[]{C0470R.id.ItemFileName, C0470R.id.ItemFileInfo, C0470R.id.tvSize, C0470R.id.tvTimeLen, C0470R.id.download_layout, C0470R.id.recording_download_txt, C0470R.id.tv_progress, C0470R.id.pb_download});
            if (this.recFileListView == null) {
                this.recFileListView = (ListView) this.contentView.findViewById(C0470R.id.recfile_list);
            }
            this.recFileListView.setAdapter(recFileListItemAdapter);
            this.recFileListView.setSelection(LocalDefines._PlatbackRecListviewFisrtPosition);
            return;
        }
        this.recFileListView.setAdapter(null);
    }

    public void GetRecFileListFromDatabase() {
        LocalDefines.bIsBackPlay = true;
        this.fileList.clear();
        RecordFileInfo[] list = DatabaseManager.GetAllRecInfo();
        if (list != null && list.length > 0) {
            for (RecordFileInfo info : list) {
                if (info != null) {
                    this.fileList.add(info);
                }
            }
        }
        if (this.isCloudFileList) {
            refleshCloudRecFileList();
        } else {
            refleshRecFileList();
        }
    }

    public void SaveRecFileListToDatabase() {
        DatabaseManager.ClearRecInfos();
        if (this.fileList != null && this.fileList.size() > 0) {
            DatabaseManager.SaveRecInfos(this.fileList);
        }
    }

    public boolean isLoadFromDatabase() {
        if (this.fileList == null || this.fileList.size() <= 0) {
            this.isLoadFromDatabase = false;
        } else {
            this.isLoadFromDatabase = true;
        }
        return this.isLoadFromDatabase;
    }

    public void setLoadFromDatabase(boolean isLoadFromDatabase) {
        this.isLoadFromDatabase = isLoadFromDatabase;
    }

    public boolean isbIsRecFileSearching() {
        return this.bIsRecFileSearching;
    }

    public void setbIsRecFileSearching(boolean bIsRecFileSearching) {
        this.bIsRecFileSearching = bIsRecFileSearching;
    }

    public int getM_nLoginExID() {
        return this.m_nLoginExID;
    }

    public void setM_nLoginExID(int m_nLoginExID) {
        this.m_nLoginExID = m_nLoginExID;
    }

    public int getnSearchChn() {
        return this.nSearchChn;
    }

    public void setnSearchChn(int nSearchChn) {
        this.nSearchChn = nSearchChn;
    }

    public int getnSearchType() {
        return this.nSearchType;
    }

    public void setnSearchType(int nSearchType) {
        this.nSearchType = nSearchType;
    }

    public void GetRecFileList() {
        LocalDefines.bIsBackPlay = true;
        if (LocalDefines._PlatbackListviewSelectedPosition >= 0 && LocalDefines._PlatbackListviewSelectedPosition < LocalDefines._severInfoListData.size()) {
            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(LocalDefines._PlatbackListviewSelectedPosition);
            if (info != null) {
                this.bIsRecFileSearching = true;
                this.fileList.clear();
                this.recFileListView.setAdapter(null);
                this.mLoadType = 1;
                this.loadingDialog.show();
                ((HomePageActivity) this.relateAtivity).setGuideBarVisible(false);
                LocalDefines._nSearchDevID = info.getnDevID();
                LocalDefines._strSearchIP = info.getStrIP();
                LocalDefines._nSearchPort = info.getnPort();
                LocalDefines._strSearchDomain = info.getStrDomain();
                LocalDefines._PlatbackRecListviewFisrtPosition = 0;
                this.m_nThreadID++;
                this.nThreadID = this.m_nThreadID;
                new RecFileSearcher(info, this.nSearchType, this.m_nThreadID).start();
            }
        }
    }

    private void updateServerListView() {
        String strDevID = this.textViewDevice.getText().toString();
        int devID = 0;
        if (!(strDevID == null || strDevID.length() <= 0 || this.deviceInfo == null)) {
            devID = this.deviceInfo.getnDevID();
        }
        if (LocalDefines._severInfoListData != null && LocalDefines._severInfoListData.size() > 0) {
            ArrayList<HashMap<String, Object>> listItem = new ArrayList();
            for (int i = 0; i < LocalDefines._severInfoListData.size(); i++) {
                DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                HashMap<String, Object> map = new HashMap();
                map.put("ItemBtnFace", Integer.valueOf(C0470R.id.item_face));
                map.put("ItemTitleName", info.getStrName());
                if (devID == info.getnDevID()) {
                    this.optOf = i;
                }
                if (info.getnDevID() <= 0) {
                    map.put("ItemTitleID", getString(C0470R.string.server) + info.getStrIP());
                } else {
                    map.put("ItemTitleID", getString(C0470R.string.strIDNumber) + info.getnDevID() + " " + getString(C0470R.string.server) + info.getStrIP());
                }
                map.put("SID", Integer.valueOf(info.getnID()));
                map.put("SaveType", Integer.valueOf(info.getnSaveType()));
                listItem.add(map);
            }
            DeviceListViewAdapter deviceListItemAdapter = new DeviceListViewAdapter(this.relateAtivity, listItem, C0470R.layout.player_back_device_select_item, new String[]{"ItemTvDeviceSelect", "ItemIvDeviceSelect"}, new int[]{C0470R.id.tvDeviceSelect, C0470R.id.ivDeviceSelect});
            if (this.serverlistView == null) {
                this.serverlistView = (ListView) ((LinearLayout) View.inflate(getActivity(), C0470R.layout.popup_window_listview, null)).findViewById(C0470R.id.lvPlayer_back);
            }
            if (this.serverlistView != null) {
                this.serverlistView.setCacheColorHint(0);
                this.serverlistView.setAdapter(deviceListItemAdapter);
                this.serverlistView.setOnItemClickListener(this);
            }
        }
    }

    private void StartPlayFile(int nIndex) {
        this.isLoadFromDatabase = true;
        int camType = LocalDefines.Device_LoginHandle.getCamType();
        Intent intent = new Intent();
        Bundle data = new Bundle();
        if (camType == 1 || camType == 2) {
            intent.setClass(this.relateAtivity, NVPlayerPlaybackFishEyeActivity.class);
            data.putBoolean("isPlayFishEyeFromCloud", false);
        } else {
            intent.setClass(this.relateAtivity, NVPlayerPlaybackActivity.class);
        }
        data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, LocalDefines.Device_LoginHandle);
        data.putInt("play_index", nIndex);
        data.putInt("cam_type", camType);
        intent.putExtras(data);
        this.relateAtivity.startActivity(intent);
        ((HomePageActivity) this.relateAtivity).closeActivity();
        overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
    }

    private void overridePendingTransition(int zoomin, int zoomout) {
    }

    public void onItemClick(AdapterView<?> arg0, View arg1, int nSelectIndex, long arg3) {
        LocalDefines.B_INTENT_ACTIVITY = true;
        if (arg0.getId() == C0470R.id.lvPlayer_back) {
            if (nSelectIndex >= 0 && nSelectIndex < LocalDefines._severInfoListData.size()) {
                LocalDefines._PlatbackListviewSelectedPosition = nSelectIndex;
                DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(LocalDefines._PlatbackListviewSelectedPosition);
                if (info != null && this.textViewDevice != null) {
                    if (LocalDefines.isZh(getActivity()) && HomePageActivity.AppMode == 1 && info.getnProductId() <= 0) {
                        if (info.getnProductId() == 0) {
                            this.isSearchCloudRec = false;
                            this.tvTFVideo.setTextColor(getResources().getColor(C0470R.color.font_color_sky_blue2));
                            this.tvCloudVideo.setTextColor(getResources().getColor(C0470R.color.font_color_gray));
                        } else {
                            this.isSearchCloudRec = false;
                            this.tvTFVideo.setTextColor(getResources().getColor(C0470R.color.font_color_sky_blue2));
                            this.tvCloudVideo.setTextColor(getResources().getColor(C0470R.color.font_color_gray));
                        }
                    }
                    this.deviceInfo = info;
                    this.textViewDevice.setText(info.getStrName());
                    this.bSearchType = true;
                    this.ivPlayerBackType.setImageResource(C0470R.drawable.play_back_video_back_2);
                    this.btnListVisible.setVisibility(0);
                    this.popupListView.dismiss();
                }
            }
        } else if (arg0.getId() == C0470R.id.recfile_list && nSelectIndex >= 0 && nSelectIndex < this.fileList.size()) {
            if (this.mRecFileDownloader != null && this.mRecFileDownloader.isDownloading()) {
                Toast.makeText(getActivity(), getString(C0470R.string.str_rec_file_cancle2), 0).show();
            } else if (this.isCloudFileList) {
                if (this.fileList != null && this.fileList.size() > 0) {
                    SaveRecFileListToDatabase();
                }
                LocalDefines.cloudRecordFileList = this.fileList;
                startPlayCloudRecordFile(nSelectIndex);
            } else {
                if (this.fileList != null && this.fileList.size() > 0) {
                    SaveRecFileListToDatabase();
                }
                LocalDefines.listMapPlayerBackFile = this.fileList;
                StartPlayFile(nSelectIndex);
            }
        }
    }

    private void setListviewOnScrollListener() {
        if (this.recFileListView != null) {
            this.recFileListView.setOnScrollListener(new OnScrollListener() {
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == 0) {
                        LocalDefines._PlatbackRecListviewFisrtPosition = PlaybackFragment.this.recFileListView.getFirstVisiblePosition();
                    }
                }

                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                }
            });
        }
    }

    private void presentShowcaseSequence() {
        new ShowcaseConfig().setDelay(0);
        MaterialShowcaseView showcaseView = new MaterialShowcaseView.Builder(getActivity()).setContentText(getResources().getString(C0470R.string.str_showcase_fra_configdevice1)).setTarget(this.contentView.findViewById(C0470R.id.llPlayBackTitle)).withRectangleShape().setDismissOnTouch(true).singleUse("PlayBackFragment").build();
        showcaseView.setContentTextGravity(17);
        showcaseView.setTopImage(C0470R.drawable.guide_t, 17);
        showcaseView.show(getActivity());
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new OnShowListener() {
            public void onShow(DialogInterface dialog) {
                ((TextView) PlaybackFragment.this.loadingView.findViewById(C0470R.id.loginText)).setText(PlaybackFragment.this.getString(C0470R.string.loading));
            }
        });
        this.loadingDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
                if (PlaybackFragment.this.bIsRecFileSearching) {
                    PlaybackFragment.this.bIsRecFileSearching = false;
                    PlaybackFragment.this.isListVisible = false;
                    PlaybackFragment.this.layoutSearchParam.setVisibility(0);
                    PlaybackFragment.this.layoutRecFileList.setVisibility(8);
                    LocalDefines.bIsBackPlay = false;
                    PlaybackFragment playbackFragment = PlaybackFragment.this;
                    playbackFragment.m_nThreadID = playbackFragment.m_nThreadID + 1;
                    ((HomePageActivity) PlaybackFragment.this.relateAtivity).setGuideBarVisible(true);
                }
            }
        });
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }

    private void stopCurrentDownloadTask() {
        if (this.mRecFileDownloader != null && this.mRecFileDownloader.isDownloading() && this.mDLFileListPosition != -1 && this.mDLFilePath != null) {
            boolean result = this.mRecFileDownloader.StopDownloadRecFile();
            final File file1 = new File(this.mDLFilePath);
            if (file1.exists()) {
                new Thread(new Runnable() {
                    public void run() {
                        boolean deleteResult = file1.delete();
                    }
                }).start();
            }
            this.mDLFileListPosition = -1;
            this.mDLFilePath = null;
        }
    }

    private void showRecordFileListLayout() {
        this.ll_cloud_record.setVisibility(8);
        this.recFileListView.setVisibility(0);
    }

    private void showScrollViewLayout() {
        this.ll_cloud_record.setVisibility(0);
        this.recFileListView.setVisibility(8);
    }

    public void GetCloudRecFileList() {
        LocalDefines.bIsBackPlay = true;
        this.fileList.clear();
        this.recFileListView.setAdapter(null);
        ((HomePageActivity) this.relateAtivity).setGuideBarVisible(false);
        this.mLoadType = 1;
        this.loadingDialog.show();
        this.m_nThreadID++;
        this.mGetRecFileId = this.m_nThreadID;
        new RecFileSearcherCloud(this.deviceInfo, this.nSearchType, this.m_nThreadID).start();
    }

    public void refleshCloudRecFileList() {
        String strInfo = Constants.MAIN_VERSION_TAG;
        if (this.fileList.size() > 0) {
            ArrayList<HashMap<String, Object>> listItem = new ArrayList();
            for (int i = 0; i < this.fileList.size(); i++) {
                RecordFileInfo fileInfo = (RecordFileInfo) this.fileList.get(i);
                HashMap<String, Object> map = new HashMap();
                map.put("ItemTitleName", Integer.valueOf(C0470R.id.ItemFileName));
                map.put("ItemTitleInfo", Integer.valueOf(C0470R.id.ItemFileInfo));
                map.put("FileName", fileInfo.getStrFileName());
                int nFileSize = fileInfo.getnFileSize();
                String strSize = getString(C0470R.string.strFileSize);
                double fFileSize;
                if (nFileSize > 1024000) {
                    fFileSize = ((double) nFileSize) / 1048576.0d;
                    if (fFileSize >= 100.0d) {
                        strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.0f", new Object[]{Double.valueOf(fFileSize)})).append(" MB").toString();
                    } else if (fFileSize >= 1.0d) {
                        strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.1f", new Object[]{Double.valueOf(fFileSize)})).append(" MB").toString();
                    } else {
                        strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.2f", new Object[]{Double.valueOf(fFileSize)})).append(" MB").toString();
                    }
                } else if (nFileSize > 1024) {
                    fFileSize = ((double) nFileSize) / 1024.0d;
                    strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.0f", new Object[]{Double.valueOf(fFileSize)})).append(" KB").toString();
                } else {
                    strSize = new StringBuilder(String.valueOf(strSize)).append(nFileSize).append(" B").toString();
                }
                String strStartTime = getString(C0470R.string.strStartTime);
                if (fileInfo.getuStartHour() >= 10) {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(fileInfo.getuStartHour()).toString();
                } else {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append("0").append(fileInfo.getuStartHour()).toString();
                }
                if (fileInfo.getuStartMin() >= 10) {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":").append(fileInfo.getuStartMin()).toString();
                } else {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":0").append(fileInfo.getuStartMin()).toString();
                }
                if (fileInfo.getuStartSec() >= 10) {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":").append(fileInfo.getuStartSec()).toString();
                } else {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":0").append(fileInfo.getuStartSec()).toString();
                }
                String strTimeLen = getString(C0470R.string.strTimeLen);
                double nTimeLen;
                if (fileInfo.getuFileTimeLen() >= 3600) {
                    nTimeLen = ((double) fileInfo.getuFileTimeLen()) / 3600.0d;
                    strTimeLen = new StringBuilder(String.valueOf(strTimeLen)).append(String.format("%.1f", new Object[]{Double.valueOf(nTimeLen)})).append(getString(C0470R.string.strHour)).toString();
                } else if (fileInfo.getuFileTimeLen() >= 60) {
                    nTimeLen = ((double) fileInfo.getuFileTimeLen()) / 60.0d;
                    strTimeLen = new StringBuilder(String.valueOf(strTimeLen)).append(String.format("%.1f", new Object[]{Double.valueOf(nTimeLen)})).append(getString(C0470R.string.strMin)).toString();
                } else {
                    nTimeLen = (double) fileInfo.getuFileTimeLen();
                    strTimeLen = new StringBuilder(String.valueOf(strTimeLen)).append(String.format("%.0f", new Object[]{Double.valueOf(nTimeLen)})).append(getString(C0470R.string.strSec)).toString();
                }
                map.put("FileInfo", new StringBuilder(String.valueOf(strStartTime)).append(" ").append(strTimeLen).append(" ").append(strSize).toString());
                map.put("FileSize", strSize);
                map.put("FileStartTime", strStartTime);
                map.put("FileTimeLen", strTimeLen);
                listItem.add(map);
            }
            RecFileListViewAdapterCloud recFileListItemAdapter = new RecFileListViewAdapterCloud(getActivity(), listItem, C0470R.layout.recfile_list_item, new String[]{"ItemTitleName", "ItemTitleInfo", "ItemSize", "ItemTimeLen"}, new int[]{C0470R.id.ItemFileName, C0470R.id.ItemFileInfo, C0470R.id.tvSize, C0470R.id.tvTimeLen});
            if (this.recFileListView == null) {
                this.recFileListView = (ListView) this.contentView.findViewById(C0470R.id.recfile_list);
            }
            this.recFileListView.setAdapter(recFileListItemAdapter);
            this.recFileListView.setSelection(LocalDefines._PlatbackRecListviewFisrtPosition);
            return;
        }
        this.recFileListView.setAdapter(null);
    }

    private void startPlayCloudRecordFile(int position) {
        int camType = LocalDefines.Device_LoginHandle.getCamType();
        Intent intent = new Intent();
        Bundle data = new Bundle();
        if (camType == 1 || camType == 2) {
            intent.setClass(getActivity(), NVPlayerPlaybackFishEyeActivity.class);
            data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, LocalDefines.Device_LoginHandle);
            data.putBoolean("isPlayFishEyeFromCloud", true);
        } else {
            intent.setClass(getActivity(), NVPlayerPlaybackCloudRecordActivity.class);
        }
        data.putInt("play_index", position);
        data.putInt(Constants.FLAG_DEVICE_ID, this.deviceInfo.getnDevID());
        data.putString("accesstoken", this.mAccesstoken);
        data.putInt("user_id", this.mUserId);
        data.putString("ecs_ip", this.mEcsIP);
        data.putString("ecs_ip2", this.mEcsIP2);
        data.putInt("ecs_port", this.mEcsPort);
        data.putInt("ecs_port2", this.mEcsPort2);
        intent.putExtras(data);
        startActivity(intent);
    }
}
