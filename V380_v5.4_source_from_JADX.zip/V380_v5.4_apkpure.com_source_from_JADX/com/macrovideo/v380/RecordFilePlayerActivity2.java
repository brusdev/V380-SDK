package com.macrovideo.v380;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.MediaController;
import com.macrovideo.custom.FullScreenVideoView;

public class RecordFilePlayerActivity2 extends Activity {
    private int mCurrentPosition;
    private MediaController mMediaController;
    private String mUri;
    private FullScreenVideoView mVideoView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setRequestedOrientation(0);
        setContentView(C0470R.layout.activity_record_file_player2);
        this.mVideoView = (FullScreenVideoView) findViewById(C0470R.id.video_view);
        this.mMediaController = new MediaController(this);
        this.mVideoView.setMediaController(this.mMediaController);
        Intent intent = getIntent();
        if (intent != null) {
            this.mUri = intent.getStringExtra("uri");
        }
    }

    protected void onResume() {
        if (this.mCurrentPosition != 0 || this.mVideoView.isPlaying()) {
            this.mVideoView.requestFocus();
            this.mVideoView.seekTo(this.mCurrentPosition);
            this.mVideoView.start();
        } else {
            this.mVideoView.setVideoPath(this.mUri);
            this.mVideoView.requestFocus();
            this.mVideoView.seekTo(this.mCurrentPosition);
            this.mVideoView.start();
        }
        super.onResume();
    }

    protected void onPause() {
        if (this.mVideoView != null) {
            this.mCurrentPosition = this.mVideoView.getCurrentPosition();
            this.mVideoView.pause();
        }
        super.onPause();
    }

    protected void onStop() {
        super.onStop();
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.mVideoView != null) {
            this.mVideoView.suspend();
            this.mVideoView = null;
        }
    }
}
