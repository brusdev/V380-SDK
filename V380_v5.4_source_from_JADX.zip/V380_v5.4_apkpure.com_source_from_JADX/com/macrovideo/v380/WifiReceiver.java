package com.macrovideo.v380;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

public class WifiReceiver extends BroadcastReceiver {
    private List<Object> list = new ArrayList();
    private List<ScanResult> list2;
    private ScanResult mScanResult;
    private WifiManager mWiFiManager;
    private StringBuilder sb = new StringBuilder();

    public void onReceive(Context context, Intent intent) {
        this.sb = new StringBuilder();
        this.list2 = this.mWiFiManager.getScanResults();
        if (this.list2 != null) {
            for (int i = 0; i < this.list2.size(); i++) {
                this.mScanResult = (ScanResult) this.list2.get(i);
                this.sb = this.sb.append(this.mScanResult.SSID);
                this.list.add(this.sb.toString());
            }
            Log.d("aaaaa", this.list.get(0));
        }
    }
}
