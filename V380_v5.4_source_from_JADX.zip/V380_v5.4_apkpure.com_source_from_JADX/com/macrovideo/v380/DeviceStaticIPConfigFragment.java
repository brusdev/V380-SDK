package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.setting.DeviceNetwordSetting;
import com.macrovideo.sdk.setting.IPConfigInfo;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;

@SuppressLint({"ValidFragment"})
public class DeviceStaticIPConfigFragment extends Fragment implements OnClickListener {
    private static final int RESULT_CODE_DEVICE_NOT_SUPPORT = -100;
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    private Button btnIPConfigSave;
    private View contentView = null;
    private EditText et_IP;
    private EditText et_gateway;
    private EditText et_main_dns;
    private EditText et_secondary_dns;
    private EditText et_subnet_addr;
    private Handler handler = new C03471();
    private boolean isActive = false;
    private ImageView ivIPConfigBack;
    private ImageView iv_DHCP;
    private ImageView iv_not_DHCP;
    private Dialog loadingDialog;
    private View loadingView;
    private IPConfigInfo mIpConfigInfo = new IPConfigInfo();
    private boolean mIsNeedFresh = true;
    private int mLoadType = 1;
    private DeviceInfo mServerInfo = null;
    private int m_nIPConfigID = 0;
    private Activity relateAtivity = null;

    class C03471 extends Handler {
        C03471() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            if (DeviceStaticIPConfigFragment.this.isActive) {
                DeviceStaticIPConfigFragment.this.mIsNeedFresh = false;
                if (msg.arg1 == 257) {
                    DeviceStaticIPConfigFragment.this.loadingDialog.dismiss();
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceStaticIPConfigFragment.this.ShowAlert(DeviceStaticIPConfigFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceStaticIPConfigFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            DeviceStaticIPConfigFragment.this.ShowConfigSetting();
                            break;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceStaticIPConfigFragment.this.ShowAlert(DeviceStaticIPConfigFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceStaticIPConfigFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            DeviceStaticIPConfigFragment.this.ShowConfigSetting();
                            break;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceStaticIPConfigFragment.this.ShowAlert(DeviceStaticIPConfigFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceStaticIPConfigFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            DeviceStaticIPConfigFragment.this.ShowConfigSetting();
                            break;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceStaticIPConfigFragment.this.ShowAlert(DeviceStaticIPConfigFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceStaticIPConfigFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            DeviceStaticIPConfigFragment.this.ShowConfigSetting();
                            break;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceStaticIPConfigFragment.this.ShowAlert(DeviceStaticIPConfigFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceStaticIPConfigFragment.this.getString(C0470R.string.notice_Result_NetError));
                            DeviceStaticIPConfigFragment.this.ShowConfigSetting();
                            break;
                        case -100:
                            DeviceStaticIPConfigFragment.this.ShowAlert(DeviceStaticIPConfigFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceStaticIPConfigFragment.this.getString(C0470R.string.str_not_support));
                            DeviceStaticIPConfigFragment.this.ShowConfigSetting();
                            break;
                        case 256:
                            Bundle data = msg.getData();
                            if (data != null) {
                                IPConfigInfo ipConfigInfo = (IPConfigInfo) data.get("ipConfigInfo");
                                if (ipConfigInfo != null) {
                                    DeviceStaticIPConfigFragment.this.mIpConfigInfo = ipConfigInfo;
                                }
                                DeviceStaticIPConfigFragment.this.initUI();
                                break;
                            }
                            DeviceStaticIPConfigFragment.this.ShowAlert(Constants.MAIN_VERSION_TAG, DeviceStaticIPConfigFragment.this.getString(C0470R.string.notice_Result_BadResult));
                            return;
                        default:
                            DeviceStaticIPConfigFragment.this.ShowAlert(DeviceStaticIPConfigFragment.this.getString(C0470R.string.alert_get_config_fail), DeviceStaticIPConfigFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            DeviceStaticIPConfigFragment.this.ShowConfigSetting();
                            break;
                    }
                }
                if (msg.arg1 == 262) {
                    DeviceStaticIPConfigFragment.this.loadingDialog.dismiss();
                    switch (msg.arg2) {
                        case 256:
                            DeviceStaticIPConfigFragment.this.clearEditText();
                            DeviceStaticIPConfigFragment.this.onSaveAndBack(DeviceStaticIPConfigFragment.this.getString(C0470R.string.alert_set_config_ok), Constants.MAIN_VERSION_TAG);
                            return;
                        default:
                            DeviceStaticIPConfigFragment.this.clearEditText();
                            DeviceStaticIPConfigFragment.this.ShowAlert(DeviceStaticIPConfigFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceStaticIPConfigFragment.this.getString(C0470R.string.snartLinkFailTitle));
                            DeviceStaticIPConfigFragment.this.ShowConfigSetting();
                            return;
                    }
                }
            }
        }
    }

    class C03482 implements OnShowListener {
        C03482() {
        }

        public void onShow(DialogInterface dialog) {
            TextView tv = (TextView) DeviceStaticIPConfigFragment.this.loadingView.findViewById(C0470R.id.loginText);
            if (DeviceStaticIPConfigFragment.this.mLoadType == 1) {
                tv.setText(DeviceStaticIPConfigFragment.this.getString(C0470R.string.loading));
            } else if (DeviceStaticIPConfigFragment.this.mLoadType == 2) {
                tv.setText(DeviceStaticIPConfigFragment.this.getString(C0470R.string.str_saving));
            }
        }
    }

    class C03493 implements OnDismissListener {
        C03493() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    private class GetIPConfigInfoThread extends Thread {
        public void run() {
            IPConfigInfo ipConfigInfo = DeviceNetwordSetting.getIPConfig(DeviceStaticIPConfigFragment.this.mServerInfo);
            if (ipConfigInfo != null) {
                int getResultCode = ipConfigInfo.getnResult();
                Message msg;
                if (getResultCode == 256) {
                    msg = DeviceStaticIPConfigFragment.this.handler.obtainMessage();
                    msg.arg1 = 257;
                    msg.arg2 = getResultCode;
                    Bundle data = new Bundle();
                    data.putParcelable("ipConfigInfo", ipConfigInfo);
                    msg.setData(data);
                    DeviceStaticIPConfigFragment.this.handler.sendMessage(msg);
                    return;
                }
                msg = DeviceStaticIPConfigFragment.this.handler.obtainMessage();
                msg.arg1 = 257;
                msg.arg2 = getResultCode;
                DeviceStaticIPConfigFragment.this.handler.sendMessage(msg);
            }
        }
    }

    private class SetIPConfigInfoThread extends Thread {
        public void run() {
            int setResultCode = DeviceNetwordSetting.setIPConfig(DeviceStaticIPConfigFragment.this.mServerInfo, DeviceStaticIPConfigFragment.this.mIpConfigInfo);
            Message msg = DeviceStaticIPConfigFragment.this.handler.obtainMessage();
            msg.arg1 = 262;
            msg.arg2 = setResultCode;
            DeviceStaticIPConfigFragment.this.handler.sendMessage(msg);
        }
    }

    public DeviceStaticIPConfigFragment(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public IPConfigInfo getIPConfigInfo() {
        return this.mIpConfigInfo;
    }

    public void setIPConfigInfo(IPConfigInfo ipConfigInfo) {
        if (this.mIpConfigInfo == null) {
            this.mIpConfigInfo = new IPConfigInfo();
        }
        if (ipConfigInfo != null) {
            this.mIpConfigInfo = ipConfigInfo;
        }
    }

    public void setServerInfo(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_static_ip_config, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        InitSubView();
        if (this.mServerInfo == null || !this.mIsNeedFresh) {
            initUI();
        } else {
            getIPConfigInfo(this.mServerInfo);
        }
        return v;
    }

    private void InitSubView() {
        createLoadingDialog();
        this.ivIPConfigBack = (ImageView) this.contentView.findViewById(C0470R.id.ivIPConfigBack);
        this.ivIPConfigBack.setOnClickListener(this);
        this.btnIPConfigSave = (Button) this.contentView.findViewById(C0470R.id.btnIPConfigSave);
        this.btnIPConfigSave.setOnClickListener(this);
        this.iv_DHCP = (ImageView) this.contentView.findViewById(C0470R.id.iv_DHCP);
        this.iv_DHCP.setOnClickListener(this);
        this.iv_not_DHCP = (ImageView) this.contentView.findViewById(C0470R.id.iv_not_DHCP);
        this.iv_not_DHCP.setOnClickListener(this);
        this.et_IP = (EditText) this.contentView.findViewById(C0470R.id.et_IP);
        this.et_subnet_addr = (EditText) this.contentView.findViewById(C0470R.id.et_subnet_addr);
        this.et_gateway = (EditText) this.contentView.findViewById(C0470R.id.et_gateway);
        this.et_main_dns = (EditText) this.contentView.findViewById(C0470R.id.et_main_dns);
        this.et_secondary_dns = (EditText) this.contentView.findViewById(C0470R.id.et_secondary_dns);
    }

    public void onStop() {
        super.onStop();
        this.relateAtivity = null;
        this.isActive = false;
    }

    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.relateAtivity = getActivity();
        this.isActive = true;
    }

    private void initUI() {
        this.btnIPConfigSave.setEnabled(true);
        if (this.mIpConfigInfo.isDisableDHCP()) {
            this.iv_DHCP.setImageResource(C0470R.drawable.btn_checkbox_normal);
            this.iv_not_DHCP.setImageResource(C0470R.drawable.btn_checkbox_check);
            setEditTextAreaEnable(true);
            this.et_IP.setText(this.mIpConfigInfo.getStrIP());
            this.et_subnet_addr.setText(this.mIpConfigInfo.getStrMask());
            this.et_gateway.setText(this.mIpConfigInfo.getStrGateway());
            this.et_main_dns.setText(this.mIpConfigInfo.getStrDNS1());
            this.et_secondary_dns.setText(this.mIpConfigInfo.getStrDNS2());
            return;
        }
        this.iv_DHCP.setImageResource(C0470R.drawable.btn_checkbox_check);
        this.iv_not_DHCP.setImageResource(C0470R.drawable.btn_checkbox_normal);
        setEditTextAreaEnable(false);
    }

    public void ShowAlert(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowAlert(title, msg);
        }
    }

    public void onSaveAndBack(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowNotic(title, msg);
            ShowConfigSetting();
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.ivIPConfigBack:
                clearEditText();
                hindKeyboard();
                ShowConfigSetting();
                return;
            case C0470R.id.iv_DHCP:
                if (this.mIpConfigInfo.isDisableDHCP()) {
                    this.iv_DHCP.setImageResource(C0470R.drawable.btn_checkbox_check);
                    this.iv_not_DHCP.setImageResource(C0470R.drawable.btn_checkbox_normal);
                    setEditTextAreaEnable(false);
                    this.mIpConfigInfo.setDisableDHCP(false);
                    return;
                }
                return;
            case C0470R.id.iv_not_DHCP:
                if (!this.mIpConfigInfo.isDisableDHCP()) {
                    this.iv_DHCP.setImageResource(C0470R.drawable.btn_checkbox_normal);
                    this.iv_not_DHCP.setImageResource(C0470R.drawable.btn_checkbox_check);
                    setEditTextAreaEnable(true);
                    this.mIpConfigInfo.setDisableDHCP(true);
                    return;
                }
                return;
            case C0470R.id.btnIPConfigSave:
                hindKeyboard();
                if (this.mIpConfigInfo.isDisableDHCP()) {
                    String str_ip = this.et_IP.getText().toString();
                    String str_gateway = this.et_gateway.getText().toString();
                    String str_subnet_addr = this.et_subnet_addr.getText().toString();
                    String str_main_dns = this.et_main_dns.getText().toString();
                    String str_secondary_dns = this.et_secondary_dns.getText().toString();
                    if (str_ip.length() == 0) {
                        Toast.makeText(this.relateAtivity, getResources().getString(C0470R.string.str_null_ip), 0).show();
                        return;
                    } else if (str_subnet_addr.length() == 0) {
                        Toast.makeText(this.relateAtivity, getResources().getString(C0470R.string.str_null_subnet), 0).show();
                        return;
                    } else if (str_gateway.length() == 0) {
                        Toast.makeText(this.relateAtivity, getResources().getString(C0470R.string.str_null_gateway), 0).show();
                        return;
                    } else if (str_main_dns.length() == 0) {
                        Toast.makeText(this.relateAtivity, getResources().getString(C0470R.string.str_null_main_dns), 0).show();
                        return;
                    } else if (!Functions.isIpAddress(str_ip)) {
                        Toast.makeText(this.relateAtivity, getResources().getString(C0470R.string.str_error_ip), 0).show();
                        return;
                    } else if (!Functions.isIpAddress(str_subnet_addr)) {
                        Toast.makeText(this.relateAtivity, getResources().getString(C0470R.string.str_error_subnet), 0).show();
                        return;
                    } else if (!Functions.isIpAddress(str_gateway)) {
                        Toast.makeText(this.relateAtivity, getResources().getString(C0470R.string.str_error_gateway), 0).show();
                        return;
                    } else if (!Functions.isIpAddress(str_main_dns)) {
                        Toast.makeText(this.relateAtivity, getResources().getString(C0470R.string.str_error_main_dns), 0).show();
                        return;
                    } else if (str_secondary_dns.length() == 0 || Functions.isIpAddress(str_secondary_dns)) {
                        this.mIpConfigInfo.setStrIP(str_ip);
                        this.mIpConfigInfo.setStrMask(str_subnet_addr);
                        this.mIpConfigInfo.setStrDNS1(str_main_dns);
                        this.mIpConfigInfo.setStrDNS2(str_secondary_dns);
                        this.mIpConfigInfo.setStrGateway(str_gateway);
                    } else {
                        Toast.makeText(this.relateAtivity, getResources().getString(C0470R.string.str_error_sub_dns), 0).show();
                        return;
                    }
                }
                this.mIpConfigInfo.setStrIP(null);
                this.mIpConfigInfo.setStrGateway(null);
                this.mIpConfigInfo.setStrMask(null);
                this.mIpConfigInfo.setStrDNS1(null);
                this.mIpConfigInfo.setStrDNS2(null);
                this.mLoadType = 2;
                this.loadingDialog.show();
                new SetIPConfigInfoThread().start();
                return;
            default:
                return;
        }
    }

    private void ShowConfigSetting() {
        this.m_nIPConfigID++;
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ChangeFragment(20, 13, this.mServerInfo);
        }
    }

    public void setNeedFreshInterface(boolean bNeedFresh) {
        this.mIsNeedFresh = bNeedFresh;
    }

    private void getIPConfigInfo(DeviceInfo info) {
        if (info != null) {
            this.m_nIPConfigID++;
            this.mLoadType = 1;
            this.loadingDialog.show();
            this.btnIPConfigSave.setEnabled(false);
            new GetIPConfigInfoThread().start();
        }
    }

    private void setEditTextAreaEnable(boolean enabled) {
        this.et_IP.setEnabled(enabled);
        this.et_subnet_addr.setEnabled(enabled);
        this.et_gateway.setEnabled(enabled);
        this.et_main_dns.setEnabled(enabled);
        this.et_secondary_dns.setEnabled(enabled);
    }

    public void hindKeyboard() {
        if (this.relateAtivity != null) {
            try {
                InputMethodManager imm = (InputMethodManager) this.relateAtivity.getSystemService("input_method");
                if (imm != null) {
                    imm.hideSoftInputFromWindow(this.relateAtivity.getCurrentFocus().getWindowToken(), 2);
                }
            } catch (Exception e) {
            }
        }
    }

    public void clearEditText() {
        this.et_IP.setText(Constants.MAIN_VERSION_TAG);
        this.et_subnet_addr.setText(Constants.MAIN_VERSION_TAG);
        this.et_gateway.setText(Constants.MAIN_VERSION_TAG);
        this.et_main_dns.setText(Constants.MAIN_VERSION_TAG);
        this.et_secondary_dns.setText(Constants.MAIN_VERSION_TAG);
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C03482());
        this.loadingDialog.setOnDismissListener(new C03493());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }
}
