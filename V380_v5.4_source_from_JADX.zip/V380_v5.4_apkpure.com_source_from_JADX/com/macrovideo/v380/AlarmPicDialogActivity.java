package com.macrovideo.v380;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.internal.view.SupportMenu;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.tools.Functions;
import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AlarmPicDialogActivity extends Activity implements OnClickListener {
    private static final int HANDLER_LARGE_IMAGE = 1;
    private static final String KEY_ALARM_TIME = "alarm_time";
    private static final String KEY_ID = "dev_id";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_USERNAME = "username";
    private static final int MSG_HIDE_DOUBLE_CLICK_VIEW = 2;
    private static final String TAG = "AlarmPicDialogActivity";
    private long mAlarmPicClickTime;
    private int mAlarmPicHeight = 0;
    private int mAlarmPicWidth = 0;
    private int mGetLargeAlarmPicThreadId;
    private Handler mHandler = new C02521();
    private ImageView mIvAlarmPic;
    private ImageView mIvCloseBtn;
    private String mPassword;
    private ProgressBar mProgressBar;
    private int mTickCount = 0;
    private int mTickCountThreadID;
    private TextView mTvAlarmDateTime;
    private TextView mTvAlarmDeviceId;
    private TextView mTvAlarmDoubleClick;
    private String mUserName;
    private int nAlarmType;
    private int nDevID;
    private String strDateTime;

    class C02521 extends Handler {
        C02521() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    AlarmPicDialogActivity.this.stopToGetLargeAlarmImage();
                    Bundle bundle = msg.getData();
                    if (bundle != null) {
                        Bitmap bitmap = (Bitmap) bundle.getParcelable("alarm_image");
                        int p_count = bundle.getInt("p_count");
                        BitmapDrawable bitmapDrawable;
                        Bitmap bitmap2;
                        if (bitmap != null) {
                            if (p_count > 0) {
                                String p_set = bundle.getString("p_set");
                                Log.d(AlarmPicDialogActivity.TAG, "p_count = " + p_count + " p_set = " + p_set);
                                Bitmap bitmapCopy = bitmap.copy(Config.RGB_565, true);
                                Canvas canvas = new Canvas(bitmapCopy);
                                canvas.translate(0.0f, 0.0f);
                                Paint paint = new Paint();
                                paint.setColor(SupportMenu.CATEGORY_MASK);
                                paint.setStrokeWidth(3.0f);
                                paint.setStyle(Style.STROKE);
                                try {
                                    JSONArray jSONArray = new JSONArray(p_set);
                                    int i = 0;
                                    while (true) {
                                        if (i >= jSONArray.length()) {
                                            bitmapDrawable = (BitmapDrawable) AlarmPicDialogActivity.this.mIvAlarmPic.getDrawable();
                                            if (bitmapDrawable != null) {
                                                bitmap2 = bitmapDrawable.getBitmap();
                                                if (bitmap2 != null) {
                                                    Log.e(AlarmPicDialogActivity.TAG, "p_count>0 bitmap2.recycle()");
                                                    bitmap2.recycle();
                                                }
                                            }
                                            AlarmPicDialogActivity.this.mIvAlarmPic.setImageBitmap(bitmapCopy);
                                        } else {
                                            JSONObject jsonObject = jSONArray.getJSONObject(i);
                                            canvas.drawRect((float) jsonObject.getInt("tx"), (float) jsonObject.getInt("ty"), (float) jsonObject.getInt("bx"), (float) jsonObject.getInt("by"), paint);
                                            i++;
                                        }
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                bitmapDrawable = (BitmapDrawable) AlarmPicDialogActivity.this.mIvAlarmPic.getDrawable();
                                if (bitmapDrawable != null) {
                                    bitmap2 = bitmapDrawable.getBitmap();
                                    Log.e(AlarmPicDialogActivity.TAG, "p_count<0 bitmap2.recycle()");
                                    if (bitmap2 != null) {
                                        bitmap2.recycle();
                                    }
                                }
                                AlarmPicDialogActivity.this.mIvAlarmPic.setImageBitmap(bitmap.copy(Config.RGB_565, true));
                            }
                            bitmap.recycle();
                            return;
                        }
                        bitmapDrawable = (BitmapDrawable) AlarmPicDialogActivity.this.mIvAlarmPic.getDrawable();
                        if (bitmapDrawable != null) {
                            bitmap2 = bitmapDrawable.getBitmap();
                            Log.e(AlarmPicDialogActivity.TAG, "图片获取有问题，使用加载失败图片 bitmap.recycle()");
                            if (bitmap2 != null) {
                                bitmap2.recycle();
                            }
                        }
                        AlarmPicDialogActivity.this.mIvAlarmPic.setImageBitmap(BitmapFactory.decodeResource(AlarmPicDialogActivity.this.getResources(), C0470R.drawable.alarm_pic_load_fail));
                        return;
                    }
                    return;
                case 2:
                    AlarmPicDialogActivity.this.mTvAlarmDoubleClick.setVisibility(4);
                    return;
                default:
                    return;
            }
        }
    }

    private class GetLargeAlarmPicThread extends Thread {
        private int deviceId;
        private int getLargeAlarmPicThreadId;
        private String password;
        private String username;

        public GetLargeAlarmPicThread(int getLargeAlarmPicThreadId, int nDevID, String strUserName, String strPassword) {
            this.getLargeAlarmPicThreadId = getLargeAlarmPicThreadId;
            this.deviceId = nDevID;
            this.username = strUserName;
            this.password = strPassword;
        }

        public void run() {
            if (this.getLargeAlarmPicThreadId == AlarmPicDialogActivity.this.mGetLargeAlarmPicThreadId && this.deviceId == AlarmPicDialogActivity.this.nDevID && this.deviceId > 0) {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put(AlarmPicDialogActivity.KEY_ID, this.deviceId);
                    jsonObject.put(AlarmPicDialogActivity.KEY_USERNAME, this.username);
                    jsonObject.put(AlarmPicDialogActivity.KEY_PASSWORD, this.password);
                    jsonObject.put(AlarmPicDialogActivity.KEY_ALARM_TIME, 0);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                String requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strAlarmLargePosition, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_CONNECT_PICTUER_TOP_NEW).append(new String(Base64.encodeBase64(jsonObject.toString().getBytes()))).toString());
                Log.d(AlarmPicDialogActivity.TAG, "requestResult = " + requestResult);
                if (requestResult != null && requestResult.length() > 0) {
                    try {
                        JSONObject jsonObject2 = new JSONObject(requestResult);
                        if (jsonObject2.getInt("result") != 0) {
                            int p_count = jsonObject2.getInt("p_count");
                            Bitmap bitmap = null;
                            try {
                                bitmap = Functions.decodeStringtoBitmap(jsonObject2.getString("alarm_image"));
                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }
                            String p_set = null;
                            if (p_count > 0) {
                                p_set = jsonObject2.getString("p_set");
                            }
                            if (this.getLargeAlarmPicThreadId == AlarmPicDialogActivity.this.mGetLargeAlarmPicThreadId && this.deviceId == AlarmPicDialogActivity.this.nDevID) {
                                Message message = new Message();
                                message.what = 1;
                                Bundle bundle = new Bundle();
                                bundle.putParcelable("alarm_image", bitmap);
                                bundle.putInt("p_count", p_count);
                                if (p_count > 0) {
                                    bundle.putString("p_set", p_set);
                                }
                                message.setData(bundle);
                                AlarmPicDialogActivity.this.mHandler.sendMessage(message);
                            }
                        }
                    } catch (JSONException e3) {
                        e3.printStackTrace();
                    }
                }
            }
        }
    }

    class TimerThread extends Thread {
        int mThreadID = 0;

        public TimerThread(int nThreadID) {
            this.mThreadID = nThreadID;
            Log.d(AlarmPicDialogActivity.TAG, "new TimerThread");
        }

        public void run() {
            while (this.mThreadID == AlarmPicDialogActivity.this.mTickCountThreadID) {
                AlarmPicDialogActivity alarmPicDialogActivity = AlarmPicDialogActivity.this;
                alarmPicDialogActivity.mTickCount = alarmPicDialogActivity.mTickCount - 1;
                if (AlarmPicDialogActivity.this.mTickCount <= 0 && this.mThreadID == AlarmPicDialogActivity.this.mTickCountThreadID) {
                    Message message = new Message();
                    message.what = 2;
                    AlarmPicDialogActivity.this.mHandler.sendMessage(message);
                    AlarmPicDialogActivity.this.mTickCount = 0;
                }
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "OnCreate");
        setContentView(C0470R.layout.activity_alarm_pic_dialog_layout);
        getWindow().addFlags(6815744);
        Display d = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(outMetrics);
        LayoutParams p = getWindow().getAttributes();
        p.width = (int) (((double) d.getWidth()) * 0.9d);
        this.mAlarmPicWidth = p.width - ((int) ((outMetrics.density * 10.0f) + 0.5f));
        this.mAlarmPicHeight = (int) (((((double) this.mAlarmPicWidth) * 1.0d) / 4.0d) * 3.0d);
        getWindow().setAttributes(p);
        DatabaseManager.InitDataBase(this);
        initViews();
        if (getDeviceInfoData(getIntent()) == null) {
            closeActivity();
            return;
        }
        startToGetLargeAlarmImage();
        this.mTickCountThreadID++;
        new TimerThread(this.mTickCountThreadID).start();
    }

    private void initViews() {
        this.mTvAlarmDeviceId = (TextView) findViewById(C0470R.id.tv_alarm_devive_id);
        this.mTvAlarmDoubleClick = (TextView) findViewById(C0470R.id.tv_alarm_pic_double_click);
        this.mTvAlarmDoubleClick.setVisibility(4);
        this.mTvAlarmDateTime = (TextView) findViewById(C0470R.id.tv_alarm_time);
        this.mProgressBar = (ProgressBar) findViewById(C0470R.id.pb_alarm_dialog);
        this.mIvAlarmPic = (ImageView) findViewById(C0470R.id.iv_alarm_pic);
        ViewGroup.LayoutParams params = this.mIvAlarmPic.getLayoutParams();
        params.width = this.mAlarmPicWidth;
        params.height = this.mAlarmPicHeight;
        this.mIvAlarmPic.setLayoutParams(params);
        this.mIvAlarmPic.setOnClickListener(this);
        this.mIvCloseBtn = (ImageView) findViewById(C0470R.id.iv_close_alarm_pic);
        this.mIvCloseBtn.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.iv_close_alarm_pic:
                closeActivity();
                return;
            case C0470R.id.iv_alarm_pic:
                if (!LocalDefines.IsSoftwareRunning) {
                    if (System.currentTimeMillis() - this.mAlarmPicClickTime > 2000) {
                        this.mTvAlarmDoubleClick.setVisibility(0);
                        this.mAlarmPicClickTime = System.currentTimeMillis();
                        this.mTickCount = 2;
                        return;
                    }
                    Intent intent = new Intent(getApplicationContext(), HomePageActivity.class);
                    intent.setFlags(270532608);
                    startActivity(intent);
                    closeActivity();
                    return;
                }
                return;
            default:
                return;
        }
    }

    protected void onResume() {
        super.onResume();
    }

    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop");
        this.mTickCountThreadID++;
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "onNewIntent");
        if (getDeviceInfoData(intent) != null) {
            stopToGetLargeAlarmImage();
            startToGetLargeAlarmImage();
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            closeActivity();
        }
        return super.onKeyDown(keyCode, event);
    }

    private void closeActivity() {
        Log.d(TAG, "closeActivity");
        stopToGetLargeAlarmImage();
        if (this.mIvAlarmPic != null) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) this.mIvAlarmPic.getDrawable();
            if (!(bitmapDrawable == null || bitmapDrawable.getBitmap() == null)) {
                Log.d(TAG, "窗口Activity 回收Bitmap");
                bitmapDrawable.getBitmap().recycle();
            }
        }
        finish();
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

    private DeviceInfo getDeviceInfoData(Intent intent) {
        this.nDevID = intent.getIntExtra("nDevID", 0);
        Log.d(TAG, "getDeviceInfo nDevID = " + this.nDevID);
        this.nAlarmType = intent.getIntExtra("nAlarmType", 0);
        this.strDateTime = intent.getStringExtra("strDateTime");
        this.mTvAlarmDeviceId.setText(String.valueOf(this.nDevID));
        this.mTvAlarmDateTime.setText(this.strDateTime);
        DeviceInfo deviceInfo = DatabaseManager.GetServerInfoByID(this.nDevID);
        if (deviceInfo == null) {
            return null;
        }
        this.mUserName = deviceInfo.getStrUsername();
        this.mPassword = deviceInfo.getStrPassword();
        return deviceInfo;
    }

    private void startToGetLargeAlarmImage() {
        this.mProgressBar.setVisibility(0);
        Log.d(TAG, "startToGetLargeAlarmImage--> nDevID = " + this.nDevID + " username = " + this.mUserName + " password = " + this.mPassword);
        int i = this.mGetLargeAlarmPicThreadId + 1;
        this.mGetLargeAlarmPicThreadId = i;
        new GetLargeAlarmPicThread(i, this.nDevID, this.mUserName, this.mPassword).start();
    }

    private void stopToGetLargeAlarmImage() {
        this.mProgressBar.setVisibility(8);
        this.mGetLargeAlarmPicThreadId++;
    }
}
