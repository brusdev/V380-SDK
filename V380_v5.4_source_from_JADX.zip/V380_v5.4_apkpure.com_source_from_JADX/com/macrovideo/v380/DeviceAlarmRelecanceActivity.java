package com.macrovideo.v380;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.media.TransportMediator;
import android.support.v4.view.ViewCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class DeviceAlarmRelecanceActivity extends Activity implements OnClickListener, OnItemClickListener {
    private static final int ADD_ALARM_DEVICE_FINSH = 258;
    private static final int ALARM_DEVICE_SELECT_FINSH = 256;
    private static int ALARM_OFF = 0;
    private static int ALARM_ON = 1;
    private static final int ALARM_PRESET = 122;
    private static final int ALARM_TYPE = 121;
    private static final int ALTER_ALARM_DEVICE_FINSH = 259;
    private static final int DELETE_ALARM_DEVICE_FINSH = 260;
    private static final int FIND_ALARM_DEVICE_FINSH = 257;
    private int alarmDeviceLevel = 0;
    private ArrayList<HashMap<String, Object>> alarmDeviceList = new ArrayList();
    private ArrayList<HashMap<String, Object>> alarmDeviceListAdd = new ArrayList();
    private int alarmDeviceType = 0;
    private int alarmOffOrOn = 1;
    private boolean bAddOrAlarm = false;
    private boolean bAlterDevice = false;
    private ImageView btnRelecance;
    private Button btnRelecanceAdd;
    private Button btnRelecanceAlter;
    private Button btnRelecanceDelete;
    private Button btnRelecanceSave;
    private EditText etAlarmDeviceName;
    private Handler handler = new C02951();
    private ImageView ivAlarmDevicePreset;
    private LinearLayout llRelecanceAdd;
    private RelativeLayout llRelecanceAlter;
    private ListView lvPreset;
    private ListView lvRelecance;
    private ListView lvRelecanceAdd;
    private HashMap<String, Object> mapMessage = new HashMap();
    private int nAddAlarmDeviceID = 0;
    private int nAlarmDeviceID = 0;
    private int nAlterAlarmDeviceID = 0;
    private int nDeleteAlarmDeviceID = 0;
    private int nFindAlarmDeviceID = 0;
    private PopupWindow popupWindowMore;
    private int presetNum = 0;
    private ProgressBar progressBarRelecance;
    private RadioButton rBtnFeeling;
    private RadioButton rBtnGAS;
    private RadioButton rBtnHigh;
    private RadioButton rBtnLow;
    private RadioButton rBtnMedium;
    private RadioButton rBtnOff;
    private RadioButton rBtnOn;
    private RadioButton rBtnOther;
    private RadioButton rBtnRKE;
    private RadioButton rBtnSmoke;
    private int relevancePreset = -1;
    private RadioGroup rgAlarmDevice;
    private RadioGroup rgAlarmDevice2;
    private RadioGroup rgAlarmDeviceLevel;
    private RadioGroup rgAlarmDeviceOffOrOn;
    private TextView tvAlarmDeviceAddress;
    private TextView tvAlarmDeviceLevel;
    private TextView tvAlarmDeviceOffOrOn;
    private TextView tvAlarmDevicePreset;
    private TextView tvAlarmDeviceType;
    private TextView tvPreset;
    private TextView tvRelecance;
    private TextView tvRelecanceAdd;

    class C02951 extends Handler {
        C02951() {
        }

        public void handleMessage(Message msg) {
            DeviceAlarmRelecanceActivity.this.progressBarRelecance.setVisibility(8);
            if (msg.arg1 == 256) {
                if (msg.arg2 == 1001) {
                    DeviceAlarmRelecanceActivity.this.alarmDeviceSelectList();
                } else {
                    Toast.makeText(DeviceAlarmRelecanceActivity.this.getApplication(), DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceDeviceSeekListFail), 0).show();
                }
            } else if (msg.arg1 == 257) {
                if (DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd == null || DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd.size() <= 0) {
                    DeviceAlarmRelecanceActivity.this.tvRelecanceAdd.setVisibility(0);
                    DeviceAlarmRelecanceActivity.this.lvRelecanceAdd.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.tvRelecanceAdd.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceDeviceGainFail));
                    return;
                }
                DeviceAlarmRelecanceActivity.this.alarmDeviceAddList();
                DeviceAlarmRelecanceActivity.this.tvRelecanceAdd.setVisibility(8);
                DeviceAlarmRelecanceActivity.this.lvRelecanceAdd.setVisibility(0);
            } else if (msg.arg1 == 258) {
                DeviceAlarmRelecanceActivity.this.btnRelecanceAdd.setEnabled(true);
                if (msg.arg2 == 1001) {
                    DeviceAlarmRelecanceActivity.this.llRelecanceAlter.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.llRelecanceAdd.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.btnRelecanceSave.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDevice.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDevice2.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDeviceLevel.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDeviceOffOrOn.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.lvRelecance.setVisibility(0);
                    DeviceAlarmRelecanceActivity.this.startAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo);
                    Toast.makeText(DeviceAlarmRelecanceActivity.this.getApplication(), DeviceAlarmRelecanceActivity.this.getString(C0470R.string.deviceAddSucceed), 0).show();
                    return;
                }
                Toast.makeText(DeviceAlarmRelecanceActivity.this.getApplication(), DeviceAlarmRelecanceActivity.this.getString(C0470R.string.deviceAddFail), 0).show();
            } else if (msg.arg1 == 259) {
                DeviceAlarmRelecanceActivity.this.btnRelecanceAlter.setEnabled(true);
                if (msg.arg2 == 1001) {
                    DeviceAlarmRelecanceActivity.this.bAlterDevice = true;
                    DeviceAlarmRelecanceActivity.this.llRelecanceAlter.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.llRelecanceAdd.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.btnRelecanceSave.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDevice.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDevice2.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDeviceLevel.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDeviceOffOrOn.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.lvRelecance.setVisibility(0);
                    DeviceAlarmRelecanceActivity.this.startAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo);
                    Toast.makeText(DeviceAlarmRelecanceActivity.this.getApplication(), DeviceAlarmRelecanceActivity.this.getString(C0470R.string.deviceAlterSucceed), 0).show();
                    return;
                }
                Toast.makeText(DeviceAlarmRelecanceActivity.this.getApplication(), DeviceAlarmRelecanceActivity.this.getString(C0470R.string.deviceAlterFail), 0).show();
            } else if (msg.arg1 == 260) {
                DeviceAlarmRelecanceActivity.this.btnRelecanceDelete.setEnabled(true);
                if (msg.arg2 == 1001) {
                    DeviceAlarmRelecanceActivity.this.llRelecanceAlter.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.llRelecanceAdd.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.btnRelecanceSave.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDevice.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDevice2.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDeviceLevel.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.rgAlarmDeviceOffOrOn.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.lvRelecance.setVisibility(0);
                    Toast.makeText(DeviceAlarmRelecanceActivity.this.getApplication(), DeviceAlarmRelecanceActivity.this.getString(C0470R.string.deviceDelete), 0).show();
                    DeviceAlarmRelecanceActivity.this.startAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo);
                    return;
                }
                Toast.makeText(DeviceAlarmRelecanceActivity.this.getApplication(), DeviceAlarmRelecanceActivity.this.getString(C0470R.string.deleteFail), 0).show();
            }
        }
    }

    class C02962 implements OnClickListener {
        C02962() {
        }

        public void onClick(View arg0) {
            DeviceAlarmRelecanceActivity.this.presetPopuwindow(arg0, 122);
        }
    }

    class C02973 implements OnCheckedChangeListener {
        C02973() {
        }

        public void onCheckedChanged(RadioGroup arg0, int arg1) {
            switch (arg0.getCheckedRadioButtonId()) {
                case C0470R.id.rBtnHigh:
                    DeviceAlarmRelecanceActivity.this.alarmDeviceLevel = 3;
                    DeviceAlarmRelecanceActivity.this.tvAlarmDeviceLevel.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceLevelHigh));
                    DeviceAlarmRelecanceActivity.this.rgAlarmDeviceLevel.setVisibility(8);
                    return;
                case C0470R.id.rBtnMedium:
                    DeviceAlarmRelecanceActivity.this.alarmDeviceLevel = 2;
                    DeviceAlarmRelecanceActivity.this.tvAlarmDeviceLevel.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceLevelMedium));
                    DeviceAlarmRelecanceActivity.this.rgAlarmDeviceLevel.setVisibility(8);
                    return;
                case C0470R.id.rBtnLow:
                    DeviceAlarmRelecanceActivity.this.alarmDeviceLevel = 1;
                    DeviceAlarmRelecanceActivity.this.tvAlarmDeviceLevel.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceLevelLow));
                    DeviceAlarmRelecanceActivity.this.rgAlarmDeviceLevel.setVisibility(8);
                    return;
                default:
                    return;
            }
        }
    }

    class C02984 implements OnClickListener {
        C02984() {
        }

        public void onClick(View arg0) {
            DeviceAlarmRelecanceActivity.this.presetPopuwindow(arg0, 121);
        }
    }

    private class AddAlarmDeviceThread extends Thread {
        byte[] buffer = new byte[412];
        private Handler handler;
        private int m_ThreadConfigID = 0;
        private String m_ThreadPassword = "admin";
        private int m_ThreadPort = 5050;
        private String m_ThreadServer = "123";
        private String m_ThreadUsername = "admin";
        private int m_nDeviceID = -1;
        private int m_nServerType = 101;
        private String m_strDomain;

        public AddAlarmDeviceThread(Handler handler, int configID, int nDeviceID, String domain, String server, int port, String username, String password, int nServerType) {
            this.m_ThreadConfigID = configID;
            this.handler = handler;
            this.m_ThreadServer = server;
            this.m_ThreadPort = port;
            this.m_ThreadUsername = username;
            this.m_ThreadPassword = password;
            this.m_nServerType = nServerType;
            this.m_nDeviceID = nDeviceID;
            this.m_strDomain = domain;
        }

        private int getAddAlarmDeviceInfoFromServer() {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            int nResultValues = 0;
            if (DeviceAlarmRelecanceActivity.this.nAddAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToServer(this.m_ThreadServer, this.m_ThreadPort, Defines.CMD_MR_WAIT);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nAddAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) LocalDefines.NV_IP_ALARM_DEVICE_ADD_REQUEST, this.buffer, 0);
                    System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 4, this.m_ThreadUsername.getBytes().length);
                    System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 36, this.m_ThreadPassword.getBytes().length);
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, 68);
                    String strID = DeviceAlarmRelecanceActivity.this.mapMessage.get("id");
                    if (strID == null || strID.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strID), this.buffer, 72);
                    String strName = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_name");
                    if (strName != null && strName.length() > 0) {
                        try {
                            Object strNameByte = strName.getBytes("GBK");
                            System.arraycopy(strNameByte, 0, this.buffer, 73, strNameByte.length);
                        } catch (UnsupportedEncodingException e5) {
                            e5.printStackTrace();
                        }
                    }
                    String strAddress = DeviceAlarmRelecanceActivity.this.mapMessage.get("device_address");
                    if (strAddress == null || strAddress.length() <= 0) {
                        return 0;
                    }
                    Functions.IntToBytes((long) Integer.parseInt(strAddress), this.buffer, 89);
                    Functions.ShortToBytesOne((short) DeviceAlarmRelecanceActivity.this.alarmOffOrOn, this.buffer, 93);
                    String strType = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_type");
                    if (strType == null || strType.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strType), this.buffer, 94);
                    String strLevel = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_level");
                    if (strLevel == null || strLevel.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strLevel), this.buffer, 95);
                    Functions.ShortToBytesOne((short) DeviceAlarmRelecanceActivity.this.relevancePreset, this.buffer, 96);
                    try {
                        writer.write(this.buffer, 0, 256);
                        writer.flush();
                    } catch (IOException e6) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e7) {
                            e7.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    int i = 0;
                    while (i < 500) {
                        try {
                            if (reader.available() >= 412) {
                                reader.read(this.buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(20);
                            } catch (InterruptedException e8) {
                                e8.printStackTrace();
                            }
                            i++;
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    if (bReadOK && Functions.BytesToInt(this.buffer, 0) == 232) {
                        Functions.changeMRParam(this.m_nDeviceID, false);
                        nConfigResultCode = 1001;
                        int nResultValue = Functions.BytesToInt(this.buffer, 4);
                        if (nResultValue == 1001) {
                            nResultValues = 1001;
                        } else if (nResultValue == 2001) {
                            nResultValues = 2001;
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e72) {
                        e72.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nAddAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 258;
                    msg.arg2 = nResultValues;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        private int getAddAlarmDeviceInfoFromMRServer(int deviceId) {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            int nResultValues = 0;
            if (DeviceAlarmRelecanceActivity.this.nAddAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToMRServer(null, 0, 5000, deviceId);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nAddAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) 881, this.buffer, 0);
                    Functions.IntToBytes(1002, this.buffer, 4);
                    if (this.m_strDomain != null) {
                        System.arraycopy(this.m_strDomain.getBytes(), 0, this.buffer, 8, this.m_strDomain.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_ThreadPort, this.buffer, 58);
                    if (this.m_ThreadUsername != null) {
                        System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 62, this.m_ThreadUsername.getBytes().length);
                    }
                    if (this.m_ThreadPassword != null) {
                        System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 94, this.m_ThreadPassword.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                    Functions.IntToBytes((long) LocalDefines.NV_IP_ALARM_DEVICE_ADD_REQUEST, this.buffer, 130);
                    String strID = DeviceAlarmRelecanceActivity.this.mapMessage.get("id");
                    if (strID == null || strID.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strID), this.buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST);
                    String strName = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_name");
                    if (strName != null && strName.length() > 0) {
                        try {
                            Object strNameByte = strName.getBytes("GBK");
                            System.arraycopy(strNameByte, 0, this.buffer, 135, strNameByte.length);
                        } catch (UnsupportedEncodingException e5) {
                            e5.printStackTrace();
                        }
                    }
                    String strAddress = DeviceAlarmRelecanceActivity.this.mapMessage.get("device_address");
                    if (strAddress == null || strAddress.length() <= 0) {
                        return 0;
                    }
                    Functions.IntToBytes((long) Integer.parseInt(strAddress), this.buffer, Defines.REC_FILE_DOWNLOAD);
                    Functions.ShortToBytesOne((short) DeviceAlarmRelecanceActivity.this.alarmOffOrOn, this.buffer, Defines.REC_FILE_GET_DATA);
                    String strType = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_type");
                    if (strType == null || strType.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strType), this.buffer, Defines.REC_FILE_GET_DATA_ACK);
                    String strLevel = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_level");
                    if (strLevel == null || strLevel.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strLevel), this.buffer, 157);
                    Functions.ShortToBytesOne((short) DeviceAlarmRelecanceActivity.this.relevancePreset, this.buffer, Defines.REC_FILE_PLAYBACK_GET_DATA);
                    try {
                        writer.write(this.buffer, 0, 256);
                        writer.flush();
                    } catch (IOException e6) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e7) {
                            e7.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    for (int i = 0; i < 500; i++) {
                        if (reader.available() >= 412) {
                            reader.read(this.buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e8) {
                            try {
                                e8.printStackTrace();
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                    }
                    if (bReadOK && Functions.BytesToInt(this.buffer, 0) == 232) {
                        Functions.changeMRParam(this.m_nDeviceID, true);
                        nConfigResultCode = 1001;
                        int nResultValue = Functions.BytesToInt(this.buffer, 4);
                        if (nResultValue == 1001) {
                            nResultValues = 1001;
                        } else if (nResultValue == 2001) {
                            nResultValues = 2001;
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e72) {
                        e72.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nAddAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 258;
                    msg.arg2 = nResultValues;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        public void run() {
            int nConfigResult;
            Message msg;
            if (Functions.isMRMode(this.m_nDeviceID)) {
                nConfigResult = getAddAlarmDeviceInfoFromMRServer(this.m_nDeviceID);
                if (nConfigResult == 0 || nConfigResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                    nConfigResult = getAddAlarmDeviceInfoFromServer();
                    if (nConfigResult != 1001) {
                        msg = this.handler.obtainMessage();
                        msg.arg1 = 258;
                        msg.arg2 = nConfigResult;
                        this.handler.sendMessage(msg);
                        return;
                    }
                    return;
                } else if (nConfigResult != 1001) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 258;
                    msg.arg2 = nConfigResult;
                    this.handler.sendMessage(msg);
                    return;
                } else {
                    return;
                }
            }
            nConfigResult = getAddAlarmDeviceInfoFromServer();
            if (nConfigResult == 0 || nConfigResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                nConfigResult = getAddAlarmDeviceInfoFromMRServer(this.m_nDeviceID);
                if (nConfigResult != 1001) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 258;
                    msg.arg2 = nConfigResult;
                    this.handler.sendMessage(msg);
                }
            } else if (nConfigResult != 1001) {
                msg = this.handler.obtainMessage();
                msg.arg1 = 258;
                msg.arg2 = nConfigResult;
                this.handler.sendMessage(msg);
            }
        }
    }

    private class AlarmDeviceThread extends Thread {
        byte[] buffer = new byte[412];
        private Handler handler;
        private int m_ThreadConfigID = 0;
        private String m_ThreadPassword = "admin";
        private int m_ThreadPort = 5050;
        private String m_ThreadServer = "123";
        private String m_ThreadUsername = "admin";
        private int m_nDeviceID = -1;
        private int m_nServerType = 101;
        private String m_strDomain;

        public AlarmDeviceThread(Handler handler, int configID, int nDeviceID, String domain, String server, int port, String username, String password, int nServerType) {
            this.m_ThreadConfigID = configID;
            this.handler = handler;
            this.m_ThreadServer = server;
            this.m_ThreadPort = port;
            this.m_ThreadUsername = username;
            this.m_ThreadPassword = password;
            this.m_nServerType = nServerType;
            this.m_nDeviceID = nDeviceID;
            this.m_strDomain = domain;
        }

        private int getAlarmDeviceSelectInfoFromServer() {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            if (DeviceAlarmRelecanceActivity.this.alarmDeviceList != null && DeviceAlarmRelecanceActivity.this.alarmDeviceList.size() > 0) {
                DeviceAlarmRelecanceActivity.this.alarmDeviceList.clear();
            }
            if (DeviceAlarmRelecanceActivity.this.nAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToServer(this.m_ThreadServer, this.m_ThreadPort, Defines.CMD_MR_WAIT);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) 130, this.buffer, 0);
                    System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 4, this.m_ThreadUsername.getBytes().length);
                    System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 36, this.m_ThreadPassword.getBytes().length);
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, 68);
                    try {
                        writer.write(this.buffer, 0, 256);
                        writer.flush();
                    } catch (IOException e5) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e6) {
                            e6.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    int i = 0;
                    while (i < 60) {
                        try {
                            if (reader.available() >= 412) {
                                reader.read(this.buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e7) {
                                e7.printStackTrace();
                            }
                            i++;
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    if (bReadOK && Functions.BytesToInt(this.buffer, 0) == 230) {
                        Functions.changeMRParam(this.m_nDeviceID, false);
                        nConfigResultCode = 1001;
                        int nDeviceNum = this.buffer[4];
                        int nPresetPermission = this.buffer[5];
                        int nPresetNum = this.buffer[6];
                        HashMap<String, Object> map;
                        if (nDeviceNum <= 0 || nDeviceNum >= 100) {
                            map = new HashMap();
                            map.put("id", Integer.valueOf(0));
                            map.put("alarm_presetPermission", Integer.valueOf(nPresetPermission));
                            map.put("alarm_presetNum", Integer.valueOf(nPresetNum));
                            map.put("alarm_name", DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceName));
                            map.put("device_address", DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceAddressCode));
                            map.put("alarm_enable", Constants.MAIN_VERSION_TAG);
                            map.put("alarm_type", Constants.MAIN_VERSION_TAG);
                            map.put("alarm_level", Constants.MAIN_VERSION_TAG);
                            map.put("alarm_ptzxID", Constants.MAIN_VERSION_TAG);
                            map.put("device_num", Integer.valueOf(0));
                            DeviceAlarmRelecanceActivity.this.alarmDeviceList.add(map);
                        } else {
                            int byteLenth = 7;
                            for (i = 0; i < nDeviceNum + 1; i++) {
                                map = new HashMap();
                                if (i < nDeviceNum) {
                                    int numID = this.buffer[byteLenth];
                                    byteLenth++;
                                    int len = 0;
                                    while (len < 16 && ((char) this.buffer[byteLenth + len]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] alarmDevice = new byte[len];
                                    Arrays.fill(alarmDevice, (byte) 0);
                                    System.arraycopy(this.buffer, byteLenth, alarmDevice, 0, len);
                                    String strName = null;
                                    try {
                                        strName = new String(alarmDevice, "GBK");
                                    } catch (UnsupportedEncodingException e8) {
                                        e8.printStackTrace();
                                    }
                                    byteLenth += 16;
                                    int deviceAddress = Functions.BytesToInt(this.buffer, byteLenth);
                                    byteLenth += 4;
                                    int alarmEnable = this.buffer[byteLenth];
                                    byteLenth++;
                                    int alarmType = this.buffer[byteLenth];
                                    byteLenth++;
                                    int alarmLevel = this.buffer[byteLenth];
                                    byteLenth++;
                                    int alarmptzxID = this.buffer[byteLenth];
                                    byteLenth++;
                                    map.put("id", Integer.valueOf(numID));
                                    map.put("alarm_name", strName);
                                    map.put("alarm_presetPermission", Integer.valueOf(nPresetPermission));
                                    map.put("alarm_presetNum", Integer.valueOf(nPresetNum));
                                    map.put("device_address", Integer.valueOf(deviceAddress));
                                    map.put("alarm_enable", Integer.valueOf(alarmEnable));
                                    map.put("alarm_type", Integer.valueOf(alarmType));
                                    map.put("alarm_level", Integer.valueOf(alarmLevel));
                                    map.put("alarm_ptzxID", Integer.valueOf(alarmptzxID));
                                    map.put("device_num", Integer.valueOf(nDeviceNum));
                                    DeviceAlarmRelecanceActivity.this.alarmDeviceList.add(map);
                                } else {
                                    map.put("id", Integer.valueOf(0));
                                    map.put("alarm_presetPermission", Integer.valueOf(nPresetPermission));
                                    map.put("alarm_presetNum", Integer.valueOf(nPresetNum));
                                    map.put("alarm_name", DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceName));
                                    map.put("device_address", DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceAddressCode));
                                    map.put("alarm_enable", Constants.MAIN_VERSION_TAG);
                                    map.put("alarm_type", Constants.MAIN_VERSION_TAG);
                                    map.put("alarm_level", Constants.MAIN_VERSION_TAG);
                                    map.put("alarm_ptzxID", Constants.MAIN_VERSION_TAG);
                                    map.put("device_num", Integer.valueOf(0));
                                    DeviceAlarmRelecanceActivity.this.alarmDeviceList.add(map);
                                }
                            }
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e62) {
                        e62.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 256;
                    msg.arg2 = nConfigResultCode;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        private int getAlarmDeviceSelectInfoFromMRServer(int deviceId) {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            if (DeviceAlarmRelecanceActivity.this.alarmDeviceList != null && DeviceAlarmRelecanceActivity.this.alarmDeviceList.size() > 0) {
                DeviceAlarmRelecanceActivity.this.alarmDeviceList.clear();
            }
            if (DeviceAlarmRelecanceActivity.this.nAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToMRServer(null, 0, 5000, deviceId);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) 880, this.buffer, 0);
                    Functions.IntToBytes(1002, this.buffer, 4);
                    if (this.m_strDomain != null) {
                        System.arraycopy(this.m_strDomain.getBytes(), 0, this.buffer, 8, this.m_strDomain.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_ThreadPort, this.buffer, 58);
                    if (this.m_ThreadUsername != null) {
                        System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 62, this.m_ThreadUsername.getBytes().length);
                    }
                    if (this.m_ThreadPassword != null) {
                        System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 94, this.m_ThreadPassword.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                    Functions.IntToBytes((long) 130, this.buffer, 130);
                    try {
                        writer.write(this.buffer, 0, 256);
                        writer.flush();
                    } catch (IOException e5) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e6) {
                            e6.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    int i = 0;
                    while (i < 360) {
                        try {
                            if (reader.available() >= 412) {
                                reader.read(this.buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e7) {
                                e7.printStackTrace();
                            }
                            i++;
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    if (bReadOK && Functions.BytesToInt(this.buffer, 0) == 230) {
                        Functions.changeMRParam(this.m_nDeviceID, true);
                        nConfigResultCode = 1001;
                        int nDeviceNum = this.buffer[4];
                        int nPresetPermission = this.buffer[5];
                        int nPresetNum = this.buffer[6];
                        HashMap<String, Object> map;
                        if (nDeviceNum > 0) {
                            int byteLenth = 7;
                            for (i = 0; i < nDeviceNum + 1; i++) {
                                map = new HashMap();
                                if (i < nDeviceNum) {
                                    int numID = this.buffer[byteLenth];
                                    byteLenth++;
                                    int len = 0;
                                    while (len < 16 && ((char) this.buffer[byteLenth + len]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] alarmDevice = new byte[len];
                                    Arrays.fill(alarmDevice, (byte) 0);
                                    System.arraycopy(this.buffer, byteLenth, alarmDevice, 0, len);
                                    String strName = null;
                                    try {
                                        strName = new String(alarmDevice, "GBK");
                                    } catch (UnsupportedEncodingException e8) {
                                        e8.printStackTrace();
                                    }
                                    byteLenth += 16;
                                    int deviceAddress = Functions.BytesToInt(this.buffer, byteLenth);
                                    byteLenth += 4;
                                    int alarmEnable = this.buffer[byteLenth];
                                    byteLenth++;
                                    int alarmType = this.buffer[byteLenth];
                                    byteLenth++;
                                    int alarmLevel = this.buffer[byteLenth];
                                    byteLenth++;
                                    int alarmptzxID = this.buffer[byteLenth];
                                    byteLenth++;
                                    map.put("id", Integer.valueOf(numID));
                                    map.put("alarm_name", strName);
                                    map.put("alarm_presetPermission", Integer.valueOf(nPresetPermission));
                                    map.put("alarm_presetNum", Integer.valueOf(nPresetNum));
                                    map.put("device_address", Integer.valueOf(deviceAddress));
                                    map.put("alarm_enable", Integer.valueOf(alarmEnable));
                                    map.put("alarm_type", Integer.valueOf(alarmType));
                                    map.put("alarm_level", Integer.valueOf(alarmLevel));
                                    map.put("alarm_ptzxID", Integer.valueOf(alarmptzxID));
                                    map.put("device_num", Integer.valueOf(nDeviceNum));
                                    DeviceAlarmRelecanceActivity.this.alarmDeviceList.add(map);
                                } else {
                                    map.put("id", Integer.valueOf(0));
                                    map.put("alarm_name", DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceName));
                                    map.put("alarm_presetPermission", Integer.valueOf(nPresetPermission));
                                    map.put("alarm_presetNum", Integer.valueOf(nPresetNum));
                                    map.put("device_address", DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceAddressCode));
                                    map.put("alarm_enable", Constants.MAIN_VERSION_TAG);
                                    map.put("alarm_type", Constants.MAIN_VERSION_TAG);
                                    map.put("alarm_level", Constants.MAIN_VERSION_TAG);
                                    map.put("alarm_ptzxID", Constants.MAIN_VERSION_TAG);
                                    map.put("device_num", Integer.valueOf(0));
                                    DeviceAlarmRelecanceActivity.this.alarmDeviceList.add(map);
                                }
                            }
                        } else {
                            map = new HashMap();
                            map.put("id", Integer.valueOf(0));
                            map.put("alarm_name", DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceName));
                            map.put("alarm_presetPermission", Integer.valueOf(nPresetPermission));
                            map.put("alarm_presetNum", Integer.valueOf(nPresetNum));
                            map.put("device_address", DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceAddressCode));
                            map.put("alarm_enable", Constants.MAIN_VERSION_TAG);
                            map.put("alarm_type", Constants.MAIN_VERSION_TAG);
                            map.put("alarm_level", Constants.MAIN_VERSION_TAG);
                            map.put("alarm_ptzxID", Constants.MAIN_VERSION_TAG);
                            map.put("device_num", Integer.valueOf(0));
                            DeviceAlarmRelecanceActivity.this.alarmDeviceList.add(map);
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e62) {
                        e62.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 256;
                    msg.arg2 = nConfigResultCode;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        public void run() {
            int nConfigResult;
            Message msg;
            if (Functions.isMRMode(this.m_nDeviceID)) {
                nConfigResult = getAlarmDeviceSelectInfoFromMRServer(this.m_nDeviceID);
                if (nConfigResult == 0 || nConfigResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                    nConfigResult = getAlarmDeviceSelectInfoFromServer();
                    if (nConfigResult != 1001) {
                        msg = this.handler.obtainMessage();
                        msg.arg1 = 256;
                        msg.arg2 = nConfigResult;
                        this.handler.sendMessage(msg);
                        return;
                    }
                    return;
                } else if (nConfigResult != 1001) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 256;
                    msg.arg2 = nConfigResult;
                    this.handler.sendMessage(msg);
                    return;
                } else {
                    return;
                }
            }
            nConfigResult = getAlarmDeviceSelectInfoFromServer();
            if (nConfigResult == 0 || nConfigResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                nConfigResult = getAlarmDeviceSelectInfoFromMRServer(this.m_nDeviceID);
                if (nConfigResult != 1001) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 256;
                    msg.arg2 = nConfigResult;
                    this.handler.sendMessage(msg);
                }
            } else if (nConfigResult != 1001) {
                msg = this.handler.obtainMessage();
                msg.arg1 = 256;
                msg.arg2 = nConfigResult;
                this.handler.sendMessage(msg);
            }
        }
    }

    private class AlarmTypeAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<String> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageView ivPresetImage;
            ImageView ivPresetSetImage;
            TextView tvPresetText;

            private ItemViewHolder() {
            }
        }

        public AlarmTypeAdapter(Context c, ArrayList<String> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.relecance_preset_count_item, null);
                this.holder = new ItemViewHolder();
                this.holder.ivPresetImage = (ImageView) convertView.findViewById(this.valueViewID[0]);
                this.holder.ivPresetSetImage = (ImageView) convertView.findViewById(this.valueViewID[1]);
                this.holder.tvPresetText = (TextView) convertView.findViewById(this.valueViewID[2]);
                convertView.setTag(this.holder);
            }
            this.holder.tvPresetText.setText(new StringBuilder(String.valueOf((String) this.mAppList.get(position))).toString());
            if (DeviceAlarmRelecanceActivity.this.alarmDeviceType == position) {
                this.holder.ivPresetSetImage.setImageResource(C0470R.drawable.play_back_choose_2);
                this.holder.tvPresetText.setTextColor(-16776961);
            } else {
                this.holder.ivPresetSetImage.setImageResource(C0470R.drawable.play_back_choose_1);
                this.holder.tvPresetText.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            }
            return convertView;
        }
    }

    private class AlterAlarmDeviceThread extends Thread {
        byte[] buffer = new byte[412];
        private Handler handler;
        private int m_ThreadConfigID = 0;
        private String m_ThreadPassword = "admin";
        private int m_ThreadPort = 5050;
        private String m_ThreadServer = "123";
        private String m_ThreadUsername = "admin";
        private int m_nDeviceID = -1;
        private int m_nServerType = 101;
        private String m_strDomain;

        public AlterAlarmDeviceThread(Handler handler, int configID, int nDeviceID, String domain, String server, int port, String username, String password, int nServerType) {
            this.m_ThreadConfigID = configID;
            this.handler = handler;
            this.m_ThreadServer = server;
            this.m_ThreadPort = port;
            this.m_ThreadUsername = username;
            this.m_ThreadPassword = password;
            this.m_nServerType = nServerType;
            this.m_nDeviceID = nDeviceID;
            this.m_strDomain = domain;
        }

        private int getAlterAlarmDeviceInfoFromServer() {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            int nResultValues = 0;
            if (DeviceAlarmRelecanceActivity.this.nAlterAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToServer(this.m_ThreadServer, this.m_ThreadPort, Defines.CMD_MR_WAIT);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nAlterAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) LocalDefines.NV_IP_ALARM_DEVICE_MODIFY_REQUEST, this.buffer, 0);
                    System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 4, this.m_ThreadUsername.getBytes().length);
                    System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 36, this.m_ThreadPassword.getBytes().length);
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, 68);
                    String strID = DeviceAlarmRelecanceActivity.this.mapMessage.get("id");
                    if (strID == null || strID.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strID), this.buffer, 72);
                    String strName = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_name");
                    if (strName != null && strName.length() > 0) {
                        try {
                            Object strNameByte = strName.getBytes("GBK");
                            System.arraycopy(strNameByte, 0, this.buffer, 73, strNameByte.length);
                        } catch (UnsupportedEncodingException e5) {
                            e5.printStackTrace();
                        }
                    }
                    String strAddress = DeviceAlarmRelecanceActivity.this.mapMessage.get("device_address");
                    if (strAddress == null || strAddress.length() <= 0) {
                        return 0;
                    }
                    Functions.IntToBytes((long) Integer.parseInt(strAddress), this.buffer, 89);
                    Functions.ShortToBytesOne((short) DeviceAlarmRelecanceActivity.this.alarmOffOrOn, this.buffer, 93);
                    String strType = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_type");
                    if (strType == null || strType.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strType), this.buffer, 94);
                    String strLevel = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_level");
                    if (strLevel == null || strLevel.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strLevel), this.buffer, 95);
                    Functions.ShortToBytesOne((short) DeviceAlarmRelecanceActivity.this.relevancePreset, this.buffer, 96);
                    try {
                        writer.write(this.buffer, 0, 256);
                        writer.flush();
                    } catch (IOException e6) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e7) {
                            e7.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    int i = 0;
                    while (i < 500) {
                        try {
                            if (reader.available() >= 412) {
                                reader.read(this.buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(20);
                            } catch (InterruptedException e8) {
                                e8.printStackTrace();
                            }
                            i++;
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    if (bReadOK && Functions.BytesToInt(this.buffer, 0) == 233) {
                        Functions.changeMRParam(this.m_nDeviceID, false);
                        nConfigResultCode = 1001;
                        int nResultValue = Functions.BytesToInt(this.buffer, 4);
                        if (nResultValue == 1001) {
                            nResultValues = 1001;
                        } else if (nResultValue == 2001) {
                            nResultValues = 2001;
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e72) {
                        e72.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nAlterAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 259;
                    msg.arg2 = nResultValues;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        private int getAlterAlarmDeviceInfoFromMRServer(int deviceId) {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            int nResultValues = 0;
            if (DeviceAlarmRelecanceActivity.this.nAlterAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToMRServer(null, 0, 5000, deviceId);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nAlterAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) 880, this.buffer, 0);
                    Functions.IntToBytes(1002, this.buffer, 4);
                    if (this.m_strDomain != null) {
                        System.arraycopy(this.m_strDomain.getBytes(), 0, this.buffer, 8, this.m_strDomain.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_ThreadPort, this.buffer, 58);
                    if (this.m_ThreadUsername != null) {
                        System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 62, this.m_ThreadUsername.getBytes().length);
                    }
                    if (this.m_ThreadPassword != null) {
                        System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 94, this.m_ThreadPassword.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                    Functions.IntToBytes((long) LocalDefines.NV_IP_ALARM_DEVICE_MODIFY_REQUEST, this.buffer, 130);
                    String strID = DeviceAlarmRelecanceActivity.this.mapMessage.get("id");
                    if (strID == null || strID.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strID), this.buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST);
                    String strName = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_name");
                    if (strName != null && strName.length() > 0) {
                        try {
                            Object strNameByte = strName.getBytes("GBK");
                            System.arraycopy(strNameByte, 0, this.buffer, 135, strNameByte.length);
                        } catch (UnsupportedEncodingException e5) {
                            e5.printStackTrace();
                        }
                    }
                    String strAddress = DeviceAlarmRelecanceActivity.this.mapMessage.get("device_address");
                    if (strAddress == null || strAddress.length() <= 0) {
                        return 0;
                    }
                    Functions.IntToBytes((long) Integer.parseInt(strAddress), this.buffer, Defines.REC_FILE_DOWNLOAD);
                    Functions.ShortToBytesOne((short) DeviceAlarmRelecanceActivity.this.alarmOffOrOn, this.buffer, Defines.REC_FILE_GET_DATA);
                    String strType = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_type");
                    if (strType == null || strType.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strType), this.buffer, Defines.REC_FILE_GET_DATA_ACK);
                    String strLevel = DeviceAlarmRelecanceActivity.this.mapMessage.get("alarm_level");
                    if (strLevel == null || strLevel.length() <= 0) {
                        return 0;
                    }
                    Functions.ShortToBytesOne((short) Integer.parseInt(strLevel), this.buffer, 157);
                    Functions.ShortToBytesOne((short) DeviceAlarmRelecanceActivity.this.relevancePreset, this.buffer, Defines.REC_FILE_PLAYBACK_GET_DATA);
                    try {
                        writer.write(this.buffer, 0, 256);
                        writer.flush();
                    } catch (IOException e6) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e7) {
                            e7.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    for (int i = 0; i < 500; i++) {
                        if (reader.available() >= 412) {
                            reader.read(this.buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e8) {
                            try {
                                e8.printStackTrace();
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                    }
                    if (bReadOK && Functions.BytesToInt(this.buffer, 0) == 233) {
                        Functions.changeMRParam(this.m_nDeviceID, true);
                        nConfigResultCode = 1001;
                        int nResultValue = Functions.BytesToInt(this.buffer, 4);
                        if (nResultValue == 1001) {
                            nResultValues = 1001;
                        } else if (nResultValue == 2001) {
                            nResultValues = 2001;
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e72) {
                        e72.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nAlterAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 259;
                    msg.arg2 = nResultValues;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        public void run() {
            int nConfigResult;
            Message msg;
            if (Functions.isMRMode(this.m_nDeviceID)) {
                nConfigResult = getAlterAlarmDeviceInfoFromMRServer(this.m_nDeviceID);
                if (nConfigResult == 0 || nConfigResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                    nConfigResult = getAlterAlarmDeviceInfoFromServer();
                    if (nConfigResult != 1001) {
                        msg = this.handler.obtainMessage();
                        msg.arg1 = 259;
                        msg.arg2 = nConfigResult;
                        this.handler.sendMessage(msg);
                        return;
                    }
                    return;
                } else if (nConfigResult != 1001) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 259;
                    msg.arg2 = nConfigResult;
                    this.handler.sendMessage(msg);
                    return;
                } else {
                    return;
                }
            }
            nConfigResult = getAlterAlarmDeviceInfoFromServer();
            if (nConfigResult == 0 || nConfigResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                nConfigResult = getAlterAlarmDeviceInfoFromMRServer(this.m_nDeviceID);
                if (nConfigResult != 1001) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 259;
                    msg.arg2 = nConfigResult;
                    this.handler.sendMessage(msg);
                }
            } else if (nConfigResult != 1001) {
                msg = this.handler.obtainMessage();
                msg.arg1 = 259;
                msg.arg2 = nConfigResult;
                this.handler.sendMessage(msg);
            }
        }
    }

    private class DeleteAlarmDeviceThread extends Thread {
        byte[] buffer = new byte[412];
        private Handler handler;
        private int m_ThreadConfigID = 0;
        private String m_ThreadPassword = "admin";
        private int m_ThreadPort = 5050;
        private String m_ThreadServer = "123";
        private String m_ThreadUsername = "admin";
        private int m_nDeviceID = -1;
        private int m_nServerType = 101;
        private String m_strDomain;
        int nAlarmAddress = 0;
        int nAlarmID = 0;

        public DeleteAlarmDeviceThread(Handler handler, int configID, int alarmID, int alarmAddress, int nDeviceID, String domain, String server, int port, String username, String password, int nServerType) {
            this.m_ThreadConfigID = configID;
            this.handler = handler;
            this.m_ThreadServer = server;
            this.m_ThreadPort = port;
            this.m_ThreadUsername = username;
            this.m_ThreadPassword = password;
            this.m_nServerType = nServerType;
            this.m_nDeviceID = nDeviceID;
            this.m_strDomain = domain;
            this.nAlarmID = alarmID;
            this.nAlarmAddress = alarmAddress;
        }

        private int getDeleteAlarmDeviceInfoFromServer() {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            int nResultValues = 0;
            if (DeviceAlarmRelecanceActivity.this.nDeleteAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToServer(this.m_ThreadServer, this.m_ThreadPort, Defines.CMD_MR_WAIT);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nDeleteAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST, this.buffer, 0);
                    System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 4, this.m_ThreadUsername.getBytes().length);
                    System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 36, this.m_ThreadPassword.getBytes().length);
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, 68);
                    Functions.ShortToBytesOne((short) this.nAlarmID, this.buffer, 72);
                    Functions.IntToBytes((long) this.nAlarmAddress, this.buffer, 73);
                    System.out.println("锟借备getRecordConfig  锟斤拷锟斤拷指锟斤拷" + this.m_ThreadUsername.length() + " : " + this.m_ThreadPassword.length() + ";" + this.m_ThreadUsername.getBytes().length + ":" + this.m_ThreadPassword.getBytes().length);
                    try {
                        writer.write(this.buffer, 0, 256);
                        writer.flush();
                    } catch (IOException e5) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e6) {
                            e6.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    int i = 0;
                    while (i < 500) {
                        try {
                            if (reader.available() >= 412) {
                                reader.read(this.buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(20);
                            } catch (InterruptedException e7) {
                                e7.printStackTrace();
                            }
                            i++;
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    if (bReadOK && Functions.BytesToInt(this.buffer, 0) == 234) {
                        Functions.changeMRParam(this.m_nDeviceID, false);
                        nConfigResultCode = 1001;
                        int nResultValue = Functions.BytesToInt(this.buffer, 4);
                        if (nResultValue == 1001) {
                            nResultValues = 1001;
                        } else if (nResultValue == 2001) {
                            nResultValues = 2001;
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e62) {
                        e62.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nDeleteAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 260;
                    msg.arg2 = nResultValues;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        private int getDeleteAlarmDeviceInfoFromMRServer(int deviceId) {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            int nResultValues = 0;
            if (DeviceAlarmRelecanceActivity.this.nDeleteAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToMRServer(null, 0, 5000, deviceId);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nDeleteAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) 880, this.buffer, 0);
                    Functions.IntToBytes(1002, this.buffer, 4);
                    if (this.m_strDomain != null) {
                        System.arraycopy(this.m_strDomain.getBytes(), 0, this.buffer, 8, this.m_strDomain.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_ThreadPort, this.buffer, 58);
                    if (this.m_ThreadUsername != null) {
                        System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 62, this.m_ThreadUsername.getBytes().length);
                    }
                    if (this.m_ThreadPassword != null) {
                        System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 94, this.m_ThreadPassword.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                    Functions.IntToBytes((long) LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST, this.buffer, 130);
                    Functions.ShortToBytes((short) this.nAlarmID, this.buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST);
                    Functions.IntToBytes((long) this.nAlarmAddress, this.buffer, 135);
                    try {
                        writer.write(this.buffer, 0, 256);
                        writer.flush();
                    } catch (IOException e5) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e6) {
                            e6.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    for (int i = 0; i < 500; i++) {
                        if (reader.available() >= 412) {
                            reader.read(this.buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e7) {
                            try {
                                e7.printStackTrace();
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                    }
                    if (bReadOK && Functions.BytesToInt(this.buffer, 0) == 234) {
                        Functions.changeMRParam(this.m_nDeviceID, true);
                        nConfigResultCode = 1001;
                        int nResultValue = Functions.BytesToInt(this.buffer, 4);
                        if (nResultValue == 1001) {
                            nResultValues = 1001;
                        } else if (nResultValue == 2001) {
                            nResultValues = 2001;
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e62) {
                        e62.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nDeleteAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 260;
                    msg.arg2 = nResultValues;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        public void run() {
            int nConfigResult;
            Message msg;
            if (Functions.isMRMode(this.m_nDeviceID)) {
                nConfigResult = getDeleteAlarmDeviceInfoFromMRServer(this.m_nDeviceID);
                if (nConfigResult == 0 || nConfigResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                    nConfigResult = getDeleteAlarmDeviceInfoFromServer();
                    if (nConfigResult != 1001) {
                        msg = this.handler.obtainMessage();
                        msg.arg1 = 259;
                        msg.arg2 = nConfigResult;
                        this.handler.sendMessage(msg);
                        return;
                    }
                    return;
                } else if (nConfigResult != 1001) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 259;
                    msg.arg2 = nConfigResult;
                    this.handler.sendMessage(msg);
                    return;
                } else {
                    return;
                }
            }
            nConfigResult = getDeleteAlarmDeviceInfoFromServer();
            if (nConfigResult == 0 || nConfigResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                nConfigResult = getDeleteAlarmDeviceInfoFromMRServer(this.m_nDeviceID);
                if (nConfigResult != 1001) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 259;
                    msg.arg2 = nConfigResult;
                    this.handler.sendMessage(msg);
                }
            } else if (nConfigResult != 1001) {
                msg = this.handler.obtainMessage();
                msg.arg1 = 259;
                msg.arg2 = nConfigResult;
                this.handler.sendMessage(msg);
            }
        }
    }

    private class DeviceListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            private ImageView ivAlarmRelecanceFunction;
            private ImageView ivAlarmRelecanceState;
            private TextView tvAlarmRelecanceAddress;
            private TextView tvAlarmRelecanceFigure;
            private TextView tvAlarmRelecanceName;

            private ItemViewHolder() {
            }
        }

        public DeviceListViewAdapter(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.alarm_relecance_device_select_item, null);
                this.holder = new ItemViewHolder();
                this.holder.tvAlarmRelecanceFigure = (TextView) convertView.findViewById(this.valueViewID[0]);
                this.holder.tvAlarmRelecanceName = (TextView) convertView.findViewById(this.valueViewID[1]);
                this.holder.tvAlarmRelecanceAddress = (TextView) convertView.findViewById(this.valueViewID[2]);
                this.holder.ivAlarmRelecanceFunction = (ImageView) convertView.findViewById(this.valueViewID[3]);
                this.holder.ivAlarmRelecanceState = (ImageView) convertView.findViewById(this.valueViewID[4]);
                convertView.setTag(this.holder);
            }
            HashMap<String, Object> map = (HashMap) this.mAppList.get(position);
            int nID = Integer.parseInt(map.get("id")) + 1;
            String strName = map.get("alarm_name");
            String strAlarmPerset = map.get("alarm_presetNum");
            String strAddress = map.get("device_address");
            String strEnable = map.get("alarm_enable");
            String strType = map.get("alarm_type");
            String strLevel = map.get("alarm_level");
            String strPtzxID = map.get("alarm_ptzxID");
            if (strAlarmPerset != null && strAlarmPerset.length() > 0) {
                DeviceAlarmRelecanceActivity.this.presetNum = Integer.parseInt(strAlarmPerset);
            }
            if (strPtzxID != null && strPtzxID.length() > 0) {
                DeviceAlarmRelecanceActivity.this.relevancePreset = Integer.parseInt(strPtzxID);
            }
            if (strEnable != null && strEnable.length() > 0) {
                if (Integer.parseInt(strEnable) == 1) {
                    this.holder.ivAlarmRelecanceState.setImageResource(C0470R.drawable.online);
                } else {
                    this.holder.ivAlarmRelecanceState.setImageResource(C0470R.drawable.offline);
                }
            }
            if (strType != null && strType.length() > 0) {
                DeviceAlarmRelecanceActivity.this.alarmDeviceType = Integer.parseInt(strType);
            }
            if (strLevel != null && strLevel.length() > 0) {
                DeviceAlarmRelecanceActivity.this.alarmDeviceLevel = Integer.parseInt(strLevel);
            }
            int nDeviceNum = Integer.parseInt(map.get("device_num"));
            this.holder.tvAlarmRelecanceFigure.setText(new StringBuilder(String.valueOf(nID)).toString());
            this.holder.tvAlarmRelecanceName.setText(new StringBuilder(String.valueOf(strName)).toString());
            this.holder.tvAlarmRelecanceAddress.setText(new StringBuilder(String.valueOf(strAddress)).toString());
            if (nDeviceNum > 0) {
                this.holder.ivAlarmRelecanceFunction.setImageResource(C0470R.drawable.arrow_selector);
            } else {
                this.holder.tvAlarmRelecanceFigure.setBackgroundResource(C0470R.drawable.btn_relecance_bg_gray_1);
                this.holder.tvAlarmRelecanceName.setBackgroundResource(C0470R.drawable.btn_relecance_bg_gray_1);
                this.holder.tvAlarmRelecanceAddress.setBackgroundResource(C0470R.drawable.btn_relecance_bg_gray_1);
                this.holder.tvAlarmRelecanceFigure.setTextColor(-7829368);
                this.holder.tvAlarmRelecanceName.setTextColor(-7829368);
                this.holder.tvAlarmRelecanceAddress.setTextColor(-7829368);
                this.holder.ivAlarmRelecanceFunction.setImageResource(C0470R.drawable.more_function_2);
            }
            return convertView;
        }
    }

    private class DeviceListViewAdapterAdd extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            private Button ivAlarmRelecanceFunction;
            private TextView tvAlarmRelecanceAddress;
            private TextView tvAlarmRelecanceFigure;

            private ItemViewHolder() {
            }
        }

        class ListViewButtonListener implements OnClickListener {
            private HashMap<String, Object> map;
            private int nDeviceNum;
            private int position;

            ListViewButtonListener(int pos, int nDeviceNum, HashMap<String, Object> map) {
                this.position = pos;
                this.nDeviceNum = nDeviceNum;
                this.map = map;
            }

            public void onClick(View v) {
                DeviceAlarmRelecanceActivity.this.mapMessage = this.map;
                DeviceAlarmRelecanceActivity.this.bAddOrAlarm = true;
                if (this.nDeviceNum > 0) {
                    DeviceAlarmRelecanceActivity.this.btnRelecanceAlter.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.btnRelecanceDelete.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.btnRelecanceAdd.setVisibility(0);
                    DeviceAlarmRelecanceActivity.this.llRelecanceAlter.setVisibility(0);
                    DeviceAlarmRelecanceActivity.this.llRelecanceAdd.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.lvRelecance.setVisibility(8);
                    DeviceAlarmRelecanceActivity.this.tvRelecance.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceAddDevice));
                    String strName = this.map.get("alarm_name");
                    if (strName != null && strName.length() > 0) {
                        DeviceAlarmRelecanceActivity.this.etAlarmDeviceName.setText(strName);
                    }
                    DeviceAlarmRelecanceActivity.this.tvAlarmDeviceAddress.setText(this.map.get("device_address"));
                    String strEnable = this.map.get("alarm_enable");
                    if (strEnable != null && strEnable.length() > 0) {
                        if (Integer.parseInt(strEnable) == DeviceAlarmRelecanceActivity.ALARM_OFF) {
                            DeviceAlarmRelecanceActivity.this.alarmOffOrOn = DeviceAlarmRelecanceActivity.ALARM_OFF;
                            DeviceAlarmRelecanceActivity.this.rBtnOff.setChecked(true);
                            DeviceAlarmRelecanceActivity.this.rBtnOn.setChecked(false);
                            DeviceAlarmRelecanceActivity.this.tvAlarmDeviceOffOrOn.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.record_record_close));
                        } else {
                            DeviceAlarmRelecanceActivity.this.alarmOffOrOn = DeviceAlarmRelecanceActivity.ALARM_ON;
                            DeviceAlarmRelecanceActivity.this.rBtnOff.setChecked(false);
                            DeviceAlarmRelecanceActivity.this.rBtnOn.setChecked(true);
                            DeviceAlarmRelecanceActivity.this.tvAlarmDeviceOffOrOn.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.record_record_open));
                        }
                    }
                    String strLevel = this.map.get("alarm_level");
                    if (strLevel != null && strLevel.length() > 0) {
                        int nLevel = Integer.parseInt(strLevel);
                        if (nLevel == 1) {
                            DeviceAlarmRelecanceActivity.this.tvAlarmDeviceLevel.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceLevelLow));
                            DeviceAlarmRelecanceActivity.this.rBtnHigh.setChecked(false);
                            DeviceAlarmRelecanceActivity.this.rBtnMedium.setChecked(false);
                            DeviceAlarmRelecanceActivity.this.rBtnLow.setChecked(true);
                        } else if (nLevel == 2) {
                            DeviceAlarmRelecanceActivity.this.tvAlarmDeviceLevel.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceLevelMedium));
                            DeviceAlarmRelecanceActivity.this.rBtnHigh.setChecked(false);
                            DeviceAlarmRelecanceActivity.this.rBtnMedium.setChecked(true);
                            DeviceAlarmRelecanceActivity.this.rBtnLow.setChecked(false);
                        } else if (nLevel == 3) {
                            DeviceAlarmRelecanceActivity.this.tvAlarmDeviceLevel.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceLevelHigh));
                            DeviceAlarmRelecanceActivity.this.rBtnHigh.setChecked(true);
                            DeviceAlarmRelecanceActivity.this.rBtnMedium.setChecked(false);
                            DeviceAlarmRelecanceActivity.this.rBtnLow.setChecked(false);
                        } else {
                            DeviceAlarmRelecanceActivity.this.tvAlarmDeviceLevel.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceAlarmLevel));
                            DeviceAlarmRelecanceActivity.this.alarmDeviceLevel = 2;
                            DeviceAlarmRelecanceActivity.this.rBtnHigh.setChecked(false);
                            DeviceAlarmRelecanceActivity.this.rBtnMedium.setChecked(false);
                            DeviceAlarmRelecanceActivity.this.rBtnLow.setChecked(true);
                        }
                    }
                    String strType = this.map.get("alarm_type");
                    if (strType != null && strType.length() > 0) {
                        switch (Integer.parseInt(strType)) {
                            case 0:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceOther));
                                DeviceAlarmRelecanceActivity.this.rBtnRKE.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnSmoke.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnFeeling.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnGAS.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnOther.setChecked(true);
                                break;
                            case 1:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceTypeRKE));
                                DeviceAlarmRelecanceActivity.this.rBtnRKE.setChecked(true);
                                DeviceAlarmRelecanceActivity.this.rBtnSmoke.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnFeeling.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnGAS.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnOther.setChecked(false);
                                break;
                            case 2:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceTypeSmoke));
                                DeviceAlarmRelecanceActivity.this.rBtnRKE.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnSmoke.setChecked(true);
                                DeviceAlarmRelecanceActivity.this.rBtnFeeling.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnGAS.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnOther.setChecked(false);
                                break;
                            case 3:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceGAS));
                                DeviceAlarmRelecanceActivity.this.rBtnRKE.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnSmoke.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnFeeling.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnGAS.setChecked(true);
                                DeviceAlarmRelecanceActivity.this.rBtnOther.setChecked(false);
                                break;
                            case 4:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceFeeling));
                                DeviceAlarmRelecanceActivity.this.rBtnRKE.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnSmoke.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnFeeling.setChecked(true);
                                DeviceAlarmRelecanceActivity.this.rBtnGAS.setChecked(false);
                                DeviceAlarmRelecanceActivity.this.rBtnOther.setChecked(false);
                                break;
                        }
                    }
                    if (DeviceAlarmRelecanceActivity.this.presetNum > 0) {
                        DeviceAlarmRelecanceActivity.this.tvPreset.setVisibility(0);
                        DeviceAlarmRelecanceActivity.this.tvAlarmDevicePreset.setVisibility(0);
                        DeviceAlarmRelecanceActivity.this.ivAlarmDevicePreset.setVisibility(0);
                    } else {
                        DeviceAlarmRelecanceActivity.this.tvPreset.setVisibility(8);
                        DeviceAlarmRelecanceActivity.this.tvAlarmDevicePreset.setVisibility(8);
                        DeviceAlarmRelecanceActivity.this.ivAlarmDevicePreset.setVisibility(8);
                    }
                    String strPtzxID = this.map.get("alarm_ptzxID");
                    if (strPtzxID != null && strPtzxID.length() > 0) {
                        int nPtzxID = Integer.parseInt(strPtzxID);
                        DeviceAlarmRelecanceActivity.this.relevancePreset = nPtzxID;
                        if (nPtzxID <= 0) {
                            DeviceAlarmRelecanceActivity.this.tvAlarmDevicePreset.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecancePresetNot));
                            DeviceAlarmRelecanceActivity.this.relevancePreset = -1;
                            return;
                        }
                        DeviceAlarmRelecanceActivity.this.tvAlarmDevicePreset.setText(new StringBuilder(String.valueOf(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecancePresetNo))).append(nPtzxID + 1).toString());
                    }
                }
            }
        }

        public DeviceListViewAdapterAdd(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.alarm_relecance_add_item, null);
                this.holder = new ItemViewHolder();
                this.holder.tvAlarmRelecanceFigure = (TextView) convertView.findViewById(this.valueViewID[0]);
                this.holder.tvAlarmRelecanceAddress = (TextView) convertView.findViewById(this.valueViewID[1]);
                this.holder.ivAlarmRelecanceFunction = (Button) convertView.findViewById(this.valueViewID[2]);
                convertView.setTag(this.holder);
            }
            HashMap<String, Object> map = (HashMap) this.mAppList.get(position);
            int nID = Integer.parseInt(map.get("id")) + 1;
            String strAddress = map.get("device_address");
            String strEnable = map.get("alarm_enable");
            String strPtzxID = map.get("alarm_ptzxID");
            int nDeviceNum = Integer.parseInt(map.get("device_num"));
            this.holder.tvAlarmRelecanceFigure.setText(new StringBuilder(String.valueOf(nID)).toString());
            this.holder.tvAlarmRelecanceAddress.setText(strAddress);
            if (strEnable != null && strEnable.length() > 0) {
                int nEnable = Integer.parseInt(strEnable);
                DeviceAlarmRelecanceActivity.this.alarmOffOrOn = nEnable;
                if (nEnable == DeviceAlarmRelecanceActivity.ALARM_ON) {
                    DeviceAlarmRelecanceActivity.this.rBtnOff.setChecked(false);
                    DeviceAlarmRelecanceActivity.this.rBtnOn.setChecked(true);
                    DeviceAlarmRelecanceActivity.this.tvAlarmDeviceOffOrOn.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.record_record_open));
                } else {
                    DeviceAlarmRelecanceActivity.this.rBtnOff.setChecked(true);
                    DeviceAlarmRelecanceActivity.this.rBtnOn.setChecked(false);
                    DeviceAlarmRelecanceActivity.this.tvAlarmDeviceOffOrOn.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.record_record_close));
                }
            }
            if (nID == 0) {
                this.holder.ivAlarmRelecanceFunction.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceDeviceConfiguration));
                this.holder.ivAlarmRelecanceFunction.setBackgroundResource(C0470R.drawable.delete_save_btn);
            }
            this.holder.ivAlarmRelecanceFunction.setOnClickListener(new ListViewButtonListener(position, nDeviceNum, map));
            return convertView;
        }
    }

    private class FindAlarmDeviceThread extends Thread {
        byte[] buffer = new byte[412];
        private Handler handler;
        private int m_ThreadConfigID = 0;
        private String m_ThreadPassword = "admin";
        private int m_ThreadPort = 5050;
        private String m_ThreadServer = "123";
        private String m_ThreadUsername = "admin";
        private int m_nDeviceID = -1;
        private int m_nServerType = 101;
        private String m_strDomain;

        public FindAlarmDeviceThread(Handler handler, int configID, int nDeviceID, String domain, String server, int port, String username, String password, int nServerType) {
            this.m_ThreadConfigID = configID;
            this.handler = handler;
            this.m_ThreadServer = server;
            this.m_ThreadPort = port;
            this.m_ThreadUsername = username;
            this.m_ThreadPassword = password;
            this.m_nServerType = nServerType;
            this.m_nDeviceID = nDeviceID;
            this.m_strDomain = domain;
        }

        private int getFindAlarmDeviceInfoFromServer() {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            if (DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd != null && DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd.size() > 0) {
                DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd.clear();
            }
            if (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToServer(this.m_ThreadServer, this.m_ThreadPort, Defines.CMD_MR_WAIT);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    int i;
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) LocalDefines.NV_IP_ALARM_DEVICE_SEARCH_REQUEST, this.buffer, 0);
                    System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 4, this.m_ThreadUsername.getBytes().length);
                    System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 36, this.m_ThreadPassword.getBytes().length);
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, 68);
                    Functions.IntToBytes((long) 100, this.buffer, 72);
                    try {
                        writer.write(this.buffer, 0, 256);
                    } catch (IOException e5) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e6) {
                            e6.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    int num = 0;
                    for (i = 0; i < 960; i++) {
                        num++;
                        if (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID != this.m_ThreadConfigID) {
                            break;
                        }
                        if (num % 50 == 0) {
                            Arrays.fill(this.buffer, (byte) 0);
                            Functions.IntToBytes((long) LocalDefines.NV_IP_ALARM_DEVICE_SEARCH_REQUEST, this.buffer, 0);
                            System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 4, this.m_ThreadUsername.getBytes().length);
                            System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 36, this.m_ThreadPassword.getBytes().length);
                            Functions.IntToBytes((long) 100, this.buffer, 68);
                            Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, 72);
                            try {
                                writer.write(this.buffer, 0, 256);
                            } catch (IOException e7) {
                                try {
                                    writer.close();
                                    reader.close();
                                } catch (IOException e62) {
                                    e62.printStackTrace();
                                }
                                nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                            }
                        }
                        if (reader.available() >= 412) {
                            reader.read(this.buffer, 0, 412);
                            if (Functions.BytesToInt(this.buffer, 0) == 231) {
                                bReadOK = true;
                                break;
                            }
                            Arrays.fill(this.buffer, (byte) 0);
                        } else {
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e8) {
                                try {
                                    e8.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                    }
                    if (!bReadOK) {
                        try {
                            writer.write(this.buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e9) {
                            try {
                                writer.flush();
                                writer.close();
                                reader.close();
                            } catch (IOException e622) {
                                e622.printStackTrace();
                            }
                            nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                        }
                    } else if (Functions.BytesToInt(this.buffer, 0) == 231) {
                        Functions.changeMRParam(this.m_nDeviceID, false);
                        nConfigResultCode = 1001;
                        int nDeviceNum = this.buffer[4];
                        if (nDeviceNum > 0) {
                            int byteLenth = 5;
                            for (i = 0; i < nDeviceNum; i++) {
                                HashMap<String, Object> map = new HashMap();
                                int numID = this.buffer[byteLenth];
                                byteLenth++;
                                int len = 0;
                                while (len < 16 && ((char) this.buffer[byteLenth + len]) != '\u0000') {
                                    len++;
                                }
                                byte[] alarmDevice = new byte[len];
                                Arrays.fill(alarmDevice, (byte) 0);
                                System.arraycopy(this.buffer, byteLenth, alarmDevice, 0, len);
                                String strName = null;
                                try {
                                    strName = new String(alarmDevice, "GBK");
                                } catch (UnsupportedEncodingException e10) {
                                    e10.printStackTrace();
                                }
                                byteLenth += 16;
                                int deviceAddress = Functions.BytesToInt(this.buffer, byteLenth);
                                byteLenth += 4;
                                int alarmEnable = this.buffer[byteLenth];
                                byteLenth++;
                                int alarmType = this.buffer[byteLenth];
                                byteLenth++;
                                int alarmLevel = this.buffer[byteLenth];
                                byteLenth++;
                                int alarmptzxID = this.buffer[byteLenth];
                                byteLenth++;
                                map.put("id", Integer.valueOf(numID));
                                map.put("alarm_name", strName);
                                map.put("device_address", Integer.valueOf(deviceAddress));
                                map.put("alarm_enable", Integer.valueOf(alarmEnable));
                                map.put("alarm_type", Integer.valueOf(alarmType));
                                map.put("alarm_level", Integer.valueOf(alarmLevel));
                                map.put("alarm_ptzxID", Integer.valueOf(alarmptzxID));
                                map.put("device_num", Integer.valueOf(nDeviceNum));
                                DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd.add(map);
                            }
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e6222) {
                        e6222.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 257;
                    msg.arg2 = nConfigResultCode;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        private int getFindAlarmDeviceInfoFromMRServer(int deviceId) {
            OutputStream writer = null;
            InputStream reader = null;
            int nConfigResultCode = 0;
            if (DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd != null && DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd.size() > 0) {
                DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd.clear();
            }
            if (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID == this.m_ThreadConfigID) {
                Socket sSocket = Functions.connectToMRServer(null, 0, 5000, deviceId);
                if (sSocket == null) {
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                try {
                    if (sSocket.isConnected()) {
                        writer = sSocket.getOutputStream();
                        reader = sSocket.getInputStream();
                    } else {
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                } catch (IOException e) {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    if (writer != null) {
                        try {
                            writer.close();
                            writer.flush();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                if (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 0) {
                    Arrays.fill(this.buffer, (byte) 0);
                    Functions.IntToBytes((long) LocalDefines.NV_IP_ALARM_DEVICE_SEARCH_REQUEST, this.buffer, 0);
                    Functions.IntToBytes(1002, this.buffer, 4);
                    if (this.m_strDomain != null) {
                        System.arraycopy(this.m_strDomain.getBytes(), 0, this.buffer, 8, this.m_strDomain.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_ThreadPort, this.buffer, 58);
                    if (this.m_ThreadUsername != null) {
                        System.arraycopy(this.m_ThreadUsername.getBytes(), 0, this.buffer, 62, this.m_ThreadUsername.getBytes().length);
                    }
                    if (this.m_ThreadPassword != null) {
                        System.arraycopy(this.m_ThreadPassword.getBytes(), 0, this.buffer, 94, this.m_ThreadPassword.getBytes().length);
                    }
                    Functions.IntToBytes((long) this.m_nDeviceID, this.buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                    Functions.IntToBytes((long) 100, this.buffer, 130);
                    try {
                        writer.write(this.buffer, 0, 256);
                        writer.flush();
                    } catch (IOException e5) {
                        try {
                            writer.close();
                            reader.close();
                        } catch (IOException e6) {
                            e6.printStackTrace();
                        }
                        nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    }
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    int num = 0;
                    int i = 0;
                    while (i < 960) {
                        num++;
                        if (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID != this.m_ThreadConfigID || num > 50) {
                            break;
                        }
                        try {
                            if (reader.available() >= 412) {
                                reader.read(this.buffer, 0, 412);
                                if (Functions.BytesToInt(this.buffer, 0) == 231) {
                                    bReadOK = true;
                                    break;
                                }
                                Arrays.fill(this.buffer, (byte) 0);
                                num = 0;
                            } else {
                                try {
                                    Thread.sleep(200);
                                } catch (InterruptedException e7) {
                                    e7.printStackTrace();
                                }
                            }
                            i++;
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    if (bReadOK && Functions.BytesToInt(this.buffer, 0) == 231) {
                        Functions.changeMRParam(this.m_nDeviceID, true);
                        nConfigResultCode = 1001;
                        int nDeviceNum = this.buffer[4];
                        if (nDeviceNum > 0) {
                            int byteLenth = 5;
                            for (i = 0; i < nDeviceNum; i++) {
                                HashMap<String, Object> map = new HashMap();
                                int numID = this.buffer[byteLenth];
                                byteLenth++;
                                int len = 0;
                                while (len < 16 && ((char) this.buffer[byteLenth + len]) != '\u0000') {
                                    len++;
                                }
                                byte[] alarmDevice = new byte[len];
                                Arrays.fill(alarmDevice, (byte) 0);
                                System.arraycopy(this.buffer, byteLenth, alarmDevice, 0, len);
                                String strName = null;
                                try {
                                    strName = new String(alarmDevice, "GBK");
                                } catch (UnsupportedEncodingException e8) {
                                    e8.printStackTrace();
                                }
                                byteLenth += 16;
                                int deviceAddress = Functions.BytesToInt(this.buffer, byteLenth);
                                byteLenth += 4;
                                int alarmEnable = this.buffer[byteLenth];
                                byteLenth++;
                                int alarmType = this.buffer[byteLenth];
                                byteLenth++;
                                int alarmLevel = this.buffer[byteLenth];
                                byteLenth++;
                                int alarmptzxID = this.buffer[byteLenth];
                                byteLenth++;
                                map.put("id", Integer.valueOf(numID));
                                map.put("alarm_name", strName);
                                map.put("device_address", Integer.valueOf(deviceAddress));
                                map.put("alarm_enable", Integer.valueOf(alarmEnable));
                                map.put("alarm_type", Integer.valueOf(alarmType));
                                map.put("alarm_level", Integer.valueOf(alarmLevel));
                                map.put("alarm_ptzxID", Integer.valueOf(alarmptzxID));
                                map.put("device_num", Integer.valueOf(nDeviceNum));
                                DeviceAlarmRelecanceActivity.this.alarmDeviceListAdd.add(map);
                            }
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e62) {
                        e62.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
                if (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID == this.m_ThreadConfigID && nConfigResultCode == 1001) {
                    DeviceAlarmRelecanceActivity deviceAlarmRelecanceActivity = DeviceAlarmRelecanceActivity.this;
                    deviceAlarmRelecanceActivity.nFindAlarmDeviceID = deviceAlarmRelecanceActivity.nFindAlarmDeviceID + 1;
                    Message msg = this.handler.obtainMessage();
                    msg.arg1 = 257;
                    msg.arg2 = nConfigResultCode;
                    this.handler.sendMessage(msg);
                }
            }
            return nConfigResultCode;
        }

        public void run() {
            if (Functions.isMRMode(this.m_nDeviceID)) {
                while (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID == this.m_ThreadConfigID) {
                    int nConfigResult = getFindAlarmDeviceInfoFromMRServer(this.m_nDeviceID);
                    try {
                        sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                return;
            }
            nConfigResult = getFindAlarmDeviceInfoFromServer();
            if (nConfigResult == 0 || nConfigResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                while (DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID == this.m_ThreadConfigID) {
                    nConfigResult = getFindAlarmDeviceInfoFromMRServer(this.m_nDeviceID);
                    try {
                        sleep(500);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            } else if (nConfigResult != 1001 && DeviceAlarmRelecanceActivity.this.nFindAlarmDeviceID == this.m_ThreadConfigID) {
                Message msg = this.handler.obtainMessage();
                msg.arg1 = 257;
                msg.arg2 = nConfigResult;
                this.handler.sendMessage(msg);
            }
        }
    }

    private class PresetAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<String> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageView ivPresetImage;
            ImageView ivPresetSetImage;
            TextView tvPresetText;

            private ItemViewHolder() {
            }
        }

        public PresetAdapter(Context c, ArrayList<String> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.relecance_preset_count_item, null);
                this.holder = new ItemViewHolder();
                this.holder.ivPresetImage = (ImageView) convertView.findViewById(this.valueViewID[0]);
                this.holder.ivPresetSetImage = (ImageView) convertView.findViewById(this.valueViewID[1]);
                this.holder.tvPresetText = (TextView) convertView.findViewById(this.valueViewID[2]);
                convertView.setTag(this.holder);
            }
            this.holder.tvPresetText.setText(new StringBuilder(String.valueOf(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.preset))).append(position).toString());
            if (position == 0) {
                this.holder.ivPresetSetImage.setVisibility(8);
                this.holder.tvPresetText.setTextColor(-16776961);
                this.holder.tvPresetText.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecancePresetOff));
            } else {
                this.holder.ivPresetSetImage.setVisibility(0);
                this.holder.tvPresetText.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            }
            if (DeviceAlarmRelecanceActivity.this.relevancePreset + 1 == position) {
                this.holder.ivPresetSetImage.setImageResource(C0470R.drawable.play_back_choose_2);
                this.holder.tvPresetText.setTextColor(-16776961);
            } else {
                this.holder.ivPresetSetImage.setImageResource(C0470R.drawable.play_back_choose_1);
                this.holder.tvPresetText.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            }
            return convertView;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((NotificationManager) getSystemService("notification")).cancel(257);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_alarm_relecance_device);
        initView();
    }

    protected void onStart() {
        super.onStart();
        startAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.llRelecanceAlter.getVisibility() == 0 || this.llRelecanceAdd.getVisibility() == 0) {
                this.nAddAlarmDeviceID++;
                this.nAlterAlarmDeviceID++;
                this.nDeleteAlarmDeviceID++;
                this.nFindAlarmDeviceID++;
                if (this.bAlterDevice) {
                    startAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo);
                    this.bAlterDevice = false;
                }
                this.tvRelecanceAdd.setText(getString(C0470R.string.relecanceDeviceAdd));
                this.tvRelecance.setText(getString(C0470R.string.relecanceDeviceList));
                this.progressBarRelecance.setVisibility(8);
                this.llRelecanceAlter.setVisibility(8);
                this.llRelecanceAdd.setVisibility(8);
                this.btnRelecanceSave.setVisibility(8);
                this.rgAlarmDevice.setVisibility(8);
                this.rgAlarmDevice2.setVisibility(8);
                this.rgAlarmDeviceLevel.setVisibility(8);
                this.lvRelecance.setVisibility(0);
            } else {
                finish();
            }
        }
        return false;
    }

    private void initView() {
        this.btnRelecanceAlter = (Button) findViewById(C0470R.id.btnRelecanceAlter);
        this.btnRelecanceAlter.setOnClickListener(this);
        this.btnRelecanceDelete = (Button) findViewById(C0470R.id.btnRelecanceDelete);
        this.btnRelecanceDelete.setOnClickListener(this);
        this.btnRelecanceAdd = (Button) findViewById(C0470R.id.btnRelecanceAdd);
        this.btnRelecanceAdd.setOnClickListener(this);
        this.tvAlarmDeviceOffOrOn = (TextView) findViewById(C0470R.id.tvAlarmDeviceOffOrOn);
        this.tvAlarmDeviceOffOrOn.setOnClickListener(this);
        this.rgAlarmDeviceOffOrOn = (RadioGroup) findViewById(C0470R.id.rgAlarmDeviceOffOrOn);
        this.rBtnOff = (RadioButton) findViewById(C0470R.id.rBtnOff);
        this.rBtnOff.setOnClickListener(this);
        this.rBtnOn = (RadioButton) findViewById(C0470R.id.rBtnOn);
        this.rBtnOn.setOnClickListener(this);
        this.tvAlarmDevicePreset = (TextView) findViewById(C0470R.id.tvAlarmDevicePreset);
        this.tvAlarmDevicePreset.setOnClickListener(new C02962());
        this.ivAlarmDevicePreset = (ImageView) findViewById(C0470R.id.ivAlarmDevicePreset);
        this.tvPreset = (TextView) findViewById(C0470R.id.tvPreset);
        this.btnRelecance = (ImageView) findViewById(C0470R.id.btnRelecance);
        this.btnRelecance.setOnClickListener(this);
        this.tvRelecance = (TextView) findViewById(C0470R.id.tvRelecance);
        this.lvRelecance = (ListView) findViewById(C0470R.id.lvRelecance);
        this.llRelecanceAdd = (LinearLayout) findViewById(C0470R.id.llRelecanceAdd);
        this.tvRelecanceAdd = (TextView) findViewById(C0470R.id.tvRelecanceAdd);
        this.lvRelecanceAdd = (ListView) findViewById(C0470R.id.lvRelecanceAdd);
        this.llRelecanceAlter = (RelativeLayout) findViewById(C0470R.id.llRelecanceAlter);
        this.etAlarmDeviceName = (EditText) findViewById(C0470R.id.etAlarmDeviceName);
        this.tvAlarmDeviceAddress = (TextView) findViewById(C0470R.id.tvAlarmDeviceAddress);
        this.tvAlarmDeviceLevel = (TextView) findViewById(C0470R.id.tvAlarmDeviceLevel);
        this.tvAlarmDeviceLevel.setOnClickListener(this);
        this.rgAlarmDeviceLevel = (RadioGroup) findViewById(C0470R.id.rgAlarmDeviceLevel);
        this.rgAlarmDeviceLevel.setOnCheckedChangeListener(new C02973());
        this.rBtnHigh = (RadioButton) findViewById(C0470R.id.rBtnHigh);
        this.rBtnMedium = (RadioButton) findViewById(C0470R.id.rBtnMedium);
        this.rBtnLow = (RadioButton) findViewById(C0470R.id.rBtnLow);
        this.tvAlarmDeviceType = (TextView) findViewById(C0470R.id.tvAlarmDeviceType);
        this.tvAlarmDeviceType.setOnClickListener(new C02984());
        this.rgAlarmDevice = (RadioGroup) findViewById(C0470R.id.rgAlarmDevice);
        this.rBtnRKE = (RadioButton) findViewById(C0470R.id.rBtnRKE);
        this.rBtnRKE.setOnClickListener(this);
        this.rBtnSmoke = (RadioButton) findViewById(C0470R.id.rBtnSmoke);
        this.rBtnSmoke.setOnClickListener(this);
        this.rBtnFeeling = (RadioButton) findViewById(C0470R.id.rBtnFeeling);
        this.rBtnFeeling.setOnClickListener(this);
        this.rBtnGAS = (RadioButton) findViewById(C0470R.id.rBtnGAS);
        this.rBtnGAS.setOnClickListener(this);
        this.rBtnOther = (RadioButton) findViewById(C0470R.id.rBtnOther);
        this.rBtnOther.setOnClickListener(this);
        this.rgAlarmDevice2 = (RadioGroup) findViewById(C0470R.id.rgAlarmDevice2);
        this.btnRelecanceSave = (Button) findViewById(C0470R.id.btnRelecanceSave);
        this.btnRelecanceSave.setOnClickListener(this);
        this.progressBarRelecance = (ProgressBar) findViewById(C0470R.id.progressBarRelecance);
    }

    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case C0470R.id.btnRelecance:
                if (this.llRelecanceAlter.getVisibility() == 0 || this.llRelecanceAdd.getVisibility() == 0) {
                    this.nAddAlarmDeviceID++;
                    this.nAlterAlarmDeviceID++;
                    this.nDeleteAlarmDeviceID++;
                    this.nFindAlarmDeviceID++;
                    this.tvRelecanceAdd.setText(getString(C0470R.string.relecanceDeviceAdd));
                    this.tvRelecance.setText(getString(C0470R.string.relecanceDeviceList));
                    this.progressBarRelecance.setVisibility(8);
                    this.llRelecanceAlter.setVisibility(8);
                    this.llRelecanceAdd.setVisibility(8);
                    this.btnRelecanceSave.setVisibility(8);
                    this.rgAlarmDevice.setVisibility(8);
                    this.rgAlarmDevice2.setVisibility(8);
                    this.rgAlarmDeviceLevel.setVisibility(8);
                    this.rgAlarmDeviceOffOrOn.setVisibility(8);
                    this.lvRelecance.setVisibility(0);
                    if (this.bAlterDevice) {
                        startAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo);
                        this.bAlterDevice = false;
                        return;
                    }
                    return;
                }
                finish();
                return;
            case C0470R.id.btnRelecanceSave:
                if (this.bAddOrAlarm) {
                    addAlarmDevice();
                    return;
                } else {
                    alterAlarmDevice();
                    return;
                }
            case C0470R.id.tvAlarmDeviceOffOrOn:
                if (this.rgAlarmDeviceOffOrOn.getVisibility() == 0) {
                    this.rgAlarmDeviceOffOrOn.setVisibility(8);
                    return;
                }
                this.rgAlarmDeviceOffOrOn.setVisibility(0);
                this.rgAlarmDevice.setVisibility(8);
                this.rgAlarmDevice2.setVisibility(8);
                this.rgAlarmDeviceLevel.setVisibility(8);
                return;
            case C0470R.id.rBtnOn:
                this.rgAlarmDeviceOffOrOn.clearCheck();
                this.rBtnOn.setChecked(true);
                this.alarmOffOrOn = ALARM_ON;
                this.tvAlarmDeviceOffOrOn.setText(getString(C0470R.string.record_record_open));
                this.rgAlarmDeviceOffOrOn.setVisibility(8);
                return;
            case C0470R.id.rBtnOff:
                this.rgAlarmDeviceOffOrOn.clearCheck();
                this.rBtnOff.setChecked(true);
                this.alarmOffOrOn = ALARM_OFF;
                this.tvAlarmDeviceOffOrOn.setText(getString(C0470R.string.record_record_close));
                this.rgAlarmDeviceOffOrOn.setVisibility(8);
                return;
            case C0470R.id.tvAlarmDeviceLevel:
                if (this.rgAlarmDeviceLevel.getVisibility() == 0) {
                    this.rgAlarmDeviceLevel.setVisibility(8);
                    return;
                }
                this.rgAlarmDeviceLevel.setVisibility(0);
                this.rgAlarmDevice.setVisibility(8);
                this.rgAlarmDevice2.setVisibility(8);
                this.rgAlarmDeviceOffOrOn.setVisibility(8);
                return;
            case C0470R.id.tvAlarmDeviceType:
                if (this.rgAlarmDevice.getVisibility() == 0) {
                    this.rgAlarmDevice.setVisibility(8);
                    this.rgAlarmDevice2.setVisibility(8);
                    return;
                }
                this.rgAlarmDevice.setVisibility(0);
                this.rgAlarmDevice2.setVisibility(0);
                this.rgAlarmDeviceOffOrOn.setVisibility(8);
                this.rgAlarmDeviceLevel.setVisibility(8);
                return;
            case C0470R.id.rBtnRKE:
                this.rgAlarmDevice.clearCheck();
                this.rgAlarmDevice2.clearCheck();
                this.rBtnRKE.setChecked(true);
                this.alarmDeviceType = 1;
                this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceTypeRKE));
                this.rgAlarmDevice.setVisibility(8);
                this.rgAlarmDevice2.setVisibility(8);
                return;
            case C0470R.id.rBtnSmoke:
                this.rgAlarmDevice.clearCheck();
                this.rgAlarmDevice2.clearCheck();
                this.rBtnSmoke.setChecked(true);
                this.alarmDeviceType = 2;
                this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceTypeSmoke));
                this.rgAlarmDevice.setVisibility(8);
                this.rgAlarmDevice2.setVisibility(8);
                return;
            case C0470R.id.rBtnGAS:
                this.rgAlarmDevice.clearCheck();
                this.rgAlarmDevice2.clearCheck();
                this.rBtnGAS.setChecked(true);
                this.alarmDeviceType = 3;
                this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceGAS));
                this.rgAlarmDevice.setVisibility(8);
                this.rgAlarmDevice2.setVisibility(8);
                return;
            case C0470R.id.rBtnFeeling:
                this.rgAlarmDevice.clearCheck();
                this.rgAlarmDevice2.clearCheck();
                this.rBtnFeeling.setChecked(true);
                this.alarmDeviceType = 4;
                this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceFeeling));
                this.rgAlarmDevice.setVisibility(8);
                this.rgAlarmDevice2.setVisibility(8);
                return;
            case C0470R.id.rBtnOther:
                this.rgAlarmDevice.clearCheck();
                this.rgAlarmDevice2.clearCheck();
                this.rBtnOther.setChecked(true);
                this.alarmDeviceType = 0;
                this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceOther));
                this.rgAlarmDevice.setVisibility(8);
                this.rgAlarmDevice2.setVisibility(8);
                return;
            case C0470R.id.btnRelecanceAlter:
                alterAlarmDevice();
                return;
            case C0470R.id.btnRelecanceDelete:
                String strID = this.mapMessage.get("id");
                int nID = 0;
                if (strID != null && strID.length() > 0) {
                    nID = Integer.parseInt(strID);
                }
                String strAddress = this.mapMessage.get("device_address");
                int nAddress = 0;
                if (strAddress != null && strAddress.length() > 0) {
                    nAddress = Integer.parseInt(strAddress);
                }
                if (nAddress != 0) {
                    startDeleteAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo, nID, nAddress);
                    return;
                }
                return;
            case C0470R.id.btnRelecanceAdd:
                addAlarmDevice();
                return;
            default:
                return;
        }
    }

    private void alarmDeviceSelectList() {
        if (this.alarmDeviceList != null && this.alarmDeviceList.size() > 0) {
            DeviceListViewAdapter deviceListViewAdapter = new DeviceListViewAdapter(this, this.alarmDeviceList, C0470R.layout.alarm_relecance_device_select_item, new String[]{"ItemtvAlarmRelecanceFigure", "ItemtvAlarmRelecanceName", "ItemtvAlarmRelecanceAddress", "ItemivAlarmRelecanceFunction", "ItemivAlarmRelecanceState"}, new int[]{C0470R.id.tvAlarmRelecanceFigure, C0470R.id.tvAlarmRelecanceName, C0470R.id.tvAlarmRelecanceAddress, C0470R.id.ivAlarmRelecanceFunction, C0470R.id.ivAlarmRelecanceState});
            if (this.lvRelecance != null) {
                this.lvRelecance.setCacheColorHint(-1);
                this.lvRelecance.setAdapter(deviceListViewAdapter);
                this.lvRelecance.setOnItemClickListener(this);
                return;
            }
            this.lvRelecance = (ListView) findViewById(C0470R.id.lvRelecance);
        }
    }

    private void alarmDeviceAddList() {
        if (this.alarmDeviceListAdd != null && this.alarmDeviceListAdd.size() > 0) {
            DeviceListViewAdapterAdd deviceListViewAdapter = new DeviceListViewAdapterAdd(this, this.alarmDeviceListAdd, C0470R.layout.alarm_relecance_add_item, new String[]{"ItemtvAlarmRelecanceFigure", "ItemtvAlarmRelecanceAddress", "ItemivAlarmRelecanceFunction"}, new int[]{C0470R.id.tvAlarmRelecanceFigure, C0470R.id.tvAlarmRelecanceAddress, C0470R.id.ivAlarmRelecanceFunction});
            if (this.lvRelecanceAdd != null) {
                this.lvRelecanceAdd.setCacheColorHint(-1);
                this.lvRelecanceAdd.setAdapter(deviceListViewAdapter);
                this.lvRelecanceAdd.setOnItemClickListener(this);
                return;
            }
            this.lvRelecanceAdd = (ListView) findViewById(C0470R.id.lvRelecanceAdd);
            this.lvRelecanceAdd.setCacheColorHint(-1);
            this.lvRelecanceAdd.setAdapter(deviceListViewAdapter);
            this.lvRelecanceAdd.setOnItemClickListener(this);
        }
    }

    private void presetPopuwindow(View v, final int type) {
        View view = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.relecance_device_preset_popupwindow, null);
        this.lvPreset = (ListView) view.findViewById(C0470R.id.lvPreset);
        if (type == 122) {
            presetList();
        } else if (type == 121) {
            AlarmTypeList();
        }
        this.lvPreset.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
                if (type != 122) {
                    if (type == 121) {
                        DeviceAlarmRelecanceActivity.this.alarmDeviceType = arg2;
                        switch (arg2) {
                            case 0:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceOther));
                                break;
                            case 1:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceTypeRKE));
                                break;
                            case 2:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceTypeSmoke));
                                break;
                            case 3:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceGAS));
                                break;
                            case 4:
                                DeviceAlarmRelecanceActivity.this.tvAlarmDeviceType.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecanceFeeling));
                                break;
                            default:
                                break;
                        }
                    }
                }
                int num = arg2 - 1;
                DeviceAlarmRelecanceActivity.this.relevancePreset = num;
                if (num < 0) {
                    DeviceAlarmRelecanceActivity.this.tvAlarmDevicePreset.setText(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecancePresetNot));
                } else {
                    DeviceAlarmRelecanceActivity.this.tvAlarmDevicePreset.setText(new StringBuilder(String.valueOf(DeviceAlarmRelecanceActivity.this.getString(C0470R.string.relecancePresetNo))).append(arg2).toString());
                }
                if (DeviceAlarmRelecanceActivity.this.popupWindowMore != null) {
                    DeviceAlarmRelecanceActivity.this.popupWindowMore.dismiss();
                }
            }
        });
        float scale = getResources().getDisplayMetrics().density;
        this.popupWindowMore = new PopupWindow(view, (int) ((((float) 200) * scale) + 0.5f), (int) ((((float) Defines.PACKET_FLAG_END) * scale) + 0.5f));
        this.popupWindowMore.setFocusable(true);
        this.popupWindowMore.setOutsideTouchable(true);
        this.popupWindowMore.setBackgroundDrawable(new BitmapDrawable());
        this.popupWindowMore.setAnimationStyle(C0470R.style.popupwindow_relevance_anim);
        this.popupWindowMore.showAsDropDown(v);
    }

    private void presetList() {
        if (this.presetNum > 0) {
            ArrayList<String> listItem = new ArrayList();
            listItem.add(Constants.MAIN_VERSION_TAG);
            for (int i = 0; i < this.presetNum; i++) {
                listItem.add(Constants.MAIN_VERSION_TAG);
            }
            PresetAdapter presetAdapter = new PresetAdapter(this, listItem, C0470R.layout.relecance_preset_count_item, new String[]{"ItemPresetImage", "ItemPresetSetImage", "ItemPresetText"}, new int[]{C0470R.id.ivPresetImage, C0470R.id.ivPresetSetImage, C0470R.id.tvPresetText});
            if (this.lvPreset != null) {
                this.lvPreset.setCacheColorHint(0);
                this.lvPreset.setAdapter(presetAdapter);
                this.lvPreset.setOnItemClickListener(this);
            }
        }
    }

    private void AlarmTypeList() {
        ArrayList<String> listItemAlarm = new ArrayList();
        listItemAlarm.add(getString(C0470R.string.relecanceOther));
        listItemAlarm.add(getString(C0470R.string.relecanceTypeRKE));
        listItemAlarm.add(getString(C0470R.string.relecanceTypeSmoke));
        listItemAlarm.add(getString(C0470R.string.relecanceGAS));
        listItemAlarm.add(getString(C0470R.string.relecanceFeeling));
        AlarmTypeAdapter alarmAdapter = new AlarmTypeAdapter(this, listItemAlarm, C0470R.layout.relecance_preset_count_item, new String[]{"ItemPresetImage", "ItemPresetSetImage", "ItemPresetText"}, new int[]{C0470R.id.ivPresetImage, C0470R.id.ivPresetSetImage, C0470R.id.tvPresetText});
        if (this.lvPreset != null) {
            this.lvPreset.setCacheColorHint(0);
            this.lvPreset.setAdapter(alarmAdapter);
            this.lvPreset.setOnItemClickListener(this);
        }
    }

    private void alterAlarmDevice() {
        String strNewName = this.etAlarmDeviceName.getText();
        if (strNewName == null || strNewName.length() <= 0) {
            Toast.makeText(getApplication(), getString(C0470R.string.relecanceAlarmName), 0).show();
            return;
        }
        try {
            if (strNewName.getBytes("GBK").length > 16) {
                Toast.makeText(getApplication(), getString(C0470R.string.relecanceInputNameTooLong), 0).show();
                return;
            }
            this.mapMessage.put("alarm_name", strNewName);
            this.mapMessage.put("alarm_type", Integer.valueOf(this.alarmDeviceType));
            this.mapMessage.put("alarm_level", Integer.valueOf(this.alarmDeviceLevel));
            startAlterAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    private void addAlarmDevice() {
        String strNewName = this.etAlarmDeviceName.getText();
        if (strNewName == null || strNewName.length() <= 0) {
            Toast.makeText(getApplication(), getString(C0470R.string.relecanceAlarmName), 0).show();
            return;
        }
        try {
            if (strNewName.getBytes("GBK").length > 16) {
                Toast.makeText(getApplication(), getString(C0470R.string.relecanceInputNameTooLong), 0).show();
            } else {
                this.mapMessage.put("alarm_name", strNewName);
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        this.mapMessage.put("alarm_type", Integer.valueOf(this.alarmDeviceType));
        this.mapMessage.put("alarm_level", Integer.valueOf(this.alarmDeviceLevel));
        startAddAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo);
    }

    private void startAlarmDeviceThread(DeviceInfo deviceInfo) {
        this.progressBarRelecance.setVisibility(0);
        this.nAlarmDeviceID++;
        new AlarmDeviceThread(this.handler, this.nAlarmDeviceID, deviceInfo.getnDevID(), deviceInfo.getStrDomain(), deviceInfo.getStrIP(), deviceInfo.getnPort(), deviceInfo.getStrUsername(), deviceInfo.getStrPassword(), deviceInfo.getnSaveType()).start();
    }

    private void startFindAlarmDeviceThread(DeviceInfo deviceInfo) {
        this.progressBarRelecance.setVisibility(0);
        this.nFindAlarmDeviceID++;
        new FindAlarmDeviceThread(this.handler, this.nFindAlarmDeviceID, deviceInfo.getnDevID(), deviceInfo.getStrDomain(), deviceInfo.getStrIP(), deviceInfo.getnPort(), deviceInfo.getStrUsername(), deviceInfo.getStrPassword(), deviceInfo.getnSaveType()).start();
    }

    private void startAddAlarmDeviceThread(DeviceInfo deviceInfo) {
        this.progressBarRelecance.setVisibility(0);
        this.nAddAlarmDeviceID++;
        new AddAlarmDeviceThread(this.handler, this.nAlarmDeviceID, deviceInfo.getnDevID(), deviceInfo.getStrDomain(), deviceInfo.getStrIP(), deviceInfo.getnPort(), deviceInfo.getStrUsername(), deviceInfo.getStrPassword(), deviceInfo.getnSaveType()).start();
    }

    private void startAlterAlarmDeviceThread(DeviceInfo deviceInfo) {
        this.progressBarRelecance.setVisibility(0);
        this.nAlterAlarmDeviceID++;
        new AlterAlarmDeviceThread(this.handler, this.nAlarmDeviceID, deviceInfo.getnDevID(), deviceInfo.getStrDomain(), deviceInfo.getStrIP(), deviceInfo.getnPort(), deviceInfo.getStrUsername(), deviceInfo.getStrPassword(), deviceInfo.getnSaveType()).start();
    }

    private void startDeleteAlarmDeviceThread(DeviceInfo deviceInfo, int nAlarmID, int nAlarmAddress) {
        this.progressBarRelecance.setVisibility(0);
        this.nDeleteAlarmDeviceID++;
        new DeleteAlarmDeviceThread(this.handler, this.nDeleteAlarmDeviceID, nAlarmID, nAlarmAddress, deviceInfo.getnDevID(), deviceInfo.getStrDomain(), deviceInfo.getStrIP(), deviceInfo.getnPort(), deviceInfo.getStrUsername(), deviceInfo.getStrPassword(), deviceInfo.getnSaveType()).start();
    }

    public void onItemClick(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
        HashMap<String, Object> map = (HashMap) this.alarmDeviceList.get(arg2);
        if (Integer.parseInt(map.get("device_num")) > 0) {
            this.btnRelecanceAlter.setVisibility(0);
            this.btnRelecanceDelete.setVisibility(0);
            this.btnRelecanceAdd.setVisibility(8);
            this.mapMessage = map;
            this.bAddOrAlarm = false;
            this.llRelecanceAlter.setVisibility(0);
            this.llRelecanceAdd.setVisibility(8);
            this.lvRelecance.setVisibility(8);
            this.tvRelecance.setText(getString(C0470R.string.relecanceAlterDevice));
            String strName = map.get("alarm_name");
            if (strName != null && strName.length() > 0) {
                this.etAlarmDeviceName.setText(strName);
            }
            this.tvAlarmDeviceAddress.setText(map.get("device_address"));
            String strEnable = map.get("alarm_enable");
            if (strEnable != null && strEnable.length() > 0) {
                int nEnable = Integer.parseInt(strEnable);
                this.alarmOffOrOn = nEnable;
                if (nEnable == ALARM_OFF) {
                    this.rBtnOff.setChecked(true);
                    this.rBtnOn.setChecked(false);
                    this.tvAlarmDeviceOffOrOn.setText(getString(C0470R.string.record_record_close));
                } else {
                    this.rBtnOff.setChecked(false);
                    this.rBtnOn.setChecked(true);
                    this.tvAlarmDeviceOffOrOn.setText(getString(C0470R.string.record_record_open));
                }
            }
            String strLevel = map.get("alarm_level");
            if (strLevel != null && strLevel.length() > 0) {
                int nLevel = Integer.parseInt(strLevel);
                if (nLevel == 1) {
                    this.tvAlarmDeviceLevel.setText(getString(C0470R.string.relecanceLevelLow));
                    this.rBtnHigh.setChecked(false);
                    this.rBtnMedium.setChecked(false);
                    this.rBtnLow.setChecked(true);
                } else if (nLevel == 2) {
                    this.tvAlarmDeviceLevel.setText(getString(C0470R.string.relecanceLevelMedium));
                    this.rBtnHigh.setChecked(false);
                    this.rBtnMedium.setChecked(true);
                    this.rBtnLow.setChecked(false);
                } else if (nLevel == 3) {
                    this.tvAlarmDeviceLevel.setText(getString(C0470R.string.relecanceLevelHigh));
                    this.rBtnHigh.setChecked(true);
                    this.rBtnMedium.setChecked(false);
                    this.rBtnLow.setChecked(false);
                } else {
                    this.tvAlarmDeviceLevel.setText(getString(C0470R.string.relecanceAlarmLevel));
                    this.alarmDeviceLevel = 2;
                    this.rBtnHigh.setChecked(false);
                    this.rBtnMedium.setChecked(false);
                    this.rBtnLow.setChecked(false);
                }
            }
            String strType = map.get("alarm_type");
            if (strType != null && strType.length() > 0) {
                switch (Integer.parseInt(strType)) {
                    case 0:
                        this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceOther));
                        this.rBtnRKE.setChecked(false);
                        this.rBtnSmoke.setChecked(false);
                        this.rBtnFeeling.setChecked(false);
                        this.rBtnGAS.setChecked(false);
                        this.rBtnOther.setChecked(true);
                        break;
                    case 1:
                        this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceTypeRKE));
                        this.rBtnRKE.setChecked(true);
                        this.rBtnSmoke.setChecked(false);
                        this.rBtnFeeling.setChecked(false);
                        this.rBtnGAS.setChecked(false);
                        this.rBtnOther.setChecked(false);
                        break;
                    case 2:
                        this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceTypeSmoke));
                        this.rBtnRKE.setChecked(false);
                        this.rBtnSmoke.setChecked(true);
                        this.rBtnFeeling.setChecked(false);
                        this.rBtnGAS.setChecked(false);
                        this.rBtnOther.setChecked(false);
                        break;
                    case 3:
                        this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceGAS));
                        this.rBtnRKE.setChecked(false);
                        this.rBtnSmoke.setChecked(false);
                        this.rBtnFeeling.setChecked(false);
                        this.rBtnGAS.setChecked(true);
                        this.rBtnOther.setChecked(false);
                        break;
                    case 4:
                        this.tvAlarmDeviceType.setText(getString(C0470R.string.relecanceFeeling));
                        this.rBtnRKE.setChecked(false);
                        this.rBtnSmoke.setChecked(false);
                        this.rBtnFeeling.setChecked(true);
                        this.rBtnGAS.setChecked(false);
                        this.rBtnOther.setChecked(false);
                        break;
                }
            }
            String strPresetPermission = map.get("alarm_presetPermission");
            if (strPresetPermission != null && strPresetPermission.length() > 0) {
                if (Integer.parseInt(strPresetPermission) > 0) {
                    this.tvPreset.setVisibility(0);
                    this.tvAlarmDevicePreset.setVisibility(0);
                    this.ivAlarmDevicePreset.setVisibility(0);
                } else {
                    this.tvPreset.setVisibility(8);
                    this.tvAlarmDevicePreset.setVisibility(8);
                    this.ivAlarmDevicePreset.setVisibility(8);
                }
                String strPresetNum = map.get("alarm_presetNum");
                if (strPresetNum != null && strPresetNum.length() > 0) {
                    this.presetNum = Integer.parseInt(strPresetNum);
                }
            }
            String strPtzxID = map.get("alarm_ptzxID");
            if (strPtzxID != null && strPtzxID.length() > 0) {
                int nPtzxID = Integer.parseInt(strPtzxID);
                this.relevancePreset = nPtzxID;
                if (nPtzxID < 0) {
                    this.tvAlarmDevicePreset.setText(getString(C0470R.string.relecancePresetNot));
                    return;
                } else {
                    this.tvAlarmDevicePreset.setText(getString(C0470R.string.relecancePresetNo) + (nPtzxID + 1));
                    return;
                }
            }
            return;
        }
        this.llRelecanceAlter.setVisibility(8);
        this.llRelecanceAdd.setVisibility(0);
        this.tvRelecanceAdd.setVisibility(0);
        this.lvRelecance.setVisibility(8);
        this.tvRelecance.setText(getString(C0470R.string.relecanceSeekDevice));
        startFindAlarmDeviceThread(LocalDefines.alarmRelecanceDeviceInfo);
    }
}
