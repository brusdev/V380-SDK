package com.macrovideo.v380;

public final class BuildConfig {
    public static final boolean DEBUG = true;
}
