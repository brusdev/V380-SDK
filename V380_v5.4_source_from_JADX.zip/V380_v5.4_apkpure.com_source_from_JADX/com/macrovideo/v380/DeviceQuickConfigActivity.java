package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.internal.view.SupportMenu;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.animate.RadarView;
import com.macrovideo.httptool.HttpUtils;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.setting.DeviceNetwordSetting;
import com.macrovideo.sdk.setting.NetwordInfo;
import com.macrovideo.sdk.tools.DeviceScanner;
import com.macrovideo.xingepush.RegistClientWithDeviceArrayToServer;
import com.tencent.android.tpush.common.Constants;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class DeviceQuickConfigActivity extends Activity implements OnClickListener {
    static final int HANDLE_MSG_CONFIG_FINISH = 4371;
    static final int HANDLE_MSG_CONNECT_WIFI = 4372;
    static final int HANDLE_MSG_DEVICE_MSG_ID = 4373;
    static final int HANDLE_MSG_FRESH_LIST = 4369;
    static final int HANDLE_MSG_WIFI_CONNECT_SUCCEED = 4370;
    private static final int PAGE_INDEX_DEVICE_SELECT = 100;
    private static final int PAGE_INDEX_WIFI_SELECT = 101;
    private int _nThreadID = 0;
    boolean bDevice = false;
    private boolean bWifiOPen = false;
    private int bindDevice_result;
    private ImageView btBack;
    private Button btnConfigWifi;
    private Button btnWifiDeviceRefresh;
    private EditText etDialogWifiPasword = null;
    private EditText etWifiConfigName;
    private EditText etWifiConfigPassword;
    @SuppressLint({"DefaultLocale"})
    private Handler handler = new C03291();
    private boolean isPasswordVisible = true;
    private LinearLayout layoutDeviceSelectView = null;
    private LinearLayout layoutIndecationView = null;
    private LinearLayout layoutSettingView = null;
    private LinearLayout layoutWifiSelectView = null;
    private ArrayList<DeviceInfo> listInfo = null;
    private LinearLayout llSeekDevice;
    private List<ScanResult> localWifiList = new ArrayList();
    private ListView lvDeviceListView;
    private ListView lvWifiListView;
    private String mBSSID = null;
    private NetwordInfo mNetworkConfig = new NetwordInfo();
    private WiFiAdnim mWiFiAdnim;
    private WifiManager mWiFiManager;
    private WifiInfo mWifiInfo;
    private int m_nNetworkConfigID = 0;
    private int m_nThreadDeviceMsg = 0;
    private List<ScanResult> mvDeviceList = new ArrayList();
    private WifiReceiver mwReceiver;
    private int nDeviceEnrcrypt = 1;
    private int nDeviceID = 0;
    private int nPageIndex = 100;
    private int nStationWifiEnrcrypt = 1;
    private int n_BindDeviceThreadID = 0;
    private View passwordInputConctentView = null;
    private Dialog passwordInputDialog;
    private PopupWindow popupWindow;
    private ProgressBar progressBarQuickConfig;
    private ProgressDialog progressDialogOpenWifi;
    private ProgressDialog progressDialogWifi;
    private RadarView rvQuickConfigSearchingRadar;
    private RelativeLayout ryWifiPassword = null;
    private DeviceInfo serverInfo;
    private MediaPlayer soundPlayer = null;
    private String strDevicePassword = null;
    private String strDeviceSSID;
    private String strStationWifiName = null;
    private String strStationWifiPassword = null;
    Hashtable<String, DeviceInfo> tableSearchResult = new Hashtable();
    private TextView tvDialogWifiName = null;
    private TextView tvHint;
    private TextView tvSeekDevice;
    private TextView tvTitle;
    private EditText tvWifiConfigPasswordFree = null;
    private ImageView wifiCheckBoxPwdHiden;

    class C03291 extends Handler {
        C03291() {
        }

        public void handleMessage(Message msg) {
            DeviceInfo info;
            DeviceQuickConfigActivity deviceQuickConfigActivity;
            if (msg.arg1 == DeviceQuickConfigActivity.HANDLE_MSG_CONNECT_WIFI) {
                DeviceQuickConfigActivity.this.connectToAPDevice(DeviceQuickConfigActivity.this.strStationWifiName, DeviceQuickConfigActivity.this.strStationWifiPassword, DeviceQuickConfigActivity.this.nStationWifiEnrcrypt);
            } else if (msg.arg1 == DeviceQuickConfigActivity.HANDLE_MSG_CONFIG_FINISH) {
                DeviceQuickConfigActivity.this.btnConfigWifi.setEnabled(true);
                DeviceQuickConfigActivity.this.soundPlayer.stop();
                if (msg.arg2 == 1) {
                    info = (DeviceInfo) DeviceQuickConfigActivity.this.tableSearchResult.get(DeviceQuickConfigActivity.this.nDeviceID);
                    if (HomePageActivity.AppMode != 1) {
                        if (DatabaseManager.IsInfoExist(info)) {
                            System.out.println("����ģʽ�¸���ap�豸");
                            DeviceQuickConfigActivity.this.bDevice = true;
                            if (info.getIsAlarmOn() == 0) {
                                DatabaseManager.UpdateServerInfoState(info);
                            } else {
                                DatabaseManager.UpdateServerInfoStateWithAlarmState(info);
                            }
                        } else {
                            System.out.println("����ģʽ�����ap�豸");
                            DeviceQuickConfigActivity.this.bDevice = true;
                            DatabaseManager.AddServerInfo(info);
                        }
                        if (DeviceQuickConfigActivity.this.bDevice) {
                            DeviceQuickConfigActivity.this.llSeekDevice.setVisibility(0);
                            DeviceQuickConfigActivity.this.tvSeekDevice.setText(info.getnDevID());
                            LocalDefines.reloadDeviceInfoList();
                            LocalDefines.isDeviceListSet = false;
                            LocalDefines.nClientDeviceSettingThreadID++;
                            new RegistClientWithDeviceArrayToServer((Handler) this, LocalDefines.nClientDeviceSettingThreadID).start();
                        }
                        deviceQuickConfigActivity = DeviceQuickConfigActivity.this;
                        deviceQuickConfigActivity.m_nThreadDeviceMsg = deviceQuickConfigActivity.m_nThreadDeviceMsg + 1;
                        new ThreadDieviceMsg(DeviceQuickConfigActivity.this.m_nThreadDeviceMsg).start();
                    } else if (DatabaseManager.IsInfoExist(info)) {
                        DeviceQuickConfigActivity.this.bDevice = true;
                        if (info.getIsAlarmOn() == 0) {
                            DatabaseManager.UpdateServerInfoState(info);
                        } else {
                            DatabaseManager.UpdateServerInfoStateWithAlarmState(info);
                        }
                        if (DeviceQuickConfigActivity.this.bDevice) {
                            DeviceQuickConfigActivity.this.llSeekDevice.setVisibility(0);
                            DeviceQuickConfigActivity.this.tvSeekDevice.setText(info.getnDevID());
                            LocalDefines.reloadDeviceInfoList();
                            LocalDefines.isDeviceListSet = false;
                            LocalDefines.nClientDeviceSettingThreadID++;
                            new RegistClientWithDeviceArrayToServer((Handler) this, LocalDefines.nClientDeviceSettingThreadID).start();
                        }
                        deviceQuickConfigActivity = DeviceQuickConfigActivity.this;
                        deviceQuickConfigActivity.m_nThreadDeviceMsg = deviceQuickConfigActivity.m_nThreadDeviceMsg + 1;
                        new ThreadDieviceMsg(DeviceQuickConfigActivity.this.m_nThreadDeviceMsg).start();
                    } else {
                        DeviceQuickConfigActivity.this.bDevice = true;
                        DeviceQuickConfigActivity.this.StartBindDeviceThread(info.getnDevID(), info.getStrUsername(), Base64.encodeToString(info.getStrPassword().getBytes(), 0), info, 1);
                    }
                } else if (msg.arg2 == ResultCode.RESULT_CODE_FAIL_PWD_ERROR) {
                    String Msg = DeviceQuickConfigActivity.this.getString(C0470R.string.notice_Result_PWDError);
                    String Title = DeviceQuickConfigActivity.this.getString(C0470R.string.snartLinkFailTitle);
                    DeviceQuickConfigActivity.this.hideConfigIndicatorView();
                    DeviceQuickConfigActivity.this.rvQuickConfigSearchingRadar.stopAnimate();
                    DeviceQuickConfigActivity.this.ShowAlert(Title, Msg);
                } else {
                    DeviceQuickConfigActivity.this.hideConfigIndicatorView();
                    DeviceQuickConfigActivity.this.rvQuickConfigSearchingRadar.stopAnimate();
                }
            } else if (msg.arg1 == DeviceQuickConfigActivity.HANDLE_MSG_WIFI_CONNECT_SUCCEED) {
                if (DeviceQuickConfigActivity.this.progressDialogWifi != null) {
                    DeviceQuickConfigActivity.this.progressDialogWifi.dismiss();
                }
                DeviceQuickConfigActivity.this.ShowWifiSelectView();
            } else if (msg.arg1 == DeviceQuickConfigActivity.HANDLE_MSG_FRESH_LIST) {
                DeviceQuickConfigActivity.this.progressBarQuickConfig.setVisibility(8);
                if (DeviceQuickConfigActivity.this.progressDialogOpenWifi != null) {
                    DeviceQuickConfigActivity.this.progressDialogOpenWifi.dismiss();
                }
                DeviceQuickConfigActivity.this.bWifiOPen = true;
                DeviceQuickConfigActivity.this.updateDeviceListView();
                DeviceQuickConfigActivity.this.updateWifiListView();
            }
            if (msg.arg1 == DeviceQuickConfigActivity.HANDLE_MSG_DEVICE_MSG_ID) {
                DeviceQuickConfigActivity.this.backToList();
            }
            if (msg.arg1 == LocalDefines.BIND_DEVICE_RESULT_CODE) {
                info = (DeviceInfo) msg.getData().getParcelable("Bind_info");
                if (msg.arg2 == 0) {
                    DatabaseManager.AddServerInfo(info);
                    DeviceQuickConfigActivity.this.bDevice = true;
                    if (DeviceQuickConfigActivity.this.bDevice) {
                        DeviceQuickConfigActivity.this.llSeekDevice.setVisibility(0);
                        DeviceQuickConfigActivity.this.tvSeekDevice.setText(info.getnDevID());
                        LocalDefines.reloadDeviceInfoList();
                        LocalDefines.isDeviceListSet = false;
                        LocalDefines.nClientDeviceSettingThreadID++;
                        new RegistClientWithDeviceArrayToServer((Handler) this, LocalDefines.nClientDeviceSettingThreadID).start();
                    }
                    deviceQuickConfigActivity = DeviceQuickConfigActivity.this;
                    deviceQuickConfigActivity.m_nThreadDeviceMsg = deviceQuickConfigActivity.m_nThreadDeviceMsg + 1;
                    new ThreadDieviceMsg(DeviceQuickConfigActivity.this.m_nThreadDeviceMsg).start();
                } else if (msg.arg2 == 401) {
                    Toast.makeText(DeviceQuickConfigActivity.this, DeviceQuickConfigActivity.this.getString(C0470R.string.str_ap_bind401), 0).show();
                    DeviceQuickConfigActivity.this.httpResult401();
                } else if (msg.arg2 == 500) {
                    Toast.makeText(DeviceQuickConfigActivity.this, DeviceQuickConfigActivity.this.getString(C0470R.string.str_ap_bind500), 0).show();
                    deviceQuickConfigActivity = DeviceQuickConfigActivity.this;
                    deviceQuickConfigActivity.m_nThreadDeviceMsg = deviceQuickConfigActivity.m_nThreadDeviceMsg + 1;
                    new ThreadDieviceMsg(DeviceQuickConfigActivity.this.m_nThreadDeviceMsg).start();
                } else if (msg.arg2 == -1) {
                    Toast.makeText(DeviceQuickConfigActivity.this, C0470R.string.str_ap_bind_network_error, 0).show();
                    deviceQuickConfigActivity = DeviceQuickConfigActivity.this;
                    deviceQuickConfigActivity.m_nThreadDeviceMsg = deviceQuickConfigActivity.m_nThreadDeviceMsg + 1;
                    new ThreadDieviceMsg(DeviceQuickConfigActivity.this.m_nThreadDeviceMsg).start();
                } else {
                    Toast.makeText(DeviceQuickConfigActivity.this, C0470R.string.str_ap_bind_other_error, 0).show();
                    deviceQuickConfigActivity = DeviceQuickConfigActivity.this;
                    deviceQuickConfigActivity.m_nThreadDeviceMsg = deviceQuickConfigActivity.m_nThreadDeviceMsg + 1;
                    new ThreadDieviceMsg(DeviceQuickConfigActivity.this.m_nThreadDeviceMsg).start();
                }
            }
        }
    }

    class C03302 implements OnShowListener {
        C03302() {
        }

        public void onShow(DialogInterface dialog) {
            DeviceQuickConfigActivity.this.onPasswordInputDialogShow();
        }
    }

    class C03313 implements OnClickListener {
        C03313() {
        }

        public void onClick(View arg0) {
            DeviceQuickConfigActivity.this.strDevicePassword = DeviceQuickConfigActivity.this.etDialogWifiPasword.getText().toString();
            if (DeviceQuickConfigActivity.this.strDevicePassword != null && DeviceQuickConfigActivity.this.strDevicePassword.length() > 0) {
                if (DeviceQuickConfigActivity.this.passwordInputDialog != null) {
                    DeviceQuickConfigActivity.this.passwordInputDialog.dismiss();
                }
                DeviceQuickConfigActivity.this.connectToAPDevice(DeviceQuickConfigActivity.this.strDeviceSSID, DeviceQuickConfigActivity.this.etDialogWifiPasword.getText().toString().trim(), DeviceQuickConfigActivity.this.nDeviceEnrcrypt);
                DeviceQuickConfigActivity.this.StartMonitor();
                DeviceQuickConfigActivity.this.progressDialogWifi.setProgressStyle(0);
                DeviceQuickConfigActivity.this.progressDialogWifi.setCanceledOnTouchOutside(false);
                DeviceQuickConfigActivity.this.progressDialogWifi.setMessage(DeviceQuickConfigActivity.this.getString(C0470R.string.connect_device));
                DeviceQuickConfigActivity.this.progressDialogWifi.show();
            }
        }
    }

    class C03324 implements OnClickListener {
        C03324() {
        }

        public void onClick(View arg0) {
            if (DeviceQuickConfigActivity.this.passwordInputDialog != null) {
                DeviceQuickConfigActivity.this.passwordInputDialog.dismiss();
            }
        }
    }

    class C03335 implements OnClickListener {
        C03335() {
        }

        public void onClick(View arg0) {
            if (DeviceQuickConfigActivity.this.isPasswordVisible) {
                DeviceQuickConfigActivity.this.isPasswordVisible = false;
                DeviceQuickConfigActivity.this.etWifiConfigPassword.setInputType(144);
                DeviceQuickConfigActivity.this.wifiCheckBoxPwdHiden.setImageResource(C0470R.drawable.netword_show_password);
                return;
            }
            DeviceQuickConfigActivity.this.isPasswordVisible = true;
            DeviceQuickConfigActivity.this.etWifiConfigPassword.setInputType(Defines.NV_IP_PTZX_REQUEST);
            DeviceQuickConfigActivity.this.wifiCheckBoxPwdHiden.setImageResource(C0470R.drawable.netword_hide);
        }
    }

    class C03346 implements DialogInterface.OnClickListener {
        C03346() {
        }

        public void onClick(DialogInterface dialog, int which) {
            DeviceQuickConfigActivity.this.mWiFiAdnim.openWifi();
            DeviceQuickConfigActivity.this.tvTitle.setText(DeviceQuickConfigActivity.this.getString(C0470R.string.btn_serverList));
            if (!DeviceQuickConfigActivity.this.bWifiOPen) {
                DeviceQuickConfigActivity.this.progressDialogOpenWifi.show();
            }
        }
    }

    class C03357 implements DialogInterface.OnClickListener {
        C03357() {
        }

        public void onClick(DialogInterface dialog, int which) {
        }
    }

    class C03368 implements OnItemClickListener {
        C03368() {
        }

        public void onItemClick(AdapterView<?> adapterView, View arg1, int index, long arg3) {
            if (DeviceQuickConfigActivity.this.localWifiList != null && DeviceQuickConfigActivity.this.localWifiList.size() > 0 && index >= 0 && index < DeviceQuickConfigActivity.this.localWifiList.size()) {
                ScanResult scanResult = (ScanResult) DeviceQuickConfigActivity.this.localWifiList.get(index);
                if (scanResult != null) {
                    DeviceQuickConfigActivity.this.etWifiConfigName.setText(scanResult.SSID);
                    Log.e("dqx", "scanResult.BSSID = " + scanResult.BSSID);
                    DeviceQuickConfigActivity.this.mBSSID = scanResult.BSSID;
                    DeviceQuickConfigActivity.this.etWifiConfigPassword.setText(null);
                    DeviceQuickConfigActivity.this.nStationWifiEnrcrypt = DeviceQuickConfigActivity.this.encryCodeOfCapabilities(scanResult.capabilities);
                    if (DeviceQuickConfigActivity.this.nStationWifiEnrcrypt == 1) {
                        DeviceQuickConfigActivity.this.ryWifiPassword.setVisibility(8);
                        DeviceQuickConfigActivity.this.tvWifiConfigPasswordFree.setVisibility(0);
                        return;
                    }
                    DeviceQuickConfigActivity.this.ryWifiPassword.setVisibility(0);
                    DeviceQuickConfigActivity.this.tvWifiConfigPasswordFree.setVisibility(8);
                }
            }
        }
    }

    class C03379 implements OnItemClickListener {
        C03379() {
        }

        public void onItemClick(AdapterView<?> adapterView, View arg1, int index, long arg3) {
            DeviceQuickConfigActivity.this.mWiFiManager = (WifiManager) DeviceQuickConfigActivity.this.getSystemService("wifi");
            if (DeviceQuickConfigActivity.this.mWiFiManager.getWifiState() != 3) {
                Toast.makeText(DeviceQuickConfigActivity.this, DeviceQuickConfigActivity.this.getString(C0470R.string.deviceWifiOpenFail), 0).show();
            } else if (DeviceQuickConfigActivity.this.mvDeviceList != null && DeviceQuickConfigActivity.this.mvDeviceList.size() > 0 && index >= 0 && index < DeviceQuickConfigActivity.this.mvDeviceList.size()) {
                ScanResult scanResult = (ScanResult) DeviceQuickConfigActivity.this.mvDeviceList.get(index);
                if (scanResult != null) {
                    DeviceQuickConfigActivity.this.strDeviceSSID = scanResult.SSID;
                    DeviceQuickConfigActivity.this.nDeviceEnrcrypt = DeviceQuickConfigActivity.this.encryCodeOfCapabilities(scanResult.capabilities);
                    if (DeviceQuickConfigActivity.this.nDeviceEnrcrypt == 1) {
                        DeviceQuickConfigActivity.this.connectToAPDevice(DeviceQuickConfigActivity.this.strDeviceSSID, Constants.MAIN_VERSION_TAG, DeviceQuickConfigActivity.this.nDeviceEnrcrypt);
                        DeviceQuickConfigActivity.this.StartMonitor();
                        DeviceQuickConfigActivity.this.progressDialogWifi.setProgressStyle(0);
                        DeviceQuickConfigActivity.this.progressDialogWifi.setCanceledOnTouchOutside(false);
                        DeviceQuickConfigActivity.this.progressDialogWifi.setMessage(DeviceQuickConfigActivity.this.getString(C0470R.string.connect_device));
                        DeviceQuickConfigActivity.this.progressDialogWifi.show();
                    } else if (DeviceQuickConfigActivity.this.passwordInputDialog != null) {
                        DeviceQuickConfigActivity.this.passwordInputDialog.show();
                    }
                }
            }
        }
    }

    class BindDeviceThread extends Thread {
        private Handler handler;
        private DeviceInfo info;
        private int infoIndex;
        private int m_BindDeviceThreadID;
        private int m_DeviceId;
        private String m_DeviceName;
        private String m_DevicePassword;

        public BindDeviceThread(int BindDeviceThreadID, String DeviceName, String DevicePassword, Handler handler, int DeviceId, DeviceInfo info, int infoIndex) {
            this.m_BindDeviceThreadID = BindDeviceThreadID;
            this.handler = handler;
            this.m_DeviceId = DeviceId;
            this.m_DeviceName = DeviceName;
            this.m_DevicePassword = DevicePassword;
            this.info = info;
            this.infoIndex = infoIndex;
        }

        public void run() {
            super.run();
            if (this.m_BindDeviceThreadID == DeviceQuickConfigActivity.this.n_BindDeviceThreadID) {
                try {
                    DeviceQuickConfigActivity.this.postBindDeviceData(this.m_DeviceId, this.m_DeviceName, this.m_DevicePassword, this.info, this.infoIndex);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = LocalDefines.BIND_DEVICE_RESULT_CODE;
            msg.arg2 = DeviceQuickConfigActivity.this.bindDevice_result;
            Bundle data = new Bundle();
            data.putParcelable("Bind_info", this.info);
            data.putInt("Bind_index", this.infoIndex);
            msg.setData(data);
            this.handler.sendMessage(msg);
        }
    }

    private class DeviceListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageView ivQuickConfigLogo;
            TextView tvName;

            private ItemViewHolder() {
            }
        }

        public DeviceListViewAdapter(Context c, int resource, String[] from, int[] to) {
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return DeviceQuickConfigActivity.this.mvDeviceList.size();
        }

        public Object getItem(int position) {
            return DeviceQuickConfigActivity.this.mvDeviceList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.quick_config_item, null);
                this.holder = new ItemViewHolder();
                this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[0]);
                this.holder.ivQuickConfigLogo = (ImageView) convertView.findViewById(this.valueViewID[1]);
                convertView.setTag(this.holder);
            }
            ScanResult scanResult = (ScanResult) DeviceQuickConfigActivity.this.mvDeviceList.get(position);
            if (scanResult != null) {
                this.holder.tvName.setText(scanResult.SSID);
                this.holder.ivQuickConfigLogo.setVisibility(0);
            }
            return convertView;
        }
    }

    private class NetWorkConfigThread extends Thread {
        private Handler handler;
        DeviceInfo info = null;
        private int m_ThreadConfigID = 0;
        int m_nMode = 1002;
        String m_strWifiName = null;
        String m_strWifiPassword = null;
        private String strBSSID = null;

        public NetWorkConfigThread(Handler handler, int configID, int nWifiMode, String strWifiName, String strWifiPassword, DeviceInfo info, String strBSSID) {
            this.m_ThreadConfigID = configID;
            this.handler = handler;
            this.info = info;
            this.m_nMode = nWifiMode;
            this.m_strWifiName = strWifiName;
            this.m_strWifiPassword = strWifiPassword;
            this.strBSSID = strBSSID;
        }

        public void run() {
            while (DeviceQuickConfigActivity.this.m_nNetworkConfigID == this.m_ThreadConfigID && !DeviceQuickConfigActivity.this.isApConnect()) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            NetwordInfo deviceParam = null;
            int i = 0;
            while (i < 3) {
                Message msg;
                deviceParam = DeviceNetwordSetting.setNetwordWithBSSID(this.info, this.m_nMode, this.m_strWifiName, this.m_strWifiPassword, this.strBSSID);
                if (deviceParam == null || deviceParam.getnResult() != 256 || DeviceQuickConfigActivity.this.m_nNetworkConfigID != this.m_ThreadConfigID) {
                    if (deviceParam != null && deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_PWD_ERROR && DeviceQuickConfigActivity.this.m_nNetworkConfigID == this.m_ThreadConfigID) {
                        msg = this.handler.obtainMessage();
                        msg.arg1 = DeviceQuickConfigActivity.HANDLE_MSG_CONFIG_FINISH;
                        msg.arg2 = deviceParam.getnResult();
                        this.handler.sendMessage(msg);
                        break;
                    }
                    i++;
                } else {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = DeviceQuickConfigActivity.HANDLE_MSG_CONNECT_WIFI;
                    msg.arg2 = deviceParam.getnResult();
                    Bundle data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    this.handler.sendMessage(msg);
                    break;
                }
            }
            if (deviceParam.getnResult() == 256 && DeviceQuickConfigActivity.this.m_nNetworkConfigID == this.m_ThreadConfigID) {
                if (DeviceQuickConfigActivity.this.m_nNetworkConfigID == this.m_ThreadConfigID) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = DeviceQuickConfigActivity.HANDLE_MSG_CONNECT_WIFI;
                    msg.arg2 = deviceParam.getnResult();
                    this.handler.sendMessage(msg);
                }
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
                while (DeviceQuickConfigActivity.this.m_nNetworkConfigID == this.m_ThreadConfigID && !DeviceQuickConfigActivity.this.isWIFIConnect()) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e22) {
                        e22.printStackTrace();
                    }
                }
                boolean bSearchresult = false;
                while (DeviceQuickConfigActivity.this.m_nNetworkConfigID == this.m_ThreadConfigID) {
                    DeviceQuickConfigActivity.this.listInfo = DeviceScanner.getDeviceListFromLan();
                    if (DeviceQuickConfigActivity.this.listInfo != null && DeviceQuickConfigActivity.this.listInfo.size() > 0) {
                        for (i = 0; i < DeviceQuickConfigActivity.this.listInfo.size(); i++) {
                            int nDeviceID = ((DeviceInfo) DeviceQuickConfigActivity.this.listInfo.get(i)).getnDevID();
                            if (nDeviceID == this.info.getnDevID()) {
                                DeviceQuickConfigActivity.this.tableSearchResult.put(nDeviceID, (DeviceInfo) DeviceQuickConfigActivity.this.listInfo.get(i));
                                bSearchresult = true;
                                continue;
                                break;
                            }
                        }
                        continue;
                    }
                    if (bSearchresult) {
                        break;
                    }
                }
                int nConfigResult = 0;
                if (bSearchresult) {
                    nConfigResult = 1;
                }
                if (DeviceQuickConfigActivity.this.m_nNetworkConfigID == this.m_ThreadConfigID) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = DeviceQuickConfigActivity.HANDLE_MSG_CONFIG_FINISH;
                    msg.arg2 = nConfigResult;
                    this.handler.sendMessage(msg);
                }
            } else if (DeviceQuickConfigActivity.this.m_nNetworkConfigID == this.m_ThreadConfigID) {
                msg = this.handler.obtainMessage();
                msg.arg1 = DeviceQuickConfigActivity.HANDLE_MSG_CONFIG_FINISH;
                msg.arg2 = 0;
                this.handler.sendMessage(msg);
            }
        }
    }

    public class ThreadDieviceMsg extends Thread {
        private int nThreadDeviceMsg = 0;

        public ThreadDieviceMsg(int nThreadDeviceMsg) {
            this.nThreadDeviceMsg = nThreadDeviceMsg;
        }

        public void run() {
            try {
                sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (DeviceQuickConfigActivity.this.m_nThreadDeviceMsg == this.nThreadDeviceMsg) {
                Message msg = DeviceQuickConfigActivity.this.handler.obtainMessage();
                msg.arg1 = DeviceQuickConfigActivity.HANDLE_MSG_DEVICE_MSG_ID;
                DeviceQuickConfigActivity.this.handler.sendMessage(msg);
            }
        }
    }

    class WifiConnectMonitorThread extends Thread {
        private int nThreadID = 0;

        public WifiConnectMonitorThread(int nThreadID) {
            this.nThreadID = nThreadID;
        }

        public void run() {
            while (DeviceQuickConfigActivity.this._nThreadID == this.nThreadID) {
                DeviceQuickConfigActivity.this.mWifiInfo = DeviceQuickConfigActivity.this.mWiFiManager.getConnectionInfo();
                if (DeviceQuickConfigActivity.this.mWifiInfo != null) {
                    String strConnSSID = DeviceQuickConfigActivity.this.mWifiInfo.getSSID();
                    if (strConnSSID == null || strConnSSID.length() <= 2) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        if (strConnSSID.substring(0, 1).equals("\"") && strConnSSID.substring(strConnSSID.length() - 1, strConnSSID.length()).equals("\"")) {
                            strConnSSID = strConnSSID.substring(1, strConnSSID.length() - 1);
                        }
                        if (strConnSSID == null || strConnSSID.length() <= 0) {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e2) {
                                e2.printStackTrace();
                            }
                        } else if (strConnSSID.equals(DeviceQuickConfigActivity.this.strDeviceSSID) && DeviceQuickConfigActivity.this.isWiFiActive() && DeviceQuickConfigActivity.this._nThreadID == this.nThreadID) {
                            Message msg = DeviceQuickConfigActivity.this.handler.obtainMessage();
                            msg.arg1 = DeviceQuickConfigActivity.HANDLE_MSG_WIFI_CONNECT_SUCCEED;
                            DeviceQuickConfigActivity.this.handler.sendMessage(msg);
                            return;
                        } else {
                            try {
                                Thread.sleep(3000);
                            } catch (InterruptedException e22) {
                                e22.printStackTrace();
                            }
                        }
                    }
                }
            }
        }
    }

    private class WifiListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageView ivQuickConfig;
            ImageView ivQuickConfigLogo;
            TextView tvName;

            private ItemViewHolder() {
            }
        }

        public WifiListViewAdapter(Context c, int resource, String[] from, int[] to) {
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return DeviceQuickConfigActivity.this.localWifiList.size();
        }

        public Object getItem(int position) {
            return DeviceQuickConfigActivity.this.localWifiList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.quick_config_item, null);
                this.holder = new ItemViewHolder();
                this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[0]);
                this.holder.ivQuickConfig = (ImageView) convertView.findViewById(this.valueViewID[1]);
                this.holder.ivQuickConfigLogo = (ImageView) convertView.findViewById(this.valueViewID[2]);
                convertView.setTag(this.holder);
            }
            ScanResult scanResult = (ScanResult) DeviceQuickConfigActivity.this.localWifiList.get(position);
            if (scanResult != null) {
                this.holder.tvName.setText(scanResult.SSID);
                this.holder.ivQuickConfigLogo.setVisibility(8);
                if (DeviceQuickConfigActivity.this.encryCodeOfCapabilities(scanResult.capabilities) == 1) {
                    if (scanResult.level >= -55) {
                        this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_4));
                    } else if (scanResult.level >= -70) {
                        this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_3));
                    } else if (scanResult.level >= -85) {
                        this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_2));
                    } else if (scanResult.level >= -100) {
                        this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_1));
                    } else {
                        this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_0));
                    }
                } else if (scanResult.level >= -55) {
                    this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_lock_4));
                } else if (scanResult.level >= -70) {
                    this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_lock_3));
                } else if (scanResult.level >= -85) {
                    this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_lock_2));
                } else if (scanResult.level >= -100) {
                    this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_lock_1));
                } else {
                    this.holder.ivQuickConfig.setImageDrawable(DeviceQuickConfigActivity.this.getResources().getDrawable(C0470R.drawable.wifi_lock_0));
                }
            }
            return convertView;
        }
    }

    public class WifiReceiver extends BroadcastReceiver {

        class C03381 implements Comparator<ScanResult> {
            C03381() {
            }

            public int compare(ScanResult object1, ScanResult object2) {
                if (object1.frequency > object2.frequency) {
                    return 1;
                }
                if (object1.frequency > object2.frequency) {
                    return -1;
                }
                return 0;
            }
        }

        public void onReceive(Context c, Intent intent) {
            List<ScanResult> scanWifiList = DeviceQuickConfigActivity.this.mWiFiManager.getScanResults();
            DeviceQuickConfigActivity.this.mvDeviceList.clear();
            DeviceQuickConfigActivity.this.localWifiList.clear();
            if (scanWifiList != null && scanWifiList.size() > 0) {
                for (int i = 0; i < scanWifiList.size(); i++) {
                    boolean isMVDevice = false;
                    ScanResult sScanResult = (ScanResult) scanWifiList.get(i);
                    Log.i("TAG", " " + sScanResult);
                    if (sScanResult != null) {
                        String strSSID = sScanResult.SSID;
                        if (strSSID.startsWith("MV") && strSSID.length() >= 10 && strSSID.length() < 32) {
                            try {
                                if (Integer.parseInt(strSSID.substring(2)) > 0) {
                                    isMVDevice = true;
                                }
                            } catch (Exception e) {
                            }
                        }
                        if (isMVDevice) {
                            DeviceQuickConfigActivity.this.mvDeviceList.add(sScanResult);
                        } else {
                            DeviceQuickConfigActivity.this.localWifiList.add(sScanResult);
                        }
                    }
                }
                if (!DeviceQuickConfigActivity.this.mvDeviceList.isEmpty()) {
                    Collections.sort(DeviceQuickConfigActivity.this.mvDeviceList, new C03381());
                }
                Message msg = DeviceQuickConfigActivity.this.handler.obtainMessage();
                msg.arg1 = DeviceQuickConfigActivity.HANDLE_MSG_FRESH_LIST;
                DeviceQuickConfigActivity.this.handler.sendMessage(msg);
            }
        }
    }

    private void createDialogs() {
        this.progressDialogOpenWifi = new ProgressDialog(this);
        this.progressDialogOpenWifi.setProgressStyle(0);
        this.progressDialogOpenWifi.setCanceledOnTouchOutside(false);
        this.progressDialogOpenWifi.setMessage(getString(C0470R.string.device_model_trade) + "...");
        this.passwordInputConctentView = LayoutInflater.from(this).inflate(C0470R.layout.wifi_edit_dialog, null);
        this.passwordInputDialog = new Dialog(this, C0470R.style.dialog_bg_transparent);
        this.passwordInputDialog.setContentView(this.passwordInputConctentView);
        this.passwordInputDialog.setOnShowListener(new C03302());
    }

    public void onPasswordInputDialogShow() {
        this.tvDialogWifiName = (TextView) this.passwordInputConctentView.findViewById(C0470R.id.tvWifiName2);
        this.passwordInputConctentView.findViewById(C0470R.id.llWifiPassword2).setVisibility(0);
        this.etDialogWifiPasword = (EditText) this.passwordInputConctentView.findViewById(C0470R.id.etWifiPassword2);
        Button btnWifiFinsh = (Button) this.passwordInputConctentView.findViewById(C0470R.id.btnWifiFinsh);
        Button btnWifiSave = (Button) this.passwordInputConctentView.findViewById(C0470R.id.btnWifiSave);
        this.tvDialogWifiName.setText(this.strDeviceSSID);
        this.etDialogWifiPasword.setText(Constants.MAIN_VERSION_TAG);
        btnWifiSave.setOnClickListener(new C03313());
        btnWifiFinsh.setOnClickListener(new C03324());
    }

    private void ShowDeviceSelectView() {
        this.nPageIndex = 100;
        this.layoutDeviceSelectView.setVisibility(0);
        this.layoutWifiSelectView.setVisibility(8);
        this.btnConfigWifi.setVisibility(8);
        this.layoutIndecationView.setVisibility(8);
        getWifiList();
    }

    private void ShowWifiSelectView() {
        this.nPageIndex = 101;
        this.layoutIndecationView.setVisibility(0);
        this.layoutDeviceSelectView.setVisibility(8);
        this.layoutWifiSelectView.setVisibility(0);
        this.tvHint.setTextColor(SupportMenu.CATEGORY_MASK);
        this.tvHint.setText(getString(C0470R.string.nonsupport5GWIFI));
        this.btnConfigWifi.setVisibility(0);
        this.btnConfigWifi.setEnabled(true);
        if (this.localWifiList != null && this.localWifiList.size() > 0) {
            ScanResult scanResult = (ScanResult) this.localWifiList.get(0);
            String wifiName = scanResult.SSID;
            this.nStationWifiEnrcrypt = encryCodeOfCapabilities(scanResult.capabilities);
            if (wifiName == null || wifiName.length() <= 0) {
                this.etWifiConfigName.setText(null);
            } else {
                this.etWifiConfigName.setText(wifiName);
            }
            this.etWifiConfigPassword.setText(null);
            updateWifiListView();
        }
    }

    private void backToList() {
        this.mBSSID = null;
        unregisterReceiver(this.mwReceiver);
        Intent intent = new Intent(this, HomePageActivity.class);
        LocalDefines.B_UPDATE_LISTVIEW = true;
        startActivity(intent);
        finish();
        overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
    }

    protected void onDestroy() {
        if (this.rvQuickConfigSearchingRadar != null) {
            this.rvQuickConfigSearchingRadar.recycleBitmap();
            System.gc();
        }
        super.onDestroy();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            back();
        }
        return false;
    }

    private void back() {
        hindKeyboard();
        if (this.nPageIndex == 100) {
            backToList();
        } else {
            this.m_nNetworkConfigID++;
            this.soundPlayer.stop();
            ShowDeviceSelectView();
            hideConfigIndicatorView();
            this.rvQuickConfigSearchingRadar.stopAnimate();
        }
        this.mBSSID = null;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().setFlags(128, 128);
        setContentView(C0470R.layout.activity_quick_config_model);
        getWindow().setBackgroundDrawable(null);
        this.mWiFiAdnim = new WiFiAdnim(this);
        this.mWiFiManager = (WifiManager) getSystemService("wifi");
        this.soundPlayer = MediaPlayer.create(this, C0470R.raw.seekmusic);
        initInterface();
        this.progressDialogWifi = new ProgressDialog(this);
        onClickListView();
        createDialogs();
        ShowDeviceSelectView();
    }

    private void getWifiList() {
        this.progressBarQuickConfig.setVisibility(0);
        this.btnConfigWifi.setVisibility(4);
        enableWifi();
        this.mWifiInfo = this.mWiFiManager.getConnectionInfo();
        this.mWiFiAdnim.startScan();
    }

    private void initInterface() {
        this.layoutSettingView = (LinearLayout) findViewById(C0470R.id.layoutSettingView);
        this.layoutIndecationView = (LinearLayout) findViewById(C0470R.id.layoutIndecationView);
        this.layoutIndecationView.setBackgroundColor(Color.parseColor("#f9f9f9"));
        this.layoutDeviceSelectView = (LinearLayout) findViewById(C0470R.id.layoutDeviceSelectView);
        this.layoutWifiSelectView = (LinearLayout) findViewById(C0470R.id.layoutWifiSelectView);
        this.btnConfigWifi = (Button) findViewById(C0470R.id.btnConfigWifi);
        this.lvDeviceListView = (ListView) findViewById(C0470R.id.lvDeviceSelectView);
        this.lvWifiListView = (ListView) findViewById(C0470R.id.lvWifiListView);
        this.btBack = (ImageView) findViewById(C0470R.id.btnQuickConfigBack);
        this.btBack.setOnClickListener(this);
        this.tvTitle = (TextView) findViewById(C0470R.id.tvConfig);
        this.tvHint = (TextView) findViewById(C0470R.id.tvHint);
        this.tvSeekDevice = (TextView) findViewById(C0470R.id.tvSeekDevice);
        this.llSeekDevice = (LinearLayout) findViewById(C0470R.id.llSeekDevice);
        this.llSeekDevice.setVisibility(8);
        this.rvQuickConfigSearchingRadar = (RadarView) findViewById(C0470R.id.rvQuickConfigSearchingRadar);
        this.rvQuickConfigSearchingRadar.setWillNotDraw(false);
        this.btnWifiDeviceRefresh = (Button) findViewById(C0470R.id.btnWifiDeviceRefresh);
        this.btnWifiDeviceRefresh.setOnClickListener(this);
        this.ryWifiPassword = (RelativeLayout) findViewById(C0470R.id.ryWifiPassword);
        this.tvWifiConfigPasswordFree = (EditText) findViewById(C0470R.id.tvWifiConfigPasswordFree);
        this.etWifiConfigName = (EditText) findViewById(C0470R.id.etWifiConfigName);
        this.etWifiConfigPassword = (EditText) findViewById(C0470R.id.etWifiConfigPassword);
        this.wifiCheckBoxPwdHiden = (ImageView) findViewById(C0470R.id.wifiCheckBoxPwdHiden);
        this.wifiCheckBoxPwdHiden.setOnClickListener(new C03335());
        this.lvDeviceListView.setCacheColorHint(0);
        this.progressBarQuickConfig = (ProgressBar) findViewById(C0470R.id.progressBarQuickConfig);
        if (this.mWiFiManager.getWifiState() != 3) {
            View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
            ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.wifiConnect));
            ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.wifi_start_bt));
            new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.wifi_is), new C03346()).setNegativeButton(getString(C0470R.string.wifi_no), new C03357()).show();
        }
        this.btBack.setOnClickListener(this);
        this.btnConfigWifi.setText(getString(C0470R.string.btn_save));
        this.btnConfigWifi.setOnClickListener(this);
    }

    private void updateDeviceListView() {
        if (this.lvDeviceListView == null) {
            this.lvDeviceListView = (ListView) findViewById(C0470R.id.lvDeviceSelectView);
        }
        if (this.mvDeviceList == null || this.mvDeviceList.size() <= 0) {
            this.lvDeviceListView.setAdapter(null);
            return;
        }
        DeviceListViewAdapter deviceListItemAdapter = new DeviceListViewAdapter(this, C0470R.layout.quick_config_item, new String[]{"ItemTvDeviceSelect", "ItemTvDeviceLogo"}, new int[]{C0470R.id.tvQuickConfig, C0470R.id.ivQuickConfigLogo});
        if (this.lvDeviceListView != null) {
            this.lvDeviceListView.setCacheColorHint(0);
            this.lvDeviceListView.setAdapter(deviceListItemAdapter);
        }
    }

    private void updateWifiListView() {
        if (this.lvWifiListView == null) {
            this.lvWifiListView = (ListView) findViewById(C0470R.id.lvWifiListView);
        }
        if (this.localWifiList == null || this.localWifiList.size() <= 0) {
            this.lvWifiListView.setAdapter(null);
            return;
        }
        WifiListViewAdapter wifiListItemAdapter = new WifiListViewAdapter(this, C0470R.layout.quick_config_item, new String[]{"ItemTvDeviceSelect", "ItemIvDeviceSelect", "ItemIvDevcieConfigLogo"}, new int[]{C0470R.id.tvQuickConfig, C0470R.id.ivQuickConfig, C0470R.id.ivQuickConfigLogo});
        if (this.lvWifiListView != null) {
            this.lvWifiListView.setCacheColorHint(0);
            this.lvWifiListView.setAdapter(wifiListItemAdapter);
        }
    }

    public void enableWifi() {
        this.mwReceiver = new WifiReceiver();
        registerReceiver(this.mwReceiver, new IntentFilter("android.net.wifi.SCAN_RESULTS"));
    }

    public boolean isWiFiActive() {
        ConnectivityManager connectivity = (ConnectivityManager) getSystemService("connectivity");
        if (connectivity == null) {
            return false;
        }
        NetworkInfo[] infos = connectivity.getAllNetworkInfo();
        if (infos == null) {
            return false;
        }
        for (NetworkInfo ni : infos) {
            if (ni.getTypeName().equals("WIFI") && ni.isConnected()) {
                return true;
            }
        }
        return false;
    }

    private void StartMonitor() {
        this._nThreadID++;
        new WifiConnectMonitorThread(this._nThreadID).start();
    }

    @SuppressLint({"DefaultLocale"})
    private void onClickListView() {
        this.lvWifiListView.setOnItemClickListener(new C03368());
        this.lvDeviceListView.setOnItemClickListener(new C03379());
    }

    private void connectToAPDevice(String SSID, String Password, int Type) {
        this.mWiFiAdnim.addNetWork(this.mWiFiAdnim.CreateWifiInfo(SSID, Password, Type));
    }

    protected void onStart() {
        super.onStart();
        isWiFiActive();
    }

    protected void onStop() {
        super.onStop();
        this.m_nThreadDeviceMsg++;
    }

    public NetwordInfo getmNetworkConfig() {
        return this.mNetworkConfig;
    }

    private boolean isApConnect() {
        boolean isAPConnect = false;
        this.mWifiInfo = this.mWiFiManager.getConnectionInfo();
        if (this.mWifiInfo == null) {
            return false;
        }
        String strConnSSID = this.mWifiInfo.getSSID();
        if (strConnSSID == null || strConnSSID.length() <= 2) {
            return false;
        }
        if (strConnSSID.substring(0, 1).equals("\"") && strConnSSID.substring(strConnSSID.length() - 1, strConnSSID.length()).equals("\"")) {
            strConnSSID = strConnSSID.substring(1, strConnSSID.length() - 1);
        }
        if (strConnSSID == null || strConnSSID.length() <= 0) {
            return false;
        }
        if (strConnSSID.equals(this.strDeviceSSID) && isWiFiActive()) {
            isAPConnect = true;
        }
        return isAPConnect;
    }

    private boolean isWIFIConnect() {
        boolean isWIFIConnect = false;
        this.mWifiInfo = this.mWiFiManager.getConnectionInfo();
        if (this.mWifiInfo == null) {
            return false;
        }
        String strConnSSID = this.mWifiInfo.getSSID();
        if (strConnSSID == null || strConnSSID.length() <= 2) {
            return false;
        }
        if (strConnSSID.substring(0, 1).equals("\"") && strConnSSID.substring(strConnSSID.length() - 1, strConnSSID.length()).equals("\"")) {
            strConnSSID = strConnSSID.substring(1, strConnSSID.length() - 1);
        }
        if (strConnSSID == null || strConnSSID.length() <= 0) {
            return false;
        }
        if (strConnSSID.equals(this.strStationWifiName) && isWiFiActive()) {
            isWIFIConnect = true;
        }
        return isWIFIConnect;
    }

    private int encryCodeOfCapabilities(String capabilities) {
        int nResult = 0;
        if (capabilities == null) {
            return 1;
        }
        if (capabilities.indexOf("WPA2") != -1) {
            nResult = 3;
        } else if (capabilities.indexOf("[WPA-PSK-TKIP+CCMP]") != -1 || capabilities.indexOf("[WPA2-PSK-TKIP+CCMP]") != -1) {
            nResult = 3;
        } else if (capabilities.indexOf("[WEP]") != -1 && capabilities.indexOf("[IBSS]") != -1) {
            nResult = 2;
        } else if (capabilities.indexOf("[WEP]") != -1) {
            nResult = 2;
        } else if (capabilities.indexOf("[WPA-PSK-CCMP]") != -1 || capabilities.indexOf("[WPA-PSK-TKIP+CCMP]") != -1) {
            nResult = 3;
        } else if (capabilities.indexOf("[WPA2-PSK-CCMP]") != -1 || capabilities.indexOf("[WPA2-PSK-TKIP+CCMP]") != -1) {
            nResult = 3;
        } else if (capabilities.indexOf("[ESS]") != -1) {
            nResult = 1;
        }
        return nResult;
    }

    private void popupWindoww(View v, int width, int height, int gravigy, int x, int y) {
        this.popupWindow = new PopupWindow(v, width, height);
        this.popupWindow.setFocusable(true);
        this.popupWindow.setOutsideTouchable(true);
        this.popupWindow.setBackgroundDrawable(new BitmapDrawable());
        v.getLocationOnScreen(new int[2]);
        this.popupWindow.showAtLocation(v, gravigy, x, y);
    }

    private void startConfigWifi() {
        Log.d("dqx", "strDeviceSSID = " + this.strDeviceSSID);
        if (this.strDeviceSSID != null && this.strDeviceSSID.length() > 3) {
            try {
                this.nDeviceID = Integer.parseInt(this.strDeviceSSID.substring(2, this.strDeviceSSID.length()));
            } catch (Exception e) {
                this.nDeviceID = 0;
            }
        }
        String strAdmin = "admin";
        String strAdminPaword = Constants.MAIN_VERSION_TAG;
        DeviceInfo serverInfos = DatabaseManager.GetServerInfo(this.nDeviceID);
        if (serverInfos != null) {
            this.serverInfo = serverInfos;
        } else {
            this.serverInfo = new DeviceInfo(-1, this.nDeviceID, this.strDeviceSSID, "192.168.1.1", 8800, strAdmin, strAdminPaword, null, null, 0);
        }
        this.btnConfigWifi.setEnabled(false);
        this.strStationWifiName = this.etWifiConfigName.getText().toString();
        this.strStationWifiPassword = this.etWifiConfigPassword.getText().toString();
        if (this.strStationWifiPassword.length() <= 7) {
            Toast.makeText(this, getString(C0470R.string.pwd_hint), 0).show();
            this.btnConfigWifi.setEnabled(true);
            return;
        }
        if (this.strStationWifiPassword == null || this.strStationWifiPassword.length() <= 0) {
            this.nStationWifiEnrcrypt = 1;
        }
        this.rvQuickConfigSearchingRadar.startAnimate();
        showConfigIndicatorView();
        if (!isApConnect()) {
            connectToAPDevice(this.strDeviceSSID, Constants.MAIN_VERSION_TAG, this.nDeviceEnrcrypt);
        }
        this.m_nNetworkConfigID++;
        new NetWorkConfigThread(this.handler, this.m_nNetworkConfigID, 1002, this.strStationWifiName, this.strStationWifiPassword, this.serverInfo, this.mBSSID).start();
        this.soundPlayer.start();
        this.soundPlayer.setLooping(true);
    }

    private void showConfigIndicatorView() {
        this.layoutSettingView.setVisibility(8);
        this.layoutIndecationView.setVisibility(0);
    }

    private void hideConfigIndicatorView() {
        this.layoutSettingView.setVisibility(0);
        this.layoutIndecationView.setVisibility(8);
    }

    public void onClick(View sender) {
        switch (sender.getId()) {
            case C0470R.id.btnQuickConfigBack:
                back();
                return;
            case C0470R.id.btnWifiDeviceRefresh:
                this.mWiFiAdnim.startScan();
                this.progressBarQuickConfig.setVisibility(0);
                return;
            case C0470R.id.btnConfigWifi:
                hindKeyboard();
                startConfigWifi();
                return;
            default:
                return;
        }
    }

    public void ShowAlert(String title, String msg) {
        View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(title);
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(msg);
        new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                DeviceQuickConfigActivity.this.setResult(-1);
            }
        }).show();
    }

    public void hindKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService("input_method");
            if (imm != null) {
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 2);
            }
        } catch (Exception e) {
        }
    }

    public void StartBindDeviceThread(int DeviceId, String DeviceName, String DevicePassword, DeviceInfo info, int infoIndex) {
        this.n_BindDeviceThreadID++;
        new BindDeviceThread(this.n_BindDeviceThreadID, DeviceName, DevicePassword, this.handler, DeviceId, info, infoIndex).start();
    }

    public void postBindDeviceData(int DeviceId, String DeviceName, String DevicePassword, DeviceInfo info, int infoIndex) throws JSONException {
        long time = System.currentTimeMillis();
        String MDLoginSign = LoginActivity.md5("accesstoken=" + DeviceListViewFragment._Token + "&deviceaccount=" + DeviceName + "&deviceid=" + DeviceId + "&devicepassword=" + DevicePassword + "&timestamp=" + (time / 1000) + "hsshop2016");
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", time / 1000);
        json.put("accesstoken", DeviceListViewFragment._Token);
        json.put("deviceid", DeviceId);
        json.put("deviceaccount", DeviceName);
        json.put("devicepassword", DevicePassword);
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/device/bind", json.toString());
        if (Recresult != null) {
            JSONObject Bindjson = new JSONObject(Recresult);
            int result = Integer.valueOf(Bindjson.getString("result")).intValue();
            this.bindDevice_result = result;
            if (result == 0) {
                DeviceListViewFragment.SaveUpdateDeviceTime(Integer.valueOf(Bindjson.getInt("update_timestamp")).intValue());
            }
        }
    }

    private void httpResult401() {
        View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.str_Notic_Close_APP));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.str_401));
        AlertDialog dialog = new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                Editor modeEditor = DeviceQuickConfigActivity.this.getSharedPreferences("ShareAPPMODE", 0).edit();
                modeEditor.putInt("GetModeNum", 0);
                modeEditor.commit();
                HomePageActivity.AppMode = 0;
                Editor editor = DeviceQuickConfigActivity.this.getSharedPreferences("SaveTimeTamp", 0).edit();
                editor.putInt("TimeTamp", 0);
                editor.commit();
                DeviceQuickConfigActivity.this.startActivity(new Intent(DeviceQuickConfigActivity.this, LoginActivity.class));
                DeviceQuickConfigActivity.this.finish();
            }
        }).create();
        dialog.setCancelable(false);
        dialog.show();
    }
}
