package com.macrovideo.v380;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;
import android.widget.Toast;
import com.macrovideo.httptool.HttpUtils;
import com.macrovideo.objects.CloudService;
import com.macrovideo.pull.lib.InnerListView;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.custom.RecordFileInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrvideo.newlogin.CloudServiceHelper;
import com.tencent.android.tpush.common.Constants;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CloudStorageActivity extends Activity implements OnClickListener, OnItemClickListener {
    static final int DATETIME_MODE_DATE = 100;
    static final int DATETIME_MODE_ENDTIME = 102;
    static final int DATETIME_MODE_STARTTIME = 101;
    static final int DATETIME_MODE_UNDEFINE = 0;
    private static final int HANDLE_ACTIVATE_SERVICE_FAIL = 1005;
    private static final int HANDLE_BIND_TO_SERVER = 1001;
    private static final int HANDLE_GET_DEVIVE_TOKEN_FAIL = 1004;
    private static final int HANDLE_GET_SERVICE_INFO = 998;
    private static final int HANDLE_GET_SERVICE_LIST = 999;
    private static final int HANDLE_GET_VALID_CODE = 1003;
    private static final int HANDLE_UNBIND_SERVICE_FROM_PHONE = 1002;
    private static final int LOGIN_BY_MAIL = 2;
    private static final int LOGIN_BY_PHONE = 1;
    public static final int REQUEST_CODE_WEBVIEW_ACTIVITY = 12;
    public static final int RESULT_CODE_WEBVIEW_ACTIVITY = 13;
    private static final int TYPE_LOADING = 1;
    private LoginHandle _deviceParam;
    private AlertDialog bindDialog;
    protected Button btnDatetimeSelectCancel;
    protected Button btnDatetimeSelectOK;
    private Button btnGetValidCode;
    private Button btnSearch;
    private View contentView;
    private View datetimeSelectConctentView;
    private Dialog datetimeSelectDialog;
    private View deviceSelectConctentView;
    private Dialog deviceSelectDialog;
    private EditText etValidCode;
    private ArrayList<RecordFileInfo> fileList = new ArrayList();
    boolean isInit = false;
    private ImageView iv_connect_to_device;
    private ImageView iv_connect_to_server;
    private ImageView iv_type_alarm;
    private ImageView iv_type_all;
    private ImageView iv_type_auto;
    protected LinearLayout layoutDatePicker;
    protected LinearLayout layoutTimePicker;
    private LinearLayout ll_search_date;
    private LinearLayout ll_search_end_time;
    private LinearLayout ll_search_start_time;
    private LinearLayout ll_type_alarm;
    private LinearLayout ll_type_all;
    private LinearLayout ll_type_auto;
    private Dialog loadingDialog;
    private View loadingView;
    private LoginHandle loginHandle = new LoginHandle();
    private String mAccesstoken;
    private ServiceListViewAdapter mAdapter;
    private ImageView mBtnBack;
    private Button mBtnSearchRecordFiles;
    private Button mBtnUnBind;
    private CloudService mCloudService;
    private long mCountDownTime = 60000;
    private DeviceInfo mDevice;
    private int mDeviceId;
    private String mEcsIP;
    private String mEcsIP2;
    private int mEcsPort;
    private int mEcsPort2;
    private int mGetRecFileId = 0;
    private TextView mGetResultError;
    private Handler mHandler = new C02581();
    private TextView mHint;
    private boolean mIsLoadingServiceInfo = false;
    private LinearLayout mLayoutCloudStorage;
    private LinearLayout mLayoutSearchCloudRecordFile;
    private int mLoadType = 1;
    private int mPosition;
    private int mProductId;
    private ProgressBar mProgressBar;
    private LinearLayout mPurchaseService;
    private LinearLayout mRenewService;
    private int mSaveLoginWay;
    private ScrollView mScrollView;
    private DatePicker mSelectDatePicker;
    protected TimePicker mSelectTimePicker;
    private List<CloudService> mServiceList = new ArrayList();
    private InnerListView mServiceListView;
    private TextView mUnbindService;
    private RelativeLayout mUnbindServiceListLayout;
    private int mUserId;
    private int m_nActiveToBindServiceID;
    private int m_nBindToDeviceThreadID;
    private int m_nGetServiceListThreadId;
    private int m_nThreadID = 0;
    private int m_n_GetServiceInfoThreadId = 0;
    protected int nDatetimeMode;
    private short nDay = (short) 0;
    private short nEndHour = (short) 23;
    private short nEndMin = (short) 59;
    private short nEndSec = (short) 0;
    private short nMonth = (short) 0;
    private int nSearchType = 0;
    private short nStartHour = (short) 0;
    private short nStartMin = (short) 0;
    private short nStartSec = (short) 0;
    private short nYear = (short) 2000;
    private ListView recFileListView;
    private SharedPreferences shareToken;
    private boolean showRecordFileListLayout = false;
    private boolean showSearchRecordFileLayout = false;
    private TextView tvDate;
    private TextView tvDateTimeCurrent;
    private TextView tvDateTimeTitle;
    private TextView tvDeviceId;
    private TextView tvEndTime;
    private TextView tvError;
    private TextView tvRecordType;
    private TextView tvStartTime;
    private TextView tv_connect_to_device;
    private TextView tv_connect_to_server;
    private AlertDialog unBindDialig;

    class C02581 extends Handler {
        C02581() {
        }

        public void handleMessage(Message msg) {
            boolean dbResult;
            SharedPreferences shareUpdateTime;
            CloudStorageActivity cloudStorageActivity;
            switch (msg.what) {
                case CloudServiceHelper.HANDLE_MSG_CODE_GET_DEVICE_TOKEN /*77*/:
                    int result = msg.arg1;
                    System.out.println("result === " + result);
                    if (result != 1001) {
                        CloudStorageActivity.this.tv_connect_to_device.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_device_fail));
                        ((AnimationDrawable) CloudStorageActivity.this.iv_connect_to_device.getBackground()).stop();
                        CloudStorageActivity.this.iv_connect_to_device.setBackgroundResource(C0470R.drawable.device_status_off);
                        CloudStorageActivity.this.tv_connect_to_server.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_server_wait));
                        CloudStorageActivity.this.iv_connect_to_server.setBackgroundResource(C0470R.drawable.device_status_off);
                        CloudStorageActivity.this.bindDialog.dismiss();
                        if (msg.arg2 != -100) {
                            if (msg.arg2 != ResultCode.NV_RESULT_DESC_NO_USER && msg.arg2 != ResultCode.NV_RESULT_DESC_PWD_ERR) {
                                if (msg.arg2 != 0) {
                                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_device_bind_service_fail), 0).show();
                                    break;
                                } else {
                                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_other_user_binding_device), 0).show();
                                    break;
                                }
                            }
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.notice_Result_PWDError), 0).show();
                            break;
                        }
                        Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_device_bind_service_fail_not_support), 0).show();
                        break;
                    }
                    CloudStorageActivity.this.tv_connect_to_device.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_device_ok));
                    ((AnimationDrawable) CloudStorageActivity.this.iv_connect_to_device.getBackground()).stop();
                    CloudStorageActivity.this.iv_connect_to_device.setBackgroundResource(C0470R.drawable.device_status_on);
                    CloudStorageActivity.this.tv_connect_to_server.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_server_ing));
                    CloudStorageActivity.this.iv_connect_to_server.setBackgroundResource(C0470R.drawable.pot_loading_animation_list);
                    ((AnimationDrawable) CloudStorageActivity.this.iv_connect_to_server.getBackground()).start();
                    new BindToServerThread(CloudStorageActivity.this.mAccesstoken, CloudStorageActivity.this.mCloudService.getService_id(), CloudStorageActivity.this.mDeviceId, String.valueOf(msg.arg2)).start();
                    break;
                    break;
                case CloudServiceHelper.HANDLE_MSG_CODE_ACTIVE_BIND_SERVICE /*78*/:
                    if (msg.arg1 != 1001) {
                        CloudStorageActivity.this.tv_connect_to_device.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_device_ok));
                        CloudStorageActivity.this.iv_connect_to_device.setBackgroundResource(C0470R.drawable.device_status_on);
                        CloudStorageActivity.this.tv_connect_to_server.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_server_fail));
                        ((AnimationDrawable) CloudStorageActivity.this.iv_connect_to_server.getBackground()).stop();
                        CloudStorageActivity.this.iv_connect_to_server.setBackgroundResource(C0470R.drawable.device_status_off);
                        CloudStorageActivity.this.bindDialog.dismiss();
                        Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_bind_service_fail), 0).show();
                        break;
                    }
                    CloudStorageActivity.this.tv_connect_to_device.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_device_ok));
                    CloudStorageActivity.this.iv_connect_to_device.setBackgroundResource(C0470R.drawable.device_status_on);
                    CloudStorageActivity.this.tv_connect_to_server.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_server_ok));
                    ((AnimationDrawable) CloudStorageActivity.this.iv_connect_to_server.getBackground()).stop();
                    CloudStorageActivity.this.iv_connect_to_server.setBackgroundResource(C0470R.drawable.device_status_on);
                    CloudStorageActivity.this.bindDialog.dismiss();
                    if (CloudStorageActivity.this.getIsServiceOutOfDate(CloudStorageActivity.this.mCloudService.getEnd_time())) {
                        CloudStorageActivity.this.mProductId = Integer.parseInt("-" + CloudStorageActivity.this.mCloudService.getService_id());
                    } else {
                        CloudStorageActivity.this.mProductId = CloudStorageActivity.this.mCloudService.getService_id();
                    }
                    CloudStorageActivity.this.mDevice.setnProductId(CloudStorageActivity.this.mProductId);
                    dbResult = DatabaseManager.updateProductId(CloudStorageActivity.this.mDevice);
                    shareUpdateTime = CloudStorageActivity.this.getSharedPreferences("SaveTimeTamp", 0);
                    shareUpdateTime.edit().putInt("TimeTamp", msg.arg2).commit();
                    DeviceListViewFragment.NewLocalTimeTamp = shareUpdateTime.getInt("TimeTamp", -101);
                    LocalDefines.shouldRefreshDeviceList = true;
                    if (CloudStorageActivity.this.mProductId > 0) {
                        CloudStorageActivity.this.mHint.setText(new StringBuilder(String.valueOf(CloudStorageActivity.this.mDeviceId)).append(" ").append(CloudStorageActivity.this.getString(C0470R.string.str_device_has_bind_service)).append(" ").append(CloudStorageActivity.this.mCloudService.getIntroduction()).toString());
                    } else if (CloudStorageActivity.this.mProductId < 0) {
                        CloudStorageActivity.this.mHint.setText(new StringBuilder(String.valueOf(CloudStorageActivity.this.mDeviceId)).append(" ").append(CloudStorageActivity.this.getString(C0470R.string.str_device_service_outofdate)).append(" ").append(CloudStorageActivity.this.mCloudService.getIntroduction()).toString());
                    }
                    CloudStorageActivity.this.mBtnUnBind.setVisibility(0);
                    CloudStorageActivity.this.mBtnSearchRecordFiles.setVisibility(0);
                    CloudStorageActivity.this.mUnbindServiceListLayout.setVisibility(8);
                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_bind_service_ok), 0).show();
                    break;
                case CloudStorageActivity.HANDLE_GET_SERVICE_INFO /*998*/:
                    CloudStorageActivity.this.mIsLoadingServiceInfo = false;
                    CloudStorageActivity.this.loadingDialog.dismiss();
                    if (msg.arg1 != 0) {
                        if (msg.arg1 == -1) {
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_network_error), 0).show();
                        } else if (msg.arg1 == 401) {
                            CloudStorageActivity.this.httpResult401();
                        } else if (msg.arg1 == 500) {
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_server_error), 0).show();
                        } else {
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_get_device_server_info_error), 0).show();
                        }
                        CloudStorageActivity.this.mScrollView.setVisibility(8);
                        CloudStorageActivity.this.tvError.setVisibility(0);
                        break;
                    }
                    LocalDefines.unbindingServiceFromMail = false;
                    CloudStorageActivity.this.mScrollView.setVisibility(0);
                    if (CloudStorageActivity.this.mCloudService.getBind_status() != 20) {
                        CloudStorageActivity.this.mHint.setText(new StringBuilder(String.valueOf(CloudStorageActivity.this.mDeviceId)).append(" ").append(CloudStorageActivity.this.getString(C0470R.string.str_device_not_bind_service)).toString());
                        CloudStorageActivity.this.mBtnUnBind.setVisibility(8);
                        CloudStorageActivity.this.mBtnSearchRecordFiles.setVisibility(8);
                        CloudStorageActivity.this.mUnbindServiceListLayout.setVisibility(0);
                        CloudStorageActivity.this.mProductId = 0;
                        CloudStorageActivity.this.mDevice.setnProductId(0);
                        DatabaseManager.updateProductId(CloudStorageActivity.this.mDevice);
                        LocalDefines.shouldRefreshDeviceList = true;
                        cloudStorageActivity = CloudStorageActivity.this;
                        cloudStorageActivity.m_nGetServiceListThreadId = cloudStorageActivity.m_nGetServiceListThreadId + 1;
                        CloudStorageActivity.this.mProgressBar.setVisibility(0);
                        new GetServiceListThread(CloudStorageActivity.this.m_nGetServiceListThreadId).start();
                        break;
                    }
                    if (CloudStorageActivity.this.getIsServiceOutOfDate(CloudStorageActivity.this.mCloudService.getEnd_time())) {
                        CloudStorageActivity.this.mProductId = 0 - Math.abs(CloudStorageActivity.this.mProductId);
                    } else {
                        CloudStorageActivity.this.mProductId = Math.abs(CloudStorageActivity.this.mProductId);
                    }
                    if (CloudStorageActivity.this.mProductId > 0) {
                        CloudStorageActivity.this.mHint.setText(new StringBuilder(String.valueOf(CloudStorageActivity.this.mDeviceId)).append(" ").append(CloudStorageActivity.this.getString(C0470R.string.str_device_has_bind_service)).append(" ").append(CloudStorageActivity.this.mCloudService.getIntroduction()).toString());
                    } else if (CloudStorageActivity.this.mProductId < 0) {
                        CloudStorageActivity.this.mHint.setText(new StringBuilder(String.valueOf(CloudStorageActivity.this.mDeviceId)).append(" ").append(CloudStorageActivity.this.getString(C0470R.string.str_device_service_outofdate)).append(" ").append(CloudStorageActivity.this.mCloudService.getIntroduction()).toString());
                    }
                    CloudStorageActivity.this.mDevice.setnProductId(CloudStorageActivity.this.mProductId);
                    DatabaseManager.updateProductId(CloudStorageActivity.this.mDevice);
                    LocalDefines.shouldRefreshDeviceList = true;
                    CloudStorageActivity.this.mBtnUnBind.setVisibility(0);
                    CloudStorageActivity.this.mBtnSearchRecordFiles.setVisibility(0);
                    CloudStorageActivity.this.mUnbindServiceListLayout.setVisibility(8);
                    break;
                case CloudStorageActivity.HANDLE_GET_SERVICE_LIST /*999*/:
                    if (msg.arg1 != 0) {
                        CloudStorageActivity.this.mGetResultError.setVisibility(0);
                        CloudStorageActivity.this.mProgressBar.setVisibility(8);
                        if (msg.arg1 != -1) {
                            if (msg.arg1 != 401) {
                                if (msg.arg1 != 500) {
                                    if (msg.arg1 != HttpUtils.RESULT_CODE_NOT_FOUND_PARAMETER || msg.arg2 != HttpUtils.RESULT_CODE_USER_NOT_BUY_SERVICE) {
                                        CloudStorageActivity.this.mGetResultError.setText(CloudStorageActivity.this.getString(C0470R.string.str_get_service_list_fail));
                                        break;
                                    }
                                    CloudStorageActivity.this.mGetResultError.setText(CloudStorageActivity.this.getString(C0470R.string.str_get_device_service_list_size_0));
                                    CloudStorageActivity.this.mServiceListView.setAdapter(null);
                                    break;
                                }
                                CloudStorageActivity.this.mGetResultError.setText(CloudStorageActivity.this.getString(C0470R.string.str_server_error));
                                break;
                            }
                            CloudStorageActivity.this.mGetResultError.setText(CloudStorageActivity.this.getString(C0470R.string.str_401));
                            CloudStorageActivity.this.httpResult401();
                            break;
                        }
                        CloudStorageActivity.this.mGetResultError.setText(CloudStorageActivity.this.getString(C0470R.string.str_get_device_server_list_error));
                        break;
                    }
                    CloudStorageActivity.this.mProgressBar.setVisibility(8);
                    CloudStorageActivity.this.mGetResultError.setVisibility(8);
                    CloudStorageActivity.this.updateServiceListView();
                    CloudStorageActivity.this.mUnbindService.setText(new StringBuilder(String.valueOf(CloudStorageActivity.this.getString(C0470R.string.str_unbind_service_list))).append("(").append(CloudStorageActivity.this.mServiceList.size()).append("):").toString());
                    break;
                    break;
                case 1001:
                    int resultCode = msg.arg1;
                    System.out.println("resultCode == " + resultCode);
                    if (resultCode != 0) {
                        CloudStorageActivity.this.tv_connect_to_device.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_device_ok));
                        CloudStorageActivity.this.iv_connect_to_device.setBackgroundResource(C0470R.drawable.device_status_on);
                        CloudStorageActivity.this.tv_connect_to_server.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_server_fail));
                        CloudStorageActivity.this.iv_connect_to_server.setBackgroundResource(C0470R.drawable.pot_loading_animation_list);
                        ((AnimationDrawable) CloudStorageActivity.this.iv_connect_to_server.getBackground()).stop();
                        CloudStorageActivity.this.iv_connect_to_server.setBackgroundResource(C0470R.drawable.device_status_off);
                        CloudStorageActivity.this.bindDialog.dismiss();
                        if (resultCode != -1) {
                            if (resultCode != 10006 || msg.arg2 != HttpUtils.RESULT_CODE_SERVICE_HAD_BINDED_OTHER_DEVIVE) {
                                if (resultCode != 10006 || msg.arg2 != HttpUtils.RESULT_CODE_DEVICE_HAD_BINDED_SERVICE) {
                                    if (resultCode != 500) {
                                        if (resultCode != 401) {
                                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_device_bind_service_fail), 0).show();
                                            break;
                                        } else {
                                            CloudStorageActivity.this.httpResult401();
                                            break;
                                        }
                                    }
                                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_server_error), 0).show();
                                    break;
                                }
                                Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_device_had_binded_service), 0).show();
                                break;
                            }
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_service_had_binded_other_device), 0).show();
                            break;
                        }
                        Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_network_error), 0).show();
                        break;
                    }
                    new ActiveToBindService(CloudStorageActivity.this.m_nActiveToBindServiceID, CloudStorageActivity.this.mCloudService.getService_id()).start();
                    break;
                    break;
                case 1002:
                    if (msg.arg1 == 0) {
                        if (CloudStorageActivity.this.mSaveLoginWay != 1) {
                            CloudStorageActivity.this.loadingDialog.dismiss();
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_send_unbind_email_ok), 0).show();
                            LocalDefines.shouldRefreshDeviceList = true;
                            LocalDefines.unbindingServiceFromMail = true;
                            break;
                        }
                        CloudStorageActivity.this.loadingDialog.dismiss();
                        Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_unbind_service_ok), 0).show();
                        CloudStorageActivity.this.mHint.setText(new StringBuilder(String.valueOf(CloudStorageActivity.this.mDeviceId)).append(" ").append(CloudStorageActivity.this.getString(C0470R.string.str_device_not_bind_service)).toString());
                        CloudStorageActivity.this.mBtnUnBind.setVisibility(8);
                        CloudStorageActivity.this.mBtnSearchRecordFiles.setVisibility(8);
                        CloudStorageActivity.this.mUnbindServiceListLayout.setVisibility(0);
                        CloudStorageActivity.this.mProgressBar.setVisibility(0);
                        cloudStorageActivity = CloudStorageActivity.this;
                        cloudStorageActivity.m_nGetServiceListThreadId = cloudStorageActivity.m_nGetServiceListThreadId + 1;
                        new GetServiceListThread(CloudStorageActivity.this.m_nGetServiceListThreadId).start();
                        CloudStorageActivity.this.mProductId = 0;
                        CloudStorageActivity.this.mDevice.setnProductId(0);
                        dbResult = DatabaseManager.updateProductId(CloudStorageActivity.this.mDevice);
                        shareUpdateTime = CloudStorageActivity.this.getSharedPreferences("SaveTimeTamp", 0);
                        shareUpdateTime.edit().putInt("TimeTamp", ((Integer) msg.obj).intValue()).commit();
                        DeviceListViewFragment.NewLocalTimeTamp = shareUpdateTime.getInt("TimeTamp", -101);
                        LocalDefines.shouldRefreshDeviceList = true;
                        break;
                    }
                    CloudStorageActivity.this.loadingDialog.dismiss();
                    CloudStorageActivity.this.mBtnUnBind.setVisibility(0);
                    CloudStorageActivity.this.mBtnSearchRecordFiles.setVisibility(0);
                    CloudStorageActivity.this.mUnbindServiceListLayout.setVisibility(8);
                    if (msg.arg1 != -1) {
                        if (msg.arg1 != 10006) {
                            if (msg.arg1 != 500) {
                                if (msg.arg1 != 401) {
                                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_unbind_service_fail), 0).show();
                                    break;
                                } else {
                                    CloudStorageActivity.this.httpResult401();
                                    break;
                                }
                            }
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_server_error), 0).show();
                            break;
                        } else if (msg.arg2 != 20001) {
                            if (msg.arg2 != 20002) {
                                if (msg.arg2 == HttpUtils.RESULT_CODE_NOT_SET_EMAIL) {
                                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_user_not_set_email), 0).show();
                                    break;
                                }
                            }
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_valid_code_out_of_date), 0).show();
                            break;
                        } else {
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_valid_code_error), 0).show();
                            break;
                        }
                    }
                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_network_error), 0).show();
                    break;
                    break;
                case 1003:
                    if (msg.arg1 != -1) {
                        if (msg.arg1 != 0) {
                            if (msg.arg1 != 500) {
                                if (msg.arg1 != 401) {
                                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_valid_code_get_fail), 0).show();
                                    break;
                                }
                                if (CloudStorageActivity.this.unBindDialig != null && CloudStorageActivity.this.unBindDialig.isShowing()) {
                                    CloudStorageActivity.this.unBindDialig.dismiss();
                                }
                                CloudStorageActivity.this.httpResult401();
                                break;
                            }
                            Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_server_error), 0).show();
                            break;
                        }
                        new TimeCountDown(CloudStorageActivity.this.mCountDownTime, 1000, CloudStorageActivity.this.btnGetValidCode).start();
                        break;
                    }
                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_network_error), 0).show();
                    break;
                case 1004:
                    CloudStorageActivity.this.tv_connect_to_device.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_device_fail));
                    ((AnimationDrawable) CloudStorageActivity.this.iv_connect_to_device.getBackground()).stop();
                    CloudStorageActivity.this.iv_connect_to_device.setBackgroundResource(C0470R.drawable.device_status_off);
                    CloudStorageActivity.this.tv_connect_to_server.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_server_wait));
                    CloudStorageActivity.this.iv_connect_to_server.setBackgroundResource(C0470R.drawable.device_status_off);
                    CloudStorageActivity.this.bindDialog.dismiss();
                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_connect_device_fail), 0).show();
                    break;
                case 1005:
                    CloudStorageActivity.this.tv_connect_to_device.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_device_ok));
                    CloudStorageActivity.this.iv_connect_to_device.setBackgroundResource(C0470R.drawable.device_status_on);
                    CloudStorageActivity.this.tv_connect_to_server.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_server_fail));
                    ((AnimationDrawable) CloudStorageActivity.this.iv_connect_to_server.getBackground()).stop();
                    CloudStorageActivity.this.iv_connect_to_server.setBackgroundResource(C0470R.drawable.device_status_off);
                    CloudStorageActivity.this.bindDialog.dismiss();
                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_connect_device_fail), 0).show();
                    break;
            }
            if (msg.arg1 == 262 && CloudStorageActivity.this.m_nThreadID == CloudStorageActivity.this.mGetRecFileId) {
                if (msg.arg2 != 0) {
                    Bundle data = msg.getData();
                    if (data != null) {
                        CloudStorageActivity.this.fileList = data.getParcelableArrayList(Defines.RECORD_FILE_RETURN_MESSAGE);
                        CloudStorageActivity.this.loginHandle = (LoginHandle) data.getParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE);
                        CloudStorageActivity.this.refleshRecFileList();
                        CloudStorageActivity.this.loadingDialog.dismiss();
                    } else {
                        return;
                    }
                } else if (CloudStorageActivity.this.recFileListView.getAdapter() == null) {
                    CloudStorageActivity.this.showScrollViewLayout();
                    Toast toast = Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.noticRecOKNOFiles), 0);
                    toast.setGravity(17, 0, 0);
                    toast.show();
                    CloudStorageActivity.this.loadingDialog.dismiss();
                    if (msg.getData() != null) {
                        CloudStorageActivity.this.fileList.clear();
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            if (msg.arg1 == 259) {
                CloudStorageActivity.this.loadingDialog.dismiss();
                Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_connect_device_fail), 0).show();
                if (CloudStorageActivity.this.fileList.size() <= 0) {
                    CloudStorageActivity.this.showScrollViewLayout();
                }
            }
        }
    }

    class C02592 implements DialogInterface.OnClickListener {
        C02592() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            CloudStorageActivity.this.etValidCode.setText(Constants.MAIN_VERSION_TAG);
            CloudStorageActivity.this.unBindDialig.show();
        }
    }

    class C02603 implements Runnable {
        C02603() {
        }

        public void run() {
            CloudStorageActivity.this.mGetResultError.setVisibility(0);
            CloudStorageActivity.this.mProgressBar.setVisibility(8);
        }
    }

    class C02614 implements OnClickListener {
        C02614() {
        }

        public void onClick(View v) {
            new GetValidCodeThread().start();
        }
    }

    class C02625 implements DialogInterface.OnClickListener {
        C02625() {
        }

        public void onClick(DialogInterface dialog, int which) {
            if (CloudStorageActivity.this.mSaveLoginWay == 1) {
                String strValidCode = CloudStorageActivity.this.etValidCode.getText().toString().trim();
                boolean isAllDigit = CloudStorageActivity.this.isNumeric(strValidCode);
                if (strValidCode == null || strValidCode.length() < 6 || !isAllDigit) {
                    Toast.makeText(CloudStorageActivity.this, CloudStorageActivity.this.getString(C0470R.string.str_valid_code_6_digits), 0).show();
                    return;
                }
                CloudStorageActivity.this.mLoadType = 1;
                CloudStorageActivity.this.loadingDialog.show();
                new UnBindServiceThread(strValidCode).start();
                return;
            }
            CloudStorageActivity.this.mLoadType = 1;
            CloudStorageActivity.this.loadingDialog.show();
            new UnBindServiceThread(null).start();
        }
    }

    class C02636 implements OnShowListener {
        C02636() {
        }

        public void onShow(DialogInterface dialog) {
            ((TextView) CloudStorageActivity.this.loadingView.findViewById(C0470R.id.loginText)).setText(CloudStorageActivity.this.getString(C0470R.string.loading));
        }
    }

    class C02647 implements OnDismissListener {
        C02647() {
        }

        public void onDismiss(DialogInterface dialog) {
            CloudStorageActivity cloudStorageActivity;
            if (CloudStorageActivity.this.mIsLoadingServiceInfo) {
                cloudStorageActivity = CloudStorageActivity.this;
                cloudStorageActivity.m_n_GetServiceInfoThreadId = cloudStorageActivity.m_n_GetServiceInfoThreadId + 1;
                CloudStorageActivity.this.mIsLoadingServiceInfo = false;
                CloudStorageActivity.this.startActivity(new Intent(CloudStorageActivity.this, HomePageActivity.class));
                LocalDefines.B_UPDATE_LISTVIEW = true;
                LocalDefines.sCloudStorageActivity = null;
                CloudStorageActivity.this.finish();
            }
            cloudStorageActivity = CloudStorageActivity.this;
            cloudStorageActivity.m_nThreadID = cloudStorageActivity.m_nThreadID + 1;
        }
    }

    class C02658 implements OnShowListener {
        private Button btnDeviceSelectCancel;

        C02658() {
        }

        public void onShow(DialogInterface dialog) {
            this.btnDeviceSelectCancel = (Button) CloudStorageActivity.this.deviceSelectConctentView.findViewById(C0470R.id.btnDeviceSelectCancel);
            this.btnDeviceSelectCancel.setOnClickListener(CloudStorageActivity.this);
        }
    }

    class C02669 implements OnDismissListener {
        C02669() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    private class ActiveToBindService extends Thread {
        private int nActiveToBindServiceID;
        private int serviceId;

        public ActiveToBindService(int m_nActiveToBindServiceID, int serviceId) {
            this.nActiveToBindServiceID = m_nActiveToBindServiceID;
            this.serviceId = serviceId;
        }

        public void run() {
            super.run();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            int result = CloudServiceHelper.activateService(this.nActiveToBindServiceID, CloudStorageActivity.this.mDeviceId, CloudStorageActivity.this.mDevice.getStrUsername(), CloudStorageActivity.this.mDevice.getStrPassword(), CloudStorageActivity.this.mAccesstoken, CloudStorageActivity.this.mUserId, this.serviceId, CloudStorageActivity.this.mHandler, CloudStorageActivity.this.mDevice);
            if (result != 256) {
                Message message = CloudStorageActivity.this.mHandler.obtainMessage();
                message.what = 1005;
                message.obj = Integer.valueOf(result);
                CloudStorageActivity.this.mHandler.sendMessage(message);
            }
        }
    }

    private class BindToDeviceThread extends Thread {
        private int nBindToDeviceThreadID;
        private int serviceId;

        public BindToDeviceThread(int m_nBindToDeviceThreadID, int serviceId) {
            this.nBindToDeviceThreadID = m_nBindToDeviceThreadID;
            this.serviceId = serviceId;
        }

        public void run() {
            super.run();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            int result = CloudServiceHelper.getDeviceToken(this.nBindToDeviceThreadID, CloudStorageActivity.this.mDeviceId, CloudStorageActivity.this.mDevice.getStrUsername(), CloudStorageActivity.this.mDevice.getStrPassword(), CloudStorageActivity.this.mAccesstoken, CloudStorageActivity.this.mUserId, this.serviceId, CloudStorageActivity.this.mHandler, CloudStorageActivity.this.mDevice);
            System.out.println("result == " + result);
            if (result != 256) {
                Message message = CloudStorageActivity.this.mHandler.obtainMessage();
                message.what = 1004;
                message.obj = Integer.valueOf(result);
                CloudStorageActivity.this.mHandler.sendMessage(message);
            }
        }
    }

    private class BindToServerThread extends Thread {
        private String accessToken;
        private int deviceId;
        private String deviceToken;
        private int serviceId;

        public BindToServerThread(String accessToken, int serviceId, int deviceId, String deviceToken) {
            this.accessToken = accessToken;
            this.serviceId = serviceId;
            this.deviceId = deviceId;
            this.deviceToken = deviceToken;
        }

        public void run() {
            super.run();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                CloudStorageActivity.this.preBindService(this.accessToken, this.serviceId, this.deviceId, this.deviceToken);
                System.out.println("accessToken + deviceToken ==" + this.accessToken + " " + this.deviceToken);
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
    }

    private class GetServiceInfoThread extends Thread {
        private int n_GetServiceInfoThreadId;
        private int n_ServiceId;

        public GetServiceInfoThread(int serviceId, int m_n_GetServiceInfoThreadId) {
            this.n_ServiceId = serviceId;
            this.n_GetServiceInfoThreadId = m_n_GetServiceInfoThreadId;
        }

        public void run() {
            if (CloudStorageActivity.this.m_n_GetServiceInfoThreadId == this.n_GetServiceInfoThreadId) {
                try {
                    Thread.sleep(500);
                    long timeStamp = System.currentTimeMillis() / 1000;
                    String md5Sign = LocalDefines.md5("accesstoken=" + CloudStorageActivity.this.mAccesstoken + "&serviceid=" + this.n_ServiceId + "&timestamp=" + timeStamp + "hsshop2016");
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("sign", md5Sign);
                    jsonObject.put("timestamp", String.valueOf(timeStamp));
                    jsonObject.put("accesstoken", CloudStorageActivity.this.mAccesstoken);
                    jsonObject.put("serviceid", this.n_ServiceId);
                    String strResult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/service/info", jsonObject.toString());
                    if (strResult != null && strResult.length() > 0) {
                        int resultCode;
                        Message msg = CloudStorageActivity.this.mHandler.obtainMessage();
                        int errorCode = 0;
                        if (strResult.equals("-1")) {
                            resultCode = -1;
                        } else {
                            JSONObject resultJson = new JSONObject(strResult);
                            resultCode = resultJson.getInt("result");
                            errorCode = resultJson.getInt("error_code");
                            if (resultCode == 0) {
                                JSONObject object = (JSONObject) resultJson.get("data");
                                CloudStorageActivity.this.mCloudService = new CloudService(object.getInt("service_id"), object.getInt("product_id"), object.getString("begin_time"), object.getString("end_time"), object.getInt("record_save_day"), object.getInt("record_resolution"), object.getString("record_resolution_name"), object.getString("device_id"), object.getInt("bind_status"), object.getString("bind_status_name"), object.getString("introduction"));
                            }
                        }
                        msg.what = CloudStorageActivity.HANDLE_GET_SERVICE_INFO;
                        msg.arg1 = resultCode;
                        msg.arg2 = errorCode;
                        if (CloudStorageActivity.this.m_n_GetServiceInfoThreadId == this.n_GetServiceInfoThreadId) {
                            CloudStorageActivity.this.mHandler.sendMessage(msg);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    class GetServiceListThread extends Thread {
        private int nGetServiceListThreadId;

        public GetServiceListThread(int m_nGetServiceListThreadId) {
            this.nGetServiceListThreadId = m_nGetServiceListThreadId;
        }

        public void run() {
            super.run();
            try {
                CloudStorageActivity.this.getServiceList();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class GetValidCodeThread extends Thread {
        public void run() {
            super.run();
            try {
                CloudStorageActivity.this.getVerifyCodeData();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class RecFileListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            TextView tvInfo;
            TextView tvName;
            TextView tvSize;
            TextView tvTimeLen;

            private ItemViewHolder() {
            }
        }

        public RecFileListViewAdapter(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.recfile_list_item_cloud, null);
                this.holder = new ItemViewHolder();
                convertView.setTag(this.holder);
            }
            this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[0]);
            this.holder.tvInfo = (TextView) convertView.findViewById(this.valueViewID[1]);
            this.holder.tvSize = (TextView) convertView.findViewById(this.valueViewID[2]);
            this.holder.tvTimeLen = (TextView) convertView.findViewById(this.valueViewID[3]);
            HashMap<String, Object> map = (HashMap) this.mAppList.get(position);
            if (map != null) {
                String strSize = (String) map.get("FileSize");
                String strTimeLen = (String) map.get("FileTimeLen");
                String info = (String) map.get("FileName");
                this.holder.tvName.setText((String) map.get("FileStartTime"));
                this.holder.tvTimeLen.setText(strTimeLen);
                this.holder.tvSize.setText(strSize);
                this.holder.tvInfo.setText(info);
            }
            return convertView;
        }
    }

    public class RecFileSearcher extends Thread {
        private DeviceInfo info = null;
        private int nSearchType = 0;
        private int nThreadID = 0;

        public RecFileSearcher(DeviceInfo info, int nSearchType, int nThreadID) {
            this.nSearchType = nSearchType;
            this.info = info;
            this.nThreadID = nThreadID;
        }

        public void run() {
            int nResult = CloudServiceHelper.Cloud_getRecordFileServer(0, CloudStorageActivity.this.mAccesstoken, CloudStorageActivity.this.mUserId, CloudStorageActivity.this.mHandler, (long) CloudStorageActivity.this.mDeviceId, CloudStorageActivity.this.mEcsIP, CloudStorageActivity.this.mEcsPort, 0, this.nSearchType, CloudStorageActivity.this.nYear, CloudStorageActivity.this.nMonth, CloudStorageActivity.this.nDay, CloudStorageActivity.this.nStartHour, CloudStorageActivity.this.nStartMin, CloudStorageActivity.this.nStartSec, CloudStorageActivity.this.nEndHour, CloudStorageActivity.this.nEndMin, CloudStorageActivity.this.nEndSec);
            if (nResult != 256 && CloudStorageActivity.this.m_nThreadID == CloudStorageActivity.this.mGetRecFileId) {
                Message msg = CloudStorageActivity.this.mHandler.obtainMessage();
                msg.arg1 = 259;
                msg.arg2 = nResult;
                CloudStorageActivity.this.mHandler.sendMessage(msg);
            }
        }
    }

    class ServiceListViewAdapter extends BaseAdapter {
        private ViewHolder holder;
        private Context mContext;
        private List<CloudService> mServiceList;

        class ViewHolder {
            Button btnBind;
            TextView tvServiceName;

            ViewHolder() {
            }
        }

        public ServiceListViewAdapter(Context context, List<CloudService> data) {
            this.mContext = context;
            this.mServiceList = data;
        }

        public int getCount() {
            return this.mServiceList.size();
        }

        public Object getItem(int position) {
            return this.mServiceList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(this.mContext, C0470R.layout.service_list_item, null);
                this.holder = new ViewHolder();
                this.holder.tvServiceName = (TextView) convertView.findViewById(C0470R.id.tv_service_name);
                this.holder.btnBind = (Button) convertView.findViewById(C0470R.id.btn_bind);
                convertView.setTag(this.holder);
            } else {
                this.holder = (ViewHolder) convertView.getTag();
            }
            this.holder.tvServiceName.setText(String.valueOf(((CloudService) this.mServiceList.get(position)).getIntroduction()));
            this.holder.btnBind.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    CloudStorageActivity.this.mCloudService = (CloudService) ServiceListViewAdapter.this.mServiceList.get(position);
                    CloudStorageActivity.this.bindDialog.show();
                    CloudStorageActivity.this.tv_connect_to_device.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_device_ing));
                    CloudStorageActivity.this.iv_connect_to_device.setBackgroundResource(C0470R.drawable.pot_loading_animation_list);
                    ((AnimationDrawable) CloudStorageActivity.this.iv_connect_to_device.getBackground()).start();
                    CloudStorageActivity.this.tv_connect_to_server.setText(CloudStorageActivity.this.getString(C0470R.string.str_connect_to_server_wait));
                    CloudStorageActivity.this.iv_connect_to_server.setBackgroundResource(C0470R.drawable.device_status_off);
                    new BindToDeviceThread(CloudStorageActivity.this.m_nBindToDeviceThreadID, ((CloudService) ServiceListViewAdapter.this.mServiceList.get(position)).getService_id()).start();
                }
            });
            return convertView;
        }
    }

    class TimeCountDown extends CountDownTimer {
        private Button bindButton;

        public TimeCountDown(long millisInFuture, long countDownInterval, Button bindView) {
            super(millisInFuture, countDownInterval);
            this.bindButton = bindView;
        }

        public void onFinish() {
            cancel();
            this.bindButton.setText(C0470R.string.str_verify_code);
            CloudStorageActivity.this.mCountDownTime = 60000;
            this.bindButton.setClickable(true);
            this.bindButton.setBackground(CloudStorageActivity.this.getResources().getDrawable(C0470R.drawable.verification_code_send));
            this.bindButton.setTextColor(CloudStorageActivity.this.getResources().getColor(C0470R.color.font_color_sky_blue));
        }

        public void onTick(long millisUntilFinished) {
            this.bindButton.setClickable(false);
            this.bindButton.setText((millisUntilFinished / 1000) + "s");
            CloudStorageActivity cloudStorageActivity = CloudStorageActivity.this;
            cloudStorageActivity.mCountDownTime = cloudStorageActivity.mCountDownTime - 1000;
        }
    }

    private class UnBindServiceThread extends Thread {
        String validcode;

        public UnBindServiceThread(String validcode) {
            this.validcode = validcode;
        }

        public void run() {
            super.run();
            try {
                CloudStorageActivity.this.unbindServiceFromPhone(this.validcode);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_cloud_storage);
        this.contentView = View.inflate(this, C0470R.layout.activity_cloud_storage, null);
        Intent intent = getIntent();
        if (intent != null) {
            this.mDeviceId = intent.getIntExtra(Constants.FLAG_DEVICE_ID, -1);
            this.mProductId = intent.getIntExtra("productId", 0);
            this.mPosition = intent.getIntExtra("position", 0);
            this.mDevice = (DeviceInfo) LocalDefines._severInfoListData.get(this.mPosition);
        }
        this.shareToken = getSharedPreferences("SaveSign", 0);
        this.mAccesstoken = this.shareToken.getString("saveToken", Constants.MAIN_VERSION_TAG);
        this.mUserId = this.shareToken.getInt("saveServeruserid", -101);
        this.mEcsIP = this.shareToken.getString("saveloginEcsIp", Constants.MAIN_VERSION_TAG);
        this.mEcsIP2 = this.shareToken.getString("saveloginEcsIp2", Constants.MAIN_VERSION_TAG);
        this.mEcsPort = this.shareToken.getInt("saveloginEcsport", 0);
        this.mEcsPort2 = this.shareToken.getInt("saveloginEcsport2", 0);
        this.mSaveLoginWay = this.shareToken.getInt("saveloginway", 1);
        if (!this.isInit) {
            Calendar calendar = Calendar.getInstance();
            this.nYear = (short) calendar.get(1);
            this.nMonth = (short) calendar.get(2);
            this.nDay = (short) calendar.get(5);
            this.nStartHour = (short) 0;
            this.nStartMin = (short) 0;
            this.nStartSec = (short) 0;
            this.nEndHour = (short) 23;
            this.nEndMin = (short) 59;
            this.nEndSec = (short) 0;
            this.isInit = true;
        }
        initViews();
        if (this.mProductId == 0) {
            this.m_nGetServiceListThreadId++;
            this.mProgressBar.setVisibility(0);
            new GetServiceListThread(this.m_nGetServiceListThreadId).start();
        } else {
            this.m_n_GetServiceInfoThreadId++;
            this.mIsLoadingServiceInfo = true;
            this.loadingDialog.show();
            this.mScrollView.setVisibility(8);
            new GetServiceInfoThread(Math.abs(this.mProductId), this.m_n_GetServiceInfoThreadId).start();
        }
        LocalDefines.sCloudStorageActivity = this;
    }

    private void initViews() {
        this.mScrollView = (ScrollView) findViewById(C0470R.id.id_scroll_view);
        this.mUnbindServiceListLayout = (RelativeLayout) findViewById(C0470R.id.rl_unbind_service_list_layout);
        this.mLayoutCloudStorage = (LinearLayout) findViewById(C0470R.id.ll_cloud_storage);
        this.mLayoutSearchCloudRecordFile = (LinearLayout) findViewById(C0470R.id.ll_cloud_record);
        showCloudStorageLayout();
        this.mBtnBack = (ImageView) findViewById(C0470R.id.btnCloudStorageBack);
        this.mBtnBack.setOnClickListener(this);
        this.mHint = (TextView) findViewById(C0470R.id.tv_hint);
        this.mUnbindService = (TextView) findViewById(C0470R.id.tv_unbind_service_list);
        this.mGetResultError = (TextView) findViewById(C0470R.id.tv_result);
        this.mGetResultError.setVisibility(8);
        this.mProgressBar = (ProgressBar) findViewById(C0470R.id.id_progress_bar);
        this.mProgressBar.setVisibility(8);
        this.mBtnUnBind = (Button) findViewById(C0470R.id.btn_unbind);
        this.mBtnUnBind.setOnClickListener(this);
        this.mBtnSearchRecordFiles = (Button) findViewById(C0470R.id.btn_search_record_files);
        this.mBtnSearchRecordFiles.setOnClickListener(this);
        if (this.mProductId == 0) {
            this.mHint.setText(this.mDeviceId + " " + getString(C0470R.string.str_device_not_bind_service));
            this.mBtnUnBind.setVisibility(8);
            this.mBtnSearchRecordFiles.setVisibility(8);
            this.mUnbindServiceListLayout.setVisibility(0);
        } else if (this.mProductId < 0) {
            this.mHint.setText(this.mDeviceId + " " + getString(C0470R.string.str_device_service_outofdate));
            this.mBtnUnBind.setVisibility(0);
            this.mBtnSearchRecordFiles.setVisibility(0);
            this.mUnbindServiceListLayout.setVisibility(8);
        } else {
            this.mHint.setText(this.mDeviceId + " " + getString(C0470R.string.str_device_has_bind_service));
            this.mBtnUnBind.setVisibility(0);
            this.mBtnSearchRecordFiles.setVisibility(0);
            this.mUnbindServiceListLayout.setVisibility(8);
        }
        this.mPurchaseService = (LinearLayout) findViewById(C0470R.id.ll_purchase_service);
        this.mPurchaseService.setOnClickListener(this);
        this.mRenewService = (LinearLayout) findViewById(C0470R.id.ll_renew_service);
        this.mRenewService.setOnClickListener(this);
        int height_in_px = (int) ((((float) 200) * getResources().getDisplayMetrics().density) + 0.5f);
        this.mServiceListView = (InnerListView) findViewById(C0470R.id.service_list);
        this.mServiceListView.setMaxHeight(height_in_px);
        this.mServiceListView.setAdapter(this.mAdapter);
        this.mServiceListView.setParentScrollView(this.mScrollView);
        createBindDialog();
        createUnBindDialog(this.mDeviceId, this.mAccesstoken);
        createLoadingDialog();
        initCloudSearchRecordFileView();
        this.tvError = (TextView) findViewById(C0470R.id.tv_error);
        this.tvError.setVisibility(8);
    }

    private void initCloudSearchRecordFileView() {
        this.tvDeviceId = (TextView) findViewById(C0470R.id.tv_device_id);
        this.tvDeviceId.setText(String.valueOf(getString(C0470R.string.str_cloud_record_search) + this.mDeviceId));
        this.tvRecordType = (TextView) findViewById(C0470R.id.tvRecordType);
        this.tvDate = (TextView) findViewById(C0470R.id.tvDate);
        this.tvStartTime = (TextView) findViewById(C0470R.id.tvStartTime);
        this.tvEndTime = (TextView) findViewById(C0470R.id.tvEndTime);
        this.btnSearch = (Button) findViewById(C0470R.id.btnSearch);
        this.btnSearch.setOnClickListener(this);
        this.ll_type_all = (LinearLayout) findViewById(C0470R.id.ll_type_all);
        this.ll_type_all.setOnClickListener(this);
        this.ll_type_auto = (LinearLayout) findViewById(C0470R.id.ll_type_auto);
        this.ll_type_auto.setOnClickListener(this);
        this.ll_type_alarm = (LinearLayout) findViewById(C0470R.id.ll_type_alarm);
        this.ll_type_alarm.setOnClickListener(this);
        this.iv_type_all = (ImageView) findViewById(C0470R.id.iv_type_all);
        this.iv_type_auto = (ImageView) findViewById(C0470R.id.iv_type_auto);
        this.iv_type_alarm = (ImageView) findViewById(C0470R.id.iv_type_alarm);
        this.ll_search_date = (LinearLayout) findViewById(C0470R.id.ll_search_date);
        this.ll_search_date.setOnClickListener(this);
        this.ll_search_start_time = (LinearLayout) findViewById(C0470R.id.ll_search_start_time);
        this.ll_search_start_time.setOnClickListener(this);
        this.ll_search_end_time = (LinearLayout) findViewById(C0470R.id.ll_search_end_time);
        this.ll_search_end_time.setOnClickListener(this);
        if (this.nMonth < (short) 9 && this.nDay < (short) 10) {
            this.tvDate.setText(this.nYear + "-0" + (this.nMonth + 1) + "-0" + this.nDay);
        } else if (this.nMonth >= (short) 9 && this.nDay < (short) 10) {
            this.tvDate.setText(this.nYear + "-" + (this.nMonth + 1) + "-0" + this.nDay);
        } else if (this.nMonth >= (short) 9 || this.nDay < (short) 10) {
            this.tvDate.setText(this.nYear + "-" + (this.nMonth + 1) + "-" + this.nDay);
        } else {
            this.tvDate.setText(this.nYear + "-0" + (this.nMonth + 1) + "-" + this.nDay);
        }
        if (this.nStartHour <= (short) 9 && this.nStartMin <= (short) 9) {
            this.tvStartTime.setText("0" + this.nStartHour + ":0" + this.nStartMin);
        } else if (this.nStartHour <= (short) 9 && this.nStartMin > (short) 9) {
            this.tvStartTime.setText("0" + this.nStartHour + ":" + this.nStartMin);
        } else if (this.nStartHour <= (short) 9 || this.nStartMin > (short) 9) {
            this.tvStartTime.setText(this.nStartHour + ":" + this.nStartMin);
        } else {
            this.tvStartTime.setText(this.nStartHour + ":0" + this.nStartMin);
        }
        if (this.nEndHour <= (short) 9 && this.nStartMin <= (short) 9) {
            this.tvEndTime.setText("0" + this.nEndHour + ":0" + this.nEndMin);
        } else if (this.nEndHour <= (short) 9 && this.nStartMin > (short) 9) {
            this.tvEndTime.setText("0" + this.nEndHour + ":" + this.nEndMin);
        } else if (this.nEndHour <= (short) 9 || this.nEndMin > (short) 9) {
            this.tvEndTime.setText(this.nEndHour + ":" + this.nEndMin);
        } else {
            this.tvEndTime.setText(this.nEndHour + ":0" + this.nEndMin);
        }
        switch (this.nSearchType) {
            case 0:
                this.iv_type_all.setImageResource(C0470R.drawable.radio_select_check);
                this.iv_type_auto.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.iv_type_alarm.setImageResource(C0470R.drawable.radio_select_uncheck);
                break;
            case 1:
                this.iv_type_all.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.iv_type_auto.setImageResource(C0470R.drawable.radio_select_check);
                this.iv_type_alarm.setImageResource(C0470R.drawable.radio_select_uncheck);
                break;
            case 3:
                this.iv_type_all.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.iv_type_auto.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.iv_type_alarm.setImageResource(C0470R.drawable.radio_select_check);
                break;
        }
        this.recFileListView = (ListView) findViewById(C0470R.id.recfile_list);
        this.recFileListView.setOnItemClickListener(this);
        this.recFileListView.setVisibility(8);
        createDialogs();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.btnCloudStorageBack:
                if (this.showRecordFileListLayout) {
                    showScrollViewLayout();
                    return;
                } else if (this.showSearchRecordFileLayout) {
                    showCloudStorageLayout();
                    return;
                } else {
                    startActivity(new Intent(this, HomePageActivity.class));
                    LocalDefines.B_UPDATE_LISTVIEW = true;
                    LocalDefines.sCloudStorageActivity = null;
                    finish();
                    return;
                }
            case C0470R.id.btn_unbind:
                showUnbindConfirmDialog();
                return;
            case C0470R.id.btn_search_record_files:
                showSearchRecordFileLayout();
                return;
            case C0470R.id.ll_purchase_service:
                Intent intent1 = new Intent(this, WeChatWebViewActivity.class);
                intent1.putExtra("url", new StringBuilder(LocalDefines.CLOUD_STORE_URL).append(this.mAccesstoken).append("&ver=").append(1).toString());
                startActivityForResult(intent1, 12);
                return;
            case C0470R.id.ll_renew_service:
                Intent intent2 = new Intent(this, WeChatWebViewActivity.class);
                intent2.putExtra("url", "http://www.av380.net/user/service-list?access_token=" + this.mAccesstoken + "&ver=" + 1);
                startActivityForResult(intent2, 12);
                return;
            case C0470R.id.ll_type_all:
                this.nSearchType = 0;
                this.tvRecordType.setText(getString(C0470R.string.AllPlayBack));
                this.iv_type_all.setImageResource(C0470R.drawable.radio_select_check);
                this.iv_type_auto.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.iv_type_alarm.setImageResource(C0470R.drawable.radio_select_uncheck);
                return;
            case C0470R.id.ll_type_auto:
                this.nSearchType = 0;
                this.tvRecordType.setText(getString(C0470R.string.record_auto_record_title));
                this.iv_type_all.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.iv_type_auto.setImageResource(C0470R.drawable.radio_select_check);
                this.iv_type_alarm.setImageResource(C0470R.drawable.radio_select_uncheck);
                return;
            case C0470R.id.ll_type_alarm:
                this.nSearchType = 0;
                this.tvRecordType.setText(getString(C0470R.string.record_alarm_record_title));
                this.iv_type_all.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.iv_type_auto.setImageResource(C0470R.drawable.radio_select_uncheck);
                this.iv_type_alarm.setImageResource(C0470R.drawable.radio_select_check);
                return;
            case C0470R.id.ll_search_date:
                ShowDateSelectView();
                return;
            case C0470R.id.ll_search_start_time:
                ShowStartTimeSelectView();
                return;
            case C0470R.id.ll_search_end_time:
                ShowEndTimeSelectView();
                return;
            case C0470R.id.btnSearch:
                showRecordFileListLayout();
                GetRecFileList();
                return;
            case C0470R.id.btnDatetimeSelectCancel:
                this.nDatetimeMode = 0;
                if (this.datetimeSelectDialog != null && this.datetimeSelectDialog.isShowing()) {
                    this.datetimeSelectDialog.dismiss();
                    return;
                }
                return;
            case C0470R.id.btnDatetimeSelectOK:
                String strHour;
                String strMinute;
                Toast toast;
                switch (this.nDatetimeMode) {
                    case 100:
                        this.nYear = (short) this.mSelectDatePicker.getYear();
                        this.nMonth = (short) this.mSelectDatePicker.getMonth();
                        this.nDay = (short) this.mSelectDatePicker.getDayOfMonth();
                        if (this.nMonth >= (short) 9 || this.nDay >= (short) 10) {
                            if (this.nMonth < (short) 9 || this.nDay >= (short) 10) {
                                if (this.nMonth < (short) 9 && this.nDay >= (short) 10) {
                                    this.tvDate.setText(this.nYear + "-0" + (this.nMonth + 1) + "-" + this.nDay);
                                    break;
                                } else {
                                    this.tvDate.setText(this.nYear + "-" + (this.nMonth + 1) + "-" + this.nDay);
                                    break;
                                }
                            }
                            this.tvDate.setText(this.nYear + "-" + (this.nMonth + 1) + "-0" + this.nDay);
                            break;
                        }
                        this.tvDate.setText(this.nYear + "-0" + (this.nMonth + 1) + "-0" + this.nDay);
                        break;
                        break;
                    case 101:
                        if (this.mSelectTimePicker.getCurrentHour().intValue() <= this.nEndHour && (this.mSelectTimePicker.getCurrentHour().intValue() != this.nEndHour || this.mSelectTimePicker.getCurrentMinute().intValue() <= this.nEndMin)) {
                            this.nStartHour = (short) this.mSelectTimePicker.getCurrentHour().intValue();
                            this.nStartMin = (short) this.mSelectTimePicker.getCurrentMinute().intValue();
                            this.nStartSec = (short) 0;
                            strHour = Constants.MAIN_VERSION_TAG;
                            strMinute = Constants.MAIN_VERSION_TAG;
                            if (this.nStartHour < (short) 10) {
                                strHour = "0" + this.nStartHour;
                            } else {
                                strHour = this.nStartHour;
                            }
                            if (this.nStartMin < (short) 10) {
                                strMinute = "0" + this.nStartMin;
                            } else {
                                strMinute = this.nStartMin;
                            }
                            this.tvStartTime.setText(new StringBuilder(String.valueOf(strHour)).append(":").append(strMinute).toString());
                            break;
                        }
                        toast = Toast.makeText(getApplicationContext(), getString(C0470R.string.noticStartlargeThanEnd), 0);
                        toast.setGravity(17, 0, 0);
                        toast.show();
                        break;
                        break;
                    case 102:
                        if (this.mSelectTimePicker.getCurrentHour().intValue() >= this.nStartHour && (this.mSelectTimePicker.getCurrentHour().intValue() != this.nStartHour || this.mSelectTimePicker.getCurrentMinute().intValue() >= this.nStartMin)) {
                            this.nEndHour = (short) this.mSelectTimePicker.getCurrentHour().intValue();
                            this.nEndMin = (short) this.mSelectTimePicker.getCurrentMinute().intValue();
                            this.nEndSec = (short) 0;
                            strHour = Constants.MAIN_VERSION_TAG;
                            strMinute = Constants.MAIN_VERSION_TAG;
                            if (this.nEndHour < (short) 10) {
                                strHour = "0" + this.nEndHour;
                            } else {
                                strHour = this.nEndHour;
                            }
                            if (this.nEndMin < (short) 10) {
                                strMinute = "0" + this.nEndMin;
                            } else {
                                strMinute = this.nEndMin;
                            }
                            this.tvEndTime.setText(new StringBuilder(String.valueOf(strHour)).append(":").append(strMinute).toString());
                            break;
                        }
                        toast = Toast.makeText(getApplicationContext(), getString(C0470R.string.noticEndLessThanStart), 0);
                        toast.setGravity(17, 0, 0);
                        toast.show();
                        break;
                        break;
                }
                this.nDatetimeMode = 0;
                if (this.datetimeSelectDialog != null && this.datetimeSelectDialog.isShowing()) {
                    this.datetimeSelectDialog.dismiss();
                    return;
                }
                return;
            case C0470R.id.btnDeviceSelectCancel:
                if (this.deviceSelectDialog != null && this.deviceSelectDialog.isShowing()) {
                    this.deviceSelectDialog.dismiss();
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void showUnbindConfirmDialog() {
        View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
        TextView tv_title = (TextView) view.findViewById(C0470R.id.tv_title);
        tv_title.setText(getString(C0470R.string.str_unbind_confirm));
        tv_title.setTextSize(18.0f);
        tv_title.setGravity(17);
        tv_title.setPadding(40, 0, 40, 0);
        ((TextView) view.findViewById(C0470R.id.tv_content)).setVisibility(8);
        new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C02592()).setNegativeButton(getString(C0470R.string.alert_btn_Cancel), null).show();
    }

    private void showSearchRecordFileLayout() {
        this.showSearchRecordFileLayout = true;
        this.mLayoutCloudStorage.setVisibility(8);
        this.mLayoutSearchCloudRecordFile.setVisibility(0);
    }

    private void showCloudStorageLayout() {
        this.showSearchRecordFileLayout = false;
        this.mLayoutCloudStorage.setVisibility(0);
        this.mLayoutSearchCloudRecordFile.setVisibility(8);
    }

    private void showScrollViewLayout() {
        this.showRecordFileListLayout = false;
        this.mScrollView.setVisibility(0);
        this.recFileListView.setVisibility(8);
    }

    private void showRecordFileListLayout() {
        this.showRecordFileListLayout = true;
        this.mScrollView.setVisibility(8);
        this.recFileListView.setVisibility(0);
    }

    private void getServiceList() throws JSONException {
        long timeStamp = System.currentTimeMillis() / 1000;
        String md5Sign = LocalDefines.md5("accesstoken=" + this.mAccesstoken + "&timestamp=" + timeStamp + "hsshop2016");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("sign", md5Sign);
        jsonObject.put("timestamp", String.valueOf(timeStamp));
        jsonObject.put("accesstoken", this.mAccesstoken);
        String strResult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/service/list", jsonObject.toString());
        if (strResult != null && strResult.length() > 0) {
            if (strResult.equals("-1")) {
                runOnUiThread(new C02603());
                return;
            }
            JSONObject resultJson = new JSONObject(strResult);
            int result = resultJson.getInt("result");
            int error_code = resultJson.getInt("error_code");
            if (result == 0) {
                if (this.mServiceList == null) {
                    this.mServiceList = new ArrayList();
                } else {
                    this.mServiceList.clear();
                }
                JSONArray array = resultJson.getJSONArray("data");
                for (int i = 0; i < array.length(); i++) {
                    JSONObject object = (JSONObject) array.get(i);
                    int service_id = object.getInt("service_id");
                    int product_id = object.getInt("product_id");
                    String begin_time = object.getString("begin_time");
                    String end_time = object.getString("end_time");
                    int record_save_day = object.getInt("record_save_day");
                    int record_resolution = object.getInt("record_resolution");
                    String record_resolution_name = object.getString("record_resolution_name");
                    String device_id = object.getString("device_id");
                    int bind_status = object.getInt("bind_status");
                    CloudService service = new CloudService(service_id, product_id, begin_time, end_time, record_save_day, record_resolution, record_resolution_name, device_id, bind_status, object.getString("bind_status_name"), object.getString("introduction"));
                    boolean isOutOfDate = getIsServiceOutOfDate(end_time);
                    if (!(bind_status == 20 || isOutOfDate)) {
                        this.mServiceList.add(service);
                    }
                }
            }
            Message message = this.mHandler.obtainMessage();
            message.what = HANDLE_GET_SERVICE_LIST;
            message.arg1 = result;
            message.arg2 = error_code;
            this.mHandler.sendMessage(message);
        }
    }

    private boolean getIsServiceOutOfDate(String strEndTime) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
        try {
            return sdf.parse(sdf.format(new Date())).compareTo(sdf.parse(strEndTime)) > 0;
        } catch (ParseException e1) {
            e1.printStackTrace();
            return false;
        }
    }

    private void updateServiceListView() {
        if (this.mAdapter == null) {
            this.mAdapter = new ServiceListViewAdapter(this, this.mServiceList);
            this.mServiceListView.setAdapter(this.mAdapter);
            return;
        }
        this.mAdapter.notifyDataSetChanged();
    }

    private void createBindDialog() {
        View view = View.inflate(this, C0470R.layout.bind_service_dialog, null);
        this.tv_connect_to_device = (TextView) view.findViewById(C0470R.id.tv_connect_to_device);
        this.tv_connect_to_server = (TextView) view.findViewById(C0470R.id.tv_connect_to_server);
        this.iv_connect_to_device = (ImageView) view.findViewById(C0470R.id.iv_connect_to_device);
        this.iv_connect_to_server = (ImageView) view.findViewById(C0470R.id.iv_connect_to_server);
        this.bindDialog = new Builder(this).setView(view).create();
        this.bindDialog.setCanceledOnTouchOutside(false);
        this.bindDialog.setCancelable(false);
    }

    private void createUnBindDialog(int deviceId, String accessToken) {
        View view = View.inflate(this, C0470R.layout.unbind_service_dialog, null);
        LinearLayout llUnbindFromPhone = (LinearLayout) view.findViewById(C0470R.id.ll_unbind_from_phone);
        LinearLayout llUnbindFromMail = (LinearLayout) view.findViewById(C0470R.id.ll_unbind_from_mail);
        if (this.mSaveLoginWay == 1) {
            llUnbindFromPhone.setVisibility(0);
            llUnbindFromMail.setVisibility(8);
        } else {
            llUnbindFromPhone.setVisibility(8);
            llUnbindFromMail.setVisibility(0);
        }
        this.etValidCode = (EditText) view.findViewById(C0470R.id.et_valid_code);
        this.btnGetValidCode = (Button) view.findViewById(C0470R.id.btn_get_valid_code);
        this.btnGetValidCode.setOnClickListener(new C02614());
        this.unBindDialig = new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C02625()).setNegativeButton(getString(C0470R.string.alert_btn_Cancel), null).create();
        this.unBindDialig.setCancelable(false);
    }

    private void preBindService(String accessToken, int serviceId, int deviceId, String deviceToken) throws JSONException {
        long time = System.currentTimeMillis();
        String md5Sign = LocalDefines.md5("accesstoken=" + accessToken + "&deviceid=" + deviceId + "&devicetoken=" + deviceToken + "&serviceid=" + serviceId + "&timestamp=" + (time / 1000) + "hsshop2016");
        JSONObject json = new JSONObject();
        json.put("sign", md5Sign);
        json.put("timestamp", time / 1000);
        json.put("accesstoken", accessToken);
        json.put("deviceid", deviceId);
        json.put("devicetoken", deviceToken);
        json.put("serviceid", serviceId);
        String httpResult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/service/bind", json.toString());
        if (httpResult != null && httpResult.length() > 0) {
            Message msg;
            if (httpResult.equals("-1")) {
                msg = this.mHandler.obtainMessage();
                msg.what = 1001;
                msg.arg1 = -1;
                this.mHandler.sendMessage(msg);
                return;
            }
            JSONObject jsonObject = new JSONObject(httpResult);
            int resultCode = jsonObject.getInt("result");
            int errorCode = jsonObject.getInt("error_code");
            msg = this.mHandler.obtainMessage();
            msg.what = 1001;
            msg.arg1 = resultCode;
            msg.arg2 = errorCode;
            this.mHandler.sendMessage(msg);
        }
    }

    private void getVerifyCodeData() throws JSONException {
        long time = System.currentTimeMillis();
        String MDLoginSign = LocalDefines.md5("accesstoken=" + this.mAccesstoken + "&codetype=unbindservice" + "&timestamp=" + (time / 1000) + "hsshop2016");
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", (time / 1000));
        json.put("codetype", "unbindservice");
        json.put("accesstoken", this.mAccesstoken);
        String httpResult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/tool/send-user-valid-code", json.toString());
        if (httpResult == null) {
            return;
        }
        if (httpResult.equals("-1")) {
            Message message = this.mHandler.obtainMessage();
            message.what = 1003;
            message.arg1 = -1;
            this.mHandler.sendMessage(message);
            return;
        }
        JSONObject jsonResult = new JSONObject(httpResult);
        int resultCode = Integer.valueOf(jsonResult.getString("result")).intValue();
        int errorCode = jsonResult.getInt("error_code");
        message = this.mHandler.obtainMessage();
        message.what = 1003;
        message.arg1 = resultCode;
        message.arg2 = errorCode;
        this.mHandler.sendMessage(message);
    }

    private void unbindServiceFromPhone(String validcode) throws JSONException {
        String content;
        long time = System.currentTimeMillis();
        String validtype = Constants.MAIN_VERSION_TAG;
        String verifyCodeSign = Constants.MAIN_VERSION_TAG;
        String MDLoginSign;
        JSONObject json;
        if (this.mSaveLoginWay == 1) {
            validtype = "mobile";
            MDLoginSign = LocalDefines.md5("accesstoken=" + this.mAccesstoken + "&deviceid=" + this.mDeviceId + "&timestamp=" + (time / 1000) + "&validcode=" + validcode + "&validtype=" + validtype + "hsshop2016");
            json = new JSONObject();
            json.put("sign", MDLoginSign);
            json.put("timestamp", (time / 1000));
            json.put("deviceid", this.mDeviceId);
            json.put("accesstoken", this.mAccesstoken);
            json.put("validcode", validcode);
            json.put("validtype", validtype);
            content = json.toString();
        } else {
            validtype = "email";
            MDLoginSign = LocalDefines.md5("accesstoken=" + this.mAccesstoken + "&deviceid=" + this.mDeviceId + "&timestamp=" + (time / 1000) + "&validtype=" + validtype + "hsshop2016");
            json = new JSONObject();
            json.put("sign", MDLoginSign);
            json.put("timestamp", (time / 1000));
            json.put("deviceid", new StringBuilder(String.valueOf(this.mDeviceId)).toString());
            json.put("accesstoken", this.mAccesstoken);
            json.put("validtype", validtype);
            content = json.toString();
        }
        String httpResult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/service/mobile-unbind", content);
        if (httpResult != null && httpResult.length() > 0) {
            Message message;
            if (httpResult.equals("-1")) {
                message = this.mHandler.obtainMessage();
                message.what = 1002;
                message.arg1 = -1;
                this.mHandler.sendMessage(message);
                return;
            }
            JSONObject jsonResult = new JSONObject(httpResult);
            int resultCode = jsonResult.getInt("result");
            int errorCode = jsonResult.getInt("error_code");
            message = this.mHandler.obtainMessage();
            if (this.mSaveLoginWay == 1 && resultCode == 0) {
                message.obj = Integer.valueOf(jsonResult.getInt("update_timestamp"));
            }
            message.what = 1002;
            message.arg1 = resultCode;
            message.arg2 = errorCode;
            this.mHandler.sendMessage(message);
        }
    }

    public boolean isNumeric(String str) {
        if (Pattern.compile("[0-9]*").matcher(str).matches()) {
            return true;
        }
        return false;
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C02636());
        this.loadingDialog.setOnDismissListener(new C02647());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }

    private void createDialogs() {
        this.deviceSelectConctentView = LayoutInflater.from(this).inflate(C0470R.layout.devices_select_dialog, null);
        this.deviceSelectDialog = new Dialog(this, C0470R.style.selectorDialog);
        this.deviceSelectDialog.setContentView(this.deviceSelectConctentView);
        this.deviceSelectDialog.setOnShowListener(new C02658());
        this.deviceSelectDialog.setOnDismissListener(new C02669());
        this.datetimeSelectConctentView = LayoutInflater.from(this).inflate(C0470R.layout.datetime_select_dialog, null);
        this.datetimeSelectDialog = new Dialog(this, C0470R.style.dialog_bg_transparent);
        this.datetimeSelectDialog.setContentView(this.datetimeSelectConctentView);
        this.datetimeSelectDialog.setOnShowListener(new OnShowListener() {

            class C02551 implements OnDateChangedListener {
                C02551() {
                }

                public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    if (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1 < 10 && CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectDatePicker.getYear() + "-0" + (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1) + "-0" + CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth());
                    } else if (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1 >= 10 && CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectDatePicker.getYear() + "-" + (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1) + "-0" + CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth());
                    } else if (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1 >= 10 || CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectDatePicker.getYear() + "-" + (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1) + "-" + CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth());
                    } else {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectDatePicker.getYear() + "-0" + (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1) + "-" + CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth());
                    }
                }
            }

            class C02562 implements OnTimeChangedListener {
                C02562() {
                }

                public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                    if (hourOfDay < 10 && minute < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":0" + minute);
                    } else if (hourOfDay >= 10 && minute < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(hourOfDay + ":0" + minute);
                    } else if (hourOfDay >= 10 || minute < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(hourOfDay + ":" + minute);
                    } else {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":" + minute);
                    }
                }
            }

            class C02573 implements OnTimeChangedListener {
                C02573() {
                }

                public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                    if (hourOfDay < 10 && minute < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":0" + minute);
                    } else if (hourOfDay >= 10 && minute < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(hourOfDay + ":0" + minute);
                    } else if (hourOfDay >= 10 || minute < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(hourOfDay + ":" + minute);
                    } else {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":" + minute);
                    }
                }
            }

            public void onShow(DialogInterface dialog) {
                CloudStorageActivity.this.tvDateTimeTitle = (TextView) CloudStorageActivity.this.datetimeSelectConctentView.findViewById(C0470R.id.tvDateTimeTitle);
                CloudStorageActivity.this.tvDateTimeCurrent = (TextView) CloudStorageActivity.this.datetimeSelectConctentView.findViewById(C0470R.id.tvDateTimeCurrent);
                CloudStorageActivity.this.mSelectDatePicker = (DatePicker) CloudStorageActivity.this.datetimeSelectConctentView.findViewById(C0470R.id.mSelectDatePicker);
                CloudStorageActivity.this.mSelectTimePicker = (TimePicker) CloudStorageActivity.this.datetimeSelectConctentView.findViewById(C0470R.id.mSelectTimePicker);
                CloudStorageActivity.this.layoutDatePicker = (LinearLayout) CloudStorageActivity.this.datetimeSelectConctentView.findViewById(C0470R.id.layoutDatePicker);
                CloudStorageActivity.this.layoutTimePicker = (LinearLayout) CloudStorageActivity.this.datetimeSelectConctentView.findViewById(C0470R.id.layoutTimePicker);
                CloudStorageActivity.this.btnDatetimeSelectCancel = (Button) CloudStorageActivity.this.datetimeSelectConctentView.findViewById(C0470R.id.btnDatetimeSelectCancel);
                CloudStorageActivity.this.btnDatetimeSelectOK = (Button) CloudStorageActivity.this.datetimeSelectConctentView.findViewById(C0470R.id.btnDatetimeSelectOK);
                CloudStorageActivity.this.btnDatetimeSelectOK.setOnClickListener(CloudStorageActivity.this);
                CloudStorageActivity.this.btnDatetimeSelectCancel.setOnClickListener(CloudStorageActivity.this);
                if (CloudStorageActivity.this.nDatetimeMode == 100) {
                    CloudStorageActivity.this.tvDateTimeTitle.setText(C0470R.string.lblDate2);
                    CloudStorageActivity.this.layoutDatePicker.setVisibility(0);
                    CloudStorageActivity.this.layoutTimePicker.setVisibility(8);
                    CloudStorageActivity.this.mSelectDatePicker.init(CloudStorageActivity.this.nYear, CloudStorageActivity.this.nMonth, CloudStorageActivity.this.nDay, new C02551());
                    if (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1 < 10 && CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectDatePicker.getYear() + "-0" + (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1) + "-0" + CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth());
                    } else if (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1 >= 10 && CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectDatePicker.getYear() + "-" + (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1) + "-0" + CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth());
                    } else if (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1 >= 10 || CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectDatePicker.getYear() + "-" + (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1) + "-" + CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth());
                    } else {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectDatePicker.getYear() + "-0" + (CloudStorageActivity.this.mSelectDatePicker.getMonth() + 1) + "-" + CloudStorageActivity.this.mSelectDatePicker.getDayOfMonth());
                    }
                } else if (CloudStorageActivity.this.nDatetimeMode == 101) {
                    CloudStorageActivity.this.tvDateTimeTitle.setText(C0470R.string.lblStartTime2);
                    CloudStorageActivity.this.layoutDatePicker.setVisibility(8);
                    CloudStorageActivity.this.layoutTimePicker.setVisibility(0);
                    CloudStorageActivity.this.mSelectTimePicker.setIs24HourView(Boolean.valueOf(true));
                    CloudStorageActivity.this.mSelectTimePicker.setCurrentHour(Integer.valueOf(CloudStorageActivity.this.nStartHour));
                    CloudStorageActivity.this.mSelectTimePicker.setCurrentMinute(Integer.valueOf(CloudStorageActivity.this.nStartMin));
                    CloudStorageActivity.this.mSelectTimePicker.setOnTimeChangedListener(new C02562());
                    if (CloudStorageActivity.this.mSelectTimePicker.getCurrentHour().intValue() < 10 && CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText("0" + CloudStorageActivity.this.mSelectTimePicker.getCurrentHour() + ":0" + CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute());
                    } else if (CloudStorageActivity.this.mSelectTimePicker.getCurrentHour().intValue() >= 10 && CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectTimePicker.getCurrentHour() + ":0" + CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute());
                    } else if (CloudStorageActivity.this.mSelectTimePicker.getCurrentHour().intValue() >= 10 || CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectTimePicker.getCurrentHour() + ":" + CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute());
                    } else {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText("0" + CloudStorageActivity.this.mSelectTimePicker.getCurrentHour() + ":" + CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute());
                    }
                } else if (CloudStorageActivity.this.nDatetimeMode == 102) {
                    CloudStorageActivity.this.tvDateTimeTitle.setText(C0470R.string.lblEndTime2);
                    CloudStorageActivity.this.layoutDatePicker.setVisibility(8);
                    CloudStorageActivity.this.layoutTimePicker.setVisibility(0);
                    CloudStorageActivity.this.mSelectTimePicker.setIs24HourView(Boolean.valueOf(true));
                    CloudStorageActivity.this.mSelectTimePicker.setCurrentHour(Integer.valueOf(CloudStorageActivity.this.nEndHour));
                    CloudStorageActivity.this.mSelectTimePicker.setCurrentMinute(Integer.valueOf(CloudStorageActivity.this.nEndMin));
                    CloudStorageActivity.this.mSelectTimePicker.setOnTimeChangedListener(new C02573());
                    if (CloudStorageActivity.this.mSelectTimePicker.getCurrentHour().intValue() < 10 && CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText("0" + CloudStorageActivity.this.mSelectTimePicker.getCurrentHour() + ":0" + CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute());
                    } else if (CloudStorageActivity.this.mSelectTimePicker.getCurrentHour().intValue() >= 10 && CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectTimePicker.getCurrentHour() + ":0" + CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute());
                    } else if (CloudStorageActivity.this.mSelectTimePicker.getCurrentHour().intValue() >= 10 || CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute().intValue() < 10) {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText(CloudStorageActivity.this.mSelectTimePicker.getCurrentHour() + ":" + CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute());
                    } else {
                        CloudStorageActivity.this.tvDateTimeCurrent.setText("0" + CloudStorageActivity.this.mSelectTimePicker.getCurrentHour() + ":" + CloudStorageActivity.this.mSelectTimePicker.getCurrentMinute());
                    }
                }
            }
        });
        this.datetimeSelectDialog.setOnDismissListener(new OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
            }
        });
    }

    private void ShowDateSelectView() {
        this.nDatetimeMode = 100;
        this.datetimeSelectDialog.show();
    }

    private void ShowStartTimeSelectView() {
        this.nDatetimeMode = 101;
        this.datetimeSelectDialog.show();
    }

    private void ShowEndTimeSelectView() {
        this.nDatetimeMode = 102;
        this.datetimeSelectDialog.show();
    }

    public void refleshRecFileList() {
        String strInfo = Constants.MAIN_VERSION_TAG;
        if (this.fileList.size() > 0) {
            ArrayList<HashMap<String, Object>> listItem = new ArrayList();
            for (int i = 0; i < this.fileList.size(); i++) {
                RecordFileInfo fileInfo = (RecordFileInfo) this.fileList.get(i);
                HashMap<String, Object> map = new HashMap();
                map.put("ItemTitleName", Integer.valueOf(C0470R.id.ItemFileName));
                map.put("ItemTitleInfo", Integer.valueOf(C0470R.id.ItemFileInfo));
                map.put("FileName", fileInfo.getStrFileName());
                int nFileSize = fileInfo.getnFileSize();
                String strSize = getString(C0470R.string.strFileSize);
                double fFileSize;
                if (nFileSize > 1024000) {
                    fFileSize = ((double) nFileSize) / 1048576.0d;
                    if (fFileSize >= 100.0d) {
                        strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.0f", new Object[]{Double.valueOf(fFileSize)})).append(" MB").toString();
                    } else if (fFileSize >= 1.0d) {
                        strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.1f", new Object[]{Double.valueOf(fFileSize)})).append(" MB").toString();
                    } else {
                        strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.2f", new Object[]{Double.valueOf(fFileSize)})).append(" MB").toString();
                    }
                } else if (nFileSize > 1024) {
                    fFileSize = ((double) nFileSize) / 1024.0d;
                    strSize = new StringBuilder(String.valueOf(strSize)).append(String.format("%.0f", new Object[]{Double.valueOf(fFileSize)})).append(" KB").toString();
                } else {
                    strSize = new StringBuilder(String.valueOf(strSize)).append(nFileSize).append(" B").toString();
                }
                String strStartTime = getString(C0470R.string.strStartTime);
                if (fileInfo.getuStartHour() >= 10) {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(fileInfo.getuStartHour()).toString();
                } else {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append("0").append(fileInfo.getuStartHour()).toString();
                }
                if (fileInfo.getuStartMin() >= 10) {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":").append(fileInfo.getuStartMin()).toString();
                } else {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":0").append(fileInfo.getuStartMin()).toString();
                }
                if (fileInfo.getuStartSec() >= 10) {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":").append(fileInfo.getuStartSec()).toString();
                } else {
                    strStartTime = new StringBuilder(String.valueOf(strStartTime)).append(":0").append(fileInfo.getuStartSec()).toString();
                }
                String strTimeLen = getString(C0470R.string.strTimeLen);
                double nTimeLen;
                if (fileInfo.getuFileTimeLen() >= 3600) {
                    nTimeLen = ((double) fileInfo.getuFileTimeLen()) / 3600.0d;
                    strTimeLen = new StringBuilder(String.valueOf(strTimeLen)).append(String.format("%.1f", new Object[]{Double.valueOf(nTimeLen)})).append(getString(C0470R.string.strHour)).toString();
                } else if (fileInfo.getuFileTimeLen() >= 60) {
                    nTimeLen = ((double) fileInfo.getuFileTimeLen()) / 60.0d;
                    strTimeLen = new StringBuilder(String.valueOf(strTimeLen)).append(String.format("%.1f", new Object[]{Double.valueOf(nTimeLen)})).append(getString(C0470R.string.strMin)).toString();
                } else {
                    nTimeLen = (double) fileInfo.getuFileTimeLen();
                    strTimeLen = new StringBuilder(String.valueOf(strTimeLen)).append(String.format("%.0f", new Object[]{Double.valueOf(nTimeLen)})).append(getString(C0470R.string.strSec)).toString();
                }
                map.put("FileInfo", new StringBuilder(String.valueOf(strStartTime)).append(" ").append(strTimeLen).append(" ").append(strSize).toString());
                map.put("FileSize", strSize);
                map.put("FileStartTime", strStartTime);
                map.put("FileTimeLen", strTimeLen);
                listItem.add(map);
            }
            RecFileListViewAdapter recFileListItemAdapter = new RecFileListViewAdapter(this, listItem, C0470R.layout.recfile_list_item, new String[]{"ItemTitleName", "ItemTitleInfo", "ItemSize", "ItemTimeLen"}, new int[]{C0470R.id.ItemFileName, C0470R.id.ItemFileInfo, C0470R.id.tvSize, C0470R.id.tvTimeLen});
            if (this.recFileListView == null) {
                this.recFileListView = (ListView) this.contentView.findViewById(C0470R.id.recfile_list);
            }
            this.recFileListView.setAdapter(recFileListItemAdapter);
            this.recFileListView.setSelection(LocalDefines._PlatbackRecListviewFisrtPosition);
            return;
        }
        this.recFileListView.setAdapter(null);
    }

    public void GetRecFileList() {
        this.fileList.clear();
        this.recFileListView.setAdapter(null);
        this.mLoadType = 1;
        this.loadingDialog.show();
        this.m_nThreadID++;
        this.mGetRecFileId = this.m_nThreadID;
        new RecFileSearcher(this.mDevice, this.nSearchType, this.m_nThreadID).start();
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        LocalDefines.cloudRecordFileList = this.fileList;
        startPlayCloudRecordFile(position);
    }

    private void startPlayCloudRecordFile(int position) {
        int camType = this.loginHandle.getCamType();
        Intent intent = new Intent();
        Bundle data = new Bundle();
        if (camType == 1 || camType == 2) {
            intent.setClass(this, NVPlayerPlaybackFishEyeActivity.class);
            data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, this.loginHandle);
            data.putBoolean("isPlayFishEyeFromCloud", true);
        } else {
            intent.setClass(this, NVPlayerPlaybackCloudRecordActivity.class);
        }
        data.putInt("play_index", position);
        data.putInt(Constants.FLAG_DEVICE_ID, this.mDeviceId);
        data.putString("accesstoken", this.mAccesstoken);
        data.putInt("user_id", this.mUserId);
        data.putString("ecs_ip", this.mEcsIP);
        data.putString("ecs_ip2", this.mEcsIP2);
        data.putInt("ecs_port", this.mEcsPort);
        data.putInt("ecs_port2", this.mEcsPort2);
        intent.putExtras(data);
        startActivity(intent);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.showRecordFileListLayout) {
                showScrollViewLayout();
            } else if (this.showSearchRecordFileLayout) {
                showCloudStorageLayout();
            } else {
                startActivity(new Intent(this, HomePageActivity.class));
                LocalDefines.B_UPDATE_LISTVIEW = true;
                LocalDefines.sCloudStorageActivity = null;
                finish();
            }
        }
        return false;
    }

    private void httpResult401() {
        View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.str_Notic_Close_APP));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.str_401));
        AlertDialog dialog = new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                Editor modeEditor = CloudStorageActivity.this.getSharedPreferences("ShareAPPMODE", 0).edit();
                modeEditor.putInt("GetModeNum", 0);
                modeEditor.commit();
                Editor editor = CloudStorageActivity.this.getSharedPreferences("SaveTimeTamp", 0).edit();
                editor.putInt("TimeTamp", 0);
                editor.commit();
                CloudStorageActivity.this.startActivity(new Intent(CloudStorageActivity.this, LoginActivity.class));
                LocalDefines.sCloudStorageActivity = null;
                CloudStorageActivity.this.finish();
            }
        }).create();
        dialog.setCancelable(false);
        dialog.show();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 12 || resultCode != 13) {
            return;
        }
        if (this.mProductId == 0) {
            this.m_nGetServiceListThreadId++;
            this.mProgressBar.setVisibility(0);
            new GetServiceListThread(this.m_nGetServiceListThreadId).start();
        } else if (this.mProductId < 0) {
            this.m_n_GetServiceInfoThreadId++;
            this.mIsLoadingServiceInfo = true;
            this.loadingDialog.show();
            this.mScrollView.setVisibility(8);
            new GetServiceInfoThread(Math.abs(this.mProductId), this.m_n_GetServiceInfoThreadId).start();
        }
    }

    void closeCurrentActivity() {
        LocalDefines.B_UPDATE_LISTVIEW = true;
        LocalDefines.sCloudStorageActivity = null;
        finish();
    }
}
