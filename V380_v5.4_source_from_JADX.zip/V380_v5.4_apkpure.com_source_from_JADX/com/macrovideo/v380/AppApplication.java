package com.macrovideo.v380;

import android.app.Application;

public class AppApplication extends Application {
    public static AppApplication appApplicationContext;

    public void onCreate() {
        super.onCreate();
        appApplicationContext = this;
    }
}
