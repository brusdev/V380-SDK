package com.macrovideo.v380;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RecordFileFragment extends Fragment implements OnItemClickListener, OnClickListener {
    private static final int HANDLE_RECORD_FILE_DELETE = 11;
    private static final int HANDLE_RECORD_FILE_GET = 10;
    private static final String KEY_IS_SELECT = "boolean";
    private static final String RECORD_FILE_LAST_MODIFY_TIME = "RECORD_FILE_LAST_MODIFY_TIME";
    private static final String RECORD_FILE_NAME = "RECORD_FILE_NAME";
    static final String RECORD_FILE_PATH = "RECORD_FILE_PATH";
    private static final String RECORD_FILE_SIZE = "RECORD_FILE_SIZE";
    private static final int TYPE_DELETING = 3;
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    public boolean bDelete = false;
    private boolean isLoadDataCompleted;
    private boolean isViewCreated;
    private LinearLayout llDelete;
    private LinearLayout llDeleteRecordFile;
    private LinearLayout llSelectAll;
    private Dialog loadingDialog;
    private View loadingView;
    private RecordFileAdapter mAdapter;
    private PhotoManagerActivity mAttachActivity;
    private View mContentView;
    private Handler mHandler = new C04711();
    boolean mIsSelectAll;
    private int mLoadType = 1;
    private List<Map<String, Object>> mRecordFileList = new ArrayList();
    private ListView mRecordFileListView;
    private int m_nGetRecordFileThreadId;

    class C04711 extends Handler {
        C04711() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 10:
                    RecordFileFragment.this.loadingDialog.dismiss();
                    RecordFileFragment.this.isLoadDataCompleted = true;
                    RecordFileFragment.this.mAttachActivity.hideRecordFileSelectState();
                    return;
                case 11:
                    RecordFileFragment.this.mRecordFileListView.setEnabled(true);
                    RecordFileFragment.this.mLoadType = 3;
                    RecordFileFragment.this.loadingDialog.show();
                    RecordFileFragment recordFileFragment = RecordFileFragment.this;
                    recordFileFragment.m_nGetRecordFileThreadId = recordFileFragment.m_nGetRecordFileThreadId + 1;
                    new GetRecordFileThread(RecordFileFragment.this.m_nGetRecordFileThreadId).start();
                    return;
                default:
                    return;
            }
        }
    }

    class C04722 implements OnShowListener {
        C04722() {
        }

        public void onShow(DialogInterface dialog) {
            TextView tv = (TextView) RecordFileFragment.this.loadingView.findViewById(C0470R.id.loginText);
            if (RecordFileFragment.this.mLoadType == 1) {
                tv.setText(RecordFileFragment.this.getString(C0470R.string.loading));
            } else if (RecordFileFragment.this.mLoadType == 2) {
                tv.setText(RecordFileFragment.this.getString(C0470R.string.str_saving));
            } else if (RecordFileFragment.this.mLoadType == 3) {
                tv.setText(RecordFileFragment.this.getString(C0470R.string.str_deleting));
            }
        }
    }

    class C04733 implements OnDismissListener {
        C04733() {
        }

        public void onDismiss(DialogInterface dialog) {
            RecordFileFragment recordFileFragment = RecordFileFragment.this;
            recordFileFragment.m_nGetRecordFileThreadId = recordFileFragment.m_nGetRecordFileThreadId + 1;
        }
    }

    private class DeleteRecordFileThread extends Thread {
        private DeleteRecordFileThread() {
        }

        public void run() {
            if (RecordFileFragment.this.mRecordFileList != null && RecordFileFragment.this.mRecordFileList.size() > 0) {
                for (int i = 0; i < RecordFileFragment.this.mRecordFileList.size(); i++) {
                    Map<String, Object> map = (Map) RecordFileFragment.this.mRecordFileList.get(i);
                    if (((Boolean) map.get("boolean")).booleanValue()) {
                        File file = new File((String) map.get(RecordFileFragment.RECORD_FILE_PATH));
                        if (file.exists()) {
                            file.delete();
                        }
                    }
                }
                Message msg = RecordFileFragment.this.mHandler.obtainMessage();
                msg.what = 11;
                RecordFileFragment.this.mHandler.sendMessage(msg);
            }
        }
    }

    class GetRecordFileThread extends Thread {
        private int n_GetRecordFileThreadId;

        class C04741 implements Comparator<Map<String, Object>> {
            C04741() {
            }

            public int compare(Map<String, Object> o1, Map<String, Object> o2) {
                return (int) (((Long) o2.get(RecordFileFragment.RECORD_FILE_LAST_MODIFY_TIME)).longValue() - ((Long) o1.get(RecordFileFragment.RECORD_FILE_LAST_MODIFY_TIME)).longValue());
            }
        }

        public GetRecordFileThread(int m_nGetRecordFileThreadId) {
            this.n_GetRecordFileThreadId = m_nGetRecordFileThreadId;
        }

        public void run() {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            if (RecordFileFragment.this.mRecordFileList == null) {
                RecordFileFragment.this.mRecordFileList = new ArrayList();
            } else {
                RecordFileFragment.this.mRecordFileList.clear();
            }
            List<String> recordFileList = RecordFileFragment.this.getRecordFilePathFromSD(new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().toString())).append(File.separator).append(LocalDefines.SDCardPath).toString());
            if (recordFileList != null && recordFileList.size() > 0) {
                for (int i = 0; i < recordFileList.size(); i++) {
                    Map<String, Object> map = new HashMap();
                    File file = new File((String) recordFileList.get(i));
                    map.put(RecordFileFragment.RECORD_FILE_NAME, file.getName());
                    map.put(RecordFileFragment.RECORD_FILE_SIZE, new StringBuilder(String.valueOf((((double) file.length()) * 1.0d) / 1024.0d)).append("Kb").toString());
                    map.put(RecordFileFragment.RECORD_FILE_LAST_MODIFY_TIME, Long.valueOf(file.lastModified()));
                    map.put(RecordFileFragment.RECORD_FILE_PATH, recordFileList.get(i));
                    map.put("boolean", Boolean.valueOf(false));
                    RecordFileFragment.this.mRecordFileList.add(map);
                }
                Collections.sort(RecordFileFragment.this.mRecordFileList, new C04741());
                LocalDefines.localRecordFileList = RecordFileFragment.this.mRecordFileList;
            }
            if (this.n_GetRecordFileThreadId == RecordFileFragment.this.m_nGetRecordFileThreadId) {
                Message msg = RecordFileFragment.this.mHandler.obtainMessage();
                msg.what = 10;
                RecordFileFragment.this.mHandler.sendMessage(msg);
            }
        }
    }

    private class RecordFileAdapter extends BaseAdapter {
        private ViewHolder holder;

        class ViewHolder {
            ImageView ivRecordFileSelect;
            TextView tvRecordFileName;

            ViewHolder() {
            }
        }

        private RecordFileAdapter() {
        }

        public int getCount() {
            return RecordFileFragment.this.mRecordFileList.size();
        }

        public Object getItem(int arg0) {
            return RecordFileFragment.this.mRecordFileList.get(arg0);
        }

        public long getItemId(int arg0) {
            return (long) arg0;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(RecordFileFragment.this.getActivity(), C0470R.layout.record_file_item, null);
                this.holder = new ViewHolder();
                this.holder.tvRecordFileName = (TextView) convertView.findViewById(C0470R.id.tv_record_file_name);
                this.holder.ivRecordFileSelect = (ImageView) convertView.findViewById(C0470R.id.iv_record_file_select);
                convertView.setTag(this.holder);
            } else {
                this.holder = (ViewHolder) convertView.getTag();
            }
            Map<String, Object> map = (Map) RecordFileFragment.this.mRecordFileList.get(position);
            this.holder.tvRecordFileName.setText((CharSequence) map.get(RecordFileFragment.RECORD_FILE_NAME));
            if (RecordFileFragment.this.bDelete) {
                this.holder.ivRecordFileSelect.setVisibility(0);
            } else {
                this.holder.ivRecordFileSelect.setVisibility(4);
            }
            if (((Boolean) map.get("boolean")).booleanValue()) {
                this.holder.ivRecordFileSelect.setImageResource(C0470R.drawable.delete_choose_2);
            } else {
                this.holder.ivRecordFileSelect.setImageResource(C0470R.drawable.delete_choose_1);
            }
            return convertView;
        }
    }

    public static RecordFileFragment newInstance() {
        return new RecordFileFragment();
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.mAttachActivity = (PhotoManagerActivity) getActivity();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        this.mContentView = inflater.inflate(C0470R.layout.fragment_record_file_manager, container, false);
        InitViews();
        return this.mContentView;
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.isViewCreated = true;
    }

    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && this.isViewCreated && !this.isLoadDataCompleted) {
            getRecordFiles();
        }
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getUserVisibleHint()) {
            getRecordFiles();
        }
    }

    void getRecordFiles() {
        this.mLoadType = 1;
        this.loadingDialog.show();
        this.m_nGetRecordFileThreadId++;
        new GetRecordFileThread(this.m_nGetRecordFileThreadId).start();
    }

    private void InitViews() {
        this.mRecordFileListView = (ListView) this.mContentView.findViewById(C0470R.id.id_record_file_listview);
        this.llDeleteRecordFile = (LinearLayout) this.mContentView.findViewById(C0470R.id.llDeletePhoto);
        this.llDeleteRecordFile.setVisibility(8);
        this.llDelete = (LinearLayout) this.mContentView.findViewById(C0470R.id.ll_delete_record_file);
        this.llDelete.setOnClickListener(this);
        this.llSelectAll = (LinearLayout) this.mContentView.findViewById(C0470R.id.ll_select_all);
        this.llSelectAll.setOnClickListener(this);
        createLoadingDialog();
    }

    void upDateRecordListView() {
        if (this.mRecordFileListView == null && this.mContentView != null) {
            this.mRecordFileListView = (ListView) this.mContentView.findViewById(C0470R.id.id_record_file_listview);
        }
        if (this.mAdapter == null) {
            this.mAdapter = new RecordFileAdapter();
            this.mRecordFileListView.setAdapter(this.mAdapter);
            this.mRecordFileListView.setOnItemClickListener(this);
            return;
        }
        this.mAdapter.notifyDataSetChanged();
    }

    private List<String> getRecordFilePathFromSD(String dirPath) {
        List<String> fileList = new ArrayList();
        File[] files = new File(dirPath).listFiles();
        if (files != null && files.length > 0) {
            for (File file : files) {
                if (checkIsRecordFile(file.getPath())) {
                    fileList.add(file.getPath());
                }
            }
        }
        return fileList;
    }

    private boolean checkIsRecordFile(String fileName) {
        if (fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length()).toLowerCase().equals("mp4")) {
            return true;
        }
        return false;
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(getActivity()).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(getActivity(), C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C04722());
        this.loadingDialog.setOnDismissListener(new C04733());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(false);
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        if (this.bDelete) {
            setRecordFileCheckState(view, position);
            return;
        }
        String uri = (String) ((Map) this.mRecordFileList.get(position)).get(RECORD_FILE_PATH);
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.setDataAndType(Uri.fromFile(new File(uri)), "video/mp4");
        if (hasAppsStartIntent(this.mAttachActivity, intent)) {
            startActivity(intent);
            return;
        }
        intent = new Intent(getActivity(), RecordFilePlayerActivity2.class);
        intent.putExtra("uri", uri);
        startActivity(intent);
    }

    public static boolean hasAppsStartIntent(Context context, Intent intent) {
        List<ResolveInfo> appInfos = getAppsForIntent(context, intent);
        return appInfos != null && appInfos.size() > 0;
    }

    public static List<ResolveInfo> getAppsForIntent(Context context, Intent intent) {
        return context.getPackageManager().queryIntentActivities(intent, 65536);
    }

    private void setRecordFileCheckState(View view, int position) {
        ImageView imageView = (ImageView) view.findViewById(C0470R.id.iv_record_file_select);
        if (imageView != null && position >= 0 && position < this.mRecordFileList.size()) {
            Map<String, Object> map = (Map) this.mRecordFileList.get(position);
            boolean bResult = ((Boolean) map.get("boolean")).booleanValue();
            if (map != null && map.size() > 0) {
                if (bResult) {
                    map.put("boolean", Boolean.valueOf(false));
                    imageView.setImageResource(C0470R.drawable.delete_choose_1);
                    return;
                }
                map.put("boolean", Boolean.valueOf(true));
                imageView.setImageResource(C0470R.drawable.delete_choose_2);
            }
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.ll_select_all:
                if (this.mRecordFileList != null && this.mRecordFileList.size() > 0) {
                    this.llSelectAll.setEnabled(false);
                    if (this.mIsSelectAll) {
                        this.mIsSelectAll = false;
                    } else {
                        this.mIsSelectAll = true;
                    }
                    for (int i = 0; i < this.mRecordFileList.size(); i++) {
                        Map<String, Object> map = (Map) this.mRecordFileList.get(i);
                        if (this.mIsSelectAll) {
                            map.put("boolean", Boolean.valueOf(true));
                        } else {
                            map.put("boolean", Boolean.valueOf(false));
                        }
                    }
                    this.llSelectAll.setEnabled(true);
                    upDateRecordListView();
                    return;
                }
                return;
            case C0470R.id.ll_delete_record_file:
                if (checkIsSelectedState()) {
                    this.mRecordFileListView.setEnabled(false);
                    new DeleteRecordFileThread().start();
                    return;
                }
                return;
            default:
                return;
        }
    }

    private boolean checkIsSelectedState() {
        boolean isSelected = false;
        if (this.mRecordFileList != null && this.mRecordFileList.size() > 0) {
            for (int i = 0; i < this.mRecordFileList.size(); i++) {
                if (((Boolean) ((Map) this.mRecordFileList.get(i)).get("boolean")).booleanValue()) {
                    isSelected = true;
                }
            }
        }
        return isSelected;
    }

    public void setImageCheckStateFalse() {
        for (int i = 0; i < this.mRecordFileList.size(); i++) {
            ((Map) this.mRecordFileList.get(i)).put("boolean", Boolean.valueOf(false));
        }
    }

    public void setBottomBarVisibility(int visibility) {
        this.llDeleteRecordFile.setVisibility(visibility);
    }
}
