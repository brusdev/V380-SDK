package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.Uri;
import android.net.http.Headers;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.Selection;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.animate.RadarView;
import com.macrovideo.httptool.HttpUtils;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.smartlink.SmarkLinkTool;
import com.macrovideo.sdk.tools.DeviceScanner;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.xingepush.RegistClientWithDeviceArrayToServer;
import com.tencent.android.tpush.common.Constants;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public class SmartLinkQuickWifiConfigActivity extends Activity implements OnClickListener, OnItemClickListener {
    static final int DEVICE_IS_EXISTANCE = 10004;
    private static final int MY_PERMISSION_REQUEST_LOCATION = 0;
    private static final int SEEK_DEVICE_OVERTIME = 19;
    private static final int WIFI_CONNECT = 17;
    private static final int WIFI_CONNECT2 = 18;
    private static final int WIFI_NOT_CONNECT = 20;
    private DeviceInfo Editinfo;
    boolean bHasUpdate = false;
    private boolean bIsConfiging = false;
    private boolean bIsNoticeShow = false;
    private boolean bIsSearching = false;
    boolean bNewDevFound = false;
    private boolean bWifiOpen = false;
    private boolean bWifiPassword = true;
    private int bindDevice_result;
    private ImageView btnSLBack;
    private Button btnSLSearchBack = null;
    private Button btnSLStartConfig;
    private Button btnWifiQuikConfig;
    private ArrayList<DeviceInfo> deviceList = null;
    private EditText etSLWifiPassword;
    private EditText etSLWifiSSID;
    private FrameLayout flayoutSLSearchingAnimate;
    private Handler handler = new C04841();
    DatagramSocket ipuAPudpSocket = null;
    DatagramSocket ipuStationudpSocket = null;
    private ImageView ivSLPwdVisible;
    private ImageView ivSoundWaveConfigWifiListViewBack;
    private LinearLayout lLayoutWifiInputPage;
    private LinearLayout llayoutSLSearchingPage;
    private List<ScanResult> locaWifiDeiviceList = new ArrayList();
    private ListView lvSoundWaveConfigWifi;
    private boolean mIsSearchingMode = false;
    private WiFiAdnim mWiFiAdnim;
    private WifiManager mWiFiManager;
    private int mWifiEnrcrypt;
    private WifiInfo mWifiInfo;
    private int m_nBindForSearchDeviceId;
    private int m_nSearchID = 0;
    private WifiReceiver mwReceiver;
    private int nConfigID = 0;
    private int nTimeoutDetectID = 0;
    private int n_BindDeviceThreadID = 0;
    private ProgressDialog progressDialog;
    private RadarView searchAminatView;
    private MediaPlayer soundPlayer = null;
    private MediaPlayer soundPlayerHint = null;
    private View soundWaveConfigConctentView = null;
    private Dialog soundWaveConfigDialog = null;
    private String strConnSSID;
    private TextView tvTimeLeft = null;
    private Builder wifiNoticeDialog = null;

    class C04841 extends Handler {
        C04841() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            if (!(msg.arg1 != 18 || SmartLinkQuickWifiConfigActivity.this.bWifiOpen || SmartLinkQuickWifiConfigActivity.this.progressDialog == null)) {
                SmartLinkQuickWifiConfigActivity.this.progressDialog.dismiss();
                Toast.makeText(SmartLinkQuickWifiConfigActivity.this, SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.wifiListingFail), 0).show();
            }
            if (msg.arg1 == 19) {
                SmartLinkQuickWifiConfigActivity smartLinkQuickWifiConfigActivity = SmartLinkQuickWifiConfigActivity.this;
                smartLinkQuickWifiConfigActivity.nTimeoutDetectID = smartLinkQuickWifiConfigActivity.nTimeoutDetectID + 1;
                SmartLinkQuickWifiConfigActivity.this.searchAminatView.stopAnimate();
                try {
                    if (SmartLinkQuickWifiConfigActivity.this.isLanguage() && SmartLinkQuickWifiConfigActivity.this.soundPlayerHint != null) {
                        SmartLinkQuickWifiConfigActivity.this.soundPlayerHint.stop();
                    }
                    if (SmartLinkQuickWifiConfigActivity.this.soundPlayer != null) {
                        SmartLinkQuickWifiConfigActivity.this.soundPlayer.stop();
                    }
                } catch (Exception e) {
                }
                SmartLinkQuickWifiConfigActivity.this.bIsConfiging = false;
                SmarkLinkTool.StopSmartConnection();
                SmartLinkQuickWifiConfigActivity.this.showInputPage();
                SmartLinkQuickWifiConfigActivity.this.ShowAlert(SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.snartLinkFailTitle), SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.snartLinkFailHint));
            }
            if (msg.arg1 == 17 && SmartLinkQuickWifiConfigActivity.this.progressDialog != null) {
                SmartLinkQuickWifiConfigActivity.this.progressDialog.dismiss();
            }
            if (msg.arg1 == 20) {
                if (SmartLinkQuickWifiConfigActivity.this.progressDialog != null) {
                    SmartLinkQuickWifiConfigActivity.this.progressDialog.dismiss();
                }
                Toast.makeText(SmartLinkQuickWifiConfigActivity.this, SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.connect_wifi_off), 0).show();
            }
            if (msg.arg1 == 1001) {
                smartLinkQuickWifiConfigActivity = SmartLinkQuickWifiConfigActivity.this;
                smartLinkQuickWifiConfigActivity.nTimeoutDetectID = smartLinkQuickWifiConfigActivity.nTimeoutDetectID + 1;
                SmartLinkQuickWifiConfigActivity.this.bIsConfiging = false;
                SmarkLinkTool.StopSmartConnection();
                SmartLinkQuickWifiConfigActivity.this.StopSearchDevice();
                Toast toast;
                switch (msg.arg2) {
                    case 101:
                        if (SmartLinkQuickWifiConfigActivity.this.deviceList == null || SmartLinkQuickWifiConfigActivity.this.deviceList.size() <= 0) {
                            toast = Toast.makeText(SmartLinkQuickWifiConfigActivity.this, SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.no_dev_found), 0);
                            toast.setGravity(17, 0, 0);
                            toast.show();
                            SmartLinkQuickWifiConfigActivity.this.StartSearchDevice();
                            return;
                        } else if (HomePageActivity.AppMode == 1) {
                            smartLinkQuickWifiConfigActivity = SmartLinkQuickWifiConfigActivity.this;
                            smartLinkQuickWifiConfigActivity.m_nBindForSearchDeviceId = smartLinkQuickWifiConfigActivity.m_nBindForSearchDeviceId + 1;
                            new BindForSearchDeviceThread(SmartLinkQuickWifiConfigActivity.this.m_nBindForSearchDeviceId, SmartLinkQuickWifiConfigActivity.this.deviceList).start();
                            return;
                        } else {
                            boolean bNewDevFound = false;
                            for (int i = 0; i < SmartLinkQuickWifiConfigActivity.this.deviceList.size(); i++) {
                                DeviceInfo info = (DeviceInfo) SmartLinkQuickWifiConfigActivity.this.deviceList.get(i);
                                if (info != null) {
                                    if (DatabaseManager.IsInfoExist(info)) {
                                        if (info.getIsAlarmOn() == 0) {
                                            DatabaseManager.UpdateServerInfoState(info);
                                        } else {
                                            DatabaseManager.UpdateServerInfoStateWithAlarmState(info);
                                        }
                                        bNewDevFound = true;
                                    } else if (DatabaseManager.AddServerInfo(info)) {
                                        bNewDevFound = true;
                                    }
                                }
                            }
                            if (SmartLinkQuickWifiConfigActivity.this.deviceList.size() <= 0) {
                                toast = Toast.makeText(SmartLinkQuickWifiConfigActivity.this, SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.no_dev_found), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                SmartLinkQuickWifiConfigActivity.this.StartSearchDevice();
                                return;
                            } else if (bNewDevFound) {
                                LocalDefines.reloadDeviceInfoList();
                                LocalDefines.isDeviceListSet = false;
                                LocalDefines.nClientDeviceSettingThreadID++;
                                new RegistClientWithDeviceArrayToServer((Handler) this, LocalDefines.nClientDeviceSettingThreadID).start();
                                smartLinkQuickWifiConfigActivity = SmartLinkQuickWifiConfigActivity.this;
                                smartLinkQuickWifiConfigActivity.nTimeoutDetectID = smartLinkQuickWifiConfigActivity.nTimeoutDetectID + 1;
                                if (SmartLinkQuickWifiConfigActivity.this.soundPlayer != null) {
                                    SmartLinkQuickWifiConfigActivity.this.soundPlayer.stop();
                                }
                                SmartLinkQuickWifiConfigActivity.this.lLayoutWifiInputPage.setVisibility(0);
                                SmartLinkQuickWifiConfigActivity.this.llayoutSLSearchingPage.setVisibility(8);
                                SmartLinkQuickWifiConfigActivity.this.StopSearchDevice();
                                SmartLinkQuickWifiConfigActivity.this.startActivity(new Intent(SmartLinkQuickWifiConfigActivity.this, HomePageActivity.class));
                                SmartLinkQuickWifiConfigActivity.this.finish();
                                return;
                            } else {
                                toast = Toast.makeText(SmartLinkQuickWifiConfigActivity.this, SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.search_finish), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                                SmartLinkQuickWifiConfigActivity.this.StartSearchDevice();
                                return;
                            }
                        }
                    case 102:
                        toast = Toast.makeText(SmartLinkQuickWifiConfigActivity.this, SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.no_dev_found), 0);
                        toast.setGravity(17, 0, 0);
                        toast.show();
                        return;
                    default:
                        return;
                }
            } else if (msg.arg1 == LocalDefines.BIND_DEVICE_RESULT_CODE) {
                String searchResultMsg = SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.add_device);
                Bundle bundle = msg.getData();
                DeviceInfo info2 = (DeviceInfo) bundle.getParcelable("Bind_info");
                int index = bundle.getInt("Bind_index");
                if (msg.arg2 == 0) {
                    if (DatabaseManager.IsInfoExist(info2)) {
                        if (info2.getIsAlarmOn() == 0) {
                            DatabaseManager.UpdateServerInfoState(info2);
                        } else {
                            DatabaseManager.UpdateServerInfoStateWithAlarmState(info2);
                        }
                        SmartLinkQuickWifiConfigActivity.this.bHasUpdate = true;
                    } else {
                        SmartLinkQuickWifiConfigActivity.this.bNewDevFound = true;
                        if (DatabaseManager.AddServerInfo(info2)) {
                            if (index == 0) {
                                searchResultMsg = new StringBuilder(String.valueOf(searchResultMsg)).append(info2.getStrName()).toString();
                            } else {
                                searchResultMsg = new StringBuilder(String.valueOf(searchResultMsg)).append(", ").append(info2.getStrName()).toString();
                            }
                        }
                    }
                    if (SmartLinkQuickWifiConfigActivity.this.deviceList.size() <= 0) {
                        return;
                    }
                    if (SmartLinkQuickWifiConfigActivity.this.bNewDevFound) {
                        System.out.println("注册信鸽");
                        LocalDefines.reloadDeviceInfoList();
                        LocalDefines.isDeviceListSet = false;
                        LocalDefines.nClientDeviceSettingThreadID++;
                        new RegistClientWithDeviceArrayToServer((Handler) this, LocalDefines.nClientDeviceSettingThreadID).start();
                        smartLinkQuickWifiConfigActivity = SmartLinkQuickWifiConfigActivity.this;
                        smartLinkQuickWifiConfigActivity.nTimeoutDetectID = smartLinkQuickWifiConfigActivity.nTimeoutDetectID + 1;
                        if (SmartLinkQuickWifiConfigActivity.this.soundPlayer != null) {
                            SmartLinkQuickWifiConfigActivity.this.soundPlayer.stop();
                        }
                        SmartLinkQuickWifiConfigActivity.this.lLayoutWifiInputPage.setVisibility(0);
                        SmartLinkQuickWifiConfigActivity.this.llayoutSLSearchingPage.setVisibility(8);
                        SmartLinkQuickWifiConfigActivity.this.StopSearchDevice();
                        SmartLinkQuickWifiConfigActivity.this.startActivity(new Intent(SmartLinkQuickWifiConfigActivity.this, HomePageActivity.class));
                        SmartLinkQuickWifiConfigActivity.this.finish();
                        return;
                    }
                    Toast toast_1 = Toast.makeText(SmartLinkQuickWifiConfigActivity.this, SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.search_finish), 0);
                    toast_1.setGravity(17, 0, 0);
                    toast_1.show();
                    SmartLinkQuickWifiConfigActivity.this.StartSearchDevice();
                } else if (msg.arg2 == 10004) {
                    if (info2.getIsAlarmOn() == 0) {
                        DatabaseManager.UpdateServerInfoState(info2);
                    } else {
                        DatabaseManager.UpdateServerInfoStateWithAlarmState(info2);
                    }
                } else if (msg.arg2 == 401) {
                    SmartLinkQuickWifiConfigActivity.this.httpResult401();
                } else if (msg.arg2 == 500) {
                    Toast.makeText(SmartLinkQuickWifiConfigActivity.this, SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.str_server_error), 0).show();
                } else if (msg.arg2 == -1) {
                    Toast.makeText(SmartLinkQuickWifiConfigActivity.this, C0470R.string.Network_Error, 0).show();
                } else {
                    Toast.makeText(SmartLinkQuickWifiConfigActivity.this, C0470R.string.str_bind_device_error, 0).show();
                }
            }
        }
    }

    class C04852 implements TextWatcher {
        C04852() {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void afterTextChanged(Editable s) {
            if (s.length() == 0) {
                SmartLinkQuickWifiConfigActivity.this.etSLWifiSSID.setEnabled(false);
            } else {
                SmartLinkQuickWifiConfigActivity.this.etSLWifiSSID.setEnabled(true);
            }
        }
    }

    class C04863 implements DialogInterface.OnClickListener {
        C04863() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            SmartLinkQuickWifiConfigActivity.this.setResult(-1);
        }
    }

    class C04874 implements DialogInterface.OnClickListener {
        C04874() {
        }

        public void onClick(DialogInterface dialog, int which) {
            SmartLinkQuickWifiConfigActivity.this.mWiFiAdnim.openWifi();
            SmartLinkQuickWifiConfigActivity.this.bIsNoticeShow = false;
            SmartLinkQuickWifiConfigActivity.this.progressDialog = new ProgressDialog(SmartLinkQuickWifiConfigActivity.this);
            SmartLinkQuickWifiConfigActivity.this.progressDialog.setProgressStyle(0);
            SmartLinkQuickWifiConfigActivity.this.progressDialog.setCanceledOnTouchOutside(false);
            SmartLinkQuickWifiConfigActivity.this.progressDialog.setMessage(SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.wifi_start));
            SmartLinkQuickWifiConfigActivity.this.progressDialog.show();
        }
    }

    class C04885 implements DialogInterface.OnClickListener {
        C04885() {
        }

        public void onClick(DialogInterface dialog, int which) {
            SmartLinkQuickWifiConfigActivity.this.bIsNoticeShow = false;
        }
    }

    class C04896 implements OnShowListener {
        C04896() {
        }

        public void onShow(DialogInterface dialog) {
            SmartLinkQuickWifiConfigActivity.this.onSoundWaveConfigListViewDialogShow();
        }
    }

    class C04918 implements DialogInterface.OnClickListener {
        C04918() {
        }

        public void onClick(DialogInterface dialog, int which) {
            Intent intent = new Intent();
            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.fromParts("package", SmartLinkQuickWifiConfigActivity.this.getPackageName(), null));
            SmartLinkQuickWifiConfigActivity.this.startActivity(intent);
        }
    }

    class C04929 implements DialogInterface.OnClickListener {
        C04929() {
        }

        public void onClick(DialogInterface dialog, int which) {
            SmartLinkQuickWifiConfigActivity.this.startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
        }
    }

    class BindDeviceThread extends Thread {
        private Handler handler;
        private DeviceInfo info;
        private int infoIndex;
        private int m_BindDeviceThreadID;
        private int m_DeviceId;
        private String m_DeviceName;
        private String m_DevicePassword;

        public BindDeviceThread(int BindDeviceThreadID, String DeviceName, String DevicePassword, Handler handler, int DeviceId, DeviceInfo info, int infoIndex) {
            this.m_BindDeviceThreadID = BindDeviceThreadID;
            this.handler = handler;
            this.m_DeviceId = DeviceId;
            this.m_DeviceName = DeviceName;
            this.m_DevicePassword = DevicePassword;
            this.info = info;
            this.infoIndex = infoIndex;
        }

        public void run() {
            super.run();
            if (this.m_BindDeviceThreadID == SmartLinkQuickWifiConfigActivity.this.n_BindDeviceThreadID) {
                try {
                    SmartLinkQuickWifiConfigActivity.this.postBindDeviceData(this.m_DeviceId, this.m_DeviceName, this.m_DevicePassword, this.info, this.infoIndex);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = LocalDefines.BIND_DEVICE_RESULT_CODE;
            msg.arg2 = SmartLinkQuickWifiConfigActivity.this.bindDevice_result;
            Bundle data = new Bundle();
            data.putParcelable("Bind_info", this.info);
            data.putInt("Bind_index", this.infoIndex);
            msg.setData(data);
            this.handler.sendMessage(msg);
        }
    }

    class BindForSearchDeviceThread extends Thread {
        boolean bNewDevFound1 = false;
        private int nBindForSearchDeviceId;
        private List<DeviceInfo> searchList;

        class C04931 implements Runnable {
            C04931() {
            }

            public void run() {
                if (BindForSearchDeviceThread.this.bNewDevFound1) {
                    LocalDefines.reloadDeviceInfoList();
                    LocalDefines.isDeviceListSet = false;
                    LocalDefines.nClientDeviceSettingThreadID++;
                    new RegistClientWithDeviceArrayToServer(SmartLinkQuickWifiConfigActivity.this, LocalDefines.nClientDeviceSettingThreadID).start();
                    SmartLinkQuickWifiConfigActivity access$0 = SmartLinkQuickWifiConfigActivity.this;
                    access$0.nTimeoutDetectID = access$0.nTimeoutDetectID + 1;
                    if (SmartLinkQuickWifiConfigActivity.this.soundPlayer != null) {
                        SmartLinkQuickWifiConfigActivity.this.soundPlayer.stop();
                    }
                    SmartLinkQuickWifiConfigActivity.this.lLayoutWifiInputPage.setVisibility(0);
                    SmartLinkQuickWifiConfigActivity.this.llayoutSLSearchingPage.setVisibility(8);
                    SmartLinkQuickWifiConfigActivity.this.StopSearchDevice();
                    SmartLinkQuickWifiConfigActivity.this.startActivity(new Intent(SmartLinkQuickWifiConfigActivity.this, HomePageActivity.class));
                    SmartLinkQuickWifiConfigActivity.this.finish();
                    return;
                }
                Toast toast = Toast.makeText(SmartLinkQuickWifiConfigActivity.this, SmartLinkQuickWifiConfigActivity.this.getString(C0470R.string.search_finish), 0);
                toast.setGravity(17, 0, 0);
                toast.show();
                SmartLinkQuickWifiConfigActivity.this.StartSearchDevice();
            }
        }

        public BindForSearchDeviceThread(int m_nBindForSearchDeviceId, List<DeviceInfo> searchList) {
            this.nBindForSearchDeviceId = m_nBindForSearchDeviceId;
            this.searchList = searchList;
        }

        public void run() {
            try {
                if (SmartLinkQuickWifiConfigActivity.this.m_nBindForSearchDeviceId == this.nBindForSearchDeviceId && this.searchList != null && this.searchList.size() > 0) {
                    for (int i = 0; i < this.searchList.size(); i++) {
                        DeviceInfo info = (DeviceInfo) this.searchList.get(i);
                        if (!(info == null || info.getnDevID() == 0)) {
                            if (DatabaseManager.IsInfoExist(info)) {
                                if (info.getIsAlarmOn() == 0) {
                                    DatabaseManager.UpdateServerInfoState(info);
                                } else {
                                    DatabaseManager.UpdateServerInfoStateWithAlarmState(info);
                                }
                                this.bNewDevFound1 = true;
                            } else {
                                String strPassword = Base64.encodeToString(info.getStrPassword().getBytes(), 0);
                                long time = System.currentTimeMillis();
                                String MDLoginSign = LoginActivity.md5("accesstoken=" + DeviceListViewFragment._Token + "&deviceaccount=" + info.getStrUsername() + "&deviceid=" + info.getnDevID() + "&devicepassword=" + strPassword + "&timestamp=" + (time / 1000) + "hsshop2016");
                                JSONObject json = new JSONObject();
                                json.put("sign", MDLoginSign);
                                json.put("timestamp", time / 1000);
                                json.put("accesstoken", DeviceListViewFragment._Token);
                                json.put("deviceid", info.getnDevID());
                                json.put("deviceaccount", info.getStrUsername());
                                json.put("devicepassword", strPassword);
                                String httpResult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/device/bind", json.toString());
                                if (!(httpResult == null || httpResult.length() <= 0 || httpResult.equals(Integer.valueOf(-1)))) {
                                    JSONObject jsonObject = new JSONObject(httpResult);
                                    if (jsonObject.getInt("result") == 0) {
                                        this.bNewDevFound1 = true;
                                        boolean dbResult = DatabaseManager.AddServerInfo(info);
                                        int update_timestamp = jsonObject.getInt("update_timestamp");
                                        SharedPreferences shareUpdateTime = SmartLinkQuickWifiConfigActivity.this.getSharedPreferences("SaveTimeTamp", 0);
                                        Editor editor = shareUpdateTime.edit();
                                        editor.putInt("TimeTamp", update_timestamp);
                                        editor.commit();
                                        DeviceListViewFragment.NewLocalTimeTamp = shareUpdateTime.getInt("TimeTamp", -101);
                                    }
                                }
                            }
                        }
                    }
                    if (SmartLinkQuickWifiConfigActivity.this.m_nBindForSearchDeviceId == this.nBindForSearchDeviceId) {
                        SmartLinkQuickWifiConfigActivity.this.runOnUiThread(new C04931());
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public class BroadCastUdp extends Thread {
        private int nTreadSearchID = 0;

        public BroadCastUdp(int nSearchID) {
            this.nTreadSearchID = nSearchID;
        }

        public void run() {
            while (SmartLinkQuickWifiConfigActivity.this.bIsSearching && this.nTreadSearchID == SmartLinkQuickWifiConfigActivity.this.m_nSearchID) {
                SmartLinkQuickWifiConfigActivity.this.deviceList = DeviceScanner.getDeviceListFromLan(SmartLinkQuickWifiConfigActivity.this.nConfigID);
                if (SmartLinkQuickWifiConfigActivity.this.deviceList != null && SmartLinkQuickWifiConfigActivity.this.deviceList.size() > 0) {
                    Message msg = SmartLinkQuickWifiConfigActivity.this.handler.obtainMessage();
                    msg.arg1 = 1001;
                    msg.arg2 = 101;
                    SmartLinkQuickWifiConfigActivity.this.handler.sendMessage(msg);
                }
            }
        }
    }

    public class DeviceSoundWaveConfigAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private List<ScanResult> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            TextView tvTimeZone;

            private ItemViewHolder() {
            }
        }

        public DeviceSoundWaveConfigAdapter(Context c, List<ScanResult> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int arg0) {
            return (long) arg0;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.time_zone_item, null);
                this.holder = new ItemViewHolder();
                this.holder.tvTimeZone = (TextView) convertView.findViewById(C0470R.id.tvTimeZone);
                convertView.setTag(this.holder);
            }
            if (this.mAppList != null && this.mAppList.size() > 0) {
                this.holder.tvTimeZone.setText(((ScanResult) this.mAppList.get(position)).SSID);
            }
            return convertView;
        }
    }

    public class TimeoutDetectThread extends Thread {
        private int nThreadID = 0;

        public TimeoutDetectThread(int nThreadID) {
            this.nThreadID = nThreadID;
        }

        public void run() {
            int nCount = 83;
            while (SmartLinkQuickWifiConfigActivity.this.nTimeoutDetectID == this.nThreadID) {
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                }
                nCount--;
                if (nCount <= 0) {
                    break;
                }
            }
            if (this.nThreadID == SmartLinkQuickWifiConfigActivity.this.nTimeoutDetectID) {
                Message msg = SmartLinkQuickWifiConfigActivity.this.handler.obtainMessage();
                msg.arg1 = 19;
                SmartLinkQuickWifiConfigActivity.this.handler.sendMessage(msg);
            }
        }
    }

    public class WifiReceiver extends BroadcastReceiver {

        class C04941 implements Comparator<ScanResult> {
            C04941() {
            }

            public int compare(ScanResult object1, ScanResult object2) {
                return Math.abs(object1.level) + Constants.MAIN_VERSION_TAG.compareTo(new StringBuilder(String.valueOf(Math.abs(object2.level))).toString());
            }
        }

        public void onReceive(Context c, Intent intent) {
            if (intent.getAction().equals("android.net.wifi.STATE_CHANGE")) {
                NetworkInfo info = (NetworkInfo) intent.getParcelableExtra("networkInfo");
                if (info.getState().equals(State.DISCONNECTED)) {
                    SmartLinkQuickWifiConfigActivity.this.etSLWifiSSID.setText(Constants.MAIN_VERSION_TAG);
                } else if (info.getState().equals(State.CONNECTED)) {
                    SmartLinkQuickWifiConfigActivity.this.mWifiInfo = SmartLinkQuickWifiConfigActivity.this.mWiFiManager.getConnectionInfo();
                    SmartLinkQuickWifiConfigActivity.this.strConnSSID = SmartLinkQuickWifiConfigActivity.this.mWifiInfo.getSSID();
                    if (SmartLinkQuickWifiConfigActivity.this.strConnSSID == null || SmartLinkQuickWifiConfigActivity.this.strConnSSID.length() <= 0 || SmartLinkQuickWifiConfigActivity.this.strConnSSID.equalsIgnoreCase("0x") || SmartLinkQuickWifiConfigActivity.this.strConnSSID.equalsIgnoreCase("<unknown ssid>")) {
                        SmartLinkQuickWifiConfigActivity.this.etSLWifiSSID.setText(Constants.MAIN_VERSION_TAG);
                    } else {
                        if (SmartLinkQuickWifiConfigActivity.this.strConnSSID.substring(0, 1).equals("\"") && SmartLinkQuickWifiConfigActivity.this.strConnSSID.substring(SmartLinkQuickWifiConfigActivity.this.strConnSSID.length() - 1, SmartLinkQuickWifiConfigActivity.this.strConnSSID.length()).equals("\"")) {
                            SmartLinkQuickWifiConfigActivity.this.strConnSSID = SmartLinkQuickWifiConfigActivity.this.strConnSSID.substring(1, SmartLinkQuickWifiConfigActivity.this.strConnSSID.length() - 1);
                        }
                        SmartLinkQuickWifiConfigActivity.this.etSLWifiSSID.setText(SmartLinkQuickWifiConfigActivity.this.strConnSSID);
                    }
                }
            } else if (intent.getAction().equals("android.net.wifi.WIFI_STATE_CHANGED")) {
                int wifistate = intent.getIntExtra("wifi_state", 1);
                if (wifistate == 1) {
                    SmartLinkQuickWifiConfigActivity.this.btnSLStartConfig.setEnabled(false);
                } else if (wifistate == 3) {
                    SmartLinkQuickWifiConfigActivity.this.btnSLStartConfig.setEnabled(true);
                }
            }
            SmartLinkQuickWifiConfigActivity.this.locaWifiDeiviceList = SmartLinkQuickWifiConfigActivity.this.mWiFiManager.getScanResults();
            if (!SmartLinkQuickWifiConfigActivity.this.locaWifiDeiviceList.isEmpty()) {
                Collections.sort(SmartLinkQuickWifiConfigActivity.this.locaWifiDeiviceList, new C04941());
            }
            if (SmartLinkQuickWifiConfigActivity.this.locaWifiDeiviceList != null && SmartLinkQuickWifiConfigActivity.this.locaWifiDeiviceList.size() > 0 && SmartLinkQuickWifiConfigActivity.this.progressDialog != null) {
                SmartLinkQuickWifiConfigActivity.this.progressDialog.dismiss();
                SmartLinkQuickWifiConfigActivity.this.bWifiOpen = true;
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(128, 128);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_smartlink_wifi_config);
        initView();
    }

    protected void onStart() {
        super.onStart();
        initWifi();
        wifiChooseWindow();
    }

    public void onStop() {
        if (this.soundWaveConfigDialog != null && this.soundWaveConfigDialog.isShowing()) {
            this.soundWaveConfigDialog.dismiss();
        }
        try {
            if (this.soundPlayerHint != null) {
                this.soundPlayerHint.stop();
            }
            if (this.soundPlayer != null) {
                this.soundPlayer.stop();
            }
        } catch (Exception e) {
        }
        if (this.bIsConfiging) {
            SmarkLinkTool.StopSmartConnection();
            showInputPage();
            this.bIsConfiging = false;
        }
        super.onStop();
    }

    protected void onDestroy() {
        this.soundPlayer = null;
        this.soundPlayerHint = null;
        this.locaWifiDeiviceList = null;
        this.mWifiInfo = null;
        unregisterReceiver(this.mwReceiver);
        if (this.searchAminatView != null) {
            this.searchAminatView.recycleBitmap();
            System.gc();
        }
        super.onDestroy();
    }

    private void initView() {
        this.lLayoutWifiInputPage = (LinearLayout) findViewById(C0470R.id.lLayoutWifiInputPage);
        this.btnSLBack = (ImageView) findViewById(C0470R.id.btnSLBack);
        this.btnSLBack.setOnClickListener(this);
        this.ivSLPwdVisible = (ImageView) findViewById(C0470R.id.ivSLPwdVisible);
        this.ivSLPwdVisible.setOnClickListener(this);
        this.btnSLStartConfig = (Button) findViewById(C0470R.id.btnSLStartConfig);
        this.btnSLStartConfig.setOnClickListener(this);
        this.btnWifiQuikConfig = (Button) findViewById(C0470R.id.btnWifiQuikConfig);
        this.btnWifiQuikConfig.setOnClickListener(this);
        this.etSLWifiSSID = (EditText) findViewById(C0470R.id.etSLWifiSSID);
        this.etSLWifiSSID.setInputType(0);
        this.etSLWifiSSID.addTextChangedListener(new C04852());
        this.etSLWifiPassword = (EditText) findViewById(C0470R.id.etSLWifiPassword);
        this.lLayoutWifiInputPage.setVisibility(0);
        this.etSLWifiPassword.setInputType(144);
        this.llayoutSLSearchingPage = (LinearLayout) findViewById(C0470R.id.llayoutSLSearchingPage);
        this.flayoutSLSearchingAnimate = (FrameLayout) findViewById(C0470R.id.flayoutSLSearchingAnimate);
        this.flayoutSLSearchingAnimate.setBackgroundColor(Color.parseColor("#f9f9f9"));
        this.llayoutSLSearchingPage.setVisibility(8);
        this.btnSLSearchBack = (Button) findViewById(C0470R.id.btnSLSearchBack);
        this.btnSLSearchBack.setOnClickListener(this);
        this.searchAminatView = (RadarView) findViewById(C0470R.id.searchAminatView);
        this.searchAminatView.setWillNotDraw(false);
        this.tvTimeLeft = (TextView) findViewById(C0470R.id.tvTimeLeft);
    }

    public void ShowAlert(String title, String msg) {
        if (hasWindowFocus()) {
            View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
            ((TextView) view.findViewById(C0470R.id.tv_title)).setText(title);
            ((TextView) view.findViewById(C0470R.id.tv_content)).setText(msg);
            new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C04863()).show();
        }
    }

    private void initWifi() {
        this.mWiFiAdnim = new WiFiAdnim(this);
        this.mWiFiManager = (WifiManager) getSystemService("wifi");
        this.mWifiInfo = this.mWiFiManager.getConnectionInfo();
        if (this.mWiFiManager.getWifiState() == 3 && this.mWifiInfo != null) {
            this.strConnSSID = this.mWifiInfo.getSSID();
            if (this.strConnSSID == null || this.strConnSSID.length() <= 0 || this.strConnSSID.equalsIgnoreCase("0x") || this.strConnSSID.equalsIgnoreCase("<unknown ssid>")) {
                this.etSLWifiSSID.setText(Constants.MAIN_VERSION_TAG);
            } else {
                if (this.strConnSSID.substring(0, 1).equals("\"") && this.strConnSSID.substring(this.strConnSSID.length() - 1, this.strConnSSID.length()).equals("\"")) {
                    this.strConnSSID = this.strConnSSID.substring(1, this.strConnSSID.length() - 1);
                }
                this.etSLWifiSSID.setText(this.strConnSSID);
            }
            if (this.lLayoutWifiInputPage.getVisibility() == 0 && isLanguage()) {
                this.soundPlayerHint = MediaPlayer.create(this, C0470R.raw.input_wifi_pwd);
                this.soundPlayerHint.setLooping(false);
                this.soundPlayerHint.start();
            }
        } else if (!this.bIsNoticeShow) {
            View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
            ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.wifiConnect));
            ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.wifi_start_bt));
            this.wifiNoticeDialog = new Builder(this);
            this.wifiNoticeDialog.setView(view);
            this.wifiNoticeDialog.setPositiveButton(getString(C0470R.string.wifi_is), new C04874());
            this.wifiNoticeDialog.setNegativeButton(getString(C0470R.string.wifi_no), new C04885());
            this.wifiNoticeDialog.show();
            this.bIsNoticeShow = true;
        }
        this.mwReceiver = new WifiReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.wifi.SCAN_RESULTS");
        intentFilter.addAction("android.net.wifi.STATE_CHANGE");
        intentFilter.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        registerReceiver(this.mwReceiver, intentFilter);
        this.mWiFiAdnim.startScan();
    }

    public boolean isWiFiActive() {
        ConnectivityManager connectivity = (ConnectivityManager) getSystemService("connectivity");
        if (connectivity == null) {
            return false;
        }
        NetworkInfo[] infos = connectivity.getAllNetworkInfo();
        if (infos == null) {
            return false;
        }
        for (NetworkInfo ni : infos) {
            if (ni.getTypeName().equals("WIFI") && ni.isConnected()) {
                return true;
            }
        }
        return false;
    }

    private void wifiChooseWindow() {
        this.soundWaveConfigConctentView = LayoutInflater.from(getApplication()).inflate(C0470R.layout.sound_wave_config_window, null);
        this.soundWaveConfigDialog = new Dialog(this, C0470R.style.dialog_bg_transparent);
        this.soundWaveConfigDialog.setContentView(this.soundWaveConfigConctentView);
        this.soundWaveConfigDialog.setOnShowListener(new C04896());
    }

    private void onSoundWaveConfigListViewDialogShow() {
        this.ivSoundWaveConfigWifiListViewBack = (ImageView) this.soundWaveConfigConctentView.findViewById(C0470R.id.ivSoundWaveConfigBack);
        this.lvSoundWaveConfigWifi = (ListView) this.soundWaveConfigConctentView.findViewById(C0470R.id.lvSoundWaveConfig);
        this.ivSoundWaveConfigWifiListViewBack.setOnClickListener(this);
        this.lvSoundWaveConfigWifi.setOnItemClickListener(this);
        if (this.locaWifiDeiviceList != null && this.locaWifiDeiviceList.size() > 0) {
            DeviceSoundWaveConfigAdapter deviceSoundWaveConfigAdapter = new DeviceSoundWaveConfigAdapter(this, this.locaWifiDeiviceList, C0470R.layout.time_zone_item, new String[]{"item_list"}, new int[]{C0470R.id.tvTimeZone});
            if (this.lvSoundWaveConfigWifi != null) {
                this.lvSoundWaveConfigWifi.setAdapter(deviceSoundWaveConfigAdapter);
                return;
            }
            this.lvSoundWaveConfigWifi = (ListView) this.soundWaveConfigConctentView.findViewById(C0470R.id.lvSoundWaveConfig);
            this.lvSoundWaveConfigWifi.setAdapter(deviceSoundWaveConfigAdapter);
        }
    }

    public boolean isLanguage() {
        if (Locale.getDefault().getLanguage().equals("zh")) {
            return true;
        }
        return false;
    }

    private void showInputPage() {
        this.lLayoutWifiInputPage.setVisibility(0);
        this.llayoutSLSearchingPage.setVisibility(8);
    }

    private void showSearchingPage() {
        this.lLayoutWifiInputPage.setVisibility(8);
        this.llayoutSLSearchingPage.setVisibility(0);
    }

    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case C0470R.id.btnSLBack:
                this.bIsConfiging = false;
                SmarkLinkTool.StopSmartConnection();
                try {
                    if (isLanguage() && this.soundPlayerHint != null) {
                        this.soundPlayerHint.stop();
                    }
                    if (this.soundPlayer != null) {
                        this.soundPlayer.stop();
                    }
                } catch (Exception e) {
                }
                startActivity(new Intent(this, HomePageActivity.class));
                finish();
                return;
            case C0470R.id.ivSLPwdVisible:
                Editable etable;
                if (this.bWifiPassword) {
                    this.bWifiPassword = false;
                    this.etSLWifiPassword.setInputType(Defines.NV_IP_PTZX_REQUEST);
                    this.ivSLPwdVisible.setImageResource(C0470R.drawable.netword_hide);
                    etable = this.etSLWifiPassword.getText();
                    Selection.setSelection(etable, etable.length());
                    return;
                }
                this.bWifiPassword = true;
                this.etSLWifiPassword.setInputType(144);
                this.ivSLPwdVisible.setImageResource(C0470R.drawable.netword_show_password);
                etable = this.etSLWifiPassword.getText();
                Selection.setSelection(etable, etable.length());
                return;
            case C0470R.id.btnSLStartConfig:
                if (isLanguage()) {
                    if (this.soundPlayerHint != null) {
                        this.soundPlayerHint.stop();
                    }
                    this.soundPlayerHint = MediaPlayer.create(this, C0470R.raw.device_perpare);
                    this.soundPlayerHint.setLooping(false);
                    this.soundPlayerHint.start();
                }
                String strSSID = this.etSLWifiSSID.getText().toString();
                String strPassword = this.etSLWifiPassword.getText().toString();
                this.nConfigID = LocalDefines.getConfigID();
                this.bIsConfiging = true;
                if (!(LocalDefines.getCurrentConnectedWifiSSIDName(this.mWiFiManager).equals(strSSID) || strSSID == null || strSSID.length() <= 0)) {
                    connectToSpecifiedWifi(strSSID, strPassword, this.mWifiEnrcrypt);
                }
                SmarkLinkTool.StartSmartConnection(this.nConfigID, strSSID, strPassword);
                this.searchAminatView.startAnimate();
                showSearchingPage();
                StartSearchDevice();
                if (isLanguage() && this.soundPlayerHint != null) {
                    this.soundPlayerHint.stop();
                }
                this.soundPlayer = MediaPlayer.create(this, C0470R.raw.seekmusic);
                this.soundPlayer.setLooping(true);
                this.soundPlayer.start();
                this.tvTimeLeft.setText(Constants.UNSTALL_PORT);
                this.nTimeoutDetectID++;
                new CountDownTimer(80000, 1000) {
                    int nCount = 80;
                    int nThreadID;

                    public void onTick(long millisUntilFinished) {
                        if (this.nThreadID == SmartLinkQuickWifiConfigActivity.this.nTimeoutDetectID && SmartLinkQuickWifiConfigActivity.this.tvTimeLeft != null) {
                            this.nCount--;
                            if (this.nCount < 0) {
                                this.nCount = 0;
                            }
                            try {
                                SmartLinkQuickWifiConfigActivity.this.tvTimeLeft.setText(this.nCount);
                            } catch (Exception e) {
                            }
                        }
                    }

                    public void onFinish() {
                        if (this.nThreadID == SmartLinkQuickWifiConfigActivity.this.nTimeoutDetectID) {
                            Message msg = SmartLinkQuickWifiConfigActivity.this.handler.obtainMessage();
                            msg.arg1 = 19;
                            SmartLinkQuickWifiConfigActivity.this.handler.sendMessage(msg);
                        }
                    }
                }.start();
                return;
            case C0470R.id.btnWifiQuikConfig:
                if (this.bIsSearching) {
                    StopSearchDevice();
                }
                if (VERSION.SDK_INT >= 23) {
                    initGPS();
                    return;
                }
                startActivity(new Intent(this, DeviceQuickConfigActivity.class));
                overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                finish();
                return;
            case C0470R.id.btnSLSearchBack:
                this.searchAminatView.stopAnimate();
                try {
                    if (isLanguage() && this.soundPlayerHint != null) {
                        this.soundPlayerHint.stop();
                    }
                    if (this.soundPlayer != null) {
                        this.soundPlayer.stop();
                    }
                } catch (Exception e2) {
                }
                this.bIsConfiging = false;
                SmarkLinkTool.StopSmartConnection();
                showInputPage();
                this.nTimeoutDetectID++;
                return;
            case C0470R.id.ivSoundWaveConfigBack:
                if (this.soundWaveConfigDialog != null) {
                    this.soundWaveConfigDialog.dismiss();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 0:
                if (permissions[0].equals("android.permission.ACCESS_COARSE_LOCATION") && grantResults[0] == 0) {
                    startActivity(new Intent(this, DeviceQuickConfigActivity.class));
                    overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                    finish();
                    return;
                }
                View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
                ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.str_permission_request));
                ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.str_permission_location));
                new Builder(this).setView(view).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new C04918()).show();
                return;
            default:
                return;
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
        this.lvSoundWaveConfigWifi.setSelection(arg2);
        if (this.locaWifiDeiviceList != null && this.locaWifiDeiviceList.size() > 0) {
            String WifiSSID = ((ScanResult) this.locaWifiDeiviceList.get(arg2)).SSID;
            this.mWifiEnrcrypt = encryCodeOfCapabilities(((ScanResult) this.locaWifiDeiviceList.get(arg2)).capabilities);
            if (WifiSSID != null && WifiSSID.length() > 0) {
                this.etSLWifiSSID.setText(WifiSSID);
                this.etSLWifiPassword.setText(Constants.MAIN_VERSION_TAG);
                Editable etable = this.etSLWifiSSID.getText();
                Selection.setSelection(etable, etable.length());
                if (this.soundWaveConfigDialog != null) {
                    this.soundWaveConfigDialog.dismiss();
                }
            }
        }
    }

    private int wifiEncrye(String capabilities) {
        if (capabilities.indexOf("WPA2") != -1) {
            return 3;
        }
        if (capabilities.indexOf("[WPA-PSK-TKIP+CCMP]") != -1 || capabilities.indexOf("[WPA2-PSK-TKIP+CCMP]") != -1) {
            return 3;
        }
        if (capabilities.indexOf("[WEP]") != -1 && capabilities.indexOf("[IBSS]") != -1) {
            return 2;
        }
        if (capabilities.indexOf("[WEP]") != -1) {
            return 2;
        }
        if (capabilities.indexOf("[WPA-PSK-CCMP]") != -1 || capabilities.indexOf("[WPA-PSK-TKIP+CCMP]") != -1) {
            return 3;
        }
        if (capabilities.indexOf("[WPA2-PSK-CCMP]") != -1 || capabilities.indexOf("[WPA2-PSK-TKIP+CCMP]") != -1) {
            return 3;
        }
        if (capabilities.indexOf("[ESS]") != -1) {
            return 1;
        }
        return 1;
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            this.bIsConfiging = false;
            SmarkLinkTool.StopSmartConnection();
            try {
                if (this.soundPlayerHint != null) {
                    this.soundPlayerHint.stop();
                }
                if (this.soundPlayer != null) {
                    this.soundPlayer.stop();
                }
            } catch (Exception e) {
            }
            if (this.lLayoutWifiInputPage.getVisibility() == 0) {
                startActivity(new Intent(this, HomePageActivity.class));
                finish();
            } else if (this.llayoutSLSearchingPage.getVisibility() == 0) {
                SmarkLinkTool.StopSmartConnection();
                showInputPage();
                StopSearchDevice();
            }
        }
        return false;
    }

    public boolean StartSearchDevice() {
        try {
            if (Functions.isNetworkAvailable(getApplicationContext())) {
                startBroadCastUdpThread();
                return true;
            }
            Toast toast = Toast.makeText(getApplicationContext(), getString(C0470R.string.toast_network_unreachable), 0);
            toast.setGravity(17, 0, 0);
            toast.show();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public void StopSearchDevice() {
        this.bIsSearching = false;
        this.m_nSearchID++;
        this.mIsSearchingMode = false;
    }

    public void startBroadCastUdpThread() {
        this.m_nSearchID++;
        this.bIsSearching = true;
        new BroadCastUdp(this.m_nSearchID).start();
    }

    private void initGPS() {
        if (((LocationManager) getSystemService(Headers.LOCATION)).isProviderEnabled("gps")) {
            startActivity(new Intent(this, DeviceQuickConfigActivity.class));
            overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
            finish();
            return;
        }
        View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.str_permission_request));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.str_hotspot));
        new Builder(this).setView(view).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new C04929()).show();
    }

    private void connectToSpecifiedWifi(String ssid, String psw, int type) {
        this.mWiFiAdnim.addNetWork(this.mWiFiAdnim.CreateWifiInfo(ssid, psw, type));
    }

    private int encryCodeOfCapabilities(String capabilities) {
        int nResult = 0;
        if (capabilities == null) {
            return 1;
        }
        if (capabilities.indexOf("WPA2") != -1) {
            nResult = 3;
        } else if (capabilities.indexOf("[WPA-PSK-TKIP+CCMP]") != -1 || capabilities.indexOf("[WPA2-PSK-TKIP+CCMP]") != -1) {
            nResult = 3;
        } else if (capabilities.indexOf("[WEP]") != -1 && capabilities.indexOf("[IBSS]") != -1) {
            nResult = 2;
        } else if (capabilities.indexOf("[WEP]") != -1) {
            nResult = 2;
        } else if (capabilities.indexOf("[WPA-PSK-CCMP]") != -1 || capabilities.indexOf("[WPA-PSK-TKIP+CCMP]") != -1) {
            nResult = 3;
        } else if (capabilities.indexOf("[WPA2-PSK-CCMP]") != -1 || capabilities.indexOf("[WPA2-PSK-TKIP+CCMP]") != -1) {
            nResult = 3;
        } else if (capabilities.indexOf("[ESS]") != -1) {
            nResult = 1;
        }
        return nResult;
    }

    public void StartBindDeviceThread(int DeviceId, String DeviceName, String DevicePassword, DeviceInfo info, int infoIndex) {
        this.n_BindDeviceThreadID++;
        new BindDeviceThread(this.n_BindDeviceThreadID, DeviceName, DevicePassword, this.handler, DeviceId, info, infoIndex).start();
    }

    public void postBindDeviceData(int DeviceId, String DeviceName, String DevicePassword, DeviceInfo info, int infoIndex) throws JSONException {
        long time = System.currentTimeMillis();
        String MDLoginSign = LoginActivity.md5("accesstoken=" + DeviceListViewFragment._Token + "&deviceaccount=" + DeviceName + "&deviceid=" + DeviceId + "&devicepassword=" + DevicePassword + "&timestamp=" + (time / 1000) + "hsshop2016");
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", time / 1000);
        json.put("accesstoken", DeviceListViewFragment._Token);
        json.put("deviceid", DeviceId);
        json.put("deviceaccount", DeviceName);
        json.put("devicepassword", DevicePassword);
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/device/bind", json.toString());
        System.out.println("服务器返回设备列表数�? = " + Recresult);
        if (Recresult != null) {
            JSONObject Bindjson = new JSONObject(Recresult);
            int result = Integer.valueOf(Bindjson.getString("result")).intValue();
            this.bindDevice_result = result;
            if (result == 0) {
                DeviceListViewFragment.SaveUpdateDeviceTime(Integer.valueOf(Bindjson.getInt("update_timestamp")).intValue());
            }
        }
    }

    private void httpResult401() {
        View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.str_Notic_Close_APP));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.str_401));
        AlertDialog dialog = new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                Editor modeEditor = SmartLinkQuickWifiConfigActivity.this.getSharedPreferences("ShareAPPMODE", 0).edit();
                modeEditor.putInt("GetModeNum", 0);
                modeEditor.commit();
                HomePageActivity.AppMode = 0;
                Editor editor = SmartLinkQuickWifiConfigActivity.this.getSharedPreferences("SaveTimeTamp", 0).edit();
                editor.putInt("TimeTamp", 0);
                editor.commit();
                SmartLinkQuickWifiConfigActivity.this.startActivity(new Intent(SmartLinkQuickWifiConfigActivity.this, LoginActivity.class));
                SmartLinkQuickWifiConfigActivity.this.finish();
            }
        }).create();
        dialog.setCancelable(false);
        dialog.show();
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (!(event.getAction() != 0 || getCurrentFocus() == null || getCurrentFocus().getWindowToken() == null)) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 2);
        }
        return super.onTouchEvent(event);
    }
}
