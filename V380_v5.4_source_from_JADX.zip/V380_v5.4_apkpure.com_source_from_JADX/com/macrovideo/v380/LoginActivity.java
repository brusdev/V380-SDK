package com.macrovideo.v380;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import com.macrovideo.httptool.HttpUtils;
import com.macrovideo.photo.PhotoViewAttacher;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends Activity implements OnClickListener, OnTouchListener {
    public static int LOGIN_THREAD_RESULT_CODE = 1;
    public static String data = null;
    private static String data_Username = null;
    public static String ecs_ip = "1.1.1.1";
    public static String ecs_ip2 = "1.1.1.1";
    public static int ecs_port = 8000;
    public static int ecs_port2 = 8000;
    public static int is_open_service = 0;
    static String key = "1234567890123456";
    public static int saveDatasign = -1;
    public static String token = null;
    public static int user_id = -101;
    private Long Dec_id = Long.valueOf(61069906);
    public int LOGIN_CODE = -100;
    private String LoginPassword;
    public int LoginThreadID = 0;
    private SharedPreferences SavePreference;
    private Button btn_experience;
    private Button btn_forgetPassword;
    private Button btn_login;
    private Button btn_register;
    private CheckBox cb_pswVisibility;
    public int dialogNo = -101;
    private Editor editor;
    private EditText et_account;
    private EditText et_password;
    @SuppressLint({"HandlerLeak"})
    private Handler handler = new C03741();
    private InputMethodManager imm;
    private boolean isRecFileListVisible = false;
    private boolean isRecFileLoadFromDatabase = false;
    private ImageView iv_cleanAccount;
    private ImageView iv_cleanPassword;
    private Dialog lDialog;
    private SharedPreferences login_data;
    private LinearLayout mBackground;
    private Dialog mLoginingDlg;
    private LinearLayout mMoveView;
    private LinearLayout mWholeView;
    private int nPageIndex = 10;
    private int nRadioIndex = 100;

    class C03741 extends Handler {
        C03741() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 == LoginActivity.LOGIN_THREAD_RESULT_CODE) {
                LoginActivity.this.mLoginingDlg.dismiss();
                switch (msg.arg2) {
                    case -1:
                        LoginActivity.this.closeLoginingDlg();
                        Toast.makeText(LoginActivity.this, LoginActivity.this.getString(C0470R.string.Network_Error), 0).show();
                        return;
                    case 0:
                        LoginActivity.this.getSharedPreferences("ShareAPPMODE", 0).edit().putInt("GetModeNum", 1).commit();
                        int preUserId = LoginActivity.this.SavePreference.getInt("saveServeruserid", -101);
                        LoginActivity.this.closeLoginingDlg();
                        Editor saveEditor = LoginActivity.this.SavePreference.edit();
                        saveEditor.putInt("savesign", 1);
                        saveEditor.putString("save_username", LoginActivity.this.et_account.getText().toString());
                        String LoginAccount = LoginActivity.this.et_account.getText().toString();
                        Bundle bundle = new Bundle();
                        bundle.putInt("preUserId", preUserId);
                        bundle.putInt("page_index", LoginActivity.this.nPageIndex);
                        bundle.putInt("radio_index", LoginActivity.this.nRadioIndex);
                        bundle.putBoolean("has_serverinfo", LoginActivity.this.isRecFileListVisible);
                        if (LoginActivity.this.CheckLoginWay(LoginActivity.this.et_account.getText().toString())) {
                            saveEditor.putInt("saveloginway", 1);
                        } else {
                            saveEditor.putInt("saveloginway", 2);
                        }
                        saveEditor.putString("saveAccount", LoginAccount);
                        saveEditor.putString("saveToken", LoginActivity.token);
                        saveEditor.putInt("saveServeruserid", LoginActivity.user_id);
                        saveEditor.putInt("saveloginis_open_service", LoginActivity.is_open_service);
                        saveEditor.putString("saveloginEcsIp", LoginActivity.ecs_ip);
                        saveEditor.putString("saveloginEcsIp2", LoginActivity.ecs_ip2);
                        saveEditor.putInt("saveloginEcsport", LoginActivity.ecs_port);
                        saveEditor.putInt("saveloginEcsport2", LoginActivity.ecs_port2);
                        saveEditor.commit();
                        LocalDefines.shouldLoadUserDeviceList = true;
                        Intent intentLogin = new Intent(LoginActivity.this, HomePageActivity.class);
                        intentLogin.putExtras(bundle);
                        LoginActivity.this.startActivity(intentLogin);
                        LoginActivity.this.finish();
                        return;
                    case 500:
                        LoginActivity.this.closeLoginingDlg();
                        Toast.makeText(LoginActivity.this, LoginActivity.this.getString(C0470R.string.str_server_error), 0).show();
                        return;
                    case 10006:
                        LoginActivity.this.closeLoginingDlg();
                        Toast.makeText(LoginActivity.this, LoginActivity.this.getString(C0470R.string.fail_to_login), 0).show();
                        return;
                    default:
                        LoginActivity.this.closeLoginingDlg();
                        Toast.makeText(LoginActivity.this, LoginActivity.this.getString(C0470R.string.Login_failed), 0).show();
                        return;
                }
            }
        }
    }

    class C03752 implements TextWatcher {
        C03752() {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (s == null || s.toString().equals(Constants.MAIN_VERSION_TAG)) {
                LoginActivity.this.iv_cleanAccount.setVisibility(8);
            } else {
                LoginActivity.this.iv_cleanAccount.setVisibility(0);
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void afterTextChanged(Editable s) {
        }
    }

    class C03763 implements OnEditorActionListener {
        C03763() {
        }

        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if (actionId == 6 || actionId == 2) {
                LoginActivity.this.login();
            }
            return false;
        }
    }

    class C03774 implements TextWatcher {
        C03774() {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (s == null || s.toString().equals(Constants.MAIN_VERSION_TAG)) {
                LoginActivity.this.iv_cleanPassword.setVisibility(8);
            } else {
                LoginActivity.this.iv_cleanPassword.setVisibility(0);
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void afterTextChanged(Editable s) {
        }
    }

    class C03785 implements OnCheckedChangeListener {
        C03785() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            LoginActivity.this.setPasswordVisibility(isChecked);
        }
    }

    class DialogTimeCount extends CountDownTimer {
        public DialogTimeCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        public void onFinish() {
            LoginActivity.this.lDialog.dismiss();
        }

        public void onTick(long millisUntilFinished) {
        }
    }

    public class LoginThread extends Thread {
        private Handler handler;
        private int m_ThreadLoginID = 0;

        public LoginThread(Handler handler, int nLoginThreadID) {
            this.handler = handler;
            this.m_ThreadLoginID = nLoginThreadID;
        }

        public void run() {
            super.run();
            try {
                if (this.m_ThreadLoginID == LoginActivity.this.LoginThreadID) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    LoginActivity.this.PostData();
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
            if (this.m_ThreadLoginID == LoginActivity.this.LoginThreadID) {
                Message msg = this.handler.obtainMessage();
                msg.arg1 = LoginActivity.LOGIN_THREAD_RESULT_CODE;
                msg.arg2 = LoginActivity.this.LOGIN_CODE;
                this.handler.sendMessage(msg);
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(C0470R.layout.activity_login);
        Bundle data = getIntent().getExtras();
        if (data != null) {
            this.nPageIndex = data.getInt("page_index");
            this.nRadioIndex = data.getInt("radio_index");
            this.isRecFileListVisible = data.getBoolean("has_serverinfo");
        }
        this.SavePreference = getSharedPreferences("SaveSign", 0);
        saveDatasign = this.SavePreference.getInt("savesign", -101);
        data_Username = this.SavePreference.getString("save_username", null);
        initViews();
        this.imm = (InputMethodManager) getSystemService("input_method");
    }

    protected void onStart() {
        super.onStart();
    }

    protected void onDestroy() {
        super.onDestroy();
        BitmapDrawable bg = (BitmapDrawable) this.mBackground.getBackground();
        this.mBackground.setBackgroundResource(0);
        bg.setCallback(null);
        if (bg.getBitmap() != null) {
            bg.getBitmap().recycle();
        }
        System.gc();
    }

    private void initViews() {
        this.iv_cleanAccount = (ImageView) findViewById(C0470R.id.iv_clean_account);
        this.iv_cleanAccount.setOnClickListener(this);
        this.iv_cleanPassword = (ImageView) findViewById(C0470R.id.iv_clean_psw);
        this.iv_cleanPassword.setOnClickListener(this);
        initLoginingDlg();
        this.et_account = (EditText) findViewById(C0470R.id.et_login_account);
        this.et_account.setTypeface(Typeface.SANS_SERIF);
        this.et_account.setImeOptions(5);
        this.et_account.addTextChangedListener(new C03752());
        if (saveDatasign == 1) {
            this.et_account.setText(data_Username);
            this.et_account.setSelection(data_Username.length());
        }
        this.et_password = (EditText) findViewById(C0470R.id.et_login_password);
        this.et_password.setImeOptions(6);
        this.et_password.setImeOptions(2);
        this.et_password.setTypeface(Typeface.SANS_SERIF);
        this.et_password.setOnEditorActionListener(new C03763());
        this.et_password.addTextChangedListener(new C03774());
        this.et_account.setOnTouchListener(this);
        this.et_password.setOnTouchListener(this);
        this.cb_pswVisibility = (CheckBox) findViewById(C0470R.id.cb_psw_visibility);
        this.cb_pswVisibility.setOnCheckedChangeListener(new C03785());
        this.btn_forgetPassword = (Button) findViewById(C0470R.id.btn_login_forget_psw);
        this.btn_forgetPassword.setOnClickListener(this);
        this.btn_register = (Button) findViewById(C0470R.id.btn_login_register);
        this.btn_register.setOnClickListener(this);
        this.btn_login = (Button) findViewById(C0470R.id.btn_login);
        this.btn_login.setOnClickListener(this);
        this.btn_experience = (Button) findViewById(C0470R.id.btn_entry_experience_app);
        this.btn_experience.setOnClickListener(this);
        this.mWholeView = (LinearLayout) findViewById(C0470R.id.whole_view);
        this.mMoveView = (LinearLayout) findViewById(C0470R.id.move_view);
        this.mBackground = (LinearLayout) findViewById(C0470R.id.root_view);
        this.mBackground.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.bg_login)));
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.iv_clean_account:
                this.et_account.setText(Constants.MAIN_VERSION_TAG);
                return;
            case C0470R.id.iv_clean_psw:
                this.et_password.setText(Constants.MAIN_VERSION_TAG);
                return;
            case C0470R.id.btn_login_forget_psw:
                startActivity(new Intent(this, ForgetPasswordActivity.class));
                return;
            case C0470R.id.btn_login_register:
                startActivity(new Intent(this, RegisterActivity.class));
                return;
            case C0470R.id.btn_login:
                if (this.et_account.getText().toString().equals(Constants.MAIN_VERSION_TAG)) {
                    Toast.makeText(this, getString(C0470R.string.Please_enter_username), 0).show();
                    return;
                } else if (this.et_password.getText().toString().equals(Constants.MAIN_VERSION_TAG)) {
                    Toast.makeText(this, getString(C0470R.string.Please_enter_password), 0).show();
                    return;
                } else {
                    showLoginingDlg();
                    startLoginThread();
                    return;
                }
            case C0470R.id.btn_entry_experience_app:
                getSharedPreferences("ShareAPPMODE", 0).edit().putInt("GetModeNum", 0).commit();
                Bundle bundle = new Bundle();
                bundle.putInt("page_index", this.nPageIndex);
                bundle.putInt("radio_index", this.nRadioIndex);
                bundle.putBoolean("has_serverinfo", this.isRecFileListVisible);
                Intent experience_intent = new Intent(this, HomePageActivity.class);
                experience_intent.putExtras(bundle);
                startActivity(experience_intent);
                finish();
                return;
            default:
                return;
        }
    }

    public boolean onTouch(View v, MotionEvent event) {
        switch (v.getId()) {
            case C0470R.id.et_login_account:
                if (this.mMoveView.getAlpha() == PhotoViewAttacher.DEFAULT_MIN_SCALE) {
                    ObjectAnimator.ofFloat(this.mMoveView, "alpha", new float[]{PhotoViewAttacher.DEFAULT_MIN_SCALE, 0.0f}).setDuration(300).start();
                    ObjectAnimator.ofFloat(this.mWholeView, "translationY", new float[]{0.0f, (float) (((-this.mMoveView.getHeight()) * 2) / 3)}).setDuration(300).start();
                    break;
                }
                break;
            case C0470R.id.et_login_password:
                if (this.mMoveView.getAlpha() == PhotoViewAttacher.DEFAULT_MIN_SCALE) {
                    ObjectAnimator.ofFloat(this.mMoveView, "alpha", new float[]{PhotoViewAttacher.DEFAULT_MIN_SCALE, 0.0f}).setDuration(300).start();
                    ObjectAnimator.ofFloat(this.mWholeView, "translationY", new float[]{0.0f, (float) (((-this.mMoveView.getHeight()) * 2) / 3)}).setDuration(300).start();
                    break;
                }
                break;
        }
        return false;
    }

    private void login() {
        checkInput(this.et_account.getText().toString().trim(), this.et_password.getText().toString().trim());
    }

    private void fastRegister() {
        startActivity(new Intent(this, RegisterActivity.class));
    }

    private void forgetPassword() {
    }

    private boolean checkInput(String account, String password) {
        return false;
    }

    private void setPasswordVisibility(boolean isVisible) {
        if (isVisible) {
            this.et_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            this.et_password.setSelection(this.et_password.getText().toString().length());
            return;
        }
        this.et_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
        this.et_password.setSelection(this.et_password.getText().toString().length());
    }

    public void startLoginThread() {
        this.LoginThreadID++;
        new LoginThread(this.handler, this.LoginThreadID).start();
    }

    private void PostData() throws JSONException {
        DecimalFormat df = new DecimalFormat("#.##");
        Intent intent = getIntent();
        try {
            this.LoginPassword = byte2hex(encrypt(this.et_password.getText().toString().getBytes(), key.getBytes()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        String Password = this.LoginPassword;
        long time = System.currentTimeMillis();
        String MDLoginSign = md5("password=" + Password + "&phonetoken=100&timestamp=" + (time / 1000) + "&username=" + this.et_account.getText().toString() + "hsshop2016");
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", (time / 1000));
        json.put("username", this.et_account.getText().toString());
        json.put("password", Password);
        json.put("phonetoken", "100");
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/user/login", json.toString());
        data = Recresult;
        if (Recresult == null) {
            return;
        }
        if (Recresult.equals("-1")) {
            this.LOGIN_CODE = -1;
            return;
        }
        JSONObject jSONObject = new JSONObject(Recresult);
        if (jSONObject != null) {
            this.LOGIN_CODE = Integer.valueOf(jSONObject.getString("result")).intValue();
            int error_code = Integer.valueOf(jSONObject.getString("error_code")).intValue();
            if (this.LOGIN_CODE == 0) {
                String data = jSONObject.getString("data");
                if (data != null) {
                    jSONObject = new JSONObject(data);
                    token = jSONObject.getString("access_token");
                    user_id = Integer.valueOf(jSONObject.getString("user_id")).intValue();
                    is_open_service = Integer.valueOf(jSONObject.getString("is_open_service")).intValue();
                    ecs_ip = jSONObject.getString("ecs_ip");
                    ecs_port = Integer.valueOf(jSONObject.getString("ecs_port")).intValue();
                    ecs_ip2 = jSONObject.getString("ecs_ip2");
                    ecs_port2 = Integer.valueOf(jSONObject.getString("ecs_port2")).intValue();
                }
            }
        }
    }

    public static String md5(String string) {
        try {
            byte[] hash = MessageDigest.getInstance("MD5").digest(string.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder(hash.length * 2);
            for (byte b : hash) {
                if ((b & 255) < 16) {
                    hex.append("0");
                }
                hex.append(Integer.toHexString(b & 255));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Huh, MD5 should be supported?", e);
        } catch (UnsupportedEncodingException e2) {
            throw new RuntimeException("Huh, UTF-8 should be supported?", e2);
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (!(event.getAction() != 0 || getCurrentFocus() == null || getCurrentFocus().getWindowToken() == null)) {
            this.imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 2);
            if (this.mMoveView.getAlpha() == 0.0f) {
                ObjectAnimator.ofFloat(this.mMoveView, "alpha", new float[]{0.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE}).setDuration(300).start();
                ObjectAnimator.ofFloat(this.mWholeView, "translationY", new float[]{(float) (((-this.mMoveView.getHeight()) * 2) / 3), 0.0f}).setDuration(300).start();
            }
        }
        return super.onTouchEvent(event);
    }

    private void showLoginingDlg() {
        if (this.mLoginingDlg != null) {
            this.mLoginingDlg.show();
        }
    }

    private void closeLoginingDlg() {
        if (this.mLoginingDlg != null && this.mLoginingDlg.isShowing()) {
            this.mLoginingDlg.dismiss();
        }
    }

    private void initLoginingDlg() {
        this.mLoginingDlg = new Dialog(this, C0470R.style.loginingDlg);
        this.mLoginingDlg.setContentView(C0470R.layout.logining_dlg);
        LayoutParams params = this.mLoginingDlg.getWindow().getAttributes();
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int cxScreen = dm.widthPixels;
        int height = (int) getResources().getDimension(C0470R.dimen.loginingdlg_height);
        int lrMargin = (int) getResources().getDimension(C0470R.dimen.loginingdlg_lr_margin);
        int topMargin = (int) getResources().getDimension(C0470R.dimen.loginingdlg_top_margin);
        params.y = ((-(dm.heightPixels - height)) / 2) + topMargin;
        params.width = cxScreen;
        params.height = height;
        this.mLoginingDlg.setCanceledOnTouchOutside(false);
    }

    public static byte[] encrypt(byte[] data, byte[] key) throws Exception {
        Key k = toKey(key);
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(1, k);
        return cipher.doFinal(data);
    }

    public static Key toKey(byte[] key) throws Exception {
        return new SecretKeySpec(key, "AES");
    }

    public static String byte2hex(byte[] b) {
        StringBuffer sb = new StringBuffer(b.length * 2);
        String tmp = Constants.MAIN_VERSION_TAG;
        for (byte b2 : b) {
            tmp = Integer.toHexString(b2 & 255);
            if (tmp.length() == 1) {
                sb.append("0");
            }
            sb.append(tmp);
        }
        return sb.toString();
    }

    public boolean CheckLoginWay(String username) {
        return RegisterActivity.isMobileNO(username);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            closeLoginingDlg();
            this.LoginThreadID++;
            Process.killProcess(Process.myPid());
            System.exit(0);
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
