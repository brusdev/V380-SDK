package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.software.update.Software;
import com.macrovideo.software.update.UpdateService;
import java.util.StringTokenizer;
import org.json.JSONException;
import org.json.JSONObject;

public class AboutActivity extends Activity implements OnClickListener {
    private int _nUpdateCheckThreadID = 0;
    private Button btnCheckForUpdate;
    private ImageView ivAboutLogo;
    private ImageView ivBackToHomePageActivity;
    Handler lHandler = new C02461();
    private ProgressDialog progressDialog;
    private Software software;
    private Dialog softwareUpdateDialog;

    class C02461 extends Handler {
        C02461() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            if (msg.arg1 == LocalDefines.APP_UPDATE_RESULT) {
                if (AboutActivity.this.progressDialog != null) {
                    AboutActivity.this.progressDialog.dismiss();
                }
                if (msg.arg2 == LocalDefines.APP_UPDATE_RESULT_HAS_NEW) {
                    LocalDefines._lCheckTime = System.currentTimeMillis();
                    LocalDefines._nCheckVersionNUm = AboutActivity.this.software.getnVersionNum();
                    AboutActivity.this.NewVersionNotice();
                    return;
                }
                Toast.makeText(AboutActivity.this, AboutActivity.this.getString(C0470R.string.notNewVersion), 0).show();
            }
        }
    }

    class C02472 implements OnClickListener {
        C02472() {
        }

        public void onClick(View v) {
            AboutActivity.this.softwareUpdateDialog.dismiss();
        }
    }

    class C02483 implements OnClickListener {
        C02483() {
        }

        public void onClick(View v) {
            AboutActivity.this.updateAPP();
            AboutActivity.this.softwareUpdateDialog.dismiss();
        }
    }

    public class AppUpdateCheckThread extends Thread {
        private Handler lHandler = null;
        private int nThreadID = 0;

        public AppUpdateCheckThread(Handler lHandler, int nThreadID) {
            this.nThreadID = nThreadID;
            this.lHandler = lHandler;
        }

        public void run() {
            JSONObject jsonCheckResult;
            JSONException e;
            JSONObject json = new JSONObject();
            try {
                json.put("app_id", LocalDefines.APP_ID_V380);
                json.put("app_name", LocalDefines.ANDROID_APP_NAME);
                json.put(LocalDefines.APP_VERSION, Functions.getVersionName(AboutActivity.this));
                json.put("system_id", 200);
                json.put("system_ver", Functions.getSystemVersion());
                String requestResult;
                int result;
                boolean bHasNew;
                JSONObject jsonNewVersion;
                JSONObject jSONObject;
                if (LocalDefines.strSysLan == null || LocalDefines.strSysLan.length() <= 0) {
                    json.put("system_lan", "cn");
                    requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strUpdate, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_SOFTWARE_UPDATE).append(json.toString()).toString());
                    result = LocalDefines.APP_UPDATE_RESULT_NO_NEW;
                    bHasNew = false;
                    if (requestResult != null && this.nThreadID == AboutActivity.this._nUpdateCheckThreadID) {
                        try {
                            jsonCheckResult = new JSONObject(requestResult);
                            if (jsonCheckResult != null) {
                                try {
                                    if (jsonCheckResult.getInt("result") == LocalDefines.APP_UPDATE_RESULT_HAS_NEW) {
                                        jsonNewVersion = jsonCheckResult.getJSONObject("new_version_info");
                                        if (jsonNewVersion != null) {
                                            if (AboutActivity.this.software == null) {
                                                AboutActivity.this.software = new Software();
                                            }
                                            AboutActivity.this.software.setnAppID(jsonNewVersion.getInt("appID"));
                                            AboutActivity.this.software.setStrName(jsonNewVersion.getString("appName"));
                                            AboutActivity.this.software.setStrReleaseDate(jsonNewVersion.getString("appReleaseDate"));
                                            AboutActivity.this.software.setnSize(jsonNewVersion.getInt("appSize"));
                                            AboutActivity.this.software.setnVersionNum(jsonNewVersion.getInt("appVersionNum"));
                                            AboutActivity.this.software.setStrVersionName(jsonNewVersion.getString("appVersionName"));
                                            AboutActivity.this.software.setStrCompany(jsonNewVersion.getString("appCompany"));
                                            AboutActivity.this.software.setStrSite(jsonNewVersion.getString("appSite"));
                                            AboutActivity.this.software.setStrDescription(jsonNewVersion.getString("appDescription"));
                                            bHasNew = true;
                                            jSONObject = jsonCheckResult;
                                        }
                                    }
                                } catch (JSONException e2) {
                                    e = e2;
                                    jSONObject = jsonCheckResult;
                                    System.out.println(" " + e.toString());
                                    if (this.nThreadID == AboutActivity.this._nUpdateCheckThreadID) {
                                    }
                                }
                            }
                        } catch (JSONException e3) {
                            e = e3;
                            System.out.println(" " + e.toString());
                            if (this.nThreadID == AboutActivity.this._nUpdateCheckThreadID) {
                            }
                        }
                    }
                    if (this.nThreadID == AboutActivity.this._nUpdateCheckThreadID && this.lHandler != null) {
                        Message msg = this.lHandler.obtainMessage();
                        msg.arg1 = LocalDefines.APP_UPDATE_RESULT;
                        if (bHasNew) {
                            msg.arg2 = LocalDefines.APP_UPDATE_RESULT_HAS_NEW;
                        } else {
                            msg.arg2 = LocalDefines.APP_UPDATE_RESULT_NO_NEW;
                        }
                        this.lHandler.sendMessage(msg);
                        return;
                    }
                }
                json.put("system_lan", LocalDefines.strSysLan);
                requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strUpdate, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_SOFTWARE_UPDATE).append(json.toString()).toString());
                result = LocalDefines.APP_UPDATE_RESULT_NO_NEW;
                bHasNew = false;
                jsonCheckResult = new JSONObject(requestResult);
                if (jsonCheckResult != null) {
                    if (jsonCheckResult.getInt("result") == LocalDefines.APP_UPDATE_RESULT_HAS_NEW) {
                        jsonNewVersion = jsonCheckResult.getJSONObject("new_version_info");
                        if (jsonNewVersion != null) {
                            if (AboutActivity.this.software == null) {
                                AboutActivity.this.software = new Software();
                            }
                            AboutActivity.this.software.setnAppID(jsonNewVersion.getInt("appID"));
                            AboutActivity.this.software.setStrName(jsonNewVersion.getString("appName"));
                            AboutActivity.this.software.setStrReleaseDate(jsonNewVersion.getString("appReleaseDate"));
                            AboutActivity.this.software.setnSize(jsonNewVersion.getInt("appSize"));
                            AboutActivity.this.software.setnVersionNum(jsonNewVersion.getInt("appVersionNum"));
                            AboutActivity.this.software.setStrVersionName(jsonNewVersion.getString("appVersionName"));
                            AboutActivity.this.software.setStrCompany(jsonNewVersion.getString("appCompany"));
                            AboutActivity.this.software.setStrSite(jsonNewVersion.getString("appSite"));
                            AboutActivity.this.software.setStrDescription(jsonNewVersion.getString("appDescription"));
                            bHasNew = true;
                            jSONObject = jsonCheckResult;
                            if (this.nThreadID == AboutActivity.this._nUpdateCheckThreadID) {
                            }
                        }
                    }
                }
                if (this.nThreadID == AboutActivity.this._nUpdateCheckThreadID) {
                }
            } catch (JSONException e4) {
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_about);
        initViews();
    }

    private void initViews() {
        this.ivBackToHomePageActivity = (ImageView) findViewById(C0470R.id.ivBackToHomeActivity);
        this.ivBackToHomePageActivity.setOnClickListener(this);
        this.ivAboutLogo = (ImageView) findViewById(C0470R.id.iv_about_icon);
        this.ivAboutLogo.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.icon)));
        this.btnCheckForUpdate = (Button) findViewById(C0470R.id.btn_check_for_update);
        this.btnCheckForUpdate.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.ivBackToHomeActivity:
                finish();
                return;
            case C0470R.id.btn_check_for_update:
                if (this.progressDialog == null) {
                    this.progressDialog = new ProgressDialog(this);
                    this.progressDialog.setProgressStyle(0);
                    this.progressDialog.setMessage(getString(C0470R.string.querySoftwareing) + "...");
                    this.progressDialog.setCanceledOnTouchOutside(false);
                }
                this.progressDialog.show();
                checkAppUpdate();
                return;
            default:
                return;
        }
    }

    private void checkAppUpdate() {
        this._nUpdateCheckThreadID++;
        new AppUpdateCheckThread(this.lHandler, this._nUpdateCheckThreadID).start();
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.ivAboutLogo != null) {
            BitmapDrawable ivAboutLogoBg = (BitmapDrawable) this.ivAboutLogo.getBackground();
            this.ivAboutLogo.setBackgroundResource(0);
            if (ivAboutLogoBg != null) {
                ivAboutLogoBg.setCallback(null);
                ivAboutLogoBg.getBitmap().recycle();
                System.gc();
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }

    public void NewVersionNotice() {
        String strMessge = this.software.getStrDescription();
        String strWhatIsNew = null;
        int nCount = 1;
        if (strMessge != null) {
            StringTokenizer strTokens = new StringTokenizer(strMessge, ";");
            strWhatIsNew = strTokens.nextToken();
            while (strTokens.hasMoreTokens()) {
                nCount++;
                strWhatIsNew = new StringBuilder(String.valueOf(strWhatIsNew)).append("\n").append(strTokens.nextToken()).toString();
            }
        }
        View view = View.inflate(this, C0470R.layout.show_software_update_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.findNowVersion));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(strWhatIsNew);
        ((Button) view.findViewById(C0470R.id.btn_no)).setOnClickListener(new C02472());
        ((Button) view.findViewById(C0470R.id.btn_yes)).setOnClickListener(new C02483());
        this.softwareUpdateDialog = new Dialog(this);
        this.softwareUpdateDialog.requestWindowFeature(1);
        this.softwareUpdateDialog.setContentView(view);
        this.softwareUpdateDialog.show();
    }

    private void updateAPP() {
        try {
            Intent updateIntent = new Intent(this, UpdateService.class);
            updateIntent.putExtra("app_name", this.software.getStrName());
            updateIntent.putExtra("updateSite", this.software.getStrSite());
            startService(updateIntent);
        } catch (Exception e) {
        }
    }
}
