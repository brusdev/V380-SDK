package com.macrovideo.v380;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

public class CloudStorageWebViewActivity extends Activity implements OnClickListener {
    private TextView mBtnClose;
    private ProgressBar mProgressBar;
    private WebView mWebView;
    private String url;

    class C02681 extends WebViewClient {
        C02681() {
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
        }
    }

    class C02692 extends WebChromeClient {
        C02692() {
        }

        public void onProgressChanged(WebView view, int newProgress) {
            if (newProgress == 100) {
                CloudStorageWebViewActivity.this.mProgressBar.setVisibility(8);
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_cloud_storage_webview);
        Intent intent = getIntent();
        if (intent != null) {
            this.url = intent.getStringExtra("url");
        }
        initViews();
    }

    private void initViews() {
        this.mBtnClose = (TextView) findViewById(C0470R.id.iv_close);
        this.mBtnClose.setOnClickListener(this);
        this.mProgressBar = (ProgressBar) findViewById(C0470R.id.pb_cloud_storage);
        setWebView();
    }

    private void setWebView() {
        this.mWebView = (WebView) findViewById(C0470R.id.id_cloud_storage_webview);
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mProgressBar.setVisibility(0);
        this.mWebView.loadUrl(this.url);
        this.mWebView.setWebViewClient(new C02681());
        this.mWebView.setWebChromeClient(new C02692());
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.iv_close:
                setResult(13);
                finish();
                return;
            default:
                return;
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.mProgressBar.getVisibility() == 0) {
                this.mProgressBar.setVisibility(8);
            }
            if (this.mWebView.canGoBack()) {
                this.mWebView.goBack();
                return true;
            }
            setResult(13);
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
