package com.macrovideo.v380;

public class OnlineResult {
    int nAlarmStat = 0;
    int nOnlineStat = 0;
    int nReuslt = 0;

    public int getnReuslt() {
        return this.nReuslt;
    }

    public void setnReuslt(int nReuslt) {
        this.nReuslt = nReuslt;
    }

    public int getnOnlineStat() {
        return this.nOnlineStat;
    }

    public void setnOnlineStat(int nOnlineStat) {
        this.nOnlineStat = nOnlineStat;
    }

    public int getnAlarmStat() {
        return this.nAlarmStat;
    }

    public void setnAlarmStat(int nAlarmStat) {
        this.nAlarmStat = nAlarmStat;
    }
}
