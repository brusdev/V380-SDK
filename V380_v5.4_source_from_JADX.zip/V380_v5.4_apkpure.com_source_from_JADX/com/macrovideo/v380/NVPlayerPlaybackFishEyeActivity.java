package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import com.example.hyfisheyepano.GLFisheyeView;
import com.macrovideo.sdk.custom.RecordFileInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.media.ITimeTextCallback;
import com.macrovideo.sdk.media.LibContext;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrovideo.sdk.media.NVPanoPlayer;
import com.macrovideo.sdk.media.Player;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@SuppressLint({"NewApi"})
public class NVPlayerPlaybackFishEyeActivity extends Activity implements OnClickListener, OnSeekBarChangeListener, OnTouchListener {
    static final int CMD_ACCEPT = 37124;
    static final int CMD_AFFIRM = 37122;
    static final int CMD_ASKFORCNLNUM = 37128;
    static final int CMD_CHECKPSW = 37129;
    static final int CMD_CONNECTINFO = 37125;
    static final int CMD_EXIT = 37123;
    static final int CMD_REQUEST = 37121;
    static final int CMD_STREAMHEAD = 37126;
    static final int CMD_UDPSHAKE = 37127;
    private static final int MY_PERMISSION_REQUEST_STORAGE = 0;
    static final int SEND_BUFFER_DATA_SIZE = 504;
    static final int SEND_BUFFER_HEADER_SIZE = 8;
    static final int SEND_BUFFER_SIZE = 512;
    static final int SESSION_FRAME_BUFFER_SIZE = 65536;
    static final short SHOWCODE_HAS_DATA = (short) 3001;
    static final short SHOWCODE_LOADING = (short) 1001;
    static final short SHOWCODE_NEW_IMAGE = (short) 1002;
    static final short SHOWCODE_STOP = (short) 2001;
    static final short SHOWCODE_VIDEO = (short) 1004;
    static final int SIZE_CMDPACKET = 128;
    static final int SP_DATA = 127;
    static final short STAT_CONNECTING = (short) 2001;
    static final short STAT_DECODE = (short) 2003;
    static final short STAT_DISCONNECT = (short) 2005;
    static final short STAT_LOADING = (short) 2002;
    static final short STAT_MR_BUSY = (short) 2007;
    static final short STAT_MR_DISCONNECT = (short) 2008;
    static final short STAT_RESTART = (short) 2006;
    static final short STAT_STOP = (short) 2004;
    static String endTimetxt;
    static String startTimetxt;
    static int time_display;
    static int totaltime;
    private LinearLayout LayoutSeekBar;
    private final int PlayerMode1 = 0;
    private final int PlayerMode2 = 3;
    private final int PlayerMode3 = 7;
    private final int PlayerMode4 = 11;
    private final int PlayerMode5 = 6;
    private final int PlayerModeLand = 12;
    private final int PlayerModeViewAngel = 4;
    private RelativeLayout RlPlayerDevice;
    private TextView Time_display_view;
    private boolean bAnyway = true;
    Bitmap bm = null;
    private RelativeLayout bottomButton;
    private LinearLayout bottomButtonHorizontal;
    private Button btnCatpure;
    private Button btnCatpureHorizontal;
    private Button btnLastFile;
    private Button btnLastFileHorizontal;
    private Button btnNextFile;
    private Button btnNextFileHorizontal;
    private Button btnRepeat = null;
    private int camType;
    LinearLayout container = null;
    private LoginHandle deviceParam = null;
    private Handler handler = new C04261();
    private View iamgeViewConctentView = null;
    private Button imgCSMode5;
    private Button imgCSModeOriginal;
    private Button imgModeViewAngle;
    private Button imgWallOriginal;
    private boolean isPlayFishEyeFromCloud;
    private RelativeLayout layoutBottomBar;
    private LinearLayout layoutCenter = null;
    private LinearLayout layoutCrossScreenMode;
    private LinearLayout layoutTopBar = null;
    private int listID = 0;
    private LinearLayout llVideoPalyBakc;
    private LinearLayout llVideoPalyBakcHorizontal;
    private String mAccessToken;
    private ImageView mBtnBack;
    private ImageView mBtnBackHorizontal;
    private Button mBtnDeviceMode;
    private Button mBtnExpandMode;
    private Button mBtnSound;
    private Button mBtnSoundHorizontal;
    private Button mBtnStopAndPlay;
    private Button mBtnStopAndPlayHorizontal;
    private int mDeviceId;
    private String mEcsIP;
    private String mEcsIP2;
    private int mEcsPort;
    private int mEcsPort2;
    private GestureDetector mGestureDetector;
    private boolean mIsFinish = false;
    private boolean mIsOnDropUp = true;
    private boolean mIsPlaying = false;
    private boolean mIsToPlay = false;
    private int mListIndex;
    private LoginHandle mLoginHandle;
    private int mPlayMode = 0;
    private boolean mPlaySound = true;
    private PopupWindow mPopupDeviceMode;
    private PopupWindow mPopupExpandMode;
    private PopupWindow mPopupExpandMode2;
    private CloseActivityReceiver mReceiver;
    int mScreenHeight = 0;
    int mScreenWidth = 0;
    private TextView mTVTopServer = null;
    private TextView mTvRealTimeDisplay = null;
    private int mUserId;
    private boolean m_bFinish = false;
    private int m_nMRPort = 80;
    private int m_nPort = 5050;
    private String m_strFileName = Constants.MAIN_VERSION_TAG;
    private String m_strIP = "127.0.0.1";
    private String m_strLanIP = "127.0.0.1";
    private String m_strMRServer = Constants.MAIN_VERSION_TAG;
    private String m_strPassword = Constants.MAIN_VERSION_TAG;
    private String m_strUsername = "admin";
    private NVPanoPlayer mvMediaPlayer = null;
    private int nPlayerFileTime;
    private int nPlayerTime = 0;
    private int nScreenOrientation = 1;
    private int nToolsViewShowTickCount = 8;
    private Dialog screenshotDialog = null;
    private SeekBar seekBarPlayProgress = null;
    private SeekBar seekBarPlayProgressHorizontal = null;
    private int timerThreadID = 0;
    private TextView tvStartTime;
    private TextView tvStartTimeHorizontal;
    private TextView tvStopTime;
    private TextView tvStopTimeHorizontal;

    class C04261 extends Handler {
        C04261() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 != 4) {
                if (msg.arg1 == 3) {
                    if (NVPlayerPlaybackFishEyeActivity.this.nScreenOrientation == 2) {
                        NVPlayerPlaybackFishEyeActivity.this.hideToolsViews();
                    }
                } else if (msg.arg1 == 2) {
                    String strPlayer;
                    NVPlayerPlaybackFishEyeActivity.this.mIsOnDropUp = false;
                    NVPlayerPlaybackFishEyeActivity.this.seekBarPlayProgress.setProgress(msg.arg2);
                    NVPlayerPlaybackFishEyeActivity.this.seekBarPlayProgressHorizontal.setProgress(msg.arg2);
                    NVPlayerPlaybackFishEyeActivity nVPlayerPlaybackFishEyeActivity = NVPlayerPlaybackFishEyeActivity.this;
                    nVPlayerPlaybackFishEyeActivity.nPlayerTime = nVPlayerPlaybackFishEyeActivity.nPlayerTime + 1;
                    if (NVPlayerPlaybackFishEyeActivity.this.nPlayerTime >= 60) {
                        strPlayer = new StringBuilder(String.valueOf(NVPlayerPlaybackFishEyeActivity.this.nPlayerTime / 60)).append(":").append(NVPlayerPlaybackFishEyeActivity.this.nPlayerTime % 60).toString();
                    } else {
                        strPlayer = "00:" + NVPlayerPlaybackFishEyeActivity.this.nPlayerTime;
                    }
                    NVPlayerPlaybackFishEyeActivity.startTimetxt = strPlayer;
                    NVPlayerPlaybackFishEyeActivity.this.tvStartTime.setText(strPlayer);
                    NVPlayerPlaybackFishEyeActivity.this.tvStartTimeHorizontal.setText(strPlayer);
                }
            }
        }
    }

    class C04272 implements DialogInterface.OnClickListener {
        C04272() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            NVPlayerPlaybackFishEyeActivity.this.setResult(-1);
        }
    }

    class BottomMenuGestureListener extends SimpleOnGestureListener {
        BottomMenuGestureListener() {
        }

        public boolean onSingleTapConfirmed(MotionEvent e) {
            if (NVPlayerPlaybackFishEyeActivity.this.layoutBottomBar.getVisibility() != 0 || NVPlayerPlaybackFishEyeActivity.this.layoutCrossScreenMode.getVisibility() != 0) {
                NVPlayerPlaybackFishEyeActivity.this.showToolsViews();
            } else if (NVPlayerPlaybackFishEyeActivity.this.nScreenOrientation == 2) {
                NVPlayerPlaybackFishEyeActivity.this.hideToolsViews();
            }
            return false;
        }
    }

    class CloseActivityReceiver extends BroadcastReceiver {
        CloseActivityReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = LocalDefines.getReceiverActionString(NVPlayerPlaybackFishEyeActivity.this);
            if (intent != null && intent.getAction().equals(action)) {
                NVPlayerPlaybackFishEyeActivity.this.stopCurrentActivityFromBroadcast();
            }
        }
    }

    class TimerThread extends Thread {
        int mThreadID = 0;

        public TimerThread(int nThreadID) {
            this.mThreadID = nThreadID;
        }

        public void run() {
            while (this.mThreadID == NVPlayerPlaybackFishEyeActivity.this.timerThreadID) {
                NVPlayerPlaybackFishEyeActivity nVPlayerPlaybackFishEyeActivity = NVPlayerPlaybackFishEyeActivity.this;
                nVPlayerPlaybackFishEyeActivity.nToolsViewShowTickCount = nVPlayerPlaybackFishEyeActivity.nToolsViewShowTickCount - 1;
                if (NVPlayerPlaybackFishEyeActivity.this.nToolsViewShowTickCount <= 0 && this.mThreadID == NVPlayerPlaybackFishEyeActivity.this.timerThreadID) {
                    Message message = new Message();
                    message.arg1 = 3;
                    NVPlayerPlaybackFishEyeActivity.this.handler.sendMessage(message);
                    NVPlayerPlaybackFishEyeActivity.this.nToolsViewShowTickCount = 0;
                }
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    class C08383 implements ITimeTextCallback {
        C08383() {
        }

        public void setTimeText(final String timeText) {
            NVPlayerPlaybackFishEyeActivity.this.runOnUiThread(new Runnable() {
                public void run() {
                    NVPlayerPlaybackFishEyeActivity.this.mTvRealTimeDisplay.setText(timeText);
                }
            });
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            exitCurrentActivity();
        }
        return false;
    }

    public boolean writeSystemParam() {
        Editor editer = getSharedPreferences(Defines._fileName, 0).edit();
        editer.putBoolean("sound", this.mPlaySound);
        editer.commit();
        return true;
    }

    private void ShowAlert(String title, String msg) {
        try {
            new Builder(this).setTitle(title).setMessage(msg).setIcon(C0470R.drawable.icon).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C04272()).show();
        } catch (Exception e) {
        }
    }

    public void onPause() {
        if (this.mIsPlaying) {
            PausePlay();
        }
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.nToolsViewShowTickCount = 8;
        this.timerThreadID++;
        new TimerThread(this.timerThreadID).start();
        if (!this.mIsFinish) {
            if (this.mIsPlaying) {
                ResumePlay();
            } else if (this.mIsToPlay) {
                startPlay();
            } else {
                stopPlay(true);
            }
        }
        this.m_bFinish = false;
        ((NotificationManager) getSystemService("notification")).cancelAll();
    }

    public void onDestroy() {
        this.mvMediaPlayer = null;
        super.onDestroy();
    }

    public void onStop() {
        this.timerThreadID++;
        if (this.m_bFinish) {
            LibContext.stopAll();
            LibContext.ClearContext();
        } else {
            NotificationManager notiManager = (NotificationManager) getSystemService("notification");
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
            builder.setContentTitle(getString(C0470R.string.app_name)).setContentText(getString(C0470R.string.app_notice)).setTicker(getString(C0470R.string.app_name)).setWhen(System.currentTimeMillis());
            int currentapiVersion = VERSION.SDK_INT;
            if (VERSION.SDK_INT >= 23) {
                builder.setSmallIcon(C0470R.drawable.my_device_3);
                builder.setLargeIcon(Functions.readBitMap(this, C0470R.drawable.icon));
            } else {
                builder.setSmallIcon(C0470R.drawable.icon_1);
            }
            Intent intent = new Intent(this, NVPlayerPlaybackFishEyeActivity.class);
            Bundle data = new Bundle();
            if (this.isPlayFishEyeFromCloud) {
                data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, this.mLoginHandle);
                data.putInt("play_index", this.mListIndex);
            } else {
                data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, this.deviceParam);
                data.putInt("play_index", this.listID);
            }
            intent.putExtras(data);
            intent.setFlags(335544320);
            notiManager.notify(257, builder.build());
            LibContext.stopAll();
        }
        this.m_bFinish = true;
        super.onStop();
    }

    private void ShowLandscapeView() {
        this.seekBarPlayProgress.setVisibility(8);
        this.tvStartTime.setVisibility(8);
        this.tvStopTime.setVisibility(8);
        synchronized (this) {
            if (this.mPopupExpandMode != null && this.mPopupExpandMode.isShowing()) {
                this.mPopupExpandMode.dismiss();
            }
            this.nToolsViewShowTickCount = 5;
            this.bAnyway = false;
            hideToolsViews();
            int nWidth = this.mScreenWidth;
            int nHeight = this.mScreenHeight;
            double dWidth = ((double) nHeight) * 1.7777777d;
            if (dWidth < ((double) nWidth)) {
                nWidth = (int) dWidth;
            }
            if (this.layoutCenter != null) {
                LayoutParams rlp = new LayoutParams(nWidth, nHeight);
                rlp.addRule(13, -1);
                this.layoutCenter.setLayoutParams(rlp);
                this.layoutCenter.setPadding(0, 0, 0, 0);
            }
            this.container.setPadding(0, 0, 0, 0);
            this.nScreenOrientation = 2;
            this.mvMediaPlayer.onOreintationChange(this.nScreenOrientation);
            this.mvMediaPlayer.getGLFisheyeView().setMode(12);
        }
    }

    private void ShowPortrailView() {
        this.seekBarPlayProgress.setVisibility(0);
        synchronized (this) {
            float scale = getResources().getDisplayMetrics().density;
            int padding_in_px = (int) ((((float) 45) * scale) + 0.5f);
            this.bAnyway = true;
            showToolsViews();
            int nWidth = this.mScreenWidth;
            int nHeight = (int) ((((float) this.mScreenHeight) - ((185.0f * scale) + 0.5f)) - ((float) LocalDefines.getStatusBarHeight(this)));
            if (this.layoutCenter != null) {
                LayoutParams rlp = new LayoutParams(nWidth, nHeight);
                rlp.addRule(10, -1);
                this.layoutCenter.setLayoutParams(rlp);
                this.layoutCenter.setPadding(0, padding_in_px, 0, 0);
            }
            int padding = (int) ((((double) (nHeight - padding_in_px)) - (((double) nWidth) * 1.1d)) / 2.0d);
            if (padding > 0) {
                this.container.setPadding(0, padding, 0, padding);
            }
            this.nScreenOrientation = 1;
            this.mvMediaPlayer.onOreintationChange(this.nScreenOrientation);
            this.mvMediaPlayer.getGLFisheyeView().setMode(this.mPlayMode);
        }
    }

    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        this.mScreenWidth = dm.widthPixels;
        this.mScreenHeight = dm.heightPixels;
        LocalDefines.loadResource(getResources());
        if (config.orientation == 2) {
            if (this.camType == 2) {
                this.layoutCrossScreenMode.setVisibility(8);
            } else if (this.camType == 1) {
                this.layoutCrossScreenMode.setVisibility(0);
            }
            ShowLandscapeView();
        } else if (config.orientation == 1) {
            this.layoutCrossScreenMode.setVisibility(8);
            ShowPortrailView();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(128, 128);
        requestWindowFeature(1);
        setRequestedOrientation(1);
        ((NotificationManager) getSystemService("notification")).cancel(257);
        setContentView(C0470R.layout.activity_nvplayer_fisheye_playbackview);
        registerReceiver(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        this.mScreenWidth = dm.widthPixels;
        this.mScreenHeight = dm.heightPixels;
        init();
        Bundle data = getIntent().getExtras();
        if (data != null) {
            this.isPlayFishEyeFromCloud = data.getBoolean("isPlayFishEyeFromCloud");
            if (this.isPlayFishEyeFromCloud) {
                this.mListIndex = data.getInt("play_index");
                this.mDeviceId = data.getInt(Constants.FLAG_DEVICE_ID);
                this.mAccessToken = data.getString("accesstoken");
                this.mUserId = data.getInt("user_id");
                this.mEcsIP = data.getString("ecs_ip");
                this.mEcsIP2 = data.getString("ecs_ip2");
                this.mEcsPort = data.getInt("ecs_port");
                this.mEcsPort2 = data.getInt("ecs_port2");
                this.mLoginHandle = (LoginHandle) data.getParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE);
                this.camType = this.mLoginHandle.getCamType();
            } else {
                this.listID = data.getInt("play_index");
                this.deviceParam = (LoginHandle) data.getParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE);
                this.camType = data.getInt("cam_type");
            }
        }
        this.mTVTopServer = (TextView) findViewById(C0470R.id.tvPlayerDevice);
        this.mTVTopServer.setText(this.m_strFileName);
        this.layoutTopBar = (LinearLayout) findViewById(C0470R.id.linearLayoutTopBar);
        this.layoutCenter = (LinearLayout) findViewById(C0470R.id.playbackContainer);
        this.layoutBottomBar = (RelativeLayout) findViewById(C0470R.id.linearLayoutBottomBar);
        this.layoutCrossScreenMode = (LinearLayout) findViewById(C0470R.id.PB_cross_screen_mode);
        this.LayoutSeekBar = (LinearLayout) findViewById(C0470R.id.bg_seekbar);
        this.LayoutSeekBar.getBackground().setAlpha(95);
        this.container = (LinearLayout) findViewById(C0470R.id.playbackContainer1);
        this.mvMediaPlayer = new NVPanoPlayer(getApplication(), this.nScreenOrientation, 0);
        this.mvMediaPlayer.setTvTimeOSD(new C08383());
        GLFisheyeView glFisheyeView = new GLFisheyeView(getApplication());
        glFisheyeView.setMode(this.mPlayMode);
        this.mvMediaPlayer.setGlFishView(glFisheyeView);
        if (this.camType == 1) {
            this.mvMediaPlayer.setFixType(1);
        } else if (this.camType == 2) {
            this.mvMediaPlayer.setFixType(0);
        }
        this.mvMediaPlayer.GetHandler(this.handler);
        this.mGestureDetector = new GestureDetector(this, new BottomMenuGestureListener());
        this.mvMediaPlayer.getGLFisheyeView().setOnTouchListener(this);
        this.container.addView(this.mvMediaPlayer.getGLFisheyeView());
        LibContext.SetContext(this.mvMediaPlayer, null, null, null);
        Player.SelectWindow(0);
        this.btnRepeat = (Button) findViewById(C0470R.id.btnRepeat1);
        this.btnRepeat.setOnClickListener(this);
        this.btnRepeat.setVisibility(8);
        this.mBtnExpandMode = (Button) findViewById(C0470R.id.btn_mode);
        this.mBtnExpandMode.setOnClickListener(this);
        this.mBtnDeviceMode = (Button) findViewById(C0470R.id.btn_device_camera);
        this.mBtnDeviceMode.setOnClickListener(this);
        if (this.camType == 2) {
            this.mBtnDeviceMode.setBackgroundResource(C0470R.drawable.device_ceiling_btn);
        } else if (this.camType == 1) {
            this.mBtnDeviceMode.setBackgroundResource(C0470R.drawable.device_wall_btn);
        }
        this.mBtnBack = (ImageView) findViewById(C0470R.id.btnPBBackToLogin);
        this.mBtnBack.setOnClickListener(this);
        this.mBtnBackHorizontal = (ImageView) findViewById(C0470R.id.btnPBBackToLoginHprizontal);
        this.mBtnBackHorizontal.setOnClickListener(this);
        this.mBtnStopAndPlay = (Button) findViewById(C0470R.id.btnPBStopAndPlay);
        this.mBtnStopAndPlay.setOnClickListener(this);
        this.mBtnStopAndPlayHorizontal = (Button) findViewById(C0470R.id.btnPBStopAndPlayHorizontal);
        this.mBtnStopAndPlayHorizontal.setOnClickListener(this);
        this.mBtnSound = (Button) findViewById(C0470R.id.btnPBAudio);
        this.mBtnSound.setOnClickListener(this);
        this.mBtnSoundHorizontal = (Button) findViewById(C0470R.id.btnPBAudioHorizontal);
        this.mBtnSoundHorizontal.setOnClickListener(this);
        this.imgCSModeOriginal = (Button) findViewById(C0470R.id.PB_iv_cross_screen_expand_normal);
        this.imgCSModeOriginal.setOnClickListener(this);
        this.imgCSMode5 = (Button) findViewById(C0470R.id.PB_iv_cross_screen_expand_mode5);
        this.imgCSMode5.setOnClickListener(this);
        if (this.mPlaySound) {
            this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn));
            this.mBtnSoundHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal));
        } else {
            this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn2));
            this.mBtnSoundHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal2));
        }
        this.seekBarPlayProgress = (SeekBar) findViewById(C0470R.id.seekBarPlayProgress);
        this.seekBarPlayProgress.setOnSeekBarChangeListener(this);
        this.seekBarPlayProgress.setMax(100);
        this.seekBarPlayProgress.setProgress(0);
        this.seekBarPlayProgressHorizontal = (SeekBar) findViewById(C0470R.id.seekBarPlayProgressHorizontal);
        this.seekBarPlayProgressHorizontal.setOnSeekBarChangeListener(this);
        this.seekBarPlayProgressHorizontal.setMax(100);
        this.seekBarPlayProgressHorizontal.setProgress(0);
        this.mIsPlaying = false;
        this.mIsToPlay = true;
        ShowPortrailView();
        createDialogs();
    }

    private void init() {
        this.mTvRealTimeDisplay = (TextView) findViewById(C0470R.id.tv_display_real_time1);
        this.tvStartTime = (TextView) findViewById(C0470R.id.tvStartTime);
        this.tvStopTime = (TextView) findViewById(C0470R.id.tvStopTime);
        this.tvStartTimeHorizontal = (TextView) findViewById(C0470R.id.tvStartTimeHorizontal);
        this.tvStopTimeHorizontal = (TextView) findViewById(C0470R.id.tvStopTimeHorizontal);
        this.btnLastFile = (Button) findViewById(C0470R.id.btnLastFlie);
        this.btnLastFile.setOnClickListener(this);
        this.btnLastFileHorizontal = (Button) findViewById(C0470R.id.btnLastFlieHorizontal);
        this.btnLastFileHorizontal.setOnClickListener(this);
        this.btnNextFile = (Button) findViewById(C0470R.id.btnNextFile);
        this.btnNextFile.setOnClickListener(this);
        this.btnNextFileHorizontal = (Button) findViewById(C0470R.id.btnNextFileHorizontal);
        this.btnNextFileHorizontal.setOnClickListener(this);
        this.btnCatpure = (Button) findViewById(C0470R.id.btnCatpure);
        this.btnCatpure.setOnClickListener(this);
        this.btnCatpureHorizontal = (Button) findViewById(C0470R.id.btnCatpureHorizontal);
        this.btnCatpureHorizontal.setOnClickListener(this);
        this.bottomButtonHorizontal = (LinearLayout) findViewById(C0470R.id.bottomButtonHorizontal);
        this.bottomButtonHorizontal.getBackground().setAlpha(95);
        this.bottomButton = (RelativeLayout) findViewById(C0470R.id.bottomButton);
        this.llVideoPalyBakc = (LinearLayout) findViewById(C0470R.id.llVideoPalyBakc);
        this.llVideoPalyBakcHorizontal = (LinearLayout) findViewById(C0470R.id.llVideoPalyBakcHorizontal);
        this.RlPlayerDevice = (RelativeLayout) findViewById(C0470R.id.RlPlayerDevice);
        this.Time_display_view = (TextView) findViewById(C0470R.id.Time_display);
        this.Time_display_view.getBackground().setAlpha(95);
    }

    private void stopPlay(boolean bFlag) {
        this.mBtnBack.setClickable(false);
        if (this.seekBarPlayProgress != null) {
            this.seekBarPlayProgress.setProgress(0);
            this.seekBarPlayProgress.setEnabled(false);
        }
        if (this.seekBarPlayProgressHorizontal != null) {
            this.seekBarPlayProgressHorizontal.setProgress(0);
            this.seekBarPlayProgressHorizontal.setEnabled(false);
        }
        this.mIsFinish = false;
        this.mIsPlaying = false;
        this.mTVTopServer.setText(this.m_strFileName);
        if (this.isPlayFishEyeFromCloud) {
            this.mvMediaPlayer.StopCloudPlayBack();
        } else {
            this.mvMediaPlayer.StopPlayBack();
        }
        this.mvMediaPlayer.pauseAudio();
        this.mBtnStopAndPlay.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn));
        this.mBtnStopAndPlayHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn_horziontal));
        this.mIsFinish = true;
    }

    private void startPlay() {
        this.mIsFinish = false;
        this.mBtnBack.setClickable(true);
        if (this.btnRepeat != null) {
            this.btnRepeat.setVisibility(8);
        }
        setRequestedOrientation(4);
        this.mvMediaPlayer.pauseAudio();
        this.mTVTopServer.setText(this.m_strFileName);
        if (Player.CurrentSelPlayer() < 4) {
            RecordFileInfo recFile;
            Player.setPlaying(Player.CurrentSelPlayer(), true);
            this.mvMediaPlayer.EnableRender();
            this.seekBarPlayProgress.setProgress(0);
            this.seekBarPlayProgressHorizontal.setProgress(0);
            if (this.isPlayFishEyeFromCloud) {
                recFile = (RecordFileInfo) LocalDefines.cloudRecordFileList.get(this.mListIndex);
            } else {
                recFile = (RecordFileInfo) LocalDefines.listMapPlayerBackFile.get(this.listID);
            }
            if (recFile != null) {
                this.m_strFileName = recFile.getStrFileName();
                this.mTVTopServer.setText(this.m_strFileName);
                this.nPlayerFileTime = recFile.getuFileTimeLen();
                String strTime = Constants.MAIN_VERSION_TAG;
                this.nPlayerTime = 0;
                if (this.nPlayerFileTime >= 60) {
                    strTime = new StringBuilder(String.valueOf(this.nPlayerFileTime / 60)).append(":").append(this.nPlayerFileTime % 60).toString();
                    endTimetxt = strTime;
                    totaltime = totalSeconds("00:00", endTimetxt);
                } else {
                    strTime = "00:" + this.nPlayerFileTime;
                    endTimetxt = strTime;
                    totaltime = totalSeconds("00:00", endTimetxt);
                }
                this.tvStopTime.setText(strTime);
                this.tvStopTimeHorizontal.setText(strTime);
                if (this.isPlayFishEyeFromCloud) {
                    if (this.mvMediaPlayer.StartCloudPlayBack(0, this.mUserId, this.mDeviceId, "123", this.mAccessToken, this.mEcsIP, this.mEcsPort, recFile, this.mPlaySound, this.mLoginHandle)) {
                        this.mvMediaPlayer.playAudio();
                        this.mBtnStopAndPlay.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_stop_btn));
                        this.mBtnStopAndPlayHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_stop_btn_horziontal));
                        this.mIsPlaying = true;
                    }
                } else if (this.mvMediaPlayer.StartPlayBack(0, this.deviceParam, recFile, this.mPlaySound)) {
                    this.mvMediaPlayer.playAudio();
                    this.mBtnStopAndPlay.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_stop_btn));
                    this.mBtnStopAndPlayHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_stop_btn_horziontal));
                    this.mIsPlaying = true;
                }
                if (this.seekBarPlayProgress != null) {
                    this.seekBarPlayProgress.setEnabled(true);
                }
                if (this.seekBarPlayProgressHorizontal != null) {
                    this.seekBarPlayProgressHorizontal.setEnabled(true);
                }
            }
        }
    }

    private void PausePlay() {
        if (this.seekBarPlayProgress != null) {
            this.seekBarPlayProgress.setProgress(0);
            this.seekBarPlayProgress.setEnabled(false);
        }
        if (this.seekBarPlayProgressHorizontal != null) {
            this.seekBarPlayProgressHorizontal.setProgress(0);
            this.seekBarPlayProgressHorizontal.setEnabled(false);
        }
        this.mIsFinish = false;
        this.mIsPlaying = false;
        this.mTVTopServer.setText(this.m_strFileName);
        if (this.isPlayFishEyeFromCloud) {
            this.mvMediaPlayer.StopCloudPlayBack();
        } else {
            this.mvMediaPlayer.StopPlayBack();
        }
        this.mvMediaPlayer.pauseAudio();
        this.mBtnStopAndPlay.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn));
        this.mBtnStopAndPlayHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn_horziontal));
        this.mIsFinish = true;
    }

    private void ResumePlay() {
    }

    private void showPopWinPlayerMode(View v) {
        View playerModeView = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.popup_expand_mode_layout, null);
        final Button imgOriginal = (Button) playerModeView.findViewById(C0470R.id.iv_expand_normal);
        final Button imgCylindric = (Button) playerModeView.findViewById(C0470R.id.iv_expand_mode1);
        final Button imgQuad = (Button) playerModeView.findViewById(C0470R.id.iv_expand_mode2);
        final Button imgMode4 = (Button) playerModeView.findViewById(C0470R.id.iv_expand_mode3);
        final Button imgModeLongLatUD = (Button) playerModeView.findViewById(C0470R.id.iv_expand_mode4);
        final Button imgModeViewAngle = (Button) playerModeView.findViewById(C0470R.id.iv_expand_mode5);
        int PopWinWidth = 0;
        if (this.camType == 1) {
            imgCylindric.setVisibility(8);
            imgQuad.setVisibility(8);
            imgMode4.setVisibility(8);
            imgModeLongLatUD.setVisibility(8);
            PopWinWidth = 80;
        }
        if (this.camType == 2) {
            imgModeViewAngle.setVisibility(8);
            PopWinWidth = 200;
        }
        switch (this.mPlayMode) {
            case 0:
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                break;
            case 3:
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_bg_click);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                break;
            case 4:
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                break;
            case 6:
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_bg_click);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                break;
            case 7:
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_bg_click);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                break;
            case 11:
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_bg_click);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                break;
        }
        imgOriginal.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlaybackFishEyeActivity.this.mPopupExpandMode.dismiss();
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(0);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 0;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode1_btn);
            }
        });
        imgCylindric.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_bg_click);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlaybackFishEyeActivity.this.mPopupExpandMode.dismiss();
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(3);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 3;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode2_btn);
            }
        });
        imgQuad.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_bg_click);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlaybackFishEyeActivity.this.mPopupExpandMode.dismiss();
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(7);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 7;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode3_btn);
            }
        });
        imgMode4.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_bg_click);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlaybackFishEyeActivity.this.mPopupExpandMode.dismiss();
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(11);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 11;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode4_btn);
            }
        });
        imgModeLongLatUD.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_bg_click);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlaybackFishEyeActivity.this.mPopupExpandMode.dismiss();
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(6);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 6;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode5_btn);
            }
        });
        imgModeViewAngle.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                imgOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                imgCylindric.setBackgroundResource(C0470R.drawable.mode2_transparent);
                imgQuad.setBackgroundResource(C0470R.drawable.mode3_transparent);
                imgMode4.setBackgroundResource(C0470R.drawable.mode4_transparent);
                imgModeLongLatUD.setBackgroundResource(C0470R.drawable.mode5_transparent);
                imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                NVPlayerPlaybackFishEyeActivity.this.mPopupExpandMode.dismiss();
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(4);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 4;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode6_btn);
            }
        });
        float density = getResources().getDisplayMetrics().density;
        this.mPopupExpandMode = new PopupWindow(playerModeView, (int) ((((float) PopWinWidth) * density) + 0.5f), (int) ((50.0f * density) + 0.5f));
        this.mPopupExpandMode.setTouchable(true);
        this.mPopupExpandMode.setFocusable(true);
        this.mPopupExpandMode.setBackgroundDrawable(new BitmapDrawable());
        this.mPopupExpandMode.setAnimationStyle(C0470R.style.popupwindow_expand_mode);
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        this.mPopupExpandMode.showAtLocation(v, 0, (int) ((((float) location[0]) + (((float) this.mPopupExpandMode.getWidth()) * density)) + 0.5f), (int) ((((float) (location[1] - this.mPopupExpandMode.getHeight())) - (25.0f * density)) + 0.5f));
    }

    private void showPopWinWallPlayerMode(View v) {
        View playerModeView = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.popup_wall_expand_mode_layout, null);
        this.imgModeViewAngle = (Button) playerModeView.findViewById(C0470R.id.iv_wall_expand_mode5);
        this.imgWallOriginal = (Button) playerModeView.findViewById(C0470R.id.iv_wall_expand_normal);
        switch (this.mPlayMode) {
            case 0:
                this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                break;
            case 4:
                this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                break;
            default:
                this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                break;
        }
        this.imgWallOriginal.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlaybackFishEyeActivity.this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                NVPlayerPlaybackFishEyeActivity.this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                NVPlayerPlaybackFishEyeActivity.this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlaybackFishEyeActivity.this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlaybackFishEyeActivity.this.mPopupExpandMode2.dismiss();
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(0);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 0;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode1_btn);
            }
        });
        this.imgModeViewAngle.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlaybackFishEyeActivity.this.imgWallOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                NVPlayerPlaybackFishEyeActivity.this.imgModeViewAngle.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                NVPlayerPlaybackFishEyeActivity.this.mPopupExpandMode2.dismiss();
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(4);
                NVPlayerPlaybackFishEyeActivity.this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                NVPlayerPlaybackFishEyeActivity.this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 4;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode6_btn);
            }
        });
        float density = getResources().getDisplayMetrics().density;
        this.mPopupExpandMode2 = new PopupWindow(playerModeView, (int) ((((float) 80) * density) + 0.5f), (int) ((50.0f * density) + 0.5f));
        this.mPopupExpandMode2.setTouchable(true);
        this.mPopupExpandMode2.setFocusable(true);
        this.mPopupExpandMode2.setBackgroundDrawable(new BitmapDrawable());
        this.mPopupExpandMode2.setAnimationStyle(C0470R.style.popupwindow_expand_mode);
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        this.mPopupExpandMode2.showAtLocation(v, 0, (int) (((double) this.mScreenWidth) * 0.7d), (int) ((((float) (location[1] - this.mPopupExpandMode2.getHeight())) - (25.0f * density)) + 0.5f));
    }

    private void showPopWinDeviceMode(View v) {
        View devicerModeView = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.popup_device_mode_layout, null);
        final Button btnCeiling = (Button) devicerModeView.findViewById(C0470R.id.iv_device_ceiling);
        final Button btnWall = (Button) devicerModeView.findViewById(C0470R.id.iv_device_wall);
        switch (this.camType) {
            case 1:
                btnCeiling.setBackgroundResource(C0470R.drawable.ceiling_transparent);
                btnWall.setBackgroundResource(C0470R.drawable.wall_bg_click);
                break;
            case 2:
                btnCeiling.setBackgroundResource(C0470R.drawable.ceiling_bg_click);
                btnWall.setBackgroundResource(C0470R.drawable.wall_transparent);
                break;
        }
        btnCeiling.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlaybackFishEyeActivity.this.camType = 2;
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.setFixType(0);
                btnCeiling.setBackgroundResource(C0470R.drawable.ceiling_bg_click);
                btnWall.setBackgroundResource(C0470R.drawable.wall_transparent);
                NVPlayerPlaybackFishEyeActivity.this.mBtnDeviceMode.setBackgroundResource(C0470R.drawable.device_ceiling_btn);
                NVPlayerPlaybackFishEyeActivity.this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                NVPlayerPlaybackFishEyeActivity.this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(0);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 0;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode1_btn);
                NVPlayerPlaybackFishEyeActivity.this.mPopupDeviceMode.dismiss();
            }
        });
        btnWall.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                NVPlayerPlaybackFishEyeActivity.this.camType = 1;
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.setFixType(1);
                btnCeiling.setBackgroundResource(C0470R.drawable.ceiling_transparent);
                btnWall.setBackgroundResource(C0470R.drawable.wall_bg_click);
                NVPlayerPlaybackFishEyeActivity.this.mBtnDeviceMode.setBackgroundResource(C0470R.drawable.device_wall_btn);
                NVPlayerPlaybackFishEyeActivity.this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                NVPlayerPlaybackFishEyeActivity.this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_transparent);
                NVPlayerPlaybackFishEyeActivity.this.mvMediaPlayer.getGLFisheyeView().setMode(0);
                NVPlayerPlaybackFishEyeActivity.this.mPlayMode = 0;
                NVPlayerPlaybackFishEyeActivity.this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.play_mode1_btn);
                NVPlayerPlaybackFishEyeActivity.this.mPopupDeviceMode.dismiss();
            }
        });
        float density = getResources().getDisplayMetrics().density;
        this.mPopupDeviceMode = new PopupWindow(devicerModeView, (int) ((((float) 80) * density) + 0.5f), (int) ((50.0f * density) + 0.5f));
        this.mPopupDeviceMode.setTouchable(true);
        this.mPopupDeviceMode.setFocusable(true);
        this.mPopupDeviceMode.setBackgroundDrawable(new BitmapDrawable());
        this.mPopupDeviceMode.setAnimationStyle(C0470R.style.popupwindow_expand_mode);
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        this.mPopupDeviceMode.showAtLocation(v, 0, (int) (((double) this.mScreenWidth) * 0.7d), (int) ((((float) (location[1] - this.mPopupDeviceMode.getHeight())) - (25.0f * density)) + 0.5f));
    }

    public void onClick(View v) {
        boolean z = false;
        this.nToolsViewShowTickCount = 5;
        if (v != null) {
            final Handler han;
            switch (v.getId()) {
                case C0470R.id.btnRepeat1:
                    stopPlay(true);
                    startPlay();
                    return;
                case C0470R.id.btn_mode:
                    if (this.camType == 2) {
                        showPopWinPlayerMode(v);
                        return;
                    } else if (this.camType == 1) {
                        showPopWinWallPlayerMode(v);
                        return;
                    } else {
                        return;
                    }
                case C0470R.id.btnCatpure:
                case C0470R.id.btnCatpureHorizontal:
                    if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                        this.screenshotDialog.show();
                        ScreenShot();
                        return;
                    }
                    ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 0);
                    return;
                case C0470R.id.btnLastFlie:
                case C0470R.id.btnLastFlieHorizontal:
                    if (this.isPlayFishEyeFromCloud) {
                        if (this.mListIndex - 1 >= 0) {
                            this.mListIndex--;
                            stopPlay(false);
                            han = new Handler();
                            han.postDelayed(new Runnable() {
                                public void run() {
                                    if (NVPlayerPlaybackFishEyeActivity.this.mIsFinish) {
                                        NVPlayerPlaybackFishEyeActivity.this.startPlay();
                                    } else {
                                        han.postDelayed(this, 1000);
                                    }
                                }
                            }, 1000);
                            return;
                        }
                        Toast.makeText(this, getString(C0470R.string.FileFirst), 0).show();
                        return;
                    } else if (this.listID - 1 >= 0) {
                        this.listID--;
                        stopPlay(false);
                        han = new Handler();
                        han.postDelayed(new Runnable() {
                            public void run() {
                                if (NVPlayerPlaybackFishEyeActivity.this.mIsFinish) {
                                    NVPlayerPlaybackFishEyeActivity.this.startPlay();
                                } else {
                                    han.postDelayed(this, 1000);
                                }
                            }
                        }, 1000);
                        return;
                    } else {
                        Toast.makeText(this, getString(C0470R.string.FileFirst), 0).show();
                        return;
                    }
                case C0470R.id.btnPBStopAndPlay:
                case C0470R.id.btnPBStopAndPlayHorizontal:
                    if (!this.mIsPlaying) {
                        z = true;
                    }
                    this.mIsPlaying = z;
                    if (this.mIsPlaying) {
                        startPlay();
                        return;
                    } else {
                        stopPlay(true);
                        return;
                    }
                case C0470R.id.btnNextFile:
                case C0470R.id.btnNextFileHorizontal:
                    if (this.isPlayFishEyeFromCloud) {
                        if (this.mListIndex + 1 < LocalDefines.cloudRecordFileList.size()) {
                            this.mListIndex++;
                            stopPlay(true);
                            han = new Handler();
                            han.postDelayed(new Runnable() {
                                public void run() {
                                    if (NVPlayerPlaybackFishEyeActivity.this.mIsFinish) {
                                        NVPlayerPlaybackFishEyeActivity.this.startPlay();
                                    } else {
                                        han.postDelayed(this, 1000);
                                    }
                                }
                            }, 1000);
                            return;
                        }
                        Toast.makeText(this, getString(C0470R.string.FileFinally), 0).show();
                        return;
                    } else if (this.listID + 1 < LocalDefines.listMapPlayerBackFile.size()) {
                        this.listID++;
                        stopPlay(true);
                        han = new Handler();
                        han.postDelayed(new Runnable() {
                            public void run() {
                                if (NVPlayerPlaybackFishEyeActivity.this.mIsFinish) {
                                    NVPlayerPlaybackFishEyeActivity.this.startPlay();
                                } else {
                                    han.postDelayed(this, 1000);
                                }
                            }
                        }, 1000);
                        return;
                    } else {
                        Toast.makeText(this, getString(C0470R.string.FileFinally), 0).show();
                        return;
                    }
                case C0470R.id.btnPBAudio:
                case C0470R.id.btnPBAudioHorizontal:
                    if (!this.mPlaySound) {
                        z = true;
                    }
                    this.mPlaySound = z;
                    if (this.mPlaySound) {
                        this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn));
                        this.mBtnSoundHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal));
                        this.mvMediaPlayer.playAudio();
                    } else {
                        this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn2));
                        this.mBtnSoundHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal2));
                        this.mvMediaPlayer.pauseAudio();
                    }
                    int nChn = Player.CurrentSelPlayer();
                    if (nChn >= 0 && nChn < 4) {
                        this.mvMediaPlayer.SetAudioParam(this.mPlaySound);
                    }
                    writeSystemParam();
                    return;
                case C0470R.id.btnPBBackToLogin:
                case C0470R.id.btnPBBackToLoginHprizontal:
                    exitCurrentActivity();
                    return;
                case C0470R.id.btn_device_camera:
                    showPopWinDeviceMode(v);
                    return;
                case C0470R.id.PB_iv_cross_screen_expand_normal:
                    this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                    this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_transparent);
                    this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.mode1_bg_click);
                    this.mvMediaPlayer.getGLFisheyeView().setMode(0);
                    this.mPlayMode = 0;
                    return;
                case C0470R.id.PB_iv_cross_screen_expand_mode5:
                    this.imgCSModeOriginal.setBackgroundResource(C0470R.drawable.mode1_transparent);
                    this.imgCSMode5.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                    this.mBtnExpandMode.setBackgroundResource(C0470R.drawable.mode6_bg_click);
                    this.mvMediaPlayer.getGLFisheyeView().setMode(4);
                    this.mPlayMode = 4;
                    return;
                default:
                    return;
            }
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != 0) {
            return;
        }
        if (!permissions[0].equals("android.permission.WRITE_EXTERNAL_STORAGE") || grantResults[0] != 0) {
            new Builder(this).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_storage1)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent();
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", NVPlayerPlaybackFishEyeActivity.this.getPackageName(), null));
                    NVPlayerPlaybackFishEyeActivity.this.startActivity(intent);
                }
            }).show();
        }
    }

    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        this.Time_display_view.setText(getCheckTimeBySeconds((totaltime * progress) / 100, "00:00"));
        if (!this.mIsOnDropUp && this.mIsPlaying && progress >= 100) {
            this.btnRepeat.setVisibility(0);
            this.mIsPlaying = false;
            this.mIsPlaying = false;
            this.mTVTopServer.setText(this.m_strFileName);
            this.mvMediaPlayer.pauseAudio();
            this.mBtnStopAndPlay.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn));
            this.mBtnStopAndPlayHorizontal.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_play_btn_horziontal));
            this.mvMediaPlayer.FinishPlayback();
            this.mIsFinish = true;
            this.seekBarPlayProgressHorizontal.setEnabled(false);
            this.seekBarPlayProgress.setEnabled(false);
        }
        if (this.seekBarPlayProgress != null && this.seekBarPlayProgress.getProgress() == 100) {
            this.seekBarPlayProgress.setProgress(0);
            this.Time_display_view.setVisibility(8);
        }
        if (this.seekBarPlayProgressHorizontal != null && this.seekBarPlayProgressHorizontal.getProgress() == 100) {
            this.seekBarPlayProgressHorizontal.setProgress(0);
            this.Time_display_view.setVisibility(8);
        }
        this.mIsOnDropUp = true;
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        this.Time_display_view.setVisibility(0);
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
        this.Time_display_view.setVisibility(8);
        this.mvMediaPlayer.SetPlayIndex(seekBar.getProgress());
    }

    private void showToolsViews() {
        this.nToolsViewShowTickCount = 5;
        this.layoutTopBar.setVisibility(0);
        if (this.bAnyway) {
            this.bottomButton.setVisibility(0);
            this.bottomButtonHorizontal.setVisibility(8);
            this.llVideoPalyBakc.setVisibility(0);
            this.llVideoPalyBakcHorizontal.setVisibility(8);
            this.RlPlayerDevice.setVisibility(0);
            return;
        }
        this.layoutBottomBar.setVisibility(0);
        if (this.camType == 1) {
            this.layoutCrossScreenMode.setVisibility(0);
        }
        this.bottomButtonHorizontal.setVisibility(0);
        this.bottomButton.setVisibility(8);
        this.llVideoPalyBakc.setVisibility(8);
        this.llVideoPalyBakcHorizontal.setVisibility(0);
        this.RlPlayerDevice.setVisibility(8);
    }

    private void hideToolsViews() {
        this.nToolsViewShowTickCount = 0;
        this.layoutBottomBar.setVisibility(8);
        this.layoutCrossScreenMode.setVisibility(8);
        this.layoutTopBar.setVisibility(8);
        this.bottomButtonHorizontal.setVisibility(8);
        this.bottomButton.setVisibility(8);
    }

    private void createDialogs() {
        this.iamgeViewConctentView = LayoutInflater.from(this).inflate(C0470R.layout.screenshotdialog, null);
        this.screenshotDialog = new Dialog(this, C0470R.style.progressDialog);
        this.screenshotDialog.setContentView(this.iamgeViewConctentView);
        this.screenshotDialog.setOnShowListener(new OnShowListener() {
            public void onShow(DialogInterface dialog) {
                Message msg = NVPlayerPlaybackFishEyeActivity.this.handler.obtainMessage();
                msg.arg1 = 4;
                NVPlayerPlaybackFishEyeActivity.this.handler.sendMessage(msg);
            }
        });
        this.screenshotDialog.setOnDismissListener(new OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
            }
        });
    }

    @SuppressLint({"SimpleDateFormat"})
    private void ScreenShot() {
        String strSavePath = Functions.GetSDPath();
        if (strSavePath == null) {
            this.screenshotDialog.dismiss();
            Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeSDCardNotExist), 0).show();
            return;
        }
        this.bm = this.mvMediaPlayer.Screenshot();
        if (this.bm != null) {
            this.bm.recycle();
            this.bm = null;
            this.bm = Bitmap.createBitmap(Defines._capWidth, Defines._capHeight, Config.RGB_565);
            this.bm.copyPixelsFromBuffer(Defines._capbuffer);
            Defines._capbuffer.position(0);
        }
        if (this.bm != null) {
            String strFileName = new StringBuilder(String.valueOf(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()))).append("(").append(this.m_strFileName).append(")").append(".jpg").toString();
            if (saveToSDCard(this.bm, strFileName)) {
                this.screenshotDialog.dismiss();
                Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeFileSaveToAlbumsOK), 0).show();
                return;
            }
            if (saveToSDCard(this.bm, new StringBuilder(String.valueOf(strSavePath)).append("/").append(strFileName).toString())) {
                this.screenshotDialog.dismiss();
                Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotOK), 0).show();
                return;
            }
            this.screenshotDialog.dismiss();
            Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotFail), 0).show();
            return;
        }
        this.screenshotDialog.dismiss();
        Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotFail), 0).show();
    }

    private boolean saveToSDCard(Bitmap image, String strFileName) {
        boolean bResult = false;
        if (image == null) {
            return 0;
        }
        try {
            File file = new File(Functions.GetSDPath() + File.separator + LocalDefines.SDCardPath);
            if (!file.exists()) {
                file.mkdir();
            }
            FileOutputStream out = new FileOutputStream(new File(file.getAbsolutePath() + File.separator + strFileName));
            image.compress(CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
            bResult = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return bResult;
    }

    private static String getCheckTimeBySeconds(int progress, String startTime) {
        String return_h = Constants.MAIN_VERSION_TAG;
        String return_m = Constants.MAIN_VERSION_TAG;
        String return_s = Constants.MAIN_VERSION_TAG;
        String[] st = startTime.split(":");
        int st_m = Integer.valueOf(st[0]).intValue();
        int st_s = Integer.valueOf(st[1]).intValue();
        int m = (progress % 3600) / 60;
        int s = progress % 60;
        if (s + st_s >= 60) {
            int tmpSecond = (s + st_s) % 60;
            m++;
            if (tmpSecond >= 10) {
                return_s = new StringBuilder(String.valueOf(tmpSecond)).toString();
            } else {
                return_s = "0" + tmpSecond;
            }
        } else if (s + st_s >= 10) {
            return_s = new StringBuilder(String.valueOf(s + st_s)).toString();
        } else {
            return_s = "0" + (s + st_s);
        }
        if (m + st_m >= 60) {
            int tmpMin = (m + st_m) % 60;
            if (tmpMin >= 10) {
                return_m = new StringBuilder(String.valueOf(tmpMin)).toString();
            } else {
                return_m = "0" + tmpMin;
            }
        } else if (m + st_m >= 10) {
            return_m = new StringBuilder(String.valueOf(m + st_m)).toString();
        } else {
            return_m = "0" + (m + st_m);
        }
        return new StringBuilder(String.valueOf(return_m)).append(":").append(return_s).toString();
    }

    private static int totalSeconds(String startTime, String endTime) {
        String[] st = startTime.split(":");
        String[] et = endTime.split(":");
        int st_m = Integer.valueOf(st[0]).intValue();
        int st_s = Integer.valueOf(st[1]).intValue();
        return ((Integer.valueOf(et[0]).intValue() - st_m) * 60) + (Integer.valueOf(et[1]).intValue() - st_s);
    }

    public boolean onTouch(View v, MotionEvent event) {
        if (v == this.mvMediaPlayer.getGLFisheyeView()) {
            this.mGestureDetector.onTouchEvent(event);
        }
        return false;
    }

    private void exitCurrentActivity() {
        if (this.mIsPlaying) {
            View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
            ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.alert_stop_play));
            ((TextView) view.findViewById(C0470R.id.tv_content)).setVisibility(8);
            new Builder(this).setView(view).setNegativeButton(getString(C0470R.string.alert_btn_Cancel), null).setPositiveButton(getString(C0470R.string.alert_btn_OK), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    try {
                        NVPlayerPlaybackFishEyeActivity.this.stopPlay(false);
                    } catch (Exception e) {
                    }
                    NVPlayerPlaybackFishEyeActivity.this.mIsPlaying = false;
                    NVPlayerPlaybackFishEyeActivity.this.m_bFinish = true;
                    if (!NVPlayerPlaybackFishEyeActivity.this.isPlayFishEyeFromCloud) {
                        NVPlayerPlaybackFishEyeActivity.this.setResult(-1);
                        Intent intent = new Intent(NVPlayerPlaybackFishEyeActivity.this, HomePageActivity.class);
                        Bundle data = new Bundle();
                        data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, NVPlayerPlaybackFishEyeActivity.this.deviceParam);
                        data.putInt("play_index", NVPlayerPlaybackFishEyeActivity.this.listID);
                        data.putBoolean("is_file_list_visible", true);
                        data.putBoolean("rec_load_from_db", true);
                        intent.putExtras(data);
                        NVPlayerPlaybackFishEyeActivity.this.startActivity(intent);
                        LocalDefines.PLAY_BACK_BACK = true;
                    }
                    NVPlayerPlaybackFishEyeActivity.this.unRegisterReceiver();
                    NVPlayerPlaybackFishEyeActivity.this.finish();
                    NVPlayerPlaybackFishEyeActivity.this.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                }
            }).show();
            return;
        }
        stopPlay(false);
        this.m_bFinish = true;
        if (!this.isPlayFishEyeFromCloud) {
            Intent intent = new Intent(this, HomePageActivity.class);
            Bundle data = new Bundle();
            data.putParcelable(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, this.deviceParam);
            data.putInt("play_index", this.listID);
            data.putBoolean("is_file_list_visible", true);
            data.putBoolean("rec_load_from_db", true);
            intent.putExtras(data);
            startActivity(intent);
            LocalDefines.PLAY_BACK_BACK = true;
        }
        unRegisterReceiver();
        finish();
        overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
    }

    private void registerReceiver(Context context) {
        IntentFilter filter = new IntentFilter();
        filter.addAction(LocalDefines.getReceiverActionString(context));
        this.mReceiver = new CloseActivityReceiver();
        registerReceiver(this.mReceiver, filter);
    }

    private void unRegisterReceiver() {
        if (this.mReceiver != null) {
            unregisterReceiver(this.mReceiver);
        }
    }

    private void stopCurrentActivityFromBroadcast() {
        if (this.mIsPlaying) {
            try {
                stopPlay(false);
            } catch (Exception e) {
            }
            this.mIsPlaying = false;
            this.m_bFinish = true;
            if (!this.isPlayFishEyeFromCloud) {
                setResult(-1);
                LocalDefines.PLAY_BACK_BACK = true;
            } else if (LocalDefines.sCloudStorageActivity != null) {
                LocalDefines.sCloudStorageActivity.closeCurrentActivity();
            }
            unRegisterReceiver();
            finish();
            return;
        }
        stopPlay(false);
        this.m_bFinish = true;
        if (!this.isPlayFishEyeFromCloud) {
            LocalDefines.PLAY_BACK_BACK = true;
        } else if (LocalDefines.sCloudStorageActivity != null) {
            LocalDefines.sCloudStorageActivity.closeCurrentActivity();
        }
        unRegisterReceiver();
        finish();
    }
}
