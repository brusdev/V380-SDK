package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.httptool.HttpUtils;
import com.macrovideo.sdk.defines.Defines;
import com.tencent.android.tpush.common.Constants;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class ForgetPasswordActivity extends Activity implements OnClickListener {
    static final int ACCOUT_IS_NOT_EXISTANCE = 21005;
    static final int PASSWORD_IS_NOT_IRREGULARITIES = 21004;
    static final int VERIFY_CODE_IS_ERROR = 20001;
    static final int VERIFY_CODE_IS_OVERTIME = 20002;
    private String MessageTxt;
    private int RESET_PWD_THREAD_RESULT_CODE = LocalDefines.BIND_DEVICE_RESULT_CODE;
    private int ResetPasswordThreadID = 0;
    private int SEND_VERIFY_CODE_RESULT = 801;
    private int VerifyPasswordThreadID = 0;
    private Button btn_finish;
    private Button btn_next1;
    private Button btn_next2;
    private Button btn_resetPwd_way;
    private Button btn_verify;
    private CheckBox cb_psw_visibility_retPwd;
    private CheckBox cb_psw_visibility_retPwd2;
    private int dialogNo = -101;
    private DialogTimeCount dialog_showtime;
    private RelativeLayout et_mailbox_layout;
    private RelativeLayout et_phoneNo_layout;
    private RelativeLayout et_resetPWd_Confirm_layout_mailbox;
    private RelativeLayout et_resetPWd_Confirm_pwd_layout;
    private RelativeLayout et_resetPWd_Confirm_verify_layout;
    private EditText et_resetPwd_Confirm_mailbox;
    private EditText et_resetPwd_Confirm_verify;
    private EditText et_resetPwd_Pwd_mailbox;
    private EditText et_resetPwd_account;
    private EditText et_resetPwd_account_mailbox;
    private EditText et_resetPwd_confirm_newPwd;
    private RelativeLayout et_resetPwd_layout_mailbox;
    private EditText et_resetPwd_newPwd;
    private RelativeLayout et_resetPwd_password_layout;
    private EditText et_resetPwd_verify;
    private LinearLayout et_resetPwd_verify_layout;
    @SuppressLint({"HandlerLeak"})
    private Handler handler = new C03541();
    private ImageView iv_forgetPwd_back;
    private ImageView iv_forgetPwd_back2;
    private ImageView iv_forgetPwd_back3;
    private Dialog lDialog;
    private Dialog mResetDlg;
    private TextView phoneNO_resetPwd_view_center;
    private LinearLayout phoneNo_resetPwd_view_layout;
    private int resetPwdResult = -100;
    private int resetPwd_Error_code = -1001;
    private int resetWay = 1;
    private TimeCount time;
    private int verify_Error_code;

    class C03541 extends Handler {
        C03541() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 == ForgetPasswordActivity.this.RESET_PWD_THREAD_RESULT_CODE) {
                if (ForgetPasswordActivity.this.resetPwd_Error_code == -1) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    ForgetPasswordActivity.this.showResetPwdMessage(msg.arg2);
                } else if (msg.arg2 == 0) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    ForgetPasswordActivity.this.showResetPwdMessage(msg.arg2);
                    ForgetPasswordActivity.this.btn_finish.setEnabled(false);
                } else if (msg.arg2 == 20001) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    ForgetPasswordActivity.this.showResetPwdMessage(msg.arg2);
                    ForgetPasswordActivity.this.et_resetPWd_Confirm_verify_layout.setVisibility(0);
                } else if (msg.arg2 == 20002) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    ForgetPasswordActivity.this.showResetPwdMessage(msg.arg2);
                    ForgetPasswordActivity.this.et_resetPWd_Confirm_verify_layout.setVisibility(0);
                } else if (msg.arg2 == ForgetPasswordActivity.PASSWORD_IS_NOT_IRREGULARITIES) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    ForgetPasswordActivity.this.showResetPwdMessage(msg.arg2);
                } else if (msg.arg2 == 500) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    Toast.makeText(ForgetPasswordActivity.this, ForgetPasswordActivity.this.getString(C0470R.string.str_server_error), 0).show();
                } else if (msg.arg2 == 10006) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    ForgetPasswordActivity.this.showResetPwdMessage(msg.arg2);
                } else {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    Toast.makeText(ForgetPasswordActivity.this.getApplicationContext(), C0470R.string.Reset_pwd_fail, 0).show();
                }
            } else if (msg.arg1 == ForgetPasswordActivity.this.SEND_VERIFY_CODE_RESULT) {
                if (ForgetPasswordActivity.this.verify_Error_code == 0) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    ForgetPasswordActivity.this.time.start();
                    ForgetPasswordActivity.this.btn_verify.setBackground(ForgetPasswordActivity.this.getResources().getDrawable(C0470R.drawable.verification_code));
                    ForgetPasswordActivity.this.btn_verify.setTextColor(ForgetPasswordActivity.this.getResources().getColor(C0470R.color.font_color_black));
                    ForgetPasswordActivity.this.btn_verify.setTextColor(Color.parseColor("#666666"));
                }
                if (ForgetPasswordActivity.this.verify_Error_code == ForgetPasswordActivity.ACCOUT_IS_NOT_EXISTANCE) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    ForgetPasswordActivity.this.showResetPwdMessage(ForgetPasswordActivity.ACCOUT_IS_NOT_EXISTANCE);
                } else if (ForgetPasswordActivity.this.verify_Error_code == -1) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    ForgetPasswordActivity.this.showResetPwdMessage(-1);
                } else if (msg.arg2 == 500) {
                    ForgetPasswordActivity.this.closeResetingDlg();
                    Toast.makeText(ForgetPasswordActivity.this, ForgetPasswordActivity.this.getString(C0470R.string.str_server_error), 0).show();
                }
            }
        }
    }

    class C03552 implements OnCheckedChangeListener {
        C03552() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            ForgetPasswordActivity.this.setPasswordVisibility(isChecked, 1);
        }
    }

    class C03563 implements OnCheckedChangeListener {
        C03563() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            ForgetPasswordActivity.this.setPasswordVisibility(isChecked, 2);
        }
    }

    class C03574 implements OnClickListener {
        C03574() {
        }

        public void onClick(View v) {
            ForgetPasswordActivity.this.lDialog.dismiss();
            Toast.makeText(ForgetPasswordActivity.this.getApplicationContext(), ForgetPasswordActivity.this.getString(C0470R.string.alert_btn_OK), 0).show();
        }
    }

    class C03585 implements OnClickListener {
        C03585() {
        }

        public void onClick(View v) {
            ForgetPasswordActivity.this.lDialog.dismiss();
            Toast.makeText(ForgetPasswordActivity.this.getApplicationContext(), ForgetPasswordActivity.this.getString(C0470R.string.alert_btn_Cancel), 0).show();
        }
    }

    class DialogTimeCount extends CountDownTimer {
        public DialogTimeCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        public void onFinish() {
            ForgetPasswordActivity.this.lDialog.dismiss();
            if (ForgetPasswordActivity.this.resetPwd_Error_code == 0) {
                ForgetPasswordActivity.this.startActivity(new Intent(ForgetPasswordActivity.this, LoginActivity.class));
            }
        }

        public void onTick(long millisUntilFinished) {
        }
    }

    public class ResetPasswordThread extends Thread {
        private Handler handler;
        private int m_ResetPasswordThreadID = 0;

        public ResetPasswordThread(Handler handler, int n_ResetPWD_ID) {
            this.handler = handler;
            this.m_ResetPasswordThreadID = n_ResetPWD_ID;
        }

        public void run() {
            super.run();
            try {
                if (this.m_ResetPasswordThreadID == ForgetPasswordActivity.this.ResetPasswordThreadID) {
                    ForgetPasswordActivity.this.PostResetPasswordData();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = ForgetPasswordActivity.this.RESET_PWD_THREAD_RESULT_CODE;
            msg.arg2 = ForgetPasswordActivity.this.resetPwd_Error_code;
            this.handler.sendMessage(msg);
        }
    }

    class TimeCount extends CountDownTimer {
        public TimeCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        public void onFinish() {
            ForgetPasswordActivity.this.btn_verify.setText(C0470R.string.str_verify_code);
            ForgetPasswordActivity.this.btn_verify.setClickable(true);
            ForgetPasswordActivity.this.btn_verify.setBackground(ForgetPasswordActivity.this.getResources().getDrawable(C0470R.drawable.verification_code_send));
            ForgetPasswordActivity.this.btn_verify.setTextColor(ForgetPasswordActivity.this.getResources().getColor(C0470R.color.font_color_sky_blue));
        }

        public void onTick(long millisUntilFinished) {
            ForgetPasswordActivity.this.btn_verify.setClickable(false);
            ForgetPasswordActivity.this.btn_verify.setText((millisUntilFinished / 1000) + "s");
        }
    }

    public class VerifyCodeThread extends Thread {
        private Handler handler;
        private int m_VerifyCodeThreadID = 0;

        public VerifyCodeThread(Handler handler, int n_VerifyCodeThreadID) {
            this.m_VerifyCodeThreadID = n_VerifyCodeThreadID;
            this.handler = handler;
        }

        public void run() {
            super.run();
            try {
                if (this.m_VerifyCodeThreadID == ForgetPasswordActivity.this.VerifyPasswordThreadID) {
                    ForgetPasswordActivity.this.PostVerifyCodeData();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = ForgetPasswordActivity.this.SEND_VERIFY_CODE_RESULT;
            msg.arg2 = ForgetPasswordActivity.this.verify_Error_code;
            this.handler.sendMessage(msg);
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_forget_password);
        initViews();
    }

    public void initViews() {
        initLoginingDlg();
        this.iv_forgetPwd_back = (ImageView) findViewById(C0470R.id.iv_forgetPwd_back);
        this.iv_forgetPwd_back.setOnClickListener(this);
        this.iv_forgetPwd_back2 = (ImageView) findViewById(C0470R.id.iv_forgetPwd_back2);
        this.iv_forgetPwd_back2.setOnClickListener(this);
        this.iv_forgetPwd_back3 = (ImageView) findViewById(C0470R.id.iv_forgetPwd_back3);
        this.iv_forgetPwd_back3.setOnClickListener(this);
        this.et_resetPwd_account = (EditText) findViewById(C0470R.id.et_resetPwd_account);
        this.et_resetPwd_newPwd = (EditText) findViewById(C0470R.id.et_resetPwd_Pwd);
        this.et_resetPwd_confirm_newPwd = (EditText) findViewById(C0470R.id.et_resetPwd_Confirm_pwd);
        this.et_resetPwd_verify = (EditText) findViewById(C0470R.id.et_resetPwd_verify);
        this.et_resetPwd_Confirm_verify = (EditText) findViewById(C0470R.id.et_resetPwd_Confirm_verify);
        this.et_resetPwd_account_mailbox = (EditText) findViewById(C0470R.id.et_resetPwd_account_mailbox);
        this.btn_verify = (Button) findViewById(C0470R.id.btn_resetPwd_get_verify_code);
        this.btn_verify.setOnClickListener(this);
        this.btn_next1 = (Button) findViewById(C0470R.id.btn_resetPwd_next1);
        this.btn_next1.setOnClickListener(this);
        this.btn_next2 = (Button) findViewById(C0470R.id.btn_resetPwd_next2);
        this.btn_next2.setOnClickListener(this);
        this.btn_finish = (Button) findViewById(C0470R.id.btn_resetPwd_finish);
        this.btn_finish.setOnClickListener(this);
        this.btn_resetPwd_way = (Button) findViewById(C0470R.id.btn_resetPwd_by_mailbox);
        this.btn_resetPwd_way.setOnClickListener(this);
        this.phoneNO_resetPwd_view_center = (TextView) findViewById(C0470R.id.phoneNO_resetPwd_view_center);
        this.phoneNo_resetPwd_view_layout = (LinearLayout) findViewById(C0470R.id.phoneNo_resetPwd_view_layout);
        this.et_resetPwd_verify_layout = (LinearLayout) findViewById(C0470R.id.et_resetPwd_verify_layout);
        this.et_phoneNo_layout = (RelativeLayout) findViewById(C0470R.id.et_phoneNo_layout);
        this.et_mailbox_layout = (RelativeLayout) findViewById(C0470R.id.et_mailbox_layout);
        this.et_resetPwd_password_layout = (RelativeLayout) findViewById(C0470R.id.et_resetPwd_password_layout);
        this.et_resetPWd_Confirm_pwd_layout = (RelativeLayout) findViewById(C0470R.id.et_resetPWd_Confirm_pwd_layout);
        this.et_resetPWd_Confirm_verify_layout = (RelativeLayout) findViewById(C0470R.id.et_resetPWd_Confirm_verify_layout);
        this.cb_psw_visibility_retPwd = (CheckBox) findViewById(C0470R.id.cb_psw_visibility_retPwd);
        this.cb_psw_visibility_retPwd.setOnCheckedChangeListener(new C03552());
        this.cb_psw_visibility_retPwd2 = (CheckBox) findViewById(C0470R.id.cb_psw_visibility_retPwd2);
        this.cb_psw_visibility_retPwd2.setOnCheckedChangeListener(new C03563());
        this.time = new TimeCount(60000, 1000);
        this.dialog_showtime = new DialogTimeCount(2000, 1000);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.iv_forgetPwd_back:
                startActivity(new Intent(this, LoginActivity.class));
                finish();
                return;
            case C0470R.id.iv_forgetPwd_back2:
                if (this.resetWay == 1) {
                    this.btn_next1.setVisibility(0);
                    this.btn_next2.setVisibility(8);
                    this.phoneNo_resetPwd_view_layout.setVisibility(8);
                    this.et_resetPwd_verify_layout.setVisibility(8);
                    this.et_phoneNo_layout.setVisibility(0);
                    this.btn_resetPwd_way.setVisibility(0);
                    this.iv_forgetPwd_back2.setVisibility(8);
                    this.iv_forgetPwd_back.setVisibility(0);
                    return;
                }
                return;
            case C0470R.id.iv_forgetPwd_back3:
                if (this.resetWay == 1) {
                    this.btn_next2.setVisibility(0);
                    this.phoneNo_resetPwd_view_layout.setVisibility(0);
                    this.et_resetPwd_verify_layout.setVisibility(0);
                    this.et_resetPWd_Confirm_pwd_layout.setVisibility(8);
                    this.et_resetPwd_password_layout.setVisibility(8);
                    this.btn_finish.setVisibility(8);
                    this.iv_forgetPwd_back2.setVisibility(0);
                    this.iv_forgetPwd_back3.setVisibility(8);
                    this.et_resetPwd_newPwd.setText(Constants.MAIN_VERSION_TAG);
                    this.et_resetPwd_confirm_newPwd.setText(Constants.MAIN_VERSION_TAG);
                    this.et_resetPWd_Confirm_verify_layout.setVisibility(8);
                }
                if (this.resetWay == 2) {
                    this.btn_next1.setVisibility(0);
                    this.btn_finish.setVisibility(8);
                    this.et_mailbox_layout.setVisibility(0);
                    this.et_resetPWd_Confirm_pwd_layout.setVisibility(8);
                    this.et_resetPwd_password_layout.setVisibility(8);
                    this.btn_resetPwd_way.setVisibility(0);
                    this.iv_forgetPwd_back.setVisibility(0);
                    this.iv_forgetPwd_back3.setVisibility(8);
                    this.et_resetPwd_newPwd.setText(Constants.MAIN_VERSION_TAG);
                    this.et_resetPwd_confirm_newPwd.setText(Constants.MAIN_VERSION_TAG);
                    this.et_resetPWd_Confirm_verify_layout.setVisibility(8);
                    return;
                }
                return;
            case C0470R.id.btn_resetPwd_get_verify_code:
                showResetingDlg();
                startVerifyCodeThread();
                return;
            case C0470R.id.btn_resetPwd_next1:
                if (this.resetWay == 1) {
                    if (this.et_resetPwd_account.getText().toString().equals(Constants.MAIN_VERSION_TAG)) {
                        this.dialogNo = 103;
                        showResetPwdMessage(this.dialogNo);
                        return;
                    } else if (isMobileNO(this.et_resetPwd_account.getText().toString())) {
                        this.btn_next1.setVisibility(8);
                        this.btn_next2.setVisibility(0);
                        this.phoneNo_resetPwd_view_layout.setVisibility(0);
                        this.et_resetPwd_verify_layout.setVisibility(0);
                        this.et_phoneNo_layout.setVisibility(8);
                        this.phoneNO_resetPwd_view_center.setText(this.et_resetPwd_account.getText().toString());
                        this.btn_resetPwd_way.setVisibility(8);
                        this.iv_forgetPwd_back.setVisibility(8);
                        this.iv_forgetPwd_back2.setVisibility(0);
                        return;
                    } else {
                        this.dialogNo = DialogTipCode.PHONE_NUMBER_IS_NOT_STANDARDLIZED;
                        showResetPwdMessage(this.dialogNo);
                        return;
                    }
                } else if (this.resetWay != 2) {
                    return;
                } else {
                    if (isEmailaddress(this.et_resetPwd_account_mailbox.getText().toString())) {
                        this.btn_next1.setVisibility(8);
                        this.btn_finish.setVisibility(0);
                        this.et_mailbox_layout.setVisibility(8);
                        this.et_resetPWd_Confirm_pwd_layout.setVisibility(0);
                        this.et_resetPwd_password_layout.setVisibility(0);
                        this.btn_resetPwd_way.setVisibility(8);
                        this.iv_forgetPwd_back.setVisibility(8);
                        this.iv_forgetPwd_back3.setVisibility(0);
                        return;
                    }
                    this.dialogNo = 113;
                    showResetPwdMessage(this.dialogNo);
                    return;
                }
            case C0470R.id.btn_resetPwd_by_mailbox:
                if (this.resetWay == 1) {
                    this.btn_resetPwd_way.setText(getResources().getString(C0470R.string.UpdatePwd_by_phone));
                    this.et_phoneNo_layout.setVisibility(8);
                    this.et_mailbox_layout.setVisibility(0);
                    this.resetWay = 2;
                    return;
                } else if (this.resetWay == 2) {
                    this.btn_resetPwd_way.setText(getResources().getString(C0470R.string.UpdatePwd_by_mailbox));
                    this.et_phoneNo_layout.setVisibility(0);
                    this.et_mailbox_layout.setVisibility(8);
                    this.resetWay = 1;
                    return;
                } else {
                    return;
                }
            case C0470R.id.btn_resetPwd_next2:
                if (this.et_resetPwd_verify.getText().toString().equals(Constants.MAIN_VERSION_TAG)) {
                    this.dialogNo = DialogTipCode.VERIFY_CODE_IS_NOT_STANDARDLIZED;
                    showResetPwdMessage(this.dialogNo);
                    return;
                } else if (isVerifyCode(this.et_resetPwd_verify.getText().toString())) {
                    this.btn_next2.setVisibility(8);
                    this.phoneNo_resetPwd_view_layout.setVisibility(8);
                    this.et_resetPwd_verify_layout.setVisibility(8);
                    this.et_resetPWd_Confirm_pwd_layout.setVisibility(0);
                    this.et_resetPwd_password_layout.setVisibility(0);
                    this.btn_finish.setVisibility(0);
                    this.iv_forgetPwd_back2.setVisibility(8);
                    this.iv_forgetPwd_back3.setVisibility(0);
                    return;
                } else {
                    this.dialogNo = DialogTipCode.VERIFY_CODE_IS_NOT_STANDARDLIZED;
                    showResetPwdMessage(this.dialogNo);
                    return;
                }
            case C0470R.id.btn_resetPwd_finish:
                if (this.et_resetPwd_newPwd.getText().toString() == null || this.et_resetPwd_confirm_newPwd.getText().toString() == null) {
                    showResetPwdMessage(109);
                    return;
                } else if (this.et_resetPwd_newPwd.getText().toString().equals(this.et_resetPwd_confirm_newPwd.getText().toString())) {
                    boolean passwordType = passwordFormat(this.et_resetPwd_newPwd.getText().toString());
                    boolean confirmpasswordType = passwordFormat(this.et_resetPwd_confirm_newPwd.getText().toString());
                    if (passwordType && confirmpasswordType) {
                        showResetingDlg();
                        startResetPasswordThread();
                        return;
                    }
                    showResetPwdMessage(109);
                    return;
                } else {
                    showResetPwdMessage(110);
                    return;
                }
            default:
                return;
        }
    }

    public void startResetPasswordThread() {
        this.ResetPasswordThreadID++;
        new ResetPasswordThread(this.handler, this.ResetPasswordThreadID).start();
    }

    public void startVerifyCodeThread() {
        this.VerifyPasswordThreadID++;
        new VerifyCodeThread(this.handler, this.VerifyPasswordThreadID).start();
    }

    private void PostResetPasswordData() throws JSONException {
        DecimalFormat df = new DecimalFormat("#.##");
        String password = null;
        try {
            password = LoginActivity.byte2hex(LoginActivity.encrypt(this.et_resetPwd_newPwd.getText().toString().getBytes(), LoginActivity.key.getBytes()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        long time = System.currentTimeMillis();
        String content = null;
        if (this.resetWay == 1) {
            if (this.et_resetPWd_Confirm_verify_layout.getVisibility() == 0) {
                this.et_resetPwd_verify.setText(this.et_resetPwd_Confirm_verify.getText().toString());
            }
            String RegisterSign = "newpassword=" + password + "&timestamp=" + (time / 1000) + "&username=" + this.et_resetPwd_account.getText().toString() + "&validcode=" + this.et_resetPwd_verify.getText().toString() + "&validtype=mobile" + "hsshop2016";
            System.out.println("RegisterSign ==" + RegisterSign);
            String MDLoginSign = md5(RegisterSign);
            JSONObject json = new JSONObject();
            json.put("sign", MDLoginSign);
            json.put("timestamp", (time / 1000));
            json.put("newpassword", password);
            json.put("username", this.et_resetPwd_account.getText().toString());
            json.put("validcode", this.et_resetPwd_verify.getText().toString());
            json.put("validtype", "mobile");
            content = json.toString();
            System.out.println("cccccccjson" + content);
        }
        if (this.resetWay == 2) {
            MDLoginSign = md5("newpassword=" + password + "&timestamp=" + (time / 1000) + "&username=" + this.et_resetPwd_account_mailbox.getText().toString() + "&validcode=" + this.et_resetPwd_verify.getText().toString() + "&validtype=email" + "hsshop2016");
            json = new JSONObject();
            json.put("sign", MDLoginSign);
            json.put("timestamp", (time / 1000));
            json.put("newpassword", password);
            json.put("username", this.et_resetPwd_account_mailbox.getText().toString());
            json.put("validcode", this.et_resetPwd_verify.getText().toString());
            json.put("validtype", "email");
            content = json.toString();
        }
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/user/reset-password", content);
        System.out.println("服务器修改密码结果" + Recresult);
        if (Recresult == null) {
            return;
        }
        if (Recresult.equals("-1")) {
            this.resetPwd_Error_code = -1;
            return;
        }
        JSONObject jsonForResult = new JSONObject(Recresult);
        if (jsonForResult != null) {
            String result = jsonForResult.getString("result");
            int error = jsonForResult.getInt("error_code");
            this.resetPwdResult = Integer.valueOf(result).intValue();
            this.resetPwd_Error_code = error;
        }
    }

    private void PostVerifyCodeData() throws JSONException {
        DecimalFormat df = new DecimalFormat("#.##");
        long time = System.currentTimeMillis();
        String VerifyCodeSign = "codetype=resetpwd&target=" + this.et_resetPwd_account.getText().toString() + "&timestamp=" + (time / 1000) + "hsshop2016";
        String MDLoginSign = md5(VerifyCodeSign);
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", (time / 1000));
        json.put("codetype", "resetpwd");
        json.put("target", this.et_resetPwd_account.getText().toString());
        String content = json.toString();
        System.out.println("LoginSign = " + VerifyCodeSign);
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/tool/send-valid-code", content);
        System.out.println("服务器返回数据 = " + Recresult);
        if (Recresult == null) {
            return;
        }
        if (Recresult.equals("-1")) {
            this.verify_Error_code = -1;
            return;
        }
        JSONObject json2 = new JSONObject(Recresult);
        String result = json2.getString("result");
        this.verify_Error_code = Integer.valueOf(json2.getString("error_code")).intValue();
    }

    public static String md5(String string) {
        try {
            byte[] hash = MessageDigest.getInstance("MD5").digest(string.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder(hash.length * 2);
            for (byte b : hash) {
                if ((b & 255) < 16) {
                    hex.append("0");
                }
                hex.append(Integer.toHexString(b & 255));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Huh, MD5 should be supported?", e);
        } catch (UnsupportedEncodingException e2) {
            throw new RuntimeException("Huh, UTF-8 should be supported?", e2);
        }
    }

    private void showResetPwdMessage(int dialogNo) {
        this.lDialog = new Dialog(this, 16973840);
        this.lDialog.requestWindowFeature(1);
        this.lDialog.setContentView(C0470R.layout.dialog_registere_layout);
        TextView messageTxt = (TextView) this.lDialog.findViewById(C0470R.id.message_register);
        messageTxt.getBackground().setAlpha(Defines.REC_FILE_SEARCH);
        switch (dialogNo) {
            case -1:
                messageTxt.setText(C0470R.string.Network_Error);
                break;
            case 0:
                if (this.resetWay == 1) {
                    messageTxt.setText(C0470R.string.Update_password);
                }
                if (this.resetWay == 2) {
                    messageTxt.setText(C0470R.string.Mailbox_reset_successfully);
                    break;
                }
                break;
            case 101:
                messageTxt.setText(C0470R.string.The_username_can_not_be_empty);
                break;
            case 102:
                messageTxt.setText(C0470R.string.The_password_can_not_be_empty);
                break;
            case 103:
                messageTxt.setText(C0470R.string.The_phone_number_can_not_be_empty);
                break;
            case DialogTipCode.PHONE_NUMBER_IS_NOT_STANDARDLIZED /*104*/:
                messageTxt.setText(C0470R.string.Please_enter_the_correct_phone_number);
                break;
            case DialogTipCode.VERIFY_CODE_IS_NOT_STANDARDLIZED /*107*/:
                messageTxt.setText(C0470R.string.The_verify_code_can_not_be_empty);
                break;
            case 109:
                messageTxt.setText(C0470R.string.confirm_correct_password);
                break;
            case 110:
                messageTxt.setText(C0470R.string.password_do_not_match);
                break;
            case 112:
                messageTxt.setText(C0470R.string.Mailbox_can_not_be_empty);
                break;
            case 113:
                messageTxt.setText(C0470R.string.Please_enter_the_correct_mailbox_address);
                break;
            case 10002:
                messageTxt.setText(C0470R.string.verify_codes_is_overtime);
                break;
            case 10006:
                messageTxt.setText(C0470R.string.confirm_correct_password);
                break;
            case 20001:
                messageTxt.setText(C0470R.string.Verify_code_is_incorrect);
                break;
            case 20002:
                messageTxt.setText(C0470R.string.verify_codes_is_overtime);
                break;
            case PASSWORD_IS_NOT_IRREGULARITIES /*21004*/:
                messageTxt.setText(C0470R.string.Set_Pwd_tip);
                break;
            case ACCOUT_IS_NOT_EXISTANCE /*21005*/:
                messageTxt.setText(C0470R.string.user_isnot_exist);
                break;
            default:
                messageTxt.setText(C0470R.string.Unknown_mistake);
                break;
        }
        ((Button) this.lDialog.findViewById(C0470R.id.positiveButton)).setOnClickListener(new C03574());
        ((Button) this.lDialog.findViewById(C0470R.id.negativeButton)).setOnClickListener(new C03585());
        this.lDialog.show();
        this.dialog_showtime.start();
    }

    public static boolean isMobileNO(String mobiles) {
        return Pattern.compile("^(([0-9][0-9][0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$").matcher(mobiles).matches();
    }

    private void initLoginingDlg() {
        this.mResetDlg = new Dialog(this, C0470R.style.loginingDlg);
        this.mResetDlg.setContentView(C0470R.layout.logining_dlg);
        LayoutParams params = this.mResetDlg.getWindow().getAttributes();
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int cxScreen = dm.widthPixels;
        int height = (int) getResources().getDimension(C0470R.dimen.loginingdlg_height);
        int lrMargin = (int) getResources().getDimension(C0470R.dimen.loginingdlg_lr_margin);
        int topMargin = (int) getResources().getDimension(C0470R.dimen.loginingdlg_top_margin);
        params.y = ((-(dm.heightPixels - height)) / 2) + topMargin;
        params.width = cxScreen;
        params.height = height;
        this.mResetDlg.setCanceledOnTouchOutside(true);
    }

    private void showResetingDlg() {
        if (this.mResetDlg != null) {
            this.mResetDlg.show();
        }
    }

    private void closeResetingDlg() {
        if (this.mResetDlg != null && this.mResetDlg.isShowing()) {
            this.mResetDlg.dismiss();
        }
    }

    private static boolean passwordFormat(String password) {
        return Pattern.compile("^[a-zA-Z0-9_`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？][a-zA-Z0-9_`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]{5,13}$").matcher(password).matches();
    }

    private boolean isEmailaddress(String mailboxAddress) {
        return Pattern.compile("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$").matcher(mailboxAddress).matches();
    }

    private boolean isVerifyCode(String code) {
        return Pattern.compile("^([0-9]{6})$").matcher(code).matches();
    }

    private void setPasswordVisibility(boolean isVisible, int index) {
        if (index == 1) {
            if (isVisible) {
                this.et_resetPwd_newPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                this.et_resetPwd_newPwd.setSelection(this.et_resetPwd_newPwd.getText().toString().length());
            } else {
                this.et_resetPwd_newPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                this.et_resetPwd_newPwd.setSelection(this.et_resetPwd_newPwd.getText().toString().length());
            }
        }
        if (index != 2) {
            return;
        }
        if (isVisible) {
            this.et_resetPwd_confirm_newPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            this.et_resetPwd_confirm_newPwd.setSelection(this.et_resetPwd_confirm_newPwd.getText().toString().length());
            return;
        }
        this.et_resetPwd_confirm_newPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
        this.et_resetPwd_confirm_newPwd.setSelection(this.et_resetPwd_confirm_newPwd.getText().toString().length());
    }
}
