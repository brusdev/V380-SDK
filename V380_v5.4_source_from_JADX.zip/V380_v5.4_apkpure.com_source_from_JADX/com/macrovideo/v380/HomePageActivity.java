package com.macrovideo.v380;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.MulticastLock;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.lock.GestureEditActivity;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.software.update.Software;
import com.macrovideo.software.update.UpdateService;
import com.macrovideo.xingepush.RegistClientToServer;
import com.macrovideo.xingepush.RegistClientWithDeviceArrayToServer;
import com.tencent.android.tpush.XGIOperateCallback;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.XGPushManager;
import com.tencent.android.tpush.common.Constants;
import java.util.ArrayList;
import java.util.Locale;
import java.util.StringTokenizer;
import org.apache.http.cookie.ClientCookie;
import org.json.JSONException;
import org.json.JSONObject;

public class HomePageActivity extends FragmentActivity implements OnClickListener {
    public static int AppMode = -100;
    public static int LocalUserID = -101;
    public static String LoginAccount = null;
    public static String LoginEcsIP = "1.1.1.1";
    public static String LoginEcsIP2 = "1.1.1.1";
    public static int LoginEcsPort = 0;
    public static int LoginEcsPort2 = 0;
    public static int LoginIsOpenServers = 0;
    public static int LoginWay = -101;
    private static final int MY_PERMISSION_REQUEST_CAMERA = 1;
    private static final int MY_PERMISSION_REQUEST_LOCATION = 5;
    private static final int MY_REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 127;
    private static final int MY_REQUEST_CODE_ASK_PHONE = 125;
    private static final int MY_REQUEST_CODE_ASK_STORAGE = 126;
    public static final String TAB_ADD = "tabAdd";
    public static final String TAB_CONFIG = "tabConfig";
    public static final String TAB_EDIT = "tabEdit";
    public static final String TAB_HELP = "tabHelp";
    public static final String TAB_HOME = "tabHome";
    public static final String TAB_PLAYBACK = "tabRecPlayback";
    public static final String TAB_SCREENSHOT = "tabScreenshot";
    static final long TIME_P = 43200000;
    public static boolean bSoftware = true;
    private int _nUpdateCheckThreadID = 0;
    private boolean bBack = true;
    boolean bFromConfig = false;
    private int canUpdateDeviceNum = 0;
    private Context context;
    private FragmentManager fragmentManager;
    private HomePageActivity homeActivity;
    private boolean isFirstIn;
    boolean isFromInit = true;
    private boolean isRecFileListVisible = false;
    private boolean isRecFileLoadFromDatabase = false;
    private ImageView ivDeviceSet;
    private ImageView ivDeviceUpdateDot;
    private ImageView ivHelp;
    private ImageView ivHome;
    private ImageView ivPlayBack;
    private Handler lHandler = new C03651();
    LinearLayout llDeviceSet;
    private LinearLayout llGuideBar;
    LinearLayout llHelp;
    LinearLayout llHome;
    LinearLayout llPlayBack;
    private ConfigDeviceFragment mConfigDeviceFragment = new ConfigDeviceFragment(null);
    private DeviceAlarmAndPromptSettingFragment mDeviceAlarmAndPromptFragment = new DeviceAlarmAndPromptSettingFragment(null);
    private DeviceDateTimeSettingFragment mDeviceDatetimeFragment = new DeviceDateTimeSettingFragment(null);
    private DeviceListViewFragment mDeviceListViewFragment = new DeviceListViewFragment();
    private DeviceNetworkSettingFragment mDeviceNetworkFragment = new DeviceNetworkSettingFragment(null);
    private DeviceRecordSettingFragment mDeviceRecordFragment = new DeviceRecordSettingFragment(null);
    private DeviceStaticIPConfigFragment mDeviceStaticIPConfigFragment = new DeviceStaticIPConfigFragment(null);
    private DeviceVersionInfoViewFragment mDeviceVersionInfoFragment = new DeviceVersionInfoViewFragment(null);
    private HelpFragment mHelpFragment = new HelpFragment();
    private PlaybackFragment mPlaybackFragment = new PlaybackFragment();
    private int mScreenWidth;
    DeviceInfo mSelectInfo = null;
    boolean m_bFinish = false;
    private Dialog messageDialog;
    MulticastLock multicastLock = null;
    private int nNotPromotVersionNum = 0;
    private int nPageIndex = 10;
    private int nRadioIndex = 100;
    private SharedPreferences shareAppMode;
    private SharedPreferences shareToken;
    private SharedPreferences sharedPreferencesV380 = null;
    Software software = new Software();
    private Dialog softwareUpdateDialog;
    private TextView tvDeviceSetting;
    private TextView tvHelp;
    private TextView tvHome;
    private TextView tvPlayBack;

    class C03651 extends Handler {
        C03651() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 == LocalDefines.APP_UPDATE_RESULT) {
                HomePageActivity.this.nNotPromotVersionNum = 7;
                if (msg.arg2 == LocalDefines.APP_UPDATE_RESULT_HAS_NEW && HomePageActivity.this.software.getnVersionNum() > HomePageActivity.this.nNotPromotVersionNum && LocalDefines._nCheckVersionNUm != HomePageActivity.this.software.getnVersionNum()) {
                    LocalDefines._lCheckTime = System.currentTimeMillis();
                    LocalDefines._nCheckVersionNUm = HomePageActivity.this.software.getnVersionNum();
                    HomePageActivity.this.NewVersionNotice();
                }
            }
        }
    }

    class C03662 implements DialogInterface.OnClickListener {
        C03662() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            LocalDefines.IsSoftwareRunning = false;
            HomePageActivity.this.m_bFinish = true;
            LocalDefines.homePageActivity = null;
            Process.killProcess(Process.myPid());
            System.exit(0);
            HomePageActivity.this.finish();
        }
    }

    class C03695 implements DialogInterface.OnClickListener {
        C03695() {
        }

        public void onClick(DialogInterface dialog, int which) {
            Intent intent = new Intent();
            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.fromParts("package", HomePageActivity.this.context.getPackageName(), null));
            HomePageActivity.this.startActivity(intent);
        }
    }

    class C03706 implements DialogInterface.OnClickListener {
        C03706() {
        }

        public void onClick(DialogInterface dialog, int which) {
            Intent intent = new Intent();
            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.fromParts("package", HomePageActivity.this.context.getPackageName(), null));
            HomePageActivity.this.startActivity(intent);
        }
    }

    class C03717 implements DialogInterface.OnClickListener {
        C03717() {
        }

        public void onClick(DialogInterface dialog, int which) {
            HomePageActivity.this.requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 126);
        }
    }

    class C03728 implements DialogInterface.OnClickListener {
        C03728() {
        }

        public void onClick(DialogInterface dialog, int which) {
            Intent intent = new Intent();
            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.fromParts("package", HomePageActivity.this.context.getPackageName(), null));
            HomePageActivity.this.startActivity(intent);
            HomePageActivity.this.homeActivity.closeActivity();
        }
    }

    class C03739 implements DialogInterface.OnClickListener {
        C03739() {
        }

        public void onClick(DialogInterface dialog, int which) {
            Intent intent = new Intent();
            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.fromParts("package", HomePageActivity.this.context.getPackageName(), null));
            HomePageActivity.this.startActivity(intent);
            HomePageActivity.this.homeActivity.closeActivity();
        }
    }

    public class AppUpdateCheckThread extends Thread {
        private Handler lHandler = null;
        private int nThreadID = 0;

        public AppUpdateCheckThread(Handler lHandler, int nThreadID) {
            this.nThreadID = nThreadID;
            this.lHandler = lHandler;
        }

        public void run() {
            JSONException e;
            JSONObject json = new JSONObject();
            try {
                json.put("app_id", LocalDefines.APP_ID_V380);
                json.put("app_name", LocalDefines.ANDROID_APP_NAME);
                json.put(LocalDefines.APP_VERSION, Functions.getVersionName(HomePageActivity.this));
                json.put("system_id", 200);
                json.put("system_ver", Functions.getSystemVersion());
                String requestResult;
                int result;
                boolean bHasNew;
                JSONObject jsonCheckResult;
                JSONObject jsonNewVersion;
                JSONObject jSONObject;
                if (LocalDefines.strSysLan == null || LocalDefines.strSysLan.length() <= 0) {
                    json.put("system_lan", "cn");
                    requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strUpdate, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_SOFTWARE_UPDATE).append(json.toString()).toString());
                    result = LocalDefines.APP_UPDATE_RESULT_NO_NEW;
                    bHasNew = false;
                    if (requestResult != null && this.nThreadID == HomePageActivity.this._nUpdateCheckThreadID) {
                        try {
                            jsonCheckResult = new JSONObject(requestResult);
                            if (jsonCheckResult != null) {
                                try {
                                    if (jsonCheckResult.getInt("result") == LocalDefines.APP_UPDATE_RESULT_HAS_NEW) {
                                        jsonNewVersion = jsonCheckResult.getJSONObject("new_version_info");
                                        if (jsonNewVersion != null) {
                                            HomePageActivity.this.software.setnAppID(jsonNewVersion.getInt("appID"));
                                            HomePageActivity.this.software.setStrName(jsonNewVersion.getString("appName"));
                                            HomePageActivity.this.software.setStrReleaseDate(jsonNewVersion.getString("appReleaseDate"));
                                            HomePageActivity.this.software.setnSize(jsonNewVersion.getInt("appSize"));
                                            HomePageActivity.this.software.setnVersionNum(jsonNewVersion.getInt("appVersionNum"));
                                            HomePageActivity.this.software.setStrVersionName(jsonNewVersion.getString("appVersionName"));
                                            HomePageActivity.this.software.setStrCompany(jsonNewVersion.getString("appCompany"));
                                            HomePageActivity.this.software.setStrSite(jsonNewVersion.getString("appSite"));
                                            HomePageActivity.this.software.setStrDescription(jsonNewVersion.getString("appDescription"));
                                            bHasNew = true;
                                            jSONObject = jsonCheckResult;
                                        }
                                    }
                                } catch (JSONException e2) {
                                    e = e2;
                                    jSONObject = jsonCheckResult;
                                    System.out.println(" " + e.toString());
                                    if (this.nThreadID == HomePageActivity.this._nUpdateCheckThreadID) {
                                    }
                                }
                            }
                        } catch (JSONException e3) {
                            e = e3;
                            System.out.println(" " + e.toString());
                            if (this.nThreadID == HomePageActivity.this._nUpdateCheckThreadID) {
                            }
                        }
                    }
                    if (this.nThreadID == HomePageActivity.this._nUpdateCheckThreadID && this.lHandler != null) {
                        Message msg = this.lHandler.obtainMessage();
                        msg.arg1 = LocalDefines.APP_UPDATE_RESULT;
                        System.out.println("Ver check msg: = " + bHasNew);
                        if (bHasNew) {
                            msg.arg2 = LocalDefines.APP_UPDATE_RESULT_HAS_NEW;
                        } else {
                            msg.arg2 = LocalDefines.APP_UPDATE_RESULT_NO_NEW;
                        }
                        this.lHandler.sendMessage(msg);
                        return;
                    }
                }
                json.put("system_lan", LocalDefines.strSysLan);
                requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strUpdate, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_SOFTWARE_UPDATE).append(json.toString()).toString());
                result = LocalDefines.APP_UPDATE_RESULT_NO_NEW;
                bHasNew = false;
                jsonCheckResult = new JSONObject(requestResult);
                if (jsonCheckResult != null) {
                    if (jsonCheckResult.getInt("result") == LocalDefines.APP_UPDATE_RESULT_HAS_NEW) {
                        jsonNewVersion = jsonCheckResult.getJSONObject("new_version_info");
                        if (jsonNewVersion != null) {
                            HomePageActivity.this.software.setnAppID(jsonNewVersion.getInt("appID"));
                            HomePageActivity.this.software.setStrName(jsonNewVersion.getString("appName"));
                            HomePageActivity.this.software.setStrReleaseDate(jsonNewVersion.getString("appReleaseDate"));
                            HomePageActivity.this.software.setnSize(jsonNewVersion.getInt("appSize"));
                            HomePageActivity.this.software.setnVersionNum(jsonNewVersion.getInt("appVersionNum"));
                            HomePageActivity.this.software.setStrVersionName(jsonNewVersion.getString("appVersionName"));
                            HomePageActivity.this.software.setStrCompany(jsonNewVersion.getString("appCompany"));
                            HomePageActivity.this.software.setStrSite(jsonNewVersion.getString("appSite"));
                            HomePageActivity.this.software.setStrDescription(jsonNewVersion.getString("appDescription"));
                            bHasNew = true;
                            jSONObject = jsonCheckResult;
                            if (this.nThreadID == HomePageActivity.this._nUpdateCheckThreadID) {
                            }
                        }
                    }
                }
                if (this.nThreadID == HomePageActivity.this._nUpdateCheckThreadID) {
                }
            } catch (JSONException e4) {
            }
        }
    }

    private class AreaSelectionAdapter extends BaseAdapter {
        private ArrayList<AreaInfo> listArea;
        private LayoutInflater mInflater;

        public final class ViewHolder {
            public TextView tvAreaA;
            public TextView tvAreaAll;
        }

        public AreaSelectionAdapter(ArrayList<AreaInfo> listArea) {
            this.listArea = listArea;
            this.mInflater = (LayoutInflater) HomePageActivity.this.getSystemService("layout_inflater");
        }

        public int getCount() {
            return this.listArea.size();
        }

        public Object getItem(int position) {
            return this.listArea.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View converView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (converView == null) {
                viewHolder = new ViewHolder();
                converView = this.mInflater.inflate(C0470R.layout.area_list_item, null);
                viewHolder.tvAreaAll = (TextView) converView.findViewById(C0470R.id.tvAreaItemAll);
                viewHolder.tvAreaA = (TextView) converView.findViewById(C0470R.id.tvAreaItemA);
                converView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) converView.getTag();
            }
            viewHolder.tvAreaAll.setText(((AreaInfo) this.listArea.get(position)).getArea());
            viewHolder.tvAreaA.setText(((AreaInfo) this.listArea.get(position)).getCountry());
            if (position == LocalDefines.areaID) {
                viewHolder.tvAreaAll.setTextColor(-16776961);
                viewHolder.tvAreaA.setTextColor(-16776961);
            } else {
                viewHolder.tvAreaAll.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                viewHolder.tvAreaA.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            }
            return converView;
        }
    }

    public /* bridge */ /* synthetic */ View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return super.onCreateView(view, str, context, attributeSet);
    }

    public /* bridge */ /* synthetic */ View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return super.onCreateView(str, context, attributeSet);
    }

    public void closeActivity() {
        this.m_bFinish = true;
        LocalDefines.homePageActivity = null;
        finish();
    }

    protected void onDestroy() {
        this.mDeviceNetworkFragment = null;
        this.mDeviceRecordFragment = null;
        this.mDeviceDatetimeFragment = null;
        this.mDeviceVersionInfoFragment = null;
        this.mDeviceAlarmAndPromptFragment = null;
        this.mDeviceListViewFragment = null;
        this.mConfigDeviceFragment = null;
        this.mPlaybackFragment = null;
        this.mHelpFragment = null;
        this.multicastLock = null;
        LocalDefines.homePageActivity = null;
        super.onDestroy();
    }

    public void ShowApplicationExitAlert() {
        View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.str_Notic_Close_APP));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setVisibility(8);
        new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C03662()).setNegativeButton(getString(C0470R.string.alert_btn_Cancel), null).show();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.bBack) {
                ShowApplicationExitAlert();
            } else if (LocalDefines.bIsConfig) {
                if (this.nPageIndex == 20 && this.mDeviceStaticIPConfigFragment != null) {
                    this.mDeviceStaticIPConfigFragment.clearEditText();
                }
                if (this.nPageIndex == 14 && this.mDeviceNetworkFragment != null && this.mDeviceNetworkFragment.mIsSearchingWifiList) {
                    this.mDeviceNetworkFragment.StopSearchWifi();
                }
                ChangeFragment(14, 13, LocalDefines.configDeviceInfo);
                LocalDefines.bIsConfig = false;
            } else if (LocalDefines.bIsBackPlay) {
                this.mPlaybackFragment.backPlayBack();
            } else {
                ShowServerListView();
                this.ivHome.setImageResource(C0470R.drawable.my_device_2);
                this.ivPlayBack.setImageResource(C0470R.drawable.server_video_1);
                this.ivDeviceSet.setImageResource(C0470R.drawable.server_set_1);
                this.ivHelp.setImageResource(C0470R.drawable.server_system_1);
                resetTextColor();
                this.tvHome.setTextColor(Color.parseColor("#0182E2"));
                this.bBack = true;
            }
        }
        return false;
    }

    protected void onStart() {
        super.onStart();
        LocalDefines.areaID = getSharedPreferences(GestureEditActivity.PARAM_LOCK_PASSWORD, 0).getInt(AreaListActivity.AREA, 0);
        Functions.setZoneIndex(LocalDefines.areaID);
        LocalDefines.IsSoftwareOpen = true;
        if (LocalDefines.PLAY_BACK_BACK) {
            LocalDefines.bIsBackPlay = true;
            this.ivHome.setImageResource(C0470R.drawable.my_device_1);
            this.ivPlayBack.setImageResource(C0470R.drawable.server_video_2);
            this.ivDeviceSet.setImageResource(C0470R.drawable.server_set_1);
            this.ivHelp.setImageResource(C0470R.drawable.server_system_1);
            resetTextColor();
            this.tvPlayBack.setTextColor(Color.parseColor("#0182E2"));
            this.bBack = false;
            this.nRadioIndex = 102;
            ShowPlayBackView();
            LocalDefines.PLAY_BACK_BACK = false;
            setGuideBarVisible(false);
        }
        if (System.currentTimeMillis() - LocalDefines._lCheckTime >= 300000) {
            CheckAppUpdate();
        }
    }

    public void onStop() {
        super.onStop();
        LocalDefines.IsSoftwareOpen = false;
        if (!this.m_bFinish) {
            Intent intent = new Intent(this, HomePageActivity.class);
            Bundle bundle = new Bundle();
            if (this.nPageIndex == 14) {
                if (this.mDeviceNetworkFragment.isGetFinish()) {
                    intent.putExtra("net_config", this.mDeviceNetworkFragment.getmNetworkConfig());
                } else {
                    this.nPageIndex = 13;
                }
            } else if (this.nPageIndex == 15) {
                if (this.mDeviceRecordFragment.isGetFinish()) {
                    intent.putExtra("record_config", this.mDeviceRecordFragment.getmRecordConfig());
                } else {
                    this.nPageIndex = 13;
                }
            } else if (this.nPageIndex == 16) {
                if (!this.mDeviceDatetimeFragment.isGetFinish()) {
                    this.nPageIndex = 13;
                }
            } else if (this.nPageIndex == 18) {
                if (this.mDeviceVersionInfoFragment.isGetFinish()) {
                    intent.putExtra("version_config", this.mDeviceVersionInfoFragment.getVerInfo());
                } else {
                    this.nPageIndex = 13;
                }
            }
            this.isRecFileLoadFromDatabase = this.mPlaybackFragment.isLoadFromDatabase();
            if (this.isRecFileLoadFromDatabase) {
                this.mPlaybackFragment.SaveRecFileListToDatabase();
            }
            this.isRecFileListVisible = this.mPlaybackFragment.isListVisible();
            if (this.isRecFileListVisible) {
                bundle.putLong(Defines.CLOUD_RECORD_FILE_RETURN_MESSAGE, Defines._lHandle);
                bundle.putString("str_ip", LocalDefines._strSearchIP);
                bundle.putString("str_lan_ip", LocalDefines._strSearchIP);
                bundle.putInt(ClientCookie.PORT_ATTR, LocalDefines._nSearchPort);
                bundle.putBoolean("mrmode", Defines._isMRMode);
                bundle.putString("mrserver", Defines._strMRServer);
                bundle.putInt("mrport", Defines._nMRPort);
            }
            bundle.putBoolean("rec_load_from_db", this.isRecFileLoadFromDatabase);
            bundle.putBoolean("is_file_list_visible", this.isRecFileListVisible);
            bundle.putInt("page_index", this.nPageIndex);
            bundle.putInt("radio_index", this.nRadioIndex);
            if (this.mSelectInfo != null) {
                bundle.putBoolean("has_serverinfo", true);
                bundle.putInt("info_id", this.mSelectInfo.getnID());
                return;
            }
            bundle.putBoolean("has_serverinfo", false);
        }
    }

    public void onResume() {
        super.onResume();
        Functions.initLanguageContext(this);
        this.m_bFinish = false;
        if (this.sharedPreferencesV380 != null) {
            this.nNotPromotVersionNum = this.sharedPreferencesV380.getInt("not_promt_ver", 0);
        }
        ((NotificationManager) getSystemService("notification")).cancelAll();
        long lTimeNow = System.currentTimeMillis();
        LocalDefines.nClientDeviceSettingThreadID++;
        new RegistClientWithDeviceArrayToServer(this.context, LocalDefines.nClientDeviceSettingThreadID).start();
        sendBroadcastToClosePlayerActivity();
    }

    private void sendBroadcastToClosePlayerActivity() {
        Intent intent = new Intent();
        intent.setAction(LocalDefines.getReceiverActionString(this));
        sendBroadcast(intent);
    }

    private void showAreaSelectDialog() {
        final ArrayList<AreaInfo> listArea = AreaData();
        AlertDialog alertDialog = new Builder(this).setTitle(C0470R.string.areaSelection).setAdapter(new AreaSelectionAdapter(listArea), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int which) {
                if (listArea != null && listArea.size() > 0 && which >= 0 && which <= listArea.size()) {
                    Editor editor = HomePageActivity.this.getSharedPreferences(GestureEditActivity.PARAM_LOCK_PASSWORD, 0).edit();
                    editor.putInt(AreaListActivity.AREA, which);
                    editor.commit();
                    LocalDefines.areaID = which;
                }
            }
        }).create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.setCancelable(false);
        alertDialog.show();
    }

    private ArrayList<AreaInfo> AreaData() {
        ArrayList<AreaInfo> listArea = new ArrayList();
        AreaInfo data = new AreaInfo();
        data.setArea(getString(C0470R.string.autoSelect));
        data.setCountry("(" + getString(C0470R.string.autoSelect) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.china));
        data.setCountry("(" + getString(C0470R.string.china2) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AS1));
        data.setCountry("(" + getString(C0470R.string.zoneAS1) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AS2));
        data.setCountry("(" + getString(C0470R.string.zoneAS2) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AS3));
        data.setCountry("(" + getString(C0470R.string.zoneAS3) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AS4));
        data.setCountry("(" + getString(C0470R.string.zoneAS4) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.NA1));
        data.setCountry("(" + getString(C0470R.string.zoneNA1) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.SA1));
        data.setCountry("(" + getString(C0470R.string.zoneSA1) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.EU1));
        data.setCountry("(" + getString(C0470R.string.zoneEU1) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.EU2));
        data.setCountry("(" + getString(C0470R.string.zoneEU2) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.OA1));
        data.setCountry("(" + getString(C0470R.string.zoneOA1) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AF1));
        data.setCountry("(" + getString(C0470R.string.zoneAF1) + ")");
        listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AF2));
        data.setCountry("(" + getString(C0470R.string.zoneAF2) + ")");
        listArea.add(data);
        return listArea;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((NotificationManager) getSystemService("notification")).cancel(257);
        requestWindowFeature(1);
        this.mScreenWidth = getResources().getDisplayMetrics().widthPixels;
        LocalDefines.homePageActivity = this;
        Functions.initLanguageContext(this);
        this.shareAppMode = getSharedPreferences("ShareAPPMODE", 0);
        AppMode = this.shareAppMode.getInt("GetModeNum", -101);
        DatabaseManager.InitDataBase(this);
        InitXingePush();
        LocalDefines.loadAlarmSettings(this);
        this.sharedPreferencesV380 = getSharedPreferences("v380_prop", 0);
        LocalDefines.IsSoftwareRunning = true;
        initArgs();
        Object param = null;
        if (AppMode == 1) {
            this.shareToken = getSharedPreferences("SaveSign", 0);
            LocalUserID = this.shareToken.getInt("saveServeruserid", -101);
            int preUserId = getIntent().getIntExtra("preUserId", -101);
            if (!(preUserId == LocalUserID || preUserId == -101)) {
                DatabaseManager.ClearServerInfo();
                getSharedPreferences("SaveTimeTamp", 0).edit().putInt("TimeTamp", -101).commit();
            }
            String accesstoken = this.shareToken.getString("saveToken", Constants.MAIN_VERSION_TAG);
            LocalUserID = this.shareToken.getInt("saveServeruserid", -101);
            LoginWay = this.shareToken.getInt("saveloginway", -101);
            LoginAccount = this.shareToken.getString("saveAccount", null);
            LoginIsOpenServers = this.shareToken.getInt("saveloginis_open_service", 0);
            LoginEcsIP = this.shareToken.getString("saveloginEcsIp", Constants.MAIN_VERSION_TAG);
            LoginEcsIP2 = this.shareToken.getString("saveloginEcsIp2", Constants.MAIN_VERSION_TAG);
            LoginEcsPort = this.shareToken.getInt("saveloginEcsport", 0);
            LoginEcsPort2 = this.shareToken.getInt("saveloginEcsport2", 0);
        }
        Bundle data = getIntent().getExtras();
        this.isFirstIn = LocalDefines.isFirstIn;
        if (this.isFirstIn) {
            LocalDefines.isFirstIn = false;
            if (!Locale.getDefault().getLanguage().equals("zh")) {
                showAreaSelectDialog();
            }
        }
        if (data != null) {
            this.nPageIndex = data.getInt("page_index");
            this.nRadioIndex = data.getInt("radio_index");
            this.isRecFileLoadFromDatabase = data.getBoolean("rec_load_from_db");
            this.isRecFileListVisible = data.getBoolean("is_file_list_visible");
            if (!this.isRecFileLoadFromDatabase) {
                DatabaseManager.ClearRecInfos();
            }
            this.mPlaybackFragment.setLoadFromDatabase(this.isRecFileLoadFromDatabase);
            this.mPlaybackFragment.setListVisible(this.isRecFileListVisible);
            if (data.getBoolean("has_serverinfo")) {
                this.mSelectInfo = DatabaseManager.GetServerInfoByID(data.getInt("info_id"));
                if (this.nPageIndex == 14) {
                    param = data.getParcelable("net_config");
                } else if (this.nPageIndex == 15) {
                    param = data.getParcelable("record_config");
                } else if (this.nPageIndex == 16) {
                    param = data.getParcelable("datetime_config");
                } else if (this.nPageIndex == 17) {
                    param = data.getParcelable("account_config");
                } else if (this.nPageIndex == 18) {
                    param = data.getParcelable("version_config");
                }
            } else {
                this.mSelectInfo = null;
            }
        } else {
            this.nPageIndex = 10;
            this.nRadioIndex = 100;
        }
        InitTabView(param);
        this.ivHome = (ImageView) findViewById(C0470R.id.ivHome);
        this.ivPlayBack = (ImageView) findViewById(C0470R.id.ivPlayBack);
        this.ivHelp = (ImageView) findViewById(C0470R.id.ivHelp);
        this.ivDeviceSet = (ImageView) findViewById(C0470R.id.ivDeviceSet);
        this.ivDeviceUpdateDot = (ImageView) findViewById(C0470R.id.home_iv_device_update_dot);
        this.llHome = (LinearLayout) findViewById(C0470R.id.llHome);
        this.llHome.setOnClickListener(this);
        this.llPlayBack = (LinearLayout) findViewById(C0470R.id.llPlayBack);
        this.llPlayBack.setOnClickListener(this);
        this.llDeviceSet = (LinearLayout) findViewById(C0470R.id.llDeviceSet);
        this.llDeviceSet.setOnClickListener(this);
        this.llHelp = (LinearLayout) findViewById(C0470R.id.llHelp);
        this.llHelp.setOnClickListener(this);
        this.tvHome = (TextView) findViewById(C0470R.id.tv_home);
        this.tvPlayBack = (TextView) findViewById(C0470R.id.tv_playback);
        this.tvDeviceSetting = (TextView) findViewById(C0470R.id.tv_device_setting);
        this.tvHelp = (TextView) findViewById(C0470R.id.tv_help);
        if (LocalDefines.HAS_NEW_MSG) {
            if (LocalDefines.MSG_TITLE.equals(Constants.MAIN_VERSION_TAG)) {
                NoTitleMessageDialog(LocalDefines.MSG_TITLE, LocalDefines.MSG);
            } else {
                HasTitleMessageDialog(LocalDefines.MSG_TITLE, LocalDefines.MSG);
            }
            LocalDefines.HAS_NEW_MSG = false;
        }
        this.homeActivity = this;
        if (VERSION.SDK_INT >= 23) {
            askForMultiPermissions2();
        }
    }

    public int getCanUpdateDeviceNum() {
        return this.canUpdateDeviceNum;
    }

    public void setCanUpdateDeviceNum(final int canUpdateDeviceNum) {
        this.canUpdateDeviceNum = canUpdateDeviceNum;
        runOnUiThread(new Runnable() {
            public void run() {
                if (canUpdateDeviceNum > 0) {
                    HomePageActivity.this.ivDeviceUpdateDot.setVisibility(0);
                } else {
                    HomePageActivity.this.ivDeviceUpdateDot.setVisibility(4);
                }
            }
        });
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (permissions[0].equals("android.permission.CAMERA") && grantResults[0] == 0) {
                    startActivity(new Intent(this, CaptureActivity.class));
                    return;
                } else {
                    new Builder(this.context).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_camera2)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new C03706()).show();
                    return;
                }
            case 5:
                if (permissions[0].equals("android.permission.ACCESS_COARSE_LOCATION") && grantResults[0] == 0) {
                    startActivity(new Intent(this, SmartLinkQuickWifiConfigActivity.class));
                    closeActivity();
                    return;
                }
                new Builder(this.context).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_location)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new C03695()).show();
                return;
            case MY_REQUEST_CODE_ASK_PHONE /*125*/:
                if (!permissions[0].equals("android.permission.READ_PHONE_STATE") || grantResults[0] != 0) {
                    new Builder(this.context).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_phone1)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new C03739()).show();
                    return;
                }
                return;
            case 126:
                if (!permissions[0].equals("android.permission.WRITE_EXTERNAL_STORAGE") || grantResults[0] != 0) {
                    new Builder(this.context).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_storage1)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent();
                            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                            intent.setData(Uri.fromParts("package", HomePageActivity.this.context.getPackageName(), null));
                            HomePageActivity.this.startActivity(intent);
                            HomePageActivity.this.homeActivity.closeActivity();
                        }
                    }).show();
                    return;
                }
                return;
            case 127:
                if (permissions[0].equals("android.permission.READ_PHONE_STATE") && grantResults[0] == 0) {
                    requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 126);
                    return;
                }
                new Builder(this.context).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_phone1)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), new C03717()).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new C03728()).show();
                return;
            default:
                return;
        }
    }

    private void askForMultiPermissions2() {
        boolean hasPhonePermission;
        if (checkSelfPermission("android.permission.READ_PHONE_STATE") == 0) {
            hasPhonePermission = true;
        } else {
            hasPhonePermission = false;
        }
        boolean hasStoragePermission;
        if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            hasStoragePermission = true;
        } else {
            hasStoragePermission = false;
        }
        if (!hasPhonePermission || !hasStoragePermission) {
            if (hasPhonePermission && !hasStoragePermission) {
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 126);
            } else if (!hasPhonePermission && hasStoragePermission) {
                requestPermissions(new String[]{"android.permission.READ_PHONE_STATE"}, MY_REQUEST_CODE_ASK_PHONE);
            } else if (!hasPhonePermission && !hasStoragePermission) {
                requestPermissions(new String[]{"android.permission.READ_PHONE_STATE"}, 127);
            }
        }
    }

    private void InitXingePush() {
        Context context = getApplicationContext();
        XGPushManager.registerPush(getApplicationContext(), new XGIOperateCallback() {
            public void onSuccess(Object data, int flag) {
                String strToKen = XGPushConfig.getToken(HomePageActivity.this);
                long nAccessId = XGPushConfig.getAccessId(HomePageActivity.this);
                String strAccessKey = XGPushConfig.getAccessKey(HomePageActivity.this);
            }

            public void onFail(Object data, int errCode, String msg) {
            }
        });
        LocalDefines.strClientID = XGPushConfig.getToken(this);
        LocalDefines.nClientRegistThreadID++;
        new RegistClientToServer(context, LocalDefines.nClientRegistThreadID).start();
        LocalDefines.nClientDeviceSettingThreadID++;
        new RegistClientWithDeviceArrayToServer(context, LocalDefines.nClientDeviceSettingThreadID).start();
    }

    private void initArgs() {
        this.context = this;
        this.fragmentManager = getSupportFragmentManager();
    }

    private void InitTabView(Object param) {
        setContentView(C0470R.layout.activity_home_page);
        this.isFromInit = false;
        this.llGuideBar = (LinearLayout) findViewById(C0470R.id.ll_guide_bar);
        if (!this.isFromInit) {
            if (this.nPageIndex == 10) {
                ShowServerListView();
            } else if (this.nPageIndex == 11) {
                ShowEditDeviceView(this.mSelectInfo, false);
            } else if (this.nPageIndex == 12) {
                ShowEditDeviceView(this.mSelectInfo, true);
            } else if (this.nPageIndex == 13) {
                if (this.mSelectInfo == null) {
                    ShowServerListView();
                } else {
                    ShowDeviceConfigView(this.mSelectInfo);
                }
            } else if (this.nPageIndex == 14) {
                ShowNetworkConfigView(this.mSelectInfo, false);
            } else if (this.nPageIndex == 15) {
                ShowRecordConfigView(this.mSelectInfo, false);
            } else if (this.nPageIndex == 16) {
                ShowDatetimeConfigView(this.mSelectInfo, false);
            } else if (this.nPageIndex == 18) {
                ShowVersioInfoView(this.mSelectInfo, false);
            } else if (this.nPageIndex == 19) {
                ShowAlarmAndPromptView(this.mSelectInfo, false);
            } else {
                this.nPageIndex = 10;
                ShowServerListView();
            }
        }
    }

    private void ShowServerListView() {
        setGuideBarVisible(true);
        this.nPageIndex = 10;
        if (this.mDeviceListViewFragment != null) {
            this.mDeviceListViewFragment.mIsModifyDeviceInfo = false;
        }
        updateFragment(this.mDeviceListViewFragment, false);
    }

    private void ShowEditDeviceView(DeviceInfo info, boolean isFromConfig) {
        this.mSelectInfo = info;
        if (isFromConfig) {
            this.nPageIndex = 12;
        } else {
            this.nPageIndex = 11;
        }
    }

    private void ShowDeviceConfigView(DeviceInfo info) {
        this.mSelectInfo = info;
        if (this.mSelectInfo != null) {
            this.nPageIndex = 13;
            this.mConfigDeviceFragment.setServerInfo(info);
            updateFragment(this.mConfigDeviceFragment, true);
        }
    }

    private void ShowNetworkConfigView(DeviceInfo info, boolean bNeedFresh) {
        this.mSelectInfo = info;
        if (this.mSelectInfo != null) {
            this.nPageIndex = 14;
            this.mDeviceNetworkFragment.setServerInfo(info);
            if (bNeedFresh) {
                this.mDeviceNetworkFragment.setNeedFreshInterface(bNeedFresh);
            }
            updateFragment(this.mDeviceNetworkFragment, true);
        }
    }

    private void ShowRecordConfigView(DeviceInfo info, boolean bNeedFresh) {
        this.mSelectInfo = info;
        if (this.mSelectInfo != null) {
            this.nPageIndex = 15;
            this.mDeviceRecordFragment.setServerInfo(info);
            if (bNeedFresh) {
                this.mDeviceRecordFragment.setNeedFreshInterface(bNeedFresh);
            }
            updateFragment(this.mDeviceRecordFragment, true);
        }
    }

    private void ShowDatetimeConfigView(DeviceInfo info, boolean bNeedFresh) {
        this.mSelectInfo = info;
        if (this.mSelectInfo != null) {
            this.nPageIndex = 16;
            this.mDeviceDatetimeFragment.setServerInfo(info);
            if (bNeedFresh) {
                this.mDeviceDatetimeFragment.setNeedFreshInterface(bNeedFresh);
            }
            updateFragment(this.mDeviceDatetimeFragment, true);
        }
    }

    private void ShowVersioInfoView(DeviceInfo info, boolean bNeedFresh) {
        this.mSelectInfo = info;
        if (this.mSelectInfo != null) {
            this.nPageIndex = 18;
            this.mDeviceVersionInfoFragment.setServerInfo(info);
            if (bNeedFresh) {
                this.mDeviceVersionInfoFragment.setNeedFreshInterface(bNeedFresh);
            }
            updateFragment(this.mDeviceVersionInfoFragment, true);
        }
    }

    private void ShowAlarmAndPromptView(DeviceInfo info, boolean bNeedFresh) {
        this.mSelectInfo = info;
        if (this.mSelectInfo != null) {
            this.nPageIndex = 19;
            this.mDeviceAlarmAndPromptFragment.setServerInfo(info);
            if (bNeedFresh) {
                this.mDeviceAlarmAndPromptFragment.setNeedFreshInterface(bNeedFresh);
            }
            updateFragment(this.mDeviceAlarmAndPromptFragment, true);
        }
    }

    private void ShowStaticIPView(DeviceInfo info, boolean bNeedFresh) {
        this.mSelectInfo = info;
        if (this.mSelectInfo != null) {
            this.nPageIndex = 20;
            this.mDeviceStaticIPConfigFragment.setServerInfo(info);
            if (bNeedFresh) {
                this.mDeviceStaticIPConfigFragment.setNeedFreshInterface(bNeedFresh);
            }
            updateFragment(this.mDeviceStaticIPConfigFragment, true);
        }
    }

    private void ShowPlayBackView() {
        updateFragment(this.mPlaybackFragment, false);
    }

    private void ShowHelpView() {
        setGuideBarVisible(true);
        updateFragment(this.mHelpFragment, false);
    }

    private void ShowConfigView() {
        setGuideBarVisible(true);
        updateFragment(this.mConfigDeviceFragment, false);
    }

    public void ChangeFragment(int nFromIndex, int nToIndex, DeviceInfo info) {
        this.nPageIndex = nToIndex;
        this.bFromConfig = false;
        this.mSelectInfo = info;
        LocalDefines.bIsConfig = false;
        if (this.nPageIndex == 10) {
            ShowServerListView();
            this.ivHome.setImageResource(C0470R.drawable.my_device_2);
            this.ivPlayBack.setImageResource(C0470R.drawable.server_video_1);
            this.ivDeviceSet.setImageResource(C0470R.drawable.server_set_1);
            this.ivHelp.setImageResource(C0470R.drawable.server_system_1);
            resetTextColor();
            this.tvHome.setTextColor(Color.parseColor("#0182E2"));
        } else if (this.nPageIndex == 11) {
            this.bFromConfig = false;
            ShowEditDeviceView(this.mSelectInfo, this.bFromConfig);
        } else if (this.nPageIndex == 12) {
            this.bFromConfig = true;
            ShowEditDeviceView(this.mSelectInfo, this.bFromConfig);
        } else if (this.nPageIndex == 13) {
            setGuideBarVisible(true);
            ShowDeviceConfigView(this.mSelectInfo);
        } else if (this.nPageIndex == 14) {
            setGuideBarVisible(false);
            ShowNetworkConfigView(this.mSelectInfo, true);
        } else if (this.nPageIndex == 15) {
            setGuideBarVisible(false);
            ShowRecordConfigView(this.mSelectInfo, true);
        } else if (this.nPageIndex == 16) {
            setGuideBarVisible(false);
            ShowDatetimeConfigView(this.mSelectInfo, true);
        } else if (this.nPageIndex == 18) {
            setGuideBarVisible(false);
            ShowVersioInfoView(this.mSelectInfo, true);
        } else if (this.nPageIndex == 19) {
            setGuideBarVisible(false);
            ShowAlarmAndPromptView(this.mSelectInfo, true);
        } else if (this.nPageIndex == 20) {
            setGuideBarVisible(false);
            ShowStaticIPView(this.mSelectInfo, true);
        }
    }

    private void updateFragment(Fragment f, boolean isAddToBackStack) {
        FragmentTransaction ft = this.fragmentManager.beginTransaction();
        ft.replace(C0470R.id.realtabcontent, f);
        ft.commit();
        getSupportFragmentManager().executePendingTransactions();
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    public void ShowAlert(String title, String msg) {
        new Builder(this).setTitle(title).setMessage(msg).setIcon(C0470R.drawable.icon).setPositiveButton(getString(C0470R.string.alert_btn_OK), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                HomePageActivity.this.setResult(-1);
            }
        }).show();
    }

    public void ShowNotic(String title, String msg) {
        Toast toast = Toast.makeText(getApplicationContext(), title, 0);
        toast.setGravity(17, 0, 0);
        toast.show();
    }

    public void openWifiSettingView() {
        if (VERSION.SDK_INT > 10) {
            startActivity(new Intent("android.settings.SETTINGS"));
        } else {
            startActivity(new Intent("android.settings.WIRELESS_SETTINGS"));
        }
    }

    public void openMulticast() {
        try {
            this.multicastLock = ((WifiManager) getSystemService("wifi")).createMulticastLock("multicast");
            this.multicastLock.acquire();
        } catch (Exception e) {
            this.multicastLock = null;
        }
    }

    public void closeMulticast() {
        if (this.multicastLock != null) {
            this.multicastLock.release();
            this.multicastLock = null;
        }
    }

    private void CheckAppUpdate() {
        this._nUpdateCheckThreadID++;
        new AppUpdateCheckThread(this.lHandler, this._nUpdateCheckThreadID).start();
    }

    public void NewVersionNotice() {
        String strMessge = this.software.getStrDescription();
        String strWhatIsNew = null;
        int nCount = 1;
        if (strMessge != null) {
            StringTokenizer strTokens = new StringTokenizer(strMessge, ";");
            strWhatIsNew = strTokens.nextToken();
            while (strTokens.hasMoreTokens()) {
                nCount++;
                strWhatIsNew = new StringBuilder(String.valueOf(strWhatIsNew)).append("\n").append(strTokens.nextToken()).toString();
            }
        }
        View view = View.inflate(this, C0470R.layout.show_software_update_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.findNowVersion));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(strWhatIsNew);
        ((Button) view.findViewById(C0470R.id.btn_no)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                HomePageActivity.this.softwareUpdateDialog.dismiss();
            }
        });
        ((Button) view.findViewById(C0470R.id.btn_yes)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                HomePageActivity.this.updateAPP();
                HomePageActivity.this.softwareUpdateDialog.dismiss();
            }
        });
        this.softwareUpdateDialog = new Dialog(this);
        this.softwareUpdateDialog.requestWindowFeature(1);
        this.softwareUpdateDialog.setContentView(view);
        this.softwareUpdateDialog.show();
    }

    private void updateAPP() {
        try {
            Intent updateIntent = new Intent(this, UpdateService.class);
            updateIntent.putExtra("app_name", getResources().getString(C0470R.string.app_name));
            updateIntent.putExtra("updateSite", this.software.getStrSite());
            startService(updateIntent);
        } catch (Exception e) {
        }
    }

    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case C0470R.id.llHome:
                if (DeviceListViewFragment.mOneKeyAlarmSettingDialog != null && DeviceListViewFragment.mOneKeyAlarmSettingDialog.isShowing()) {
                    return;
                }
                if (DeviceListViewFragment.deleteDeviceDialog == null || !DeviceListViewFragment.deleteDeviceDialog.isShowing()) {
                    this.ivHome.setImageResource(C0470R.drawable.my_device_2);
                    this.ivPlayBack.setImageResource(C0470R.drawable.server_video_1);
                    this.ivDeviceSet.setImageResource(C0470R.drawable.server_set_1);
                    this.ivHelp.setImageResource(C0470R.drawable.server_system_1);
                    ShowServerListView();
                    this.bBack = true;
                    resetTextColor();
                    this.tvHome.setTextColor(Color.parseColor("#0182E2"));
                    return;
                }
                return;
            case C0470R.id.llPlayBack:
                if (DeviceListViewFragment.mOneKeyAlarmSettingDialog != null && DeviceListViewFragment.mOneKeyAlarmSettingDialog.isShowing()) {
                    return;
                }
                if (DeviceListViewFragment.deleteDeviceDialog == null || !DeviceListViewFragment.deleteDeviceDialog.isShowing()) {
                    this.ivHome.setImageResource(C0470R.drawable.my_device_1);
                    this.ivPlayBack.setImageResource(C0470R.drawable.server_video_2);
                    this.ivDeviceSet.setImageResource(C0470R.drawable.server_set_1);
                    this.ivHelp.setImageResource(C0470R.drawable.server_system_1);
                    this.nRadioIndex = 102;
                    ShowPlayBackView();
                    this.bBack = false;
                    this.mPlaybackFragment.backPlayBack();
                    resetTextColor();
                    this.tvPlayBack.setTextColor(Color.parseColor("#0182E2"));
                    return;
                }
                return;
            case C0470R.id.llDeviceSet:
                if (DeviceListViewFragment.mOneKeyAlarmSettingDialog != null && DeviceListViewFragment.mOneKeyAlarmSettingDialog.isShowing()) {
                    return;
                }
                if (DeviceListViewFragment.deleteDeviceDialog == null || !DeviceListViewFragment.deleteDeviceDialog.isShowing()) {
                    this.ivHome.setImageResource(C0470R.drawable.my_device_1);
                    this.ivPlayBack.setImageResource(C0470R.drawable.server_video_1);
                    this.ivDeviceSet.setImageResource(C0470R.drawable.server_set_2);
                    this.ivHelp.setImageResource(C0470R.drawable.server_system_1);
                    ShowConfigView();
                    this.bBack = false;
                    resetTextColor();
                    this.tvDeviceSetting.setTextColor(Color.parseColor("#0182E2"));
                    return;
                }
                return;
            case C0470R.id.llHelp:
                if (DeviceListViewFragment.mOneKeyAlarmSettingDialog != null && DeviceListViewFragment.mOneKeyAlarmSettingDialog.isShowing()) {
                    return;
                }
                if (DeviceListViewFragment.deleteDeviceDialog == null || !DeviceListViewFragment.deleteDeviceDialog.isShowing()) {
                    this.ivHome.setImageResource(C0470R.drawable.my_device_1);
                    this.ivPlayBack.setImageResource(C0470R.drawable.server_video_1);
                    this.ivDeviceSet.setImageResource(C0470R.drawable.server_set_1);
                    this.ivHelp.setImageResource(C0470R.drawable.server_system_2);
                    this.nRadioIndex = 103;
                    ShowHelpView();
                    this.bBack = false;
                    resetTextColor();
                    this.tvHelp.setTextColor(Color.parseColor("#0182E2"));
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void SetEnabled(boolean bEnabled) {
        this.ivHome.setEnabled(bEnabled);
        this.ivPlayBack.setEnabled(bEnabled);
        this.ivHelp.setEnabled(bEnabled);
        this.ivDeviceSet.setEnabled(bEnabled);
    }

    private void resetTextColor() {
        this.tvHome.setTextColor(Color.parseColor("#808080"));
        this.tvPlayBack.setTextColor(Color.parseColor("#808080"));
        this.tvDeviceSetting.setTextColor(Color.parseColor("#808080"));
        this.tvHelp.setTextColor(Color.parseColor("#808080"));
    }

    void setGuideBarVisible(boolean visible) {
        if (visible) {
            this.llGuideBar.setVisibility(0);
        } else {
            this.llGuideBar.setVisibility(8);
        }
    }

    public void HasTitleMessageDialog(String title, String content) {
        View view = View.inflate(this, C0470R.layout.show_message_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(title);
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(content.replace("\\n", "\n"));
        ((Button) view.findViewById(C0470R.id.btn_no)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                HomePageActivity.this.messageDialog.dismiss();
            }
        });
        ((Button) view.findViewById(C0470R.id.btn_yes)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                HomePageActivity.this.messageDialog.dismiss();
            }
        });
        this.messageDialog = new Dialog(this, C0470R.style.messageDlg);
        this.messageDialog.requestWindowFeature(1);
        this.messageDialog.setContentView(view);
        Window dialogWindow = this.messageDialog.getWindow();
        LayoutParams lp = dialogWindow.getAttributes();
        lp.width = (int) (((double) this.mScreenWidth) * 0.7d);
        dialogWindow.setAttributes(lp);
        this.messageDialog.show();
    }

    public void NoTitleMessageDialog(String title, String content) {
        View view = View.inflate(this, C0470R.layout.show_no_title_message_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(content.replace("\\n", "\n"));
        ((Button) view.findViewById(C0470R.id.btn_no)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                HomePageActivity.this.messageDialog.dismiss();
            }
        });
        ((Button) view.findViewById(C0470R.id.btn_yes)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                HomePageActivity.this.messageDialog.dismiss();
            }
        });
        this.messageDialog = new Dialog(this, C0470R.style.messageDlg);
        this.messageDialog.requestWindowFeature(1);
        this.messageDialog.setContentView(view);
        Window dialogWindow = this.messageDialog.getWindow();
        LayoutParams lp = dialogWindow.getAttributes();
        lp.width = (int) (((double) this.mScreenWidth) * 0.7d);
        dialogWindow.setAttributes(lp);
        this.messageDialog.show();
    }
}
