package com.macrovideo.v380;

import android.app.Activity;
import android.view.View;
import com.macrovideo.materialshowcaseview.MaterialShowcaseSequence;
import com.macrovideo.materialshowcaseview.MaterialShowcaseView.Builder;
import com.macrovideo.materialshowcaseview.ShowcaseConfig;

public class ShowCaseView {
    private Activity activity = null;

    public ShowCaseView(Activity activity) {
        this.activity = activity;
    }

    public void addShowcaseView(View[] v, String[] next, String[] content, String SHOWCASE_ID) {
        ShowcaseConfig config = new ShowcaseConfig();
        config.setDelay(500);
        MaterialShowcaseSequence sequence = new MaterialShowcaseSequence(this.activity, SHOWCASE_ID);
        sequence.setConfig(config);
        for (int i = 0; i < v.length; i++) {
            sequence.addSequenceItem(new Builder(this.activity).setTarget(v[i]).setDismissOnTouch(true).setContentText(content[i]).withRectangleShape().build());
        }
        sequence.start();
    }
}
