package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.internal.view.SupportMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.pull.lib.CheckSwitchButton;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.setting.DeviceRecordSetting;
import com.macrovideo.sdk.setting.DeviceSDCardFormatSetting;
import com.macrovideo.sdk.setting.RecordInfo;
import com.tencent.android.tpush.common.Constants;

@SuppressLint({"ValidFragment"})
public class DeviceRecordSettingFragment extends Fragment implements OnClickListener {
    private static final int SDCARD_FORMAT = 1;
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    private boolean bAlarmVideo = false;
    private boolean bFrequency = false;
    private boolean bVideotape = false;
    private CheckSwitchButton btAlarmVideo;
    private CheckSwitchButton btFrequency;
    private CheckSwitchButton btVideotape;
    private ImageView btnRecordBack;
    private Button btnRecordSave;
    private Button btnSDCard;
    private View contentView = null;
    private Handler handler = new C03391();
    private boolean isActive = false;
    private boolean isGetFinish = false;
    private long lFreshTime = 0;
    private LinearLayout ll_line;
    private Dialog loadingDialog;
    private View loadingView;
    private LinearLayout loayoutNewversion = null;
    private boolean mIsNeedFresh = false;
    private int mLoadType = 1;
    private DeviceInfo mServerInfo = null;
    private int nID = -1;
    int nThreadSDCareID = 0;
    private RadioButton rBtnExceed;
    private RadioButton rBtnHigh;
    private RadioButton rBtnMark;
    private RadioGroup rRadioGroup1;
    private Activity relateAtivity = null;
    private TextView tvDiskRemainSize = null;
    private TextView tvDiskSize = null;
    private TextView tvRecordNotice = null;

    class C03391 extends Handler {
        C03391() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            if (DeviceRecordSettingFragment.this.isActive) {
                DeviceRecordSettingFragment.this.mIsNeedFresh = false;
                int bFullRecordOP = 0;
                boolean bAutoRecord = false;
                boolean bAlarmRecord = false;
                int nDiskSize = 0;
                int nDiskRemain = 0;
                int nFrameSize = 0;
                int nRecordStat = 0;
                boolean isAudioEnable = false;
                boolean is1080pEnable = false;
                boolean is720Enable = false;
                boolean isD1Enable = false;
                boolean isVGAEnable = false;
                boolean isCIFEnable = false;
                boolean isQVGAEnable = false;
                boolean isQCIFEnable = false;
                boolean is960pEnable = false;
                Bundle data;
                RecordInfo recordHandler;
                if (msg.arg1 == 96) {
                    DeviceRecordSettingFragment.this.loadingDialog.dismiss();
                    DeviceRecordSettingFragment.this.btnRecordSave.setEnabled(true);
                    DeviceRecordSettingFragment.this.contentView.findViewById(C0470R.id.layoutRecordConfigPanel).setEnabled(true);
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_NetError));
                            return;
                        case 256:
                            data = msg.getData();
                            if (data != null) {
                                DeviceRecordSettingFragment.this.lFreshTime = System.currentTimeMillis();
                                recordHandler = (RecordInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                                if (recordHandler != null) {
                                    bFullRecordOP = recordHandler.getnFullRecordOP();
                                    bAutoRecord = recordHandler.isbAutoRecord();
                                    bAlarmRecord = recordHandler.isbAlarmRecord();
                                    nFrameSize = recordHandler.getnFrameSize();
                                    isAudioEnable = recordHandler.isAudioEnable();
                                }
                                DeviceRecordSettingFragment.this.btVideotape.setChecked(bAutoRecord);
                                DeviceRecordSettingFragment.this.btAlarmVideo.setChecked(bAlarmRecord);
                                if (DeviceRecordSettingFragment.this.mServerInfo != null) {
                                    DeviceRecordSettingFragment.this.nID = DeviceRecordSettingFragment.this.mServerInfo.getnID();
                                } else {
                                    DeviceRecordSettingFragment.this.nID = -1;
                                }
                                LocalDefines._objRecordConfig.setbAutoRecord(bAutoRecord);
                                LocalDefines._objRecordConfig.setbAlarmRecord(bAlarmRecord);
                                LocalDefines._objRecordConfig.setnFullRecordOP(bFullRecordOP);
                                LocalDefines._objRecordConfig.setAudioEnable(isAudioEnable);
                                LocalDefines._objRecordConfig.setnFrameSize(nFrameSize);
                                DeviceRecordSettingFragment.this.lFreshTime = System.currentTimeMillis();
                            }
                            DeviceRecordSettingFragment.this.onSaveAndBack(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_ok), Constants.MAIN_VERSION_TAG);
                            return;
                        default:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            return;
                    }
                } else if (msg.arg1 == 80) {
                    DeviceRecordSettingFragment.this.loadingDialog.dismiss();
                    DeviceRecordSettingFragment.this.btnRecordSave.setEnabled(true);
                    DeviceRecordSettingFragment.this.tvRecordNotice.setVisibility(0);
                    DeviceRecordSettingFragment.this.tvRecordNotice.setText(DeviceRecordSettingFragment.this.getString(C0470R.string.getting_record_config_fail));
                    DeviceRecordSettingFragment.this.contentView.findViewById(C0470R.id.layoutRecordConfigPanel).setEnabled(false);
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            DeviceRecordSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            DeviceRecordSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            DeviceRecordSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            DeviceRecordSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_NetError));
                            DeviceRecordSettingFragment.this.ShowConfigSetting();
                            return;
                        case 256:
                            DeviceRecordSettingFragment.this.isGetFinish = true;
                            DeviceRecordSettingFragment.this.btnRecordSave.setEnabled(true);
                            DeviceRecordSettingFragment.this.tvRecordNotice.setVisibility(8);
                            DeviceRecordSettingFragment.this.tvRecordNotice.setText(DeviceRecordSettingFragment.this.getString(C0470R.string.getting_record_config));
                            DeviceRecordSettingFragment.this.contentView.findViewById(C0470R.id.layoutRecordConfigPanel).setEnabled(true);
                            data = msg.getData();
                            if (data == null) {
                                DeviceRecordSettingFragment.this.ShowAlert(Constants.MAIN_VERSION_TAG, DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_BadResult));
                                return;
                            }
                            DeviceRecordSettingFragment.this.lFreshTime = System.currentTimeMillis();
                            recordHandler = (RecordInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                            if (recordHandler != null) {
                                bFullRecordOP = recordHandler.getnFullRecordOP();
                                bAutoRecord = recordHandler.isbAutoRecord();
                                bAlarmRecord = recordHandler.isbAlarmRecord();
                                nDiskSize = recordHandler.getnDiskSize();
                                nDiskRemain = recordHandler.getnDiskRemainSize();
                                nFrameSize = recordHandler.getnFrameSize();
                                isAudioEnable = recordHandler.isAudioEnable();
                                is1080pEnable = recordHandler.isIs1080PEnable();
                                is720Enable = recordHandler.isIs720Enable();
                                isD1Enable = recordHandler.isD1Enable();
                                isVGAEnable = recordHandler.isVGAEnable();
                                isCIFEnable = recordHandler.isCIFEnable();
                                isQVGAEnable = recordHandler.isQVGAEnable();
                                isQCIFEnable = recordHandler.isQCIFEnable();
                                is960pEnable = recordHandler.isIs960PEnable();
                                nRecordStat = recordHandler.getnRecordStat();
                            }
                            DeviceRecordSettingFragment.this.btVideotape.setChecked(bAutoRecord);
                            DeviceRecordSettingFragment.this.btAlarmVideo.setChecked(bAlarmRecord);
                            if (DeviceRecordSettingFragment.this.mServerInfo != null) {
                                DeviceRecordSettingFragment.this.nID = DeviceRecordSettingFragment.this.mServerInfo.getnID();
                            } else {
                                DeviceRecordSettingFragment.this.nID = -1;
                            }
                            LocalDefines._objRecordConfig.setbAutoRecord(bAutoRecord);
                            LocalDefines._objRecordConfig.setbAlarmRecord(bAlarmRecord);
                            LocalDefines._objRecordConfig.setnFullRecordOP(bFullRecordOP);
                            LocalDefines._objRecordConfig.setnDiskSize(nDiskSize);
                            LocalDefines._objRecordConfig.setnDiskRemainSize(nDiskRemain);
                            LocalDefines._objRecordConfig.setnRecordStat(nRecordStat);
                            if (is1080pEnable || is720Enable || isD1Enable || isVGAEnable || isCIFEnable || isQVGAEnable || isQCIFEnable) {
                                LocalDefines._objRecordConfig.setNewVersion(true);
                            } else {
                                LocalDefines._objRecordConfig.setNewVersion(false);
                            }
                            LocalDefines._objRecordConfig.setAudioEnable(isAudioEnable);
                            LocalDefines._objRecordConfig.setnFrameSize(nFrameSize);
                            LocalDefines._objRecordConfig.setIs1080PEnable(is1080pEnable);
                            LocalDefines._objRecordConfig.setIs720Enable(is720Enable);
                            LocalDefines._objRecordConfig.setD1Enable(isD1Enable);
                            LocalDefines._objRecordConfig.setVGAEnable(isVGAEnable);
                            LocalDefines._objRecordConfig.setCIFEnable(isCIFEnable);
                            LocalDefines._objRecordConfig.setQVGAEnable(isQVGAEnable);
                            LocalDefines._objRecordConfig.setIs960PEnable(is960pEnable);
                            LocalDefines._objRecordConfig.setSDCardFormatting(recordHandler.isSDCardFormatting());
                            DeviceRecordSettingFragment.this.initUI();
                            return;
                        default:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_get_config_fail), DeviceRecordSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            DeviceRecordSettingFragment.this.ShowConfigSetting();
                            return;
                    }
                } else if (msg.arg1 == 1) {
                    DeviceRecordSettingFragment.this.loadingDialog.dismiss();
                    switch (msg.arg2) {
                        case -1:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_title), DeviceRecordSettingFragment.this.getString(C0470R.string.SDCardNetWordFail));
                            return;
                        case 0:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_title), DeviceRecordSettingFragment.this.getString(C0470R.string.SDCardDeviceReturnFail));
                            return;
                        case 1001:
                            DeviceRecordSettingFragment.this.ShowAlert(DeviceRecordSettingFragment.this.getString(C0470R.string.alert_title), DeviceRecordSettingFragment.this.getString(C0470R.string.SDCardSucceed));
                            return;
                        case 2001:
                            Toast.makeText(DeviceRecordSettingFragment.this.relateAtivity, DeviceRecordSettingFragment.this.getString(C0470R.string.SDCardFail), 1).show();
                            return;
                        default:
                            return;
                    }
                }
            }
        }
    }

    class C03402 implements OnCheckedChangeListener {
        C03402() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isCheck) {
            if (isCheck) {
                DeviceRecordSettingFragment.this.bVideotape = true;
            } else {
                DeviceRecordSettingFragment.this.bVideotape = false;
            }
        }
    }

    class C03413 implements OnCheckedChangeListener {
        C03413() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isCheck) {
            if (isCheck) {
                DeviceRecordSettingFragment.this.bAlarmVideo = true;
            } else {
                DeviceRecordSettingFragment.this.bAlarmVideo = false;
            }
        }
    }

    class C03424 implements OnCheckedChangeListener {
        C03424() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isCheck) {
            if (isCheck) {
                DeviceRecordSettingFragment.this.bFrequency = true;
            } else {
                DeviceRecordSettingFragment.this.bFrequency = false;
            }
        }
    }

    class C03435 implements DialogInterface.OnClickListener {
        C03435() {
        }

        public void onClick(DialogInterface dialog, int which) {
            DeviceRecordSettingFragment.this.mLoadType = 2;
            DeviceRecordSettingFragment.this.loadingDialog.show();
            if (DeviceRecordSettingFragment.this.mServerInfo != null) {
                DeviceRecordSettingFragment.this.startSDCardFormat();
            }
        }
    }

    class C03446 implements DialogInterface.OnClickListener {
        C03446() {
        }

        public void onClick(DialogInterface dialog, int which) {
        }
    }

    class C03457 implements OnShowListener {
        C03457() {
        }

        public void onShow(DialogInterface dialog) {
            ((TextView) DeviceRecordSettingFragment.this.loadingView.findViewById(C0470R.id.loginText)).setText(DeviceRecordSettingFragment.this.getString(C0470R.string.loading));
        }
    }

    class C03468 implements OnDismissListener {
        C03468() {
        }

        public void onDismiss(DialogInterface dialog) {
            DeviceRecordSettingFragment deviceRecordSettingFragment = DeviceRecordSettingFragment.this;
            deviceRecordSettingFragment.nThreadSDCareID++;
        }
    }

    private class RecordConfigThread extends Thread {
        static final int OP_TYPE_GET = 10;
        static final int OP_TYPE_SET = 11;
        DeviceInfo info;
        private boolean m_bAlarmRecord;
        private boolean m_bAutoRecord;
        private int m_isAudioEnable;
        private int m_nFrameSize;
        private int m_nFullRecordOP;
        private int nOPType;

        public RecordConfigThread(DeviceInfo info) {
            this.m_bAutoRecord = false;
            this.m_bAlarmRecord = false;
            this.m_nFullRecordOP = Defines.NV_RECORD_OP_RECORVER;
            this.m_nFrameSize = 0;
            this.m_isAudioEnable = 0;
            this.nOPType = 10;
            this.info = null;
            this.nOPType = 10;
            this.info = info;
        }

        public RecordConfigThread(boolean bAutoRecord, boolean bAlarmRecord, int nFullRecordOP, int nFrameSize, int nIsAudioEnable, DeviceInfo info) {
            this.m_bAutoRecord = false;
            this.m_bAlarmRecord = false;
            this.m_nFullRecordOP = Defines.NV_RECORD_OP_RECORVER;
            this.m_nFrameSize = 0;
            this.m_isAudioEnable = 0;
            this.nOPType = 10;
            this.info = null;
            this.nOPType = 11;
            this.m_bAutoRecord = bAutoRecord;
            this.m_bAlarmRecord = bAlarmRecord;
            this.m_nFullRecordOP = nFullRecordOP;
            this.m_nFrameSize = nFrameSize;
            this.m_isAudioEnable = nIsAudioEnable;
            this.info = info;
        }

        public void run() {
            RecordInfo deviceParam;
            Message msg;
            Bundle data;
            if (this.nOPType == 10) {
                deviceParam = DeviceRecordSetting.getRecordSetting(this.info);
                if (deviceParam != null) {
                    msg = DeviceRecordSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 80;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceRecordSettingFragment.this.handler.sendMessage(msg);
                }
            } else if (this.nOPType == 11) {
                deviceParam = DeviceRecordSetting.setRecordSetting(this.info, this.m_bAutoRecord, this.m_bAlarmRecord, this.m_nFullRecordOP, this.m_nFrameSize, this.m_isAudioEnable);
                if (deviceParam != null) {
                    msg = DeviceRecordSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 96;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceRecordSettingFragment.this.handler.sendMessage(msg);
                }
            }
        }
    }

    private class ThreadSDCard extends Thread {
        private int nSDCareID = 0;

        public ThreadSDCard(int nSDCareID) {
            this.nSDCareID = nSDCareID;
        }

        public void run() {
            int nResult = DeviceSDCardFormatSetting.setSDCardFormat(DeviceRecordSettingFragment.this.mServerInfo);
            if (this.nSDCareID == DeviceRecordSettingFragment.this.nThreadSDCareID) {
                Message msg = DeviceRecordSettingFragment.this.handler.obtainMessage();
                msg.arg1 = 1;
                msg.arg2 = nResult;
                DeviceRecordSettingFragment.this.handler.sendMessage(msg);
            }
        }
    }

    public RecordInfo getmRecordConfig() {
        if (this.isGetFinish) {
            return LocalDefines._objRecordConfig;
        }
        return null;
    }

    public void setmRecordConfig(RecordInfo recordConfig) {
        if (LocalDefines._objRecordConfig == null) {
            LocalDefines._objRecordConfig = new RecordInfo();
        }
        if (LocalDefines._objRecordConfig != null) {
            LocalDefines._objRecordConfig.setbAutoRecord(recordConfig.isbAutoRecord());
            LocalDefines._objRecordConfig.setbAlarmRecord(recordConfig.isbAlarmRecord());
            LocalDefines._objRecordConfig.setnFullRecordOP(recordConfig.getnFullRecordOP());
            LocalDefines._objRecordConfig.setnDiskSize(recordConfig.getnDiskSize());
            LocalDefines._objRecordConfig.setnDiskRemainSize(recordConfig.getnDiskRemainSize());
            LocalDefines._objRecordConfig.setNewVersion(recordConfig.isNewVersion());
            LocalDefines._objRecordConfig.setAudioEnable(recordConfig.isAudioEnable());
            LocalDefines._objRecordConfig.setnFrameSize(recordConfig.getnFrameSize());
            LocalDefines._objRecordConfig.setIs1080PEnable(recordConfig.isIs1080PEnable());
            LocalDefines._objRecordConfig.setIs720Enable(recordConfig.isIs720Enable());
            LocalDefines._objRecordConfig.setD1Enable(recordConfig.isD1Enable());
            LocalDefines._objRecordConfig.setVGAEnable(recordConfig.isVGAEnable());
            LocalDefines._objRecordConfig.setCIFEnable(recordConfig.isCIFEnable());
            LocalDefines._objRecordConfig.setQVGAEnable(recordConfig.isQVGAEnable());
            LocalDefines._objRecordConfig.setIs960PEnable(recordConfig.isIs960PEnable());
            LocalDefines._objRecordConfig.setSDCardFormatting(recordConfig.isSDCardFormatting());
        }
    }

    public DeviceRecordSettingFragment(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public boolean isGetFinish() {
        return this.isGetFinish;
    }

    public void setServerInfo(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public void setNeedFreshInterface(boolean bNeedFresh) {
        this.mIsNeedFresh = bNeedFresh;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_record_config, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        InitSubView();
        return v;
    }

    public void onStop() {
        super.onStop();
        this.relateAtivity = null;
        this.isActive = false;
        this.nThreadSDCareID++;
    }

    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.relateAtivity = getActivity();
        this.isActive = true;
    }

    private void InitSubView() {
        this.btVideotape = (CheckSwitchButton) this.contentView.findViewById(C0470R.id.btVideotape);
        this.btVideotape.setOnCheckedChangeListener(new C03402());
        this.btAlarmVideo = (CheckSwitchButton) this.contentView.findViewById(C0470R.id.btAlarmVideo);
        this.btAlarmVideo.setOnCheckedChangeListener(new C03413());
        this.btFrequency = (CheckSwitchButton) this.contentView.findViewById(C0470R.id.btFrequency);
        this.btFrequency.setOnCheckedChangeListener(new C03424());
        this.btnRecordBack = (ImageView) this.contentView.findViewById(C0470R.id.btnRecordBack);
        this.btnRecordBack.setOnClickListener(this);
        this.btnRecordSave = (Button) this.contentView.findViewById(C0470R.id.btnRecordSave);
        this.btnRecordSave.setOnClickListener(this);
        this.btnRecordSave.setEnabled(false);
        this.tvRecordNotice = (TextView) this.contentView.findViewById(C0470R.id.tvRecordNotice);
        this.tvRecordNotice.setVisibility(8);
        this.tvDiskSize = (TextView) this.contentView.findViewById(C0470R.id.tvDiskSize);
        this.tvDiskRemainSize = (TextView) this.contentView.findViewById(C0470R.id.tvDiskRemainSize);
        this.tvDiskSize.setText(getString(C0470R.string.disk_size) + " 0G");
        this.tvDiskRemainSize.setText(getString(C0470R.string.disk_use) + " 0G");
        createLoadingDialog();
        this.loayoutNewversion = (LinearLayout) this.contentView.findViewById(C0470R.id.loayoutNewversion);
        this.loayoutNewversion.setVisibility(8);
        this.ll_line = (LinearLayout) this.contentView.findViewById(C0470R.id.ll_line);
        this.ll_line.setVisibility(8);
        this.rBtnExceed = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnExceed);
        this.rBtnHigh = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnHigh);
        this.rBtnMark = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnMark);
        Drawable[] drawables1 = this.rBtnExceed.getCompoundDrawables();
        drawables1[0].setBounds(this.rBtnExceed.getPaddingLeft(), this.rBtnExceed.getPaddingTop(), this.rBtnExceed.getPaddingLeft() + LocalDefines.dip2px(this.relateAtivity, 25.0f), this.rBtnExceed.getPaddingTop() + LocalDefines.dip2px(this.relateAtivity, 25.0f));
        this.rBtnExceed.setCompoundDrawables(drawables1[0], drawables1[1], drawables1[2], drawables1[3]);
        Drawable[] drawables2 = this.rBtnHigh.getCompoundDrawables();
        drawables2[0].setBounds(this.rBtnHigh.getPaddingLeft(), this.rBtnHigh.getPaddingTop(), this.rBtnHigh.getPaddingLeft() + LocalDefines.dip2px(this.relateAtivity, 25.0f), this.rBtnHigh.getPaddingTop() + LocalDefines.dip2px(this.relateAtivity, 25.0f));
        this.rBtnHigh.setCompoundDrawables(drawables2[0], drawables2[1], drawables2[2], drawables2[3]);
        Drawable[] drawables3 = this.rBtnMark.getCompoundDrawables();
        drawables3[0].setBounds(this.rBtnMark.getPaddingLeft(), this.rBtnMark.getPaddingTop(), this.rBtnMark.getPaddingLeft() + LocalDefines.dip2px(this.relateAtivity, 25.0f), this.rBtnMark.getPaddingTop() + LocalDefines.dip2px(this.relateAtivity, 25.0f));
        this.rBtnMark.setCompoundDrawables(drawables3[0], drawables3[1], drawables3[2], drawables3[3]);
        this.rRadioGroup1 = (RadioGroup) this.contentView.findViewById(C0470R.id.rRadioGroup1);
        this.rRadioGroup1.clearCheck();
        this.btnSDCard = (Button) this.contentView.findViewById(C0470R.id.btnSDCard);
        this.btnSDCard.setOnClickListener(this);
        if (this.mServerInfo == null || !this.mIsNeedFresh) {
            initUI();
        } else {
            getRecordConfig(this.mServerInfo);
        }
    }

    private void initUI() {
        if (LocalDefines._objRecordConfig != null) {
            this.btVideotape.setChecked(LocalDefines._objRecordConfig.isbAutoRecord());
            this.btAlarmVideo.setChecked(LocalDefines._objRecordConfig.isbAlarmRecord());
            if (LocalDefines._objRecordConfig.isSDCardFormatting()) {
                this.btnSDCard.setVisibility(0);
            } else {
                this.btnSDCard.setVisibility(8);
            }
            if (LocalDefines._objRecordConfig.isNewVersion()) {
                this.loayoutNewversion.setVisibility(0);
                this.ll_line.setVisibility(0);
                this.rRadioGroup1.setOnCheckedChangeListener(null);
                this.rBtnExceed.setEnabled(LocalDefines._objRecordConfig.isIs1080PEnable());
                if (LocalDefines._objRecordConfig.isIs720Enable() || LocalDefines._objRecordConfig.isIs960PEnable()) {
                    this.rBtnHigh.setEnabled(true);
                    this.rBtnHigh.setVisibility(0);
                } else {
                    this.rBtnHigh.setEnabled(false);
                    this.rBtnHigh.setVisibility(4);
                }
                if (LocalDefines._objRecordConfig.isD1Enable() || LocalDefines._objRecordConfig.isVGAEnable() || LocalDefines._objRecordConfig.isCIFEnable() || LocalDefines._objRecordConfig.isQVGAEnable()) {
                    this.rBtnMark.setEnabled(true);
                    this.rBtnMark.setVisibility(0);
                } else {
                    this.rBtnMark.setEnabled(false);
                    this.rBtnMark.setVisibility(4);
                }
                this.rRadioGroup1.clearCheck();
                switch (LocalDefines._objRecordConfig.getnFrameSize()) {
                    case 1000:
                        this.rBtnExceed.setChecked(true);
                        break;
                    case 1001:
                        this.rBtnHigh.setChecked(true);
                        break;
                    case 1002:
                        this.rBtnMark.setChecked(true);
                        break;
                    case 1003:
                        this.rBtnMark.setChecked(true);
                        break;
                    case 1004:
                        this.rBtnMark.setChecked(true);
                        break;
                    case 1005:
                        this.rBtnMark.setChecked(true);
                        break;
                    case Defines.VIDEO_TYPE_960P /*1007*/:
                        this.rBtnHigh.setChecked(true);
                        break;
                }
                if (LocalDefines._objRecordConfig.isAudioEnable()) {
                    this.btFrequency.setChecked(true);
                } else {
                    this.btFrequency.setChecked(false);
                }
            } else {
                LocalDefines._objRecordConfig.setNewVersion(false);
                this.loayoutNewversion.setVisibility(8);
                this.ll_line.setVisibility(8);
            }
            int nRecordStat = LocalDefines._objRecordConfig.getnRecordStat();
            int nDiskSize = LocalDefines._objRecordConfig.getnDiskSize();
            int nDiskRemain = LocalDefines._objRecordConfig.getnDiskRemainSize();
            if (nRecordStat == -11) {
                this.tvDiskSize.setGravity(17);
                this.tvDiskSize.setText(getString(C0470R.string.lblNOSDCard));
                this.tvDiskRemainSize.setText(Constants.MAIN_VERSION_TAG);
                this.btnSDCard.setEnabled(false);
                this.btnSDCard.setTextColor(getResources().getColor(C0470R.color.font_color_gray));
                this.tvDiskSize.setTextColor(SupportMenu.CATEGORY_MASK);
            } else if (nRecordStat == -12) {
                this.tvDiskSize.setGravity(17);
                this.tvDiskSize.setText(getString(C0470R.string.lbSDCardWritteErr));
                this.tvDiskRemainSize.setText(Constants.MAIN_VERSION_TAG);
                this.btnSDCard.setEnabled(false);
                this.btnSDCard.setTextColor(getResources().getColor(C0470R.color.font_color_gray));
                this.tvDiskSize.setTextColor(SupportMenu.CATEGORY_MASK);
            } else {
                this.tvDiskSize.setGravity(19);
                this.tvDiskSize.setTextColor(-1);
                if (nDiskSize < 512) {
                    this.tvDiskSize.setGravity(17);
                    this.tvDiskSize.setText(getString(C0470R.string.lblNOSDCard));
                    this.tvDiskRemainSize.setText(Constants.MAIN_VERSION_TAG);
                    this.btnSDCard.setEnabled(false);
                    this.btnSDCard.setTextColor(getResources().getColor(C0470R.color.font_color_gray));
                    this.tvDiskSize.setTextColor(SupportMenu.CATEGORY_MASK);
                    return;
                }
                this.btnSDCard.setEnabled(true);
                this.btnSDCard.setTextColor(getResources().getColor(C0470R.color.font_color_blue));
                if (nDiskRemain < 0) {
                    nDiskRemain = 0;
                }
                if (nDiskRemain > nDiskSize) {
                    nDiskRemain = nDiskSize;
                }
                if (nDiskSize >= 1000) {
                    double dDiskSize = ((double) nDiskSize) / 1024.0d;
                    this.tvDiskSize.setText(getString(C0470R.string.disk_size) + " " + String.format("%.2f", new Object[]{Double.valueOf(dDiskSize)}) + "G");
                } else {
                    this.tvDiskSize.setText(getString(C0470R.string.disk_size) + " " + nDiskSize + "M");
                }
                if (nDiskRemain > 1024) {
                    double dDiskRemainSize = ((double) nDiskRemain) / 1024.0d;
                    this.tvDiskRemainSize.setText(getString(C0470R.string.disk_use) + " " + String.format("%.2f", new Object[]{Double.valueOf(dDiskRemainSize)}) + "G");
                    return;
                }
                this.tvDiskRemainSize.setText(getString(C0470R.string.disk_use) + " " + nDiskRemain + "M");
            }
        }
    }

    public void hindKeyboard() {
        if (this.relateAtivity != null) {
            try {
                InputMethodManager imm = (InputMethodManager) this.relateAtivity.getSystemService("input_method");
                if (imm != null) {
                    imm.hideSoftInputFromWindow(this.relateAtivity.getCurrentFocus().getWindowToken(), 2);
                }
            } catch (Exception e) {
            }
        }
    }

    public void ShowAlert(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowAlert(title, msg);
        }
    }

    public void onSaveAndBack(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowNotic(title, msg);
            ShowConfigSetting();
        }
    }

    public void onClick(View v) {
        int nFrameSize = 0;
        switch (v.getId()) {
            case C0470R.id.rBtnHigh:
                this.rRadioGroup1.clearCheck();
                this.rBtnHigh.setChecked(true);
                return;
            case C0470R.id.btnRecordBack:
                this.isGetFinish = false;
                ShowConfigSetting();
                return;
            case C0470R.id.rBtnExceed:
                this.rRadioGroup1.clearCheck();
                this.rBtnExceed.setChecked(true);
                return;
            case C0470R.id.rBtnMark:
                this.rRadioGroup1.clearCheck();
                this.rBtnMark.setChecked(true);
                return;
            case C0470R.id.btnSDCard:
                SDCardFormat();
                return;
            case C0470R.id.btnRecordSave:
                int nIsAudioEnable;
                boolean bAlarmRecord;
                boolean bAutoRecord;
                hindKeyboard();
                if (this.bFrequency) {
                    nIsAudioEnable = 1000;
                } else {
                    nIsAudioEnable = 1001;
                }
                if (this.bAlarmVideo) {
                    bAlarmRecord = true;
                } else {
                    bAlarmRecord = false;
                }
                if (this.bVideotape) {
                    bAutoRecord = true;
                } else {
                    bAutoRecord = false;
                }
                if (this.rBtnExceed.isChecked()) {
                    if (LocalDefines._objRecordConfig.isIs1080PEnable()) {
                        nFrameSize = 1000;
                    }
                } else if (this.rBtnHigh.isChecked()) {
                    if (LocalDefines._objRecordConfig.isIs720Enable()) {
                        nFrameSize = 1001;
                    } else if (LocalDefines._objRecordConfig.isIs960PEnable()) {
                        nFrameSize = Defines.VIDEO_TYPE_960P;
                    }
                } else if (this.rBtnMark.isChecked()) {
                    if (LocalDefines._objRecordConfig.isD1Enable()) {
                        nFrameSize = 1002;
                    } else if (LocalDefines._objRecordConfig.isVGAEnable()) {
                        nFrameSize = 1003;
                    } else if (LocalDefines._objRecordConfig.isCIFEnable()) {
                        nFrameSize = 1004;
                    } else if (LocalDefines._objRecordConfig.isQVGAEnable()) {
                        nFrameSize = 1005;
                    }
                }
                if (this.mServerInfo != null) {
                    setRecordConfig(this.mServerInfo, bAutoRecord, bAlarmRecord, Defines.NV_RECORD_OP_RECORVER, nFrameSize, nIsAudioEnable);
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void SDCardFormat() {
        View view = View.inflate(this.relateAtivity, C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.alert_title));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.SDCardALer));
        new Builder(this.relateAtivity).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_YES), new C03435()).setNegativeButton(getString(C0470R.string.alert_btn_NO), new C03446()).show();
    }

    private void ShowConfigSetting() {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ChangeFragment(15, 13, this.mServerInfo);
        }
    }

    private void getRecordConfig(DeviceInfo info) {
        if (info != null) {
            this.mLoadType = 1;
            this.loadingDialog.show();
            this.btnRecordSave.setEnabled(false);
            this.tvRecordNotice.setVisibility(0);
            this.tvRecordNotice.setText(getString(C0470R.string.getting_record_config));
            this.isGetFinish = false;
            new RecordConfigThread(info).start();
        }
    }

    private void setRecordConfig(DeviceInfo info, boolean bAutoRecord, boolean bAlarmRecord, int nFullRecordOP, int nFrameSize, int nIsAudioEnable) {
        if (info != null) {
            this.mLoadType = 2;
            this.loadingDialog.show();
            this.btnRecordSave.setEnabled(false);
            new RecordConfigThread(bAutoRecord, bAlarmRecord, nFullRecordOP, nFrameSize, nIsAudioEnable, info).start();
        }
    }

    private void startSDCardFormat() {
        this.nThreadSDCareID++;
        new ThreadSDCard(this.nThreadSDCareID).start();
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C03457());
        this.loadingDialog.setOnDismissListener(new C03468());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }
}
