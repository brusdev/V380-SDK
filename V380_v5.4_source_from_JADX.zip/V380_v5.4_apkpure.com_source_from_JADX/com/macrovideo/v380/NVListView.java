package com.macrovideo.v380;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.widget.ListView;

public class NVListView extends ListView {
    private Paint mPaint = new Paint();

    public NVListView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mPaint.setStyle(Style.STROKE);
        this.mPaint.setColor(ViewCompat.MEASURED_STATE_MASK);
    }

    public NVListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mPaint.setStyle(Style.STROKE);
        this.mPaint.setColor(ViewCompat.MEASURED_STATE_MASK);
    }

    public NVListView(Context context) {
        super(context);
        this.mPaint.setStyle(Style.STROKE);
        this.mPaint.setColor(ViewCompat.MEASURED_STATE_MASK);
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int lines = getHeight() / 40;
        for (int i = 0; i < lines; i++) {
            canvas.drawLine(0.0f, (float) (i * 40), (float) (getWidth() - 1), (float) (i * 40), this.mPaint);
        }
    }
}
