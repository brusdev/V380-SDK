package com.macrovideo.v380;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.NotificationCompat;
import android.support.v4.internal.view.SupportMenu;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.component.xlistview.XListView;
import com.macrovideo.component.xlistview.XListView.IXListViewListener;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.objects.AlarmImageResult;
import com.macrovideo.sdk.objects.ObjectAlarmMessage;
import com.macrovideo.sdk.tools.AlarmPictureGetter;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.cookie.ClientCookie;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class NVAlarmMsgListViewActivity extends Activity implements IXListViewListener, OnClickListener, OnItemClickListener {
    public static String AlarmServerRecv = LocalDefines._strAlarmServerRecv1;
    static final int HANDLE_GET_ALARM_IMAGE_LARGER = 51;
    static final int HANDLE_MESSAGE_LIST_FRESH = 48;
    static final int HANDLE_MESSAGE_LIST_GET_FROM_DATABASE = 50;
    static final int HANDLE_MESSAGE_LIST_MORE_FRESH = 49;
    static final int RESULT_CODE_FAIL = -101;
    static final int RESULT_CODE_OK = 100;
    private static final int SERVER_INDEX_COUNT = 3;
    private ImageView alarmIamgeView = null;
    private XListView alarmPullRefreshList = null;
    private ProgressBar alarmSearchingProgress = null;
    private ImageView btnAlarmListBack = null;
    private Button btnCancelImageView = null;
    private Button btnReGetAlarmMessage = null;
    private Button btnSaveAlarmImage = null;
    private View connectConctentView = null;
    private Dialog connectingDialog = null;
    AlarmMessageListViewAdapter deviceListItemAdapter = null;
    private Handler handler = new C03791();
    private View iamgeViewConctentView = null;
    private Dialog iamgeViewDialog = null;
    private boolean isImageViewShow = false;
    private ImageView ivAlarmImageMsgback;
    private ImageView lvAlarmBacktotop = null;
    int mAlarmGetTHreadID = 0;
    private int mAlarmImageHeight;
    private int mAlarmImageWidth;
    private CloseActivityReceiver mReceiver;
    int mSaveId = 0;
    private String mStrAlarmServer = null;
    private boolean m_bFinish = false;
    private boolean m_isGettingMore = false;
    private boolean m_isGettingPuase = false;
    private long m_lGetBackEndTime = 0;
    private long m_lGetBackStartTime = 0;
    private long m_lLastFreshTime = 0;
    private long m_lLastGetTime = 0;
    private int m_nDeviceID = 0;
    private int m_nID = 0;
    private int m_nMsgGetThreadID = 0;
    private int m_nMsgMoreGetThreadID = 0;
    private int m_nNewMsgCount = 0;
    private int m_nPort = 8800;
    private int m_nSaveType = 0;
    private int m_nServerType = 0;
    private String m_strDomain = "123.nvdvr.net";
    private String m_strName = "IPC127.0.0.1";
    private String m_strPassword = "1";
    private String m_strServer = "127.0.0.1";
    private String m_strUsername = "1";
    int nSelectIndex = -1;
    private ProgressBar progressBarGetingLarge = null;
    private String strAlarmTime;
    private String strDeviceID;
    private TextView tvAlarmImageID;
    private TextView tvAlarmTime;
    private TextView tvAlarmTopTitle = null;

    class C03791 extends Handler {
        C03791() {
        }

        public void handleMessage(Message msg) {
            Bundle data;
            if (msg.arg1 != 51) {
                if (msg.arg1 != 48) {
                    if (msg.arg1 != NVAlarmMsgListViewActivity.HANDLE_MESSAGE_LIST_MORE_FRESH) {
                        if (msg.arg1 != 50) {
                            if (msg.arg1 == 1001) {
                                NVAlarmMsgListViewActivity.this.connectingDialog.dismiss();
                                switch (msg.arg2) {
                                    case 256:
                                        data = msg.getData();
                                        if (data != null) {
                                            data.putInt("id", NVAlarmMsgListViewActivity.this.m_nID);
                                            data.putInt("device_id", NVAlarmMsgListViewActivity.this.m_nDeviceID);
                                            data.putString("name", NVAlarmMsgListViewActivity.this.m_strName);
                                            data.putString("server", NVAlarmMsgListViewActivity.this.m_strServer);
                                            data.putString("username", NVAlarmMsgListViewActivity.this.m_strUsername);
                                            data.putString("password", NVAlarmMsgListViewActivity.this.m_strPassword);
                                            NVAlarmMsgListViewActivity nVAlarmMsgListViewActivity = NVAlarmMsgListViewActivity.this;
                                            nVAlarmMsgListViewActivity.m_nMsgGetThreadID = nVAlarmMsgListViewActivity.m_nMsgGetThreadID + 1;
                                            NVAlarmMsgListViewActivity.this.ShowPlayActivity(data);
                                            break;
                                        }
                                        NVAlarmMsgListViewActivity.this.ShowAlert(new StringBuilder(String.valueOf(NVAlarmMsgListViewActivity.this.getString(C0470R.string.alert_title_login_failed))).append("(").append(NVAlarmMsgListViewActivity.this.getString(C0470R.string.notice_Result_BadResult)).append(")").toString(), null);
                                        return;
                                    case 4097:
                                        NVAlarmMsgListViewActivity.this.ShowAlert(new StringBuilder(String.valueOf(NVAlarmMsgListViewActivity.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(NVAlarmMsgListViewActivity.this.getString(C0470R.string.notice_Result_BadResult)).append(")").toString(), null);
                                        break;
                                    case 4098:
                                        NVAlarmMsgListViewActivity.this.ShowAlert(new StringBuilder(String.valueOf(NVAlarmMsgListViewActivity.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(NVAlarmMsgListViewActivity.this.getString(C0470R.string.notice_Result_ConnectServerFailed)).append(")").toString(), null);
                                        break;
                                    case 4099:
                                        NVAlarmMsgListViewActivity.this.ShowAlert(new StringBuilder(String.valueOf(NVAlarmMsgListViewActivity.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(NVAlarmMsgListViewActivity.this.getString(C0470R.string.notice_Result_ConnectServerFailed)).append(")").toString(), null);
                                        break;
                                    case LocalDefines.LOGIN_RESULT_CODE_FAIL_VERIFY_FAILED /*4100*/:
                                        NVAlarmMsgListViewActivity.this.ShowAlert(NVAlarmMsgListViewActivity.this.getString(C0470R.string.alert_title_login_failed), NVAlarmMsgListViewActivity.this.getString(C0470R.string.notice_Result_VerifyFailed));
                                        break;
                                    case LocalDefines.LOGIN_RESULT_CODE_FAIL_USER_NOEXIST /*4101*/:
                                        NVAlarmMsgListViewActivity.this.ShowAlert(NVAlarmMsgListViewActivity.this.getString(C0470R.string.alert_title_login_failed), NVAlarmMsgListViewActivity.this.getString(C0470R.string.notice_Result_UserNoExist));
                                        break;
                                    case LocalDefines.LOGIN_RESULT_CODE_FAIL_PWD_ERROR /*4102*/:
                                        NVAlarmMsgListViewActivity.this.ShowAlert(NVAlarmMsgListViewActivity.this.getString(C0470R.string.alert_title_login_failed), NVAlarmMsgListViewActivity.this.getString(C0470R.string.notice_Result_PWDError));
                                        break;
                                    case LocalDefines.LOGIN_RESULT_CODE_FAIL_OLD_VERSON /*4103*/:
                                        NVAlarmMsgListViewActivity.this.ShowAlert(NVAlarmMsgListViewActivity.this.getString(C0470R.string.alert_title_login_failed), NVAlarmMsgListViewActivity.this.getString(C0470R.string.notice_Result_Old_Version));
                                        break;
                                    default:
                                        NVAlarmMsgListViewActivity.this.ShowAlert(new StringBuilder(String.valueOf(NVAlarmMsgListViewActivity.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(NVAlarmMsgListViewActivity.this.getString(C0470R.string.notice_Result_ConnectServerFailed)).append(")").toString(), null);
                                        break;
                                }
                            }
                        }
                        NVAlarmMsgListViewActivity.this.m_isGettingMore = false;
                        NVAlarmMsgListViewActivity.this.GetMoreAlarmMessageFromDataBase();
                        NVAlarmMsgListViewActivity.this.alarmSearchingProgress.setVisibility(8);
                        NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopRefresh();
                        NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopLoadMore();
                        if (LocalDefines.alarmInfoListData.size() <= 0) {
                            NVAlarmMsgListViewActivity.this.tvAlarmTopTitle.setText(NVAlarmMsgListViewActivity.this.m_nDeviceID);
                        } else {
                            NVAlarmMsgListViewActivity.this.tvAlarmTopTitle.setText(NVAlarmMsgListViewActivity.this.m_nDeviceID + "(" + LocalDefines.alarmInfoListData.size() + ")");
                        }
                    } else {
                        NVAlarmMsgListViewActivity.this.m_isGettingMore = false;
                        NVAlarmMsgListViewActivity.this.updateListView(true);
                        NVAlarmMsgListViewActivity.this.alarmSearchingProgress.setVisibility(8);
                        NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopRefresh();
                        NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopLoadMore();
                        if (LocalDefines.alarmInfoListData.size() <= 0) {
                            NVAlarmMsgListViewActivity.this.tvAlarmTopTitle.setText(NVAlarmMsgListViewActivity.this.m_nDeviceID);
                        } else {
                            NVAlarmMsgListViewActivity.this.tvAlarmTopTitle.setText(NVAlarmMsgListViewActivity.this.m_nDeviceID + "(" + LocalDefines.alarmInfoListData.size() + ")");
                        }
                    }
                } else {
                    LocalDefines.B_UPDATE_LISTVIEW = true;
                    DatabaseManager.UpdateServerInfoMsgCount(NVAlarmMsgListViewActivity.this.m_nDeviceID, NVAlarmMsgListViewActivity.this.m_lLastGetTime, NVAlarmMsgListViewActivity.this.m_lLastGetTime, 0, NVAlarmMsgListViewActivity.this.m_strUsername, NVAlarmMsgListViewActivity.this.m_strPassword);
                    NVAlarmMsgListViewActivity.this.updateListView(false);
                    NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopRefresh();
                    NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopLoadMore();
                    NVAlarmMsgListViewActivity.this.alarmSearchingProgress.setVisibility(8);
                    if (LocalDefines.alarmInfoListData.size() <= 0) {
                        NVAlarmMsgListViewActivity.this.tvAlarmTopTitle.setText(NVAlarmMsgListViewActivity.this.m_nDeviceID);
                    } else {
                        NVAlarmMsgListViewActivity.this.tvAlarmTopTitle.setText(NVAlarmMsgListViewActivity.this.m_nDeviceID + "(" + LocalDefines.alarmInfoListData.size() + ")");
                    }
                }
            } else if (msg.arg2 == 100) {
                data = msg.getData();
                if (data != null) {
                    int nDevID = data.getInt("dev_id");
                    int nSaveId = data.getInt("save_id");
                    int nThreadID = data.getInt("thread_id");
                    String strUsername = data.getString("username");
                    String strPassword = data.getString("password");
                    String strAlarmImage = data.getString("str_alarm_image");
                    Bitmap image = (Bitmap) data.getParcelable("image");
                    Bitmap imageCopy = null;
                    String strAlarmCopyImage = null;
                    String p_set = data.getString("p_set");
                    if (!(p_set == null || p_set.length() <= 0 || image == null)) {
                        imageCopy = image.copy(Config.RGB_565, true);
                        Canvas canvas = new Canvas(imageCopy);
                        canvas.translate(0.0f, 0.0f);
                        Paint paint = new Paint();
                        paint.setColor(SupportMenu.CATEGORY_MASK);
                        paint.setStrokeWidth(3.0f);
                        paint.setStyle(Style.STROKE);
                        try {
                            JSONArray jSONArray = new JSONArray(p_set);
                            int i = 0;
                            while (true) {
                                if (i >= jSONArray.length()) {
                                    break;
                                }
                                JSONObject jsonObject = jSONArray.getJSONObject(i);
                                canvas.drawRect((float) jsonObject.getInt("tx"), (float) jsonObject.getInt("ty"), (float) jsonObject.getInt("bx"), (float) jsonObject.getInt("by"), paint);
                                i++;
                            }
                        } catch (JSONException e) {
                        }
                        strAlarmCopyImage = Functions.encodeBitmapToString(imageCopy);
                    }
                    if (NVAlarmMsgListViewActivity.this.m_nDeviceID == nDevID && nSaveId == NVAlarmMsgListViewActivity.this.mSaveId && NVAlarmMsgListViewActivity.this.mAlarmGetTHreadID == nThreadID) {
                        if (LocalDefines.alarmInfoListData.size() > 0 && NVAlarmMsgListViewActivity.this.nSelectIndex >= 0 && NVAlarmMsgListViewActivity.this.nSelectIndex < LocalDefines.alarmInfoListData.size()) {
                            ObjectAlarmMessage alarmMessage = (ObjectAlarmMessage) LocalDefines.alarmInfoListData.get(NVAlarmMsgListViewActivity.this.nSelectIndex);
                            if (alarmMessage != null) {
                                if (p_set == null || p_set.length() <= 0 || imageCopy == null) {
                                    alarmMessage.setImage(Functions.decodeStringtoBitmap(strAlarmImage, NVAlarmMsgListViewActivity.this.mAlarmImageWidth, NVAlarmMsgListViewActivity.this.mAlarmImageHeight));
                                    alarmMessage.setStrAlarmImage(strAlarmImage);
                                    DatabaseManager.UpdateAlarmMessageImage(alarmMessage.getImage(), alarmMessage.getnDevID(), alarmMessage.getnAlarmID(), strAlarmImage);
                                } else {
                                    alarmMessage.setImage(Functions.decodeStringtoBitmap(strAlarmCopyImage, NVAlarmMsgListViewActivity.this.mAlarmImageWidth, NVAlarmMsgListViewActivity.this.mAlarmImageHeight));
                                    alarmMessage.setStrAlarmImage(strAlarmCopyImage);
                                    DatabaseManager.UpdateAlarmMessageImage(alarmMessage.getImage(), alarmMessage.getnDevID(), alarmMessage.getnAlarmID(), strAlarmCopyImage);
                                }
                                NVAlarmMsgListViewActivity.this.strAlarmTime = alarmMessage.getStrAlarmTime();
                            }
                        }
                        if (p_set != null) {
                            try {
                                if (p_set.length() > 0 && imageCopy != null) {
                                    NVAlarmMsgListViewActivity.this.alarmIamgeView.setImageBitmap(imageCopy);
                                    NVAlarmMsgListViewActivity.this.strDeviceID = new StringBuilder(String.valueOf(nDevID)).toString();
                                    NVAlarmMsgListViewActivity.this.btnSaveAlarmImage.setEnabled(true);
                                    NVAlarmMsgListViewActivity.this.progressBarGetingLarge.setVisibility(8);
                                    NVAlarmMsgListViewActivity.this.tvAlarmImageID.setText(NVAlarmMsgListViewActivity.this.strDeviceID);
                                    NVAlarmMsgListViewActivity.this.tvAlarmTime.setText(new StringBuilder(String.valueOf(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strAlarmTime))).append(NVAlarmMsgListViewActivity.this.strAlarmTime).toString());
                                }
                            } catch (Exception e2) {
                            }
                        }
                        NVAlarmMsgListViewActivity.this.alarmIamgeView.setImageBitmap(image);
                        NVAlarmMsgListViewActivity.this.strDeviceID = new StringBuilder(String.valueOf(nDevID)).toString();
                        NVAlarmMsgListViewActivity.this.btnSaveAlarmImage.setEnabled(true);
                        NVAlarmMsgListViewActivity.this.progressBarGetingLarge.setVisibility(8);
                        NVAlarmMsgListViewActivity.this.tvAlarmImageID.setText(NVAlarmMsgListViewActivity.this.strDeviceID);
                        NVAlarmMsgListViewActivity.this.tvAlarmTime.setText(new StringBuilder(String.valueOf(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strAlarmTime))).append(NVAlarmMsgListViewActivity.this.strAlarmTime).toString());
                    }
                }
                NVAlarmMsgListViewActivity.this.deviceListItemAdapter.notifyDataSetChanged();
            }
            NVAlarmMsgListViewActivity.this.m_isGettingPuase = false;
        }
    }

    class C03802 implements DialogInterface.OnClickListener {
        C03802() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            NVAlarmMsgListViewActivity.this.setResult(-1);
        }
    }

    class C03813 implements OnShowListener {
        C03813() {
        }

        public void onShow(DialogInterface dialog) {
            ((TextView) NVAlarmMsgListViewActivity.this.connectConctentView.findViewById(C0470R.id.loginText)).setText(NVAlarmMsgListViewActivity.this.getString(C0470R.string.loading));
        }
    }

    class C03824 implements OnDismissListener {
        C03824() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class C03835 implements OnShowListener {
        C03835() {
        }

        public void onShow(DialogInterface dialog) {
            NVAlarmMsgListViewActivity.this.isImageViewShow = true;
            BitmapDrawable bitmapDrawable = (BitmapDrawable) NVAlarmMsgListViewActivity.this.alarmIamgeView.getDrawable();
            if (!(bitmapDrawable == null || bitmapDrawable.getBitmap() == null || bitmapDrawable.getBitmap().isRecycled())) {
                bitmapDrawable.getBitmap().recycle();
            }
            NVAlarmMsgListViewActivity.this.alarmIamgeView.setImageBitmap(null);
            NVAlarmMsgListViewActivity.this.tvAlarmTime.setText(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strAlarmTime));
            NVAlarmMsgListViewActivity.this.btnSaveAlarmImage.setEnabled(false);
            NVAlarmMsgListViewActivity.this.progressBarGetingLarge.setVisibility(0);
            if (NVAlarmMsgListViewActivity.this.alarmIamgeView != null && LocalDefines.alarmInfoListData.size() > 0 && NVAlarmMsgListViewActivity.this.nSelectIndex >= 0 && NVAlarmMsgListViewActivity.this.nSelectIndex < LocalDefines.alarmInfoListData.size()) {
                ObjectAlarmMessage alarmMessage = (ObjectAlarmMessage) LocalDefines.alarmInfoListData.get(NVAlarmMsgListViewActivity.this.nSelectIndex);
                if (alarmMessage == null) {
                    return;
                }
                NVAlarmMsgListViewActivity nVAlarmMsgListViewActivity;
                if (NVAlarmMsgListViewActivity.this.mSaveId != alarmMessage.getnSaveID()) {
                    NVAlarmMsgListViewActivity.this.mSaveId = alarmMessage.getnSaveID();
                    if (alarmMessage.getStrAlarmImage() == null || alarmMessage.getStrAlarmImage().length() <= 0) {
                        nVAlarmMsgListViewActivity = NVAlarmMsgListViewActivity.this;
                        nVAlarmMsgListViewActivity.mAlarmGetTHreadID++;
                        new AlarmMessageGetAlarmImageThread(NVAlarmMsgListViewActivity.this.mAlarmGetTHreadID, alarmMessage.getnDevID(), NVAlarmMsgListViewActivity.this.mSaveId, NVAlarmMsgListViewActivity.this.m_strUsername, NVAlarmMsgListViewActivity.this.m_strPassword, alarmMessage.getStrImageIp(), alarmMessage.getbHasPosition(), alarmMessage.getLSaveTime(), alarmMessage.getnAlarmLevel()).start();
                        return;
                    }
                    NVAlarmMsgListViewActivity.this.alarmIamgeView.setImageBitmap(Functions.decodeStringtoBitmap(alarmMessage.getStrAlarmImage()));
                    NVAlarmMsgListViewActivity.this.btnSaveAlarmImage.setEnabled(true);
                    NVAlarmMsgListViewActivity.this.progressBarGetingLarge.setVisibility(8);
                    NVAlarmMsgListViewActivity.this.strDeviceID = new StringBuilder(String.valueOf(alarmMessage.getnDevID())).toString();
                    NVAlarmMsgListViewActivity.this.strAlarmTime = alarmMessage.getStrAlarmTime();
                    NVAlarmMsgListViewActivity.this.tvAlarmImageID.setText(NVAlarmMsgListViewActivity.this.strDeviceID);
                    NVAlarmMsgListViewActivity.this.tvAlarmTime.setText(new StringBuilder(String.valueOf(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strAlarmTime))).append(NVAlarmMsgListViewActivity.this.strAlarmTime).toString());
                } else if (alarmMessage.getStrAlarmImage() == null || alarmMessage.getStrAlarmImage().length() <= 0) {
                    nVAlarmMsgListViewActivity = NVAlarmMsgListViewActivity.this;
                    nVAlarmMsgListViewActivity.mAlarmGetTHreadID++;
                    new AlarmMessageGetAlarmImageThread(NVAlarmMsgListViewActivity.this.mAlarmGetTHreadID, alarmMessage.getnDevID(), NVAlarmMsgListViewActivity.this.mSaveId, NVAlarmMsgListViewActivity.this.m_strUsername, NVAlarmMsgListViewActivity.this.m_strPassword, alarmMessage.getStrImageIp(), alarmMessage.getbHasPosition(), alarmMessage.getLSaveTime(), alarmMessage.getnAlarmLevel()).start();
                } else {
                    NVAlarmMsgListViewActivity.this.alarmIamgeView.setImageBitmap(Functions.decodeStringtoBitmap(alarmMessage.getStrAlarmImage()));
                    NVAlarmMsgListViewActivity.this.btnSaveAlarmImage.setEnabled(true);
                    NVAlarmMsgListViewActivity.this.progressBarGetingLarge.setVisibility(8);
                    NVAlarmMsgListViewActivity.this.strDeviceID = new StringBuilder(String.valueOf(alarmMessage.getnDevID())).toString();
                    NVAlarmMsgListViewActivity.this.strAlarmTime = alarmMessage.getStrAlarmTime();
                    NVAlarmMsgListViewActivity.this.tvAlarmImageID.setText(NVAlarmMsgListViewActivity.this.strDeviceID);
                    NVAlarmMsgListViewActivity.this.tvAlarmTime.setText(new StringBuilder(String.valueOf(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strAlarmTime))).append(NVAlarmMsgListViewActivity.this.strAlarmTime).toString());
                }
            }
        }
    }

    class C03846 implements OnDismissListener {
        C03846() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class C03857 implements OnScrollListener {
        C03857() {
        }

        public void onScrollStateChanged(AbsListView view, int scrollState) {
        }

        public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        }
    }

    class C03868 implements Comparator<ObjectAlarmMessage> {
        C03868() {
        }

        public int compare(ObjectAlarmMessage msg1, ObjectAlarmMessage msg2) {
            if (msg1 == null || msg2 == null) {
                return 0;
            }
            if (msg1.getLSaveTime() > msg2.getLSaveTime()) {
                return -1;
            }
            if (msg1.getLSaveTime() < msg2.getLSaveTime()) {
                return 1;
            }
            return 0;
        }
    }

    class C03879 implements Runnable {
        C03879() {
        }

        public void run() {
            NVAlarmMsgListViewActivity.this.alarmSearchingProgress.setVisibility(8);
            Toast.makeText(NVAlarmMsgListViewActivity.this, NVAlarmMsgListViewActivity.this.getResources().getString(C0470R.string.str_load_alarm_image_fail), 0).show();
            NVAlarmMsgListViewActivity.this.iamgeViewDialog.dismiss();
            NVAlarmMsgListViewActivity.this.isImageViewShow = false;
        }
    }

    public class AlarmMessageGetAlarmImageThread extends Thread {
        private String m_ThreadPassword = "admin";
        private String m_ThreadUsername = "admin";
        private boolean m_bHasPosition;
        private long m_lAlarmTime;
        private int m_nDeviceID = 0;
        private int m_nSaveID = 0;
        private int m_nVersion;
        private String nStrImageIp;
        private int nThreadID = 0;

        private void handleOssAlarmImageResultSuccess(AlarmImageResult a1Message, Handler handler) {
            if (a1Message != null && a1Message.getnReuslt() == 256) {
                Message msg = handler.obtainMessage();
                msg.arg1 = 51;
                msg.arg2 = 100;
                Bundle data = new Bundle();
                data.putInt("dev_id", this.m_nDeviceID);
                data.putInt("save_id", this.m_nSaveID);
                data.putInt("thread_id", this.nThreadID);
                data.putString("username", this.m_ThreadUsername);
                data.putString("password", this.m_ThreadPassword);
                data.putString("str_alarm_image", Functions.encodeBitmapToString(a1Message.getaImage()));
                data.putParcelable("image", a1Message.getaImage());
                if (a1Message.getnPCount() > 0) {
                    data.putString("p_set", a1Message.getStrPositionSet());
                }
                msg.setData(data);
                handler.sendMessage(msg);
            }
        }

        public AlarmMessageGetAlarmImageThread(int nThreadID, int nDeviceID, int nSaveID, String strUsername, String strPassword, String strImageIp, boolean hasPosition, long lAlarmTime, int nVersion) {
            this.nThreadID = nThreadID;
            this.m_nDeviceID = nDeviceID;
            this.m_nSaveID = nSaveID;
            this.m_ThreadUsername = strUsername;
            this.m_ThreadPassword = strPassword;
            this.nStrImageIp = strImageIp;
            this.m_bHasPosition = hasPosition;
            this.m_lAlarmTime = lAlarmTime;
            this.m_nVersion = nVersion;
        }

        public void run() {
            Exception e;
            JSONObject objStr;
            if (this.m_nDeviceID > 0) {
                if (this.m_nVersion == 20) {
                    ObjectAlarmMessage aMessage = new ObjectAlarmMessage(0, this.m_nSaveID, this.m_nSaveID, this.m_nDeviceID, 0, 0, Constants.MAIN_VERSION_TAG, Constants.MAIN_VERSION_TAG, this.m_lAlarmTime, Constants.MAIN_VERSION_TAG, this.nStrImageIp, this.m_bHasPosition, this.m_nVersion);
                    AlarmImageResult a1Message = AlarmPictureGetter.getAlarmPic(aMessage, this.m_ThreadUsername, this.m_ThreadPassword);
                    if (a1Message != null && a1Message.getnReuslt() == 256) {
                        handleOssAlarmImageResultSuccess(a1Message, NVAlarmMsgListViewActivity.this.handler);
                        return;
                    } else if (a1Message == null || a1Message.getnReuslt() == AlarmPictureGetter.OSS_GET_ALARM_IMAGE_CANCEL) {
                        NVAlarmMsgListViewActivity.this.runOnUiGetLargeImageFail(this.nThreadID);
                        return;
                    } else {
                        a1Message = AlarmPictureGetter.getAlarmPic(aMessage, this.m_ThreadUsername, this.m_ThreadPassword);
                        if (a1Message == null || a1Message.getnReuslt() != 256) {
                            NVAlarmMsgListViewActivity.this.runOnUiGetLargeImageFail(this.nThreadID);
                            return;
                        } else {
                            handleOssAlarmImageResultSuccess(a1Message, NVAlarmMsgListViewActivity.this.handler);
                            return;
                        }
                    }
                }
                int i;
                JSONObject jsObject = new JSONObject();
                JSONObject jSONObject = jsObject;
                jSONObject.put("dev_id", this.m_nDeviceID);
                jSONObject = jsObject;
                jSONObject.put("alarm_id", this.m_nSaveID);
                jsObject.put(ClientCookie.VERSION_ATTR, 2);
                if (this.m_ThreadUsername == null || this.m_ThreadUsername.length() <= 0) {
                    try {
                        jsObject.put("username", Constants.MAIN_VERSION_TAG);
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }
                } else {
                    jSONObject = jsObject;
                    jSONObject.put("username", this.m_ThreadUsername);
                }
                if (this.m_ThreadPassword == null || this.m_ThreadPassword.length() <= 0) {
                    jsObject.put("password", Constants.MAIN_VERSION_TAG);
                } else {
                    jSONObject = jsObject;
                    jSONObject.put("password", this.m_ThreadPassword);
                }
                if (this.m_bHasPosition) {
                    jSONObject = jsObject;
                    jSONObject.put("has_position", this.m_bHasPosition);
                    jSONObject = jsObject;
                    jSONObject.put("alarm_time", this.m_lAlarmTime);
                }
                String str = new String(Base64.encodeBase64(jsObject.toString().getBytes()));
                String requestResult = null;
                if (this.nStrImageIp != null) {
                    requestResult = Functions.GetJsonStringFromServerByHTTP(this.nStrImageIp, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_CONNECT_PICTUER_BY_ID).append(str).toString());
                }
                if (requestResult == null || requestResult.length() <= 0) {
                    for (i = 0; i < 3; i++) {
                        String server = LocalDefines.getAlarmServerByIndex(i);
                        requestResult = Functions.GetJsonStringFromServerByHTTP(server, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_CONNECT_PICTUER_BY_ID).append(str).toString());
                        if (requestResult != null && requestResult.length() > 0) {
                            NVAlarmMsgListViewActivity.this.mStrAlarmServer = server;
                            break;
                        }
                    }
                    if (requestResult == null || requestResult.length() <= 0) {
                        NVAlarmMsgListViewActivity.this.runOnUiGetLargeImageFail(this.nThreadID);
                        return;
                    }
                }
                JSONObject objStr2 = null;
                int p_count = 0;
                String p_set = Constants.MAIN_VERSION_TAG;
                if (requestResult != null) {
                    try {
                        jSONObject = new JSONObject(requestResult);
                        try {
                            int result = jSONObject.getInt("result");
                            try {
                                p_count = jSONObject.getInt("p_count");
                                if (p_count > 0) {
                                    p_set = jSONObject.getString("p_set");
                                }
                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }
                            if (result == 0) {
                                String strParam = jSONObject.getString("param");
                                String strServer = jSONObject.getString("server");
                                if (strServer != null && strParam != null) {
                                    str = new String(Base64.decodeBase64(strParam.getBytes()));
                                    jsObject.put(ClientCookie.PATH_ATTR, str);
                                    str = new String(Base64.encodeBase64(jsObject.toString().getBytes()));
                                    objStr2 = null;
                                    for (i = 0; i < 3; i++) {
                                        requestResult = Functions.GetJsonStringFromServerByHTTP(strServer, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_CONNECT_PICTUER_PATH).append(str).toString());
                                        if (requestResult != null) {
                                            objStr = null;
                                            break;
                                        }
                                    }
                                    objStr = null;
                                }
                            }
                        } catch (JSONException e3) {
                            objStr2 = jSONObject;
                            objStr = objStr2;
                            if (requestResult != null) {
                            }
                            NVAlarmMsgListViewActivity.this.runOnUiGetLargeImageFail(this.nThreadID);
                            return;
                        }
                    } catch (JSONException e4) {
                    }
                } else {
                    objStr = null;
                }
                if (requestResult != null || requestResult.length() <= 0) {
                    NVAlarmMsgListViewActivity.this.runOnUiGetLargeImageFail(this.nThreadID);
                    return;
                }
                if (objStr == null) {
                    try {
                        jSONObject = new JSONObject(requestResult);
                    } catch (Exception e5) {
                        e2 = e5;
                        objStr2 = objStr;
                        e2.printStackTrace();
                    }
                }
                objStr2 = objStr;
                if (objStr2 != null) {
                    try {
                        if (objStr2.getInt("result") == 1) {
                            String strTempImage = null;
                            try {
                                strTempImage = objStr2.getString("alarm_image");
                            } catch (Exception e22) {
                                e22.printStackTrace();
                            }
                            if (strTempImage != null) {
                                if (strTempImage.length() > 0) {
                                    Bitmap image = Functions.decodeStringtoBitmap(strTempImage);
                                    if (image == null) {
                                        NVAlarmMsgListViewActivity.this.runOnUiGetLargeImageFail(this.nThreadID);
                                        return;
                                    }
                                    Message msg = NVAlarmMsgListViewActivity.this.handler.obtainMessage();
                                    msg.arg1 = 51;
                                    msg.arg2 = 100;
                                    Bundle data = new Bundle();
                                    Bundle bundle = data;
                                    bundle.putInt("dev_id", this.m_nDeviceID);
                                    bundle = data;
                                    bundle.putInt("save_id", this.m_nSaveID);
                                    bundle = data;
                                    bundle.putInt("thread_id", this.nThreadID);
                                    bundle = data;
                                    bundle.putString("username", this.m_ThreadUsername);
                                    bundle = data;
                                    bundle.putString("password", this.m_ThreadPassword);
                                    data.putString("str_alarm_image", strTempImage);
                                    data.putParcelable("image", image);
                                    if (p_count > 0) {
                                        data.putString("p_set", p_set);
                                    }
                                    msg.setData(data);
                                    NVAlarmMsgListViewActivity.this.handler.sendMessage(msg);
                                    return;
                                }
                            }
                            NVAlarmMsgListViewActivity.this.runOnUiGetLargeImageFail(this.nThreadID);
                        }
                    } catch (Exception e6) {
                        e22 = e6;
                        e22.printStackTrace();
                    }
                }
            }
        }
    }

    public class AlarmMessageListGetMoreThread extends Thread {
        private int nThreadID = 0;

        public AlarmMessageListGetMoreThread(int nThreadID) {
            this.nThreadID = nThreadID;
        }

        public void run() {
            long lNewFreshTime = NVAlarmMsgListViewActivity.this.m_lGetBackEndTime;
            Message msg;
            if (NVAlarmMsgListViewActivity.this.m_nDeviceID > 0 || this.nThreadID != NVAlarmMsgListViewActivity.this.m_nMsgMoreGetThreadID) {
                JSONObject jsObject = new JSONObject();
                jsObject.put("from_time", NVAlarmMsgListViewActivity.this.m_lGetBackStartTime);
                jsObject.put("to_time", NVAlarmMsgListViewActivity.this.m_lGetBackEndTime);
                jsObject.put("dev_id", NVAlarmMsgListViewActivity.this.m_nDeviceID);
                jsObject.put("max_count", 10);
                if (NVAlarmMsgListViewActivity.this.m_strUsername == null || NVAlarmMsgListViewActivity.this.m_strUsername.length() <= 0) {
                    try {
                        jsObject.put("username", Constants.MAIN_VERSION_TAG);
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }
                } else {
                    jsObject.put("username", NVAlarmMsgListViewActivity.this.m_strUsername);
                }
                String str;
                String requestResult;
                int i;
                String server;
                if (NVAlarmMsgListViewActivity.this.m_strPassword == null || NVAlarmMsgListViewActivity.this.m_strPassword.length() <= 0) {
                    jsObject.put("password", Constants.MAIN_VERSION_TAG);
                    str = new String(Base64.encodeBase64(jsObject.toString().getBytes()));
                    requestResult = null;
                    if (NVAlarmMsgListViewActivity.this.mStrAlarmServer != null) {
                        requestResult = Functions.GetJsonStringFromServerByHTTP(NVAlarmMsgListViewActivity.this.mStrAlarmServer, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_ALARM_GET_MORE_MESSAGE_LIST).append(str).toString());
                    }
                    if (requestResult == null || requestResult.length() <= 0) {
                        for (i = 0; i < 3; i++) {
                            server = LocalDefines.getAlarmServerByIndex(i);
                            requestResult = Functions.GetJsonStringFromServerByHTTP(server, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_ALARM_GET_MORE_MESSAGE_LIST).append(str).toString());
                            if (requestResult == null && requestResult.length() > 0) {
                                NVAlarmMsgListViewActivity.this.mStrAlarmServer = server;
                                break;
                            }
                        }
                        if (requestResult == null || requestResult.length() <= 0) {
                            msg = NVAlarmMsgListViewActivity.this.handler.obtainMessage();
                            msg.arg1 = 50;
                            NVAlarmMsgListViewActivity.this.handler.sendMessage(msg);
                            return;
                        }
                    }
                    try {
                        JSONObject jSONObject = new JSONObject(requestResult);
                        if (jSONObject != null) {
                            int result = jSONObject.getInt("result");
                            String value = jSONObject.getString("value");
                            if (value != null && value.length() > 0) {
                                JSONArray jSONArray = new JSONArray(value);
                                int j = 0;
                                while (true) {
                                    if (j >= jSONArray.length()) {
                                        break;
                                    }
                                    JSONObject obj = (JSONObject) jSONArray.get(j);
                                    int nTempSaveId = obj.getInt("id");
                                    int nTempAlarmID = obj.getInt("alarm_id");
                                    int nTempDevID = obj.getInt("dev_id");
                                    int nTempAlarmType = obj.getInt("alarm_type");
                                    int nTempAlarmLevel = obj.getInt("version_num");
                                    String strTempAlarmContent = obj.getString("alarm_msg");
                                    String strTempAlarmTime = obj.getString("alarm_time");
                                    String strTempImage = obj.getString("alarm_image");
                                    long lTempLastFreshTime = obj.getLong("last_fresh_time");
                                    if (lTempLastFreshTime < lNewFreshTime) {
                                        lNewFreshTime = lTempLastFreshTime;
                                    }
                                    String strImageIp = null;
                                    try {
                                        strImageIp = obj.getString("ip");
                                    } catch (Exception e) {
                                    }
                                    boolean hasPosition = false;
                                    try {
                                        hasPosition = obj.getBoolean("has_position");
                                    } catch (Exception e2) {
                                    }
                                    if (DatabaseManager.isAlarmMessageExistQueryBySaveId(nTempSaveId, nTempDevID)) {
                                        NVAlarmMsgListViewActivity.this.addMessageToList(DatabaseManager.getAlarmMessageBySaveId(nTempSaveId, nTempDevID));
                                    } else {
                                        ObjectAlarmMessage aMessage = new ObjectAlarmMessage(0, nTempSaveId, nTempAlarmID, nTempDevID, nTempAlarmType, nTempAlarmLevel, strTempAlarmContent, strTempAlarmTime, lTempLastFreshTime, strTempImage, strImageIp, hasPosition);
                                        NVAlarmMsgListViewActivity.this.addMessageToList(aMessage);
                                        DatabaseManager.AddAlarmMessage(aMessage);
                                    }
                                    j++;
                                }
                            }
                        }
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (lNewFreshTime >= NVAlarmMsgListViewActivity.this.m_lGetBackEndTime || this.nThreadID != NVAlarmMsgListViewActivity.this.m_nMsgMoreGetThreadID) {
                        msg = NVAlarmMsgListViewActivity.this.handler.obtainMessage();
                        msg.arg1 = 50;
                        NVAlarmMsgListViewActivity.this.handler.sendMessage(msg);
                    } else {
                        NVAlarmMsgListViewActivity.this.m_lGetBackEndTime = lNewFreshTime;
                        msg = NVAlarmMsgListViewActivity.this.handler.obtainMessage();
                        msg.arg1 = NVAlarmMsgListViewActivity.HANDLE_MESSAGE_LIST_MORE_FRESH;
                        Bundle data = new Bundle();
                        data.putInt("dev_id", NVAlarmMsgListViewActivity.this.m_nDeviceID);
                        data.putString("username", NVAlarmMsgListViewActivity.this.m_strUsername);
                        data.putString("password", NVAlarmMsgListViewActivity.this.m_strUsername);
                        msg.setData(data);
                        NVAlarmMsgListViewActivity.this.handler.sendMessage(msg);
                    }
                    try {
                        Thread.sleep(3000);
                        return;
                    } catch (InterruptedException e4) {
                        e4.printStackTrace();
                        return;
                    }
                }
                jsObject.put("password", NVAlarmMsgListViewActivity.this.m_strPassword);
                str = new String(Base64.encodeBase64(jsObject.toString().getBytes()));
                requestResult = null;
                if (NVAlarmMsgListViewActivity.this.mStrAlarmServer != null) {
                    requestResult = Functions.GetJsonStringFromServerByHTTP(NVAlarmMsgListViewActivity.this.mStrAlarmServer, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_ALARM_GET_MORE_MESSAGE_LIST).append(str).toString());
                }
                for (i = 0; i < 3; i++) {
                    server = LocalDefines.getAlarmServerByIndex(i);
                    requestResult = Functions.GetJsonStringFromServerByHTTP(server, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_ALARM_GET_MORE_MESSAGE_LIST).append(str).toString());
                    if (requestResult == null) {
                    }
                }
                msg = NVAlarmMsgListViewActivity.this.handler.obtainMessage();
                msg.arg1 = 50;
                NVAlarmMsgListViewActivity.this.handler.sendMessage(msg);
                return;
            }
            msg = NVAlarmMsgListViewActivity.this.handler.obtainMessage();
            msg.arg1 = 50;
            NVAlarmMsgListViewActivity.this.handler.sendMessage(msg);
        }
    }

    public class AlarmMessageListGettingThread extends Thread {
        private boolean bGettingAlarmMsg = false;
        private int nThreadID = 0;

        class C03881 implements Runnable {
            C03881() {
            }

            public void run() {
                NVAlarmMsgListViewActivity.this.alarmSearchingProgress.setVisibility(8);
                NVAlarmMsgListViewActivity.this.updateListView(false);
                NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopRefresh();
                NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopLoadMore();
                Toast.makeText(NVAlarmMsgListViewActivity.this, NVAlarmMsgListViewActivity.this.getResources().getString(C0470R.string.Network_Error), 0).show();
            }
        }

        class C03892 implements Runnable {
            C03892() {
            }

            public void run() {
                NVAlarmMsgListViewActivity.this.alarmSearchingProgress.setVisibility(8);
                NVAlarmMsgListViewActivity.this.updateListView(false);
                NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopRefresh();
                NVAlarmMsgListViewActivity.this.alarmPullRefreshList.stopLoadMore();
                Toast.makeText(NVAlarmMsgListViewActivity.this, NVAlarmMsgListViewActivity.this.getResources().getString(C0470R.string.str_none_msgs), 0).show();
            }
        }

        public AlarmMessageListGettingThread(int nThreadID) {
            this.nThreadID = nThreadID;
        }

        public void StopFresh() {
            this.bGettingAlarmMsg = false;
        }

        public void StartFresh() {
            this.bGettingAlarmMsg = true;
        }

        public void run() {
            long lLastFreshTime = NVAlarmMsgListViewActivity.this.m_lLastGetTime;
            long lNewFreshTime = NVAlarmMsgListViewActivity.this.m_lLastGetTime;
            long lBackEndTime = 0;
            while (this.nThreadID == NVAlarmMsgListViewActivity.this.m_nMsgGetThreadID) {
                if (!this.bGettingAlarmMsg || NVAlarmMsgListViewActivity.this.m_isGettingMore || NVAlarmMsgListViewActivity.this.m_isGettingPuase) {
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else if (NVAlarmMsgListViewActivity.this.m_nDeviceID <= 0) {
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                } else {
                    int nRecvCount = 0;
                    JSONObject jsObject = new JSONObject();
                    jsObject.put("last_fresh_time", lLastFreshTime);
                    jsObject.put("dev_id", NVAlarmMsgListViewActivity.this.m_nDeviceID);
                    jsObject.put("max_count", 10);
                    lNewFreshTime = lLastFreshTime;
                    if (NVAlarmMsgListViewActivity.this.m_strUsername == null || NVAlarmMsgListViewActivity.this.m_strUsername.length() <= 0) {
                        try {
                            jsObject.put("username", Constants.MAIN_VERSION_TAG);
                        } catch (JSONException e1) {
                            e1.printStackTrace();
                        }
                    } else {
                        jsObject.put("username", NVAlarmMsgListViewActivity.this.m_strUsername);
                    }
                    String requestResult;
                    String str;
                    int i;
                    String server;
                    if (NVAlarmMsgListViewActivity.this.m_strPassword == null || NVAlarmMsgListViewActivity.this.m_strPassword.length() <= 0) {
                        jsObject.put("password", Constants.MAIN_VERSION_TAG);
                        requestResult = null;
                        str = new String(Base64.encodeBase64(jsObject.toString().getBytes()));
                        if (NVAlarmMsgListViewActivity.this.mStrAlarmServer != null) {
                            requestResult = Functions.GetJsonStringFromServerByHTTP(NVAlarmMsgListViewActivity.this.mStrAlarmServer, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_ALARM_GET_MESSAGE_LIST).append(str).toString());
                        }
                        if (requestResult == null || requestResult.length() <= 0) {
                            for (i = 0; i < 3; i++) {
                                server = LocalDefines.getAlarmServerByIndex(i);
                                requestResult = Functions.GetJsonStringFromServerByHTTP(server, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_ALARM_GET_MESSAGE_LIST).append(str).toString());
                                if (requestResult == null && requestResult.length() > 0) {
                                    NVAlarmMsgListViewActivity.this.mStrAlarmServer = server;
                                    break;
                                }
                            }
                            if (requestResult == null || requestResult.length() <= 0) {
                                NVAlarmMsgListViewActivity.this.runOnUiThread(new C03881());
                                return;
                            }
                        }
                        if (requestResult.contains("\"result\":0")) {
                            NVAlarmMsgListViewActivity.this.runOnUiThread(new C03892());
                            return;
                        }
                        JSONObject jSONObject = new JSONObject(requestResult);
                        if (jSONObject != null) {
                            int result = jSONObject.getInt("result");
                            String value = jSONObject.getString("value");
                            if (result > 0 && value != null && value.length() > 0) {
                                JSONArray jSONArray = new JSONArray(value);
                                int j = 0;
                                while (true) {
                                    if (j >= jSONArray.length()) {
                                        break;
                                    }
                                    JSONObject obj = (JSONObject) jSONArray.get(j);
                                    int nTempSaveId = obj.getInt("id");
                                    int nTempAlarmID = obj.getInt("alarm_id");
                                    int nTempDevID = obj.getInt("dev_id");
                                    int nTempAlarmType = obj.getInt("alarm_type");
                                    int nTempAlarmLevel = obj.getInt("version_num");
                                    String strTempAlarmContent = obj.getString("alarm_msg");
                                    String strTempAlarmTime = obj.getString("alarm_time");
                                    String strTempImage = obj.getString("alarm_image");
                                    long lTempLastFreshTime = obj.getLong("last_fresh_time");
                                    if (lTempLastFreshTime > lNewFreshTime) {
                                        lNewFreshTime = lTempLastFreshTime;
                                    }
                                    if (lBackEndTime == 0) {
                                        lBackEndTime = lTempLastFreshTime;
                                    } else if (lBackEndTime > lTempLastFreshTime) {
                                        lBackEndTime = lTempLastFreshTime;
                                    }
                                    String strImageIp = null;
                                    try {
                                        strImageIp = obj.getString("ip");
                                    } catch (Exception e22) {
                                        e22.printStackTrace();
                                    }
                                    boolean hasPosition = false;
                                    try {
                                        hasPosition = obj.getBoolean("has_position");
                                    } catch (Exception e3) {
                                        try {
                                            e3.printStackTrace();
                                        } catch (Exception e32) {
                                            e32.printStackTrace();
                                        }
                                    }
                                    ObjectAlarmMessage aMessage = new ObjectAlarmMessage(0, nTempSaveId, nTempAlarmID, nTempDevID, nTempAlarmType, nTempAlarmLevel, strTempAlarmContent, strTempAlarmTime, lTempLastFreshTime, strTempImage, strImageIp, hasPosition);
                                    nRecvCount++;
                                    NVAlarmMsgListViewActivity.this.addMessageToList(aMessage);
                                    DatabaseManager.AddAlarmMessage(aMessage);
                                    j++;
                                }
                            }
                        }
                        if (lNewFreshTime > lLastFreshTime && this.nThreadID == NVAlarmMsgListViewActivity.this.m_nMsgGetThreadID) {
                            if (lBackEndTime < NVAlarmMsgListViewActivity.this.m_lGetBackEndTime) {
                                NVAlarmMsgListViewActivity.this.m_lGetBackEndTime = lBackEndTime;
                            }
                            lLastFreshTime = lNewFreshTime;
                            NVAlarmMsgListViewActivity.this.m_lLastGetTime = lNewFreshTime;
                            NVAlarmMsgListViewActivity.this.m_lLastFreshTime = NVAlarmMsgListViewActivity.this.m_lLastGetTime;
                            Message msg = NVAlarmMsgListViewActivity.this.handler.obtainMessage();
                            msg.arg1 = 48;
                            Bundle data = new Bundle();
                            data.putInt("dev_id", NVAlarmMsgListViewActivity.this.m_nDeviceID);
                            data.putString("username", NVAlarmMsgListViewActivity.this.m_strUsername);
                            data.putString("password", NVAlarmMsgListViewActivity.this.m_strUsername);
                            data.putLong("last_fresh_time", lLastFreshTime);
                            msg.setData(data);
                            NVAlarmMsgListViewActivity.this.handler.sendMessage(msg);
                        }
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e23) {
                            e23.printStackTrace();
                        }
                        NVAlarmMsgListViewActivity nVAlarmMsgListViewActivity = NVAlarmMsgListViewActivity.this;
                        nVAlarmMsgListViewActivity.m_nMsgGetThreadID = nVAlarmMsgListViewActivity.m_nMsgGetThreadID + 1;
                    } else {
                        jsObject.put("password", NVAlarmMsgListViewActivity.this.m_strPassword);
                        requestResult = null;
                        str = new String(Base64.encodeBase64(jsObject.toString().getBytes()));
                        if (NVAlarmMsgListViewActivity.this.mStrAlarmServer != null) {
                            requestResult = Functions.GetJsonStringFromServerByHTTP(NVAlarmMsgListViewActivity.this.mStrAlarmServer, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_ALARM_GET_MESSAGE_LIST).append(str).toString());
                        }
                        for (i = 0; i < 3; i++) {
                            server = LocalDefines.getAlarmServerByIndex(i);
                            requestResult = Functions.GetJsonStringFromServerByHTTP(server, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_ALARM_GET_MESSAGE_LIST).append(str).toString());
                            if (requestResult == null) {
                            }
                        }
                        NVAlarmMsgListViewActivity.this.runOnUiThread(new C03881());
                        return;
                    }
                }
            }
        }
    }

    private class AlarmMessageListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageView btnImage;
            TextView tvAlarmMsg;
            TextView tvAlarmTime;
            TextView tvItemTips;

            private ItemViewHolder() {
            }
        }

        public AlarmMessageListViewAdapter(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.alarm_list_item, null);
                this.holder = new ItemViewHolder();
                this.holder.btnImage = (ImageView) convertView.findViewById(C0470R.id.ivAlarmImage);
                this.holder.tvAlarmTime = (TextView) convertView.findViewById(C0470R.id.ItemAlarmTime);
                this.holder.tvAlarmMsg = (TextView) convertView.findViewById(C0470R.id.ItemAlarmContent);
                this.holder.tvItemTips = (TextView) convertView.findViewById(C0470R.id.ItemTips);
                convertView.setTag(this.holder);
            }
            HashMap<String, Object> map = (HashMap) this.mAppList.get(position);
            if (map != null) {
                int nIndex = ((Integer) map.get("index")).intValue();
                if (nIndex >= 0 && nIndex < LocalDefines.alarmInfoListData.size() && LocalDefines.alarmInfoListData.size() > 0) {
                    ObjectAlarmMessage alarmMessage = (ObjectAlarmMessage) LocalDefines.alarmInfoListData.get(nIndex);
                    if (alarmMessage != null) {
                        this.holder.btnImage.setImageBitmap(alarmMessage.getImage());
                        if (alarmMessage.getImage() != null) {
                            this.holder.tvItemTips.setVisibility(4);
                        } else {
                            this.holder.tvItemTips.setVisibility(0);
                        }
                        this.holder.tvAlarmTime.setText(alarmMessage.getStrAlarmTime());
                        switch (alarmMessage.getnAlarmType()) {
                            case 100:
                                this.holder.tvAlarmMsg.setText(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strSmokeAlarm));
                                break;
                            case 200:
                                this.holder.tvAlarmMsg.setText(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strMotionAlarm));
                                break;
                            case 300:
                                this.holder.tvAlarmMsg.setText(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strPIRAlarm));
                                break;
                            case 400:
                                this.holder.tvAlarmMsg.setText(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strRKEAlarm));
                                break;
                            case 500:
                                this.holder.tvAlarmMsg.setText(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strGasAlarm));
                                break;
                            case 600:
                                this.holder.tvAlarmMsg.setText(NVAlarmMsgListViewActivity.this.getString(C0470R.string.strWarmAlarm));
                                break;
                        }
                    }
                }
            }
            return convertView;
        }
    }

    class CloseActivityReceiver extends BroadcastReceiver {
        CloseActivityReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = LocalDefines.getReceiverActionString(NVAlarmMsgListViewActivity.this);
            if (intent != null && intent.getAction().equals(action)) {
                NVAlarmMsgListViewActivity.this.stopCurrentActivityFromBroadcast();
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            this.m_bFinish = true;
            StopGetAlarmMessage();
            startActivity(new Intent(this, HomePageActivity.class));
            unRegisterReceiver();
            finish();
            overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
        }
        return false;
    }

    private void ShowAlert(String title, String msg) {
        try {
            View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
            ((TextView) view.findViewById(C0470R.id.tv_title)).setText(title);
            ((TextView) view.findViewById(C0470R.id.tv_content)).setText(msg);
            new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C03802()).show();
        } catch (Exception e) {
        }
    }

    private void createDialogs() {
        this.connectConctentView = LayoutInflater.from(this).inflate(C0470R.layout.logindialog, null);
        this.connectingDialog = new Dialog(this, C0470R.style.selectorDialog);
        this.connectingDialog.setContentView(this.connectConctentView);
        this.connectingDialog.setOnShowListener(new C03813());
        this.connectingDialog.setOnDismissListener(new C03824());
        this.iamgeViewConctentView = LayoutInflater.from(this).inflate(C0470R.layout.alarm_image_viewer, null);
        this.btnCancelImageView = (Button) this.iamgeViewConctentView.findViewById(C0470R.id.btnCancelImageView);
        this.btnSaveAlarmImage = (Button) this.iamgeViewConctentView.findViewById(C0470R.id.btnSaveAlarmImage);
        this.btnCancelImageView.setOnClickListener(this);
        this.btnSaveAlarmImage.setOnClickListener(this);
        this.tvAlarmImageID = (TextView) this.iamgeViewConctentView.findViewById(C0470R.id.tvAlarmImageID);
        this.tvAlarmImageID.setText(String.valueOf(this.m_nDeviceID));
        this.tvAlarmTime = (TextView) this.iamgeViewConctentView.findViewById(C0470R.id.tvAlarmTime);
        this.ivAlarmImageMsgback = (ImageView) this.iamgeViewConctentView.findViewById(C0470R.id.ivAlarmImageMsgback);
        this.ivAlarmImageMsgback.setOnClickListener(this);
        this.alarmIamgeView = (ImageView) this.iamgeViewConctentView.findViewById(C0470R.id.ivAlarmImageView);
        this.progressBarGetingLarge = (ProgressBar) this.iamgeViewConctentView.findViewById(C0470R.id.progressBarGetingLarge);
        this.iamgeViewDialog = new Dialog(this, C0470R.style.Dialog_Fullscreen);
        this.iamgeViewDialog.setContentView(this.iamgeViewConctentView);
        this.iamgeViewDialog.setOnShowListener(new C03835());
        this.iamgeViewDialog.setCancelable(false);
        this.iamgeViewDialog.setOnDismissListener(new C03846());
    }

    public void onPause() {
        if (this.iamgeViewDialog != null && this.iamgeViewDialog.isShowing()) {
            this.iamgeViewDialog.dismiss();
        }
        super.onPause();
    }

    public void onResume() {
        ((NotificationManager) getSystemService("notification")).cancel(257);
        this.m_bFinish = false;
        if (this.isImageViewShow && this.iamgeViewDialog != null) {
            this.iamgeViewDialog.show();
        }
        super.onResume();
    }

    public void onStop() {
        if (!this.m_bFinish) {
            Intent intent = new Intent(this, NVAlarmMsgListViewActivity.class);
            Bundle data = new Bundle();
            data.putString("name", this.m_strName);
            data.putString("server", this.m_strServer);
            data.putString(ClientCookie.DOMAIN_ATTR, this.m_strDomain);
            data.putInt(ClientCookie.PORT_ATTR, this.m_nPort);
            data.putString("username", this.m_strUsername);
            data.putString("password", this.m_strPassword);
            data.putInt("device_id", this.m_nDeviceID);
            data.putInt("id", this.m_nID);
            data.putInt("server_type", this.m_nServerType);
            data.putInt("new_msg_count", this.m_nNewMsgCount);
            data.putLong("last_fresh_time", this.m_lLastFreshTime);
            data.putLong("last_get_time", this.m_lLastGetTime);
            intent.putExtras(data);
            intent.setFlags(335544320);
            NotificationManager notiManager = (NotificationManager) getSystemService("notification");
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
            builder.setContentTitle(getString(C0470R.string.app_name)).setContentText(getString(C0470R.string.app_notice)).setTicker(getString(C0470R.string.app_name)).setWhen(System.currentTimeMillis()).setOngoing(false);
            if (VERSION.SDK_INT >= 23) {
                builder.setSmallIcon(C0470R.drawable.my_device_3);
                builder.setLargeIcon(Functions.readBitMap(this, C0470R.drawable.icon));
            } else {
                builder.setSmallIcon(C0470R.drawable.icon_1);
            }
            builder.setContentIntent(PendingIntent.getActivity(getApplicationContext(), 0, intent, 0));
            notiManager.notify(257, builder.build());
        }
        this.m_bFinish = true;
        super.onStop();
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_nvplayer_alarmmessagelist);
        DisplayMetrics outMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(outMetrics);
        this.mAlarmImageWidth = (int) ((outMetrics.density * 105.0f) + 0.5f);
        this.mAlarmImageHeight = (int) ((outMetrics.density * 80.0f) + 0.5f);
        Bundle data = getIntent().getExtras();
        registerReceiver(this);
        if (data != null) {
            this.m_strName = data.getString("name");
            this.m_strServer = data.getString("server");
            this.m_strDomain = data.getString(ClientCookie.DOMAIN_ATTR);
            this.m_nPort = data.getInt(ClientCookie.PORT_ATTR, 8800);
            this.m_strUsername = data.getString("username");
            this.m_strPassword = data.getString("password");
            this.m_nDeviceID = data.getInt("device_id");
            this.m_nID = data.getInt("id");
            this.m_nSaveType = data.getInt("save_type");
            this.m_nNewMsgCount = data.getInt("new_msg_count");
            this.m_nServerType = 101;
            if (this.m_nSaveType == Defines.SERVER_SAVE_TYPE_ADD) {
                if (Functions.isIpAddress(this.m_strServer)) {
                    this.m_nServerType = 101;
                } else {
                    if (!Functions.hasDot(this.m_strServer)) {
                        this.m_strServer += Defines.MV_DOMAIN_SUFFIX;
                    }
                    this.m_nServerType = 100;
                }
            }
            if (this.m_nID != LocalDefines._nCurrentID) {
                for (int i = 0; i < LocalDefines.alarmInfoListData.size(); i++) {
                    Bitmap bitmap = ((ObjectAlarmMessage) LocalDefines.alarmInfoListData.get(i)).getImage();
                    if (!(bitmap == null || bitmap.isRecycled())) {
                        bitmap.recycle();
                    }
                }
                LocalDefines.alarmInfoListData.clear();
                System.gc();
                LocalDefines._nCurrentID = this.m_nID;
            }
            this.m_lLastFreshTime = data.getLong("last_fresh_time");
            this.m_lLastGetTime = data.getLong("last_get_time");
            this.m_lGetBackEndTime = this.m_lLastFreshTime;
            this.m_lGetBackStartTime = this.m_lLastGetTime;
        }
        this.btnAlarmListBack = (ImageView) findViewById(C0470R.id.btnAlarmListBack);
        this.tvAlarmTopTitle = (TextView) findViewById(C0470R.id.tvAlarmTopTitle);
        this.alarmPullRefreshList = (XListView) findViewById(C0470R.id.alarmPullRefreshList);
        this.alarmSearchingProgress = (ProgressBar) findViewById(C0470R.id.alarmSearchingProgress);
        this.lvAlarmBacktotop = (ImageView) findViewById(C0470R.id.lvAlarmBacktotop);
        this.lvAlarmBacktotop.setVisibility(8);
        this.alarmPullRefreshList.setPullLoadEnable(true);
        this.alarmPullRefreshList.setPullRefreshEnable(false);
        this.alarmPullRefreshList.setXListViewListener(this);
        this.tvAlarmTopTitle.setText(this.m_nDeviceID);
        this.btnAlarmListBack.setOnClickListener(this);
        this.lvAlarmBacktotop.setOnClickListener(this);
        this.btnReGetAlarmMessage = (Button) findViewById(C0470R.id.btn_reGetAlarmMessage);
        this.btnReGetAlarmMessage.setOnClickListener(this);
        if (this.m_nNewMsgCount > 0) {
            StartGetAlarmMessage();
        } else {
            ShowAlarmMessage();
        }
        createDialogs();
    }

    protected void onDestroy() {
        super.onDestroy();
    }

    private boolean saveToSDCard(Bitmap image, String strFileName) {
        boolean bResult = false;
        if (image == null) {
            return 0;
        }
        try {
            File file = new File(Functions.GetSDPath() + File.separator + LocalDefines.SDCardPath);
            if (!file.exists()) {
                file.mkdir();
            }
            FileOutputStream out = new FileOutputStream(new File(file.getAbsolutePath() + File.separator + strFileName));
            image.compress(CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
            bResult = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return bResult;
    }

    private boolean saveAlarmImage(String strSavePath) {
        if (LocalDefines.alarmInfoListData.size() > 0 && this.nSelectIndex >= 0 && this.nSelectIndex < LocalDefines.alarmInfoListData.size()) {
            ObjectAlarmMessage alarmMessage = (ObjectAlarmMessage) LocalDefines.alarmInfoListData.get(this.nSelectIndex);
            if (alarmMessage != null) {
                Bitmap bm = Functions.decodeStringtoBitmap(alarmMessage.getStrAlarmImage());
                if (bm != null) {
                    String strFileName = Constants.MAIN_VERSION_TAG;
                    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
                    String strAlarmDate = alarmMessage.getStrAlarmTime();
                    if (strAlarmDate != null) {
                        String dateString = Constants.MAIN_VERSION_TAG;
                        try {
                            dateString = formatter.format(formatter.parse(strAlarmDate));
                        } catch (ParseException e) {
                            dateString = formatter.format(new Date());
                        }
                        strFileName = new StringBuilder(String.valueOf(dateString)).append("(").append(alarmMessage.getnDevID()).append(")").append(".jpg").toString();
                    } else {
                        strFileName = formatter.format(new Date()) + "(" + alarmMessage.getnDevID() + ")" + ".jpg";
                    }
                    if (saveToSDCard(bm, strFileName)) {
                        Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeFileSaveToAlbumsOK), 0).show();
                    } else if (saveToSDCard(bm, new StringBuilder(String.valueOf(strSavePath)).append("/").append(strFileName).toString())) {
                        Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeFileSaveOK), 0).show();
                    } else {
                        Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeFileSaveFail), 0).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeFileSaveFail), 0).show();
                }
            }
        }
        return false;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.btnAlarmListBack:
                this.m_bFinish = true;
                StopGetAlarmMessage();
                startActivity(new Intent(this, HomePageActivity.class));
                unRegisterReceiver();
                finish();
                overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                return;
            case C0470R.id.btn_reGetAlarmMessage:
                if (this.m_nNewMsgCount > 0) {
                    StartGetAlarmMessage();
                    return;
                } else {
                    ShowAlarmMessage();
                    return;
                }
            case C0470R.id.ivAlarmImageMsgback:
                this.iamgeViewDialog.dismiss();
                this.isImageViewShow = false;
                this.mAlarmGetTHreadID++;
                AlarmPictureGetter.reset();
                return;
            case C0470R.id.btnSaveAlarmImage:
                String strSavePath = Functions.GetSDPath();
                if (strSavePath == null) {
                    Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeSDCardNotExist), 0).show();
                    return;
                } else {
                    saveAlarmImage(strSavePath);
                    return;
                }
            case C0470R.id.btnCancelImageView:
                this.iamgeViewDialog.dismiss();
                this.isImageViewShow = false;
                this.mAlarmGetTHreadID++;
                AlarmPictureGetter.reset();
                return;
            default:
                return;
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        this.nSelectIndex = position - 1;
        this.iamgeViewDialog.show();
    }

    private void StartGetMoreAlarmMessage() {
        this.m_nMsgMoreGetThreadID++;
        this.m_isGettingMore = true;
        new AlarmMessageListGetMoreThread(this.m_nMsgMoreGetThreadID).start();
    }

    private void ShowAlarmMessage() {
        if (this.deviceListItemAdapter == null) {
            updateListView(false);
        } else {
            this.deviceListItemAdapter.notifyDataSetChanged();
        }
        this.m_nMsgGetThreadID++;
        this.alarmSearchingProgress.setVisibility(0);
        AlarmMessageListGettingThread alarmPictureGettingThread = new AlarmMessageListGettingThread(this.m_nMsgGetThreadID);
        alarmPictureGettingThread.StartFresh();
        alarmPictureGettingThread.start();
    }

    private void GetMoreAlarmMessageFromDataBase() {
        ObjectAlarmMessage[] array = DatabaseManager.GetAlarmMessage(this.m_nDeviceID, 10, 0, this.m_lGetBackEndTime);
        if (array != null && array.length > 0) {
            for (ObjectAlarmMessage aMessage : array) {
                for (int j = 0; j < LocalDefines.alarmInfoListData.size(); j++) {
                    if (((ObjectAlarmMessage) LocalDefines.alarmInfoListData.get(j)).getnSaveID() == aMessage.getnSaveID()) {
                        break;
                    }
                }
                addMessageToList(aMessage);
            }
            this.m_lGetBackEndTime = array[array.length - 1].getLSaveTime();
            updateListView(true);
        }
    }

    private void StartGetAlarmMessage() {
        this.m_nMsgGetThreadID++;
        this.alarmSearchingProgress.setVisibility(0);
        AlarmMessageListGettingThread alarmPictureGettingThread = new AlarmMessageListGettingThread(this.m_nMsgGetThreadID);
        alarmPictureGettingThread.StartFresh();
        alarmPictureGettingThread.start();
    }

    private void StopGetAlarmMessage() {
        this.alarmSearchingProgress.setVisibility(8);
        this.m_nMsgGetThreadID++;
    }

    public void updateListView(boolean flag) {
        if (LocalDefines.alarmInfoListData.size() <= 0) {
            this.tvAlarmTopTitle.setText(this.m_nDeviceID);
        } else {
            this.tvAlarmTopTitle.setText(this.m_nDeviceID + "(" + LocalDefines.alarmInfoListData.size() + ")");
        }
        if (LocalDefines.alarmInfoListData != null) {
            sortAlarmList();
            ArrayList<HashMap<String, Object>> listItem = new ArrayList();
            for (int i = 0; i < LocalDefines.alarmInfoListData.size(); i++) {
                ObjectAlarmMessage alarmMessage = (ObjectAlarmMessage) LocalDefines.alarmInfoListData.get(i);
                HashMap<String, Object> map = new HashMap();
                map.put("index", Integer.valueOf(i));
                map.put("alarm_id", Integer.valueOf(alarmMessage.getnAlarmID()));
                map.put("dev_id", Integer.valueOf(alarmMessage.getnDevID()));
                listItem.add(map);
            }
            this.deviceListItemAdapter = new AlarmMessageListViewAdapter(this, listItem, C0470R.layout.server_list_item, new String[]{"ItemImage", "ItemAlarmTime", "ItemAlarmType", "ItemTips"}, new int[]{C0470R.id.ivAlarmImage, C0470R.id.ItemAlarmTime, C0470R.id.ItemAlarmContent, C0470R.id.ItemTips});
            setListviewOnScrollListener();
            if (this.alarmPullRefreshList != null) {
                this.alarmPullRefreshList.setCacheColorHint(0);
                this.alarmPullRefreshList.setAdapter(this.deviceListItemAdapter);
                this.alarmPullRefreshList.setOnItemClickListener(this);
            }
            if (flag && LocalDefines.alarmInfoListData.size() > 0) {
                this.alarmPullRefreshList.setSelection(LocalDefines.alarmInfoListData.size() - 1);
                return;
            }
            return;
        }
        setListviewOnScrollListener();
        if (this.alarmPullRefreshList != null) {
            this.alarmPullRefreshList.setAdapter(null);
            this.deviceListItemAdapter = null;
        }
    }

    private void setListviewOnScrollListener() {
        if (this.alarmPullRefreshList != null) {
            this.alarmPullRefreshList.setOnScrollListener(new C03857());
        }
    }

    private void ShowPlayActivity(Bundle data) {
        Intent intent = new Intent(this, NVPlayerPlayActivity.class);
        intent.putExtras(data);
        startActivity(intent);
        overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
        finish();
    }

    public void addMessageToList(ObjectAlarmMessage aMessage) {
        LocalDefines.alarmInfoListData.add(0, aMessage);
    }

    private void sortAlarmList() {
        Collections.sort(LocalDefines.alarmInfoListData, new C03868());
    }

    public void onRefresh() {
    }

    public void onLoadMore() {
        if (!this.m_isGettingMore) {
            StartGetMoreAlarmMessage();
        }
    }

    private void registerReceiver(Context context) {
        IntentFilter filter = new IntentFilter();
        filter.addAction(LocalDefines.getReceiverActionString(context));
        this.mReceiver = new CloseActivityReceiver();
        registerReceiver(this.mReceiver, filter);
    }

    private void unRegisterReceiver() {
        if (this.mReceiver != null) {
            unregisterReceiver(this.mReceiver);
        }
    }

    private void stopCurrentActivityFromBroadcast() {
        if (this.iamgeViewDialog != null && this.iamgeViewDialog.isShowing()) {
            this.iamgeViewDialog.dismiss();
        }
        this.m_bFinish = true;
        StopGetAlarmMessage();
        unRegisterReceiver();
        finish();
    }

    private void runOnUiGetLargeImageFail(int nThreadId) {
        if (this.mAlarmGetTHreadID == nThreadId) {
            runOnUiThread(new C03879());
        }
    }
}
