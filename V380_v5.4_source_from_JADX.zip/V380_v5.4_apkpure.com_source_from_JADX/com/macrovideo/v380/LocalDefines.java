package com.macrovideo.v380;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.SoundPool;
import android.net.wifi.WifiManager;
import android.os.Vibrator;
import android.util.Log;
import com.macrovideo.photo.PhotoViewAttacher;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.custom.RecordFileInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrovideo.sdk.objects.ObjectAlarmMessage;
import com.macrovideo.sdk.objects.PTZXPoint;
import com.macrovideo.sdk.setting.AlarmAndPromptInfo;
import com.macrovideo.sdk.setting.RecordInfo;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LocalDefines {
    public static final int AD_APP_ID = 1001;
    public static final String AD_GET_TIME = "AD_GET_TIME";
    public static final String AD_ID = "AD_ID";
    public static final String AD_MS_ID = "AD_MS_ID";
    public static final String AD_SHOW_ALREADY = "AD_SHOW_ALREADY";
    public static final String AD_SHOW_DURATION = "AD_SHOW_DURATION";
    public static final String AD_SHOW_FREQUENCY = "AD_SHOW_FREQUENCY";
    public static String ALARM_DEVICE_LOGIN = "alarmDeviceLogin";
    public static final int ALARM_DEVICE_SEARCH_OFF = 101;
    public static final int ALARM_DEVICE_SEARCH_ON = 100;
    public static final int ALARM_FALLURE = 1;
    public static final int ALARM_LEVEL_H = 3;
    public static final int ALARM_LEVEL_L = 1;
    public static final int ALARM_LEVEL_M = 2;
    public static final int ALARM_MODEL_315 = 315;
    public static final int ALARM_MODEL_433 = 433;
    public static final int ALARM_MSG_TYPE_ACCESS_CTRL = 400;
    public static final int ALARM_MSG_TYPE_GAS = 500;
    public static final int ALARM_MSG_TYPE_MOTION = 200;
    public static final int ALARM_MSG_TYPE_PIR = 300;
    public static final int ALARM_MSG_TYPE_SMOG = 100;
    public static final int ALARM_MSG_TYPE_UNDIFINED = 111;
    public static final int ALARM_MSG_TYPE_WARM = 600;
    public static String ALARM_SETTINGS = "alarm_settings_sharedpreference";
    public static String ALARM_SHAKE = "alarm_shake";
    public static String ALARM_SOUND = "alarm_sound";
    public static final int ALARM_SUCCESS = 0;
    public static String ANDROID_APP_NAME = "V380";
    public static int APP_ID_ICAMSEE = ResultCode.NV_RESULT_DESC_NO_USER;
    public static int APP_ID_ICAMSEE2 = 1021;
    public static int APP_ID_V380 = 1120;
    public static int APP_UPDATE_RESULT = 2221;
    public static int APP_UPDATE_RESULT_HAS_NEW = 2;
    public static int APP_UPDATE_RESULT_NO_NEW = 1;
    public static final String APP_VERSION = "app_version";
    public static final byte AuthModeOpen = (byte) 0;
    public static final byte AuthModeWEPOPEN = (byte) 1;
    public static final byte AuthModeWEPSHARE = (byte) 2;
    public static final byte AuthModeWPA1EAPWPA2EAP = (byte) 5;
    public static final byte AuthModeWPA1PSKWPA2PSKAES = (byte) 12;
    public static final byte AuthModeWPA1PSKWPA2PSKTKIP = (byte) 13;
    public static final byte AuthModeWPA1PSKWPA2PSKTKIPAES = (byte) 14;
    public static final byte AuthModeWPA2EAP = (byte) 4;
    public static final byte AuthModeWPA2PSKAES = (byte) 9;
    public static final byte AuthModeWPA2PSKTKIP = (byte) 10;
    public static final byte AuthModeWPA2PSKTKIPAES = (byte) 11;
    public static final byte AuthModeWPAEAP = (byte) 3;
    public static final byte AuthModeWPAPSKAES = (byte) 6;
    public static final byte AuthModeWPAPSKTKIP = (byte) 7;
    public static final byte AuthModeWPAPSKTKIPAES = (byte) 8;
    public static final int BIND_DEVICE_RESULT_CODE = 800;
    public static boolean B_ALTER_PASSWORD = false;
    public static boolean B_CREATE_PASSWORD = false;
    public static boolean B_DELETE_PASSWORD = false;
    public static boolean B_INTENT_ACTIVITY = false;
    public static boolean B_OFF_PASSWORD = false;
    public static boolean B_TESTING_PASSWORD = false;
    public static boolean B_UPDATE_LISTVIEW = true;
    public static final int CAMTYPE_CEIL = 2;
    public static final int CAMTYPE_WALL = 1;
    public static final String CLOUD_STORE_URL = "http://www.av380.net/site/login?access_token=";
    public static final int CMD_MR_GET_IMAGE = 1003;
    public static final int CMD_MR_LOGIN = 1001;
    public static final int CMD_MR_LOGIN_RESPONSE = 2001;
    public static final int CMD_MR_PLAY = 1002;
    public static final int CMD_MR_PLAY_RESPONSE = 2002;
    public static final int CRITICAL = 300;
    public static final int CUSTOMBUF = 254;
    public static int CanSetTime = 1;
    public static final int DEVICE_ACCESS_CTRL = 1;
    public static final int DEVICE_GAS = 3;
    public static final int DEVICE_IP_UPDATE = 1002;
    public static String DEVICE_MESSAGE_RECEIVE = "alarmMessageReceive";
    public static DeviceInfo DEVICE_MSG = null;
    public static final int DEVICE_OTHER = 0;
    public static final int DEVICE_SEARCH_RESULT = 1001;
    public static final int DEVICE_SEARCH_RESULT_FAIL = 102;
    public static final int DEVICE_SEARCH_RESULT_OK = 101;
    public static final int DEVICE_SMOKE_FEELING = 2;
    public static final int DEVICE_SOUND_WAVE_END = 1003;
    public static final int DEVICE_WARM_FEELING = 4;
    public static final int DISCONNECT = 253;
    public static final int DOWNREQUEST = 100;
    public static LoginHandle Device_LoginHandle = null;
    public static String DownAPPDir = "v380_download";
    public static String DownAPPName = "v380.apk";
    public static final int EXALARMMODE_EXTERNAL = 10;
    public static final int EXALARMMODE_INTERNAL = 11;
    public static final int EXALARMMODE_MANUALOFF = 12;
    public static final int EXALARMMODE_MANUALON = 13;
    public static final int FILEDATA = 112;
    public static final int FILEDATAEND = 111;
    public static final int FILEERROR = 113;
    public static final int FILESTART = 110;
    static final int FILE_TYPE_ALARM = 3;
    static final int FILE_TYPE_ALL = 0;
    static final int FILE_TYPE_MOTION = 2;
    static final int FILE_TYPE_NORMAL = 1;
    public static final int FIXTYPE_CEIL = 0;
    public static final int FIXTYPE_WALL = 1;
    public static final int HANDLE_MSG_CODE_LOGIN_RESULT = 16;
    public static final int HANDLE_MSG_CODE_WIFI_SEARCH_RESULT = 32;
    public static final int HANDLE_SHOW_WINDOW_ADD = 273;
    public static boolean HAS_NEW_MSG = false;
    public static final String IS_FIRST_IN = "isFirstIn";
    public static boolean IsSoftwareOpen = false;
    public static boolean IsSoftwareRunning = false;
    public static final String JSP_SERVER_ALARM_GET_MESSAGE_LIST = "/GetAlarmMsg/AlarmGetMessageList?param=";
    public static final String JSP_SERVER_ALARM_GET_MORE_MESSAGE_LIST = "/GetAlarmMsg/AlarmGetMessageListWithCondition?param=";
    public static final String JSP_SERVER_CONNECT_MSG = "/GetAlarmMsg/AlarmSelectServletMsg?param=";
    public static final String JSP_SERVER_CONNECT_PICTUER_BY_ID = "/GetAlarmMsg/AlarmGetPictureByID?param=";
    public static final String JSP_SERVER_CONNECT_PICTUER_PATH = "/GetAlarmMsg/AlarmGetPictureByPath?param=";
    public static final String JSP_SERVER_CONNECT_PICTUER_PREVIEW = "/GetAlarmMsg/PreviewSelectServletDeviceInfo?param=";
    public static final String JSP_SERVER_CONNECT_PICTUER_PREVIEW_DEFAULT = "/GetPreviewServer/PreviewSelectServletDeviceInfo?param=";
    public static final String JSP_SERVER_CONNECT_PICTUER_TOP_NEW = "/GetAlarmMsg/AlarmSelectServletTopNewPicture?param=";
    public static final String JSP_SERVER_CONNECT_PICTURE = "/GetAlarmMsg/AlarmSelectServletPicture?param=";
    public static final String JSP_SERVER_CONNECT_PICTURE_CONDITION = "/GetAlarmMsg/AlarmSelectServletPictureCondition?param=";
    public static final String JSP_SERVER_CONNECT_PICTURE_LARGE = "/GetAlarmMsg/AlarmSelectServletPictureByID?param=";
    public static final String JSP_SERVER_REGIST_CLIENT = "/GetAlarmMsg/XGPhoneClientRegistered?param=";
    public static final String JSP_SERVER_SET_DEVICE_ALARM = "/GetAlarmMsg/ClientWithDeivceRegistered?param=";
    public static final String JSP_SERVER_SET_DEVICE_ARRAY_ALARM = "/GetAlarmMsg/ClientWithDeivceArrayRegistered?param=";
    public static final String JSP_SERVER_SOFTWARE_UPDATE = "/AppManage/UpdateSelectServletAppVersionCheck?param=";
    public static final int LIST_MODE_CONFIG = 203;
    public static final int LIST_MODE_DEMONSTRATE = 204;
    public static final int LIST_MODE_EDIT = 201;
    public static final int LIST_MODE_NORMAL = 200;
    public static final int LIST_MODE_SEARCHING = 202;
    public static final int LOGIN_RESULT_CODE_FAIL_NET_DOWN = 4097;
    public static final int LOGIN_RESULT_CODE_FAIL_NET_POOL = 4098;
    public static final int LOGIN_RESULT_CODE_FAIL_OLD_VERSON = 4103;
    public static final int LOGIN_RESULT_CODE_FAIL_PWD_ERROR = 4102;
    public static final int LOGIN_RESULT_CODE_FAIL_SERVER_OFFLINE = 4099;
    public static final int LOGIN_RESULT_CODE_FAIL_USER_NOEXIST = 4101;
    public static final int LOGIN_RESULT_CODE_FAIL_VERIFY_FAILED = 4100;
    public static final int LOGIN_RESULT_CODE_SUCCESS = 1;
    public static ArrayList<Integer> LocalAlarmAreaList = new ArrayList();
    public static Map<Integer, ArrayList<Integer>> Localmap_Select_area = new HashMap();
    public static Map<Integer, Boolean> Localmap_Update_area = new HashMap();
    public static final int MAJOR = 400;
    public static final int MINOR = 500;
    public static String MSG = "MSG";
    public static String MSG_TITLE = "MSG_TITLE";
    static final String MV_DOMAIN_SUFFIX = ".nvdvr.net";
    public static final int NOTICE = 600;
    public static final int NV_DEVICE_NET_STATE_ONLINE = 1200;
    public static final int NV_IPC_ONLINE_CHECK_OFFLINE = 0;
    public static final int NV_IPC_ONLINE_CHECK_ONLINE = 1;
    public static final int NV_IPC_ONLINE_CHECK_REQUEST = 172;
    public static final int NV_IPC_ONLINE_CHECK_RESPONSE = 272;
    public static final int NV_IPC_ONLINE_CHECK_UNKNOWN = 10;
    public static final int NV_IPC_REMOTE_GET_REQUEST = 880;
    public static final int NV_IPC_REMOTE_SET_REQUEST = 881;
    public static final int NV_IP_ALARM_DEVICE_ADD_REQUEST = 132;
    public static final int NV_IP_ALARM_DEVICE_ADD_RESPONSE = 232;
    public static final int NV_IP_ALARM_DEVICE_DELETE_REQUEST = 134;
    public static final int NV_IP_ALARM_DEVICE_DELETE_RESPONSE = 234;
    public static final int NV_IP_ALARM_DEVICE_LIST_REQUEST = 130;
    public static final int NV_IP_ALARM_DEVICE_LIST_RESPONSE = 230;
    public static final int NV_IP_ALARM_DEVICE_MODIFY_REQUEST = 133;
    public static final int NV_IP_ALARM_DEVICE_MODIFY_RESPONSE = 233;
    public static final int NV_IP_ALARM_DEVICE_SEARCH_REQUEST = 131;
    public static final int NV_IP_ALARM_DEVICE_SEARCH_RESPONSE = 231;
    public static final int NV_LANGUAGE_CN = 1000;
    public static final int NV_LANGUAGE_EN = 1100;
    public static final int NV_RESULT_FAILED = 2001;
    public static final int NV_RESULT_SUCCEED = 1001;
    public static final int NV_WIFI_MODE_ALL = 1003;
    public static final int NV_WIFI_MODE_AP = 1001;
    public static final int NV_WIFI_MODE_STATION = 1002;
    public static final int NV_WIFI_MODE_UNKNOW = 0;
    public static final int ON_LINE_STAT_LAN = 101;
    public static final int ON_LINE_STAT_OFF = 100;
    public static final int ON_LINE_STAT_READY = 0;
    public static final int ON_LINE_STAT_UNKNOW = -1;
    public static final int ON_LINE_STAT_WAN = 102;
    public static final int OS_PHONE_TYPE = 1002;
    static final int PAGE_INDEX_ADDDEVICE = 11;
    static final int PAGE_INDEX_CONFIG = 13;
    static final int PAGE_INDEX_CONFIG_ACOUNT = 17;
    static final int PAGE_INDEX_CONFIG_ALARMANDPROMPT = 19;
    static final int PAGE_INDEX_CONFIG_DATETIME = 16;
    static final int PAGE_INDEX_CONFIG_NETWORK = 14;
    static final int PAGE_INDEX_CONFIG_RECORD = 15;
    static final int PAGE_INDEX_CONFIG_STATIC_IP = 20;
    static final int PAGE_INDEX_CONFIG_VERSION = 18;
    static final int PAGE_INDEX_MODIFYDEVICE = 12;
    static final int PAGE_INDEX_SERVERLIST = 10;
    public static boolean PLAY_BACK_BACK = false;
    public static String PUSH_ID = "pushId";
    public static String PUSH_MSG = "pushMsg";
    public static String PUSH_RECEIVER = "com.macrovideo.update.push";
    public static String PUSH_TIME = "pushTime";
    public static String PUSH_TITLE = "pushTitle";
    public static String PUSH_TYPE = "pushType";
    static final int RADIO_INDEX_HELP = 103;
    static final int RADIO_INDEX_HOME = 100;
    static final int RADIO_INDEX_PIECTURE = 101;
    static final int RADIO_INDEX_PLAYBACK = 102;
    public static final int RECORD_STAT_NO_SDCARD = -11;
    public static final int RECORD_STAT_RUN_OK = 10;
    public static final int RECORD_STAT_SDCARD_WRITE_ERR = -12;
    public static final int RECORD_STAT_UNKOWN = 0;
    public static String RECV_ALARM_MSG = "recv_msg";
    public static final int REC_FILE_SEARCH_RESULT_CODE_FAIL_NET_DOWN = -4113;
    public static final int REC_FILE_SEARCH_RESULT_CODE_FAIL_NET_POOL = -4114;
    public static final int REC_FILE_SEARCH_RESULT_CODE_FAIL_OLD_VERSON = -4119;
    public static final int REC_FILE_SEARCH_RESULT_CODE_FAIL_PWD_ERROR = -4118;
    public static final int REC_FILE_SEARCH_RESULT_CODE_FAIL_SERVER_OFFLINE = -4115;
    public static final int REC_FILE_SEARCH_RESULT_CODE_FAIL_USER_NOEXIST = -4117;
    public static final int REC_FILE_SEARCH_RESULT_CODE_FAIL_VERIFY_FAILED = -4116;
    public static final int REC_FILE_SEARCH_RESULT_CODE_SUCCESS = 17;
    public static String SDCardPath = "hongshi";
    public static int SERVER_SAVE_TYPE_ADD = ResultCode.NV_RESULT_DESC_NO_USER;
    public static int SERVER_SAVE_TYPE_DEMO = ResultCode.NV_RESULT_DESC_NO_PRI;
    public static int SERVER_SAVE_TYPE_SEARCH = ResultCode.NV_RESULT_DESC_PWD_ERR;
    static final int SERVER_TYPE_DOMAIN = 100;
    static final int SERVER_TYPE_IP = 101;
    public static boolean SOFTWARE_PASSWORD_OPEN = false;
    public static String SOFTWARE_PASSWORD_STATE = "software_password_state";
    public static String SOUND_SHAKE_STORE_NAME = "ShoundShake";
    static final int STOPDOWN = 101;
    static final int STOPUPLOAD = 103;
    public static ArrayList<Integer> ServerAlarmAreaList = new ArrayList();
    public static int ServerAlarmSwitch1 = 0;
    public static int ServerAlarmSwitch2 = 0;
    public static int ServerAlarmSwitch3 = 0;
    public static ArrayList<Integer> ServerEndHour = new ArrayList();
    public static ArrayList<String> ServerEndHour_Str = new ArrayList();
    public static ArrayList<Integer> ServerEndMin = new ArrayList();
    public static ArrayList<String> ServerEndMin_Str = new ArrayList();
    public static ArrayList<Integer> ServerEndSec = new ArrayList();
    public static ArrayList<String> ServerEndSec_Str = new ArrayList();
    public static ArrayList<String> ServerEndTime_Str = new ArrayList();
    public static ArrayList<Integer> ServerStartHour = new ArrayList();
    public static ArrayList<String> ServerStartHour_Str = new ArrayList();
    public static ArrayList<Integer> ServerStartMin = new ArrayList();
    public static ArrayList<String> ServerStartMin_Str = new ArrayList();
    public static ArrayList<Integer> ServerStartSec = new ArrayList();
    public static ArrayList<String> ServerStartSec_Str = new ArrayList();
    public static ArrayList<String> ServerStartTime_Str = new ArrayList();
    public static final int TESTCONNECTION = 222;
    static final int UPLOADQUEST = 102;
    public static final int USERVERIFY = 167;
    public static final int USERVERIFYRESULT = 168;
    public static final int USERVERIFYRESULTMR = 169;
    public static final String VERSION_PREF = "version_pref";
    public static final int WECHAT_PAYMENT_VER = 1;
    public static final int WIFI_SEARCH_RESULT_CODE_FAIL_NET_DOWN = 4113;
    public static final int WIFI_SEARCH_RESULT_CODE_FAIL_NET_POOL = 4114;
    public static final int WIFI_SEARCH_RESULT_CODE_FAIL_OLD_VERSON = 4119;
    public static final int WIFI_SEARCH_RESULT_CODE_FAIL_PWD_ERROR = 4118;
    public static final int WIFI_SEARCH_RESULT_CODE_FAIL_SERVER_OFFLINE = 4115;
    public static final int WIFI_SEARCH_RESULT_CODE_FAIL_USER_NOEXIST = 4117;
    public static final int WIFI_SEARCH_RESULT_CODE_FAIL_VERIFY_FAILED = 4116;
    public static final int WIFI_SEARCH_RESULT_CODE_SUCCESS = 17;
    public static final int XGPUSH_VALID_TOKEN_LENGTH = 40;
    public static AlarmAndPromptInfo _AlarmAndPromptConfig = new AlarmAndPromptInfo();
    public static int _DemoMRPort = 8800;
    static String _DemoMRServer = "rs31.nvdvr.cn";
    public static byte[] _ImagePixel = new byte[4915200];
    public static int _MRPort = 8800;
    static String _MRServer = "127.0.0.1";
    public static int _MRServerIndex = 0;
    public static int _OnLinePort = 8900;
    public static float _PTZXHeight = 80.0f;
    public static int _PTZXPointDevID = 0;
    public static float _PTZXWidth = 120.0f;
    public static int _PlatbackListviewSelectedPosition = 0;
    public static int _PlatbackRecListviewFisrtPosition = 0;
    static byte[] _SockBuf = new byte[524288];
    public static final int _YUVHeight = 480;
    public static final int _YUVWidth = 0;
    static boolean _bUseMRServer = true;
    public static int _capHeight = _YUVHeight;
    public static int _capWidth = 640;
    public static ByteBuffer _capbuffer = ByteBuffer.wrap(_ImagePixel);
    public static ArrayList<DeviceInfo> _demoSeverInfoListData = new ArrayList();
    static final String _fileName = "systemConfig.xml";
    static boolean _isAutoLoginEnable = true;
    public static boolean _isMRMode = false;
    public static boolean _isNeedGetPreviewDeviceList = true;
    public static boolean _isQRResultOK = false;
    public static long _lCheckTime = 0;
    public static long _lConfigIDGenTime = 0;
    public static long _lHandle = -1;
    public static long _lHandleGetTime = 0;
    public static int _listviewFisrtPosition = 0;
    public static int _nAlarmPort = 8888;
    public static int _nCheckVersionNUm = 0;
    public static int _nConfigID = 0;
    public static int _nCurrentID = 0;
    public static int _nDeviceID = -1;
    public static int _nListMode = 200;
    public static int _nMRPort = 0;
    public static int _nQRResultDevice = 0;
    public static int _nSearchDevID = -1;
    public static int _nSearchPort = 8800;
    public static RecordInfo _objRecordConfig = new RecordInfo();
    public static byte[] _playFaceYUVData = new byte[Defines.FRAME_BUF_MAX_SIZE];
    public static HashMap<Integer, PTZXPoint> _ptzxPointList = new HashMap();
    public static ArrayList<DeviceInfo> _severInfoListData = new ArrayList();
    public static ArrayList<ServerInfoForAlarm> _severInfoListDataForAlarm = new ArrayList();
    public static ArrayList<DeviceInfo> _severInfoWithoutImageListData = new ArrayList();
    public static String _strAlarmLargePosition = "as114.nvdvr.cn";
    public static String _strAlarmServerRecv = "alarm1.nvdvr.cn";
    public static String _strAlarmServerRecv1 = "alarmrec1.nvdvr.cn";
    public static String _strAlarmServerRecv2 = "alarmrec2.nvdvr.cn";
    public static String _strAlarmServerSend = "alarm1.nvdvr.cn";
    public static String _strDefaultAlarmServerRecv = null;
    public static String _strDeviceDemoServer = "preview.nvdvr.cn";
    public static String _strMRServer = null;
    public static String _strPassword = null;
    public static String _strSearchDomain = "127.0.0.1";
    public static String _strSearchIP = "127.0.0.1";
    public static String _strUpdate = "update.nvdvr.cn";
    public static String _strUserName = null;
    public static ArrayList<ObjectAlarmMessage> alarmInfoListData = new ArrayList();
    public static DeviceInfo alarmRelecanceDeviceInfo = null;
    public static int alarmcolumns = 8;
    public static int alarmrows = 4;
    public static int areaID = 0;
    public static boolean bIsBackPlay = false;
    public static boolean bIsConfig = false;
    public static List<RecordFileInfo> cloudRecordFileList = new ArrayList();
    public static DeviceInfo configDeviceInfo = null;
    public static int effectiveTime1 = 0;
    public static int effectiveTime2 = 0;
    public static int effectiveTime3 = 0;
    public static HomePageActivity homePageActivity = null;
    public static boolean isClientRegisted = false;
    public static boolean isDeviceBinded = false;
    public static boolean isDeviceListSet = false;
    public static boolean isFirstIn = false;
    public static boolean isRecvMsg = true;
    static boolean isResourrceLoaded = false;
    public static boolean isSound = false;
    public static boolean isVibrate = false;
    public static Long lChannelID = Long.valueOf(2100146144);
    private static long lPlayTime = 0;
    public static List<RecordFileInfo> listMapPlayerBackFile = new ArrayList();
    public static List<Map<String, Object>> localRecordFileList = new ArrayList();
    static MRServerInfo mrServer1 = new MRServerInfo();
    static MRServerInfo mrServer2 = new MRServerInfo();
    static MRServerInfo mrServer3 = new MRServerInfo();
    static final int nBuildCount = 11;
    public static int nClientDeviceSettingThreadID = 0;
    public static int nClientRegistThreadID = 0;
    public static final int notificationAlarmID = 258;
    public static final int notificationID = 257;
    static final long[] pattern = new long[]{500, 1000, 500, 1000};
    public static CloudStorageActivity sCloudStorageActivity = null;
    public static boolean shouldLoadUserDeviceList = false;
    public static boolean shouldRefreshDeviceList = false;
    public static boolean shouldUpdateSelectArea = false;
    private static SoundPool soudPool = null;
    private static int sourceid_alarm_notice = 0;
    private static int sourceid_alarm_warm = 0;
    public static String strApiKey = "ANZ5W6T49K8E";
    public static String strClientID = "android";
    public static String strPhoneNumber = "unknow";
    public static String strSecretKey = "80959d56c239d520de85aff158e9baf7";
    public static String strSoundFile = "alarm.mp3";
    public static String strSysLan = null;
    public static String strUserID = "unknow";
    public static boolean unbindingServiceFromMail = false;
    private static Vibrator vibrator = null;

    public static void loadAlarmSettings(Activity context) {
        if (context != null) {
            SharedPreferences alarmSettingSharedPreferences = context.getSharedPreferences(ALARM_SETTINGS, 32768);
            if (alarmSettingSharedPreferences != null) {
                isRecvMsg = alarmSettingSharedPreferences.getBoolean(RECV_ALARM_MSG, true);
                isVibrate = alarmSettingSharedPreferences.getBoolean(ALARM_SHAKE, false);
                isSound = alarmSettingSharedPreferences.getBoolean(ALARM_SOUND, true);
            }
            strSysLan = context.getString(C0470R.string.country_code);
        }
    }

    public static void saveAlarmSettings(Activity context) {
        if (context != null) {
            SharedPreferences alarmSettingSharedPreferences = context.getSharedPreferences(ALARM_SETTINGS, 32768);
            if (alarmSettingSharedPreferences != null) {
                Editor editor = alarmSettingSharedPreferences.edit();
                if (editor != null) {
                    editor.putBoolean(RECV_ALARM_MSG, isRecvMsg);
                    editor.putBoolean(ALARM_SHAKE, isVibrate);
                    editor.putBoolean(ALARM_SOUND, isSound);
                    editor.commit();
                }
            }
        }
    }

    public static void addAlarmTime(int starthour1, int starthour2, int starthour3, int startmin1, int startmin2, int startmin3, int startsec1, int startsec2, int startsec3, int endhour1, int endhour2, int endhour3, int endmin1, int endmin2, int endmin3, int endsec1, int endsec2, int endsec3) {
        String str_starthour1;
        String str_startmin1;
        String str_startsec1;
        String str_endhour1;
        String str_endmin1;
        String str_endsec1;
        String str_starthour2;
        String str_startmin2;
        String str_startsec2;
        String str_endhour2;
        String str_endmin2;
        String str_endsec2;
        String str_starthour3;
        String str_startmin3;
        String str_startsec3;
        String str_endhour3;
        String str_endmin3;
        String str_endsec3;
        if (starthour1 == 0 && startmin1 == 0 && endhour1 == 0 && endmin1 == 0) {
            effectiveTime1 = 0;
        } else {
            effectiveTime1 = 1;
        }
        if (starthour2 == 0 && startmin2 == 0 && endhour2 == 0 && endmin2 == 0) {
            effectiveTime2 = 0;
        } else {
            effectiveTime2 = 1;
        }
        if (starthour3 == 0 && startmin3 == 0 && endhour3 == 0 && endmin3 == 0) {
            effectiveTime3 = 0;
        } else {
            effectiveTime3 = 1;
        }
        Log.i("TAG", "effectiveTime = " + effectiveTime1 + " " + effectiveTime2 + " " + effectiveTime3 + " ");
        ServerStartHour.add(0, Integer.valueOf(starthour1));
        ServerStartHour.add(1, Integer.valueOf(starthour2));
        ServerStartHour.add(2, Integer.valueOf(starthour3));
        ServerStartMin.add(0, Integer.valueOf(startmin1));
        ServerStartMin.add(1, Integer.valueOf(startmin2));
        ServerStartMin.add(2, Integer.valueOf(startmin3));
        ServerStartSec.add(0, Integer.valueOf(startsec1));
        ServerStartSec.add(1, Integer.valueOf(startsec2));
        ServerStartSec.add(2, Integer.valueOf(startsec3));
        ServerEndHour.add(0, Integer.valueOf(endhour1));
        ServerEndHour.add(1, Integer.valueOf(endhour2));
        ServerEndHour.add(2, Integer.valueOf(endhour3));
        ServerEndMin.add(0, Integer.valueOf(endmin1));
        ServerEndMin.add(1, Integer.valueOf(endmin2));
        ServerEndMin.add(2, Integer.valueOf(endmin3));
        ServerEndSec.add(0, Integer.valueOf(endsec1));
        ServerEndSec.add(1, Integer.valueOf(endsec2));
        ServerEndSec.add(2, Integer.valueOf(endsec3));
        if (starthour1 < 10) {
            str_starthour1 = "0" + starthour1;
        } else {
            str_starthour1 = starthour1;
        }
        if (startmin1 < 10) {
            str_startmin1 = "0" + startmin1;
        } else {
            str_startmin1 = startmin1;
        }
        if (startsec1 < 10) {
            str_startsec1 = "0" + startsec1;
        } else {
            str_startsec1 = startsec1;
        }
        if (endhour1 < 10) {
            str_endhour1 = "0" + endhour1;
        } else {
            str_endhour1 = endhour1;
        }
        if (endmin1 < 10) {
            str_endmin1 = "0" + endmin1;
        } else {
            str_endmin1 = endmin1;
        }
        if (endsec1 < 10) {
            str_endsec1 = "0" + endsec1;
        } else {
            str_endsec1 = endsec1;
        }
        if (starthour2 < 10) {
            str_starthour2 = "0" + starthour2;
        } else {
            str_starthour2 = starthour2;
        }
        if (startmin2 < 10) {
            str_startmin2 = "0" + startmin2;
        } else {
            str_startmin2 = startmin2;
        }
        if (startsec2 < 10) {
            str_startsec2 = "0" + startsec2;
        } else {
            str_startsec2 = startsec2;
        }
        if (endhour2 < 10) {
            str_endhour2 = "0" + endhour2;
        } else {
            str_endhour2 = endhour2;
        }
        if (endmin2 < 10) {
            str_endmin2 = "0" + endmin2;
        } else {
            str_endmin2 = endmin2;
        }
        if (endsec2 < 10) {
            str_endsec2 = "0" + endsec2;
        } else {
            str_endsec2 = endsec2;
        }
        if (starthour3 < 10) {
            str_starthour3 = "0" + starthour3;
        } else {
            str_starthour3 = starthour3;
        }
        if (startmin3 < 10) {
            str_startmin3 = "0" + startmin3;
        } else {
            str_startmin3 = startmin3;
        }
        if (startsec3 < 10) {
            str_startsec3 = "0" + startsec3;
        } else {
            str_startsec3 = startsec3;
        }
        if (endhour3 < 10) {
            str_endhour3 = "0" + endhour3;
        } else {
            str_endhour3 = endhour3;
        }
        if (endmin3 < 10) {
            str_endmin3 = "0" + endmin3;
        } else {
            str_endmin3 = endmin3;
        }
        if (endsec3 < 10) {
            str_endsec3 = "0" + endsec3;
        } else {
            str_endsec3 = endsec3;
        }
        ServerStartHour_Str.add(0, str_starthour1);
        ServerStartHour_Str.add(1, str_starthour2);
        ServerStartHour_Str.add(2, str_starthour3);
        ServerStartMin_Str.add(0, str_startmin1);
        ServerStartMin_Str.add(1, str_startmin2);
        ServerStartMin_Str.add(2, str_startmin3);
        ServerStartSec_Str.add(0, str_startsec1);
        ServerStartSec_Str.add(1, str_startsec2);
        ServerStartSec_Str.add(2, str_startsec3);
        ServerEndHour_Str.add(0, str_endhour1);
        ServerEndHour_Str.add(1, str_endhour2);
        ServerEndHour_Str.add(2, str_endhour3);
        ServerEndMin_Str.add(0, str_endmin1);
        ServerEndMin_Str.add(1, str_endmin2);
        ServerEndMin_Str.add(2, str_endmin3);
        ServerEndSec_Str.add(0, str_endsec1);
        ServerEndSec_Str.add(1, str_endsec2);
        ServerEndSec_Str.add(2, str_endsec3);
        ServerStartTime_Str.add(0, str_starthour1 + ":" + str_startmin1);
        ServerStartTime_Str.add(1, str_starthour2 + ":" + str_startmin2);
        ServerStartTime_Str.add(2, str_starthour3 + ":" + str_startmin3);
        ServerStartTime_Str.add(0, str_starthour1 + ":" + str_startmin1);
        ServerStartTime_Str.add(1, str_starthour2 + ":" + str_startmin2);
        ServerStartTime_Str.add(2, str_starthour3 + ":" + str_startmin3);
        ServerEndTime_Str.add(0, str_endhour1 + ":" + str_endmin1);
        ServerEndTime_Str.add(1, str_endhour2 + ":" + str_endmin2);
        ServerEndTime_Str.add(2, str_endhour3 + ":" + str_endmin3);
        ServerEndTime_Str.add(0, str_endhour1 + ":" + str_endmin1);
        ServerEndTime_Str.add(1, str_endhour2 + ":" + str_endmin2);
        ServerEndTime_Str.add(2, str_endhour3 + ":" + str_endmin3);
    }

    public static int reloadDeviceInfoList() {
        _severInfoListData.clear();
        _severInfoWithoutImageListData.clear();
        DeviceInfo[] array = DatabaseManager.GetAllServerInfo();
        if (array != null) {
            for (int i = 0; i < array.length; i++) {
                if (array[i] != null) {
                    _severInfoListData.add(array[i]);
                    _severInfoWithoutImageListData.add(array[i].copyDeviceInfoWithoutImage());
                }
            }
        }
        return _severInfoListData.size();
    }

    public static synchronized void initNoticeSound(Context context) {
        synchronized (LocalDefines.class) {
            if (soudPool == null) {
                soudPool = new SoundPool(1, 1, 5);
            }
            sourceid_alarm_notice = soudPool.load(context, C0470R.raw.alarm_notice, 0);
            sourceid_alarm_warm = soudPool.load(context, C0470R.raw.alarm_warm, 0);
            if (vibrator == null) {
                vibrator = (Vibrator) context.getSystemService("vibrator");
            }
        }
    }

    public static synchronized void playNoticeSound(int nAlarmType) {
        synchronized (LocalDefines.class) {
            if (System.currentTimeMillis() - lPlayTime > 1000) {
                if (isSound && soudPool != null) {
                    if (nAlarmType == 100 || nAlarmType == 300 || nAlarmType == 400 || nAlarmType == 500 || nAlarmType == 600) {
                        soudPool.play(sourceid_alarm_warm, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, 0, 0, PhotoViewAttacher.DEFAULT_MIN_SCALE);
                    } else {
                        soudPool.play(sourceid_alarm_notice, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, 0, 0, PhotoViewAttacher.DEFAULT_MIN_SCALE);
                    }
                    lPlayTime = System.currentTimeMillis();
                }
                if (isVibrate && vibrator != null) {
                    vibrator.vibrate(pattern, -1);
                }
            }
        }
    }

    public static int loadDeviceList(boolean isCheck) {
        if (isCheck && _severInfoListData.size() > 0) {
            return _severInfoListData.size();
        }
        if (_severInfoListData.size() > 0) {
            for (int i = _severInfoListData.size() - 1; i >= 0; i--) {
                DeviceInfo info = (DeviceInfo) _severInfoListData.get(i);
                if (info != null) {
                    info.releaseImage();
                }
            }
            System.gc();
        }
        reloadDeviceInfoList();
        return 0;
    }

    public static String getAlarmServerByIndex(int index) {
        switch (index) {
            case 0:
                return _strAlarmServerRecv;
            case 1:
                return _strAlarmServerRecv1;
            case 2:
                return _strAlarmServerRecv2;
            default:
                return _strAlarmServerRecv;
        }
    }

    static boolean loadMRServer() {
        MRServerInfo[] mrServers = DatabaseManager.GetALLMRServer();
        if (mrServers == null) {
            mrServer1.setnServerID(1);
            mrServer1.setbIsInit(false);
            mrServer2.setnServerID(2);
            mrServer2.setbIsInit(false);
            mrServer3.setnServerID(3);
            mrServer3.setbIsInit(false);
            DatabaseManager.AddMRServerInfo(mrServer1);
            DatabaseManager.AddMRServerInfo(mrServer2);
            DatabaseManager.AddMRServerInfo(mrServer3);
        } else {
            for (int i = mrServers.length - 1; i >= 0; i--) {
                if (mrServers[i] != null) {
                    if (mrServers[i].getnServerID() == 1) {
                        mrServer1.setnServerID(1);
                        mrServer1.setnID(mrServers[i].getnID());
                        mrServer1.setbIsInit(mrServers[i].isbIsInit());
                        mrServer1.setlInitTime(mrServers[i].getlInitTime());
                        mrServer1.setStrDomain(mrServers[i].getStrDomain());
                        mrServer1.setStrIP(mrServers[i].getStrIP());
                    } else if (mrServers[i].getnServerID() == 2) {
                        mrServer2.setnServerID(2);
                        mrServer2.setnID(mrServers[i].getnID());
                        mrServer2.setbIsInit(mrServers[i].isbIsInit());
                        mrServer2.setlInitTime(mrServers[i].getlInitTime());
                        mrServer2.setStrDomain(mrServers[i].getStrDomain());
                        mrServer2.setStrIP(mrServers[i].getStrIP());
                    } else if (mrServers[i].getnServerID() == 3) {
                        mrServer3.setnServerID(3);
                        mrServer3.setnID(mrServers[i].getnID());
                        mrServer3.setbIsInit(mrServers[i].isbIsInit());
                        mrServer3.setlInitTime(mrServers[i].getlInitTime());
                        mrServer3.setStrDomain(mrServers[i].getStrDomain());
                        mrServer3.setStrIP(mrServers[i].getStrIP());
                    }
                }
            }
        }
        return false;
    }

    static void loadResource(Resources resource) {
        if (resource != null && !isResourrceLoaded) {
            if (_ImagePixel == null) {
                _ImagePixel = new byte[3686400];
            }
            if (_SockBuf == null) {
                _SockBuf = new byte[524288];
            }
            if (_playFaceYUVData == null) {
                _playFaceYUVData = new byte[Defines.FRAME_BUF_MAX_SIZE];
            }
            Arrays.fill(_playFaceYUVData, (byte) 0);
            isResourrceLoaded = true;
        }
    }

    public static boolean updatePTZXPoints(int nDevID, int nPTZXID, Bitmap image) {
        boolean bResult = false;
        PTZXPoint pTZXPoint = null;
        if (_PTZXPointDevID == nDevID) {
            pTZXPoint = (PTZXPoint) _ptzxPointList.get(Integer.valueOf(nPTZXID));
        } else {
            _ptzxPointList.clear();
        }
        if (pTZXPoint == null) {
            pTZXPoint = new PTZXPoint(0, nDevID, nPTZXID, System.currentTimeMillis(), null);
            bResult = DatabaseManager.AddPTZXInfo(pTZXPoint);
        }
        if (pTZXPoint != null) {
            pTZXPoint.setFaceImage(image);
            pTZXPoint.setlSaveTime(System.currentTimeMillis());
            bResult = DatabaseManager.updatePTZXPoint(pTZXPoint);
            _ptzxPointList.remove(Integer.valueOf(nPTZXID));
            _ptzxPointList.put(Integer.valueOf(nPTZXID), pTZXPoint);
            _PTZXPointDevID = nDevID;
        }
        return bResult;
    }

    public static int loadPTZXPoints(int nDevID) {
        System.out.println("loadPTZXPoints : " + nDevID);
        boolean isToLoad = true;
        if (_PTZXPointDevID == nDevID) {
            isToLoad = false;
        }
        if (isToLoad) {
            System.out.println("loadPTZXPoints : " + nDevID);
            PTZXPoint[] ptzxPointsList = DatabaseManager.GetPTZXInfos(nDevID);
            if (ptzxPointsList != null && ptzxPointsList.length > 0) {
                _ptzxPointList.clear();
                for (int i = ptzxPointsList.length - 1; i >= 0; i--) {
                    _ptzxPointList.put(Integer.valueOf(ptzxPointsList[i].getnPTZXID()), ptzxPointsList[i]);
                }
                _PTZXPointDevID = nDevID;
            }
        }
        return _ptzxPointList.size();
    }

    public static int getConfigID() {
        if (_nConfigID <= 0 || System.currentTimeMillis() - _lConfigIDGenTime >= 60000) {
            _nConfigID = ((int) (Math.random() * 10.0d)) + 1;
            if (_nConfigID >= 10) {
                _nConfigID = 9;
            } else if (_nConfigID <= 0) {
                _nConfigID = 1;
            }
        }
        return _nConfigID;
    }

    public static boolean isZh(Context context) {
        if (context.getResources().getConfiguration().locale.getLanguage().endsWith("zh")) {
            return true;
        }
        return false;
    }

    public static int dip2px(Context context, float dpValue) {
        return (int) ((dpValue * context.getResources().getDisplayMetrics().density) + 0.5f);
    }

    public static int px2dip(Context context, float pxValue) {
        return (int) ((pxValue / context.getResources().getDisplayMetrics().density) + 0.5f);
    }

    public static String md5(String string) {
        try {
            byte[] hash = MessageDigest.getInstance("MD5").digest(string.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder(hash.length * 2);
            for (byte b : hash) {
                if ((b & 255) < 16) {
                    hex.append("0");
                }
                hex.append(Integer.toHexString(b & 255));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Huh, MD5 should be supported?", e);
        } catch (UnsupportedEncodingException e2) {
            throw new RuntimeException("Huh, UTF-8 should be supported?", e2);
        }
    }

    public static String getCurrentConnectedWifiSSIDName(WifiManager mWiFiManager) {
        String currentConnectedSSIDName = mWiFiManager.getConnectionInfo().getSSID();
        currentConnectedSSIDName = (String) currentConnectedSSIDName.subSequence(1, currentConnectedSSIDName.length() - 1);
        if (currentConnectedSSIDName == null || currentConnectedSSIDName.length() <= 0 || currentConnectedSSIDName.equalsIgnoreCase("0x") || !currentConnectedSSIDName.substring(0, 1).equals("\"") || !currentConnectedSSIDName.substring(currentConnectedSSIDName.length() - 1, currentConnectedSSIDName.length()).equals("\"")) {
            return currentConnectedSSIDName;
        }
        return currentConnectedSSIDName.substring(1, currentConnectedSSIDName.length() - 1);
    }

    public static int getStatusBarHeight(Context context) {
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return context.getResources().getDimensionPixelSize(resourceId);
        }
        return 0;
    }

    public static String getReceiverActionString(Context context) {
        return context.getPackageName() + ".CLOSE_PLAYER_ACTIVITY";
    }
}
