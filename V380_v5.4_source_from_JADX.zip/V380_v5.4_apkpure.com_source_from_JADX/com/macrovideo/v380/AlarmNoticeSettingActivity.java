package com.macrovideo.v380;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import com.macrovideo.pull.lib.CheckSwitchButton;
import com.macrovideo.xingepush.RegistClientToServer;

public class AlarmNoticeSettingActivity extends Activity implements OnClickListener {
    private CheckSwitchButton btnSwitchRecvMsg;
    private CheckSwitchButton btnSwitchSound;
    private CheckSwitchButton btnSwitchVibreate;
    private ImageView ivAlarmFunction;

    class C02491 implements OnCheckedChangeListener {
        C02491() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isCheck) {
            LocalDefines.isSound = isCheck;
            LocalDefines.saveAlarmSettings(AlarmNoticeSettingActivity.this);
        }
    }

    class C02502 implements OnCheckedChangeListener {
        C02502() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isCheck) {
            LocalDefines.isVibrate = isCheck;
            LocalDefines.saveAlarmSettings(AlarmNoticeSettingActivity.this);
        }
    }

    class C02513 implements OnCheckedChangeListener {
        C02513() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isCheck) {
            LocalDefines.isRecvMsg = isCheck;
            LocalDefines.saveAlarmSettings(AlarmNoticeSettingActivity.this);
            AlarmNoticeSettingActivity.this.updateSettingToServer();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_alarm_notice_setting);
        initView();
    }

    private void initView() {
        this.btnSwitchSound = (CheckSwitchButton) findViewById(C0470R.id.btnSound);
        this.btnSwitchSound.setOnCheckedChangeListener(new C02491());
        this.btnSwitchVibreate = (CheckSwitchButton) findViewById(C0470R.id.btnShake);
        this.btnSwitchVibreate.setOnCheckedChangeListener(new C02502());
        this.btnSwitchRecvMsg = (CheckSwitchButton) findViewById(C0470R.id.btnAlarmFunction);
        this.btnSwitchRecvMsg.setOnCheckedChangeListener(new C02513());
        this.ivAlarmFunction = (ImageView) findViewById(C0470R.id.ivAlarmFunction);
        this.ivAlarmFunction.setOnClickListener(this);
    }

    private void updateSettingToServer() {
        LocalDefines.nClientRegistThreadID++;
        new RegistClientToServer(this, LocalDefines.nClientRegistThreadID).start();
    }

    public void onStart() {
        super.onStart();
        LocalDefines.loadAlarmSettings(this);
        this.btnSwitchRecvMsg.setChecked(LocalDefines.isRecvMsg);
        this.btnSwitchVibreate.setChecked(LocalDefines.isVibrate);
        this.btnSwitchSound.setChecked(LocalDefines.isSound);
    }

    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case C0470R.id.ivAlarmFunction:
                finish();
                return;
            default:
                return;
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            finish();
        }
        return false;
    }
}
