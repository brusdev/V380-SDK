package com.macrovideo.v380;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.macrovideo.custom.ViewPagerIndicator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PhotoManagerActivity extends FragmentActivity implements OnClickListener {
    private boolean isSelected = false;
    private FragmentPagerAdapter mAdapter;
    private ImageView mBtnBack;
    public TextView mBtnSelect;
    private List<Fragment> mContents;
    private List<String> mFragmentTitles;
    private ViewPagerIndicator mIndicator;
    private PhotoFragment mPhotoFragment;
    private RecordFileFragment mRecordFileFragment;
    private ViewPager mViewPager;

    class C08391 implements OnPageChangeListener {
        C08391() {
        }

        public void onPageSelected(int arg0) {
            if (arg0 == 0) {
                if (PhotoManagerActivity.this.isSelected) {
                    PhotoManagerActivity.this.hideRecordFileSelectState();
                }
            } else if (PhotoManagerActivity.this.isSelected) {
                PhotoManagerActivity.this.hidePhotoSelectState();
            }
        }

        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        public void onPageScrollStateChanged(int arg0) {
        }
    }

    public /* bridge */ /* synthetic */ View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return super.onCreateView(view, str, context, attributeSet);
    }

    public /* bridge */ /* synthetic */ View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return super.onCreateView(str, context, attributeSet);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_photo_manager);
        initViews();
        initDatas();
    }

    private void initViews() {
        this.mViewPager = (ViewPager) findViewById(C0470R.id.id_viewpager);
        this.mViewPager.addOnPageChangeListener(new C08391());
        this.mIndicator = (ViewPagerIndicator) findViewById(C0470R.id.id_indicator);
        this.mBtnBack = (ImageView) findViewById(C0470R.id.iv_back);
        this.mBtnBack.setOnClickListener(this);
        this.mBtnSelect = (TextView) findViewById(C0470R.id.tv_select);
        this.mBtnSelect.setOnClickListener(this);
    }

    private void initDatas() {
        this.mFragmentTitles = Arrays.asList(new String[]{getString(C0470R.string.tabScreenShot), getString(C0470R.string.str_recording)});
        this.mContents = new ArrayList();
        this.mPhotoFragment = PhotoFragment.newInstance();
        this.mRecordFileFragment = RecordFileFragment.newInstance();
        this.mContents.add(this.mPhotoFragment);
        this.mContents.add(this.mRecordFileFragment);
        this.mAdapter = new FragmentPagerAdapter(getSupportFragmentManager()) {
            public int getCount() {
                return PhotoManagerActivity.this.mContents.size();
            }

            public Fragment getItem(int arg0) {
                return (Fragment) PhotoManagerActivity.this.mContents.get(arg0);
            }
        };
        this.mViewPager.setAdapter(this.mAdapter);
        this.mIndicator.setDatas(this.mFragmentTitles);
        this.mIndicator.setViewPager(this.mViewPager);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.iv_back:
                if (!this.isSelected) {
                    finish();
                    return;
                } else if (this.mViewPager.getCurrentItem() == 0) {
                    hidePhotoSelectState();
                    return;
                } else {
                    hideRecordFileSelectState();
                    return;
                }
            case C0470R.id.tv_select:
                if (this.isSelected) {
                    if (this.mViewPager.getCurrentItem() == 0) {
                        hidePhotoSelectState();
                        return;
                    } else {
                        hideRecordFileSelectState();
                        return;
                    }
                } else if (this.mViewPager.getCurrentItem() == 0) {
                    showPhotoSelectState();
                    return;
                } else {
                    showRecordFileSelectState();
                    return;
                }
            default:
                return;
        }
    }

    public void hidePhotoSelectState() {
        if (this.mPhotoFragment == null) {
            this.mPhotoFragment = PhotoFragment.newInstance();
        }
        this.isSelected = false;
        this.mBtnSelect.setText(getString(C0470R.string.str_select));
        this.mPhotoFragment.mIsSelectAll = false;
        this.mPhotoFragment.bDelete = false;
        this.mPhotoFragment.setImageCheckStateFalse();
        this.mPhotoFragment.updatePhotoGridView();
        this.mPhotoFragment.setBottomBarVisibility(8);
    }

    public void showPhotoSelectState() {
        if (this.mPhotoFragment == null) {
            this.mPhotoFragment = PhotoFragment.newInstance();
        }
        this.isSelected = true;
        this.mBtnSelect.setText(getString(C0470R.string.btn_cancel));
        this.mPhotoFragment.bDelete = true;
        this.mPhotoFragment.updatePhotoGridView();
        this.mPhotoFragment.setBottomBarVisibility(0);
    }

    public void hideRecordFileSelectState() {
        if (this.mRecordFileFragment == null) {
            this.mRecordFileFragment = RecordFileFragment.newInstance();
        }
        this.isSelected = false;
        this.mBtnSelect.setText(getString(C0470R.string.str_select));
        this.mRecordFileFragment.mIsSelectAll = false;
        this.mRecordFileFragment.bDelete = false;
        this.mRecordFileFragment.setImageCheckStateFalse();
        this.mRecordFileFragment.upDateRecordListView();
        this.mRecordFileFragment.setBottomBarVisibility(8);
    }

    public void showRecordFileSelectState() {
        if (this.mRecordFileFragment == null) {
            this.mRecordFileFragment = RecordFileFragment.newInstance();
        }
        this.isSelected = true;
        this.mBtnSelect.setText(getString(C0470R.string.btn_cancel));
        this.mRecordFileFragment.bDelete = true;
        this.mRecordFileFragment.upDateRecordListView();
        this.mRecordFileFragment.setBottomBarVisibility(0);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (!this.isSelected) {
                finish();
            } else if (this.mViewPager.getCurrentItem() == 0) {
                hidePhotoSelectState();
            } else {
                hideRecordFileSelectState();
            }
        }
        return false;
    }
}
