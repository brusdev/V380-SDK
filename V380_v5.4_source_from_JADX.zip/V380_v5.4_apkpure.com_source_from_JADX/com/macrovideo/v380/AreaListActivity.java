package com.macrovideo.v380;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.lock.GestureEditActivity;
import java.util.ArrayList;

public class AreaListActivity extends Activity implements OnItemClickListener, OnClickListener {
    public static final String AREA = "Area";
    private Button btnAreaSave = null;
    private ImageView ivAreaBack = null;
    private ArrayList<AreaInfo> listArea = null;
    private ListView listViewArea = null;
    private SharedPreferences preferences;
    private RelativeLayout rlAreaList = null;
    private TextView tvAreaA = null;
    private TextView tvAreaAll = null;
    private TextView tvAreaTitle = null;

    private class AreaSelectionAdapter extends BaseAdapter {
        private LayoutInflater mInflater;

        public final class ViewHolder {
            public TextView tvAreaA;
            public TextView tvAreaAll;
        }

        public AreaSelectionAdapter() {
            this.mInflater = (LayoutInflater) AreaListActivity.this.getSystemService("layout_inflater");
        }

        public int getCount() {
            return AreaListActivity.this.listArea.size();
        }

        public Object getItem(int position) {
            return AreaListActivity.this.listArea.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View converView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (converView == null) {
                viewHolder = new ViewHolder();
                converView = this.mInflater.inflate(C0470R.layout.area_list_item, null);
                viewHolder.tvAreaAll = (TextView) converView.findViewById(C0470R.id.tvAreaItemAll);
                viewHolder.tvAreaA = (TextView) converView.findViewById(C0470R.id.tvAreaItemA);
                converView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) converView.getTag();
            }
            viewHolder.tvAreaAll.setText(((AreaInfo) AreaListActivity.this.listArea.get(position)).getArea());
            viewHolder.tvAreaA.setText(((AreaInfo) AreaListActivity.this.listArea.get(position)).getCountry());
            if (position == LocalDefines.areaID) {
                viewHolder.tvAreaAll.setTextColor(-16776961);
                viewHolder.tvAreaA.setTextColor(-16776961);
            } else {
                viewHolder.tvAreaAll.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                viewHolder.tvAreaA.setTextColor(Color.parseColor("#666666"));
            }
            return converView;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.area_list_activity);
        initView();
        AreaData();
    }

    protected void onStart() {
        super.onStart();
        String strArea = ((AreaInfo) this.listArea.get(LocalDefines.areaID)).getArea();
        String strCountry = ((AreaInfo) this.listArea.get(LocalDefines.areaID)).getCountry();
        this.tvAreaAll.setText(new StringBuilder(String.valueOf(strArea)).toString());
        this.tvAreaA.setText(new StringBuilder(String.valueOf(strCountry)).toString());
    }

    private void initView() {
        this.listViewArea = (ListView) findViewById(C0470R.id.lvArea);
        this.listViewArea.setOnItemClickListener(this);
        this.listViewArea.setCacheColorHint(0);
        this.tvAreaA = (TextView) findViewById(C0470R.id.tvAreaA);
        this.tvAreaA.setOnClickListener(this);
        this.tvAreaAll = (TextView) findViewById(C0470R.id.tvAreaAll);
        this.tvAreaAll.setOnClickListener(this);
        this.tvAreaTitle = (TextView) findViewById(C0470R.id.tvAreaTitle);
        this.btnAreaSave = (Button) findViewById(C0470R.id.btnAreaSave);
        this.btnAreaSave.setOnClickListener(this);
        this.rlAreaList = (RelativeLayout) findViewById(C0470R.id.rlAreaList);
        this.rlAreaList.setOnClickListener(this);
        this.ivAreaBack = (ImageView) findViewById(C0470R.id.ivAreaBack);
        this.ivAreaBack.setOnClickListener(this);
    }

    private void AreaData() {
        this.listArea = new ArrayList();
        AreaInfo data = new AreaInfo();
        data.setArea(getString(C0470R.string.autoSelect));
        data.setCountry("(" + getString(C0470R.string.autoSelect) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.china));
        data.setCountry("(" + getString(C0470R.string.china2) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AS1));
        data.setCountry("(" + getString(C0470R.string.zoneAS1) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AS2));
        data.setCountry("(" + getString(C0470R.string.zoneAS2) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AS3));
        data.setCountry("(" + getString(C0470R.string.zoneAS3) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AS4));
        data.setCountry("(" + getString(C0470R.string.zoneAS4) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.NA1));
        data.setCountry("(" + getString(C0470R.string.zoneNA1) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.SA1));
        data.setCountry("(" + getString(C0470R.string.zoneSA1) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.EU1));
        data.setCountry("(" + getString(C0470R.string.zoneEU1) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.EU2));
        data.setCountry("(" + getString(C0470R.string.zoneEU2) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.OA1));
        data.setCountry("(" + getString(C0470R.string.zoneOA1) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AF1));
        data.setCountry("(" + getString(C0470R.string.zoneAF1) + ")");
        this.listArea.add(data);
        data = new AreaInfo();
        data.setArea(getString(C0470R.string.AF2));
        data.setCountry("(" + getString(C0470R.string.zoneAF2) + ")");
        this.listArea.add(data);
    }

    private void getAreaSelectionList() {
        if (this.listArea != null && this.listArea.size() > 0) {
            AreaSelectionAdapter arAdapter = new AreaSelectionAdapter();
            if (this.listViewArea != null) {
                this.listViewArea.setAdapter(arAdapter);
                return;
            }
            this.listViewArea = (ListView) findViewById(C0470R.id.lvArea);
            this.listViewArea.setCacheColorHint(0);
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.ivAreaBack:
                if (this.listViewArea.getVisibility() == 8) {
                    finish();
                    return;
                }
                this.rlAreaList.setVisibility(0);
                this.listViewArea.setVisibility(8);
                this.tvAreaTitle.setText(getString(C0470R.string.areaSelection));
                return;
            case C0470R.id.tvAreaAll:
            case C0470R.id.tvAreaA:
                this.rlAreaList.setVisibility(8);
                this.listViewArea.setVisibility(0);
                this.tvAreaTitle.setText(getString(C0470R.string.areaSelections));
                getAreaSelectionList();
                return;
            case C0470R.id.btnAreaSave:
                Toast.makeText(this, getString(C0470R.string.areaSave), 0).show();
                return;
            default:
                return;
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        if (this.listArea != null && this.listArea.size() > 0 && position >= 0 && position <= this.listArea.size()) {
            AreaInfo areDate = (AreaInfo) this.listArea.get(position);
            String strAreaAll = areDate.getArea();
            String strAreaA = areDate.getCountry();
            this.tvAreaAll.setText(new StringBuilder(String.valueOf(strAreaAll)).toString());
            this.tvAreaA.setText(new StringBuilder(String.valueOf(strAreaA)).toString());
            this.rlAreaList.setVisibility(0);
            this.listViewArea.setVisibility(8);
            this.preferences = getSharedPreferences(GestureEditActivity.PARAM_LOCK_PASSWORD, 0);
            Editor editor = this.preferences.edit();
            editor.putInt(AREA, position);
            editor.commit();
            LocalDefines.areaID = position;
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.listViewArea.getVisibility() == 8) {
                finish();
            } else {
                this.rlAreaList.setVisibility(0);
                this.listViewArea.setVisibility(8);
                this.tvAreaTitle.setText(getString(C0470R.string.areaSelection));
            }
        }
        return false;
    }
}
