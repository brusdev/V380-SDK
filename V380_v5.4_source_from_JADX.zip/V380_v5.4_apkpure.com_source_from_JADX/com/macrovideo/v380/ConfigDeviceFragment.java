package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.materialshowcaseview.MaterialShowcaseView;
import com.macrovideo.materialshowcaseview.MaterialShowcaseView.Builder;
import com.macrovideo.materialshowcaseview.ShowcaseConfig;
import com.macrovideo.sdk.custom.DeviceInfo;
import java.util.ArrayList;
import java.util.HashMap;

@SuppressLint({"ValidFragment"})
public class ConfigDeviceFragment extends Fragment implements OnClickListener, OnItemClickListener {
    private ImageView btnConfigBack;
    private View contentView = null;
    private IntentFilter intentFilter;
    private ImageView ivDeviceCanUpdate;
    private ArrayList<HashMap<String, Object>> listItem;
    private LinearLayout llDeviceConfigListView;
    private LinearLayout llDeviceConfigTitle;
    private ListView lvDeviceConfig;
    private int optOf;
    private PopupWindow popupListView;
    private TabBroadcastReceiver receiver;
    private Activity relateAtivity = null;
    private DeviceInfo serverInfo = new DeviceInfo();
    private ScrollView tlDeviceConfig;
    private LinearLayout trAlarmAndPrompt;
    private LinearLayout trNetwork;
    private LinearLayout trRecord;
    private LinearLayout trStaticIP;
    private LinearLayout trTime;
    private LinearLayout trVersion;
    private TextView tvDeviceConfigListView;

    private class DeviceListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageView ivDeviceSelect;
            TextView tvName;

            private ItemViewHolder() {
            }
        }

        public DeviceListViewAdapter(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.player_back_device_select_item, null);
                this.holder = new ItemViewHolder();
                this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[0]);
                this.holder.ivDeviceSelect = (ImageView) convertView.findViewById(this.valueViewID[1]);
                convertView.setTag(this.holder);
            }
            HashMap<String, Object> map = (HashMap) this.mAppList.get(position);
            if (map != null) {
                if (position == ConfigDeviceFragment.this.optOf) {
                    this.holder.tvName.setTextColor(-16776961);
                    this.holder.ivDeviceSelect.setImageResource(C0470R.drawable.play_back_choose_2);
                } else {
                    this.holder.tvName.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                    this.holder.ivDeviceSelect.setImageResource(C0470R.drawable.play_back_choose_1);
                }
                this.holder.tvName.setText((String) map.get("ItemTitleName"));
            }
            return convertView;
        }
    }

    class TabBroadcastReceiver extends BroadcastReceiver {
        TabBroadcastReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            intent.getAction().equals("TAB1_ACTION");
        }
    }

    public ConfigDeviceFragment(DeviceInfo serverInfo) {
        this.serverInfo = serverInfo;
    }

    public void setServerInfo(DeviceInfo serverInfo) {
        this.serverInfo = serverInfo;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_config, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        InitSubView();
        presentShowcaseSequence();
        return v;
    }

    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(this.receiver);
    }

    public void onResume() {
        super.onResume();
        this.receiver = new TabBroadcastReceiver();
        getActivity().registerReceiver(this.receiver, getIntentFilter());
    }

    public void onDestroy() {
        super.onDestroy();
    }

    private IntentFilter getIntentFilter() {
        if (this.intentFilter == null) {
            this.intentFilter = new IntentFilter();
            this.intentFilter.addAction("TAB1_ACTION");
        }
        return this.intentFilter;
    }

    private void updateDeviceListView() {
        String strDevID = this.tvDeviceConfigListView.getText();
        int devID = 0;
        if (!(strDevID == null || strDevID.length() <= 0 || LocalDefines.DEVICE_MSG == null)) {
            devID = LocalDefines.DEVICE_MSG.getnDevID();
        }
        if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
            if (this.lvDeviceConfig == null) {
                this.lvDeviceConfig = (ListView) ((LinearLayout) View.inflate(getActivity(), C0470R.layout.popup_window_listview, null)).findViewById(C0470R.id.lvDeviceConfig);
            }
            if (this.lvDeviceConfig != null) {
                this.lvDeviceConfig.setAdapter(null);
                return;
            }
            return;
        }
        this.listItem = new ArrayList();
        for (int i = 0; i < LocalDefines._severInfoListData.size(); i++) {
            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
            HashMap<String, Object> map = new HashMap();
            map.put("ItemBtnFace", Integer.valueOf(C0470R.id.item_face));
            map.put("ItemTitleName", info.getStrName());
            map.put("server", info);
            if (devID == info.getnDevID()) {
                this.optOf = i;
            }
            if (info.getnDevID() <= 0) {
                map.put("ItemTitleID", getString(C0470R.string.server) + info.getStrIP());
            } else {
                map.put("ItemTitleID", getString(C0470R.string.strIDNumber) + info.getnDevID() + " " + getString(C0470R.string.server) + info.getStrIP());
            }
            map.put("SID", Integer.valueOf(info.getnID()));
            map.put("SaveType", Integer.valueOf(info.getnSaveType()));
            this.listItem.add(map);
        }
        DeviceListViewAdapter deviceListItemAdapter = new DeviceListViewAdapter(this.relateAtivity, this.listItem, C0470R.layout.player_back_device_select_item, new String[]{"ItemTvDeviceSelect", "ItemIvDeviceSelect"}, new int[]{C0470R.id.tvDeviceSelect, C0470R.id.ivDeviceSelect});
        if (this.lvDeviceConfig == null) {
            this.lvDeviceConfig = (ListView) ((LinearLayout) View.inflate(getActivity(), C0470R.layout.popup_window_listview, null)).findViewById(C0470R.id.lvDeviceConfig);
        }
        if (this.lvDeviceConfig != null) {
            this.lvDeviceConfig.setCacheColorHint(0);
            this.lvDeviceConfig.setAdapter(deviceListItemAdapter);
            this.lvDeviceConfig.setOnItemClickListener(this);
        }
    }

    private void InitSubView() {
        this.llDeviceConfigTitle = (LinearLayout) this.contentView.findViewById(C0470R.id.llDeviceConfigTitle);
        this.llDeviceConfigListView = (LinearLayout) this.contentView.findViewById(C0470R.id.llDeviceConfigListView);
        this.llDeviceConfigListView.setOnClickListener(this);
        LinearLayout view = (LinearLayout) View.inflate(getActivity(), C0470R.layout.popup_window_listview, null);
        this.lvDeviceConfig = (ListView) view.findViewById(C0470R.id.lvDeviceConfig);
        this.popupListView = new PopupWindow(view, -1, -2);
        this.popupListView.setFocusable(true);
        this.popupListView.setOutsideTouchable(true);
        this.popupListView.setAnimationStyle(C0470R.style.popupwindow_device_list);
        this.popupListView.setBackgroundDrawable(new BitmapDrawable());
        this.tvDeviceConfigListView = (TextView) this.contentView.findViewById(C0470R.id.tvDeviceConfigListView);
        if (LocalDefines._severInfoListData != null && LocalDefines._severInfoListData.size() > 0) {
            if (LocalDefines._PlatbackListviewSelectedPosition < 0 || LocalDefines._PlatbackListviewSelectedPosition >= LocalDefines._severInfoListData.size()) {
                LocalDefines._PlatbackListviewSelectedPosition = 0;
            }
            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(LocalDefines._PlatbackListviewSelectedPosition);
            if (!(info == null || this.tvDeviceConfigListView == null)) {
                this.tvDeviceConfigListView.setText(info.getStrName());
                this.serverInfo = info;
                LocalDefines.DEVICE_MSG = info;
            }
        } else if (this.tvDeviceConfigListView != null) {
            this.tvDeviceConfigListView.setText(getString(C0470R.string.noDevice));
        }
        this.tlDeviceConfig = (ScrollView) this.contentView.findViewById(C0470R.id.wifi_id_ap_setting);
        this.btnConfigBack = (ImageView) this.contentView.findViewById(C0470R.id.btnConfigBack);
        this.btnConfigBack.setOnClickListener(this);
        this.trNetwork = (LinearLayout) this.contentView.findViewById(C0470R.id.trConfigNetwork);
        this.trNetwork.setOnClickListener(this);
        this.trRecord = (LinearLayout) this.contentView.findViewById(C0470R.id.trConfigRecord);
        this.trRecord.setOnClickListener(this);
        this.trTime = (LinearLayout) this.contentView.findViewById(C0470R.id.trConfigDataTime);
        this.trTime.setOnClickListener(this);
        this.trVersion = (LinearLayout) this.contentView.findViewById(C0470R.id.trDevVerInfo);
        this.trVersion.setOnClickListener(this);
        this.trAlarmAndPrompt = (LinearLayout) this.contentView.findViewById(C0470R.id.trConfigAlarmAndPrompt);
        this.trAlarmAndPrompt.setOnClickListener(this);
        this.trStaticIP = (LinearLayout) this.contentView.findViewById(C0470R.id.trStaticIP);
        this.trStaticIP.setOnClickListener(this);
        this.ivDeviceCanUpdate = (ImageView) this.contentView.findViewById(C0470R.id.config_iv_device_can_update);
        if (this.serverInfo == null || !this.serverInfo.isCanUpdateDevice()) {
            this.ivDeviceCanUpdate.setVisibility(4);
        } else {
            this.ivDeviceCanUpdate.setVisibility(0);
        }
    }

    public void onClick(View v) {
        if (this.serverInfo != null) {
            LocalDefines.configDeviceInfo = this.serverInfo;
        }
        switch (v.getId()) {
            case C0470R.id.btnConfigBack:
                if (this.popupListView == null || !this.popupListView.isShowing()) {
                    ShowServerList();
                    return;
                } else {
                    this.popupListView.dismiss();
                    return;
                }
            case C0470R.id.llDeviceConfigListView:
                if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
                    Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                    return;
                }
                updateDeviceListView();
                this.popupListView.showAsDropDown(this.llDeviceConfigListView, 0, -10);
                return;
            case C0470R.id.trConfigNetwork:
                if (this.serverInfo != null) {
                    ShowNetworkSetting(this.serverInfo);
                    LocalDefines.bIsConfig = true;
                    return;
                }
                Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                return;
            case C0470R.id.trConfigRecord:
                if (this.serverInfo != null) {
                    ShowRecordSetting(this.serverInfo);
                    LocalDefines.bIsConfig = true;
                    return;
                }
                Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                return;
            case C0470R.id.trConfigDataTime:
                if (this.serverInfo != null) {
                    ShowDateTimeSetting(this.serverInfo);
                    LocalDefines.bIsConfig = true;
                    return;
                }
                Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                return;
            case C0470R.id.trConfigAlarmAndPrompt:
                if (this.serverInfo != null) {
                    ShowAlarmAndPromptSetting(this.serverInfo);
                    LocalDefines.bIsConfig = true;
                    return;
                }
                Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                return;
            case C0470R.id.trStaticIP:
                if (this.serverInfo != null) {
                    ShowStaticIPSetting(this.serverInfo);
                    LocalDefines.bIsConfig = true;
                    return;
                }
                Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                return;
            case C0470R.id.trDevVerInfo:
                if (this.serverInfo != null) {
                    ShowVersionInfo(this.serverInfo);
                    LocalDefines.bIsConfig = true;
                    return;
                }
                Toast.makeText(getActivity(), getString(C0470R.string.noDevice), 0).show();
                return;
            default:
                return;
        }
    }

    private void ShowServerList() {
        ((HomePageActivity) this.relateAtivity).ChangeFragment(13, 10, null);
    }

    private void ShowVersionInfo(DeviceInfo info) {
        ((HomePageActivity) this.relateAtivity).ChangeFragment(13, 18, info);
    }

    private void ShowUserConfigView(DeviceInfo info) {
        ((HomePageActivity) this.relateAtivity).ChangeFragment(13, 17, info);
    }

    private void ShowDateTimeSetting(DeviceInfo info) {
        ((HomePageActivity) this.relateAtivity).ChangeFragment(13, 16, info);
    }

    private void ShowNetworkSetting(DeviceInfo info) {
        ((HomePageActivity) this.relateAtivity).ChangeFragment(13, 14, info);
    }

    private void ShowRecordSetting(DeviceInfo info) {
        ((HomePageActivity) this.relateAtivity).ChangeFragment(13, 15, info);
    }

    private void ShowAlarmAndPromptSetting(DeviceInfo info) {
        ((HomePageActivity) this.relateAtivity).ChangeFragment(13, 19, info);
    }

    private void ShowStaticIPSetting(DeviceInfo info) {
        ((HomePageActivity) this.relateAtivity).ChangeFragment(13, 20, info);
    }

    public void onItemClick(AdapterView<?> adapterView, View arg1, int nSelectIndex, long arg3) {
        HashMap<String, Object> map = new HashMap();
        this.serverInfo = new DeviceInfo();
        map = (HashMap) this.listItem.get(nSelectIndex);
        this.serverInfo = (DeviceInfo) map.get("server");
        LocalDefines.DEVICE_MSG = this.serverInfo;
        this.tvDeviceConfigListView.setText(map.get("ItemTitleName").toString());
        this.popupListView.dismiss();
        if (nSelectIndex >= 0 && nSelectIndex < LocalDefines._severInfoListData.size()) {
            LocalDefines._PlatbackListviewSelectedPosition = nSelectIndex;
        }
        this.ivDeviceCanUpdate.setVisibility(this.serverInfo.isCanUpdateDevice() ? 0 : 4);
    }

    private void presentShowcaseSequence() {
        new ShowcaseConfig().setDelay(0);
        MaterialShowcaseView showcaseView = new Builder(getActivity()).setContentText(getResources().getString(C0470R.string.str_showcase_fra_configdevice1)).setTarget(this.contentView.findViewById(C0470R.id.llDeviceConfigTitle)).withRectangleShape().setDismissOnTouch(true).singleUse("ConfigDeviceFragment").build();
        showcaseView.setContentTextGravity(17);
        showcaseView.setTopImage(C0470R.drawable.guide_t, 17);
        showcaseView.show(getActivity());
    }
}
