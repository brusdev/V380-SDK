package com.macrovideo.v380;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileHelper {
    private String FILESPATH;
    private String SDPATH;
    private Context context;
    private boolean hasSD = false;

    public FileHelper(Context context) {
        this.context = context;
        this.hasSD = Environment.getExternalStorageState().equals("mounted");
        this.SDPATH = Environment.getExternalStorageDirectory().getPath();
        this.FILESPATH = this.context.getFilesDir().getPath();
    }

    public File createSDFile(String fileName) throws IOException {
        File file = new File(this.SDPATH + "//" + fileName);
        if (!file.exists()) {
            file.createNewFile();
        }
        return file;
    }

    public boolean deleteSDFile(String fileName) {
        File file = new File(this.SDPATH + "//" + fileName);
        if (file == null || !file.exists() || file.isDirectory()) {
            return false;
        }
        return file.delete();
    }

    public String readSDFile(String fileName) {
        StringBuffer sb = new StringBuffer();
        try {
            FileInputStream fis = new FileInputStream(new File(this.SDPATH + "//" + fileName));
            while (true) {
                int c = fis.read();
                if (c == -1) {
                    break;
                }
                sb.append((char) c);
            }
            fis.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return sb.toString();
    }

    public String getFILESPATH() {
        return this.FILESPATH;
    }

    public String getSDPATH() {
        return this.SDPATH;
    }

    public boolean hasSD() {
        return this.hasSD;
    }
}
