package com.macrovideo.v380;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.custom.RecordFileInfo;
import com.macrovideo.sdk.objects.ObjectAlarmMessage;
import com.macrovideo.sdk.objects.PTZXPoint;
import java.io.ByteArrayOutputStream;
import org.apache.http.cookie.ClientCookie;

public class DatabaseManager {
    static final CursorFactory CURSOR_FACTORY = null;
    static final String DB_NAME = "macrosee_db";
    static final int DB_VERSION = 12;
    public static final String TABLE_ALARM_MESSAGE = "alarm_picture";
    public static final String TABLE_DEVICE_INFO = "device_info";
    public static final String TABLE_DEVICE_INFO_LOGIN = "device_info2";
    public static final String TABLE_MR_SERVER = "mr_server_info";
    public static final String TABLE_PTZX_FACE = "ptzx_face";
    public static final String TABLE_REC_FILE = "rec_info";
    public static final String TABLE_SERVER_FACE = "server_face";
    static DatabaseHelper databaseHelper = null;
    private static Object lock = new Object();

    public static boolean InitDataBase(Context context) {
        if (databaseHelper == null) {
            databaseHelper = new DatabaseHelper(context, DB_NAME, CURSOR_FACTORY, 12);
        }
        return true;
    }

    public static boolean IsInfoExist(DeviceInfo info) {
        boolean bResult = false;
        if (databaseHelper == null || info == null) {
            return 0;
        }
        SQLiteDatabase database = databaseHelper.getWritableDatabase();
        if (database == null || info == null) {
            return 0;
        }
        String sql;
        if (HomePageActivity.AppMode == 1) {
            sql = "select count(*) from device_info2 where dev_id=" + info.getnDevID();
        } else {
            sql = "select count(*) from device_info where dev_id=" + info.getnDevID();
        }
        try {
            Cursor cursor = database.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                try {
                    cursor.moveToFirst();
                    if (cursor.getInt(0) > 0) {
                        bResult = true;
                    }
                } catch (SQLException e) {
                } catch (Exception e2) {
                }
            }
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (SQLException e3) {
                }
            }
            if (database != null) {
                database.close();
            }
            return bResult;
        } catch (SQLException e4) {
            return 0;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean AddServerInfo(com.macrovideo.sdk.custom.DeviceInfo r10) {
        /*
        r0 = 0;
        r5 = databaseHelper;
        if (r5 == 0) goto L_0x0007;
    L_0x0005:
        if (r10 != 0) goto L_0x0009;
    L_0x0007:
        r1 = r0;
    L_0x0008:
        return r1;
    L_0x0009:
        r6 = lock;
        monitor-enter(r6);
        r5 = databaseHelper;	 Catch:{ all -> 0x01cf }
        r2 = r5.getWritableDatabase();	 Catch:{ all -> 0x01cf }
        if (r2 == 0) goto L_0x0016;
    L_0x0014:
        if (r10 != 0) goto L_0x0019;
    L_0x0016:
        monitor-exit(r6);	 Catch:{ all -> 0x01cf }
        r1 = r0;
        goto L_0x0008;
    L_0x0019:
        r4 = 0;
        r5 = com.macrovideo.v380.HomePageActivity.AppMode;	 Catch:{ all -> 0x01cf }
        r7 = 1;
        if (r5 != r7) goto L_0x00fa;
    L_0x001f:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x01cf }
        r7 = "insert into device_info2 (dev_id, name, ip, port, username, password, domain, save_type, online_stat, online_stat_time, one_key_alarm_state, product_id, synchronization_sign, face) values ('";
        r5.<init>(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnDevID();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrName();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrIP();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnPort();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrUsername();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrPassword();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrDomain();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnSaveType();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnOnLineStat();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r8 = r10.getlOnLineStatChaneTime();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r8);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getIsAlarmOn();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnProductId();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getisSynchronized();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getFaceImage();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "')";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r4 = r5.toString();	 Catch:{ all -> 0x01cf }
    L_0x00ee:
        r2.execSQL(r4);	 Catch:{ SQLException -> 0x01cb }
        r0 = 1;
    L_0x00f2:
        r2.close();	 Catch:{ SQLException -> 0x01d2 }
        r2 = 0;
    L_0x00f6:
        monitor-exit(r6);	 Catch:{ all -> 0x01cf }
        r1 = r0;
        goto L_0x0008;
    L_0x00fa:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x01cf }
        r7 = "insert into device_info (dev_id, name, ip, port, username, password, domain, save_type, online_stat, online_stat_time, one_key_alarm_state, product_id, synchronization_sign, face) values ('";
        r5.<init>(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnDevID();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrName();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrIP();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnPort();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrUsername();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrPassword();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getStrDomain();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnSaveType();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnOnLineStat();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r8 = r10.getlOnLineStatChaneTime();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r8);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getIsAlarmOn();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getnProductId();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getisSynchronized();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "','";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = r10.getFaceImage();	 Catch:{ all -> 0x01cf }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r7 = "')";
        r5 = r5.append(r7);	 Catch:{ all -> 0x01cf }
        r4 = r5.toString();	 Catch:{ all -> 0x01cf }
        goto L_0x00ee;
    L_0x01cb:
        r3 = move-exception;
        r0 = 0;
        goto L_0x00f2;
    L_0x01cf:
        r5 = move-exception;
        monitor-exit(r6);	 Catch:{ all -> 0x01cf }
        throw r5;
    L_0x01d2:
        r5 = move-exception;
        goto L_0x00f6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.macrovideo.v380.DatabaseManager.AddServerInfo(com.macrovideo.sdk.custom.DeviceInfo):boolean");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean modifyServerInfo(com.macrovideo.sdk.custom.DeviceInfo r8) {
        /*
        r0 = 0;
        r5 = databaseHelper;
        if (r5 == 0) goto L_0x0007;
    L_0x0005:
        if (r8 != 0) goto L_0x0009;
    L_0x0007:
        r1 = r0;
    L_0x0008:
        return r1;
    L_0x0009:
        r6 = lock;
        monitor-enter(r6);
        r5 = databaseHelper;	 Catch:{ all -> 0x0137 }
        r2 = r5.getWritableDatabase();	 Catch:{ all -> 0x0137 }
        if (r2 == 0) goto L_0x0016;
    L_0x0014:
        if (r8 != 0) goto L_0x0019;
    L_0x0016:
        monitor-exit(r6);	 Catch:{ all -> 0x0137 }
        r1 = r0;
        goto L_0x0008;
    L_0x0019:
        r4 = 0;
        r5 = com.macrovideo.v380.HomePageActivity.AppMode;	 Catch:{ all -> 0x0137 }
        r7 = 1;
        if (r5 != r7) goto L_0x00ae;
    L_0x001f:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0137 }
        r7 = "update device_info2 set dev_id=";
        r5.<init>(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getnDevID();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = ",name='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrName();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',ip='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrIP();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',port=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getnPort();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = ",username='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrUsername();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',password='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrPassword();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',domain='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrDomain();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',save_type=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getnSaveType();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = " where id=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getnID();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r4 = r5.toString();	 Catch:{ all -> 0x0137 }
    L_0x00a2:
        r2.execSQL(r4);	 Catch:{ SQLException -> 0x0133 }
        r0 = 1;
    L_0x00a6:
        r2.close();	 Catch:{ SQLException -> 0x013a }
        r2 = 0;
    L_0x00aa:
        monitor-exit(r6);	 Catch:{ all -> 0x0137 }
        r1 = r0;
        goto L_0x0008;
    L_0x00ae:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0137 }
        r7 = "update device_info set dev_id=";
        r5.<init>(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getnDevID();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = ",name='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrName();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',ip='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrIP();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',port=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getnPort();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = ",username='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrUsername();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',password='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrPassword();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',domain='";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getStrDomain();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = "',save_type=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getnSaveType();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = " where id=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r7 = r8.getnID();	 Catch:{ all -> 0x0137 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0137 }
        r4 = r5.toString();	 Catch:{ all -> 0x0137 }
        goto L_0x00a2;
    L_0x0133:
        r3 = move-exception;
        r0 = 0;
        goto L_0x00a6;
    L_0x0137:
        r5 = move-exception;
        monitor-exit(r6);	 Catch:{ all -> 0x0137 }
        throw r5;
    L_0x013a:
        r5 = move-exception;
        goto L_0x00aa;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.macrovideo.v380.DatabaseManager.modifyServerInfo(com.macrovideo.sdk.custom.DeviceInfo):boolean");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean UpdateServerInfo(com.macrovideo.sdk.custom.DeviceInfo r10) {
        /*
        r0 = 0;
        r5 = databaseHelper;
        if (r5 == 0) goto L_0x0007;
    L_0x0005:
        if (r10 != 0) goto L_0x0009;
    L_0x0007:
        r1 = r0;
    L_0x0008:
        return r1;
    L_0x0009:
        r6 = lock;
        monitor-enter(r6);
        r5 = databaseHelper;	 Catch:{ all -> 0x015f }
        r2 = r5.getWritableDatabase();	 Catch:{ all -> 0x015f }
        if (r2 == 0) goto L_0x0016;
    L_0x0014:
        if (r10 != 0) goto L_0x0019;
    L_0x0016:
        monitor-exit(r6);	 Catch:{ all -> 0x015f }
        r1 = r0;
        goto L_0x0008;
    L_0x0019:
        r4 = 0;
        r5 = com.macrovideo.v380.HomePageActivity.AppMode;	 Catch:{ all -> 0x015f }
        r7 = 1;
        if (r5 != r7) goto L_0x00c0;
    L_0x001f:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x015f }
        r7 = "update device_info2 set ip='";
        r5.<init>(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getStrIP();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = "',port=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getnPort();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " ,online_stat=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getnOnLineStat();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " ,online_stat_time=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r8 = r10.getlOnLineStatChaneTime();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r8);	 Catch:{ all -> 0x015f }
        r7 = " ,one_key_alarm_state=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getIsAlarmOn();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " ,product_id=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getnProductId();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " ,synchronization_sign=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getisSynchronized();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " where dev_id=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getnDevID();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " and save_type=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = com.macrovideo.v380.LocalDefines.SERVER_SAVE_TYPE_SEARCH;	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r4 = r5.toString();	 Catch:{ all -> 0x015f }
    L_0x00a0:
        r5 = java.lang.System.out;	 Catch:{ all -> 0x015f }
        r7 = new java.lang.StringBuilder;	 Catch:{ all -> 0x015f }
        r8 = "UpdateServerInfo ";
        r7.<init>(r8);	 Catch:{ all -> 0x015f }
        r7 = r7.append(r4);	 Catch:{ all -> 0x015f }
        r7 = r7.toString();	 Catch:{ all -> 0x015f }
        r5.println(r7);	 Catch:{ all -> 0x015f }
        r2.execSQL(r4);	 Catch:{ SQLException -> 0x0143 }
        r0 = 1;
    L_0x00b8:
        r2.close();	 Catch:{ SQLException -> 0x0162 }
        r2 = 0;
    L_0x00bc:
        monitor-exit(r6);	 Catch:{ all -> 0x015f }
        r1 = r0;
        goto L_0x0008;
    L_0x00c0:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x015f }
        r7 = "update device_info set ip='";
        r5.<init>(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getStrIP();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = "',port=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getnPort();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " ,online_stat=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getnOnLineStat();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " ,online_stat_time=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r8 = r10.getlOnLineStatChaneTime();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r8);	 Catch:{ all -> 0x015f }
        r7 = " ,one_key_alarm_state=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getIsAlarmOn();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " ,product_id=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getnProductId();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " ,synchronization_sign=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getisSynchronized();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " where dev_id=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = r10.getnDevID();	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = " and save_type=";
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r7 = com.macrovideo.v380.LocalDefines.SERVER_SAVE_TYPE_SEARCH;	 Catch:{ all -> 0x015f }
        r5 = r5.append(r7);	 Catch:{ all -> 0x015f }
        r4 = r5.toString();	 Catch:{ all -> 0x015f }
        goto L_0x00a0;
    L_0x0143:
        r3 = move-exception;
        r0 = 0;
        r5 = java.lang.System.out;	 Catch:{ all -> 0x015f }
        r7 = new java.lang.StringBuilder;	 Catch:{ all -> 0x015f }
        r8 = "UpdateServerInfo err";
        r7.<init>(r8);	 Catch:{ all -> 0x015f }
        r8 = r3.toString();	 Catch:{ all -> 0x015f }
        r7 = r7.append(r8);	 Catch:{ all -> 0x015f }
        r7 = r7.toString();	 Catch:{ all -> 0x015f }
        r5.println(r7);	 Catch:{ all -> 0x015f }
        goto L_0x00b8;
    L_0x015f:
        r5 = move-exception;
        monitor-exit(r6);	 Catch:{ all -> 0x015f }
        throw r5;
    L_0x0162:
        r5 = move-exception;
        goto L_0x00bc;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.macrovideo.v380.DatabaseManager.UpdateServerInfo(com.macrovideo.sdk.custom.DeviceInfo):boolean");
    }

    public static boolean UpdateServerInfoState(DeviceInfo info) {
        return UpdateServerInfoStateStep(info, false);
    }

    public static boolean UpdateServerInfoStateAndCanUpdateInfo(DeviceInfo info) {
        return UpdateServerInfoStateStep(info, true);
    }

    private static boolean UpdateServerInfoStateStep(DeviceInfo info, boolean changeUpdateDevice) {
        if (!(databaseHelper == null || info == null)) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    try {
                        ContentValues values = new ContentValues();
                        values.put("ip", info.getStrIP());
                        values.put("online_stat", Integer.valueOf(info.getnOnLineStat()));
                        values.put("online_stat_time", Long.valueOf(info.getlOnLineStatChaneTime()));
                        values.put("save_type", Integer.valueOf(info.getnSaveType()));
                        if (changeUpdateDevice) {
                            int i;
                            String str = "can_update";
                            if (info.isCanUpdateDevice()) {
                                i = 1;
                            } else {
                                i = 0;
                            }
                            values.put(str, Integer.valueOf(i));
                        }
                        String[] whereArgs = new String[]{String.valueOf(info.getnDevID())};
                        String whereClause = "dev_id=?";
                        if (HomePageActivity.AppMode == 1) {
                            database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                        } else {
                            database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                        }
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    public static boolean UpdateServerInfoMsgCount(int nDevID, long lLastFreshTime, long lLastGetTime, int nMsgCount, String strUsername, String strPassword) {
        if (databaseHelper == null || nDevID < 0) {
            return false;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database == null) {
                return false;
            }
            try {
                ContentValues values = new ContentValues();
                values.put("last_fresh_time", Long.valueOf(lLastFreshTime));
                values.put("last_get_time", Long.valueOf(lLastGetTime));
                values.put("new_msg_count", Integer.valueOf(nMsgCount));
                String[] whereArgs = new String[]{String.valueOf(nDevID), strUsername, strPassword};
                String whereClause = "dev_id=? and username=? and password=?";
                if (HomePageActivity.AppMode == 1) {
                    database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                } else {
                    database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                }
            } catch (SQLException e) {
            }
            try {
                database.close();
            } catch (SQLException e2) {
            }
            return false;
        }
    }

    public static boolean UpdateServerInfoMsgFreshTime(int nDevID, long lLastFreshTime) {
        if (databaseHelper != null && nDevID >= 0) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    try {
                        ContentValues values = new ContentValues();
                        values.put("last_fresh_time", Long.valueOf(lLastFreshTime));
                        values.put("new_msg_count", Integer.valueOf(1));
                        String[] whereArgs = new String[]{String.valueOf(nDevID)};
                        String whereClause = "dev_id=?";
                        if (HomePageActivity.AppMode == 1) {
                            database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                        } else {
                            database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                        }
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean DeleteServerInfo(com.macrovideo.sdk.custom.DeviceInfo r8) {
        /*
        r0 = 0;
        r5 = databaseHelper;
        if (r5 == 0) goto L_0x0007;
    L_0x0005:
        if (r8 != 0) goto L_0x0009;
    L_0x0007:
        r1 = r0;
    L_0x0008:
        return r1;
    L_0x0009:
        r6 = lock;
        monitor-enter(r6);
        r5 = databaseHelper;	 Catch:{ all -> 0x0054 }
        r2 = r5.getWritableDatabase();	 Catch:{ all -> 0x0054 }
        if (r2 == 0) goto L_0x0016;
    L_0x0014:
        if (r8 != 0) goto L_0x0019;
    L_0x0016:
        monitor-exit(r6);	 Catch:{ all -> 0x0054 }
        r1 = r0;
        goto L_0x0008;
    L_0x0019:
        r4 = 0;
        r5 = com.macrovideo.v380.HomePageActivity.AppMode;	 Catch:{ all -> 0x0054 }
        r7 = 1;
        if (r5 != r7) goto L_0x003d;
    L_0x001f:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0054 }
        r7 = "delete from device_info2 where id=";
        r5.<init>(r7);	 Catch:{ all -> 0x0054 }
        r7 = r8.getnID();	 Catch:{ all -> 0x0054 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0054 }
        r4 = r5.toString();	 Catch:{ all -> 0x0054 }
    L_0x0032:
        r2.execSQL(r4);	 Catch:{ SQLException -> 0x0051 }
        r0 = 1;
    L_0x0036:
        r2.close();	 Catch:{ SQLException -> 0x0057 }
        r2 = 0;
    L_0x003a:
        monitor-exit(r6);	 Catch:{ all -> 0x0054 }
        r1 = r0;
        goto L_0x0008;
    L_0x003d:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0054 }
        r7 = "delete from device_info where id=";
        r5.<init>(r7);	 Catch:{ all -> 0x0054 }
        r7 = r8.getnID();	 Catch:{ all -> 0x0054 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0054 }
        r4 = r5.toString();	 Catch:{ all -> 0x0054 }
        goto L_0x0032;
    L_0x0051:
        r3 = move-exception;
        r0 = 0;
        goto L_0x0036;
    L_0x0054:
        r5 = move-exception;
        monitor-exit(r6);	 Catch:{ all -> 0x0054 }
        throw r5;
    L_0x0057:
        r5 = move-exception;
        goto L_0x003a;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.macrovideo.v380.DatabaseManager.DeleteServerInfo(com.macrovideo.sdk.custom.DeviceInfo):boolean");
    }

    public static boolean ClearServerInfo() {
        boolean bResult = false;
        if (databaseHelper != null) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    String sql;
                    if (HomePageActivity.AppMode == 1) {
                        sql = "delete from device_info2";
                    } else {
                        sql = "delete from device_info";
                    }
                    try {
                        database.execSQL(sql);
                        bResult = true;
                    } catch (SQLException e) {
                        bResult = false;
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return bResult;
    }

    public static boolean setFaceForID(int nID, Bitmap face) {
        if (!(databaseHelper == null || nID < 0 || face == null)) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    try {
                        ByteArrayOutputStream os = new ByteArrayOutputStream();
                        face.compress(CompressFormat.JPEG, 70, os);
                        ContentValues values = new ContentValues();
                        values.put("face", os.toByteArray());
                        String[] whereArgs = new String[]{String.valueOf(nID)};
                        String whereClause = "id=?";
                        if (HomePageActivity.AppMode == 1) {
                            database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                        } else {
                            database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                        }
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    public static boolean setFaceForDevID(int nDevID, Bitmap face, String strUsername, String strPassword) {
        if (!(databaseHelper == null || nDevID < 0 || face == null)) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    try {
                        ByteArrayOutputStream os = new ByteArrayOutputStream();
                        face.compress(CompressFormat.JPEG, 70, os);
                        ContentValues values = new ContentValues();
                        values.put("face", os.toByteArray());
                        String[] whereArgs = new String[]{String.valueOf(nDevID), String.valueOf(strUsername), String.valueOf(strPassword)};
                        String whereClause = " dev_id=? and username=? and password=?";
                        if (HomePageActivity.AppMode == 1) {
                            database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                        } else {
                            database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                        }
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.macrovideo.sdk.custom.DeviceInfo[] GetAllServerInfoWithoutImage() {
        /*
        r44 = 0;
        r33 = 0;
        r3 = databaseHelper;
        if (r3 != 0) goto L_0x000b;
    L_0x0008:
        r44 = 0;
    L_0x000a:
        return r44;
    L_0x000b:
        r48 = lock;
        monitor-enter(r48);
        r3 = databaseHelper;	 Catch:{ all -> 0x0184 }
        r26 = r3.getReadableDatabase();	 Catch:{ all -> 0x0184 }
        if (r26 != 0) goto L_0x001a;
    L_0x0016:
        monitor-exit(r48);	 Catch:{ all -> 0x0184 }
        r44 = 0;
        goto L_0x000a;
    L_0x001a:
        r45 = 0;
        r3 = com.macrovideo.v380.HomePageActivity.AppMode;	 Catch:{ all -> 0x0184 }
        r19 = 1;
        r0 = r19;
        if (r3 != r0) goto L_0x00df;
    L_0x0024:
        r45 = "select * from device_info2 order by id desc";
    L_0x0026:
        r25 = 0;
        r3 = 0;
        r0 = r26;
        r1 = r45;
        r25 = r0.rawQuery(r1, r3);	 Catch:{ SQLException -> 0x00e3 }
        r2 = r25.getCount();	 Catch:{ all -> 0x0184 }
        if (r2 <= 0) goto L_0x00ca;
    L_0x0037:
        r0 = new com.macrovideo.sdk.custom.DeviceInfo[r2];	 Catch:{ all -> 0x0184 }
        r44 = r0;
        r3 = "id";
        r0 = r25;
        r32 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "dev_id";
        r0 = r25;
        r27 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "name";
        r0 = r25;
        r36 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "ip";
        r0 = r25;
        r43 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "port";
        r0 = r25;
        r40 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "username";
        r0 = r25;
        r47 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "password";
        r0 = r25;
        r39 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "domain";
        r0 = r25;
        r28 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "save_type";
        r0 = r25;
        r42 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "new_msg_count";
        r0 = r25;
        r37 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "last_fresh_time";
        r0 = r25;
        r34 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "last_get_time";
        r0 = r25;
        r35 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "face";
        r0 = r25;
        r30 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "one_key_alarm_state";
        r0 = r25;
        r38 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "product_id";
        r0 = r25;
        r41 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r3 = "synchronization_sign";
        r0 = r25;
        r46 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x0184 }
        r31 = 0;
        r25.moveToFirst();	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
    L_0x00c0:
        r3 = r25.isAfterLast();	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        if (r3 != 0) goto L_0x00ca;
    L_0x00c6:
        r0 = r31;
        if (r0 < r2) goto L_0x00e9;
    L_0x00ca:
        if (r25 == 0) goto L_0x00d1;
    L_0x00cc:
        r25.close();	 Catch:{ SQLException -> 0x017f }
        r25 = 0;
    L_0x00d1:
        if (r26 == 0) goto L_0x00d8;
    L_0x00d3:
        r26.close();	 Catch:{ SQLException -> 0x017f }
        r26 = 0;
    L_0x00d8:
        monitor-exit(r48);	 Catch:{ all -> 0x0184 }
        if (r33 == 0) goto L_0x000a;
    L_0x00db:
        r44 = 0;
        goto L_0x000a;
    L_0x00df:
        r45 = "select * from device_info order by id desc";
        goto L_0x0026;
    L_0x00e3:
        r29 = move-exception;
        monitor-exit(r48);	 Catch:{ all -> 0x0184 }
        r44 = 0;
        goto L_0x000a;
    L_0x00e9:
        r0 = r25;
        r1 = r32;
        r4 = r0.getInt(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r27;
        r5 = r0.getInt(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r36;
        r6 = r0.getString(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r43;
        r7 = r0.getString(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r40;
        r8 = r0.getInt(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r47;
        r9 = r0.getString(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r39;
        r10 = r0.getString(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r28;
        r11 = r0.getString(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r42;
        r13 = r0.getInt(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r37;
        r18 = r0.getInt(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r34;
        r14 = r0.getLong(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r35;
        r16 = r0.getLong(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r38;
        r12 = r0.getInt(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r41;
        r23 = r0.getInt(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r0 = r25;
        r1 = r46;
        r24 = r0.getInt(r1);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r3 = new com.macrovideo.sdk.custom.DeviceInfo;	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r19 = 0;
        r20 = 0;
        r22 = 0;
        r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r16, r18, r19, r20, r22, r23, r24);	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r44[r31] = r3;	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        r31 = r31 + 1;
        r25.moveToNext();	 Catch:{ SQLException -> 0x0175, Exception -> 0x017a }
        goto L_0x00c0;
    L_0x0175:
        r29 = move-exception;
        r33 = 1;
        goto L_0x00ca;
    L_0x017a:
        r29 = move-exception;
        r33 = 1;
        goto L_0x00ca;
    L_0x017f:
        r29 = move-exception;
        r33 = 1;
        goto L_0x00d8;
    L_0x0184:
        r3 = move-exception;
        monitor-exit(r48);	 Catch:{ all -> 0x0184 }
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.macrovideo.v380.DatabaseManager.GetAllServerInfoWithoutImage():com.macrovideo.sdk.custom.DeviceInfo[]");
    }

    public static DeviceInfo GetServerInfo(int DevID) {
        DeviceInfo serverList = null;
        boolean isErr = false;
        if (databaseHelper == null) {
            return null;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getReadableDatabase();
            if (database == null) {
                return null;
            }
            String sql;
            Cursor cursor;
            if (HomePageActivity.AppMode == 1) {
                sql = "select * from device_info2 where dev_id=" + DevID;
            } else {
                sql = "select * from device_info where dev_id=" + DevID;
            }
            try {
                cursor = database.rawQuery(sql, null);
                int count = cursor.getCount();
                if (count > 0) {
                    DeviceInfo serverList2 = new DeviceInfo();
                    try {
                        int idIndex = cursor.getColumnIndex("id");
                        int devIdIndex = cursor.getColumnIndex("dev_id");
                        int nameIndex = cursor.getColumnIndex("name");
                        int serverIndex = cursor.getColumnIndex("ip");
                        int portIndex = cursor.getColumnIndex(ClientCookie.PORT_ATTR);
                        int usernameIndex = cursor.getColumnIndex("username");
                        int passwordIndex = cursor.getColumnIndex("password");
                        int domainIndex = cursor.getColumnIndex(ClientCookie.DOMAIN_ATTR);
                        int saveTypeIndex = cursor.getColumnIndex("save_type");
                        int newMsgCountIndex = cursor.getColumnIndex("new_msg_count");
                        int lastFreshIndex = cursor.getColumnIndex("last_fresh_time");
                        int lastGetIndex = cursor.getColumnIndex("last_get_time");
                        int faceIndex = cursor.getColumnIndex("face");
                        int one_key_alarm_state_index = cursor.getColumnIndex("one_key_alarm_state");
                        int product_id_index = cursor.getColumnIndex("product_id");
                        int synchronization_sign_index = cursor.getColumnIndex("synchronization_sign");
                        int i = 0;
                        try {
                            cursor.moveToFirst();
                            while (!cursor.isAfterLast()) {
                                if (i >= count) {
                                    serverList = serverList2;
                                    break;
                                }
                                int nID = cursor.getInt(idIndex);
                                int nDevID = cursor.getInt(devIdIndex);
                                String strName = cursor.getString(nameIndex);
                                String strServer = cursor.getString(serverIndex);
                                int nPort = cursor.getInt(portIndex);
                                String strUsername = cursor.getString(usernameIndex);
                                String strPassword = cursor.getString(passwordIndex);
                                String strDomain = cursor.getString(domainIndex);
                                int nSaveType = cursor.getInt(saveTypeIndex);
                                int nNewMsgCount = cursor.getInt(newMsgCountIndex);
                                long lLastFreshTime = cursor.getLong(lastFreshIndex);
                                long lGetFreshTime = cursor.getLong(lastGetIndex);
                                int one_key_alarm_state = cursor.getInt(one_key_alarm_state_index);
                                int product_id = cursor.getInt(product_id_index);
                                int synchronization_sign = cursor.getInt(synchronization_sign_index);
                                byte[] faceData = cursor.getBlob(faceIndex);
                                Bitmap faceImage = null;
                                if (faceData != null && faceData.length > 256) {
                                    try {
                                        faceImage = BitmapFactory.decodeByteArray(faceData, 0, faceData.length);
                                    } catch (OutOfMemoryError e) {
                                        faceImage = null;
                                    }
                                }
                                serverList = new DeviceInfo(nID, nDevID, strName, "192.168.1.1", nPort, strUsername, strPassword, strDomain, one_key_alarm_state, nSaveType, lLastFreshTime, lGetFreshTime, nNewMsgCount, 0, 0, faceImage, product_id, synchronization_sign);
                                i++;
                                try {
                                    cursor.moveToNext();
                                    serverList2 = serverList;
                                } catch (SQLException e2) {
                                } catch (Exception e3) {
                                }
                            }
                            serverList = serverList2;
                        } catch (SQLException e4) {
                            serverList = serverList2;
                        } catch (Exception e5) {
                            serverList = serverList2;
                        }
                    } catch (Throwable th) {
                        Throwable th2 = th;
                        serverList = serverList2;
                        throw th2;
                    }
                }
                if (cursor != null) {
                    try {
                        cursor.close();
                    } catch (SQLException e6) {
                        isErr = true;
                    }
                }
                if (database != null) {
                    database.close();
                }
            } catch (SQLException e7) {
                return null;
            } catch (Throwable th3) {
                th2 = th3;
                throw th2;
            }
        }
        isErr = true;
        if (cursor != null) {
            cursor.close();
        }
        if (database != null) {
            database.close();
        }
        if (isErr) {
            return serverList;
        }
        return null;
        isErr = true;
        if (cursor != null) {
            cursor.close();
        }
        if (database != null) {
            database.close();
        }
        if (isErr) {
            return serverList;
        }
        return null;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.macrovideo.sdk.custom.DeviceInfo[] GetAllServerInfo() {
        /*
        r51 = 0;
        r36 = 0;
        r3 = databaseHelper;
        if (r3 != 0) goto L_0x000b;
    L_0x0008:
        r51 = 0;
    L_0x000a:
        return r51;
    L_0x000b:
        r55 = lock;
        monitor-enter(r55);
        r3 = databaseHelper;	 Catch:{ all -> 0x01fd }
        r28 = r3.getReadableDatabase();	 Catch:{ all -> 0x01fd }
        if (r28 != 0) goto L_0x001a;
    L_0x0016:
        monitor-exit(r55);	 Catch:{ all -> 0x01fd }
        r51 = 0;
        goto L_0x000a;
    L_0x001a:
        r52 = 0;
        r3 = com.macrovideo.v380.HomePageActivity.AppMode;	 Catch:{ all -> 0x01fd }
        r56 = 1;
        r0 = r56;
        if (r3 != r0) goto L_0x00ff;
    L_0x0024:
        r52 = "select * from device_info2 order by id desc";
    L_0x0026:
        r27 = 0;
        r3 = 0;
        r0 = r28;
        r1 = r52;
        r27 = r0.rawQuery(r1, r3);	 Catch:{ SQLException -> 0x0103 }
        r26 = r27.getCount();	 Catch:{ all -> 0x01fd }
        if (r26 <= 0) goto L_0x01f4;
    L_0x0037:
        r0 = r26;
        r0 = new com.macrovideo.sdk.custom.DeviceInfo[r0];	 Catch:{ all -> 0x01fd }
        r51 = r0;
        r3 = "id";
        r0 = r27;
        r35 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "dev_id";
        r0 = r27;
        r29 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "name";
        r0 = r27;
        r41 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "ip";
        r0 = r27;
        r50 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "port";
        r0 = r27;
        r47 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "username";
        r0 = r27;
        r54 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "password";
        r0 = r27;
        r46 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "domain";
        r0 = r27;
        r30 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "save_type";
        r0 = r27;
        r49 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "new_msg_count";
        r0 = r27;
        r42 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "last_fresh_time";
        r0 = r27;
        r37 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "last_get_time";
        r0 = r27;
        r40 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "online_stat";
        r0 = r27;
        r44 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "online_stat_time";
        r0 = r27;
        r45 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "face";
        r0 = r27;
        r33 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "one_key_alarm_state";
        r0 = r27;
        r43 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "product_id";
        r0 = r27;
        r48 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "can_update";
        r0 = r27;
        r25 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r3 = "synchronization_sign";
        r0 = r27;
        r53 = r0.getColumnIndex(r3);	 Catch:{ all -> 0x01fd }
        r38 = java.lang.System.currentTimeMillis();	 Catch:{ all -> 0x01fd }
        r34 = 0;
        r27.moveToFirst();	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
    L_0x00de:
        r3 = r27.isAfterLast();	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        if (r3 != 0) goto L_0x00ea;
    L_0x00e4:
        r0 = r34;
        r1 = r26;
        if (r0 < r1) goto L_0x0109;
    L_0x00ea:
        if (r27 == 0) goto L_0x00f1;
    L_0x00ec:
        r27.close();	 Catch:{ SQLException -> 0x01f8 }
        r27 = 0;
    L_0x00f1:
        if (r28 == 0) goto L_0x00f8;
    L_0x00f3:
        r28.close();	 Catch:{ SQLException -> 0x01f8 }
        r28 = 0;
    L_0x00f8:
        monitor-exit(r55);	 Catch:{ all -> 0x01fd }
        if (r36 == 0) goto L_0x000a;
    L_0x00fb:
        r51 = 0;
        goto L_0x000a;
    L_0x00ff:
        r52 = "select * from device_info order by id desc";
        goto L_0x0026;
    L_0x0103:
        r31 = move-exception;
        monitor-exit(r55);	 Catch:{ all -> 0x01fd }
        r51 = 0;
        goto L_0x000a;
    L_0x0109:
        r0 = r27;
        r1 = r35;
        r4 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r29;
        r5 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r41;
        r6 = r0.getString(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r50;
        r7 = r0.getString(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r47;
        r8 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r54;
        r9 = r0.getString(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r46;
        r10 = r0.getString(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r30;
        r11 = r0.getString(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r49;
        r13 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r42;
        r18 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r37;
        r14 = r0.getLong(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r40;
        r16 = r0.getLong(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r44;
        r19 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r45;
        r20 = r0.getLong(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r43;
        r12 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r48;
        r23 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r25;
        r2 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r0 = r27;
        r1 = r53;
        r24 = r0.getInt(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r56 = r38 - r20;
        r58 = 50000; // 0xc350 float:7.0065E-41 double:2.47033E-319;
        r3 = (r56 > r58 ? 1 : (r56 == r58 ? 0 : -1));
        if (r3 < 0) goto L_0x01a6;
    L_0x01a2:
        r20 = 0;
        r19 = 0;
    L_0x01a6:
        r0 = r27;
        r1 = r33;
        r32 = r0.getBlob(r1);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r22 = 0;
        if (r32 == 0) goto L_0x01c9;
    L_0x01b2:
        r0 = r32;
        r3 = r0.length;	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r56 = 256; // 0x100 float:3.59E-43 double:1.265E-321;
        r0 = r56;
        if (r3 <= r0) goto L_0x01c9;
    L_0x01bb:
        r3 = 0;
        r0 = r32;
        r0 = r0.length;	 Catch:{ OutOfMemoryError -> 0x01e9 }
        r56 = r0;
        r0 = r32;
        r1 = r56;
        r22 = android.graphics.BitmapFactory.decodeByteArray(r0, r3, r1);	 Catch:{ OutOfMemoryError -> 0x01e9 }
    L_0x01c9:
        r3 = new com.macrovideo.sdk.custom.DeviceInfo;	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r16, r18, r19, r20, r22, r23, r24);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r51[r34] = r3;	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r56 = r51[r34];	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r3 = 1;
        if (r2 != r3) goto L_0x01ed;
    L_0x01d5:
        r3 = 1;
    L_0x01d6:
        r0 = r56;
        r0.setCanUpdateDevice(r3);	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        r32 = 0;
        r34 = r34 + 1;
        r27.moveToNext();	 Catch:{ SQLException -> 0x01e4, Exception -> 0x01ef }
        goto L_0x00de;
    L_0x01e4:
        r31 = move-exception;
        r36 = 1;
        goto L_0x00ea;
    L_0x01e9:
        r31 = move-exception;
        r22 = 0;
        goto L_0x01c9;
    L_0x01ed:
        r3 = 0;
        goto L_0x01d6;
    L_0x01ef:
        r31 = move-exception;
        r36 = 1;
        goto L_0x00ea;
    L_0x01f4:
        r51 = 0;
        goto L_0x00ea;
    L_0x01f8:
        r31 = move-exception;
        r36 = 1;
        goto L_0x00f8;
    L_0x01fd:
        r3 = move-exception;
        monitor-exit(r55);	 Catch:{ all -> 0x01fd }
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.macrovideo.v380.DatabaseManager.GetAllServerInfo():com.macrovideo.sdk.custom.DeviceInfo[]");
    }

    public static DeviceInfo[] GetServerInfos(int count) {
        DeviceInfo[] serverList = null;
        if (databaseHelper == null) {
            return null;
        }
        SQLiteDatabase database = databaseHelper.getReadableDatabase();
        if (database == null) {
            return null;
        }
        String sql;
        if (HomePageActivity.AppMode == 1) {
            sql = "select  *  from device_info2 order by id desc limit " + count;
        } else {
            sql = "select  *  from device_info order by id desc limit " + count;
        }
        try {
            Cursor cursor = database.rawQuery(sql, null);
            int maxCount = cursor.getCount();
            if (maxCount < count) {
                count = maxCount;
            }
            if (count > 0) {
                serverList = new DeviceInfo[count];
                int idIndex = cursor.getColumnIndex("id");
                int devIdIndex = cursor.getColumnIndex("dev_id");
                int nameIndex = cursor.getColumnIndex("name");
                int serverIndex = cursor.getColumnIndex("ip");
                int portIndex = cursor.getColumnIndex(ClientCookie.PORT_ATTR);
                int usernameIndex = cursor.getColumnIndex("username");
                int passwordIndex = cursor.getColumnIndex("password");
                int domainIndex = cursor.getColumnIndex(ClientCookie.DOMAIN_ATTR);
                int saveTypeIndex = cursor.getColumnIndex("save_type");
                int faceIndex = cursor.getColumnIndex("face");
                int i = 0;
                try {
                    cursor.moveToFirst();
                    while (!cursor.isAfterLast() && i < count) {
                        int nID = cursor.getInt(idIndex);
                        int nDevID = cursor.getInt(devIdIndex);
                        String strName = cursor.getString(nameIndex);
                        String strServer = cursor.getString(serverIndex);
                        int nPort = cursor.getInt(portIndex);
                        String strUsername = cursor.getString(usernameIndex);
                        String strPassword = cursor.getString(passwordIndex);
                        String strDomain = cursor.getString(domainIndex);
                        int nSaveType = cursor.getInt(saveTypeIndex);
                        byte[] faceData = cursor.getBlob(faceIndex);
                        Bitmap faceImage = null;
                        if (faceData != null && faceData.length > 256) {
                            try {
                                faceImage = BitmapFactory.decodeByteArray(faceData, 0, faceData.length);
                            } catch (OutOfMemoryError e) {
                                faceImage = null;
                            }
                        }
                        serverList[i] = new DeviceInfo(nID, nDevID, strName, strServer, nPort, strUsername, strPassword, strDomain, nSaveType, faceImage);
                        i++;
                        cursor.moveToNext();
                    }
                } catch (SQLException e2) {
                } catch (Exception e3) {
                }
            }
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (SQLException e4) {
                }
            }
            if (database != null) {
                database.close();
            }
            return serverList;
        } catch (SQLException e5) {
            return null;
        }
    }

    public static DeviceInfo GetServerInfoByID(int nId) {
        if (databaseHelper == null) {
            DeviceInfo serverinfo = null;
            return null;
        }
        SQLiteDatabase database = databaseHelper.getReadableDatabase();
        if (database == null) {
            serverinfo = null;
            return null;
        }
        String sql;
        if (HomePageActivity.AppMode == 1) {
            sql = "select * from device_info2 where dev_id=" + nId;
        } else {
            sql = "select * from device_info where dev_id=" + nId;
        }
        try {
            Cursor cursor = database.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                int idIndex = cursor.getColumnIndex("id");
                int devIdIndex = cursor.getColumnIndex("dev_id");
                int nameIndex = cursor.getColumnIndex("name");
                int serverIndex = cursor.getColumnIndex("ip");
                int portIndex = cursor.getColumnIndex(ClientCookie.PORT_ATTR);
                int usernameIndex = cursor.getColumnIndex("username");
                int passwordIndex = cursor.getColumnIndex("password");
                int domainIndex = cursor.getColumnIndex(ClientCookie.DOMAIN_ATTR);
                int saveTypeIndex = cursor.getColumnIndex("save_type");
                int faceIndex = cursor.getColumnIndex("face");
                try {
                    cursor.moveToFirst();
                    if (!cursor.isAfterLast()) {
                        int nID = cursor.getInt(idIndex);
                        int nDevID = cursor.getInt(devIdIndex);
                        String strName = cursor.getString(nameIndex);
                        String strServer = cursor.getString(serverIndex);
                        int nPort = cursor.getInt(portIndex);
                        String strUsername = cursor.getString(usernameIndex);
                        String strPassword = cursor.getString(passwordIndex);
                        String strDomain = cursor.getString(domainIndex);
                        int nSaveType = cursor.getInt(saveTypeIndex);
                        byte[] faceData = cursor.getBlob(faceIndex);
                        Bitmap faceImage = null;
                        if (faceData != null && faceData.length > 256) {
                            try {
                                faceImage = BitmapFactory.decodeByteArray(faceData, 0, faceData.length);
                            } catch (OutOfMemoryError e) {
                                faceImage = null;
                            }
                        }
                        serverinfo = new DeviceInfo(nID, nDevID, strName, strServer, nPort, strUsername, strPassword, strDomain, nSaveType, faceImage);
                        if (cursor != null) {
                            try {
                                cursor.close();
                            } catch (SQLException e2) {
                            }
                        }
                        if (database != null) {
                            database.close();
                        }
                        return serverinfo;
                    }
                } catch (SQLException e3) {
                    serverinfo = null;
                } catch (Exception e4) {
                    serverinfo = null;
                }
            }
            serverinfo = null;
            if (cursor != null) {
                cursor.close();
            }
            if (database != null) {
                database.close();
            }
            return serverinfo;
        } catch (SQLException e5) {
            serverinfo = null;
            return null;
        }
    }

    public static boolean ClearRecInfos() {
        boolean bResult = false;
        if (databaseHelper != null) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database != null) {
                try {
                    database.execSQL("delete from rec_info");
                    bResult = true;
                } catch (SQLException e) {
                    bResult = false;
                }
                database.close();
            }
        }
        return bResult;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int SaveRecInfos(java.util.ArrayList<com.macrovideo.sdk.custom.RecordFileInfo> r11) {
        /*
        r5 = 0;
        r8 = databaseHelper;
        if (r8 == 0) goto L_0x000d;
    L_0x0005:
        if (r11 == 0) goto L_0x000d;
    L_0x0007:
        r8 = r11.size();
        if (r8 > 0) goto L_0x000f;
    L_0x000d:
        r6 = r5;
    L_0x000e:
        return r6;
    L_0x000f:
        r9 = lock;
        monitor-enter(r9);
        r8 = databaseHelper;	 Catch:{ all -> 0x00c3 }
        r1 = r8.getWritableDatabase();	 Catch:{ all -> 0x00c3 }
        if (r1 == 0) goto L_0x001c;
    L_0x001a:
        if (r11 != 0) goto L_0x001f;
    L_0x001c:
        monitor-exit(r9);	 Catch:{ all -> 0x00c3 }
        r6 = r5;
        goto L_0x000e;
    L_0x001f:
        r1.beginTransaction();	 Catch:{ all -> 0x00c3 }
        r4 = 0;
        r8 = r11.size();	 Catch:{ all -> 0x00be }
        r3 = r8 + -1;
    L_0x0029:
        if (r3 >= 0) goto L_0x003a;
    L_0x002b:
        r1.setTransactionSuccessful();	 Catch:{ all -> 0x00be }
        r1.endTransaction();	 Catch:{ all -> 0x00c3 }
        if (r1 == 0) goto L_0x0037;
    L_0x0033:
        r1.close();	 Catch:{ SQLException -> 0x00c6 }
        r1 = 0;
    L_0x0037:
        monitor-exit(r9);	 Catch:{ all -> 0x00c3 }
        r6 = r5;
        goto L_0x000e;
    L_0x003a:
        r8 = r11.get(r3);	 Catch:{ all -> 0x00be }
        r0 = r8;
        r0 = (com.macrovideo.sdk.custom.RecordFileInfo) r0;	 Catch:{ all -> 0x00be }
        r4 = r0;
        if (r4 == 0) goto L_0x00b6;
    L_0x0044:
        r8 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00be }
        r10 = "insert into rec_info (file_id, file_size, name, start_hour, start_min, start_sec, file_time_len) values ('";
        r8.<init>(r10);	 Catch:{ all -> 0x00be }
        r10 = r4.getnFileID();	 Catch:{ all -> 0x00be }
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = "','";
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = r4.getnFileSize();	 Catch:{ all -> 0x00be }
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = "','";
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = r4.getStrFileName();	 Catch:{ all -> 0x00be }
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = "','";
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = r4.getuStartHour();	 Catch:{ all -> 0x00be }
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = "','";
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = r4.getuStartMin();	 Catch:{ all -> 0x00be }
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = "','";
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = r4.getuStartSec();	 Catch:{ all -> 0x00be }
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = "','";
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = r4.getuFileTimeLen();	 Catch:{ all -> 0x00be }
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r10 = "')";
        r8 = r8.append(r10);	 Catch:{ all -> 0x00be }
        r7 = r8.toString();	 Catch:{ all -> 0x00be }
        r1.execSQL(r7);	 Catch:{ SQLException -> 0x00bb }
        r5 = r5 + 1;
    L_0x00b6:
        r4 = 0;
        r3 = r3 + -1;
        goto L_0x0029;
    L_0x00bb:
        r2 = move-exception;
        goto L_0x002b;
    L_0x00be:
        r8 = move-exception;
        r1.endTransaction();	 Catch:{ all -> 0x00c3 }
        throw r8;	 Catch:{ all -> 0x00c3 }
    L_0x00c3:
        r8 = move-exception;
        monitor-exit(r9);	 Catch:{ all -> 0x00c3 }
        throw r8;
    L_0x00c6:
        r8 = move-exception;
        goto L_0x0037;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.macrovideo.v380.DatabaseManager.SaveRecInfos(java.util.ArrayList):int");
    }

    public static RecordFileInfo[] GetAllRecInfo() {
        RecordFileInfo[] recFileList = null;
        if (databaseHelper == null) {
            return null;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getReadableDatabase();
            if (database == null) {
                return null;
            }
            try {
                Cursor cursor = database.rawQuery("select * from rec_info order by id desc", null);
                int count = cursor.getCount();
                if (count > 0) {
                    recFileList = new RecordFileInfo[count];
                    int idIndex = cursor.getColumnIndex("id");
                    int fileIdIndex = cursor.getColumnIndex("file_id");
                    int fileSizeIndex = cursor.getColumnIndex("file_size");
                    int nameIndex = cursor.getColumnIndex("name");
                    int startHourIndex = cursor.getColumnIndex("start_hour");
                    int startMinIndex = cursor.getColumnIndex("start_min");
                    int startSecIndex = cursor.getColumnIndex("start_sec");
                    int timeLenIndex = cursor.getColumnIndex("file_time_len");
                    int i = 0;
                    try {
                        cursor.moveToFirst();
                        while (!cursor.isAfterLast() && i < count) {
                            int nID = cursor.getInt(idIndex);
                            recFileList[i] = new RecordFileInfo(cursor.getInt(fileIdIndex), cursor.getInt(fileSizeIndex), cursor.getInt(startHourIndex), cursor.getInt(startMinIndex), cursor.getInt(startSecIndex), cursor.getInt(timeLenIndex), cursor.getString(nameIndex));
                            i++;
                            cursor.moveToNext();
                        }
                    } catch (SQLException e) {
                    } catch (Exception e2) {
                    }
                }
                if (cursor != null) {
                    try {
                        cursor.close();
                    } catch (SQLException e3) {
                    }
                }
                if (database != null) {
                    database.close();
                }
                return recFileList;
            } catch (SQLException e4) {
                return null;
            }
        }
    }

    public static boolean IsMRServerExist(MRServerInfo info) {
        boolean bResult = false;
        if (databaseHelper == null || info == null) {
            return 0;
        }
        SQLiteDatabase database = databaseHelper.getWritableDatabase();
        if (database == null || info == null) {
            return 0;
        }
        String sql;
        if (HomePageActivity.AppMode == 1) {
            sql = "select count(*) from device_info2 where server_id=" + info.getnServerID();
        } else {
            sql = "select count(*) from device_info where server_id=" + info.getnServerID();
        }
        try {
            Cursor cursor = database.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                try {
                    cursor.moveToFirst();
                    if (cursor.getInt(0) > 0) {
                        bResult = true;
                    }
                } catch (SQLException e) {
                } catch (Exception e2) {
                }
            }
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (SQLException e3) {
                }
            }
            if (database != null) {
                database.close();
            }
            return bResult;
        } catch (SQLException e4) {
            return 0;
        }
    }

    public static boolean AddMRServerInfo(MRServerInfo info) {
        if (databaseHelper == null || info == null) {
            return 0;
        }
        SQLiteDatabase database = databaseHelper.getWritableDatabase();
        if (database == null || info == null) {
            return 0;
        }
        boolean bResult;
        int isInit = 0;
        if (info.isbIsInit()) {
            isInit = 1;
        }
        try {
            database.execSQL("insert into mr_server_info (server_id, is_init, init_time, domain, ip) values ('" + info.getnServerID() + "','" + isInit + "','" + info.getlInitTime() + "','" + info.getStrDomain() + "','" + info.getStrIP() + "')");
            bResult = true;
        } catch (SQLException e) {
            bResult = false;
        }
        database.close();
        return bResult;
    }

    public static boolean modifyMRServerInfo(MRServerInfo info) {
        if (databaseHelper == null || info == null) {
            return 0;
        }
        SQLiteDatabase database = databaseHelper.getWritableDatabase();
        if (database == null || info == null) {
            return 0;
        }
        boolean bResult;
        int isInit = 0;
        if (info.isbIsInit()) {
            isInit = 1;
        }
        try {
            database.execSQL("update mr_server_info set is_init=" + isInit + ",init_time=" + info.getlInitTime() + ",domain='" + info.getStrDomain() + "',ip='" + info.getStrIP() + "' where server_id=" + info.getnServerID());
            bResult = true;
        } catch (SQLException e) {
            bResult = false;
        }
        database.close();
        return bResult;
    }

    public static MRServerInfo[] GetALLMRServer() {
        MRServerInfo[] serverList = null;
        if (databaseHelper == null) {
            return null;
        }
        SQLiteDatabase database = databaseHelper.getReadableDatabase();
        if (database == null) {
            return null;
        }
        try {
            Cursor cursor = database.rawQuery("select * from mr_server_info order by id desc", null);
            int count = cursor.getCount();
            if (count > 0) {
                serverList = new MRServerInfo[count];
                int idIndex = cursor.getColumnIndex("id");
                int serverIdIndex = cursor.getColumnIndex("server_id");
                int isInitIndex = cursor.getColumnIndex("is_init");
                int initTimeIndex = cursor.getColumnIndex("init_time");
                int domainIndex = cursor.getColumnIndex(ClientCookie.DOMAIN_ATTR);
                int ipIndex = cursor.getColumnIndex("ip");
                int i = 0;
                try {
                    cursor.moveToFirst();
                    while (!cursor.isAfterLast() && i < count) {
                        int nID = cursor.getInt(idIndex);
                        int nServerID = cursor.getInt(serverIdIndex);
                        int nIsInit = cursor.getInt(isInitIndex);
                        long lInitTime = cursor.getLong(initTimeIndex);
                        String strDomain = cursor.getString(domainIndex);
                        String strIP = cursor.getString(ipIndex);
                        boolean isInit = false;
                        if (nIsInit == 1) {
                            isInit = true;
                        }
                        serverList[i] = new MRServerInfo(nID, nServerID, isInit, lInitTime, strDomain, strIP);
                        i++;
                        cursor.moveToNext();
                    }
                } catch (SQLException e) {
                } catch (Exception e2) {
                }
            }
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (SQLException e3) {
                    return serverList;
                }
            }
            if (database == null) {
                return serverList;
            }
            database.close();
            return serverList;
        } catch (SQLException e4) {
            return null;
        }
    }

    public static boolean ClearMRServerInfo() {
        boolean bResult = false;
        if (databaseHelper != null) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database != null) {
                try {
                    database.execSQL("delete from mr_server_info");
                    bResult = true;
                } catch (SQLException e) {
                    bResult = false;
                }
                database.close();
            }
        }
        return bResult;
    }

    public static boolean DeleteServerFace(int nServerID) {
        if (databaseHelper == null) {
            return 0;
        }
        SQLiteDatabase database = databaseHelper.getWritableDatabase();
        if (database == null) {
            return 0;
        }
        boolean bResult;
        try {
            database.execSQL("delete from server_face where server_id=" + nServerID);
            bResult = true;
        } catch (SQLException e) {
            bResult = false;
        }
        database.close();
        return bResult;
    }

    public static boolean ClearServerFace(int nServerID) {
        if (databaseHelper == null) {
            return 0;
        }
        SQLiteDatabase database = databaseHelper.getWritableDatabase();
        if (database == null) {
            return 0;
        }
        boolean bResult;
        try {
            database.execSQL("delete from server_face");
            bResult = true;
        } catch (SQLException e) {
            bResult = false;
        }
        database.close();
        return bResult;
    }

    public static boolean isAlarmMessageExistQueryBySaveId(int saveId, int deviceId) {
        boolean bResult = false;
        if (databaseHelper == null) {
            return 0;
        }
        SQLiteDatabase database = databaseHelper.getWritableDatabase();
        if (database == null) {
            return 0;
        }
        try {
            Cursor cursor = database.rawQuery("select count(*) from alarm_picture where save_id=" + saveId + " and dev_id=" + deviceId, null);
            if (cursor.getCount() > 0) {
                try {
                    cursor.moveToFirst();
                    if (cursor.getInt(0) > 0) {
                        bResult = true;
                    }
                } catch (SQLException e) {
                } catch (Exception e2) {
                }
            }
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (SQLException e3) {
                }
            }
            if (database != null) {
                database.close();
            }
            return bResult;
        } catch (SQLException e4) {
            return 0;
        }
    }

    public static ObjectAlarmMessage getAlarmMessageBySaveId(int save_id, int device_id) {
        Throwable th;
        if (databaseHelper == null) {
            ObjectAlarmMessage alarmMessage = null;
            return null;
        }
        SQLiteDatabase database = databaseHelper.getReadableDatabase();
        if (database == null) {
            alarmMessage = null;
            return null;
        }
        synchronized (lock) {
            try {
                try {
                    Cursor cursor = database.rawQuery("select * from alarm_picture where save_id=" + save_id + " and dev_id=" + device_id, null);
                    if (cursor.getCount() > 0) {
                        int idIndex = cursor.getColumnIndex("id");
                        int saveIndex = cursor.getColumnIndex("save_id");
                        int alarmIndex = cursor.getColumnIndex("alarm_id");
                        int devIndex = cursor.getColumnIndex("dev_id");
                        int alarmTypeIndex = cursor.getColumnIndex("alarm_type");
                        int alarmLevelIndex = cursor.getColumnIndex("alarm_level");
                        int alarmMsgIndex = cursor.getColumnIndex("alarm_msg");
                        int alarmTimeIndex = cursor.getColumnIndex("alarm_time");
                        int saveTimeIndex = cursor.getColumnIndex("save_time");
                        int imageIndex = cursor.getColumnIndex("image");
                        int strAlarmImageIndex = cursor.getColumnIndex("str_alarm_image");
                        int strImageIpIndex = cursor.getColumnIndex("str_image_ip");
                        int hasPositionIndex = cursor.getColumnIndex("has_position");
                        try {
                            cursor.moveToFirst();
                            int nID = cursor.getInt(idIndex);
                            int nSaveID = cursor.getInt(saveIndex);
                            int nAlarmID = cursor.getInt(alarmIndex);
                            int nDevID = cursor.getInt(devIndex);
                            int nAlarmType = cursor.getInt(alarmTypeIndex);
                            int nAlarmLevel = cursor.getInt(alarmLevelIndex);
                            String strAlarmMsg = cursor.getString(alarmMsgIndex);
                            String stAlarmTime = cursor.getString(alarmTimeIndex);
                            long lSaveTime = cursor.getLong(saveTimeIndex);
                            String strAlarmImage = cursor.getString(strAlarmImageIndex);
                            String strImageIp = cursor.getString(strImageIpIndex);
                            boolean bHasPosition = false;
                            if (cursor.getInt(hasPositionIndex) == 1) {
                                bHasPosition = true;
                            }
                            byte[] imageData = cursor.getBlob(imageIndex);
                            Bitmap image = null;
                            if (imageData != null && imageData.length > 256) {
                                try {
                                    Options options = new Options();
                                    options.inPreferredConfig = Config.RGB_565;
                                    image = BitmapFactory.decodeByteArray(imageData, 0, imageData.length, options);
                                } catch (OutOfMemoryError e) {
                                    image = null;
                                }
                            }
                            alarmMessage = new ObjectAlarmMessage(nID, nSaveID, nAlarmID, nDevID, nAlarmType, nAlarmLevel, strAlarmMsg, stAlarmTime, lSaveTime, strAlarmImage, strImageIp, bHasPosition);
                            try {
                                alarmMessage.setImage(image);
                            } catch (SQLException e2) {
                            } catch (Exception e3) {
                            }
                        } catch (SQLException e4) {
                            alarmMessage = null;
                        } catch (Exception e5) {
                            alarmMessage = null;
                        }
                    } else {
                        alarmMessage = null;
                    }
                    if (cursor != null) {
                        try {
                            cursor.close();
                        } catch (SQLException e6) {
                        }
                    }
                    if (database != null) {
                        database.close();
                    }
                } catch (SQLException e7) {
                    alarmMessage = null;
                    return null;
                }
                try {
                    return alarmMessage;
                } catch (Throwable th2) {
                    th = th2;
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                alarmMessage = null;
                throw th;
            }
        }
    }

    public static boolean AddAlarmMessage(ObjectAlarmMessage info) {
        boolean bResult = false;
        if (databaseHelper == null || info == null) {
            return 0;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database == null) {
                return 0;
            }
            try {
                ContentValues values = new ContentValues();
                Bitmap image = info.getImage();
                if (image != null) {
                    ByteArrayOutputStream os = new ByteArrayOutputStream();
                    image.compress(CompressFormat.JPEG, 70, os);
                    values.put("image", os.toByteArray());
                }
                values.put("save_id", Integer.valueOf(info.getnSaveID()));
                values.put("alarm_id", Integer.valueOf(info.getnAlarmID()));
                values.put("dev_id", Integer.valueOf(info.getnDevID()));
                values.put("alarm_type", Integer.valueOf(info.getnAlarmType()));
                values.put("alarm_level", Integer.valueOf(info.getnAlarmLevel()));
                values.put("alarm_msg", info.getStrAlarmMsg());
                values.put("alarm_time", info.getStrAlarmTime());
                values.put("save_time", Long.valueOf(info.getLSaveTime()));
                values.put("str_alarm_image", info.getStrAlarmImage());
                values.put("str_image_ip", info.getStrImageIp());
                int nHasPosition = 0;
                if (info.getbHasPosition()) {
                    nHasPosition = 1;
                }
                values.put("has_position", Integer.valueOf(nHasPosition));
                if (database.insert(TABLE_ALARM_MESSAGE, null, values) != -1) {
                    bResult = true;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
                database.close();
            } catch (SQLException e) {
            }
            return bResult;
        }
    }

    public static ObjectAlarmMessage[] GetAlarmMessage() {
        ObjectAlarmMessage[] messageList = null;
        if (databaseHelper == null) {
            return null;
        }
        SQLiteDatabase database = databaseHelper.getReadableDatabase();
        if (database == null) {
            return null;
        }
        synchronized (lock) {
            try {
                Cursor cursor = database.rawQuery("select * from alarm_picture order by id desc", null);
                int count = cursor.getCount();
                if (count > 0) {
                    messageList = new ObjectAlarmMessage[count];
                    int idIndex = cursor.getColumnIndex("id");
                    int saveIndex = cursor.getColumnIndex("save_id");
                    int alarmIndex = cursor.getColumnIndex("alarm_id");
                    int devIndex = cursor.getColumnIndex("dev_id");
                    int alarmTypeIndex = cursor.getColumnIndex("alarm_type");
                    int alarmLevelIndex = cursor.getColumnIndex("alarm_level");
                    int alarmMsgIndex = cursor.getColumnIndex("alarm_msg");
                    int alarmTimeIndex = cursor.getColumnIndex("alarm_time");
                    int saveTimeIndex = cursor.getColumnIndex("save_time");
                    int imageIndex = cursor.getColumnIndex("image");
                    int strAlarmImageIndex = cursor.getColumnIndex("str_alarm_image");
                    int strImageIpIndex = cursor.getColumnIndex("str_image_ip");
                    int hasPositionIndex = cursor.getColumnIndex("has_position");
                    int i = 0;
                    try {
                        cursor.moveToFirst();
                        while (!cursor.isAfterLast() && i < count) {
                            int nID = cursor.getInt(idIndex);
                            int nSaveID = cursor.getInt(saveIndex);
                            int nAlarmID = cursor.getInt(alarmIndex);
                            int nDevID = cursor.getInt(devIndex);
                            int nAlarmType = cursor.getInt(alarmTypeIndex);
                            int nAlarmLevel = cursor.getInt(alarmLevelIndex);
                            String strAlarmMsg = cursor.getString(alarmMsgIndex);
                            String stAlarmTime = cursor.getString(alarmTimeIndex);
                            long lSaveTime = cursor.getLong(saveTimeIndex);
                            String strAlarmImage = cursor.getString(strAlarmImageIndex);
                            String strImageIp = cursor.getString(strImageIpIndex);
                            boolean bHasPosition = false;
                            if (cursor.getInt(hasPositionIndex) == 1) {
                                bHasPosition = true;
                            }
                            byte[] imageData = cursor.getBlob(imageIndex);
                            Bitmap image = null;
                            if (imageData != null && imageData.length > 256) {
                                try {
                                    Options options = new Options();
                                    options.inPreferredConfig = Config.RGB_565;
                                    image = BitmapFactory.decodeByteArray(imageData, 0, imageData.length, options);
                                } catch (OutOfMemoryError e) {
                                    image = null;
                                }
                            }
                            messageList[i] = new ObjectAlarmMessage(nID, nSaveID, nAlarmID, nDevID, nAlarmType, nAlarmLevel, strAlarmMsg, stAlarmTime, lSaveTime, strAlarmImage, strImageIp, bHasPosition);
                            messageList[i].setImage(image);
                            i++;
                            cursor.moveToNext();
                        }
                    } catch (SQLException e2) {
                    } catch (Exception e3) {
                    }
                }
                if (cursor != null) {
                    try {
                        cursor.close();
                    } catch (SQLException e4) {
                    }
                }
                if (database != null) {
                    database.close();
                }
            } catch (SQLException e5) {
                return null;
            }
        }
        return messageList;
    }

    public static ObjectAlarmMessage[] GetAlarmMessage(int nDevID, int nCount, long lStartTime, long lEndTime) {
        ObjectAlarmMessage[] messageList = null;
        if (databaseHelper == null) {
            return null;
        }
        SQLiteDatabase database = databaseHelper.getReadableDatabase();
        if (database == null) {
            return null;
        }
        try {
            Cursor cursor = database.rawQuery("select * from alarm_picture where dev_id=" + nDevID + " and save_time>" + lStartTime + " and save_time<" + lEndTime + " order by save_time desc limit " + nCount, null);
            int count = cursor.getCount();
            if (count > 0) {
                messageList = new ObjectAlarmMessage[count];
                int idIndex = cursor.getColumnIndex("id");
                int saveIndex = cursor.getColumnIndex("save_id");
                int alarmIndex = cursor.getColumnIndex("alarm_id");
                int devIndex = cursor.getColumnIndex("dev_id");
                int alarmTypeIndex = cursor.getColumnIndex("alarm_type");
                int alarmLevelIndex = cursor.getColumnIndex("alarm_level");
                int alarmMsgIndex = cursor.getColumnIndex("alarm_msg");
                int alarmTimeIndex = cursor.getColumnIndex("alarm_time");
                int saveTimeIndex = cursor.getColumnIndex("save_time");
                int imageIndex = cursor.getColumnIndex("image");
                int strAlarmImgaeIndex = cursor.getColumnIndex("str_alarm_image");
                int strImageIpIndex = cursor.getColumnIndex("str_image_ip");
                int hasPositionIndex = cursor.getColumnIndex("has_position");
                int i = 0;
                try {
                    cursor.moveToFirst();
                    while (!cursor.isAfterLast() && i < count) {
                        int nID = cursor.getInt(idIndex);
                        int nSaveID = cursor.getInt(saveIndex);
                        int nAlarmID = cursor.getInt(alarmIndex);
                        int nDeviceID = cursor.getInt(devIndex);
                        int nAlarmType = cursor.getInt(alarmTypeIndex);
                        int nAlarmLevel = cursor.getInt(alarmLevelIndex);
                        String strAlarmMsg = cursor.getString(alarmMsgIndex);
                        String strAlarmTime = cursor.getString(alarmTimeIndex);
                        long lSaveTime = cursor.getLong(saveTimeIndex);
                        String strAlarmImage = cursor.getString(strAlarmImgaeIndex);
                        String strImageIp = cursor.getString(strImageIpIndex);
                        boolean bHasPosition = false;
                        if (cursor.getInt(hasPositionIndex) == 1) {
                            bHasPosition = true;
                        }
                        byte[] imageData = cursor.getBlob(imageIndex);
                        Bitmap image = null;
                        if (imageData != null && imageData.length > 256) {
                            try {
                                Options options = new Options();
                                options.inPreferredConfig = Config.RGB_565;
                                image = BitmapFactory.decodeByteArray(imageData, 0, imageData.length, options);
                            } catch (OutOfMemoryError e) {
                                image = null;
                            }
                        }
                        messageList[i] = new ObjectAlarmMessage(nID, nSaveID, nAlarmID, nDeviceID, nAlarmType, nAlarmLevel, strAlarmMsg, strAlarmTime, lSaveTime, image, strAlarmImage, strImageIp, bHasPosition);
                        i++;
                        cursor.moveToNext();
                    }
                } catch (SQLException e2) {
                } catch (Exception e3) {
                }
            }
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (SQLException e4) {
                }
            }
            if (database != null) {
                database.close();
            }
            return messageList;
        } catch (SQLException e5) {
            return null;
        }
    }

    public static boolean ClearAlarmMessage() {
        boolean bResult = false;
        if (databaseHelper != null) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database != null) {
                try {
                    database.execSQL("delete from alarm_picture");
                    bResult = true;
                } catch (SQLException e) {
                    bResult = false;
                }
                database.close();
            }
        }
        return bResult;
    }

    public static boolean UpdateAlarmMessageImage(Bitmap image, int nDevID, int nAlarmID, String strAlarmImage) {
        if (!(databaseHelper == null || nDevID < 0 || image == null)) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    try {
                        ByteArrayOutputStream os = new ByteArrayOutputStream();
                        image.compress(CompressFormat.JPEG, 70, os);
                        ContentValues values = new ContentValues();
                        values.put("image", os.toByteArray());
                        values.put("str_alarm_image", strAlarmImage);
                        String[] whereArgs = new String[]{String.valueOf(nDevID), String.valueOf(nAlarmID)};
                        database.update(TABLE_ALARM_MESSAGE, values, " dev_id=? and alarm_id=?", whereArgs);
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    public static boolean IsPTZXExit(int nDevID, int nPTZXID) {
        boolean bResult = false;
        if (databaseHelper == null || nDevID <= 0 || nPTZXID < 0) {
            return 0;
        }
        SQLiteDatabase database = databaseHelper.getWritableDatabase();
        if (database == null) {
            return 0;
        }
        try {
            Cursor cursor = database.rawQuery("select count(*) from ptzx_face where dev_id=" + nDevID + " and ptzx_id=" + nPTZXID, null);
            if (cursor.getCount() > 0) {
                try {
                    cursor.moveToFirst();
                    if (cursor.getInt(0) > 0) {
                        bResult = true;
                    }
                } catch (SQLException e) {
                } catch (Exception e2) {
                }
            }
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (SQLException e3) {
                }
            }
            if (database != null) {
                database.close();
            }
            return bResult;
        } catch (SQLException e4) {
            return 0;
        }
    }

    public static boolean AddPTZXInfo(PTZXPoint ptzx) {
        if (databaseHelper == null || ptzx == null) {
            return 0;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database == null) {
                return 0;
            }
            boolean bResult;
            try {
                database.execSQL("insert into ptzx_face (dev_id,ptzx_id,save_time,image) values ('" + ptzx.getnDevID() + "','" + ptzx.getnPTZXID() + "','" + ptzx.getlSaveTime() + "','" + ptzx.getFaceImage() + "')");
                bResult = true;
            } catch (SQLException e) {
                bResult = false;
            }
            try {
                database.close();
            } catch (SQLException e2) {
            }
            return bResult;
        }
    }

    public static boolean setPTZXFaceForDevID(int nDevID, int nPTZXID, Bitmap image) {
        if (!(databaseHelper == null || nDevID <= 0 || image == null)) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    try {
                        ByteArrayOutputStream os = new ByteArrayOutputStream();
                        image.compress(CompressFormat.JPEG, 70, os);
                        ContentValues values = new ContentValues();
                        values.put("face", os.toByteArray());
                        String[] whereArgs = new String[]{String.valueOf(nDevID), String.valueOf(nPTZXID)};
                        database.update(TABLE_PTZX_FACE, values, " dev_id=? and and ptzx_id=?", whereArgs);
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    public static boolean updatePTZXPoint(PTZXPoint ptzx) {
        if (!(databaseHelper == null || ptzx == null || ptzx.getFaceImage() == null)) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    try {
                        ByteArrayOutputStream os = new ByteArrayOutputStream();
                        ptzx.getFaceImage().compress(CompressFormat.JPEG, 70, os);
                        ContentValues values = new ContentValues();
                        values.put("image", os.toByteArray());
                        String[] whereArgs = new String[]{String.valueOf(ptzx.getnDevID()), String.valueOf(ptzx.getnPTZXID())};
                        database.update(TABLE_PTZX_FACE, values, " dev_id=? and ptzx_id=?", whereArgs);
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    public static PTZXPoint[] GetPTZXInfos(int nDevID) {
        PTZXPoint[] ptzxPoints = null;
        if (databaseHelper == null) {
            return null;
        }
        SQLiteDatabase database = databaseHelper.getReadableDatabase();
        if (database == null) {
            return null;
        }
        try {
            Cursor cursor = database.rawQuery("select * from ptzx_face where dev_id=" + nDevID, null);
            int nCount = cursor.getCount();
            if (nCount > 0) {
                ptzxPoints = new PTZXPoint[nCount];
                int idIndex = cursor.getColumnIndex("id");
                int ptzxIndex = cursor.getColumnIndex("ptzx_id");
                int saveTimeIndex = cursor.getColumnIndex("save_time");
                int faceIndex = cursor.getColumnIndex("image");
                int i = 0;
                try {
                    cursor.moveToFirst();
                    while (!cursor.isAfterLast() && i < nCount) {
                        int nID = cursor.getInt(idIndex);
                        int nPTZXID = cursor.getInt(ptzxIndex);
                        long lSaveTime = cursor.getLong(saveTimeIndex);
                        byte[] faceData = cursor.getBlob(faceIndex);
                        Bitmap faceImage = null;
                        if (faceData != null && faceData.length > 256) {
                            try {
                                faceImage = BitmapFactory.decodeByteArray(faceData, 0, faceData.length);
                            } catch (OutOfMemoryError e) {
                                faceImage = null;
                            }
                        }
                        ptzxPoints[i] = new PTZXPoint(nID, nDevID, nPTZXID, lSaveTime, faceImage);
                        i++;
                        cursor.moveToNext();
                    }
                } catch (SQLException e2) {
                } catch (Exception e3) {
                }
            }
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (SQLException e4) {
                }
            }
            if (database != null) {
                database.close();
            }
            return ptzxPoints;
        } catch (SQLException e5) {
            return null;
        }
    }

    public static boolean ClearPTZXInfo(int nDevID) {
        if (databaseHelper == null) {
            return 0;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database == null) {
                return 0;
            }
            boolean bResult;
            try {
                database.execSQL("delete from ptzx_face where dev_id=" + nDevID);
                bResult = true;
            } catch (SQLException e) {
                bResult = false;
            }
            try {
                database.close();
            } catch (SQLException e2) {
            }
            return bResult;
        }
    }

    public static boolean updateServerInfoOneKeyAlarmSetting(int deviceId, boolean alarmState) {
        if (databaseHelper != null) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    int oneKeyAlarmState;
                    if (alarmState) {
                        oneKeyAlarmState = 2;
                    } else {
                        oneKeyAlarmState = 1;
                    }
                    try {
                        ContentValues values = new ContentValues();
                        values.put("one_key_alarm_state", Integer.valueOf(oneKeyAlarmState));
                        String[] whereArgs = new String[]{String.valueOf(deviceId)};
                        String whereClause = "dev_id=?";
                        if (HomePageActivity.AppMode == 1) {
                            database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                        } else {
                            database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                        }
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    public static boolean updateServerInfoOneKeyDeviceAlarmAndPromptSetting(int deviceId, boolean alarmState) {
        if (databaseHelper != null) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    int oneKeyAlarmState;
                    if (alarmState) {
                        oneKeyAlarmState = 20;
                    } else {
                        oneKeyAlarmState = 10;
                    }
                    try {
                        ContentValues values = new ContentValues();
                        values.put("one_key_alarm_state", Integer.valueOf(oneKeyAlarmState));
                        String[] whereArgs = new String[]{String.valueOf(deviceId)};
                        String whereClause = "dev_id=?";
                        if (HomePageActivity.AppMode == 1) {
                            database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                        } else {
                            database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                        }
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    public static int getServerInfoOneKeyAlarmState(DeviceInfo info) {
        int bResult = 0;
        if (databaseHelper == null || info == null) {
            return 0;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database == null) {
                return 0;
            }
            String sql;
            if (HomePageActivity.AppMode == 1) {
                sql = "select one_key_alarm_state from device_info2 where dev_id=" + info.getnDevID();
            } else {
                sql = "select one_key_alarm_state from device_info where dev_id=" + info.getnDevID();
            }
            try {
                Cursor cursor = database.rawQuery(sql, null);
                if (cursor.getCount() > 0) {
                    int oneKeyAlarmStateIndex = cursor.getColumnIndex("one_key_alarm_state");
                    cursor.moveToFirst();
                    bResult = cursor.getInt(oneKeyAlarmStateIndex);
                }
                if (cursor != null) {
                    try {
                        cursor.close();
                    } catch (SQLException e) {
                    }
                }
                if (database != null) {
                    database.close();
                }
                return bResult;
            } catch (SQLException e2) {
                return 0;
            }
        }
    }

    public static boolean UpdateServerInfoStateWithAlarmState(DeviceInfo info) {
        return UpdateServerInfoStateWithAlarmStateStep(info, false);
    }

    public static boolean UpdateServerInfoStateWithAlarmStateAndCanUpdateInfo(DeviceInfo info) {
        return UpdateServerInfoStateWithAlarmStateStep(info, true);
    }

    public static boolean UpdateServerInfoStateWithAlarmStateStep(DeviceInfo info, boolean changeUpdateInfo) {
        if (!(databaseHelper == null || info == null)) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    try {
                        ContentValues values = new ContentValues();
                        values.put("ip", info.getStrIP());
                        values.put("online_stat", Integer.valueOf(info.getnOnLineStat()));
                        values.put("online_stat_time", Long.valueOf(info.getlOnLineStatChaneTime()));
                        values.put("save_type", Integer.valueOf(info.getnSaveType()));
                        if (changeUpdateInfo) {
                            int i;
                            String str = "can_update";
                            if (info.isCanUpdateDevice()) {
                                i = 1;
                            } else {
                                i = 0;
                            }
                            values.put(str, Integer.valueOf(i));
                        }
                        values.put("one_key_alarm_state", Integer.valueOf(info.getIsAlarmOn()));
                        String[] whereArgs = new String[]{String.valueOf(info.getnDevID())};
                        String whereClause = "dev_id=?";
                        if (HomePageActivity.AppMode == 1) {
                            database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                        } else {
                            database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                        }
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    public static int getProductId(DeviceInfo info) {
        int bResult = 0;
        if (databaseHelper == null || info == null) {
            return 0;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database == null) {
                return 0;
            }
            String sql;
            if (HomePageActivity.AppMode == 1) {
                sql = "select product_id from device_info2 where dev_id=" + info.getnDevID();
            } else {
                sql = "select product_id from device_info where dev_id=" + info.getnDevID();
            }
            try {
                Cursor cursor = database.rawQuery(sql, null);
                if (cursor.getCount() > 0) {
                    int product_id = cursor.getColumnIndex("product_id");
                    cursor.moveToFirst();
                    bResult = cursor.getInt(product_id);
                }
                if (cursor != null) {
                    try {
                        cursor.close();
                    } catch (SQLException e) {
                    }
                }
                if (database != null) {
                    database.close();
                }
                return bResult;
            } catch (SQLException e2) {
                return 0;
            }
        }
    }

    public static boolean updateProductId(DeviceInfo info) {
        if (databaseHelper == null || info == null) {
            return 0;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database == null) {
                return 0;
            }
            boolean bResult;
            try {
                ContentValues values = new ContentValues();
                if (HomePageActivity.AppMode == 1) {
                    values.put("product_id", Integer.valueOf(info.getnProductId()));
                } else {
                    values.put("product_id", Integer.valueOf(0));
                }
                String[] whereArgs = new String[]{String.valueOf(info.getnDevID())};
                String whereClause = "dev_id=?";
                if (HomePageActivity.AppMode == 1) {
                    database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                } else {
                    database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                }
                bResult = true;
            } catch (SQLException e) {
                bResult = false;
            }
            try {
                database.close();
            } catch (SQLException e2) {
            }
            return bResult;
        }
    }

    public static boolean updateUserDeviceListFromGet(DeviceInfo info) {
        if (!(databaseHelper == null || info == null)) {
            synchronized (lock) {
                SQLiteDatabase database = databaseHelper.getWritableDatabase();
                if (database == null) {
                } else {
                    try {
                        ContentValues values = new ContentValues();
                        values.put("username", info.getStrUsername());
                        values.put("password", info.getStrPassword());
                        values.put("product_id", Integer.valueOf(info.getnProductId()));
                        String[] whereArgs = new String[]{String.valueOf(info.getnDevID())};
                        String whereClause = "dev_id=?";
                        if (HomePageActivity.AppMode == 1) {
                            database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                        } else {
                            database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                        }
                    } catch (SQLException e) {
                    }
                    try {
                        database.close();
                    } catch (SQLException e2) {
                    }
                }
            }
        }
        return false;
    }

    public static int getSynchronizedCode(int DeviceID) {
        int bResult = -1;
        if (databaseHelper == null) {
            return -1;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database == null) {
                return -1;
            }
            String sql;
            if (HomePageActivity.AppMode == 1) {
                sql = "select synchronization_sign from device_info2 where dev_id=" + DeviceID;
            } else {
                sql = "select synchronization_sign from device_info where dev_id=" + DeviceID;
            }
            try {
                Cursor cursor = database.rawQuery(sql, null);
                if (cursor.getCount() > 0) {
                    int Synchronization_Sign = cursor.getColumnIndex("synchronization_sign");
                    cursor.moveToFirst();
                    bResult = cursor.getInt(Synchronization_Sign);
                }
                if (cursor != null) {
                    try {
                        cursor.close();
                    } catch (SQLException e) {
                    }
                }
                if (database != null) {
                    database.close();
                }
                System.out.println("getSynchronizedCode " + bResult);
                return bResult;
            } catch (SQLException e2) {
                return 0;
            }
        }
    }

    public static boolean updateSynchronizedCode(int DeviceID, int code) {
        if (databaseHelper == null) {
            return 0;
        }
        synchronized (lock) {
            SQLiteDatabase database = databaseHelper.getWritableDatabase();
            if (database == null) {
                return 0;
            }
            boolean bResult;
            try {
                ContentValues values = new ContentValues();
                if (HomePageActivity.AppMode == 1) {
                    values.put("synchronization_sign", Integer.valueOf(code));
                } else {
                    values.put("synchronization_sign", Integer.valueOf(0));
                }
                String[] whereArgs = new String[]{String.valueOf(DeviceID)};
                String whereClause = "dev_id=?";
                if (HomePageActivity.AppMode == 1) {
                    database.update(TABLE_DEVICE_INFO_LOGIN, values, whereClause, whereArgs);
                } else {
                    database.update(TABLE_DEVICE_INFO, values, whereClause, whereArgs);
                }
                bResult = true;
            } catch (SQLException e) {
                bResult = false;
            }
            try {
                database.close();
            } catch (SQLException e2) {
            }
            return bResult;
        }
    }
}
