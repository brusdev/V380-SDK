package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.objects.ObjectUserInfo;
import com.macrovideo.sdk.setting.AccountInfo;
import com.macrovideo.sdk.setting.DeviceAccountMessageSetting;
import com.tencent.android.tpush.common.Constants;

@SuppressLint({"ValidFragment"})
public class DeviceAccountSettingFragment extends Fragment implements OnClickListener {
    public static final int HANDLE_MSG_CODE_GET_USER_RESULT = 144;
    public static final int HANDLE_MSG_CODE_SET_USER_RESULT = 256;
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    private ImageView btnUserBack;
    private Button btnUserSave;
    private LinearLayout cbModifyPassword = null;
    private ImageView cbModifyPasswordCheckbox = null;
    private View contentView = null;
    private EditText etConfirmPassword = null;
    private EditText etNewPassword = null;
    private EditText etOldPassword = null;
    private EditText etUsername = null;
    private Handler handler = new C02791();
    private IntentFilter intentFilter;
    private boolean isActive = false;
    private boolean isGetFinish = false;
    private Dialog loadingDialog;
    private View loadingView;
    private boolean mIsNeedFresh = true;
    private int mLoadType = 1;
    private DeviceInfo mServerInfo = null;
    private boolean m_bModifyPassword = false;
    private int m_nUserInfoID = 0;
    private int nUserID = 0;
    private TabBroadcastReceiver receiver;
    private Activity relateAtivity = null;
    private String strNewPassword = null;
    private String strNewUsername = null;
    ObjectUserInfo userInfo = new ObjectUserInfo();

    class C02791 extends Handler {
        C02791() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            if (DeviceAccountSettingFragment.this.isActive) {
                DeviceAccountSettingFragment.this.mIsNeedFresh = false;
                Bundle data;
                AccountInfo accountHandler;
                if (msg.arg1 == 256) {
                    DeviceAccountSettingFragment.this.loadingDialog.dismiss();
                    DeviceAccountSettingFragment.this.btnUserSave.setEnabled(true);
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_NetError));
                            return;
                        case 256:
                            data = msg.getData();
                            if (data == null) {
                                DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_BadResult), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_BadResult));
                                return;
                            }
                            accountHandler = (AccountInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                            DeviceAccountSettingFragment.this.userInfo.setnUID(accountHandler.getnUserID());
                            DeviceAccountSettingFragment.this.userInfo.setStrUsername(DeviceAccountSettingFragment.this.strNewUsername);
                            DeviceAccountSettingFragment.this.userInfo.setStrPassword(DeviceAccountSettingFragment.this.strNewPassword);
                            DeviceAccountSettingFragment.this.btnUserSave.setEnabled(true);
                            if (!(DeviceAccountSettingFragment.this.mServerInfo == null || DeviceAccountSettingFragment.this.userInfo == null)) {
                                DeviceAccountSettingFragment.this.mServerInfo.setStrUsername(accountHandler.getStrUserName());
                                DeviceAccountSettingFragment.this.mServerInfo.setStrPassword(accountHandler.getStrPassword());
                                DatabaseManager.modifyServerInfo(DeviceAccountSettingFragment.this.mServerInfo);
                            }
                            DeviceAccountSettingFragment.this.onSaveAndBack(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_ok), Constants.MAIN_VERSION_TAG);
                            return;
                        default:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            return;
                    }
                } else if (msg.arg1 == 144) {
                    DeviceAccountSettingFragment.this.loadingDialog.dismiss();
                    DeviceAccountSettingFragment.this.btnUserSave.setEnabled(true);
                    String strUsername = Constants.MAIN_VERSION_TAG;
                    String strPassword = Constants.MAIN_VERSION_TAG;
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            DeviceAccountSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            DeviceAccountSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            DeviceAccountSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            DeviceAccountSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_NetError));
                            DeviceAccountSettingFragment.this.ShowConfigSetting();
                            return;
                        case 256:
                            DeviceAccountSettingFragment.this.btnUserSave.setEnabled(true);
                            data = msg.getData();
                            if (data == null) {
                                DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_BadResult), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_BadResult));
                                return;
                            }
                            DeviceAccountSettingFragment.this.isGetFinish = true;
                            accountHandler = (AccountInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                            strUsername = accountHandler.getStrUserName();
                            strPassword = accountHandler.getStrPassword();
                            int nUID = accountHandler.getnUserID();
                            DeviceAccountSettingFragment.this.nUserID = nUID;
                            DeviceAccountSettingFragment.this.userInfo.setnUID(nUID);
                            DeviceAccountSettingFragment.this.userInfo.setStrUsername(strUsername);
                            DeviceAccountSettingFragment.this.userInfo.setStrPassword(strPassword);
                            DeviceAccountSettingFragment.this.etUsername.setText(strUsername);
                            DeviceAccountSettingFragment.this.etOldPassword.setText(Constants.MAIN_VERSION_TAG);
                            DeviceAccountSettingFragment.this.etNewPassword.setText(Constants.MAIN_VERSION_TAG);
                            DeviceAccountSettingFragment.this.etConfirmPassword.setText(Constants.MAIN_VERSION_TAG);
                            return;
                        default:
                            DeviceAccountSettingFragment.this.ShowAlert(DeviceAccountSettingFragment.this.getString(C0470R.string.alert_get_config_fail), DeviceAccountSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            DeviceAccountSettingFragment.this.ShowConfigSetting();
                            return;
                    }
                }
            }
        }
    }

    class C02802 implements OnShowListener {
        C02802() {
        }

        public void onShow(DialogInterface dialog) {
            TextView tv = (TextView) DeviceAccountSettingFragment.this.loadingView.findViewById(C0470R.id.loginText);
            if (DeviceAccountSettingFragment.this.mLoadType == 1) {
                tv.setText(DeviceAccountSettingFragment.this.getString(C0470R.string.loading));
            } else if (DeviceAccountSettingFragment.this.mLoadType == 2) {
                tv.setText(DeviceAccountSettingFragment.this.getString(C0470R.string.str_saving));
            }
        }
    }

    class C02813 implements OnDismissListener {
        C02813() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class TabBroadcastReceiver extends BroadcastReceiver {
        TabBroadcastReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            intent.getAction().equals("TAB1_ACTION");
        }
    }

    private class UserConfigThread extends Thread {
        static final int OP_TYPE_GET = 10;
        static final int OP_TYPE_SET = 11;
        DeviceInfo info;
        private String m_newPassword;
        private String m_newUsername;
        private int nOPType;

        public UserConfigThread(DeviceInfo info) {
            this.m_newUsername = "admin";
            this.m_newPassword = "admin";
            this.info = null;
            this.nOPType = 10;
            this.nOPType = 10;
            this.info = info;
        }

        public UserConfigThread(String newUsername, String newPassword, DeviceInfo info) {
            this.m_newUsername = "admin";
            this.m_newPassword = "admin";
            this.info = null;
            this.nOPType = 10;
            this.nOPType = 11;
            this.m_newUsername = newUsername;
            this.m_newPassword = newPassword;
            this.info = info;
        }

        public void run() {
            AccountInfo deviceParam;
            Message msg;
            Bundle data;
            if (this.nOPType == 10) {
                deviceParam = DeviceAccountMessageSetting.getAccountMessage(this.info);
                if (deviceParam != null) {
                    msg = DeviceAccountSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 144;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceAccountSettingFragment.this.handler.sendMessage(msg);
                }
            } else if (this.nOPType == 11) {
                deviceParam = DeviceAccountMessageSetting.setAccountMessage(this.info, this.m_newUsername, this.m_newPassword, DeviceAccountSettingFragment.this.nUserID);
                if (deviceParam != null) {
                    msg = DeviceAccountSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 256;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceAccountSettingFragment.this.handler.sendMessage(msg);
                }
            }
        }
    }

    public DeviceAccountSettingFragment(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public boolean isGetFinish() {
        return this.isGetFinish;
    }

    public void setServerInfo(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public void setNeedFreshInterface(boolean bNeedFresh) {
        this.mIsNeedFresh = bNeedFresh;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_user_config, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        InitSubView();
        return v;
    }

    public void onStop() {
        super.onStop();
        this.relateAtivity = null;
        this.isActive = false;
    }

    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(this.receiver);
    }

    public void onResume() {
        super.onResume();
        this.receiver = new TabBroadcastReceiver();
        getActivity().registerReceiver(this.receiver, getIntentFilter());
        this.relateAtivity = getActivity();
        this.isActive = true;
    }

    private IntentFilter getIntentFilter() {
        if (this.intentFilter == null) {
            this.intentFilter = new IntentFilter();
            this.intentFilter.addAction("TAB1_ACTION");
        }
        return this.intentFilter;
    }

    private void InitSubView() {
        createLoadingDialog();
        this.btnUserBack = (ImageView) this.contentView.findViewById(C0470R.id.btnUserBack);
        this.btnUserBack.setOnClickListener(this);
        this.btnUserSave = (Button) this.contentView.findViewById(C0470R.id.btnUserSave);
        this.btnUserSave.setOnClickListener(this);
        this.btnUserSave.setEnabled(false);
        this.etUsername = (EditText) this.contentView.findViewById(C0470R.id.etUsername);
        this.etOldPassword = (EditText) this.contentView.findViewById(C0470R.id.etPasswordOld);
        this.etNewPassword = (EditText) this.contentView.findViewById(C0470R.id.etPasswordNew);
        this.etConfirmPassword = (EditText) this.contentView.findViewById(C0470R.id.etPasswordConfirm);
        this.cbModifyPassword = (LinearLayout) this.contentView.findViewById(C0470R.id.cbModifyPassword);
        this.cbModifyPasswordCheckbox = (ImageView) this.contentView.findViewById(C0470R.id.cbModifyPasswordCheckbox);
        this.cbModifyPassword.setOnClickListener(this);
        this.m_bModifyPassword = false;
        this.cbModifyPasswordCheckbox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
        this.contentView.findViewById(C0470R.id.layoutPassworSetting).setVisibility(4);
        if (this.mServerInfo != null && this.mIsNeedFresh) {
            getUserInfo(this.mServerInfo);
        }
    }

    public void hindKeyboard() {
        if (this.relateAtivity != null) {
            try {
                InputMethodManager imm = (InputMethodManager) this.relateAtivity.getSystemService("input_method");
                if (imm != null) {
                    imm.hideSoftInputFromWindow(this.relateAtivity.getCurrentFocus().getWindowToken(), 2);
                }
            } catch (Exception e) {
            }
        }
    }

    public void ShowAlert(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowAlert(title, msg);
        }
    }

    public void onSaveAndBack(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowNotic(title, msg);
            ShowConfigSetting();
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.btnUserBack:
                this.isGetFinish = false;
                ShowConfigSetting();
                return;
            case C0470R.id.cbModifyPassword:
                this.m_bModifyPassword = !this.m_bModifyPassword;
                if (this.m_bModifyPassword) {
                    this.cbModifyPasswordCheckbox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_check));
                    this.contentView.findViewById(C0470R.id.layoutPassworSetting).setVisibility(0);
                    return;
                }
                this.cbModifyPasswordCheckbox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
                this.contentView.findViewById(C0470R.id.layoutPassworSetting).setVisibility(4);
                return;
            case C0470R.id.btnUserSave:
                hindKeyboard();
                if (this.mServerInfo != null) {
                    String strUsername;
                    String strNewPassword;
                    if (this.m_bModifyPassword) {
                        strUsername = this.etUsername.getText().toString().trim();
                        strNewPassword = this.etNewPassword.getText().toString().trim();
                        String strConfirm = this.etConfirmPassword.getText().toString().trim();
                        String strPassword = this.etOldPassword.getText().toString().trim();
                        if (strUsername.compareTo(Constants.MAIN_VERSION_TAG) == 0) {
                            ShowAlert(getString(C0470R.string.alert_title), getString(C0470R.string.alert_username_is_invalide));
                            return;
                        } else if (strNewPassword.compareTo(strConfirm) != 0) {
                            ShowAlert(getString(C0470R.string.alert_title), getString(C0470R.string.alert_password_confirm_err));
                            return;
                        } else if (strPassword.compareTo(this.userInfo.getStrPassword().trim()) != 0) {
                            ShowAlert(getString(C0470R.string.alert_title), getString(C0470R.string.alert_password_err));
                            return;
                        }
                    }
                    strUsername = this.etUsername.getText().toString().trim();
                    if (strUsername.compareTo(Constants.MAIN_VERSION_TAG) == 0) {
                        ShowAlert(getString(C0470R.string.alert_title), getString(C0470R.string.alert_username_is_invalide));
                        return;
                    }
                    strNewPassword = this.userInfo.getStrPassword();
                    if (strNewPassword == null && ((this.userInfo.getStrPassword() == null || this.userInfo.getStrPassword().length() == 0) && strUsername.compareTo(this.userInfo.getStrUsername()) == 0)) {
                        ShowAlert(getString(C0470R.string.alert_set_config_fail), Constants.MAIN_VERSION_TAG);
                        return;
                    } else if (strNewPassword != null && strNewPassword.compareTo(this.userInfo.getStrPassword()) == 0 && strUsername.compareTo(this.userInfo.getStrUsername()) == 0) {
                        ShowAlert(getString(C0470R.string.alert_set_config_fail), getString(C0470R.string.newPasswordAndOldPassword));
                        return;
                    } else {
                        setUserInfo(this.mServerInfo, this.nUserID, strUsername, strNewPassword);
                        return;
                    }
                }
                return;
            default:
                return;
        }
    }

    private void ShowConfigSetting() {
        this.m_nUserInfoID++;
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ChangeFragment(16, 13, this.mServerInfo);
        }
    }

    private void getUserInfo(DeviceInfo info) {
        if (info != null) {
            this.m_nUserInfoID++;
            this.mLoadType = 1;
            this.loadingDialog.show();
            this.btnUserSave.setEnabled(false);
            this.isGetFinish = false;
            new UserConfigThread(info).start();
        }
    }

    private void setUserInfo(DeviceInfo info, int nUID, String strUsername, String strPassword) {
        if (info != null) {
            this.m_nUserInfoID++;
            this.mLoadType = 2;
            this.loadingDialog.show();
            this.btnUserSave.setEnabled(false);
            new UserConfigThread(strUsername, strPassword, info).start();
        }
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C02802());
        this.loadingDialog.setOnDismissListener(new C02813());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }
}
