package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.OnScaleGestureListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.custom.RoundCornerImageView;
import com.macrovideo.photo.PhotoViewAttacher;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.media.LibContext;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrovideo.sdk.media.NVMediaPlayer;
import com.macrovideo.sdk.media.Player;
import com.macrovideo.sdk.objects.PTZXPoint;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.sdk.tools.SpSaveList;
import com.tencent.android.tpush.common.Constants;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressLint({"NewApi"})
public class NVPlayerPlayActivity extends Activity implements OnClickListener, OnTouchListener, OnItemClickListener {
    private static int BTN_SCREENSHOT = 10010;
    static final int CMD_ACCEPT = 37124;
    static final int CMD_AFFIRM = 37122;
    static final int CMD_ASKFORCNLNUM = 37128;
    static final int CMD_CHECKPSW = 37129;
    static final int CMD_CONNECTINFO = 37125;
    static final int CMD_EXIT = 37123;
    static final int CMD_REQUEST = 37121;
    static final int CMD_STREAMHEAD = 37126;
    static final int CMD_UDPSHAKE = 37127;
    private static final int MY_PERMISSIONS_REQUEST_MICROPHONE = 2;
    private static final int MY_PERMISSION_REQUEST_STORAGE = 3;
    private static final int PTZX_RESULT_FAIL = 1112;
    private static final int PTZX_RESULT_OK = 1111;
    static final int SEND_BUFFER_DATA_SIZE = 504;
    static final int SEND_BUFFER_HEADER_SIZE = 8;
    static final int SEND_BUFFER_SIZE = 512;
    static final int SESSION_FRAME_BUFFER_SIZE = 65536;
    static final short SHOWCODE_HAS_DATA = (short) 3001;
    static final short SHOWCODE_LOADING = (short) 1001;
    static final short SHOWCODE_NEW_IMAGE = (short) 1002;
    static final short SHOWCODE_STOP = (short) 2001;
    static final short SHOWCODE_VIDEO = (short) 1004;
    static final int SIZE_CMDPACKET = 128;
    static final int SP_DATA = 127;
    static final short STAT_CONNECTING = (short) 2001;
    static final short STAT_DECODE = (short) 2003;
    static final short STAT_DISCONNECT = (short) 2005;
    static final short STAT_LOADING = (short) 2002;
    static final short STAT_MR_BUSY = (short) 2007;
    static final short STAT_MR_DISCONNECT = (short) 2008;
    static final short STAT_RESTART = (short) 2006;
    static final short STAT_STOP = (short) 2004;
    private static boolean m_controlPanel = false;
    private ArrayList<Integer> ALL_area_alarmlist;
    private int FLING_MAX_DISTANCE = this.FLING_MIN_DISTANCE;
    private int FLING_MIN_DISTANCE = 10;
    private int FLING_MIN_VELOCITY = 80;
    private Map<Integer, Integer> LocalAreaSelectmap;
    private LinearLayout RlVertical;
    private ArrayList<Integer> SelectAreaList;
    private ArrayList<String> Viewlist;
    private SelectAreaAdapter adapter;
    private boolean bAnyway = true;
    private boolean bIsDownPressed = false;
    private boolean bIsLeftPressed = false;
    private boolean bIsRightPressed = false;
    private boolean bIsUpPressed = false;
    private View[] backgroundContainers = new View[4];
    Bitmap bm = null;
    private Button btnCancelImageView = null;
    private Button btnCanelAllArea = null;
    private Button btnHD = null;
    private Button btnPTZDown;
    private Button btnPTZLeft;
    private Button btnPTZRight;
    private Button btnPTZUP;
    private Button btnPresetConfig;
    private Button btnSelectAllArea;
    private Button btnSmooth = null;
    private Button btn_lastDevice;
    private Button btn_nextDevice;
    private Button btn_saveSelectArea = null;
    private Button btn_selectArea;
    private Button button_Cloud_Terrace;
    LinearLayout[] containers = new LinearLayout[4];
    private RelativeLayout controlPanel;
    private LoginHandle deviceParam = null;
    private float fScaleSize = PhotoViewAttacher.DEFAULT_MIN_SCALE;
    String folderName = "iCamSeeImages";
    NVMediaPlayer[] glViews = new NVMediaPlayer[4];
    private Handler handler = new C03901();
    private View iamgeViewConctentView = null;
    private Dialog iamgeViewDialog = null;
    private ImageView[] img_v = new ImageView[4];
    private boolean isAllArea = false;
    boolean isCheck = false;
    private boolean isRecording = false;
    private boolean isSelectArea = false;
    private ImageView ivPresetLandscape;
    private long lScaleTime = 0;
    private LinearLayout layoutBottomBar;
    private LinearLayout layoutCenter = null;
    private LinearLayout layoutMicBtn;
    private LinearLayout layoutPresetConfig;
    private LinearLayout layoutRecord;
    private LinearLayout layoutReverse;
    private LinearLayout layoutTopBar = null;
    private LinearLayout layout_Cloud_Terrace;
    private LinearLayout layout_ScreenShot;
    private RelativeLayout llLandscape;
    private LinearLayout llLandscapeDefinition;
    private LinearLayout llPlayTalkback;
    private LinearLayout llVertical;
    private LinearLayout ll_alarmArea_btn = null;
    private LinearLayout ll_alarmArea_explain = null;
    private ListView lvPreset;
    private ImageView mBtnBack;
    private Button mBtnBack2;
    private Button mBtnImageQl = null;
    private Button mBtnImageQl2 = null;
    private Button mBtnMic = null;
    private Button mBtnMic2 = null;
    private Button mBtnReverse = null;
    private Button mBtnReverse2 = null;
    private Button mBtnScreenShot = null;
    private Button mBtnScreenShot2 = null;
    private Button mBtnSound;
    private Button mBtnSound2;
    private Button mBtnStopAndPlay;
    private GestureDetector mGestureDetector = null;
    private GridView mGridView;
    private boolean mIsPlaying = false;
    private boolean mIsReverse = false;
    private boolean mIsSpeaking = false;
    private boolean mPlaySound = false;
    private int mPlayingChn = -1;
    private boolean mQLHD = true;
    private CloseActivityReceiver mReceiver;
    private ScaleGestureDetector mScaleGestureDetector = null;
    int mScreenHeight = 0;
    int mScreenWidth = 0;
    private int mStreamType = 0;
    private boolean m_bFinish = false;
    private boolean m_bPTZ = false;
    private boolean m_bPTZX = false;
    private boolean m_bReversePRI = true;
    private boolean m_bSpeak = false;
    private boolean m_isHD = true;
    private int m_nAddType = 0;
    private int m_nDeviceID = 0;
    private int m_nID = 0;
    private int m_nPTZXCount = 0;
    private int m_nPTZXID = 0;
    private int m_nThreadID = 0;
    private String m_strName = "IPC";
    private String m_strPassword = "1";
    private String m_strUsername = "1";
    private Map<Integer, ArrayList<Integer>> map_Select_area;
    private int nScreenOrientation = 1;
    private int nToolsViewShowTickCount = 8;
    private View[] parentContainers = new View[4];
    private PopupWindow popupWindowCloud;
    private PopupWindow popupWindowMore;
    private ProgressBar progressBarPresetConfig;
    private int ptzTimerThreadID = 0;
    private PTZXPiontAdapter ptzxAdapter = null;
    private LinearLayout rlvideoSetting;
    private Dialog screenshotDialog = null;
    int startX = 0;
    int startY = 0;
    private TextView tBtnImageQl = null;
    private TextView tBtnMic = null;
    private TextView tBtnReverse = null;
    private TextView tBtnSound = null;
    private int timerThreadID = 0;
    private View[] top_bottom = new View[2];
    private TextView tvPlayDeviceID;
    private TextView txt_ImageGQL;

    class C03901 extends Handler {
        C03901() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 == NVPlayerPlayActivity.BTN_SCREENSHOT) {
                NVPlayerPlayActivity.this.mBtnScreenShot.setEnabled(true);
                NVPlayerPlayActivity.this.mBtnScreenShot2.setEnabled(true);
            } else if (msg.arg1 == NVPlayerPlayActivity.PTZX_RESULT_OK) {
                NVPlayerPlayActivity.this.progressBarPresetConfig.setVisibility(8);
                int nPTZXID = msg.arg2;
                if (nPTZXID >= 0 && nPTZXID < 9) {
                    boolean isSetOK = LocalDefines.updatePTZXPoints(NVPlayerPlayActivity.this.m_nDeviceID, nPTZXID, NVPlayerPlayActivity.this.getPTZXImage());
                }
                Toast.makeText(NVPlayerPlayActivity.this, NVPlayerPlayActivity.this.getString(C0470R.string.presetOK), 0).show();
                if (NVPlayerPlayActivity.this.ptzxAdapter != null) {
                    NVPlayerPlayActivity.this.ptzxAdapter.notifyDataSetChanged();
                }
            } else if (msg.arg1 == NVPlayerPlayActivity.PTZX_RESULT_FAIL) {
                NVPlayerPlayActivity.this.progressBarPresetConfig.setVisibility(8);
                Toast.makeText(NVPlayerPlayActivity.this, NVPlayerPlayActivity.this.getString(C0470R.string.presetFail), 0).show();
            } else if (msg.arg1 == 4) {
                NVPlayerPlayActivity.this.ScreenShot();
            } else if (msg.arg1 != 3) {
                switch (msg.arg2) {
                    case 0:
                        if (msg.arg1 == 1) {
                            Player.ShowProgressBar(0, true);
                            return;
                        } else {
                            Player.ShowProgressBar(0, false);
                            return;
                        }
                    case 1:
                        if (msg.arg1 == 1) {
                            Player.ShowProgressBar(1, true);
                            return;
                        } else {
                            Player.ShowProgressBar(1, false);
                            return;
                        }
                    case 2:
                        if (msg.arg1 == 1) {
                            Player.ShowProgressBar(2, true);
                            return;
                        } else {
                            Player.ShowProgressBar(2, false);
                            return;
                        }
                    case 3:
                        if (msg.arg1 == 1) {
                            Player.ShowProgressBar(3, true);
                            return;
                        } else {
                            Player.ShowProgressBar(3, false);
                            return;
                        }
                    default:
                        return;
                }
            } else if (!NVPlayerPlayActivity.this.mIsSpeaking && NVPlayerPlayActivity.this.nScreenOrientation == 2) {
                if (NVPlayerPlayActivity.this.popupWindowMore == null || !NVPlayerPlayActivity.this.popupWindowMore.isShowing()) {
                    NVPlayerPlayActivity.this.hideToolsViews();
                } else {
                    NVPlayerPlayActivity.this.nToolsViewShowTickCount = 5;
                }
            }
        }
    }

    class C03912 implements OnShowListener {
        C03912() {
        }

        public void onShow(DialogInterface dialog) {
            Message msg = NVPlayerPlayActivity.this.handler.obtainMessage();
            msg.arg1 = 4;
            NVPlayerPlayActivity.this.handler.sendMessage(msg);
        }
    }

    class C03923 implements OnDismissListener {
        C03923() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class C03934 implements DialogInterface.OnClickListener {
        C03934() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            NVPlayerPlayActivity.this.setResult(-1);
        }
    }

    class C03945 implements OnTouchListener {
        private long firstTouch = 0;
        private boolean isFullScreen = false;
        private long secondTouch = 0;

        C03945() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            NVPlayerPlayActivity.this.OnGLPlayViewSelected(0);
            switch (event.getAction()) {
                case 0:
                    this.secondTouch = event.getDownTime();
                    if (this.secondTouch - this.firstTouch <= 350) {
                        if (!this.isFullScreen) {
                            this.isFullScreen = true;
                            NVPlayerPlayActivity.this.FullScreenMode(0);
                            LibContext.SwitchPlayingMode(0, this.isFullScreen);
                            break;
                        }
                        this.isFullScreen = false;
                        NVPlayerPlayActivity.this.ExitFullScreenMode(0);
                        LibContext.SwitchPlayingMode(0, this.isFullScreen);
                        break;
                    }
                    this.firstTouch = this.secondTouch;
                    if (Player.isWindowSelected(0)) {
                        Player.isWindowPlaying(0);
                        break;
                    }
                    break;
            }
            return false;
        }
    }

    class C03956 implements OnTouchListener {
        private long firstTouch = 0;
        private boolean isFullScreen = false;
        private long secondTouch = 0;

        C03956() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            NVPlayerPlayActivity.this.OnGLPlayViewSelected(1);
            switch (event.getAction()) {
                case 0:
                    this.secondTouch = event.getDownTime();
                    if (this.secondTouch - this.firstTouch <= 350) {
                        if (!this.isFullScreen) {
                            this.isFullScreen = true;
                            NVPlayerPlayActivity.this.FullScreenMode(1);
                            LibContext.SwitchPlayingMode(1, this.isFullScreen);
                            break;
                        }
                        this.isFullScreen = false;
                        NVPlayerPlayActivity.this.ExitFullScreenMode(1);
                        LibContext.SwitchPlayingMode(1, this.isFullScreen);
                        break;
                    }
                    this.firstTouch = this.secondTouch;
                    if (Player.isWindowSelected(1)) {
                        Player.isWindowPlaying(1);
                        break;
                    }
                    break;
            }
            return false;
        }
    }

    class C03967 implements OnTouchListener {
        private long firstTouch = 0;
        private boolean isFullScreen = false;
        private long secondTouch = 0;

        C03967() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            NVPlayerPlayActivity.this.OnGLPlayViewSelected(2);
            switch (event.getAction()) {
                case 0:
                    this.secondTouch = event.getDownTime();
                    if (this.secondTouch - this.firstTouch <= 350) {
                        if (!this.isFullScreen) {
                            this.isFullScreen = true;
                            NVPlayerPlayActivity.this.FullScreenMode(2);
                            LibContext.SwitchPlayingMode(2, this.isFullScreen);
                            break;
                        }
                        this.isFullScreen = false;
                        NVPlayerPlayActivity.this.ExitFullScreenMode(2);
                        LibContext.SwitchPlayingMode(2, this.isFullScreen);
                        break;
                    }
                    this.firstTouch = this.secondTouch;
                    if (Player.isWindowSelected(2)) {
                        Player.isWindowPlaying(2);
                        break;
                    }
                    break;
            }
            return false;
        }
    }

    class C03978 implements OnTouchListener {
        private long firstTouch = 0;
        private boolean isFullScreen = false;
        private long secondTouch = 0;

        C03978() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            NVPlayerPlayActivity.this.OnGLPlayViewSelected(3);
            switch (event.getAction()) {
                case 0:
                    this.secondTouch = event.getDownTime();
                    if (this.secondTouch - this.firstTouch <= 350) {
                        if (!this.isFullScreen) {
                            this.isFullScreen = true;
                            NVPlayerPlayActivity.this.FullScreenMode(3);
                            LibContext.SwitchPlayingMode(3, this.isFullScreen);
                            break;
                        }
                        this.isFullScreen = false;
                        NVPlayerPlayActivity.this.ExitFullScreenMode(3);
                        LibContext.SwitchPlayingMode(3, this.isFullScreen);
                        break;
                    }
                    this.firstTouch = this.secondTouch;
                    if (Player.isWindowSelected(3)) {
                        Player.isWindowPlaying(3);
                        break;
                    }
                    break;
            }
            return false;
        }
    }

    class C03989 implements OnTouchListener {
        C03989() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            NVPlayerPlayActivity.this.glViews[0].StopPlay();
            Player.ClearGLESScreen(NVPlayerPlayActivity.this.glViews, false, 0);
            return false;
        }
    }

    class CloseActivityReceiver extends BroadcastReceiver {
        CloseActivityReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = LocalDefines.getReceiverActionString(NVPlayerPlayActivity.this);
            if (intent != null && intent.getAction().equals(action)) {
                NVPlayerPlayActivity.this.stopCurrentActivityFromBroadcast();
            }
        }
    }

    class PTZGestureListener extends SimpleOnGestureListener {
        public static final int MOVE_TO_DOWN = 3;
        public static final int MOVE_TO_LEFT = 0;
        public static final int MOVE_TO_RIGHT = 1;
        public static final int MOVE_TO_UP = 2;
        boolean bTouchDown = false;
        boolean bTouchLeft = false;
        boolean bTouchRight = false;
        boolean bTouchUp = false;
        double nMoveDistanceX = 0.0d;
        double nMoveDistanceY = 0.0d;
        private int nStep = 0;
        double nVelocityX = 0.0d;
        double nVelocityY = 0.0d;
        float x1 = 0.0f;
        float x2 = 0.0f;
        float y1 = 0.0f;
        float y2 = 0.0f;

        PTZGestureListener(Context context) {
        }

        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            return false;
        }

        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            if (NVPlayerPlayActivity.this.bIsLeftPressed || NVPlayerPlayActivity.this.bIsRightPressed || NVPlayerPlayActivity.this.bIsUpPressed || NVPlayerPlayActivity.this.bIsDownPressed) {
                return true;
            }
            this.bTouchLeft = false;
            this.bTouchRight = false;
            this.bTouchUp = false;
            this.bTouchDown = false;
            this.nVelocityX = (double) Math.abs(velocityX);
            this.nMoveDistanceX = (double) Math.abs(e1.getX() - e2.getX());
            this.nVelocityY = (double) Math.abs(velocityY);
            this.nMoveDistanceY = (double) Math.abs(e1.getY() - e2.getY());
            if (this.nVelocityY >= this.nVelocityX) {
                this.nVelocityX = 0.0d;
            } else {
                this.nVelocityY = 0.0d;
            }
            if (this.nVelocityY < this.nVelocityX) {
                this.nStep = 0;
                if (this.nMoveDistanceX > ((double) NVPlayerPlayActivity.this.FLING_MIN_DISTANCE)) {
                    this.nStep = 1;
                    if (this.nMoveDistanceX > ((double) NVPlayerPlayActivity.this.FLING_MAX_DISTANCE)) {
                        this.nStep = (int) (this.nMoveDistanceX / ((double) NVPlayerPlayActivity.this.FLING_MAX_DISTANCE));
                    }
                }
                if (this.nVelocityX > ((double) NVPlayerPlayActivity.this.FLING_MIN_VELOCITY) && this.nMoveDistanceX > ((double) NVPlayerPlayActivity.this.FLING_MIN_DISTANCE)) {
                    if (e1.getX() > e2.getX()) {
                        this.bTouchLeft = true;
                    } else {
                        this.bTouchRight = true;
                    }
                }
            } else if (this.nVelocityY > this.nVelocityX) {
                this.nStep = 0;
                if (this.nMoveDistanceX > ((double) NVPlayerPlayActivity.this.FLING_MIN_DISTANCE)) {
                    this.nStep = 1;
                    if (this.nMoveDistanceX > ((double) NVPlayerPlayActivity.this.FLING_MAX_DISTANCE)) {
                        this.nStep = (int) (this.nMoveDistanceX / ((double) NVPlayerPlayActivity.this.FLING_MAX_DISTANCE));
                    }
                }
                if (this.nVelocityY > ((double) NVPlayerPlayActivity.this.FLING_MIN_VELOCITY) && this.nMoveDistanceY > ((double) NVPlayerPlayActivity.this.FLING_MIN_DISTANCE)) {
                    if (e1.getY() > e2.getY()) {
                        this.bTouchUp = true;
                    } else {
                        this.bTouchDown = true;
                    }
                }
            } else if (this.nMoveDistanceY >= this.nMoveDistanceX) {
                if (this.nVelocityY > ((double) NVPlayerPlayActivity.this.FLING_MIN_VELOCITY) && this.nMoveDistanceY > ((double) NVPlayerPlayActivity.this.FLING_MIN_DISTANCE)) {
                    if (e1.getY() > e2.getY()) {
                        this.bTouchUp = true;
                    } else {
                        this.bTouchDown = true;
                    }
                }
            } else if (this.nVelocityX > ((double) NVPlayerPlayActivity.this.FLING_MIN_VELOCITY) && this.nMoveDistanceX > ((double) NVPlayerPlayActivity.this.FLING_MIN_DISTANCE)) {
                if (e1.getX() > e2.getX()) {
                    this.bTouchLeft = true;
                } else {
                    this.bTouchRight = true;
                }
            }
            if (this.nStep > 5) {
                this.nStep = 5;
            }
            NVPlayerPlayActivity.this.glViews[Player.CurrentSelPlayer()].SendPTZAction(this.bTouchLeft, this.bTouchRight, this.bTouchUp, this.bTouchDown, this.nStep);
            return false;
        }

        public boolean onSingleTapConfirmed(MotionEvent e) {
            if (NVPlayerPlayActivity.this.layoutBottomBar.getVisibility() != 0) {
                NVPlayerPlayActivity.this.showToolsViews();
            } else if (NVPlayerPlayActivity.this.nScreenOrientation == 2) {
                NVPlayerPlayActivity.this.hideToolsViews();
            }
            return false;
        }
    }

    private enum PTZMoveDirectEnum {
        LEFT(C0470R.drawable.control_btn_left_click, C0470R.drawable.control_btn_left),
        RIGHT(C0470R.drawable.control_btn_right_click, C0470R.drawable.control_btn_right),
        UP(C0470R.drawable.control_btn_up_click, C0470R.drawable.control_btn_up),
        DOWN(C0470R.drawable.control_btn_down_click, C0470R.drawable.control_btn_down);
        
        private int bgId1;
        private int bgId2;

        private PTZMoveDirectEnum(int bgId1, int bgId2) {
            this.bgId1 = -1;
            this.bgId2 = -1;
            this.bgId1 = bgId1;
            this.bgId2 = bgId2;
        }
    }

    class PTZTimerThread extends Thread {
        int mThreadID = 0;

        public PTZTimerThread(int nThreadID) {
            this.mThreadID = nThreadID;
        }

        public void run() {
            while (this.mThreadID == NVPlayerPlayActivity.this.ptzTimerThreadID) {
                boolean bLeft = NVPlayerPlayActivity.this.bIsLeftPressed;
                boolean bRight = NVPlayerPlayActivity.this.bIsRightPressed;
                boolean bUp = NVPlayerPlayActivity.this.bIsUpPressed;
                boolean bDown = NVPlayerPlayActivity.this.bIsDownPressed;
                if (bLeft && bRight) {
                    bLeft = false;
                    bRight = false;
                }
                if (bUp && bDown) {
                    bUp = false;
                    bDown = false;
                }
                if (bLeft || bRight || bUp || bDown) {
                    NVPlayerPlayActivity.this.glViews[Player.CurrentSelPlayer()].SendPTZAction(bLeft, bRight, bUp, bDown, 0);
                    try {
                        sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        sleep(50);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }
    }

    private class PTZXPiontAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<Bitmap> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            RoundCornerImageView btnPTZXSet;
            ImageView ivPresetImage;
            TextView tvIDText;
            TextView tvPresetText;

            private ItemViewHolder() {
            }
        }

        class ListViewButtonListener implements OnClickListener {
            private int position;

            ListViewButtonListener(int pos) {
                this.position = pos;
            }

            public void onClick(View v) {
                if (v.getId() == PTZXPiontAdapter.this.holder.ivPresetImage.getId()) {
                    NVPlayerPlayActivity.this.locationPTZXPoint(this.position);
                    if (NVPlayerPlayActivity.this.popupWindowMore != null) {
                        NVPlayerPlayActivity.this.popupWindowMore.dismiss();
                    }
                } else if (v.getId() == PTZXPiontAdapter.this.holder.btnPTZXSet.getId()) {
                    NVPlayerPlayActivity.this.progressBarPresetConfig.setVisibility(0);
                    NVPlayerPlayActivity.this.startPTZXConfig(NVPlayerPlayActivity.this.deviceParam, this.position, 102, NVPlayerPlayActivity.this.deviceParam.getnDeviceID());
                }
            }
        }

        public PTZXPiontAdapter(Context c, ArrayList<Bitmap> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.preset_count_item, null);
                this.holder = new ItemViewHolder();
                this.holder.ivPresetImage = (ImageView) convertView.findViewById(this.valueViewID[0]);
                this.holder.btnPTZXSet = (RoundCornerImageView) convertView.findViewById(this.valueViewID[1]);
                this.holder.tvPresetText = (TextView) convertView.findViewById(this.valueViewID[2]);
                this.holder.tvIDText = (TextView) convertView.findViewById(this.valueViewID[3]);
                convertView.setTag(this.holder);
            }
            PTZXPoint ptzxPoint = null;
            Bitmap image = null;
            if (LocalDefines._PTZXPointDevID == NVPlayerPlayActivity.this.m_nDeviceID) {
                ptzxPoint = (PTZXPoint) LocalDefines._ptzxPointList.get(Integer.valueOf(position));
            }
            if (ptzxPoint != null) {
                image = ptzxPoint.getFaceImage();
            }
            if (image != null) {
                this.holder.ivPresetImage.setImageBitmap(image);
                this.holder.tvPresetText.setVisibility(8);
            } else {
                this.holder.tvPresetText.setVisibility(0);
                this.holder.ivPresetImage.setImageBitmap(null);
            }
            ListViewButtonListener listener = new ListViewButtonListener(position);
            this.holder.tvIDText.setText((position + 1));
            this.holder.ivPresetImage.setOnClickListener(listener);
            this.holder.btnPTZXSet.setOnClickListener(listener);
            return convertView;
        }
    }

    private class PTZXThread extends Thread {
        private Handler handler;
        LoginHandle lhandle = null;
        private int m_ThreadConfigID = 0;
        private int m_ThreadPTZXAction = 0;
        private int m_ThreadPTZXID = 0;
        private int m_nDeviceID = 0;

        public PTZXThread(Handler handler, int configID, LoginHandle lhandle, int nPTZXID, int nPTZXAction, int nDeviceID) {
            this.m_ThreadConfigID = configID;
            this.handler = handler;
            this.lhandle = lhandle;
            this.m_ThreadPTZXID = nPTZXID;
            this.m_ThreadPTZXAction = nPTZXAction;
            this.m_nDeviceID = nDeviceID;
        }

        public void run() {
            int nConfigResult = NVPlayerPlayActivity.this.glViews[Player.CurrentSelPlayer()].SetPTZXLocationID(this.m_ThreadPTZXID, this.lhandle, this.m_nDeviceID);
            Message msg;
            if (NVPlayerPlayActivity.this.m_nPTZXID == this.m_ThreadConfigID && nConfigResult == 256) {
                msg = this.handler.obtainMessage();
                msg.arg1 = NVPlayerPlayActivity.PTZX_RESULT_OK;
                msg.arg2 = this.m_ThreadPTZXID;
                this.handler.sendMessage(msg);
            } else if (NVPlayerPlayActivity.this.m_nPTZXID == this.m_ThreadConfigID) {
                msg = this.handler.obtainMessage();
                msg.arg1 = NVPlayerPlayActivity.PTZX_RESULT_FAIL;
                msg.arg2 = nConfigResult;
                this.handler.sendMessage(msg);
            }
        }
    }

    class ScaleGestureListener implements OnScaleGestureListener {
        ScaleGestureListener() {
        }

        public boolean onScale(ScaleGestureDetector detector) {
            NVPlayerPlayActivity nVPlayerPlayActivity;
            if (detector.getScaleFactor() > PhotoViewAttacher.DEFAULT_MIN_SCALE) {
                nVPlayerPlayActivity = NVPlayerPlayActivity.this;
                nVPlayerPlayActivity.fScaleSize = nVPlayerPlayActivity.fScaleSize - 0.008f;
                if (((double) NVPlayerPlayActivity.this.fScaleSize) < 0.2d) {
                    NVPlayerPlayActivity.this.fScaleSize = 0.2f;
                } else {
                    NVPlayerPlayActivity.this.glViews[Player.CurrentSelPlayer()].scale(NVPlayerPlayActivity.this.fScaleSize, NVPlayerPlayActivity.this.fScaleSize);
                }
            } else if (detector.getScaleFactor() < PhotoViewAttacher.DEFAULT_MIN_SCALE) {
                nVPlayerPlayActivity = NVPlayerPlayActivity.this;
                nVPlayerPlayActivity.fScaleSize = nVPlayerPlayActivity.fScaleSize + 0.05f;
                if (NVPlayerPlayActivity.this.fScaleSize > PhotoViewAttacher.DEFAULT_MIN_SCALE) {
                    NVPlayerPlayActivity.this.fScaleSize = PhotoViewAttacher.DEFAULT_MIN_SCALE;
                } else {
                    NVPlayerPlayActivity.this.glViews[Player.CurrentSelPlayer()].scale(NVPlayerPlayActivity.this.fScaleSize, NVPlayerPlayActivity.this.fScaleSize);
                }
            }
            NVPlayerPlayActivity.this.lScaleTime = System.currentTimeMillis();
            return false;
        }

        public boolean onScaleBegin(ScaleGestureDetector detector) {
            return true;
        }

        public void onScaleEnd(ScaleGestureDetector detector) {
        }
    }

    public class SelectAreaAdapter extends BaseAdapter {
        Context context;
        ArrayList<Integer> listDate;
        GridView mGv;

        public SelectAreaAdapter(GridView gv, Context mContext, ArrayList<Integer> list) {
            this.context = mContext;
            this.mGv = gv;
            this.listDate = list;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = LayoutInflater.from(this.context).inflate(C0470R.layout.draggable_grid_item, null);
            if (this.listDate != null) {
                for (int i = 0; i < this.listDate.size(); i++) {
                    int isSelect = ((Integer) this.listDate.get(i)).intValue();
                    if (position == i) {
                        if (isSelect == 1) {
                            convertView.setBackgroundColor(Color.parseColor("#ff0000"));
                            convertView.getBackground().setAlpha(51);
                        } else {
                            convertView.setBackgroundColor(Color.parseColor("#000000"));
                            convertView.getBackground().setAlpha(20);
                        }
                    }
                }
            }
            convertView.setLayoutParams(new LayoutParams(-1, this.mGv.getHeight() / LocalDefines.alarmrows));
            return convertView;
        }

        public int getCount() {
            return this.listDate.size();
        }

        public Object getItem(int position) {
            return this.listDate.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }
    }

    private class ThreadBtnScreenShot extends Thread {
        private int nThreadID = 0;

        public ThreadBtnScreenShot(int nThreadID) {
            this.nThreadID = nThreadID;
        }

        public void run() {
            super.run();
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (NVPlayerPlayActivity.this.m_nThreadID == this.nThreadID) {
                Message msg = NVPlayerPlayActivity.this.handler.obtainMessage();
                msg.arg1 = NVPlayerPlayActivity.BTN_SCREENSHOT;
                NVPlayerPlayActivity.this.handler.sendMessage(msg);
            }
        }
    }

    class TimerThread extends Thread {
        int mThreadID = 0;

        public TimerThread(int nThreadID) {
            this.mThreadID = nThreadID;
        }

        public void run() {
            while (this.mThreadID == NVPlayerPlayActivity.this.timerThreadID) {
                NVPlayerPlayActivity nVPlayerPlayActivity = NVPlayerPlayActivity.this;
                nVPlayerPlayActivity.nToolsViewShowTickCount = nVPlayerPlayActivity.nToolsViewShowTickCount - 1;
                if (NVPlayerPlayActivity.this.nToolsViewShowTickCount <= 0 && this.mThreadID == NVPlayerPlayActivity.this.timerThreadID) {
                    Message message = new Message();
                    message.arg1 = 3;
                    NVPlayerPlayActivity.this.handler.sendMessage(message);
                    NVPlayerPlayActivity.this.nToolsViewShowTickCount = 0;
                }
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void createDialogs() {
        this.iamgeViewConctentView = LayoutInflater.from(this).inflate(C0470R.layout.screenshotdialog, null);
        this.screenshotDialog = new Dialog(this, C0470R.style.progressDialog);
        this.screenshotDialog.setContentView(this.iamgeViewConctentView);
        this.screenshotDialog.setOnShowListener(new C03912());
        this.screenshotDialog.setOnDismissListener(new C03923());
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.isSelectArea) {
                finish();
            } else {
                exitCurrentActivity();
            }
        }
        return false;
    }

    private void readSystemParam() {
        this.mPlaySound = getSharedPreferences(Defines._fileName, 0).getBoolean("sounds", true);
    }

    public boolean writeSystemParam() {
        Editor editer = getSharedPreferences(Defines._fileName, 0).edit();
        editer.putBoolean("sounds", this.mPlaySound);
        editer.commit();
        return true;
    }

    private void ShowAlert(String title, String msg) {
        try {
            new Builder(this).setTitle(title).setMessage(msg).setIcon(C0470R.drawable.icon).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C03934()).show();
        } catch (Exception e) {
        }
    }

    public void onPause() {
        OnPlayersPuase();
        super.onPause();
    }

    public void onResume() {
        OnPlayersResume();
        this.nToolsViewShowTickCount = 8;
        this.timerThreadID++;
        new TimerThread(this.timerThreadID).start();
        if (this.mIsPlaying) {
            startPlay();
        } else {
            stopPlay(true);
        }
        this.m_bFinish = false;
        ((NotificationManager) getSystemService("notification")).cancel(257);
        this.nScreenOrientation = getResources().getConfiguration().orientation;
        super.onResume();
    }

    public void OnPlayersResume() {
        for (int i = 0; i < 4; i++) {
            if (this.glViews[i] != null) {
                this.glViews[i].onResume();
            }
        }
    }

    public void onDestroy() {
        this.glViews = null;
        this.containers = null;
        this.top_bottom = null;
        this.parentContainers = null;
        this.backgroundContainers = null;
        this.img_v = null;
        super.onDestroy();
    }

    public void onStop() {
        this.timerThreadID++;
        this.m_nThreadID++;
        if (this.m_bFinish) {
            LibContext.stopAll();
            LibContext.ClearContext();
        } else {
            NotificationManager notiManager = (NotificationManager) getSystemService("notification");
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
            builder.setContentTitle(getString(C0470R.string.app_name)).setContentText(getString(C0470R.string.app_notice)).setTicker(getString(C0470R.string.app_name)).setWhen(System.currentTimeMillis()).setOngoing(false);
            if (VERSION.SDK_INT >= 23) {
                builder.setSmallIcon(C0470R.drawable.my_device_3);
                builder.setLargeIcon(Functions.readBitMap(this, C0470R.drawable.icon));
            } else {
                builder.setSmallIcon(C0470R.drawable.icon_1);
            }
            notiManager.notify(257, builder.build());
            Intent intent = new Intent(this, NVPlayerPlayActivity.class);
            Bundle data = new Bundle();
            data.putString("name", this.m_strName);
            if (this.mIsPlaying) {
                data.putBoolean("isplaying", true);
                data.putInt("playing_chn", this.mPlayingChn);
            }
            data.putParcelable(Constants.MAIN_VERSION_TAG, this.deviceParam);
            intent.putExtras(data);
            intent.setFlags(335544320);
            PendingIntent contentIntent = PendingIntent.getActivity(this, 257, intent, 134217728);
            LibContext.stopAll();
        }
        this.tBtnImageQl.setText(getString(C0470R.string.str_recording));
        this.mBtnImageQl.setBackgroundResource(C0470R.drawable.btn_recording);
        if (this.isRecording) {
            this.glViews[Player.CurrentSelPlayer()].StopRecord();
        }
        this.isRecording = false;
        this.m_bFinish = true;
        super.onStop();
    }

    private void ShowLandscapeView() {
        this.rlvideoSetting.setVisibility(8);
        synchronized (this) {
            this.bAnyway = false;
            this.nToolsViewShowTickCount = 5;
            this.mGridView.setVisibility(8);
            this.btnSelectAllArea.setVisibility(8);
            this.rlvideoSetting.setVisibility(8);
            int nWidth = this.mScreenWidth;
            int nHeight = this.mScreenHeight;
            double dWidth = ((double) nHeight) * 1.777778d;
            if (dWidth < ((double) nWidth)) {
                nWidth = (int) dWidth;
            }
            if (this.popupWindowMore != null) {
                this.popupWindowMore.dismiss();
            }
            hideToolsViews();
            if (this.layoutCenter != null) {
                RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(nWidth, nHeight);
                rlp.addRule(13, -1);
                this.layoutCenter.setLayoutParams(rlp);
                this.layoutCenter.setPadding(0, 0, 0, 0);
            }
            this.nScreenOrientation = 2;
            for (int i = 0; i < 4; i++) {
                if (this.glViews[i] != null) {
                    this.glViews[i].onOreintationChange(this.nScreenOrientation);
                }
            }
        }
    }

    private void ShowPortrailView() {
        if (this.isSelectArea) {
            this.rlvideoSetting.setVisibility(8);
        } else {
            this.rlvideoSetting.setVisibility(0);
        }
        synchronized (this) {
            if (this.m_bPTZX) {
                this.btnPresetConfig.setVisibility(0);
            }
            if (this.mScreenWidth <= this.mScreenHeight) {
                int padding_in_px = (int) ((((float) 45) * getResources().getDisplayMetrics().density) + 0.5f);
                this.bAnyway = true;
                showToolsViews();
                int nWidth = this.mScreenWidth;
                int statusBarHeight = LocalDefines.getStatusBarHeight(this);
                int nHeight = (int) (((double) (this.mScreenHeight - statusBarHeight)) * 0.6d);
                this.RlVertical.setLayoutParams(new LinearLayout.LayoutParams(this.mScreenWidth, (int) (((double) (this.mScreenHeight - statusBarHeight)) * 0.4d)));
                LinearLayout.LayoutParams Btnparams = new LinearLayout.LayoutParams((int) (((double) this.mScreenWidth) * 0.14d), (int) (((double) this.mScreenWidth) * 0.14d));
                if (this.layoutCenter != null) {
                    RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(nWidth, nHeight);
                    rlp.addRule(10, -1);
                    this.layoutCenter.setLayoutParams(rlp);
                    this.layoutCenter.setPadding(0, padding_in_px, 0, 0);
                }
                if (this.layoutPresetConfig != null) {
                    this.btnPresetConfig.setLayoutParams(Btnparams);
                }
                if (this.layout_Cloud_Terrace != null) {
                    this.button_Cloud_Terrace.setLayoutParams(Btnparams);
                }
                if (this.layout_ScreenShot != null) {
                    this.mBtnScreenShot.setLayoutParams(Btnparams);
                }
                if (this.layoutReverse != null) {
                    this.mBtnReverse.setLayoutParams(Btnparams);
                }
                if (this.layoutMicBtn != null) {
                    this.mBtnMic.setLayoutParams(Btnparams);
                }
                if (this.layoutRecord != null) {
                    this.mBtnImageQl.setLayoutParams(Btnparams);
                }
                this.nScreenOrientation = 1;
                for (int i = 0; i < 4; i++) {
                    if (this.glViews[i] != null) {
                        this.glViews[i].onOreintationChange(this.nScreenOrientation);
                    }
                }
            } else if (!this.isSelectArea) {
                ShowLandscapeView();
            }
        }
    }

    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        this.mScreenWidth = dm.widthPixels;
        this.mScreenHeight = dm.heightPixels;
        LocalDefines.loadResource(getResources());
        if (config.orientation == 2) {
            ShowLandscapeView();
        } else if (config.orientation == 1) {
            ShowPortrailView();
        }
    }

    public void InitGLContainers() {
        this.top_bottom[0] = findViewById(C0470R.id.playContainerTop);
        this.top_bottom[1] = findViewById(C0470R.id.playContainerBottom);
        this.parentContainers[0] = findViewById(C0470R.id.playContainerParent1);
        this.parentContainers[1] = findViewById(C0470R.id.playContainerParent2);
        this.parentContainers[2] = findViewById(C0470R.id.playContainerParent3);
        this.parentContainers[3] = findViewById(C0470R.id.playContainerParent4);
        this.backgroundContainers[0] = findViewById(C0470R.id.playContainer1background);
        this.backgroundContainers[1] = findViewById(C0470R.id.playContainer2background);
        this.backgroundContainers[2] = findViewById(C0470R.id.playContainer3background);
        this.backgroundContainers[3] = findViewById(C0470R.id.playContainer4background);
        this.containers[0] = (LinearLayout) findViewById(C0470R.id.playContainer1);
        this.containers[1] = (LinearLayout) findViewById(C0470R.id.playContainer2);
        this.containers[2] = (LinearLayout) findViewById(C0470R.id.playContainer3);
        this.containers[3] = (LinearLayout) findViewById(C0470R.id.playContainer4);
    }

    void InitGLViewCloseButton() {
        this.img_v[0] = (ImageView) findViewById(C0470R.id.close_but_0);
        this.img_v[1] = (ImageView) findViewById(C0470R.id.close_but_1);
        this.img_v[2] = (ImageView) findViewById(C0470R.id.close_but_2);
        this.img_v[3] = (ImageView) findViewById(C0470R.id.close_but_3);
    }

    void SetCloseButtonVisible(boolean isVisible) {
        if (isVisible) {
            this.img_v[0].setVisibility(0);
            this.img_v[1].setVisibility(0);
            this.img_v[2].setVisibility(0);
            this.img_v[3].setVisibility(0);
            return;
        }
        this.img_v[0].setVisibility(8);
        this.img_v[1].setVisibility(8);
        this.img_v[2].setVisibility(8);
        this.img_v[3].setVisibility(8);
    }

    public void InitGLViewPlayer() {
        for (int i = 0; i < 4; i++) {
            this.glViews[i] = new NVMediaPlayer(getApplication(), this.nScreenOrientation, i);
            this.glViews[i].setRenderMode(0);
        }
    }

    public void ReleaseGLViewPlayer() {
        for (int i = 0; i < 4; i++) {
            if (this.glViews[i] != null) {
                this.glViews[i].DisableRender();
                this.glViews[i] = null;
            }
        }
    }

    public void OnPlayersPuase() {
        for (int i = 0; i < 4; i++) {
            if (this.glViews[i] != null) {
                this.glViews[i].onPause();
            }
        }
    }

    public void ConnectGLViewToPlayer() {
        for (int i = 0; i < 4; i++) {
            this.containers[i].addView(this.glViews[i]);
        }
    }

    public void InitGLViewProgressbar() {
        Player.GetProgressBars((ProgressBar) findViewById(C0470R.id.spinner_0), 0);
        Player.GetProgressBars((ProgressBar) findViewById(C0470R.id.spinner_1), 1);
        Player.GetProgressBars((ProgressBar) findViewById(C0470R.id.spinner_2), 2);
        Player.GetProgressBars((ProgressBar) findViewById(C0470R.id.spinner_3), 3);
    }

    private void InitGLViewTouchEventEX() {
        if (this.layoutCenter != null) {
            this.layoutCenter.setLongClickable(true);
            this.layoutCenter.setOnTouchListener(this);
        }
    }

    private void InitGLViewTouchEvent() {
        this.glViews[0].setOnTouchListener(new C03945());
        this.glViews[1].setOnTouchListener(new C03956());
        this.glViews[2].setOnTouchListener(new C03967());
        this.glViews[3].setOnTouchListener(new C03978());
        this.img_v[0].setOnTouchListener(new C03989());
        this.img_v[1].setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                NVPlayerPlayActivity.this.glViews[1].StopPlay();
                Player.ClearGLESScreen(NVPlayerPlayActivity.this.glViews, false, 1);
                return false;
            }
        });
        this.img_v[2].setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                NVPlayerPlayActivity.this.glViews[2].StopPlay();
                Player.ClearGLESScreen(NVPlayerPlayActivity.this.glViews, false, 2);
                return false;
            }
        });
        this.img_v[3].setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                NVPlayerPlayActivity.this.glViews[3].StopPlay();
                Player.ClearGLESScreen(NVPlayerPlayActivity.this.glViews, false, 3);
                return false;
            }
        });
    }

    public void OnGLPlayViewSelected(int WndID) {
        switch (WndID) {
            case 0:
                Player.SelectWindow(0);
                this.backgroundContainers[0].setVisibility(0);
                if (this.backgroundContainers[1].getVisibility() == 0) {
                    this.backgroundContainers[1].setVisibility(8);
                }
                if (this.backgroundContainers[2].getVisibility() == 0) {
                    this.backgroundContainers[2].setVisibility(8);
                }
                if (this.backgroundContainers[3].getVisibility() == 0) {
                    this.backgroundContainers[3].setVisibility(8);
                    return;
                }
                return;
            case 1:
                Player.SelectWindow(1);
                this.backgroundContainers[1].setVisibility(0);
                if (this.backgroundContainers[0].getVisibility() == 0) {
                    this.backgroundContainers[0].setVisibility(8);
                }
                if (this.backgroundContainers[2].getVisibility() == 0) {
                    this.backgroundContainers[2].setVisibility(8);
                }
                if (this.backgroundContainers[3].getVisibility() == 0) {
                    this.backgroundContainers[3].setVisibility(8);
                    return;
                }
                return;
            case 2:
                Player.SelectWindow(2);
                this.backgroundContainers[2].setVisibility(0);
                if (this.backgroundContainers[0].getVisibility() == 0) {
                    this.backgroundContainers[0].setVisibility(8);
                }
                if (this.backgroundContainers[1].getVisibility() == 0) {
                    this.backgroundContainers[1].setVisibility(8);
                }
                if (this.backgroundContainers[3].getVisibility() == 0) {
                    this.backgroundContainers[3].setVisibility(8);
                    return;
                }
                return;
            case 3:
                Player.SelectWindow(3);
                this.backgroundContainers[3].setVisibility(0);
                if (this.backgroundContainers[0].getVisibility() == 0) {
                    this.backgroundContainers[0].setVisibility(8);
                }
                if (this.backgroundContainers[1].getVisibility() == 0) {
                    this.backgroundContainers[1].setVisibility(8);
                }
                if (this.backgroundContainers[2].getVisibility() == 0) {
                    this.backgroundContainers[2].setVisibility(8);
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void FullScreenMode(int WndID) {
        switch (WndID) {
            case 0:
                this.top_bottom[0].setVisibility(0);
                this.parentContainers[1].setVisibility(8);
                this.containers[1].setVisibility(8);
                this.glViews[1].setVisibility(8);
                this.top_bottom[1].setVisibility(8);
                this.parentContainers[2].setVisibility(8);
                this.containers[2].setVisibility(8);
                this.glViews[2].setVisibility(8);
                this.parentContainers[3].setVisibility(8);
                this.containers[3].setVisibility(8);
                this.glViews[3].setVisibility(8);
                return;
            case 1:
                this.top_bottom[0].setVisibility(0);
                this.parentContainers[0].setVisibility(8);
                this.containers[0].setVisibility(8);
                this.glViews[0].setVisibility(8);
                this.top_bottom[1].setVisibility(8);
                this.parentContainers[2].setVisibility(8);
                this.containers[2].setVisibility(8);
                this.glViews[2].setVisibility(8);
                this.parentContainers[3].setVisibility(8);
                this.containers[3].setVisibility(8);
                this.glViews[3].setVisibility(8);
                return;
            case 2:
                this.top_bottom[0].setVisibility(8);
                this.parentContainers[0].setVisibility(8);
                this.containers[0].setVisibility(8);
                this.glViews[0].setVisibility(8);
                this.parentContainers[1].setVisibility(8);
                this.containers[1].setVisibility(8);
                this.glViews[1].setVisibility(8);
                this.top_bottom[1].setVisibility(0);
                this.parentContainers[3].setVisibility(8);
                this.containers[3].setVisibility(8);
                this.glViews[3].setVisibility(8);
                return;
            case 3:
                this.top_bottom[0].setVisibility(8);
                this.parentContainers[0].setVisibility(8);
                this.containers[0].setVisibility(8);
                this.glViews[0].setVisibility(8);
                this.parentContainers[1].setVisibility(8);
                this.containers[1].setVisibility(8);
                this.glViews[1].setVisibility(8);
                this.top_bottom[1].setVisibility(0);
                this.parentContainers[2].setVisibility(8);
                this.containers[2].setVisibility(8);
                this.glViews[2].setVisibility(8);
                return;
            default:
                return;
        }
    }

    public void ExitFullScreenMode(int WndID) {
        this.top_bottom[0].setVisibility(0);
        this.parentContainers[0].setVisibility(0);
        this.containers[0].setVisibility(0);
        this.glViews[0].setVisibility(0);
        this.parentContainers[1].setVisibility(0);
        this.containers[1].setVisibility(0);
        this.glViews[1].setVisibility(0);
        this.top_bottom[1].setVisibility(0);
        this.parentContainers[2].setVisibility(0);
        this.containers[2].setVisibility(0);
        this.glViews[2].setVisibility(0);
        this.parentContainers[3].setVisibility(0);
        this.containers[3].setVisibility(0);
        this.glViews[3].setVisibility(0);
    }

    public void SetGLViewPlayerMessageHandler() {
        for (int i = 0; i < 4; i++) {
            this.glViews[i].GetHandler(this.handler);
        }
    }

    private boolean saveToSDCard(Bitmap image, String strFileName) {
        boolean bResult = false;
        if (image == null) {
            return 0;
        }
        try {
            File file = new File(Functions.GetSDPath() + File.separator + LocalDefines.SDCardPath);
            if (!file.exists()) {
                file.mkdir();
            }
            FileOutputStream out = new FileOutputStream(new File(file.getAbsolutePath() + File.separator + strFileName));
            image.compress(CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
            bResult = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return bResult;
    }

    private Bitmap getPTZXImage() {
        this.bm = this.glViews[Player.CurrentSelPlayer()].Screenshot();
        float deltaW = Defines._PTZXWidth / ((float) Defines._capWidth);
        float deltaH = Defines._PTZXHeight / ((float) Defines._capHeight);
        Matrix matrix = new Matrix();
        matrix.postScale(deltaW, deltaH);
        return Bitmap.createBitmap(this.bm, 0, 0, this.bm.getWidth(), this.bm.getHeight(), matrix, true);
    }

    private void ScreenShot() {
        this.m_nThreadID++;
        this.mBtnScreenShot.setEnabled(false);
        this.mBtnScreenShot2.setEnabled(false);
        new ThreadBtnScreenShot(this.m_nThreadID).start();
        String strSavePath = Functions.GetSDPath();
        if (strSavePath == null) {
            this.screenshotDialog.dismiss();
            Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeSDCardNotExist), 0).show();
            return;
        }
        this.bm = this.glViews[Player.CurrentSelPlayer()].Screenshot();
        if (this.bm != null) {
            String strFileName = new StringBuilder(String.valueOf(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()))).append("(").append(this.m_strName).append(")").append(".jpg").toString();
            if (saveToSDCard(this.bm, strFileName)) {
                this.screenshotDialog.dismiss();
                Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeFileSaveToAlbumsOK), 0).show();
                return;
            }
            if (saveToSDCard(this.bm, new StringBuilder(String.valueOf(strSavePath)).append("/").append(strFileName).toString())) {
                this.screenshotDialog.dismiss();
                Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotOK), 0).show();
                return;
            }
            this.screenshotDialog.dismiss();
            Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotFail), 0).show();
            return;
        }
        this.screenshotDialog.dismiss();
        Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeScreenShotFail), 0).show();
    }

    public void onCreate(Bundle savedInstanceState) {
        int i;
        super.onCreate(savedInstanceState);
        getWindow().setFlags(128, 128);
        ((NotificationManager) getSystemService("notification")).cancel(257);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_nvplayer_playview);
        this.SelectAreaList = new ArrayList();
        Bundle data = getIntent().getExtras();
        if (data != null) {
            this.m_strName = data.getString("name");
            this.isSelectArea = data.getBoolean("isSelectArea");
            this.deviceParam = (LoginHandle) data.getParcelable(Defines.RECORD_FILE_RETURN_MESSAGE);
            this.m_bReversePRI = this.deviceParam.isbReversePRI();
            this.m_bPTZ = this.deviceParam.isbPTZ();
            this.m_bPTZX = this.deviceParam.isbPTZX();
            this.m_nPTZXCount = this.deviceParam.getnPTZXCount();
            this.m_nDeviceID = this.deviceParam.getnDeviceID();
            this.m_strUsername = data.getString("username");
            this.m_strPassword = data.getString("password");
            this.m_bSpeak = this.deviceParam.isbSpeak();
        }
        if (this.isSelectArea) {
            setRequestedOrientation(1);
        } else {
            setRequestedOrientation(10);
        }
        registerReceiver(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float scale = getResources().getDisplayMetrics().density;
        this.mScreenWidth = dm.widthPixels;
        this.mScreenHeight = dm.heightPixels;
        LocalDefines.loadResource(getResources());
        this.FLING_MAX_DISTANCE = this.mScreenWidth / 3;
        this.rlvideoSetting = (LinearLayout) findViewById(C0470R.id.rlvideoSetting);
        this.rlvideoSetting.getBackground().setAlpha(95);
        this.btn_lastDevice = (Button) findViewById(C0470R.id.btn_lastDevice);
        this.btn_lastDevice.setOnClickListener(this);
        this.txt_ImageGQL = (TextView) findViewById(C0470R.id.txt_definition);
        this.txt_ImageGQL.setOnClickListener(this);
        this.btn_nextDevice = (Button) findViewById(C0470R.id.btn_nextDevice);
        this.btn_nextDevice.setOnClickListener(this);
        this.button_Cloud_Terrace = (Button) findViewById(C0470R.id.button_Cloud_Terrace);
        this.layout_Cloud_Terrace = (LinearLayout) findViewById(C0470R.id.layout_Cloud_Terrace);
        this.layout_Cloud_Terrace.setOnClickListener(this);
        this.layout_ScreenShot = (LinearLayout) findViewById(C0470R.id.layout_ScreenShot);
        this.layout_ScreenShot.setOnClickListener(this);
        this.layoutRecord = (LinearLayout) findViewById(C0470R.id.layoutRecord);
        this.mBtnScreenShot = (Button) findViewById(C0470R.id.buttonScreenShot);
        this.mBtnReverse = (Button) findViewById(C0470R.id.buttonReverse);
        this.mBtnMic = (Button) findViewById(C0470R.id.buttonMic);
        this.mBtnMic.setOnTouchListener(this);
        this.mBtnImageQl = (Button) findViewById(C0470R.id.buttonImageGQL);
        this.mBtnImageQl.setOnClickListener(this);
        this.btnPresetConfig = (Button) findViewById(C0470R.id.btnPresetConfig);
        this.layoutPresetConfig = (LinearLayout) findViewById(C0470R.id.layoutPresetConfig);
        this.layoutPresetConfig.setOnClickListener(this);
        this.layoutReverse = (LinearLayout) findViewById(C0470R.id.layoutReverse);
        this.layoutReverse.setOnClickListener(this);
        this.layoutMicBtn = (LinearLayout) findViewById(C0470R.id.layoutMicBtn);
        this.tvPlayDeviceID = (TextView) findViewById(C0470R.id.tvPlayDeviceID);
        this.llPlayTalkback = (LinearLayout) findViewById(C0470R.id.llPlayTalkback);
        this.btn_saveSelectArea = (Button) findViewById(C0470R.id.btn_saveSelectArea);
        this.btn_saveSelectArea.setOnClickListener(this);
        this.ll_alarmArea_explain = (LinearLayout) findViewById(C0470R.id.ll_alarmArea_explain);
        LocalDefines.loadPTZXPoints(this.deviceParam.getnDeviceID());
        this.mGestureDetector = new GestureDetector(this, new PTZGestureListener(this));
        this.mScaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureListener());
        this.tvPlayDeviceID.setText(this.m_strName);
        this.layoutTopBar = (LinearLayout) findViewById(C0470R.id.linearLayoutTopBar);
        this.layoutCenter = (LinearLayout) findViewById(C0470R.id.playContainer);
        this.layoutBottomBar = (LinearLayout) findViewById(C0470R.id.linearLayoutBottomBar);
        this.llLandscape = (RelativeLayout) findViewById(C0470R.id.llLandscape);
        this.llLandscape.getBackground().setAlpha(95);
        this.RlVertical = (LinearLayout) findViewById(C0470R.id.RlVertical);
        if (this.RlVertical != null) {
            this.RlVertical.setLayoutParams(new LinearLayout.LayoutParams(this.mScreenWidth, (int) (((double) (this.mScreenHeight - LocalDefines.getStatusBarHeight(this))) * 0.4d)));
        }
        this.llLandscapeDefinition = (LinearLayout) findViewById(C0470R.id.llLandscapeDefinition);
        this.llLandscapeDefinition.getBackground().setAlpha(95);
        this.ivPresetLandscape = (ImageView) findViewById(C0470R.id.ivPresetLandscape);
        this.ivPresetLandscape.setOnClickListener(this);
        this.btn_selectArea = (Button) findViewById(C0470R.id.btn_selectArea);
        this.btn_selectArea.setOnClickListener(this);
        this.btnSelectAllArea = (Button) findViewById(C0470R.id.btnSelectAllArea);
        this.btnSelectAllArea.setOnClickListener(this);
        this.btnCanelAllArea = (Button) findViewById(C0470R.id.btnCanelAllArea);
        this.btnCanelAllArea.setOnClickListener(this);
        this.ll_alarmArea_btn = (LinearLayout) findViewById(C0470R.id.ll_alarmArea_btn);
        this.Viewlist = new ArrayList();
        this.map_Select_area = new HashMap();
        this.ALL_area_alarmlist = new ArrayList();
        int index2 = 1;
        for (i = 0; i < LocalDefines.ServerAlarmAreaList.size(); i++) {
            int index = ((Integer) LocalDefines.ServerAlarmAreaList.get(i)).intValue();
            if (index == 0) {
                index2 = index;
                this.isAllArea = false;
            }
            if (index2 == 1) {
                this.isAllArea = true;
            }
        }
        this.mGridView = (GridView) findViewById(C0470R.id.gv);
        this.mGridView.setNumColumns(LocalDefines.alarmcolumns);
        if (this.isSelectArea) {
            DeviceAlarmAndPromptSettingFragment deviceAlarmAndPromptSettingFragment = new DeviceAlarmAndPromptSettingFragment();
            if (DeviceAlarmAndPromptSettingFragment.isSaveArea) {
                for (i = 0; i < LocalDefines.alarmrows * LocalDefines.alarmcolumns; i++) {
                    this.SelectAreaList.add(i, Integer.valueOf(((Integer) LocalDefines.LocalAlarmAreaList.get(i)).intValue()));
                }
                this.adapter = new SelectAreaAdapter(this.mGridView, getApplicationContext(), this.SelectAreaList);
            } else {
                for (i = 0; i < LocalDefines.alarmrows * LocalDefines.alarmcolumns; i++) {
                    this.SelectAreaList.add(i, Integer.valueOf(((Integer) LocalDefines.ServerAlarmAreaList.get(i)).intValue()));
                }
                this.adapter = new SelectAreaAdapter(this.mGridView, getApplicationContext(), this.SelectAreaList);
            }
        }
        this.mGridView.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case 0:
                        int item = NVPlayerPlayActivity.this.mGridView.pointToPosition((int) event.getX(), (int) event.getY());
                        if (item != -1) {
                            if (((Integer) NVPlayerPlayActivity.this.SelectAreaList.get(item)).intValue() == 0) {
                                NVPlayerPlayActivity.this.isCheck = false;
                                NVPlayerPlayActivity.this.SelectAreaList.remove(item);
                                NVPlayerPlayActivity.this.SelectAreaList.add(item, Integer.valueOf(1));
                                NVPlayerPlayActivity.this.mGridView.getChildAt(item).setBackgroundColor(Color.parseColor("#ff0000"));
                                NVPlayerPlayActivity.this.mGridView.getChildAt(item).getBackground().setAlpha(51);
                            } else {
                                NVPlayerPlayActivity.this.isCheck = true;
                                NVPlayerPlayActivity.this.SelectAreaList.remove(item);
                                NVPlayerPlayActivity.this.SelectAreaList.add(item, Integer.valueOf(0));
                                NVPlayerPlayActivity.this.LocalAreaSelectmap.clear();
                                NVPlayerPlayActivity.this.mGridView.getChildAt(item).setBackgroundColor(Color.parseColor("#000000"));
                                NVPlayerPlayActivity.this.mGridView.getChildAt(item).getBackground().setAlpha(20);
                            }
                        }
                        return true;
                    case 2:
                        float x = event.getX();
                        float y = event.getY();
                        int i;
                        Rect rect;
                        if (NVPlayerPlayActivity.this.isCheck) {
                            for (i = 0; i < LocalDefines.alarmrows * LocalDefines.alarmcolumns; i++) {
                                rect = new Rect();
                                NVPlayerPlayActivity.this.mGridView.getChildAt(i).getHitRect(rect);
                                if (rect.contains((int) x, (int) y)) {
                                    NVPlayerPlayActivity.this.SelectAreaList.remove(i);
                                    NVPlayerPlayActivity.this.SelectAreaList.add(i, Integer.valueOf(0));
                                    NVPlayerPlayActivity.this.LocalAreaSelectmap.clear();
                                    NVPlayerPlayActivity.this.mGridView.getChildAt(i).setBackgroundColor(Color.parseColor("#000000"));
                                    NVPlayerPlayActivity.this.mGridView.getChildAt(i).getBackground().setAlpha(20);
                                }
                            }
                        } else {
                            for (i = 0; i < LocalDefines.alarmrows * LocalDefines.alarmcolumns; i++) {
                                rect = new Rect();
                                NVPlayerPlayActivity.this.mGridView.getChildAt(i).getHitRect(rect);
                                if (rect.contains((int) x, (int) y)) {
                                    NVPlayerPlayActivity.this.SelectAreaList.remove(i);
                                    NVPlayerPlayActivity.this.SelectAreaList.add(i, Integer.valueOf(1));
                                    NVPlayerPlayActivity.this.mGridView.getChildAt(i).setBackgroundColor(Color.parseColor("#ff0000"));
                                    NVPlayerPlayActivity.this.mGridView.getChildAt(i).getBackground().setAlpha(51);
                                }
                            }
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
        this.mGridView.setAdapter(this.adapter);
        for (i = 0; i < LocalDefines.alarmcolumns * LocalDefines.alarmrows; i++) {
            this.Viewlist.add(Constants.MAIN_VERSION_TAG);
            this.ALL_area_alarmlist.add(i, Integer.valueOf(1));
        }
        this.LocalAreaSelectmap = new HashMap();
        if (this.isSelectArea) {
            this.mGridView.setVisibility(0);
            this.btn_saveSelectArea.setVisibility(0);
            this.ll_alarmArea_explain.setVisibility(0);
            this.layoutPresetConfig.setVisibility(8);
            this.layout_Cloud_Terrace.setVisibility(8);
            this.layout_ScreenShot.setVisibility(8);
            this.layoutReverse.setVisibility(8);
            this.layoutMicBtn.setVisibility(8);
            this.layoutRecord.setVisibility(8);
            this.rlvideoSetting.setVisibility(8);
            this.btnSelectAllArea.setVisibility(0);
            this.ll_alarmArea_btn.setVisibility(0);
        } else {
            this.mGridView.setVisibility(8);
            this.btn_saveSelectArea.setVisibility(8);
            this.ll_alarmArea_explain.setVisibility(8);
            this.layoutPresetConfig.setVisibility(0);
            this.layout_Cloud_Terrace.setVisibility(0);
            this.layout_ScreenShot.setVisibility(0);
            this.layoutReverse.setVisibility(0);
            this.layoutMicBtn.setVisibility(0);
            this.layoutRecord.setVisibility(0);
            this.rlvideoSetting.setVisibility(0);
            this.btnSelectAllArea.setVisibility(8);
            this.ll_alarmArea_btn.setVisibility(8);
        }
        InitGLContainers();
        InitGLViewProgressbar();
        InitGLViewPlayer();
        ConnectGLViewToPlayer();
        SetGLViewPlayerMessageHandler();
        Player.ClearGLESScreen(this.glViews, true, 0);
        InitGLViewCloseButton();
        InitGLViewTouchEventEX();
        LibContext.SetContext(this.glViews[0], this.glViews[1], this.glViews[2], this.glViews[3]);
        Player.SelectWindow(0);
        FullScreenMode(0);
        ShowPortrailView();
        this.mBtnBack = (ImageView) findViewById(C0470R.id.buttonBackToLogin);
        this.mBtnBack.setOnClickListener(this);
        this.mBtnSound = (Button) findViewById(C0470R.id.btn_Listen);
        this.mBtnSound.setOnClickListener(this);
        this.tBtnMic = (TextView) findViewById(C0470R.id.buttonMicTxt);
        this.mBtnScreenShot2 = (Button) findViewById(C0470R.id.buttonScreenShot2);
        this.mBtnScreenShot2.setOnClickListener(this);
        this.mBtnMic2 = (Button) findViewById(C0470R.id.buttonMic2);
        this.mBtnMic2.setOnTouchListener(this);
        this.mBtnReverse2 = (Button) findViewById(C0470R.id.buttonReverse2);
        this.mBtnReverse2.setOnClickListener(this);
        this.mBtnSound2 = (Button) findViewById(C0470R.id.buttonSound2);
        this.mBtnSound2.setOnClickListener(this);
        this.mBtnBack2 = (Button) findViewById(C0470R.id.buttonBackToLogin2);
        this.mBtnBack2.setOnClickListener(this);
        this.tBtnImageQl = (TextView) findViewById(C0470R.id.buttonImageGQLTxt);
        this.mBtnImageQl2 = (Button) findViewById(C0470R.id.buttonImageGQL2);
        this.mBtnImageQl2.setOnClickListener(this);
        this.btnHD = (Button) findViewById(C0470R.id.btnHD);
        this.btnSmooth = (Button) findViewById(C0470R.id.btnSmooth);
        this.btnHD.setOnClickListener(this);
        this.btnSmooth.setOnClickListener(this);
        if (this.mQLHD) {
            this.mBtnImageQl.setVisibility(0);
            this.mBtnImageQl2.setVisibility(0);
        } else {
            this.mBtnImageQl.setVisibility(8);
            this.mBtnImageQl2.setVisibility(8);
        }
        if (this.mStreamType == 0) {
            this.btnSmooth.setTextColor(getResources().getColor(C0470R.color.font_color_blue));
            this.btnHD.setTextColor(-1);
        } else {
            this.btnSmooth.setTextColor(-1);
            this.btnHD.setTextColor(getResources().getColor(C0470R.color.font_color_blue));
        }
        readSystemParam();
        onSoundChange();
        this.mPlayingChn = 1;
        this.mIsPlaying = true;
        createDialogs();
    }

    private void registerReceiver(Context context) {
        IntentFilter filter = new IntentFilter();
        filter.addAction(LocalDefines.getReceiverActionString(context));
        this.mReceiver = new CloseActivityReceiver();
        registerReceiver(this.mReceiver, filter);
    }

    private void unRegisterReceiver() {
        if (this.mReceiver != null) {
            unregisterReceiver(this.mReceiver);
        }
    }

    private void stopCurrentActivityFromBroadcast() {
        if (this.isRecording) {
            this.isRecording = false;
            this.glViews[Player.CurrentSelPlayer()].StopRecord();
        }
        if (this.mIsPlaying) {
            setResult(-1);
            stopPlay(false);
            LibContext.ClearContext();
            ReleaseGLViewPlayer();
            this.m_bFinish = true;
            LocalDefines.B_UPDATE_LISTVIEW = true;
            unRegisterReceiver();
            finish();
            return;
        }
        stopPlay(false);
        this.m_bFinish = true;
        LibContext.ClearContext();
        ReleaseGLViewPlayer();
        LocalDefines.B_UPDATE_LISTVIEW = true;
        unRegisterReceiver();
        finish();
    }

    private void presetPopuwindow(boolean showTooView) {
        View view = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.ptzx_pannel_popupwindow, null);
        this.lvPreset = (ListView) view.findViewById(C0470R.id.lvPreset);
        Button btnPresetCancel = (Button) view.findViewById(C0470R.id.btnPresetCancel);
        this.progressBarPresetConfig = (ProgressBar) view.findViewById(C0470R.id.progressBarPresetConfig);
        LinearLayout llTopTitle = (LinearLayout) view.findViewById(C0470R.id.llTopTitle);
        presetList();
        if (showTooView) {
            btnPresetCancel.setVisibility(8);
            llTopTitle.setVisibility(0);
        } else {
            btnPresetCancel.setVisibility(8);
            llTopTitle.setVisibility(8);
        }
        btnPresetCancel.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if (NVPlayerPlayActivity.this.popupWindowMore != null) {
                    NVPlayerPlayActivity.this.popupWindowMore.dismiss();
                }
            }
        });
        float scale = getResources().getDisplayMetrics().density;
        if (((float) ((((int) ((((float) 60) * scale) + 0.5f)) * 6) + ((int) ((((float) 40) * scale) + 0.5f)))) > ((float) 225)) {
        }
        if (this.mScreenHeight < this.mScreenWidth) {
            this.popupWindowMore = new PopupWindow(view, (this.mScreenHeight * 4) / 5, -1);
        } else {
            this.popupWindowMore = new PopupWindow(view, -1, (int) (((double) (this.mScreenHeight - LocalDefines.getStatusBarHeight(this))) * 0.4d));
        }
        this.popupWindowMore.setFocusable(true);
        this.popupWindowMore.setOutsideTouchable(true);
        this.popupWindowMore.setBackgroundDrawable(new BitmapDrawable());
        this.popupWindowMore.showAtLocation(view, 83, 0, 0);
    }

    private void presetList() {
        if (this.m_nPTZXCount > 0) {
            ArrayList<Bitmap> listItem = new ArrayList();
            for (int i = 0; i < this.m_nPTZXCount; i++) {
                listItem.add(Functions.readBitMap(this, C0470R.drawable.alarm_icon));
            }
            this.ptzxAdapter = new PTZXPiontAdapter(this, listItem, C0470R.layout.preset_count_item, new String[]{"ItemPresetImage", "ItemPresetSetImage", "ItemPresetText", "ItemIDText"}, new int[]{C0470R.id.ivPresetImage, C0470R.id.btnPTZXSet, C0470R.id.tvPresetText, C0470R.id.tvPTZXID});
            if (this.lvPreset != null) {
                this.lvPreset.setCacheColorHint(0);
                this.lvPreset.setAdapter(this.ptzxAdapter);
                this.lvPreset.setOnItemClickListener(this);
            }
        }
    }

    private void stopPlay(boolean bFlag) {
        this.ptzTimerThreadID++;
        if (!(this.m_nAddType == Defines.SERVER_SAVE_TYPE_DEMO || this.glViews[Player.CurrentSelPlayer()] == null)) {
            this.bm = this.glViews[Player.CurrentSelPlayer()].Screenshot();
            if (this.bm != null) {
                Bitmap image = Functions.zoomBitmap(this.bm, Defines.SYSTEM_ID_WIN8, 240);
                if (this.m_nDeviceID > 0) {
                    DatabaseManager.setFaceForDevID(this.m_nDeviceID, image, this.m_strUsername, this.m_strPassword);
                } else {
                    DatabaseManager.setFaceForID(this.m_nID, image);
                }
            }
        }
        this.mIsPlaying = false;
        this.tvPlayDeviceID.setText(this.m_strName);
        this.mPlayingChn = -1;
        this.glViews[Player.CurrentSelPlayer()].scale(PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE);
        this.glViews[Player.CurrentSelPlayer()].StopPlay();
        Player.ShowProgressBar(0, false);
        Player.ShowProgressBar(1, false);
        Player.ShowProgressBar(2, false);
        Player.ShowProgressBar(3, false);
        Player.ClearGLESScreen(this.glViews, true, 0);
    }

    private void startPlay() {
        if (this.isSelectArea) {
            this.tvPlayDeviceID.setText(getString(C0470R.string.str_select_area_below));
        } else if (this.m_strName == null || this.m_strName.trim().length() <= 0) {
            this.tvPlayDeviceID.setText(getString(C0470R.string.Notification_Playing_Chn) + " " + this.m_strName);
        } else {
            this.tvPlayDeviceID.setText(getString(C0470R.string.Notification_Playing_Chn) + " " + this.m_strName);
        }
        this.glViews[Player.CurrentSelPlayer()].setnServerID(this.deviceParam.getnDeviceID());
        if (Player.CurrentSelPlayer() < 4) {
            Player.setPlaying(Player.CurrentSelPlayer(), true);
            Player.ClearGLESScreen(this.glViews, false, Player.CurrentSelPlayer());
            this.glViews[Player.CurrentSelPlayer()].EnableRender();
            this.glViews[Player.CurrentSelPlayer()].StartPlay(0, 0, this.mStreamType, this.mPlaySound, this.deviceParam);
            this.glViews[Player.CurrentSelPlayer()].setReverse(this.mIsReverse);
            this.glViews[Player.CurrentSelPlayer()].playAudio();
        }
        this.ptzTimerThreadID++;
        if (this.m_bPTZ) {
            new PTZTimerThread(this.ptzTimerThreadID).start();
        }
        this.mIsPlaying = true;
    }

    private void onStreamTypeChange(int nType) {
        if (this.mStreamType != nType) {
            this.mStreamType = nType;
            if (this.mStreamType == 0) {
                this.tBtnImageQl.setText(getString(C0470R.string.str_recording));
                this.mBtnImageQl.setBackgroundResource(C0470R.drawable.btn_recording);
                if (this.isRecording) {
                    this.glViews[Player.CurrentSelPlayer()].StopRecord();
                }
                this.isRecording = false;
                this.btnSmooth.setTextColor(-16776961);
                this.btnHD.setTextColor(-1);
            } else if (this.mStreamType == 1) {
                this.tBtnImageQl.setText(getString(C0470R.string.str_recording));
                this.mBtnImageQl.setBackgroundResource(C0470R.drawable.btn_recording);
                if (this.isRecording) {
                    this.glViews[Player.CurrentSelPlayer()].StopRecord();
                }
                this.isRecording = false;
                this.btnSmooth.setTextColor(-1);
                this.btnHD.setTextColor(-16776961);
            }
            if (this.mIsPlaying) {
                stopPlay(false);
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                startPlay();
            }
        }
    }

    private void onSoundChange() {
        if (this.mPlaySound) {
            this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_new));
            this.mBtnSound2.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal));
        } else {
            this.mBtnSound.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_new2));
            this.mBtnSound2.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.play_back_sound_btn_horziontal2));
        }
        int nChn = Player.CurrentSelPlayer();
        if (nChn >= 0 && nChn < 4) {
            this.glViews[Player.CurrentSelPlayer()].SetAudioParam(this.mPlaySound);
        }
        writeSystemParam();
    }

    public void onClick(View v) {
        int i;
        this.nToolsViewShowTickCount = 5;
        if (v == this.btnSelectAllArea) {
            this.SelectAreaList.clear();
            for (i = 0; i < LocalDefines.alarmcolumns * LocalDefines.alarmrows; i++) {
                this.SelectAreaList.add(i, Integer.valueOf(1));
            }
            this.isAllArea = true;
            this.adapter = new SelectAreaAdapter(this.mGridView, getApplicationContext(), this.SelectAreaList);
            this.mGridView.setAdapter(this.adapter);
        }
        if (v == this.btnCanelAllArea) {
            this.SelectAreaList.clear();
            for (i = 0; i < LocalDefines.alarmcolumns * LocalDefines.alarmrows; i++) {
                this.SelectAreaList.add(i, Integer.valueOf(0));
            }
            this.btnSelectAllArea.setText(C0470R.string.btnSelectALL);
            this.isAllArea = false;
            this.adapter = new SelectAreaAdapter(this.mGridView, getApplicationContext(), this.SelectAreaList);
            this.mGridView.setAdapter(this.adapter);
        }
        if (v == this.btn_saveSelectArea) {
            this.mGridView.setVisibility(8);
            DeviceAlarmAndPromptSettingFragment deviceAlarmAndPromptSettingFragment = new DeviceAlarmAndPromptSettingFragment();
            DeviceAlarmAndPromptSettingFragment.isSaveArea = true;
            LocalDefines.shouldUpdateSelectArea = true;
            LocalDefines.Localmap_Update_area.put(Integer.valueOf(this.deviceParam.getnDeviceID()), Boolean.valueOf(LocalDefines.shouldUpdateSelectArea));
            LocalDefines.LocalAlarmAreaList = this.SelectAreaList;
            for (i = 0; i < LocalDefines.LocalAlarmAreaList.size(); i++) {
                Integer num = (Integer) LocalDefines.LocalAlarmAreaList.get(i);
            }
            List splist = new ArrayList();
            SharedPreferences mySharedPreferences = getSharedPreferences("scenelist", 0);
            Editor edit = mySharedPreferences.edit();
            try {
                edit.putString("spArea_list_for" + this.deviceParam.getnDeviceID(), SpSaveList.SceneList2String(LocalDefines.LocalAlarmAreaList));
                edit.commit();
                splist = SpSaveList.String2SceneList(mySharedPreferences.getString("spArea_list_for" + this.deviceParam.getnDeviceID(), Constants.MAIN_VERSION_TAG));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e2) {
                e2.printStackTrace();
            }
            LocalDefines.Localmap_Select_area.put(Integer.valueOf(this.deviceParam.getnDeviceID()), LocalDefines.LocalAlarmAreaList);
            if (LocalDefines.Localmap_Select_area != null) {
                LocalDefines.LocalAlarmAreaList = (ArrayList) LocalDefines.Localmap_Select_area.get(Integer.valueOf(this.deviceParam.getnDeviceID()));
            }
            finish();
        }
        if (v == this.btn_selectArea) {
            this.mGridView.setVisibility(0);
            this.btnSelectAllArea.setVisibility(0);
            this.rlvideoSetting.setVisibility(8);
        } else if (v == this.btnCancelImageView) {
            this.iamgeViewDialog.dismiss();
        } else {
            if (v == this.layoutPresetConfig) {
                if (this.popupWindowMore != null && this.popupWindowMore.isShowing()) {
                    return;
                }
                if (this.m_bPTZX) {
                    presetPopuwindow(true);
                } else {
                    Toast.makeText(getApplicationContext(), getResources().getString(C0470R.string.str_preset_position), 0).show();
                }
            }
            if (v == this.ivPresetLandscape) {
                if (this.m_bPTZX) {
                    presetPopuwindow(false);
                } else {
                    Toast.makeText(getApplicationContext(), getResources().getString(C0470R.string.str_preset_position), 0).show();
                }
            }
            if (v == this.layout_ScreenShot) {
                if (!this.mIsPlaying) {
                    return;
                }
                if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                    this.screenshotDialog.show();
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 3);
                }
            } else if (v == this.mBtnScreenShot2) {
                if (!this.mIsPlaying) {
                    return;
                }
                if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                    this.screenshotDialog.show();
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 3);
                }
            } else if (v == this.layoutReverse) {
                if (this.m_bReversePRI) {
                    this.glViews[Player.CurrentSelPlayer()].SetCamImageOrientation(1000);
                    return;
                }
                this.mIsReverse = !this.mIsReverse;
                this.glViews[Player.CurrentSelPlayer()].setReverse(this.mIsReverse);
            } else if (v != this.mBtnReverse2) {
                if (v == this.mBtnImageQl) {
                    if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                        SaveRecordFile();
                    } else {
                        ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 3);
                        return;
                    }
                }
                if (v == this.txt_ImageGQL) {
                    if (this.m_isHD) {
                        this.txt_ImageGQL.setText(getResources().getString(C0470R.string.btnHD));
                        onStreamTypeChange(1);
                        this.txt_ImageGQL.setTextColor(getResources().getColor(C0470R.color.font_color_blue));
                        this.m_isHD = false;
                    } else {
                        this.txt_ImageGQL.setText(getResources().getString(C0470R.string.standardDefinition));
                        onStreamTypeChange(0);
                        this.m_isHD = true;
                        this.txt_ImageGQL.setTextColor(getResources().getColor(C0470R.color.font_color_white));
                    }
                } else if (v == this.btnHD) {
                    this.m_isHD = false;
                    onStreamTypeChange(1);
                    this.txt_ImageGQL.setTextColor(getResources().getColor(C0470R.color.font_color_blue));
                    this.txt_ImageGQL.setText(getResources().getString(C0470R.string.btnHD));
                } else if (v == this.btnSmooth) {
                    this.m_isHD = true;
                    onStreamTypeChange(0);
                    this.txt_ImageGQL.setTextColor(getResources().getColor(C0470R.color.font_color_white));
                    this.txt_ImageGQL.setText(getResources().getString(C0470R.string.standardDefinition));
                } else if (v == this.mBtnSound) {
                    v.setEnabled(false);
                    if (this.mPlaySound) {
                        this.mPlaySound = false;
                    } else {
                        this.mPlaySound = true;
                    }
                    onSoundChange();
                    v.setEnabled(true);
                } else if (v == this.mBtnSound2) {
                    v.setEnabled(false);
                    if (this.mPlaySound) {
                        this.mPlaySound = false;
                    } else {
                        this.mPlaySound = true;
                    }
                    onSoundChange();
                    v.setEnabled(true);
                } else if (v == this.mBtnStopAndPlay) {
                    this.mIsPlaying = !this.mIsPlaying;
                    if (this.mIsPlaying) {
                        this.mPlayingChn = 1;
                        startPlay();
                    } else {
                        stopPlay(true);
                    }
                } else if (v == this.mBtnBack) {
                    if (this.isSelectArea) {
                        finish();
                    } else {
                        exitCurrentActivity();
                    }
                } else if (v == this.mBtnBack2) {
                    if (this.isSelectArea) {
                        finish();
                    } else {
                        exitCurrentActivity();
                    }
                }
                if (v != this.layout_Cloud_Terrace) {
                    return;
                }
                if (this.popupWindowMore != null && this.popupWindowMore.isShowing()) {
                    return;
                }
                if (m_controlPanel) {
                    ptzContorlPopuwindow(false);
                    m_controlPanel = false;
                    return;
                }
                ptzContorlPopuwindow(true);
                m_controlPanel = true;
            } else if (this.m_bReversePRI) {
                this.glViews[Player.CurrentSelPlayer()].SetCamImageOrientation(1000);
            } else {
                this.mIsReverse = !this.mIsReverse;
                this.glViews[Player.CurrentSelPlayer()].setReverse(this.mIsReverse);
            }
        }
    }

    public void ShowNotic(String title, String msg) {
        Toast toast = Toast.makeText(getApplicationContext(), title, 0);
        toast.setGravity(17, 0, 0);
        toast.show();
    }

    public boolean hasPTZXPRI() {
        if (!this.m_bPTZ) {
            ShowNotic(getString(C0470R.string.deviceTurn), Constants.MAIN_VERSION_TAG);
            this.btnPTZDown.setEnabled(false);
            this.btnPTZLeft.setEnabled(false);
            this.btnPTZRight.setEnabled(false);
            this.btnPTZUP.setEnabled(false);
        }
        return this.m_bPTZ;
    }

    public boolean onTouch(View v, MotionEvent event) {
        if (v == this.layoutCenter) {
            this.mScaleGestureDetector.onTouchEvent(event);
            if (System.currentTimeMillis() - this.lScaleTime <= 500) {
                return true;
            }
            this.mGestureDetector.onTouchEvent(event);
            return true;
        } else if (v == this.mBtnMic) {
            return intercom(event, false);
        } else {
            if (v == this.mBtnMic2) {
                return intercom(event, true);
            }
            if (v == this.btnPTZLeft) {
                setPTXMoveView(event, PTZMoveDirectEnum.LEFT);
            } else if (v == this.btnPTZRight) {
                setPTXMoveView(event, PTZMoveDirectEnum.RIGHT);
            } else if (v == this.btnPTZUP) {
                setPTXMoveView(event, PTZMoveDirectEnum.UP);
            } else if (v == this.btnPTZDown) {
                setPTXMoveView(event, PTZMoveDirectEnum.DOWN);
            }
            return false;
        }
    }

    private boolean intercom(MotionEvent event, boolean isBtn2) {
        if (this.mIsPlaying) {
            Button btn = isBtn2 ? this.mBtnMic2 : this.mBtnMic;
            switch (event.getAction()) {
                case 0:
                    if (!shouldRemind()) {
                        setIntercomViewValue(btn, isBtn2 ? C0470R.drawable.cross_screen_btn_talk_click : C0470R.drawable.btn_talk_click, true, 0, true);
                        this.glViews[Player.CurrentSelPlayer()].StartSpeak();
                        break;
                    }
                    break;
                case 1:
                    setIntercomViewValue(btn, isBtn2 ? C0470R.drawable.cross_screen_btn_talk : C0470R.drawable.btn_talk, false, 8, true);
                    this.glViews[Player.CurrentSelPlayer()].StopSpeak();
                    break;
                case 2:
                    setIntercomViewValue(btn, isBtn2 ? C0470R.drawable.cross_screen_btn_talk_click : C0470R.drawable.btn_talk_click, true, 0, false);
                    break;
                case 3:
                    setIntercomViewValue(btn, isBtn2 ? C0470R.drawable.cross_screen_btn_talk : C0470R.drawable.btn_talk, false, 8, true);
                    this.glViews[Player.CurrentSelPlayer()].StopSpeak();
                    break;
                default:
                    break;
            }
        }
        return true;
    }

    private boolean shouldRemind() {
        if (!this.m_bSpeak) {
            Toast.makeText(this, getString(C0470R.string.str_do_not_support_mic), 0).show();
            return true;
        } else if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0) {
            return false;
        } else {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.RECORD_AUDIO"}, 2);
            return true;
        }
    }

    private void setIntercomViewValue(Button btn, int btnMicBgId, boolean isSpeaking, int llPlayTalkbackVisible, boolean isSleep) {
        btn.setBackgroundResource(btnMicBgId);
        this.llPlayTalkback.setVisibility(llPlayTalkbackVisible);
        this.mIsSpeaking = isSpeaking;
        if (isSleep) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean setPTXMoveView(MotionEvent event, PTZMoveDirectEnum moveDirect) {
        Button btn = null;
        if (moveDirect == PTZMoveDirectEnum.LEFT) {
            btn = this.btnPTZLeft;
        } else if (moveDirect == PTZMoveDirectEnum.RIGHT) {
            btn = this.btnPTZRight;
        } else if (moveDirect == PTZMoveDirectEnum.UP) {
            btn = this.btnPTZUP;
        } else if (moveDirect == PTZMoveDirectEnum.DOWN) {
            btn = this.btnPTZDown;
        }
        if (hasPTZXPRI()) {
            switch (event.getAction()) {
                case 0:
                    if (this.m_bPTZ) {
                        btn.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, moveDirect.bgId1)));
                    }
                    if (moveDirect != PTZMoveDirectEnum.LEFT) {
                        if (moveDirect != PTZMoveDirectEnum.RIGHT) {
                            if (moveDirect != PTZMoveDirectEnum.UP) {
                                if (moveDirect == PTZMoveDirectEnum.DOWN) {
                                    this.bIsDownPressed = true;
                                    break;
                                }
                            }
                            this.bIsUpPressed = true;
                            break;
                        }
                        this.bIsRightPressed = true;
                        break;
                    }
                    this.bIsLeftPressed = true;
                    break;
                    break;
                case 1:
                    btn.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, moveDirect.bgId2)));
                    setIsDirectPressedFalse();
                    break;
                case 3:
                    btn.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, moveDirect.bgId2)));
                    setIsDirectPressedFalse();
                    break;
                default:
                    break;
            }
        }
        return true;
    }

    private void setIsDirectPressedFalse() {
        this.bIsLeftPressed = false;
        this.bIsRightPressed = false;
        this.bIsUpPressed = false;
        this.bIsDownPressed = false;
    }

    private void showToolsViews() {
        if (this.popupWindowMore != null) {
            this.popupWindowMore.dismiss();
        }
        this.nToolsViewShowTickCount = 5;
        this.layoutBottomBar.setVisibility(0);
        if (this.bAnyway) {
            this.layoutTopBar.setVisibility(0);
            this.RlVertical.setVisibility(0);
            this.ivPresetLandscape.setVisibility(8);
            this.llLandscape.setVisibility(8);
            this.llLandscapeDefinition.setVisibility(8);
            return;
        }
        this.layoutTopBar.setVisibility(8);
        this.RlVertical.setVisibility(8);
        this.llLandscape.setVisibility(0);
        this.llLandscapeDefinition.setVisibility(0);
        if (this.m_bPTZX) {
            this.ivPresetLandscape.setVisibility(0);
        } else {
            this.ivPresetLandscape.setVisibility(4);
        }
    }

    private void hideToolsViews() {
        this.nToolsViewShowTickCount = 0;
        this.layoutBottomBar.setVisibility(8);
        this.layoutTopBar.setVisibility(8);
        this.llLandscape.setVisibility(8);
        this.llLandscapeDefinition.setVisibility(8);
        this.ivPresetLandscape.setVisibility(8);
    }

    private void startPTZXConfig(LoginHandle lhandle, int nPTZXID, int nPTZXAction, int nDeviceID) {
        this.m_nPTZXID++;
        new PTZXThread(this.handler, this.m_nPTZXID, lhandle, nPTZXID, nPTZXAction, nDeviceID).start();
    }

    private void locationPTZXPoint(int nPTZXID) {
        this.glViews[Player.CurrentSelPlayer()].CallPTZXLocationID(nPTZXID, this.deviceParam);
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long arg3) {
        if (((Integer) this.SelectAreaList.get(position)).intValue() == 0) {
            view.setBackgroundColor(Color.parseColor("#ff0000"));
            this.SelectAreaList.remove(position);
            this.SelectAreaList.add(position, Integer.valueOf(1));
            this.LocalAreaSelectmap.clear();
            view.getBackground().setAlpha(51);
            return;
        }
        view.setBackgroundColor(Color.parseColor("#000000"));
        view.getBackground().setAlpha(20);
        this.SelectAreaList.remove(position);
        this.SelectAreaList.add(position, Integer.valueOf(0));
        this.LocalAreaSelectmap.clear();
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 2 && !(permissions[0].equals("android.permission.RECORD_AUDIO") && grantResults[0] == 0)) {
            new Builder(this).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_microphone2)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent();
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", NVPlayerPlayActivity.this.getPackageName(), null));
                    NVPlayerPlayActivity.this.startActivity(intent);
                }
            }).show();
        }
        if (requestCode != 3) {
            return;
        }
        if (!permissions[0].equals("android.permission.WRITE_EXTERNAL_STORAGE") || grantResults[0] != 0) {
            new Builder(this).setTitle(getResources().getString(C0470R.string.str_permission_request)).setMessage(getResources().getString(C0470R.string.str_permission_storage1)).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent();
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", NVPlayerPlayActivity.this.getPackageName(), null));
                    NVPlayerPlayActivity.this.startActivity(intent);
                }
            }).show();
        }
    }

    private void SaveRecordFile() {
        String strSDcardPath = Functions.GetSDPath();
        if (strSDcardPath == null) {
            Toast.makeText(getApplicationContext(), getString(C0470R.string.noticeSDCardNotExist), 0).show();
            return;
        }
        String strSavePath = new StringBuilder(String.valueOf(strSDcardPath)).append(File.separator).append(LocalDefines.SDCardPath).toString();
        File file = new File(strSavePath);
        if (!file.exists()) {
            file.mkdir();
        }
        if (!this.mIsPlaying) {
            Toast.makeText(this, getString(C0470R.string.str_wait_to_play), 0).show();
        } else if (this.isRecording) {
            this.tBtnImageQl.setText(getString(C0470R.string.str_recording));
            this.mBtnImageQl.setBackgroundResource(C0470R.drawable.btn_recording);
            Toast.makeText(this, getString(C0470R.string.str_record_ok), 0).show();
            this.isRecording = false;
            this.glViews[Player.CurrentSelPlayer()].StopRecord();
        } else {
            this.tBtnImageQl.setText(getString(C0470R.string.str_recording_2));
            this.mBtnImageQl.setBackgroundResource(C0470R.drawable.btn_recording_click);
            this.glViews[Player.CurrentSelPlayer()].StartRecord(new StringBuilder(String.valueOf(strSavePath)).append(File.separator).append(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())).append("(").append(this.m_strName).append(")").append(".mp4").toString());
            this.isRecording = true;
        }
    }

    private void ptzContorlPopuwindow(boolean showTooView) {
        View view = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.popupwindow_ptz_control, null);
        this.controlPanel = (RelativeLayout) view.findViewById(C0470R.id.ptzCtrlPanel);
        this.btnPTZLeft = (Button) view.findViewById(C0470R.id.btnPTZLeft);
        this.btnPTZLeft.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.control_btn_left)));
        RelativeLayout.LayoutParams paramsLeft = (RelativeLayout.LayoutParams) this.btnPTZLeft.getLayoutParams();
        paramsLeft.width = (int) (((double) this.mScreenWidth) * 0.14d);
        paramsLeft.height = (int) (((double) this.mScreenWidth) * 0.14d);
        this.btnPTZLeft.setLayoutParams(paramsLeft);
        this.btnPTZLeft.setOnTouchListener(this);
        this.btnPTZRight = (Button) view.findViewById(C0470R.id.btnPTZRight);
        this.btnPTZRight.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.control_btn_right)));
        RelativeLayout.LayoutParams paramsRight = (RelativeLayout.LayoutParams) this.btnPTZRight.getLayoutParams();
        paramsRight.width = (int) (((double) this.mScreenWidth) * 0.14d);
        paramsRight.height = (int) (((double) this.mScreenWidth) * 0.14d);
        this.btnPTZRight.setLayoutParams(paramsRight);
        this.btnPTZRight.setOnTouchListener(this);
        this.btnPTZUP = (Button) view.findViewById(C0470R.id.btnPTZUP);
        this.btnPTZUP.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.control_btn_up)));
        RelativeLayout.LayoutParams paramsUP = (RelativeLayout.LayoutParams) this.btnPTZUP.getLayoutParams();
        paramsUP.width = (int) (((double) this.mScreenWidth) * 0.14d);
        paramsUP.height = (int) (((double) this.mScreenWidth) * 0.14d);
        this.btnPTZUP.setLayoutParams(paramsUP);
        this.btnPTZUP.setOnTouchListener(this);
        this.btnPTZDown = (Button) view.findViewById(C0470R.id.btnPTZDown);
        this.btnPTZDown.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.control_btn_down)));
        RelativeLayout.LayoutParams paramsDown = (RelativeLayout.LayoutParams) this.btnPTZDown.getLayoutParams();
        paramsDown.width = (int) (((double) this.mScreenWidth) * 0.14d);
        paramsDown.height = (int) (((double) this.mScreenWidth) * 0.14d);
        this.btnPTZDown.setLayoutParams(paramsDown);
        this.btnPTZDown.setOnTouchListener(this);
        float scale = getResources().getDisplayMetrics().density;
        if (((float) ((((int) ((((float) 60) * scale) + 0.5f)) * 6) + ((int) ((((float) 40) * scale) + 0.5f)))) > ((float) 225)) {
        }
        int statusBarHeight = LocalDefines.getStatusBarHeight(this);
        if (this.mScreenHeight < this.mScreenWidth) {
            this.popupWindowMore = new PopupWindow(view, (this.mScreenHeight * 4) / 5, -1);
        } else {
            this.popupWindowMore = new PopupWindow(view, -1, (int) (((double) (this.mScreenHeight - statusBarHeight)) * 0.4d));
        }
        this.popupWindowMore.setFocusable(true);
        this.popupWindowMore.setOutsideTouchable(true);
        this.popupWindowMore.setBackgroundDrawable(new BitmapDrawable());
        this.popupWindowMore.showAtLocation(view, 83, 0, 0);
        this.controlPanel.setLayoutParams(new LinearLayout.LayoutParams(this.mScreenWidth, (int) (((double) (this.mScreenHeight - statusBarHeight)) * 0.4d)));
    }

    public void DialogStopRecord() {
        View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(C0470R.string.Stop_recording);
        ((TextView) view.findViewById(C0470R.id.tv_content)).setVisibility(8);
        new Builder(this).setView(view).setNegativeButton(getString(C0470R.string.alert_btn_NO), null).setPositiveButton(getString(C0470R.string.alert_btn_YES), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                NVPlayerPlayActivity.this.isRecording = false;
                NVPlayerPlayActivity.this.glViews[Player.CurrentSelPlayer()].StopRecord();
                NVPlayerPlayActivity.this.tBtnImageQl.setText(NVPlayerPlayActivity.this.getString(C0470R.string.str_recording));
                NVPlayerPlayActivity.this.mBtnImageQl.setBackgroundResource(C0470R.drawable.btn_recording);
                NVPlayerPlayActivity.this.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
            }
        }).show();
    }

    private void exitCurrentActivity() {
        if (this.isRecording) {
            DialogStopRecord();
        } else if (this.mIsPlaying) {
            View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
            ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.alert_stop_play));
            ((TextView) view.findViewById(C0470R.id.tv_content)).setVisibility(8);
            new Builder(this).setView(view).setNegativeButton(getString(C0470R.string.alert_btn_NO), null).setPositiveButton(getString(C0470R.string.alert_btn_YES), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    try {
                        NVPlayerPlayActivity.this.stopPlay(false);
                    } catch (Exception e) {
                    }
                    LibContext.ClearContext();
                    NVPlayerPlayActivity.this.ReleaseGLViewPlayer();
                    NVPlayerPlayActivity.this.setResult(-1);
                    NVPlayerPlayActivity.this.mIsPlaying = false;
                    NVPlayerPlayActivity.this.m_bFinish = true;
                    NVPlayerPlayActivity.this.startActivity(new Intent(NVPlayerPlayActivity.this, HomePageActivity.class));
                    LocalDefines.B_UPDATE_LISTVIEW = true;
                    NVPlayerPlayActivity.this.unRegisterReceiver();
                    NVPlayerPlayActivity.this.finish();
                    NVPlayerPlayActivity.this.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                }
            }).show();
        } else {
            stopPlay(false);
            LibContext.ClearContext();
            ReleaseGLViewPlayer();
            this.m_bFinish = true;
            startActivity(new Intent(this, HomePageActivity.class));
            unRegisterReceiver();
            finish();
            overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
        }
    }
}
