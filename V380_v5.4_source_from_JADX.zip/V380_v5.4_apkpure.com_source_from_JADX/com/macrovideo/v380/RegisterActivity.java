package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.httptool.HttpUtils;
import com.macrovideo.sdk.defines.Defines;
import com.tencent.android.tpush.common.Constants;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends Activity implements OnClickListener {
    public static int REGISTER_THREAD_RESULT_CODE = 801;
    public static int SEND_VERIFY_THREAD_RESULT_CODE = LocalDefines.BIND_DEVICE_RESULT_CODE;
    private LinearLayout America_Area;
    private LinearLayout Australian_Area;
    private LinearLayout China_Area;
    public int Code_ActiveUser = DialogTipCode.USER_NOT_ACTIVATED;
    private int EMAIL_WAY = 2;
    private LinearLayout England_Area;
    private String MessageTxt;
    private int PHONE_WAY = 1;
    private int RegisterThreadID = 0;
    private LinearLayout Register_email_set_userinfo_layout;
    private LinearLayout Register_set_userinfo_layout;
    private int VerifyPasswordThreadID = 0;
    private Button btn_change_register_way;
    private Button btn_get_verify_code;
    private Button btn_register_by_mailbox;
    private Button btn_register_by_mobilephone;
    private Button btn_register_finish;
    private Button btn_register_next1;
    private Button btn_register_next2;
    private CheckBox cb_email_pwd;
    private CheckBox cb_protocol;
    private CheckBox cb_pwd;
    private CheckBox cb_second_pwd;
    private int dialogNo = -101;
    private DialogTimeCount dialog_showtime;
    public int errorResult_register = 1000;
    private RelativeLayout et_accout_layout;
    private RelativeLayout et_email_accout_layout;
    private RelativeLayout et_email_password_layout;
    private EditText et_email_register_account;
    private EditText et_email_verify;
    private RelativeLayout et_email_verify_layout;
    private EditText et_mailRegisterPassword;
    private RelativeLayout et_password_layout;
    private RelativeLayout et_phoneNo_layout;
    private EditText et_registerAccount;
    private EditText et_registerPassword;
    private EditText et_register_phoneNO;
    private EditText et_register_verify;
    private RelativeLayout et_second_verify_layout;
    private RelativeLayout et_verify_layout;
    @SuppressLint({"HandlerLeak"})
    private Handler handler = new C04751();
    private ImageView img_phoneNO_area;
    private boolean isMobileNo = true;
    private ImageView iv_back;
    private ImageView iv_back2;
    private ImageView iv_back3;
    private ImageView iv_cleanPassword;
    private Dialog lDialog;
    private Dialog mRegisterDlg;
    private LinearLayout number_area_layout;
    private TextView phoneNO_view_center;
    private TextView phoneNo_area_txt;
    private LinearLayout phoneNo_view_layout;
    private PopupWindow popupWindowAddManu;
    private int registerResult = -100;
    private int registerWay = 1;
    private EditText second_et_register_password;
    private EditText second_et_register_verify;
    private int sendVerifyresult = -1;
    private TimeCount2 time;
    private TextView txt_Remark;
    private TextView txt_title_register;
    private LinearLayout user_protocol_layout;

    class C04751 extends Handler {
        C04751() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 == RegisterActivity.REGISTER_THREAD_RESULT_CODE) {
                switch (msg.arg2) {
                    case -1:
                        RegisterActivity.this.closeRegisteringDlg();
                        RegisterActivity.this.showRegisterMessage(-1);
                        return;
                    case 0:
                        RegisterActivity.this.closeRegisteringDlg();
                        RegisterActivity.this.showRegisterMessage(0);
                        return;
                    case 500:
                        RegisterActivity.this.closeRegisteringDlg();
                        Toast.makeText(RegisterActivity.this, RegisterActivity.this.getString(C0470R.string.str_server_error), 0).show();
                        return;
                    case 20001:
                        RegisterActivity.this.closeRegisteringDlg();
                        RegisterActivity.this.showRegisterMessage(20001);
                        RegisterActivity.this.et_second_verify_layout.setVisibility(0);
                        RegisterActivity.this.et_register_verify.setText(RegisterActivity.this.second_et_register_verify.getText().toString());
                        return;
                    case 20002:
                        RegisterActivity.this.closeRegisteringDlg();
                        RegisterActivity.this.showRegisterMessage(20002);
                        RegisterActivity.this.et_second_verify_layout.setVisibility(0);
                        RegisterActivity.this.et_register_verify.setText(RegisterActivity.this.second_et_register_verify.getText().toString());
                        return;
                    case DialogTipCode.USER_IS_XISTENCE /*21003*/:
                        RegisterActivity.this.closeRegisteringDlg();
                        RegisterActivity.this.showRegisterMessage(DialogTipCode.USER_IS_XISTENCE);
                        return;
                    case DialogTipCode.USER_NOT_ACTIVATED /*21008*/:
                        RegisterActivity.this.closeRegisteringDlg();
                        RegisterActivity.this.showRegisterMessage(DialogTipCode.USER_NOT_ACTIVATED);
                        return;
                    default:
                        RegisterActivity.this.closeRegisteringDlg();
                        RegisterActivity.this.showRegisterMessage(-101);
                        return;
                }
            } else if (msg.arg1 != RegisterActivity.SEND_VERIFY_THREAD_RESULT_CODE) {
            } else {
                if (RegisterActivity.this.sendVerifyresult == DialogTipCode.USER_IS_XISTENCE) {
                    RegisterActivity.this.closeRegisteringDlg();
                    if (RegisterActivity.this.registerWay == RegisterActivity.this.PHONE_WAY) {
                        RegisterActivity.this.showRegisterMessage(DialogTipCode.USER_IS_XISTENCE);
                    } else {
                        RegisterActivity.this.showRegisterMessage(DialogTipCode.USER_IS_XISTENCE);
                    }
                } else if (RegisterActivity.this.sendVerifyresult == 0) {
                    RegisterActivity.this.closeRegisteringDlg();
                    RegisterActivity.this.btn_get_verify_code.setBackground(RegisterActivity.this.getResources().getDrawable(C0470R.drawable.verification_code));
                    RegisterActivity.this.btn_get_verify_code.setTextColor(Color.parseColor("#666666"));
                    RegisterActivity.this.time.start();
                } else if (RegisterActivity.this.sendVerifyresult == -1) {
                    RegisterActivity.this.closeRegisteringDlg();
                    RegisterActivity.this.showRegisterMessage(-1);
                } else if (RegisterActivity.this.sendVerifyresult == 500) {
                    RegisterActivity.this.closeRegisteringDlg();
                    Toast.makeText(RegisterActivity.this, RegisterActivity.this.getString(C0470R.string.str_server_error), 0).show();
                } else if (RegisterActivity.this.registerWay != RegisterActivity.this.EMAIL_WAY) {
                } else {
                    if (RegisterActivity.isEmailaddress(RegisterActivity.this.et_email_register_account.getText().toString())) {
                        RegisterActivity.this.btn_register_next1.setText(C0470R.string.str_register);
                        RegisterActivity.this.et_email_password_layout.setVisibility(0);
                        RegisterActivity.this.et_email_accout_layout.setVisibility(8);
                        RegisterActivity.this.et_email_verify_layout.setVisibility(0);
                        RegisterActivity.this.user_protocol_layout.setVisibility(8);
                        RegisterActivity.this.btn_register_by_mailbox.setVisibility(8);
                        RegisterActivity.this.txt_Remark.setVisibility(0);
                        RegisterActivity.this.btn_register_finish.setVisibility(0);
                        RegisterActivity.this.btn_register_next1.setVisibility(8);
                        return;
                    }
                    RegisterActivity.this.showRegisterMessage(111);
                }
            }
        }
    }

    class C04762 implements OnCheckedChangeListener {
        C04762() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            RegisterActivity.this.setPasswordVisibility(isChecked, 2);
        }
    }

    class C04773 implements OnCheckedChangeListener {
        C04773() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            RegisterActivity.this.setPasswordVisibility(isChecked, 1);
        }
    }

    class C04784 implements OnCheckedChangeListener {
        C04784() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                RegisterActivity.this.btn_register_next1.setEnabled(true);
            } else {
                RegisterActivity.this.btn_register_next1.setEnabled(false);
            }
        }
    }

    class C04795 implements OnCheckedChangeListener {
        C04795() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            RegisterActivity.this.setPasswordVisibility(isChecked, 3);
        }
    }

    class C04806 implements TextWatcher {
        C04806() {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (s != null) {
                s.toString().equals(Constants.MAIN_VERSION_TAG);
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void afterTextChanged(Editable s) {
        }
    }

    class C04817 implements TextWatcher {
        C04817() {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (s != null) {
                s.toString().equals(Constants.MAIN_VERSION_TAG);
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void afterTextChanged(Editable s) {
        }
    }

    class C04828 implements OnClickListener {
        C04828() {
        }

        public void onClick(View v) {
            RegisterActivity.this.lDialog.dismiss();
        }
    }

    class C04839 implements OnClickListener {
        C04839() {
        }

        public void onClick(View v) {
            RegisterActivity.this.lDialog.dismiss();
        }
    }

    class DialogTimeCount extends CountDownTimer {
        public DialogTimeCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        public void onFinish() {
            RegisterActivity.this.lDialog.dismiss();
            if (RegisterActivity.this.errorResult_register == 0 || RegisterActivity.this.errorResult_register == RegisterActivity.this.Code_ActiveUser) {
                RegisterActivity.this.startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        }

        public void onTick(long millisUntilFinished) {
        }
    }

    public class RegisterThread extends Thread {
        private Handler handler;
        private int m_RegisterThreadID = 0;

        public RegisterThread(Handler handler, int n_RegisterThreadID) {
            this.handler = handler;
            this.m_RegisterThreadID = n_RegisterThreadID;
        }

        public void run() {
            super.run();
            try {
                if (this.m_RegisterThreadID == RegisterActivity.this.RegisterThreadID) {
                    RegisterActivity.this.PostRegisterData();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = RegisterActivity.REGISTER_THREAD_RESULT_CODE;
            msg.arg2 = RegisterActivity.this.errorResult_register;
            this.handler.sendMessage(msg);
        }
    }

    class TimeCount2 extends CountDownTimer {
        public TimeCount2(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        public void onFinish() {
            RegisterActivity.this.btn_get_verify_code.setText(C0470R.string.str_verify_code);
            RegisterActivity.this.btn_get_verify_code.setClickable(true);
            RegisterActivity.this.btn_get_verify_code.setBackground(RegisterActivity.this.getResources().getDrawable(C0470R.drawable.verification_code_send));
            RegisterActivity.this.btn_get_verify_code.setTextColor(RegisterActivity.this.getResources().getColor(C0470R.color.font_color_sky_blue));
        }

        public void onTick(long millisUntilFinished) {
            RegisterActivity.this.btn_get_verify_code.setClickable(false);
            RegisterActivity.this.btn_get_verify_code.setText((millisUntilFinished / 1000) + "s");
        }
    }

    public class VerifyCodeThread extends Thread {
        private Handler handler;
        private int m_VerifyCodeThreadID = 0;

        public VerifyCodeThread(Handler handler, int n_VerifyCodeThreadID) {
            this.m_VerifyCodeThreadID = n_VerifyCodeThreadID;
            this.handler = handler;
        }

        public void run() {
            super.run();
            try {
                if (this.m_VerifyCodeThreadID == RegisterActivity.this.VerifyPasswordThreadID) {
                    RegisterActivity.this.PostVerifyCodeData();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = RegisterActivity.SEND_VERIFY_THREAD_RESULT_CODE;
            this.handler.sendMessage(msg);
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_register_mobile_phone);
        initViews();
    }

    private void initViews() {
        initLoginingDlg();
        this.time = new TimeCount2(60000, 1000);
        this.dialog_showtime = new DialogTimeCount(2000, 1000);
        this.phoneNO_view_center = (TextView) findViewById(C0470R.id.phoneNO_view_center);
        this.phoneNo_area_txt = (TextView) findViewById(C0470R.id.phoneNo_area_txt);
        this.txt_title_register = (TextView) findViewById(C0470R.id.txt_title_register);
        this.btn_get_verify_code = (Button) findViewById(C0470R.id.btn_get_verify_code);
        this.btn_get_verify_code.setOnClickListener(this);
        this.btn_register_next1 = (Button) findViewById(C0470R.id.btn_register_next1);
        this.btn_register_next1.setOnClickListener(this);
        this.btn_register_next2 = (Button) findViewById(C0470R.id.btn_register_next2);
        this.btn_register_next2.setOnClickListener(this);
        this.btn_register_finish = (Button) findViewById(C0470R.id.btn_register_finish);
        this.btn_register_finish.setOnClickListener(this);
        this.btn_change_register_way = (Button) findViewById(C0470R.id.btn_change_register_way);
        this.btn_change_register_way.setOnClickListener(this);
        this.btn_register_by_mailbox = (Button) findViewById(C0470R.id.btn_register_by_mailbox);
        this.btn_register_by_mailbox.setOnClickListener(this);
        this.btn_register_by_mobilephone = (Button) findViewById(C0470R.id.btn_register_by_mobilephone);
        this.btn_register_by_mobilephone.setOnClickListener(this);
        this.cb_second_pwd = (CheckBox) findViewById(C0470R.id.cb_second_register_pwd);
        this.cb_second_pwd.setOnCheckedChangeListener(new C04762());
        this.cb_pwd = (CheckBox) findViewById(C0470R.id.cb_first_register_pwd);
        this.cb_pwd.setOnCheckedChangeListener(new C04773());
        this.cb_protocol = (CheckBox) findViewById(C0470R.id.cb_user_protocol);
        this.cb_protocol.setOnCheckedChangeListener(new C04784());
        this.cb_email_pwd = (CheckBox) findViewById(C0470R.id.cb_email_register_pwd);
        this.cb_email_pwd.setOnCheckedChangeListener(new C04795());
        this.iv_back = (ImageView) findViewById(C0470R.id.iv_register_back);
        this.iv_back.setOnClickListener(this);
        this.iv_back2 = (ImageView) findViewById(C0470R.id.iv_register_back2);
        this.iv_back2.setOnClickListener(this);
        this.iv_back3 = (ImageView) findViewById(C0470R.id.iv_register_back3);
        this.iv_back3.setOnClickListener(this);
        this.img_phoneNO_area = (ImageView) findViewById(C0470R.id.img_phoneNO_area);
        this.et_register_phoneNO = (EditText) findViewById(C0470R.id.et_register_phoneNO);
        this.et_register_verify = (EditText) findViewById(C0470R.id.et_register_verify);
        this.et_registerPassword = (EditText) findViewById(C0470R.id.et_register_password);
        this.et_registerPassword.addTextChangedListener(new C04806());
        this.et_registerAccount = (EditText) findViewById(C0470R.id.et_register_account);
        this.et_registerAccount.addTextChangedListener(new C04817());
        this.et_phoneNo_layout = (RelativeLayout) findViewById(C0470R.id.et_phoneNo_layout);
        this.user_protocol_layout = (LinearLayout) findViewById(C0470R.id.user_protocol_layout);
        this.phoneNo_view_layout = (LinearLayout) findViewById(C0470R.id.phoneNo_view_layout);
        this.et_verify_layout = (RelativeLayout) findViewById(C0470R.id.et_verify_layout);
        this.et_accout_layout = (RelativeLayout) findViewById(C0470R.id.et_accout_layout);
        this.et_password_layout = (RelativeLayout) findViewById(C0470R.id.et_password_layout);
        this.et_second_verify_layout = (RelativeLayout) findViewById(C0470R.id.et_second_verify_layout);
        this.number_area_layout = (LinearLayout) findViewById(C0470R.id.number_area_layout);
        this.number_area_layout.setOnClickListener(this);
        this.txt_Remark = (TextView) findViewById(C0470R.id.txt_Remark);
        this.Register_set_userinfo_layout = (LinearLayout) findViewById(C0470R.id.Register_set_userinfo_layout);
        this.Register_email_set_userinfo_layout = (LinearLayout) findViewById(C0470R.id.Register_email_set_userinfo_layout);
        this.second_et_register_password = (EditText) findViewById(C0470R.id.second_et_register_password);
        this.et_mailRegisterPassword = (EditText) findViewById(C0470R.id.et_email_register_password);
        this.et_email_password_layout = (RelativeLayout) findViewById(C0470R.id.et_email_password_layout);
        this.et_email_accout_layout = (RelativeLayout) findViewById(C0470R.id.et_email_accout_layout);
        this.et_email_verify_layout = (RelativeLayout) findViewById(C0470R.id.et_email_verify_layout);
        this.second_et_register_verify = (EditText) findViewById(C0470R.id.second_et_register_verify);
        this.et_email_register_account = (EditText) findViewById(C0470R.id.et_email_register_account);
        this.et_email_verify = (EditText) findViewById(C0470R.id.et_email_verify);
        if (getResources().getConfiguration().locale.getCountry().equals("CN") || getResources().getConfiguration().locale.getCountry().equals("TW") || getResources().getConfiguration().locale.getCountry().equals("HK")) {
            this.txt_title_register.setText(C0470R.string.str_quick_register_phone);
            this.btn_register_by_mailbox.setText(C0470R.string.email_register);
            this.Register_email_set_userinfo_layout.setVisibility(8);
            this.et_phoneNo_layout.setVisibility(0);
            this.registerWay = 1;
            return;
        }
        this.txt_title_register.setText(C0470R.string.title_email_register);
        this.btn_register_by_mailbox.setText(C0470R.string.phone_register);
        this.Register_email_set_userinfo_layout.setVisibility(0);
        this.et_phoneNo_layout.setVisibility(8);
        this.registerWay = 2;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.iv_register_back:
                startActivity(new Intent(this, LoginActivity.class));
                finish();
                return;
            case C0470R.id.btn_get_verify_code:
                if (!this.et_register_phoneNO.getText().toString().equals(Constants.MAIN_VERSION_TAG)) {
                    isMobileNO(this.et_register_phoneNO.getText().toString());
                    showRegisteringDlg();
                    startVerifyCodeThread();
                    return;
                }
                return;
            case C0470R.id.iv_register_back2:
                if (this.registerWay == 1) {
                    this.btn_register_next2.setVisibility(8);
                    this.btn_register_next1.setVisibility(0);
                    this.et_phoneNo_layout.setVisibility(0);
                    this.user_protocol_layout.setVisibility(0);
                    this.btn_register_by_mailbox.setVisibility(0);
                    this.phoneNo_view_layout.setVisibility(8);
                    this.et_verify_layout.setVisibility(8);
                    this.iv_back.setVisibility(0);
                    this.iv_back2.setVisibility(8);
                }
                if (this.registerWay == 2) {
                    this.user_protocol_layout.setVisibility(0);
                    this.btn_register_next1.setVisibility(0);
                    this.btn_register_by_mailbox.setVisibility(0);
                    this.Register_email_set_userinfo_layout.setVisibility(0);
                    this.btn_register_finish.setVisibility(8);
                    this.Register_set_userinfo_layout.setVisibility(8);
                    this.txt_Remark.setVisibility(8);
                    this.iv_back.setVisibility(0);
                    this.iv_back2.setVisibility(8);
                    return;
                }
                return;
            case C0470R.id.iv_register_back3:
                if (this.registerWay == 1) {
                    this.btn_register_next2.setVisibility(0);
                    this.et_password_layout.setVisibility(0);
                    this.btn_register_finish.setVisibility(8);
                    this.phoneNo_view_layout.setVisibility(0);
                    this.et_verify_layout.setVisibility(0);
                    this.Register_set_userinfo_layout.setVisibility(8);
                    this.txt_Remark.setVisibility(8);
                    this.iv_back2.setVisibility(0);
                    this.iv_back3.setVisibility(8);
                    this.et_second_verify_layout.setVisibility(8);
                    this.et_registerPassword.setText(Constants.MAIN_VERSION_TAG);
                    this.second_et_register_password.setText(Constants.MAIN_VERSION_TAG);
                }
                if (this.registerWay == 2) {
                    this.user_protocol_layout.setVisibility(0);
                    this.btn_register_next1.setVisibility(0);
                    this.btn_register_by_mailbox.setVisibility(0);
                    this.Register_email_set_userinfo_layout.setVisibility(0);
                    this.btn_register_finish.setVisibility(8);
                    this.Register_set_userinfo_layout.setVisibility(8);
                    this.txt_Remark.setVisibility(8);
                    this.iv_back.setVisibility(0);
                    this.iv_back3.setVisibility(8);
                    this.et_second_verify_layout.setVisibility(8);
                    this.et_registerPassword.setText(Constants.MAIN_VERSION_TAG);
                    this.second_et_register_password.setText(Constants.MAIN_VERSION_TAG);
                    return;
                }
                return;
            case C0470R.id.number_area_layout:
                showAreaMenu(v);
                return;
            case C0470R.id.btn_register_next1:
                if (this.registerWay == 1) {
                    if (this.et_register_phoneNO.getText().toString().equals(Constants.MAIN_VERSION_TAG)) {
                        this.dialogNo = 103;
                        showRegisterMessage(this.dialogNo);
                        return;
                    } else if (isMobileNO(this.et_register_phoneNO.getText().toString())) {
                        this.phoneNO_view_center.setText(" " + this.et_register_phoneNO.getText().toString() + " ");
                        this.btn_register_next2.setVisibility(0);
                        this.btn_register_next1.setVisibility(8);
                        this.et_phoneNo_layout.setVisibility(8);
                        this.user_protocol_layout.setVisibility(8);
                        this.btn_register_by_mailbox.setVisibility(8);
                        this.phoneNo_view_layout.setVisibility(0);
                        this.et_verify_layout.setVisibility(0);
                        this.iv_back.setVisibility(8);
                        this.iv_back2.setVisibility(0);
                    } else {
                        this.dialogNo = DialogTipCode.PHONE_NUMBER_IS_NOT_STANDARDLIZED;
                        showRegisterMessage(this.dialogNo);
                        return;
                    }
                }
                if (this.registerWay != 2) {
                    return;
                }
                if (isEmailaddress(this.et_email_register_account.getText().toString())) {
                    this.user_protocol_layout.setVisibility(8);
                    this.btn_register_next1.setVisibility(8);
                    this.btn_register_by_mailbox.setVisibility(8);
                    this.Register_email_set_userinfo_layout.setVisibility(8);
                    this.btn_register_finish.setVisibility(0);
                    this.Register_set_userinfo_layout.setVisibility(0);
                    this.txt_Remark.setVisibility(0);
                    this.iv_back.setVisibility(8);
                    this.iv_back3.setVisibility(0);
                    return;
                }
                this.dialogNo = 113;
                showRegisterMessage(this.dialogNo);
                return;
            case C0470R.id.btn_register_next2:
                if (this.et_register_verify.getText().toString().equals(Constants.MAIN_VERSION_TAG)) {
                    this.dialogNo = DialogTipCode.VERIFY_CODE_IS_NOT_STANDARDLIZED;
                    showRegisterMessage(this.dialogNo);
                    return;
                } else if (isVerifyCode(this.et_register_verify.getText().toString())) {
                    this.btn_register_next2.setVisibility(8);
                    this.et_accout_layout.setVisibility(8);
                    this.et_password_layout.setVisibility(0);
                    this.btn_register_finish.setVisibility(0);
                    this.phoneNo_view_layout.setVisibility(8);
                    this.et_verify_layout.setVisibility(8);
                    this.txt_title_register.setText(C0470R.string.set_password);
                    this.Register_set_userinfo_layout.setVisibility(0);
                    this.txt_Remark.setVisibility(0);
                    this.iv_back2.setVisibility(8);
                    this.iv_back3.setVisibility(0);
                    return;
                } else {
                    this.dialogNo = DialogTipCode.VERIFY_CODE_IS_NOT_STANDARDLIZED;
                    showRegisterMessage(this.dialogNo);
                    return;
                }
            case C0470R.id.btn_register_finish:
                if (this.registerWay == 1) {
                    this.et_registerAccount.setText(this.et_register_phoneNO.getText().toString());
                }
                if (this.registerWay == 2) {
                    this.et_registerAccount.setText(this.et_email_register_account.getText().toString());
                }
                if (!passwordFormat(this.et_registerPassword.getText().toString())) {
                    showRegisterMessage(109);
                    return;
                } else if (!this.et_registerPassword.getText().toString().equals(this.second_et_register_password.getText().toString())) {
                    showRegisterMessage(110);
                    return;
                } else if (this.et_registerAccount.getText().toString().equals(Constants.MAIN_VERSION_TAG)) {
                    this.dialogNo = 101;
                    showRegisterMessage(this.dialogNo);
                    return;
                } else if (this.et_registerPassword.getText().toString().equals(Constants.MAIN_VERSION_TAG)) {
                    this.dialogNo = 109;
                    showRegisterMessage(this.dialogNo);
                    return;
                } else {
                    showRegisteringDlg();
                    startRegisterThread();
                    return;
                }
            case C0470R.id.btn_register_by_mailbox:
                if (this.registerWay == 1) {
                    this.txt_title_register.setText(C0470R.string.title_email_register);
                    this.btn_register_by_mailbox.setText(C0470R.string.phone_register);
                    this.Register_email_set_userinfo_layout.setVisibility(0);
                    this.et_phoneNo_layout.setVisibility(8);
                    this.registerWay = 2;
                    return;
                } else if (this.registerWay == 2) {
                    this.txt_title_register.setText(C0470R.string.str_quick_register_phone);
                    this.btn_register_by_mailbox.setText(C0470R.string.email_register);
                    this.Register_email_set_userinfo_layout.setVisibility(8);
                    this.et_phoneNo_layout.setVisibility(0);
                    this.registerWay = 1;
                    return;
                } else {
                    return;
                }
            case C0470R.id.China_Area:
                this.phoneNo_area_txt.setText("+86");
                this.popupWindowAddManu.dismiss();
                return;
            case C0470R.id.England_Area:
                this.phoneNo_area_txt.setText("+44");
                this.popupWindowAddManu.dismiss();
                return;
            case C0470R.id.America_Area:
                this.phoneNo_area_txt.setText("+1");
                this.popupWindowAddManu.dismiss();
                return;
            case C0470R.id.Australian_Area:
                this.phoneNo_area_txt.setText("+61");
                this.popupWindowAddManu.dismiss();
                return;
            default:
                return;
        }
    }

    public void startRegisterThread() {
        this.RegisterThreadID++;
        new RegisterThread(this.handler, this.RegisterThreadID).start();
    }

    public void startVerifyCodeThread() {
        this.VerifyPasswordThreadID++;
        new VerifyCodeThread(this.handler, this.VerifyPasswordThreadID).start();
    }

    private void PostRegisterData() throws JSONException {
        DecimalFormat df = new DecimalFormat("#.##");
        String content = null;
        long time = System.currentTimeMillis();
        String PhoneWayPassword = null;
        String MailPassword = null;
        try {
            byte[] Phonepassword = LoginActivity.encrypt(this.et_registerPassword.getText().toString().getBytes(), LoginActivity.key.getBytes());
            byte[] Mailpassword = LoginActivity.encrypt(this.et_registerPassword.getText().toString().getBytes(), LoginActivity.key.getBytes());
            PhoneWayPassword = LoginActivity.byte2hex(Phonepassword);
            MailPassword = LoginActivity.byte2hex(Mailpassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (this.registerWay == this.PHONE_WAY) {
            if (this.et_second_verify_layout.getVisibility() == 0) {
                this.et_register_verify.setText(this.second_et_register_verify.getText().toString());
            }
            String password = PhoneWayPassword;
            String MDLoginSign = md5("mobile=" + this.et_register_phoneNO.getText().toString() + "&password=" + password + "&timestamp=" + (time / 1000) + "&username=" + this.et_register_phoneNO.getText().toString() + "&validcode=" + this.et_register_verify.getText().toString() + "hsshop2016");
            JSONObject json = new JSONObject();
            json.put("sign", MDLoginSign);
            json.put("timestamp", (time / 1000));
            json.put("mobile", this.et_register_phoneNO.getText().toString());
            json.put("password", password);
            json.put("username", this.et_register_phoneNO.getText().toString());
            json.put("validcode", this.et_register_verify.getText().toString());
            content = json.toString();
        }
        if (this.registerWay == this.EMAIL_WAY) {
            password = MailPassword;
            MDLoginSign = md5("email=" + this.et_email_register_account.getText().toString() + "&password=" + password + "&timestamp=" + (time / 1000) + "&username=" + this.et_email_register_account.getText().toString() + "hsshop2016");
            json = new JSONObject();
            json.put("sign", MDLoginSign);
            json.put("timestamp", (time / 1000));
            json.put("email", this.et_email_register_account.getText().toString());
            json.put("password", password);
            json.put("username", this.et_email_register_account.getText().toString());
            content = json.toString();
        }
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/user/register", content);
        System.out.println("服务器返回的注册数据 = " + Recresult);
        if (Recresult == null) {
            return;
        }
        if (Recresult.equals("-1")) {
            this.errorResult_register = -1;
            return;
        }
        JSONObject jSONObject = new JSONObject(Recresult);
        if (jSONObject != null) {
            String result = jSONObject.getString("result");
            this.registerResult = Integer.valueOf(result).intValue();
            System.out.println("注册结果 = " + result);
            this.errorResult_register = Integer.valueOf(jSONObject.getString("error_code")).intValue();
            System.out.println("errorResult_register = " + this.errorResult_register);
        }
    }

    private void PostVerifyCodeData() throws JSONException {
        DecimalFormat df = new DecimalFormat("#.##");
        long time = System.currentTimeMillis();
        String content = null;
        if (this.registerWay == this.PHONE_WAY) {
            String MDLoginSign = md5("codetype=reg&target=" + this.et_register_phoneNO.getText().toString() + "&timestamp=" + (time / 1000) + "hsshop2016");
            JSONObject json = new JSONObject();
            json.put("sign", MDLoginSign);
            json.put("timestamp", (time / 1000));
            json.put("codetype", Constants.SHARED_PREFS_KEY_REGISTER);
            json.put("target", this.et_register_phoneNO.getText().toString());
            content = json.toString();
        }
        if (this.registerWay == this.EMAIL_WAY) {
            MDLoginSign = md5("codetype=reg&target=" + this.et_email_register_account.getText().toString() + "&timestamp=" + (time / 1000) + "hsshop2016");
            json = new JSONObject();
            json.put("sign", MDLoginSign);
            json.put("timestamp", (time / 1000));
            json.put("codetype", Constants.SHARED_PREFS_KEY_REGISTER);
            json.put("target", this.et_email_register_account.getText().toString());
            content = json.toString();
        }
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/tool/send-valid-code", content);
        System.out.println("服务器返回数据 = " + Recresult);
        if (Recresult != null) {
            json = new JSONObject(Recresult);
            String result = json.getString("result");
            this.sendVerifyresult = Integer.valueOf(json.getString("error_code")).intValue();
        }
    }

    public static String md5(String string) {
        try {
            byte[] hash = MessageDigest.getInstance("MD5").digest(string.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder(hash.length * 2);
            for (byte b : hash) {
                if ((b & 255) < 16) {
                    hex.append("0");
                }
                hex.append(Integer.toHexString(b & 255));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Huh, MD5 should be supported?", e);
        } catch (UnsupportedEncodingException e2) {
            throw new RuntimeException("Huh, UTF-8 should be supported?", e2);
        }
    }

    private void showRegisterMessage(int dialogNo) {
        this.lDialog = new Dialog(this, 16973840);
        this.lDialog.requestWindowFeature(1);
        this.lDialog.setContentView(C0470R.layout.dialog_registere_layout);
        Window dialogWindow = this.lDialog.getWindow();
        LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(48);
        Display d = getWindowManager().getDefaultDisplay();
        lp.width = d.getWidth() * 1;
        lp.height = (int) (((double) d.getWidth()) * 0.4d);
        dialogWindow.setAttributes(lp);
        TextView messageTxt = (TextView) this.lDialog.findViewById(C0470R.id.message_register);
        messageTxt.getBackground().setAlpha(Defines.REC_FILE_SEARCH);
        switch (dialogNo) {
            case -1:
                messageTxt.setText(C0470R.string.Network_Error);
                break;
            case 0:
                if (this.registerWay == 1) {
                    messageTxt.setText(C0470R.string.Register_success);
                }
                if (this.registerWay == 2) {
                    messageTxt.setText(C0470R.string.Mailbox_register_successfully);
                    break;
                }
                break;
            case 101:
                messageTxt.setText(C0470R.string.The_username_can_not_be_empty);
                break;
            case 103:
                messageTxt.setText(C0470R.string.The_phone_number_can_not_be_empty);
                break;
            case DialogTipCode.PHONE_NUMBER_IS_NOT_STANDARDLIZED /*104*/:
                messageTxt.setText(C0470R.string.Please_enter_the_correct_phone_number);
                break;
            case DialogTipCode.VERIFY_CODE_IS_NOT_STANDARDLIZED /*107*/:
                messageTxt.setText(C0470R.string.The_verify_code_can_not_be_empty);
                break;
            case 108:
                messageTxt.setText(C0470R.string.confirm_correct_username);
                break;
            case 109:
                messageTxt.setText(C0470R.string.confirm_correct_password);
                break;
            case 110:
                messageTxt.setText(C0470R.string.password_do_not_match);
                break;
            case 111:
                messageTxt.setText(C0470R.string.enter_correct_mailbox);
                break;
            case 113:
                messageTxt.setText(C0470R.string.Please_enter_the_correct_mailbox_address);
                break;
            case 10004:
                if (this.registerWay != this.PHONE_WAY) {
                    messageTxt.setText(C0470R.string.Mail_Is_Exist);
                    break;
                } else {
                    messageTxt.setText(C0470R.string.Phone_exist);
                    break;
                }
            case 20001:
                messageTxt.setText(C0470R.string.Verify_code_is_incorrect);
                break;
            case 20002:
                messageTxt.setText(C0470R.string.verify_codes_is_overtime);
                break;
            case DialogTipCode.USER_IS_XISTENCE /*21003*/:
                if (this.registerWay != this.PHONE_WAY) {
                    messageTxt.setText(C0470R.string.Mail_Is_Exist);
                    break;
                } else {
                    messageTxt.setText(C0470R.string.Phone_exist);
                    break;
                }
            case DialogTipCode.USER_NOT_ACTIVATED /*21008*/:
                messageTxt.setText(C0470R.string.User_not_activitated);
                break;
        }
        ((Button) this.lDialog.findViewById(C0470R.id.positiveButton)).setOnClickListener(new C04828());
        ((Button) this.lDialog.findViewById(C0470R.id.negativeButton)).setOnClickListener(new C04839());
        this.lDialog.show();
        this.dialog_showtime.start();
    }

    private void initLoginingDlg() {
        this.mRegisterDlg = new Dialog(this, C0470R.style.loginingDlg);
        this.mRegisterDlg.setContentView(C0470R.layout.logining_dlg);
        LayoutParams params = this.mRegisterDlg.getWindow().getAttributes();
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int cxScreen = dm.widthPixels;
        int height = (int) getResources().getDimension(C0470R.dimen.loginingdlg_height);
        int lrMargin = (int) getResources().getDimension(C0470R.dimen.loginingdlg_lr_margin);
        int topMargin = (int) getResources().getDimension(C0470R.dimen.loginingdlg_top_margin);
        params.y = ((-(dm.heightPixels - height)) / 2) + topMargin;
        params.width = cxScreen;
        params.height = height;
        this.mRegisterDlg.setCanceledOnTouchOutside(true);
    }

    private void showRegisteringDlg() {
        if (this.mRegisterDlg != null) {
            this.mRegisterDlg.show();
        }
    }

    private void closeRegisteringDlg() {
        if (this.mRegisterDlg != null && this.mRegisterDlg.isShowing()) {
            this.mRegisterDlg.dismiss();
        }
    }

    public static boolean isMobileNO(String mobiles) {
        return Pattern.compile("^(([0-9][0-9][0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$").matcher(mobiles).matches();
    }

    private void setPasswordVisibility(boolean isVisible, int id) {
        if (isVisible) {
            switch (id) {
                case 1:
                    this.et_registerPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    this.et_registerPassword.setSelection(this.et_registerPassword.getText().toString().length());
                    return;
                case 2:
                    this.second_et_register_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    this.second_et_register_password.setSelection(this.second_et_register_password.getText().toString().length());
                    return;
                case 3:
                    this.et_mailRegisterPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    this.et_mailRegisterPassword.setSelection(this.et_mailRegisterPassword.getText().toString().length());
                    return;
                default:
                    return;
            }
        }
        switch (id) {
            case 1:
                this.et_registerPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                this.et_registerPassword.setSelection(this.et_registerPassword.getText().toString().length());
                return;
            case 2:
                this.second_et_register_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                this.second_et_register_password.setSelection(this.second_et_register_password.getText().toString().length());
                return;
            case 3:
                this.et_mailRegisterPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                this.et_mailRegisterPassword.setSelection(this.et_mailRegisterPassword.getText().toString().length());
                return;
            default:
                return;
        }
    }

    private void showAreaMenu(View v) {
        View view = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0470R.layout.menu_area_popuwindow, null);
        this.China_Area = (LinearLayout) view.findViewById(C0470R.id.China_Area);
        this.China_Area.setOnClickListener(this);
        this.England_Area = (LinearLayout) view.findViewById(C0470R.id.England_Area);
        this.England_Area.setOnClickListener(this);
        this.America_Area = (LinearLayout) view.findViewById(C0470R.id.America_Area);
        this.America_Area.setOnClickListener(this);
        this.Australian_Area = (LinearLayout) view.findViewById(C0470R.id.Australian_Area);
        this.Australian_Area.setOnClickListener(this);
        float scale = getResources().getDisplayMetrics().density;
        this.popupWindowAddManu = new PopupWindow(view, (int) ((((float) 50) * scale) + 0.5f), (int) ((((float) 340) * scale) + 0.5f));
        this.popupWindowAddManu.setFocusable(true);
        this.popupWindowAddManu.setOutsideTouchable(true);
        this.popupWindowAddManu.setBackgroundDrawable(new BitmapDrawable());
        this.popupWindowAddManu.setAnimationStyle(C0470R.style.popupwindow_relevance_anim);
        this.popupWindowAddManu.showAsDropDown(v);
    }

    private static boolean passwordFormat(String password) {
        System.out.println("输入的密码:" + password);
        return Pattern.compile("^[a-zA-Z0-9_`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？][a-zA-Z0-9_`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]{5,13}$").matcher(password).matches();
    }

    private static boolean UsernameFormat(String username) {
        System.out.println("输入的密码:" + username);
        return Pattern.compile("^[a-zA-Z0-9_][a-zA-Z0-9_]{3,19}$").matcher(username).matches();
    }

    private static boolean isEmailaddress(String mailboxAddress) {
        return Pattern.compile("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$").matcher(mailboxAddress).matches();
    }

    private boolean isVerifyCode(String code) {
        return Pattern.compile("^([0-9]{6})$").matcher(code).matches();
    }
}
