package com.macrovideo.v380;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import com.tencent.android.tpush.common.Constants;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import java.util.LinkedList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.sourceforge.simcpux.MD5;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

public class WeChatPayActivity extends Activity implements OnClickListener {
    public static String DataJson = null;
    public static int payNum = 0;
    String AesStr = Constants.MAIN_VERSION_TAG;
    boolean NetWorkstate = true;
    private Button confirmButton;
    private boolean ispaytofail = false;
    private ImageView ivWeChatPayBack;
    private int m_nActiveID = 0;
    private IWXAPI msgApi = WXAPIFactory.createWXAPI(this, null);
    private PayReq req;
    private StringBuffer sb;

    class DownTicker extends CountDownTimer {
        private int nActiveID = 0;

        public DownTicker(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        public void setNActiveID(int nActiveID) {
            this.nActiveID = nActiveID;
        }

        public void onFinish() {
            if (WeChatPayActivity.this.m_nActiveID == this.nActiveID) {
                WeChatPayActivity.this.startActivity(new Intent(WeChatPayActivity.this, WeChatWebViewActivity.class));
                WeChatPayActivity.this.finish();
            }
        }

        public void onTick(long millisUntilFinished) {
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_wechatpay);
        Intent intent = getIntent();
        this.ispaytofail = intent.getBooleanExtra("paytocanel", false);
        if (!intent.getStringExtra("WeChatData").equals(Constants.MAIN_VERSION_TAG)) {
            DataJson = intent.getStringExtra("WeChatData");
        }
        this.confirmButton = (Button) findViewById(C0470R.id.bt_corfirm);
        this.ivWeChatPayBack = (ImageView) findViewById(C0470R.id.ivWeChatPayBack);
        this.ivWeChatPayBack.setOnClickListener(this);
        this.confirmButton.setOnClickListener(this);
        this.sb = new StringBuffer();
        this.req = new PayReq();
        if (!this.ispaytofail) {
            if (isWXAppInstalledAndSupported()) {
                startPay();
                finish();
                return;
            }
            Toast.makeText(getApplicationContext(), getString(C0470R.string.str_please_intall_wechat), 0).show();
        }
    }

    protected void onDestroy() {
        this.req = null;
        this.msgApi = null;
        System.gc();
        super.onDestroy();
    }

    public void startPay() {
        try {
            genPayReq(DataJson);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        sendPayReq();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.ivWeChatPayBack:
                Intent intent = new Intent(this, WeChatWebViewActivity.class);
                intent.putExtra("url", new StringBuilder(LocalDefines.CLOUD_STORE_URL).append(WeChatWebViewActivity.mAccesstoken).append("&ver=").append(1).toString());
                startActivity(intent);
                finish();
                return;
            case C0470R.id.bt_corfirm:
                if (isWXAppInstalledAndSupported()) {
                    startPay();
                    finish();
                    return;
                }
                Toast.makeText(getApplicationContext(), getString(C0470R.string.str_please_intall_wechat), 0).show();
                return;
            default:
                return;
        }
    }

    private boolean isWXAppInstalledAndSupported() {
        IWXAPI msgApi = WXAPIFactory.createWXAPI(this, null);
        msgApi.registerApp(net.sourceforge.simcpux.Constants.APP_ID);
        return msgApi.isWXAppInstalled();
    }

    private void genPayReq(String data) throws JSONException {
        JSONObject json = new JSONObject(data);
        String appid = json.getString("appid");
        net.sourceforge.simcpux.Constants.APP_ID = appid;
        String partnerid = json.getString("mch_id");
        String nonce_str = json.getString("nonce_str");
        String prepay_id = json.getString("prepay_id");
        List<NameValuePair> signParams = new LinkedList();
        signParams.add(new BasicNameValuePair("appid", appid));
        signParams.add(new BasicNameValuePair("noncestr", nonce_str));
        signParams.add(new BasicNameValuePair("package", "Sign=WXPay"));
        signParams.add(new BasicNameValuePair("partnerid", partnerid));
        signParams.add(new BasicNameValuePair("prepayid", prepay_id));
        signParams.add(new BasicNameValuePair("timestamp", String.valueOf(genTimeStamp())));
        this.req.appId = appid;
        this.req.nonceStr = nonce_str;
        this.req.packageValue = "Sign=WXPay";
        this.req.partnerId = partnerid;
        this.req.prepayId = prepay_id;
        this.req.timeStamp = String.valueOf(genTimeStamp());
        this.req.sign = genAppSign(signParams);
        this.sb.append("sign\n" + this.req.sign + "\n\n");
    }

    private long genTimeStamp() {
        return System.currentTimeMillis() / 1000;
    }

    private void sendPayReq() {
        this.msgApi.registerApp(net.sourceforge.simcpux.Constants.APP_ID);
        boolean result = this.msgApi.sendReq(this.req);
    }

    private String genAppSign(List<NameValuePair> params) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < params.size(); i++) {
            sb.append(((NameValuePair) params.get(i)).getName());
            sb.append('=');
            sb.append(((NameValuePair) params.get(i)).getValue());
            sb.append('&');
        }
        sb.append("key=");
        sb.append(net.sourceforge.simcpux.Constants.API_KEY);
        this.sb.append("sign str\n" + sb.toString() + "\n\n");
        return MD5.getMessageDigest(sb.toString().getBytes());
    }

    public static String decrypt(String input, String key) {
        byte[] output = null;
        try {
            SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(2, skey);
            output = cipher.doFinal(input.getBytes());
        } catch (Exception e) {
        }
        return new String(output);
    }

    public static String encrypt(String input, String key) {
        byte[] crypted = null;
        try {
            SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(1, skey);
            crypted = cipher.doFinal(input.getBytes());
        } catch (Exception e) {
        }
        return new String(crypted);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            Intent intent = new Intent(this, WeChatWebViewActivity.class);
            intent.putExtra("url", new StringBuilder(LocalDefines.CLOUD_STORE_URL).append(WeChatWebViewActivity.mAccesstoken).append("&ver=").append(1).toString());
            startActivity(intent);
            finish();
        }
        return false;
    }
}
