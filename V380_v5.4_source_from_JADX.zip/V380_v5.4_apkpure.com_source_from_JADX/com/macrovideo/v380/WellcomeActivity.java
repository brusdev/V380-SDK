package com.macrovideo.v380;

import android.app.Activity;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.app.NotificationCompat.Builder;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.macrovideo.lock.GestureEditActivity;
import com.macrovideo.lock.GestureVerifyActivity;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import java.io.File;

public class WellcomeActivity extends Activity {
    private AdsRunnable adsRunnable = null;
    private Handler handler = new Handler();
    private boolean isFinish = false;
    private boolean isShowingAds = false;
    private ImageView luancherFace = null;
    private Button mBtnSkipAds;
    private int m_nActiveID = 0;
    private String strCountryCode = "en";

    class AdsRunnable implements Runnable {
        private Intent mIntent;
        private int mShowTime;

        public AdsRunnable(Intent intent, int time) {
            this.mIntent = intent;
            this.mShowTime = time;
        }

        public void run() {
            this.mShowTime--;
            if (this.mShowTime > 0) {
                WellcomeActivity.this.handler.postDelayed(this, 3000);
            } else {
                WellcomeActivity.this.finishActivity(this.mIntent);
            }
        }

        private Intent getIntent() {
            return this.mIntent;
        }
    }

    class DownTicker extends CountDownTimer {
        private int nActiveID = 0;

        public DownTicker(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        public void setNActiveID(int nActiveID) {
            this.nActiveID = nActiveID;
        }

        public void onTick(long millisUntilFinished) {
        }

        public void onFinish() {
            if (WellcomeActivity.this.m_nActiveID == this.nActiveID) {
                SharedPreferences preferences = WellcomeActivity.this.getSharedPreferences(GestureEditActivity.PARAM_LOCK_PASSWORD, 0);
                SharedPreferences version_pref = WellcomeActivity.this.getSharedPreferences(LocalDefines.VERSION_PREF, 0);
                String patternString = preferences.getString(GestureEditActivity.PARAM_LOCK_PASSWORD_KEY, null);
                boolean bIsPasswordOpen = preferences.getBoolean(LocalDefines.SOFTWARE_PASSWORD_STATE, false);
                Intent intent = new Intent();
                if (patternString == null || !bIsPasswordOpen) {
                    String app_version = WellcomeActivity.this.getResources().getString(C0470R.string.app_ver);
                    if (app_version.equals(version_pref.getString(LocalDefines.APP_VERSION, Constants.MAIN_VERSION_TAG))) {
                        LocalDefines.isFirstIn = false;
                    } else {
                        Editor editor = version_pref.edit();
                        editor.putString(LocalDefines.APP_VERSION, app_version);
                        editor.commit();
                        LocalDefines.isFirstIn = true;
                    }
                    LocalDefines.shouldLoadUserDeviceList = true;
                    if (WellcomeActivity.this.getSharedPreferences("ShareAPPMODE", 0).getInt("GetModeNum", -101) != 1) {
                        intent.setClass(WellcomeActivity.this, LoginActivity.class);
                    } else {
                        intent.setClass(WellcomeActivity.this, HomePageActivity.class);
                    }
                } else {
                    intent.setClass(WellcomeActivity.this, GestureVerifyActivity.class);
                    LocalDefines.B_INTENT_ACTIVITY = true;
                }
                Bundle bundle = new Bundle();
                bundle.putInt("page_index", 10);
                bundle.putInt("radio_index", 100);
                bundle.putBoolean("has_serverinfo", false);
                intent.putExtras(bundle);
                long ad_id = version_pref.getLong(LocalDefines.AD_ID, 0);
                int ad_frequency = version_pref.getInt(LocalDefines.AD_SHOW_FREQUENCY, 0);
                int ad_show_already = version_pref.getInt(LocalDefines.AD_SHOW_ALREADY, 0);
                if (LocalDefines.isFirstIn || ad_id == 0 || ad_show_already >= ad_frequency || !WellcomeActivity.this.hasPermissionWriteSD()) {
                    WellcomeActivity.this.finishActivity(intent);
                    return;
                }
                WellcomeActivity.this.showAdImage(new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getPath())).append(File.separator).append("hongshi").append(File.separator).append("ad.o").toString(), version_pref.getInt(LocalDefines.AD_SHOW_DURATION, 3), intent);
            }
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if ((getIntent().getFlags() & 4194304) != 0) {
            finish();
            return;
        }
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(C0470R.layout.activity_wellcome);
        this.luancherFace = (ImageView) findViewById(C0470R.id.luancher_face);
        this.mBtnSkipAds = (Button) findViewById(C0470R.id.btn_skip_ad);
        this.mBtnSkipAds.setAlpha(77.0f);
        this.mBtnSkipAds.setVisibility(8);
        this.strCountryCode = getString(C0470R.string.country_code);
        if ("hans".compareTo(this.strCountryCode) == 0) {
            this.luancherFace.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.wellcome_bg)));
        } else if ("hant".compareTo(this.strCountryCode) == 0) {
            this.luancherFace.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.wellcome_bg)));
        } else {
            this.luancherFace.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this, C0470R.drawable.wellcome_bg)));
        }
        this.m_nActiveID++;
        DownTicker ticker = new DownTicker(2000, 1000);
        ticker.setNActiveID(this.m_nActiveID);
        ticker.start();
    }

    public void onStop() {
        if (!this.isFinish) {
            this.m_nActiveID++;
            NotificationManager notiManager = (NotificationManager) getSystemService("notification");
            Builder builder = new Builder(this);
            builder.setContentTitle(getString(C0470R.string.app_name)).setContentText(getString(C0470R.string.app_notice)).setTicker(getString(C0470R.string.app_name)).setWhen(System.currentTimeMillis()).setOngoing(false).setSmallIcon(C0470R.drawable.icon);
            Intent intent = new Intent(this, WellcomeActivity.class);
            intent.setFlags(335544320);
            builder.setContentIntent(PendingIntent.getActivity(getApplicationContext(), 0, intent, 0));
            notiManager.notify(257, builder.build());
        }
        super.onStop();
    }

    public void onResume() {
        super.onResume();
        ((NotificationManager) getSystemService("notification")).cancel(257);
        this.isFinish = false;
        this.m_nActiveID++;
        DownTicker ticker = new DownTicker(2000, 1000);
        ticker.setNActiveID(this.m_nActiveID);
        ticker.start();
    }

    protected void onDestroy() {
        if (this.luancherFace != null) {
            BitmapDrawable luancherFaces = (BitmapDrawable) this.luancherFace.getBackground();
            if (luancherFaces != null) {
                this.luancherFace.setBackgroundResource(0);
                luancherFaces.setCallback(null);
                if (luancherFaces.getBitmap() != null) {
                    luancherFaces.getBitmap().recycle();
                }
                System.gc();
            }
        }
        super.onDestroy();
    }

    private void showAdImage(String adPath, int time, Intent intent) {
        this.mBtnSkipAds.setVisibility(0);
        this.isShowingAds = true;
        if (new File(adPath).exists()) {
            SharedPreferences version_pref = getSharedPreferences(LocalDefines.VERSION_PREF, 0);
            version_pref.edit().putInt(LocalDefines.AD_SHOW_ALREADY, version_pref.getInt(LocalDefines.AD_SHOW_ALREADY, 0) + 1).apply();
            Glide.with((Activity) this).load(new File(adPath)).diskCacheStrategy(DiskCacheStrategy.NONE).into(this.luancherFace);
            this.adsRunnable = new AdsRunnable(intent, time);
            this.handler.postDelayed(this.adsRunnable, 1000);
            return;
        }
        finishActivity(intent);
    }

    private boolean hasPermissionWriteSD() {
        if (VERSION.SDK_INT < 23 || checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        return false;
    }

    private void startGetAdInfoService() {
        if (Functions.isNetworkAvailable(getApplicationContext()) && hasPermissionWriteSD()) {
            startService(new Intent(this, AdsInfoService.class));
        }
    }

    private void finishActivity(Intent intent) {
        startActivity(intent);
        this.isFinish = true;
        startGetAdInfoService();
        finish();
    }

    public void skipAd(View view) {
        if (this.adsRunnable != null) {
            this.handler.removeCallbacks(this.adsRunnable);
            finishActivity(this.adsRunnable.getIntent());
        }
    }
}
