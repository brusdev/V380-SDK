package com.macrovideo.v380;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import com.bumptech.glide.Glide;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.MessageKey;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;

public class AdsInfoService extends IntentService {
    private static final int RESULT_CODE_APP_ID_NOT_FOUND = -1003;
    private static final int RESULT_CODE_LATEST_DATA = -1002;
    private static final int RESULT_CODE_NO_AD_OR_MS = -1004;
    private static final int RESULT_CODE_NO_NEED_TO_SHOW = -1005;
    private static final int RESULT_CODE_PARAMS_ERROR = -1001;
    private static final int RESULT_CODE_SUCCESS = 0;
    private static final int TYPE_AD = 1;
    private static final int TYPE_MS = 2;
    public static String mAdFilePath = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getPath())).append(File.separator).append(LocalDefines.SDCardPath).append(File.separator).append("ad.o").toString();
    private String mAdIpAddr = "ad.nvdvr.cn";
    private String mAdParams = "/ad/index.php?param=";
    private int mAdPort = 80;

    public AdsInfoService() {
        super("AdsInfoService");
    }

    protected void onHandleIntent(Intent intent) {
        try {
            SharedPreferences version_pref = getSharedPreferences(LocalDefines.VERSION_PREF, 0);
            long adId = version_pref.getLong(LocalDefines.AD_ID, 0);
            int appVer = getPackageManager().getPackageInfo(getPackageName(), 16384).versionCode;
            String app_name = getResources().getString(C0470R.string.app_name);
            int[] screenSize = getScreenSize(this);
            String strScreenSize = screenSize[1] + "-" + screenSize[0];
            float rate = (float) ((((double) screenSize[1]) * 1.0d) / ((double) screenSize[0]));
            int type = Math.abs(((double) rate) - 1.7777777777777777d) - Math.abs(((double) rate) - 1.3333333333333333d) < 0.0d ? 1 : 2;
            long ms_id = version_pref.getLong(LocalDefines.AD_MS_ID, 0);
            String language = "cn";
            language = LocalDefines.isZh(this) ? "cn" : "en";
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("app_id", 1001);
            jsonObject.put("app_ver", appVer);
            jsonObject.put("ad_id", adId);
            jsonObject.put("app_name", app_name);
            jsonObject.put("ms_id", ms_id);
            jsonObject.put("type", type);
            jsonObject.put("size", strScreenSize);
            jsonObject.put("language", language);
            String str = new String(Base64.encodeBase64(jsonObject.toString().getBytes()));
            String requestResult = null;
            if ((System.currentTimeMillis() / 1000) - (version_pref.getLong(LocalDefines.AD_GET_TIME, 0) / 1000) >= 86400) {
                requestResult = Functions.GetJsonStringFromServerByHTTP(this.mAdIpAddr, this.mAdPort, this.mAdParams + str);
            }
            if (requestResult != null && requestResult.length() > 0) {
                JSONObject jSONObject = new JSONObject(requestResult);
                int result = jSONObject.getInt("result");
                int returnType = jSONObject.getInt("type");
                String data = jSONObject.getString("data");
                if (result == 0) {
                    Editor editor = version_pref.edit();
                    if (returnType == 1) {
                        jSONObject = new JSONObject(data);
                        String adUrl = jSONObject.getString("image");
                        int duration = jSONObject.getInt("duration");
                        int frequency = jSONObject.getInt("frequency");
                        long ad_id_new = jSONObject.getLong("ad_id");
                        Glide.get(this).clearDiskCache();
                        if (copyFile(((File) Glide.with((Context) this).load(adUrl).downloadOnly(Integer.MIN_VALUE, Integer.MIN_VALUE).get()).getPath(), mAdFilePath)) {
                            editor.putLong(LocalDefines.AD_GET_TIME, System.currentTimeMillis());
                            editor.putLong(LocalDefines.AD_ID, ad_id_new);
                            editor.putInt(LocalDefines.AD_SHOW_DURATION, duration);
                            editor.putInt(LocalDefines.AD_SHOW_FREQUENCY, frequency);
                            if (ad_id_new != adId) {
                                editor.putInt(LocalDefines.AD_SHOW_ALREADY, 0);
                            }
                            editor.apply();
                        }
                    } else if (returnType == 2) {
                        jSONObject = new JSONObject(data);
                        long msIdNew = jSONObject.getLong("ms_id");
                        String msTitle = jSONObject.getString(MessageKey.MSG_TITLE);
                        String message = jSONObject.getString("message");
                        long priority = jSONObject.getLong(LogFactory.PRIORITY_KEY);
                        if (ms_id != msIdNew) {
                            editor.putLong(LocalDefines.AD_MS_ID, msIdNew);
                            LocalDefines.HAS_NEW_MSG = true;
                            LocalDefines.MSG = message;
                            LocalDefines.MSG_TITLE = msTitle;
                        }
                        editor.apply();
                    }
                } else if (result != -1001 && result != -1002 && result != -1003 && result != -1004) {
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean copyFile(String oldPath, String newPath) {
        Exception e;
        Throwable th;
        InputStream inStream = null;
        FileOutputStream fs = null;
        boolean result = false;
        int bytesum = 0;
        try {
            File oldfile = new File(oldPath);
            File newFile = new File(newPath);
            if (newFile.exists()) {
                newFile.delete();
            }
            if (oldfile.exists()) {
                InputStream inStream2 = new FileInputStream(oldPath);
                try {
                    FileOutputStream fs2 = new FileOutputStream(newPath);
                    try {
                        byte[] buffer = new byte[1024];
                        while (true) {
                            int byteread = inStream2.read(buffer);
                            if (byteread == -1) {
                                break;
                            }
                            bytesum += byteread;
                            fs2.write(buffer, 0, byteread);
                        }
                        result = true;
                        fs = fs2;
                        inStream = inStream2;
                    } catch (Exception e2) {
                        e = e2;
                        fs = fs2;
                        inStream = inStream2;
                    } catch (Throwable th2) {
                        th = th2;
                        fs = fs2;
                        inStream = inStream2;
                    }
                } catch (Exception e3) {
                    e = e3;
                    inStream = inStream2;
                    try {
                        e.printStackTrace();
                        if (inStream != null) {
                            try {
                                inStream.close();
                            } catch (IOException e4) {
                                e4.printStackTrace();
                            }
                        }
                        if (fs != null) {
                            try {
                                fs.close();
                            } catch (IOException e42) {
                                e42.printStackTrace();
                            }
                        }
                        return result;
                    } catch (Throwable th3) {
                        th = th3;
                        if (inStream != null) {
                            try {
                                inStream.close();
                            } catch (IOException e422) {
                                e422.printStackTrace();
                            }
                        }
                        if (fs != null) {
                            try {
                                fs.close();
                            } catch (IOException e4222) {
                                e4222.printStackTrace();
                            }
                        }
                        throw th;
                    }
                } catch (Throwable th4) {
                    th = th4;
                    inStream = inStream2;
                    if (inStream != null) {
                        inStream.close();
                    }
                    if (fs != null) {
                        fs.close();
                    }
                    throw th;
                }
            }
            if (inStream != null) {
                try {
                    inStream.close();
                } catch (IOException e42222) {
                    e42222.printStackTrace();
                }
            }
            if (fs != null) {
                try {
                    fs.close();
                } catch (IOException e422222) {
                    e422222.printStackTrace();
                }
            }
        } catch (Exception e5) {
            e = e5;
            e.printStackTrace();
            if (inStream != null) {
                inStream.close();
            }
            if (fs != null) {
                fs.close();
            }
            return result;
        }
        return result;
    }

    private int[] getScreenSize(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService("window");
        wm.getDefaultDisplay().getMetrics(new DisplayMetrics());
        return new int[]{outMetrics.widthPixels, outMetrics.heightPixels};
    }
}
