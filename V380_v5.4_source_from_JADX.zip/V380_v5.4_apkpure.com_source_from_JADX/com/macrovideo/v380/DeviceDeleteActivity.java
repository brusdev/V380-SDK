package com.macrovideo.v380;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.xingepush.RegistClientWithDeviceArrayToServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DeviceDeleteActivity extends Activity implements OnClickListener, OnItemClickListener {
    private boolean bSelectAllCheck = false;
    private Button btnDeviceDelete;
    private ImageView ivDeviceDeleteBack;
    private ImageView ivDeviceDeleteCheckOrAll;
    private ListView lvDeviceDeleteListView;

    private class DeviceDeleteListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private List<Map<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageView ivDeviceDelete;
            TextView tvDeviceDelete;

            private ItemViewHolder() {
            }
        }

        class ListViewButtonListener implements OnClickListener {
            private ImageView imageView;
            private int position;

            ListViewButtonListener(int pos, ImageView v) {
                this.position = pos;
                this.imageView = v;
            }

            public void onClick(View v) {
                if (v.getId() == DeviceDeleteListViewAdapter.this.holder.ivDeviceDelete.getId() && this.position >= 0 && this.position < LocalDefines._severInfoListData.size()) {
                    DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(this.position);
                    if (info != null) {
                        if (info.isCheck()) {
                            info.setCheck(false);
                            this.imageView.setImageResource(C0470R.drawable.delete_choose_not_button);
                        } else {
                            info.setCheck(true);
                            this.imageView.setImageResource(C0470R.drawable.delete_choose_save_button);
                        }
                    }
                    DeviceDeleteActivity.this.checkForSelect();
                }
            }
        }

        public DeviceDeleteListViewAdapter(Context c, List<Map<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.device_add_delete_item, null);
                this.holder = new ItemViewHolder();
                this.holder.tvDeviceDelete = (TextView) convertView.findViewById(this.valueViewID[0]);
                this.holder.ivDeviceDelete = (ImageView) convertView.findViewById(this.valueViewID[1]);
                convertView.setTag(this.holder);
            }
            if (((Map) this.mAppList.get(position)) != null) {
                if (position >= 0 && position < LocalDefines._severInfoListData.size()) {
                    DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(position);
                    if (info != null) {
                        if (info.isCheck()) {
                            this.holder.ivDeviceDelete.setImageResource(C0470R.drawable.delete_choose_save_button);
                        } else {
                            this.holder.ivDeviceDelete.setImageResource(C0470R.drawable.delete_choose_not_button);
                        }
                        this.holder.tvDeviceDelete.setText(info.getnDevID());
                    }
                }
                this.holder.ivDeviceDelete.setOnClickListener(new ListViewButtonListener(position, this.holder.ivDeviceDelete));
            }
            return convertView;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((NotificationManager) getSystemService("notification")).cancel(257);
        requestWindowFeature(1);
        setContentView(C0470R.layout.popuwindow_delete_device);
        init();
    }

    private void init() {
        this.ivDeviceDeleteBack = (ImageView) findViewById(C0470R.id.ivDeviceDeleteBack);
        this.ivDeviceDeleteBack.setOnClickListener(this);
        this.ivDeviceDeleteCheckOrAll = (ImageView) findViewById(C0470R.id.ivDeviceDeleteCheckOrAll);
        this.ivDeviceDeleteCheckOrAll.setOnClickListener(this);
        this.lvDeviceDeleteListView = (ListView) findViewById(C0470R.id.lvDeviceDeleteListView);
        this.btnDeviceDelete = (Button) findViewById(C0470R.id.btnDeviceDelete);
        this.btnDeviceDelete.setOnClickListener(this);
        updateDeleteList();
    }

    private void checkForSelect() {
        boolean hasSelect = false;
        boolean hasAllSelect = true;
        if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
            hasAllSelect = false;
        } else {
            for (int i = 0; i < LocalDefines._severInfoListData.size(); i++) {
                DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                if (info != null) {
                    if (info.isCheck()) {
                        hasSelect = true;
                    } else {
                        hasAllSelect = false;
                    }
                }
            }
        }
        this.bSelectAllCheck = hasAllSelect;
        if (this.bSelectAllCheck) {
            this.ivDeviceDeleteCheckOrAll.setImageResource(C0470R.drawable.delete_choose_save_button);
        } else {
            this.ivDeviceDeleteCheckOrAll.setImageResource(C0470R.drawable.delete_choose_not_button);
        }
        if (this.btnDeviceDelete != null) {
            this.btnDeviceDelete.setEnabled(hasSelect);
        }
    }

    private void updateDeleteList() {
        if (this.lvDeviceDeleteListView != null) {
            List<Map<String, Object>> listItem = new ArrayList();
            if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
                this.lvDeviceDeleteListView.setAdapter(null);
                return;
            }
            for (int i = 0; i < LocalDefines._severInfoListData.size(); i++) {
                HashMap<String, Object> map = new HashMap();
                map.put("index", Integer.valueOf(i));
                map.put("device_id", Integer.valueOf(((DeviceInfo) LocalDefines._severInfoListData.get(i)).getnDevID()));
                map.put("server", LocalDefines._severInfoListData.get(i));
                listItem.add(map);
            }
            DeviceDeleteListViewAdapter deleteListViewAdapter = new DeviceDeleteListViewAdapter(this, listItem, C0470R.layout.device_add_delete_item, new String[]{"ItemName2", "ItemButton2"}, new int[]{C0470R.id.tvDeviceDelete, C0470R.id.ivDeviceDelete});
            this.lvDeviceDeleteListView.setCacheColorHint(0);
            this.lvDeviceDeleteListView.setAdapter(deleteListViewAdapter);
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
    }

    public void onClick(View arg0) {
        boolean z = false;
        int i;
        DeviceInfo info;
        switch (arg0.getId()) {
            case C0470R.id.ivDeviceDeleteBack:
                this.lvDeviceDeleteListView = null;
                startActivity(new Intent(this, HomePageActivity.class));
                LocalDefines.B_UPDATE_LISTVIEW = true;
                finish();
                return;
            case C0470R.id.ivDeviceDeleteCheckOrAll:
                if (!this.bSelectAllCheck) {
                    z = true;
                }
                this.bSelectAllCheck = z;
                if (this.bSelectAllCheck) {
                    this.ivDeviceDeleteCheckOrAll.setImageResource(C0470R.drawable.delete_choose_save_button);
                } else {
                    this.ivDeviceDeleteCheckOrAll.setImageResource(C0470R.drawable.delete_choose_not_button);
                }
                for (i = 0; i < LocalDefines._severInfoListData.size(); i++) {
                    info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                    if (info != null) {
                        info.setCheck(this.bSelectAllCheck);
                    }
                }
                updateDeleteList();
                checkForSelect();
                return;
            case C0470R.id.btnDeviceDelete:
                if (LocalDefines._severInfoListData != null && LocalDefines._severInfoListData.size() > 0) {
                    for (i = LocalDefines._severInfoListData.size() - 1; i >= 0; i--) {
                        info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                        if (info != null && info.isCheck() && DatabaseManager.DeleteServerInfo(info)) {
                            LocalDefines._severInfoListData.remove(i);
                            LocalDefines._severInfoWithoutImageListData.remove(i);
                        }
                    }
                    LocalDefines.isDeviceListSet = false;
                    LocalDefines.nClientDeviceSettingThreadID++;
                    new RegistClientWithDeviceArrayToServer((Context) this, LocalDefines.nClientDeviceSettingThreadID).start();
                    Toast.makeText(this, getString(C0470R.string.deviceDelete), 0).show();
                }
                updateDeleteList();
                return;
            default:
                return;
        }
    }

    public void onResume() {
        super.onResume();
        if (this.bSelectAllCheck) {
            this.ivDeviceDeleteCheckOrAll.setImageResource(C0470R.drawable.delete_choose_save_button);
        } else {
            this.ivDeviceDeleteCheckOrAll.setImageResource(C0470R.drawable.delete_choose_not_button);
        }
        for (int i = 0; i < LocalDefines._severInfoListData.size(); i++) {
            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
            if (info != null) {
                info.setCheck(this.bSelectAllCheck);
            }
        }
        checkForSelect();
        updateDeleteList();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            startActivity(new Intent(this, HomePageActivity.class));
            LocalDefines.B_UPDATE_LISTVIEW = true;
            finish();
        }
        return false;
    }
}
