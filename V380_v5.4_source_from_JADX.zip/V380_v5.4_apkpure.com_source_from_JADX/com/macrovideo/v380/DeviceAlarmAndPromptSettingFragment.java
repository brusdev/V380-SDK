package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;
import android.widget.Toast;
import com.macrovideo.pull.lib.CheckSwitchButton;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrovideo.sdk.media.LoginHelperEX;
import com.macrovideo.sdk.setting.AlarmAndPromptInfo;
import com.macrovideo.sdk.setting.DeviceAlarmAndPromptSetting;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import java.util.ArrayList;

@SuppressLint({"ValidFragment", "HandlerLeak"})
public class DeviceAlarmAndPromptSettingFragment extends Fragment implements OnClickListener {
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    public static boolean isAllTime = true;
    static boolean isSaveArea = false;
    private ArrayList<Integer> AlarmSwitchItem;
    private CheckBox CBTime1;
    private CheckBox CBTime2;
    private CheckBox CBTime3;
    private int CustomTimeSize = 0;
    private short EndHour = (short) 0;
    private short EndMin = (short) 0;
    private short EndSec = (short) 0;
    private ArrayList<String> EndTimeitems = new ArrayList();
    private int ServerIsCheckTime = 0;
    private int StartHour = 0;
    private int StartMin = 0;
    private int StartSec = 0;
    private ArrayList<String> StartTimeitems = new ArrayList();
    private CustomTimeAdapter adapter;
    private LinearLayout alarmline1;
    private CheckSwitchButton btAlarmAudio;
    private CheckSwitchButton btAlarmMianSwitch;
    private CheckSwitchButton btAudioMianSwitch;
    private CheckSwitchButton btMotionDetect;
    private ImageView btnAlarmAndPromptBack;
    private Button btnAlarmAndPromptSave;
    private Button btnDatetimeSelectCancel = null;
    private Button btnDatetimeSelectOK = null;
    private Button btnDeviceSelectCancel = null;
    private Button btnRelecance;
    private View contentView = null;
    private int endHour1 = 0;
    private int endHour2 = 0;
    private int endHour3 = 0;
    private ArrayList<Integer> endHourItem;
    private int endMin1 = 0;
    private int endMin2 = 0;
    private int endMin3 = 0;
    private ArrayList<Integer> endMinItem;
    private int endSec1 = 0;
    private int endSec2 = 0;
    private int endSec3 = 0;
    private ArrayList<Integer> endSecItem;
    private Dialog endTimeSelectDialog = null;
    private View enddatetimeSelectConctentView = null;
    private Handler handler = new C02831();
    private ImageView imgDeleteTime1;
    private ImageView imgDeleteTime2;
    private ImageView imgDeleteTime3;
    private ImageView imgTimeArrow;
    private IntentFilter intentFilter;
    private boolean isActive = false;
    private ArrayList<Integer> isCheckItem;
    private boolean isGetFinish = false;
    private int ischeckTime1 = 1;
    private int ischeckTime2 = 1;
    private int ischeckTime3 = 1;
    private long lFreshTime = 0;
    private LinearLayout layoutAlarmArea = null;
    private LinearLayout layoutDatePicker = null;
    private LinearLayout layoutTimePicker = null;
    private ListView listCustomTime;
    private LinearLayout llSetAlarmTime;
    private Dialog loadingDialog;
    private View loadingView;
    private LinearLayout loayoutIOModePanel = null;
    private int mAlarmTimeItemHeight;
    boolean mBAlarmVoiceSwitch = false;
    boolean mBMainAlarmSwitch = false;
    boolean mBMotionAlarmSwitch = false;
    boolean mBPIRAlarmSwitch = false;
    boolean mBSmokeAlarmSwitch = false;
    boolean mBVoicePromptsMainSwitch = false;
    boolean mHasAlarmConfig = false;
    boolean mHasExIOConfig = false;
    boolean mHasVoicePromptsConfig = false;
    int mIOMode = 0;
    private boolean mIsNeedFresh = false;
    int mLanguage = 1000;
    private int mLoadType = 1;
    private DatePicker mSelectDatePicker = null;
    private TimePicker mSelectEndTimePicker = null;
    private TimePicker mSelectStartTimePicker = null;
    private DeviceInfo mServerInfo = null;
    int mSetCustomTime = 1;
    private int m_loginID = 0;
    private int m_nPort = 8800;
    private String m_strIP = "127.0.0.1";
    private String m_strName = "IPC";
    private String m_strPassword = Constants.MAIN_VERSION_TAG;
    private String m_strUsername = Constants.MAIN_VERSION_TAG;
    private int nID = -1;
    private RadioButton rBtnAlarmAudioDisable = null;
    private RadioButton rBtnAlarmAudioEnable = null;
    private RadioButton rBtnAlarmMianSwitchDisable = null;
    private RadioButton rBtnAlarmMianSwitchEnable = null;
    private RadioButton rBtnAllTime;
    private RadioButton rBtnAudioMianSwitchDisable = null;
    private RadioButton rBtnAudioMianSwitchEnable = null;
    private RadioButton rBtnIOModeExternal = null;
    private RadioButton rBtnIOModeInternal = null;
    private RadioButton rBtnIOModeManualOff = null;
    private RadioButton rBtnIOModeManualOn = null;
    private RadioButton rBtnLanguageCN = null;
    private RadioButton rBtnLanguageEN = null;
    private RadioButton rBtnSetTime;
    private RadioGroup rIORadioGroup1 = null;
    private RadioGroup rIORadioGroup2 = null;
    private TabBroadcastReceiver receiver;
    private Activity relateAtivity = null;
    private RelativeLayout rlSetTime1;
    private RelativeLayout rlSetTime2;
    private RelativeLayout rlSetTime3;
    private RelativeLayout rl_addTime = null;
    private String sEndHour = "0";
    private String sEndMin = "0";
    private String sEndSec = "0";
    private String sStartHour = "0";
    private String sStartMin = "0";
    private String sStartSec = "0";
    private int startHour1 = 0;
    private int startHour2 = 0;
    private int startHour3 = 0;
    private ArrayList<Integer> startHourItem;
    private int startMin1 = 0;
    private int startMin2 = 0;
    private int startMin3 = 0;
    private ArrayList<Integer> startMinItem;
    private int startSec1 = 0;
    private int startSec2 = 0;
    private int startSec3 = 0;
    private ArrayList<Integer> startSecItem;
    private Dialog startTimeSelectDialog = null;
    private View startdatetimeSelectConctentView = null;
    private String strSavePassword = Constants.MAIN_VERSION_TAG;
    private String strSaveUsername = Constants.MAIN_VERSION_TAG;
    private TextView tvDateTimeCurrent = null;
    private TextView tvDateTimeTitle = null;
    private TextView txt_addTime;

    class C02831 extends Handler {
        C02831() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            if (DeviceAlarmAndPromptSettingFragment.this.isActive) {
                DeviceAlarmAndPromptSettingFragment.this.mIsNeedFresh = false;
                int state;
                if (msg.arg1 == 262) {
                    DeviceAlarmAndPromptSettingFragment.this.loadingDialog.dismiss();
                    DeviceAlarmAndPromptSettingFragment.this.btnAlarmAndPromptSave.setEnabled(true);
                    DeviceAlarmAndPromptSettingFragment.this.contentView.findViewById(C0470R.id.layoutAlarmAndPromptPanel).setEnabled(true);
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_NetError));
                            return;
                        case 256:
                            LocalDefines.shouldUpdateSelectArea = false;
                            LocalDefines.Localmap_Update_area.put(Integer.valueOf(DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getnDevID()), Boolean.valueOf(LocalDefines.shouldUpdateSelectArea));
                            if (msg.getData() != null) {
                                DeviceAlarmAndPromptSettingFragment.this.lFreshTime = System.currentTimeMillis();
                                if (DeviceAlarmAndPromptSettingFragment.this.mServerInfo != null) {
                                    DeviceAlarmAndPromptSettingFragment.this.nID = DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getnID();
                                    DeviceAlarmAndPromptSettingFragment.this.strSaveUsername = DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getStrUsername();
                                    DeviceAlarmAndPromptSettingFragment.this.strSavePassword = DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getStrPassword();
                                } else {
                                    DeviceAlarmAndPromptSettingFragment.this.nID = -1;
                                }
                                LocalDefines._AlarmAndPromptConfig.setHasAlarmConfig(DeviceAlarmAndPromptSettingFragment.this.mHasAlarmConfig);
                                LocalDefines._AlarmAndPromptConfig.setbMainAlarmSwitch(DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch);
                                LocalDefines._AlarmAndPromptConfig.setbMotionAlarmSwitch(DeviceAlarmAndPromptSettingFragment.this.mBMotionAlarmSwitch);
                                LocalDefines._AlarmAndPromptConfig.setbPIRAlarmSwitch(DeviceAlarmAndPromptSettingFragment.this.mBPIRAlarmSwitch);
                                LocalDefines._AlarmAndPromptConfig.setbSmokeAlarmSwitch(DeviceAlarmAndPromptSettingFragment.this.mBSmokeAlarmSwitch);
                                LocalDefines._AlarmAndPromptConfig.setHasVoicePromptsConfig(DeviceAlarmAndPromptSettingFragment.this.mHasVoicePromptsConfig);
                                LocalDefines._AlarmAndPromptConfig.setbVoicePromptsMainSwitch(DeviceAlarmAndPromptSettingFragment.this.mBVoicePromptsMainSwitch);
                                LocalDefines._AlarmAndPromptConfig.setbAlarmVoiceSwitch(DeviceAlarmAndPromptSettingFragment.this.mBAlarmVoiceSwitch);
                                LocalDefines._AlarmAndPromptConfig.setnLanguage(DeviceAlarmAndPromptSettingFragment.this.mLanguage);
                                LocalDefines._AlarmAndPromptConfig.setHasExIOConfig(DeviceAlarmAndPromptSettingFragment.this.mHasExIOConfig);
                                LocalDefines._AlarmAndPromptConfig.setnIOMode(DeviceAlarmAndPromptSettingFragment.this.mIOMode);
                            }
                            DeviceAlarmAndPromptSettingFragment.this.onSaveAndBack(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_ok), Constants.MAIN_VERSION_TAG);
                            state = DatabaseManager.getServerInfoOneKeyAlarmState(DeviceAlarmAndPromptSettingFragment.this.mServerInfo);
                            if (state == 1 || state == 2) {
                                DatabaseManager.updateServerInfoOneKeyAlarmSetting(DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getnDevID(), DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch);
                                return;
                            } else {
                                DatabaseManager.updateServerInfoOneKeyDeviceAlarmAndPromptSetting(DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getnDevID(), DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch);
                                return;
                            }
                        default:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            return;
                    }
                } else if (msg.arg1 == 261) {
                    DeviceAlarmAndPromptSettingFragment.this.loadingDialog.dismiss();
                    DeviceAlarmAndPromptSettingFragment.this.btnAlarmAndPromptSave.setEnabled(false);
                    DeviceAlarmAndPromptSettingFragment.this.contentView.findViewById(C0470R.id.layoutAlarmAndPromptPanel).setEnabled(false);
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            DeviceAlarmAndPromptSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            DeviceAlarmAndPromptSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            DeviceAlarmAndPromptSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            DeviceAlarmAndPromptSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_NetError));
                            DeviceAlarmAndPromptSettingFragment.this.ShowConfigSetting();
                            return;
                        case 256:
                            DeviceAlarmAndPromptSettingFragment.this.isGetFinish = true;
                            DeviceAlarmAndPromptSettingFragment.this.btnAlarmAndPromptSave.setEnabled(true);
                            DeviceAlarmAndPromptSettingFragment.this.contentView.findViewById(C0470R.id.layoutAlarmAndPromptPanel).setEnabled(true);
                            data = msg.getData();
                            if (data == null) {
                                DeviceAlarmAndPromptSettingFragment.this.ShowAlert(Constants.MAIN_VERSION_TAG, DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_BadResult));
                                return;
                            }
                            DeviceAlarmAndPromptSettingFragment.this.lFreshTime = System.currentTimeMillis();
                            AlarmAndPromptInfo alarmAndPromptHandler = (AlarmAndPromptInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                            if (alarmAndPromptHandler != null) {
                                DeviceAlarmAndPromptSettingFragment.this.mHasAlarmConfig = alarmAndPromptHandler.isHasAlarmConfig();
                                DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch = alarmAndPromptHandler.isbMainAlarmSwitch();
                                DeviceAlarmAndPromptSettingFragment.this.mBMotionAlarmSwitch = alarmAndPromptHandler.isbMotionAlarmSwitch();
                                DeviceAlarmAndPromptSettingFragment.this.mBPIRAlarmSwitch = alarmAndPromptHandler.isbPIRAlarmSwitch();
                                DeviceAlarmAndPromptSettingFragment.this.mBSmokeAlarmSwitch = alarmAndPromptHandler.isbSmokeAlarmSwitch();
                                DeviceAlarmAndPromptSettingFragment.this.mHasVoicePromptsConfig = alarmAndPromptHandler.isHasVoicePromptsConfig();
                                DeviceAlarmAndPromptSettingFragment.this.mBVoicePromptsMainSwitch = alarmAndPromptHandler.isbVoicePromptsMainSwitch();
                                DeviceAlarmAndPromptSettingFragment.this.mBAlarmVoiceSwitch = alarmAndPromptHandler.isbAlarmVoiceSwitch();
                                DeviceAlarmAndPromptSettingFragment.this.mLanguage = alarmAndPromptHandler.getnLanguage();
                                DeviceAlarmAndPromptSettingFragment.this.mHasExIOConfig = alarmAndPromptHandler.isHasExIOConfig();
                                DeviceAlarmAndPromptSettingFragment.this.mIOMode = alarmAndPromptHandler.getnIOMode();
                                LocalDefines.CanSetTime = alarmAndPromptHandler.getCanSetTime();
                                if (alarmAndPromptHandler.getAlarmrows() != 0) {
                                    LocalDefines.alarmrows = alarmAndPromptHandler.getAlarmrows();
                                }
                                if (alarmAndPromptHandler.getAlarmcolumns() != 0) {
                                    LocalDefines.alarmcolumns = alarmAndPromptHandler.getAlarmcolumns();
                                }
                                LocalDefines.ServerAlarmSwitch1 = alarmAndPromptHandler.getServerAlarmSwitch1();
                                LocalDefines.ServerAlarmSwitch2 = alarmAndPromptHandler.getServerAlarmSwitch2();
                                LocalDefines.ServerAlarmSwitch3 = alarmAndPromptHandler.getServerAlarmSwitch3();
                                LocalDefines.addAlarmTime(alarmAndPromptHandler.getStarthour1(), alarmAndPromptHandler.getStarthour2(), alarmAndPromptHandler.getStarthour3(), alarmAndPromptHandler.getStartmin1(), alarmAndPromptHandler.getStartmin2(), alarmAndPromptHandler.getStartmin3(), alarmAndPromptHandler.getStartsec1(), alarmAndPromptHandler.getStartsec2(), alarmAndPromptHandler.getStartsec3(), alarmAndPromptHandler.getEndhour1(), alarmAndPromptHandler.getEndhour2(), alarmAndPromptHandler.getEndhour3(), alarmAndPromptHandler.getEndmin1(), alarmAndPromptHandler.getEndmin2(), alarmAndPromptHandler.getEndmin3(), alarmAndPromptHandler.getEndsec1(), alarmAndPromptHandler.getEndsec2(), alarmAndPromptHandler.getEndsec3());
                                LocalDefines.ServerAlarmAreaList = DeviceAlarmAndPromptSetting.ServerAlarmAreaList;
                            }
                            if (DeviceAlarmAndPromptSettingFragment.this.mServerInfo != null) {
                                DeviceAlarmAndPromptSettingFragment.this.nID = DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getnID();
                                DeviceAlarmAndPromptSettingFragment.this.strSaveUsername = DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getStrUsername();
                                DeviceAlarmAndPromptSettingFragment.this.strSavePassword = DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getStrPassword();
                            } else {
                                DeviceAlarmAndPromptSettingFragment.this.nID = -1;
                            }
                            LocalDefines._AlarmAndPromptConfig.setHasAlarmConfig(DeviceAlarmAndPromptSettingFragment.this.mHasAlarmConfig);
                            LocalDefines._AlarmAndPromptConfig.setbMainAlarmSwitch(DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch);
                            LocalDefines._AlarmAndPromptConfig.setbMotionAlarmSwitch(DeviceAlarmAndPromptSettingFragment.this.mBMotionAlarmSwitch);
                            LocalDefines._AlarmAndPromptConfig.setbPIRAlarmSwitch(DeviceAlarmAndPromptSettingFragment.this.mBPIRAlarmSwitch);
                            LocalDefines._AlarmAndPromptConfig.setbSmokeAlarmSwitch(DeviceAlarmAndPromptSettingFragment.this.mBSmokeAlarmSwitch);
                            LocalDefines._AlarmAndPromptConfig.setHasVoicePromptsConfig(DeviceAlarmAndPromptSettingFragment.this.mHasVoicePromptsConfig);
                            LocalDefines._AlarmAndPromptConfig.setbVoicePromptsMainSwitch(DeviceAlarmAndPromptSettingFragment.this.mBVoicePromptsMainSwitch);
                            LocalDefines._AlarmAndPromptConfig.setbAlarmVoiceSwitch(DeviceAlarmAndPromptSettingFragment.this.mBAlarmVoiceSwitch);
                            LocalDefines._AlarmAndPromptConfig.setnLanguage(DeviceAlarmAndPromptSettingFragment.this.mLanguage);
                            LocalDefines._AlarmAndPromptConfig.setHasExIOConfig(DeviceAlarmAndPromptSettingFragment.this.mHasExIOConfig);
                            LocalDefines._AlarmAndPromptConfig.setnIOMode(DeviceAlarmAndPromptSettingFragment.this.mIOMode);
                            DeviceAlarmAndPromptSettingFragment.this.updateUI();
                            state = DatabaseManager.getServerInfoOneKeyAlarmState(DeviceAlarmAndPromptSettingFragment.this.mServerInfo);
                            if (state == 1 || state == 2) {
                                DatabaseManager.updateServerInfoOneKeyAlarmSetting(DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getnDevID(), DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch);
                                return;
                            } else {
                                DatabaseManager.updateServerInfoOneKeyDeviceAlarmAndPromptSetting(DeviceAlarmAndPromptSettingFragment.this.mServerInfo.getnDevID(), DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch);
                                return;
                            }
                        default:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_get_config_fail), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            DeviceAlarmAndPromptSettingFragment.this.ShowConfigSetting();
                            return;
                    }
                } else if (msg.arg1 == 16) {
                    DeviceAlarmAndPromptSettingFragment.this.loadingDialog.dismiss();
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            return;
                        case 256:
                            data = msg.getData();
                            if (data == null) {
                                DeviceAlarmAndPromptSettingFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed))).append("(").append(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_BadResult)).append(")").toString(), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_connect_tips));
                                return;
                            }
                            int listMode = data.getInt("list_mode");
                            data.putBoolean("isSelectArea", true);
                            data.putString("name", DeviceAlarmAndPromptSettingFragment.this.m_strName);
                            data.putString("server", DeviceAlarmAndPromptSettingFragment.this.m_strIP);
                            data.putString("username", DeviceAlarmAndPromptSettingFragment.this.m_strUsername);
                            data.putString("password", DeviceAlarmAndPromptSettingFragment.this.m_strPassword);
                            data.putInt("nPort", DeviceAlarmAndPromptSettingFragment.this.m_nPort);
                            int camType = ((LoginHandle) data.getParcelable(Defines.RECORD_FILE_RETURN_MESSAGE)).getCamType();
                            Intent intent;
                            if (camType == 1 || camType == 2) {
                                intent = new Intent(DeviceAlarmAndPromptSettingFragment.this.relateAtivity, NVPlayerPlayFishEyeActivity.class);
                                intent.putExtras(data);
                                DeviceAlarmAndPromptSettingFragment.this.relateAtivity.startActivity(intent);
                                DeviceAlarmAndPromptSettingFragment.this.relateAtivity.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                                return;
                            }
                            intent = new Intent(DeviceAlarmAndPromptSettingFragment.this.relateAtivity, NVPlayerPlayActivity.class);
                            intent.putExtras(data);
                            DeviceAlarmAndPromptSettingFragment.this.relateAtivity.startActivity(intent);
                            DeviceAlarmAndPromptSettingFragment.this.relateAtivity.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                            return;
                        case 4097:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_BadResult)).append(")").toString(), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_connect_tips));
                            return;
                        case 4098:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed)).append(")").toString(), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_connect_tips));
                            return;
                        case 4099:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed)).append(")").toString(), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_connect_tips));
                            return;
                        case LocalDefines.LOGIN_RESULT_CODE_FAIL_VERIFY_FAILED /*4100*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_VerifyFailed));
                            return;
                        case LocalDefines.LOGIN_RESULT_CODE_FAIL_USER_NOEXIST /*4101*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            return;
                        case LocalDefines.LOGIN_RESULT_CODE_FAIL_PWD_ERROR /*4102*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            return;
                        case LocalDefines.LOGIN_RESULT_CODE_FAIL_OLD_VERSON /*4103*/:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            return;
                        default:
                            DeviceAlarmAndPromptSettingFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed)).append(")").toString(), DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.alert_connect_tips));
                            return;
                    }
                }
            }
        }
    }

    class C02842 implements OnCheckedChangeListener {
        C02842() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isChecked) {
            if (isChecked) {
                DeviceAlarmAndPromptSettingFragment.this.llSetAlarmTime.setVisibility(0);
                DeviceAlarmAndPromptSettingFragment.this.alarmline1.setVisibility(0);
                DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch = true;
                DeviceAlarmAndPromptSettingFragment.this.btMotionDetect.setChecked(true);
                if (DeviceAlarmAndPromptSettingFragment.isAllTime) {
                    DeviceAlarmAndPromptSettingFragment.this.rl_addTime.setVisibility(8);
                    DeviceAlarmAndPromptSettingFragment.this.listCustomTime.setVisibility(8);
                } else {
                    DeviceAlarmAndPromptSettingFragment.this.rl_addTime.setVisibility(0);
                    DeviceAlarmAndPromptSettingFragment.this.listCustomTime.setVisibility(0);
                }
            } else {
                DeviceAlarmAndPromptSettingFragment.this.llSetAlarmTime.setVisibility(8);
                DeviceAlarmAndPromptSettingFragment.this.alarmline1.setVisibility(8);
                DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch = false;
            }
            DeviceAlarmAndPromptSettingFragment.this.btMotionDetect.setEnabled(DeviceAlarmAndPromptSettingFragment.this.mBMainAlarmSwitch);
        }
    }

    class C02853 implements OnCheckedChangeListener {
        C02853() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isChecked) {
            if (isChecked) {
                DeviceAlarmAndPromptSettingFragment.this.mBMotionAlarmSwitch = true;
            } else {
                DeviceAlarmAndPromptSettingFragment.this.mBMotionAlarmSwitch = false;
            }
        }
    }

    class C02864 implements OnCheckedChangeListener {
        C02864() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isChecked) {
            if (isChecked) {
                DeviceAlarmAndPromptSettingFragment.this.mBAlarmVoiceSwitch = true;
            } else {
                DeviceAlarmAndPromptSettingFragment.this.mBAlarmVoiceSwitch = false;
            }
        }
    }

    class C02875 implements OnCheckedChangeListener {
        C02875() {
        }

        public void onCheckedChanged(CompoundButton arg0, boolean isCheck) {
            if (isCheck) {
                DeviceAlarmAndPromptSettingFragment.this.mBVoicePromptsMainSwitch = true;
                DeviceAlarmAndPromptSettingFragment.this.btAlarmAudio.setEnabled(true);
                DeviceAlarmAndPromptSettingFragment.this.rBtnLanguageEN.setEnabled(true);
                DeviceAlarmAndPromptSettingFragment.this.rBtnLanguageCN.setEnabled(true);
                return;
            }
            DeviceAlarmAndPromptSettingFragment.this.mBVoicePromptsMainSwitch = false;
            DeviceAlarmAndPromptSettingFragment.this.btAlarmAudio.setEnabled(false);
            DeviceAlarmAndPromptSettingFragment.this.rBtnLanguageEN.setEnabled(false);
            DeviceAlarmAndPromptSettingFragment.this.rBtnLanguageCN.setEnabled(false);
        }
    }

    class C02886 implements OnShowListener {
        C02886() {
        }

        public void onShow(DialogInterface dialog) {
            TextView tv = (TextView) DeviceAlarmAndPromptSettingFragment.this.loadingView.findViewById(C0470R.id.loginText);
            if (DeviceAlarmAndPromptSettingFragment.this.mLoadType == 1) {
                tv.setText(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.loading));
            } else if (DeviceAlarmAndPromptSettingFragment.this.mLoadType == 2) {
                tv.setText(DeviceAlarmAndPromptSettingFragment.this.getString(C0470R.string.str_saving));
            }
        }
    }

    class C02897 implements OnDismissListener {
        C02897() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    class C02918 implements OnShowListener {

        class C02901 implements OnTimeChangedListener {
            C02901() {
            }

            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                if (hourOfDay < 10 && minute < 10) {
                    DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 && minute < 10) {
                    DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":0" + minute);
                } else if (hourOfDay >= 10 || minute < 10) {
                    DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":" + minute);
                } else {
                    DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":" + minute);
                }
            }
        }

        C02918() {
        }

        public void onShow(DialogInterface dialog) {
            DeviceAlarmAndPromptSettingFragment.this.tvDateTimeTitle = (TextView) DeviceAlarmAndPromptSettingFragment.this.startdatetimeSelectConctentView.findViewById(C0470R.id.tvDateTimeTitle);
            DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent = (TextView) DeviceAlarmAndPromptSettingFragment.this.startdatetimeSelectConctentView.findViewById(C0470R.id.tvDateTimeCurrent);
            DeviceAlarmAndPromptSettingFragment.this.mSelectDatePicker = (DatePicker) DeviceAlarmAndPromptSettingFragment.this.startdatetimeSelectConctentView.findViewById(C0470R.id.mSelectDatePicker);
            DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker = (TimePicker) DeviceAlarmAndPromptSettingFragment.this.startdatetimeSelectConctentView.findViewById(C0470R.id.mSelectTimePicker);
            DeviceAlarmAndPromptSettingFragment.this.layoutDatePicker = (LinearLayout) DeviceAlarmAndPromptSettingFragment.this.startdatetimeSelectConctentView.findViewById(C0470R.id.layoutDatePicker);
            DeviceAlarmAndPromptSettingFragment.this.layoutTimePicker = (LinearLayout) DeviceAlarmAndPromptSettingFragment.this.startdatetimeSelectConctentView.findViewById(C0470R.id.layoutTimePicker);
            DeviceAlarmAndPromptSettingFragment.this.btnDatetimeSelectCancel = (Button) DeviceAlarmAndPromptSettingFragment.this.startdatetimeSelectConctentView.findViewById(C0470R.id.btnDatetimeSelectCancel);
            DeviceAlarmAndPromptSettingFragment.this.btnDatetimeSelectOK = (Button) DeviceAlarmAndPromptSettingFragment.this.startdatetimeSelectConctentView.findViewById(C0470R.id.btnDatetimeSelectOK);
            DeviceAlarmAndPromptSettingFragment.this.btnDatetimeSelectOK.setOnClickListener(DeviceAlarmAndPromptSettingFragment.this);
            DeviceAlarmAndPromptSettingFragment.this.btnDatetimeSelectCancel.setOnClickListener(DeviceAlarmAndPromptSettingFragment.this);
            DeviceAlarmAndPromptSettingFragment.this.layoutDatePicker.setVisibility(8);
            DeviceAlarmAndPromptSettingFragment.this.layoutTimePicker.setVisibility(0);
            DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.setIs24HourView(Boolean.valueOf(true));
            DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.setCurrentHour(Integer.valueOf(DeviceAlarmAndPromptSettingFragment.this.StartHour));
            DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.setCurrentMinute(Integer.valueOf(DeviceAlarmAndPromptSettingFragment.this.StartMin));
            DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.setOnTimeChangedListener(new C02901());
            if (DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentHour().intValue() < 10 && DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentMinute().intValue() < 10) {
                DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText("0" + DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentHour() + ":0" + DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentMinute());
            } else if (DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentHour().intValue() >= 10 && DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentMinute().intValue() < 10) {
                DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText(DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentHour() + ":0" + DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentMinute());
            } else if (DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentHour().intValue() >= 10 || DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentMinute().intValue() < 10) {
                DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText(DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentHour() + ":" + DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentMinute());
            } else {
                DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText("0" + DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentHour() + ":" + DeviceAlarmAndPromptSettingFragment.this.mSelectStartTimePicker.getCurrentMinute());
            }
        }
    }

    class C02929 implements OnDismissListener {
        C02929() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    private class AlarmAndPromptConfigThread extends Thread {
        static final int OP_TYPE_GET = 10;
        static final int OP_TYPE_SET = 11;
        private ArrayList<Integer> alarmArea;
        private int alarmSwitch1;
        private int alarmSwitch2;
        private int alarmSwitch3;
        private boolean bAlarmVoiceSwitch;
        private boolean bMainAlarmSwitch;
        private boolean bVoicePromptsMainSwitch;
        private boolean hasAlarmConfig;
        private boolean hasExIOConfig;
        private boolean hasVoicePromptsConfig;
        private DeviceInfo info;
        private int nIOMode;
        private int nLanguage;
        private int nOPType;
        private int ntimequantum;

        public AlarmAndPromptConfigThread(DeviceInfo info) {
            this.hasAlarmConfig = false;
            this.bMainAlarmSwitch = false;
            this.hasVoicePromptsConfig = false;
            this.bVoicePromptsMainSwitch = false;
            this.bAlarmVoiceSwitch = false;
            this.nLanguage = 1000;
            this.hasExIOConfig = false;
            this.nIOMode = 0;
            this.info = null;
            this.nOPType = 10;
            this.nOPType = 10;
            this.info = info;
        }

        public AlarmAndPromptConfigThread(boolean hasAlarmConfig, boolean bMainAlarmSwitch, boolean hasVoicePromptsConfig, boolean bAlarmVoiceSwitch, boolean bVoicePromptsMainSwitch, int nLanguage, boolean hasExIOConfig, int nIOMode, int timeArea, int ntimequantum, int alarmswitch1, int starthour1, int startmin1, int startsec1, int alarmswitch2, int starthour2, int startmin2, int startsec2, int alarmswitch3, int starthour3, int startmin3, int startsec3, ArrayList<Integer> alarmArea, DeviceInfo info) {
            this.hasAlarmConfig = false;
            this.bMainAlarmSwitch = false;
            this.hasVoicePromptsConfig = false;
            this.bVoicePromptsMainSwitch = false;
            this.bAlarmVoiceSwitch = false;
            this.nLanguage = 1000;
            this.hasExIOConfig = false;
            this.nIOMode = 0;
            this.info = null;
            this.nOPType = 10;
            this.nOPType = 11;
            this.hasAlarmConfig = hasAlarmConfig;
            this.bMainAlarmSwitch = bMainAlarmSwitch;
            this.hasVoicePromptsConfig = hasVoicePromptsConfig;
            this.bAlarmVoiceSwitch = bAlarmVoiceSwitch;
            this.bVoicePromptsMainSwitch = bVoicePromptsMainSwitch;
            this.nLanguage = nLanguage;
            this.hasExIOConfig = hasExIOConfig;
            this.nIOMode = nIOMode;
            this.alarmSwitch1 = alarmswitch1;
            this.alarmSwitch2 = alarmswitch2;
            this.alarmSwitch3 = alarmswitch3;
            this.info = info;
            this.alarmArea = alarmArea;
            this.ntimequantum = ntimequantum;
        }

        public void run() {
            AlarmAndPromptInfo deviceParam;
            Message msg;
            Bundle data;
            if (this.nOPType == 10) {
                deviceParam = DeviceAlarmAndPromptSetting.getAlarmAndPropmt(this.info);
                if (deviceParam != null) {
                    msg = DeviceAlarmAndPromptSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 261;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceAlarmAndPromptSettingFragment.this.handler.sendMessage(msg);
                }
            } else if (this.nOPType == 11) {
                if (this.alarmArea != null) {
                    deviceParam = DeviceAlarmAndPromptSetting.setAlarmAndPropmt(this.info, this.hasAlarmConfig, this.bMainAlarmSwitch, this.hasVoicePromptsConfig, this.bAlarmVoiceSwitch, this.bVoicePromptsMainSwitch, this.nLanguage, this.hasExIOConfig, this.nIOMode, DeviceAlarmAndPromptSettingFragment.this.mBMotionAlarmSwitch, 1, this.ntimequantum, this.alarmSwitch1, DeviceAlarmAndPromptSettingFragment.this.startHour1, DeviceAlarmAndPromptSettingFragment.this.startMin1, DeviceAlarmAndPromptSettingFragment.this.startSec1, DeviceAlarmAndPromptSettingFragment.this.endHour1, DeviceAlarmAndPromptSettingFragment.this.endMin1, DeviceAlarmAndPromptSettingFragment.this.endSec1, this.alarmSwitch2, DeviceAlarmAndPromptSettingFragment.this.startHour2, DeviceAlarmAndPromptSettingFragment.this.startMin2, DeviceAlarmAndPromptSettingFragment.this.startSec2, DeviceAlarmAndPromptSettingFragment.this.endHour2, DeviceAlarmAndPromptSettingFragment.this.endMin2, DeviceAlarmAndPromptSettingFragment.this.endSec2, this.alarmSwitch3, DeviceAlarmAndPromptSettingFragment.this.startHour3, DeviceAlarmAndPromptSettingFragment.this.startMin3, DeviceAlarmAndPromptSettingFragment.this.startSec3, DeviceAlarmAndPromptSettingFragment.this.endHour3, DeviceAlarmAndPromptSettingFragment.this.endMin3, DeviceAlarmAndPromptSettingFragment.this.endSec3, this.alarmArea);
                } else {
                    deviceParam = DeviceAlarmAndPromptSetting.setAlarmAndPropmt(this.info, this.hasAlarmConfig, this.bMainAlarmSwitch, this.hasVoicePromptsConfig, this.bAlarmVoiceSwitch, this.bVoicePromptsMainSwitch, this.nLanguage, this.hasExIOConfig, this.nIOMode, DeviceAlarmAndPromptSettingFragment.this.mBMotionAlarmSwitch, 1, this.ntimequantum, this.alarmSwitch1, DeviceAlarmAndPromptSettingFragment.this.startHour1, DeviceAlarmAndPromptSettingFragment.this.startMin1, DeviceAlarmAndPromptSettingFragment.this.startSec1, DeviceAlarmAndPromptSettingFragment.this.endHour1, DeviceAlarmAndPromptSettingFragment.this.endMin1, DeviceAlarmAndPromptSettingFragment.this.endSec1, this.alarmSwitch2, DeviceAlarmAndPromptSettingFragment.this.startHour2, DeviceAlarmAndPromptSettingFragment.this.startMin2, DeviceAlarmAndPromptSettingFragment.this.startSec2, DeviceAlarmAndPromptSettingFragment.this.endHour2, DeviceAlarmAndPromptSettingFragment.this.endMin2, DeviceAlarmAndPromptSettingFragment.this.endSec2, this.alarmSwitch3, DeviceAlarmAndPromptSettingFragment.this.startHour3, DeviceAlarmAndPromptSettingFragment.this.startMin3, DeviceAlarmAndPromptSettingFragment.this.startSec3, DeviceAlarmAndPromptSettingFragment.this.endHour3, DeviceAlarmAndPromptSettingFragment.this.endMin3, DeviceAlarmAndPromptSettingFragment.this.endSec3, LocalDefines.ServerAlarmAreaList);
                }
                if (deviceParam != null) {
                    msg = DeviceAlarmAndPromptSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 262;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceAlarmAndPromptSettingFragment.this.handler.sendMessage(msg);
                }
            }
        }
    }

    class CustomTimeAdapter extends BaseAdapter {
        private ArrayList<String> EndTimeList;
        private ArrayList<String> StartTimeList;

        public CustomTimeAdapter(ArrayList<String> startTimeList, ArrayList<String> endTimeList) {
            this.StartTimeList = startTimeList;
            this.EndTimeList = endTimeList;
        }

        public int getCount() {
            return this.StartTimeList.size();
        }

        public Object getItem(int position) {
            return this.StartTimeList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            final ViewHolder viewHolder;
            if (convertView == null) {
                convertView = LayoutInflater.from(DeviceAlarmAndPromptSettingFragment.this.relateAtivity).inflate(C0470R.layout.list_custom_time_item, parent, false);
                viewHolder = new ViewHolder();
                viewHolder.cb_view = (CheckBox) convertView.findViewById(C0470R.id.CBTime);
                if (((Integer) DeviceAlarmAndPromptSettingFragment.this.isCheckItem.get(position)).intValue() == 1) {
                    viewHolder.cb_view.setChecked(true);
                } else {
                    viewHolder.cb_view.setChecked(false);
                }
                viewHolder.cb_view.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked) {
                            if (position == 0) {
                                LocalDefines.ServerAlarmSwitch1 = 1;
                                DeviceAlarmAndPromptSettingFragment.this.ischeckTime1 = 1;
                                DeviceAlarmAndPromptSettingFragment.this.isCheckItem.remove(position);
                                DeviceAlarmAndPromptSettingFragment.this.isCheckItem.add(position, Integer.valueOf(1));
                            } else if (position == 1) {
                                LocalDefines.ServerAlarmSwitch2 = 1;
                                DeviceAlarmAndPromptSettingFragment.this.ischeckTime2 = 1;
                                DeviceAlarmAndPromptSettingFragment.this.isCheckItem.remove(position);
                                DeviceAlarmAndPromptSettingFragment.this.isCheckItem.add(position, Integer.valueOf(1));
                            } else if (position == 2) {
                                LocalDefines.ServerAlarmSwitch3 = 1;
                                DeviceAlarmAndPromptSettingFragment.this.ischeckTime3 = 1;
                                DeviceAlarmAndPromptSettingFragment.this.isCheckItem.remove(position);
                                DeviceAlarmAndPromptSettingFragment.this.isCheckItem.add(position, Integer.valueOf(1));
                            }
                        } else if (position == 0) {
                            LocalDefines.ServerAlarmSwitch1 = 0;
                            DeviceAlarmAndPromptSettingFragment.this.isCheckItem.remove(position);
                            DeviceAlarmAndPromptSettingFragment.this.isCheckItem.add(position, Integer.valueOf(0));
                            DeviceAlarmAndPromptSettingFragment.this.ischeckTime1 = 0;
                        } else if (position == 1) {
                            LocalDefines.ServerAlarmSwitch2 = 0;
                            DeviceAlarmAndPromptSettingFragment.this.isCheckItem.remove(position);
                            DeviceAlarmAndPromptSettingFragment.this.isCheckItem.add(position, Integer.valueOf(0));
                            DeviceAlarmAndPromptSettingFragment.this.ischeckTime2 = 0;
                        } else if (position == 2) {
                            LocalDefines.ServerAlarmSwitch3 = 0;
                            DeviceAlarmAndPromptSettingFragment.this.isCheckItem.remove(position);
                            DeviceAlarmAndPromptSettingFragment.this.isCheckItem.add(position, Integer.valueOf(0));
                            DeviceAlarmAndPromptSettingFragment.this.ischeckTime3 = 0;
                        }
                    }
                });
                viewHolder.image_view = (Button) convertView.findViewById(C0470R.id.imgDeleteTime);
                viewHolder.image_view.setOnClickListener(new OnClickListener() {
                    public void onClick(View v) {
                        DeviceAlarmAndPromptSettingFragment.this.startHourItem.remove(position);
                        DeviceAlarmAndPromptSettingFragment.this.startMinItem.remove(position);
                        DeviceAlarmAndPromptSettingFragment.this.endHourItem.remove(position);
                        DeviceAlarmAndPromptSettingFragment.this.endMinItem.remove(position);
                        if (((Integer) DeviceAlarmAndPromptSettingFragment.this.isCheckItem.get(position)).intValue() == 1) {
                            viewHolder.cb_view.setChecked(true);
                        } else {
                            viewHolder.cb_view.setChecked(false);
                        }
                        DeviceAlarmAndPromptSettingFragment.this.isCheckItem.size();
                        DeviceAlarmAndPromptSettingFragment.this.isCheckItem.remove(position);
                        if (DeviceAlarmAndPromptSettingFragment.this.CustomTimeSize == 1 && position == 0) {
                            LocalDefines.ServerAlarmSwitch1 = 0;
                        }
                        if (DeviceAlarmAndPromptSettingFragment.this.CustomTimeSize == 2) {
                            if (position == 0) {
                                DeviceAlarmAndPromptSettingFragment.this.ischeckTime2 = LocalDefines.ServerAlarmSwitch1;
                                LocalDefines.ServerAlarmSwitch1 = LocalDefines.ServerAlarmSwitch2;
                            } else {
                                LocalDefines.ServerAlarmSwitch2 = 0;
                            }
                        }
                        if (DeviceAlarmAndPromptSettingFragment.this.CustomTimeSize == 3) {
                            if (position == 0) {
                                DeviceAlarmAndPromptSettingFragment.this.ischeckTime1 = LocalDefines.ServerAlarmSwitch2;
                                DeviceAlarmAndPromptSettingFragment.this.ischeckTime2 = LocalDefines.ServerAlarmSwitch3;
                                LocalDefines.ServerAlarmSwitch1 = LocalDefines.ServerAlarmSwitch2;
                                LocalDefines.ServerAlarmSwitch2 = LocalDefines.ServerAlarmSwitch3;
                            } else if (position == 1) {
                                DeviceAlarmAndPromptSettingFragment.this.ischeckTime2 = LocalDefines.ServerAlarmSwitch3;
                                LocalDefines.ServerAlarmSwitch3 = LocalDefines.ServerAlarmSwitch2;
                            } else {
                                LocalDefines.ServerAlarmSwitch3 = 0;
                            }
                        }
                        DeviceAlarmAndPromptSettingFragment.this.StartTimeitems.remove(position);
                        DeviceAlarmAndPromptSettingFragment.this.EndTimeitems.remove(position);
                        DeviceAlarmAndPromptSettingFragment.this.adapter = new CustomTimeAdapter(DeviceAlarmAndPromptSettingFragment.this.StartTimeitems, DeviceAlarmAndPromptSettingFragment.this.EndTimeitems);
                        DeviceAlarmAndPromptSettingFragment.this.listCustomTime.setAdapter(DeviceAlarmAndPromptSettingFragment.this.adapter);
                        LayoutParams linearParams2 = (LayoutParams) DeviceAlarmAndPromptSettingFragment.this.listCustomTime.getLayoutParams();
                        linearParams2.height = DeviceAlarmAndPromptSettingFragment.this.StartTimeitems.size() * DeviceAlarmAndPromptSettingFragment.this.mAlarmTimeItemHeight;
                        DeviceAlarmAndPromptSettingFragment.this.listCustomTime.setLayoutParams(linearParams2);
                        DeviceAlarmAndPromptSettingFragment access$0 = DeviceAlarmAndPromptSettingFragment.this;
                        access$0.CustomTimeSize = access$0.CustomTimeSize - 1;
                        DeviceAlarmAndPromptSettingFragment.this.rl_addTime.setVisibility(0);
                    }
                });
                viewHolder.text_startTime = (TextView) convertView.findViewById(C0470R.id.txt_startAlarmTime);
                viewHolder.text_startTime.setText((CharSequence) this.StartTimeList.get(position));
                viewHolder.text_endTime = (TextView) convertView.findViewById(C0470R.id.txt_endAlarmTime);
                viewHolder.text_endTime.setText((CharSequence) this.EndTimeList.get(position));
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            return convertView;
        }
    }

    class LoginThread extends Thread {
        private Handler handler;
        private DeviceInfo info = null;
        private int m_ThreadLoginID = 0;
        private int m_nListMode;

        public LoginThread(Handler handler, DeviceInfo info, int nLoginID, int nListMode) {
            this.handler = handler;
            this.info = info;
            this.m_ThreadLoginID = nLoginID;
            this.m_nListMode = nListMode;
        }

        public void run() {
            if (this.m_ThreadLoginID == DeviceAlarmAndPromptSettingFragment.this.m_loginID) {
                LoginHandle deviceParam;
                if (this.info.getnSaveType() == Defines.SERVER_SAVE_TYPE_DEMO) {
                    deviceParam = LoginHelperEX.getDeviceParamEX(this.info, this.info.getStrMRServer(), this.info.getnMRPort());
                    deviceParam.setSetMRServer(true);
                } else {
                    deviceParam = LoginHelperEX.getDeviceParamEX(this.info);
                }
                if (this.m_ThreadLoginID != DeviceAlarmAndPromptSettingFragment.this.m_loginID) {
                    return;
                }
                Message msg;
                if (deviceParam != null && deviceParam.getnResult() == 256) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 16;
                    msg.arg2 = 256;
                    Bundle data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    data.putInt("list_mode", this.m_nListMode);
                    DeviceAlarmAndPromptSettingFragment.this.m_strName = this.info.getStrName();
                    msg.setData(data);
                    this.handler.sendMessage(msg);
                } else if (deviceParam != null) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 16;
                    msg.arg2 = deviceParam.getnResult();
                    this.handler.sendMessage(msg);
                } else {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 16;
                    msg.arg2 = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    this.handler.sendMessage(msg);
                }
            }
        }
    }

    class TabBroadcastReceiver extends BroadcastReceiver {
        TabBroadcastReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            intent.getAction().equals("TAB1_ACTION");
        }
    }

    public class ViewHolder {
        CheckBox cb_view;
        Button image_view;
        TextView text_endTime;
        TextView text_startTime;
    }

    public DeviceAlarmAndPromptSettingFragment(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public boolean isGetFinish() {
        return this.isGetFinish;
    }

    public void setServerInfo(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public void setNeedFreshInterface(boolean bNeedFresh) {
        this.mIsNeedFresh = bNeedFresh;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_alarmandprompt_config, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        DisplayMetrics outMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(outMetrics);
        this.mAlarmTimeItemHeight = (int) ((outMetrics.density * 40.0f) + 0.5f);
        createDialogs();
        InitSubView();
        return v;
    }

    public void onStop() {
        super.onStop();
        this.relateAtivity = null;
        this.isActive = false;
    }

    public void onPause() {
        super.onPause();
    }

    public void onDestroy() {
        super.onDestroy();
        isSaveArea = false;
        getActivity().unregisterReceiver(this.receiver);
    }

    public void onResume() {
        super.onResume();
        this.receiver = new TabBroadcastReceiver();
        getActivity().registerReceiver(this.receiver, getIntentFilter());
        this.relateAtivity = getActivity();
        this.isActive = true;
    }

    private IntentFilter getIntentFilter() {
        if (this.intentFilter == null) {
            this.intentFilter = new IntentFilter();
            this.intentFilter.addAction("TAB1_ACTION");
        }
        return this.intentFilter;
    }

    private void InitSubView() {
        createLoadingDialog();
        this.startHourItem = new ArrayList();
        this.startMinItem = new ArrayList();
        this.startSecItem = new ArrayList();
        this.endHourItem = new ArrayList();
        this.endMinItem = new ArrayList();
        this.endSecItem = new ArrayList();
        this.AlarmSwitchItem = new ArrayList();
        this.isCheckItem = new ArrayList();
        this.startHourItem.clear();
        this.startMinItem.clear();
        this.startSecItem.clear();
        this.endHourItem.clear();
        this.endMinItem.clear();
        this.endSecItem.clear();
        this.AlarmSwitchItem.clear();
        this.StartTimeitems.clear();
        this.EndTimeitems.clear();
        this.CustomTimeSize = 0;
        this.llSetAlarmTime = (LinearLayout) this.contentView.findViewById(C0470R.id.llSetAlarmTime);
        this.rBtnAllTime = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnAllTime);
        this.rBtnAllTime.setOnClickListener(this);
        this.rBtnSetTime = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnSetTime);
        this.rBtnSetTime.setOnClickListener(this);
        this.imgTimeArrow = (ImageView) this.contentView.findViewById(C0470R.id.imgTimeArrow);
        this.rlSetTime1 = (RelativeLayout) this.contentView.findViewById(C0470R.id.rlSetTime1);
        this.rlSetTime2 = (RelativeLayout) this.contentView.findViewById(C0470R.id.rlSetTime2);
        this.rlSetTime3 = (RelativeLayout) this.contentView.findViewById(C0470R.id.rlSetTime3);
        this.imgDeleteTime1 = (ImageView) this.contentView.findViewById(C0470R.id.imgDeleteTime1);
        this.imgDeleteTime1.setOnClickListener(this);
        this.imgDeleteTime2 = (ImageView) this.contentView.findViewById(C0470R.id.imgDeleteTime2);
        this.imgDeleteTime2.setOnClickListener(this);
        this.imgDeleteTime3 = (ImageView) this.contentView.findViewById(C0470R.id.imgDeleteTime3);
        this.imgDeleteTime3.setOnClickListener(this);
        this.txt_addTime = (TextView) this.contentView.findViewById(C0470R.id.txt_addTime);
        this.rl_addTime = (RelativeLayout) this.contentView.findViewById(C0470R.id.rl_addTime);
        this.rl_addTime.setOnClickListener(this);
        this.alarmline1 = (LinearLayout) this.contentView.findViewById(C0470R.id.alarmline1);
        this.listCustomTime = (ListView) this.contentView.findViewById(C0470R.id.list_customTime);
        this.btnRelecance = (Button) this.contentView.findViewById(C0470R.id.btnRelecance);
        this.btnRelecance.setOnClickListener(this);
        this.btAlarmMianSwitch = (CheckSwitchButton) this.contentView.findViewById(C0470R.id.btAlarmMianSwitch);
        this.btAlarmMianSwitch.setOnCheckedChangeListener(new C02842());
        this.btMotionDetect = (CheckSwitchButton) this.contentView.findViewById(C0470R.id.btMotionDetect);
        this.btMotionDetect.setOnCheckedChangeListener(new C02853());
        this.btAlarmAudio = (CheckSwitchButton) this.contentView.findViewById(C0470R.id.btAlarmAudio);
        this.btAlarmAudio.setOnCheckedChangeListener(new C02864());
        this.btAudioMianSwitch = (CheckSwitchButton) this.contentView.findViewById(C0470R.id.btAudioMianSwitch);
        this.btAudioMianSwitch.setOnCheckedChangeListener(new C02875());
        this.btnAlarmAndPromptBack = (ImageView) this.contentView.findViewById(C0470R.id.btnAlarmAndPromptBack);
        this.btnAlarmAndPromptBack.setOnClickListener(this);
        this.btnAlarmAndPromptSave = (Button) this.contentView.findViewById(C0470R.id.btnAlarmAndPromptSave);
        this.btnAlarmAndPromptSave.setOnClickListener(this);
        this.btnAlarmAndPromptSave.setEnabled(false);
        this.loayoutIOModePanel = (LinearLayout) this.contentView.findViewById(C0470R.id.loayoutIOModePanel);
        this.rBtnAlarmMianSwitchEnable = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnAlarmMianSwitchEnable);
        this.rBtnAlarmMianSwitchDisable = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnAlarmMianSwitchDisable);
        this.rBtnAlarmMianSwitchEnable.setOnClickListener(this);
        this.rBtnAlarmMianSwitchDisable.setOnClickListener(this);
        this.rBtnAudioMianSwitchEnable = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnAudioMianSwitchEnable);
        this.rBtnAudioMianSwitchDisable = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnAudioMianSwitchDisable);
        this.rBtnAudioMianSwitchEnable.setOnClickListener(this);
        this.rBtnAudioMianSwitchDisable.setOnClickListener(this);
        this.rBtnAlarmAudioEnable = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnAlarmAudioEnable);
        this.rBtnAlarmAudioDisable = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnAlarmAudioDisable);
        this.rBtnAlarmAudioEnable.setOnClickListener(this);
        this.rBtnAlarmAudioDisable.setOnClickListener(this);
        this.rBtnLanguageCN = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnLanguageCN);
        this.rBtnLanguageEN = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnLanguageEN);
        this.rBtnLanguageCN.setOnClickListener(this);
        this.rBtnLanguageEN.setOnClickListener(this);
        Drawable[] drawables1 = this.rBtnLanguageCN.getCompoundDrawables();
        drawables1[0].setBounds(this.rBtnLanguageCN.getPaddingLeft(), this.rBtnLanguageCN.getPaddingTop(), this.rBtnLanguageCN.getPaddingLeft() + LocalDefines.dip2px(this.relateAtivity, 25.0f), this.rBtnLanguageCN.getPaddingTop() + LocalDefines.dip2px(this.relateAtivity, 25.0f));
        this.rBtnLanguageCN.setCompoundDrawables(drawables1[0], drawables1[1], drawables1[2], drawables1[3]);
        Drawable[] drawables2 = this.rBtnLanguageEN.getCompoundDrawables();
        drawables2[0].setBounds(this.rBtnLanguageEN.getPaddingLeft(), this.rBtnLanguageEN.getPaddingTop(), this.rBtnLanguageEN.getPaddingLeft() + LocalDefines.dip2px(this.relateAtivity, 25.0f), this.rBtnLanguageEN.getPaddingTop() + LocalDefines.dip2px(this.relateAtivity, 25.0f));
        this.rBtnLanguageEN.setCompoundDrawables(drawables2[0], drawables2[1], drawables2[2], drawables2[3]);
        this.rIORadioGroup1 = (RadioGroup) this.contentView.findViewById(C0470R.id.rIORadioGroup1);
        this.rIORadioGroup2 = (RadioGroup) this.contentView.findViewById(C0470R.id.rIORadioGroup2);
        this.rIORadioGroup1.clearCheck();
        this.rIORadioGroup2.clearCheck();
        this.rBtnIOModeExternal = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnIOModeExternal);
        this.rBtnIOModeInternal = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnIOModeInternal);
        this.rBtnIOModeManualOff = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnIOModeManualOff);
        this.rBtnIOModeManualOn = (RadioButton) this.contentView.findViewById(C0470R.id.rBtnIOModeManualOn);
        this.rBtnIOModeExternal.setOnClickListener(this);
        this.rBtnIOModeInternal.setOnClickListener(this);
        this.rBtnIOModeManualOff.setOnClickListener(this);
        this.rBtnIOModeManualOn.setOnClickListener(this);
        this.layoutAlarmArea = (LinearLayout) this.contentView.findViewById(C0470R.id.layoutAlarmArea);
        this.layoutAlarmArea.setOnClickListener(this);
        if (this.mServerInfo == null || !this.mIsNeedFresh) {
            updateUI();
        } else {
            getAlarmAndPromptConfig(this.mServerInfo);
        }
        LocalDefines.LocalAlarmAreaList = (ArrayList) LocalDefines.Localmap_Select_area.get(Integer.valueOf(this.mServerInfo.getnDevID()));
        if (LocalDefines.LocalAlarmAreaList != null) {
            for (int i = 0; i < LocalDefines.LocalAlarmAreaList.size(); i++) {
                Integer num = (Integer) LocalDefines.LocalAlarmAreaList.get(i);
            }
        }
    }

    private void updateUI() {
        this.btnAlarmAndPromptSave.setEnabled(true);
        if (this.mHasExIOConfig && this.mIOMode == LocalDefines.ALARM_MODEL_315) {
            this.btnRelecance.setVisibility(0);
        } else {
            this.btnRelecance.setVisibility(8);
        }
        if (LocalDefines._AlarmAndPromptConfig.isHasAlarmConfig()) {
            this.btAlarmMianSwitch.setEnabled(true);
            this.btMotionDetect.setEnabled(LocalDefines._AlarmAndPromptConfig.isbMainAlarmSwitch());
            this.btAlarmMianSwitch.setChecked(LocalDefines._AlarmAndPromptConfig.isbMainAlarmSwitch());
            this.btMotionDetect.setChecked(LocalDefines._AlarmAndPromptConfig.isbMotionAlarmSwitch());
            if (LocalDefines.effectiveTime1 == 1) {
                this.CustomTimeSize = 1;
                this.startHourItem.add(0, (Integer) LocalDefines.ServerStartHour.get(0));
                this.startMinItem.add(0, (Integer) LocalDefines.ServerStartMin.get(0));
                this.endHourItem.add(0, (Integer) LocalDefines.ServerEndHour.get(0));
                this.endMinItem.add(0, (Integer) LocalDefines.ServerEndMin.get(0));
                this.StartTimeitems.add(0, (String) LocalDefines.ServerStartTime_Str.get(0));
                this.EndTimeitems.add(0, (String) LocalDefines.ServerEndTime_Str.get(0));
                this.isCheckItem.add(0, Integer.valueOf(LocalDefines.ServerAlarmSwitch1));
            }
            if (LocalDefines.effectiveTime2 == 1) {
                if (this.CustomTimeSize == 1) {
                    this.CustomTimeSize = 2;
                    this.startHourItem.add(1, (Integer) LocalDefines.ServerStartHour.get(1));
                    this.startMinItem.add(1, (Integer) LocalDefines.ServerStartMin.get(1));
                    this.endHourItem.add(1, (Integer) LocalDefines.ServerEndHour.get(1));
                    this.endMinItem = LocalDefines.ServerEndMin;
                    this.StartTimeitems.add(1, (String) LocalDefines.ServerStartTime_Str.get(1));
                    this.EndTimeitems.add(1, (String) LocalDefines.ServerEndTime_Str.get(1));
                    this.isCheckItem.add(1, Integer.valueOf(LocalDefines.ServerAlarmSwitch2));
                } else {
                    this.CustomTimeSize = 1;
                    this.startHourItem.add(0, (Integer) LocalDefines.ServerStartHour.get(1));
                    this.startMinItem.add(0, (Integer) LocalDefines.ServerStartMin.get(1));
                    this.endHourItem.add(0, (Integer) LocalDefines.ServerEndHour.get(1));
                    this.endMinItem = LocalDefines.ServerEndMin;
                    this.StartTimeitems.add(0, (String) LocalDefines.ServerStartTime_Str.get(1));
                    this.EndTimeitems.add(0, (String) LocalDefines.ServerEndTime_Str.get(1));
                    this.isCheckItem.add(0, Integer.valueOf(LocalDefines.ServerAlarmSwitch2));
                }
            }
            if (LocalDefines.effectiveTime3 == 1) {
                if (this.CustomTimeSize == 1) {
                    this.CustomTimeSize = 2;
                    this.startHourItem.add(1, (Integer) LocalDefines.ServerStartHour.get(2));
                    this.startMinItem.add(1, (Integer) LocalDefines.ServerStartMin.get(2));
                    this.endHourItem.add(1, (Integer) LocalDefines.ServerEndHour.get(2));
                    this.endMinItem = LocalDefines.ServerEndMin;
                    this.StartTimeitems.add(1, (String) LocalDefines.ServerStartTime_Str.get(2));
                    this.EndTimeitems.add(1, (String) LocalDefines.ServerEndTime_Str.get(2));
                    this.isCheckItem.add(1, Integer.valueOf(LocalDefines.ServerAlarmSwitch3));
                } else if (this.CustomTimeSize == 2) {
                    this.CustomTimeSize = 3;
                    this.startHourItem.add(2, (Integer) LocalDefines.ServerStartHour.get(2));
                    this.startMinItem.add(2, (Integer) LocalDefines.ServerStartMin.get(2));
                    this.endHourItem.add(2, (Integer) LocalDefines.ServerEndHour.get(2));
                    this.endMinItem = LocalDefines.ServerEndMin;
                    this.StartTimeitems.add(2, (String) LocalDefines.ServerStartTime_Str.get(2));
                    this.EndTimeitems.add(2, (String) LocalDefines.ServerEndTime_Str.get(2));
                    this.isCheckItem.add(2, Integer.valueOf(LocalDefines.ServerAlarmSwitch3));
                } else {
                    this.CustomTimeSize = 1;
                    this.startHourItem.add(0, (Integer) LocalDefines.ServerStartHour.get(2));
                    this.startMinItem.add(0, (Integer) LocalDefines.ServerStartMin.get(2));
                    this.endHourItem.add(0, (Integer) LocalDefines.ServerEndHour.get(2));
                    this.endMinItem = LocalDefines.ServerEndMin;
                    this.StartTimeitems.add(0, (String) LocalDefines.ServerStartTime_Str.get(2));
                    this.EndTimeitems.add(0, (String) LocalDefines.ServerEndTime_Str.get(2));
                    this.isCheckItem.add(0, Integer.valueOf(LocalDefines.ServerAlarmSwitch3));
                }
            }
            this.adapter = new CustomTimeAdapter(this.StartTimeitems, this.EndTimeitems);
            LayoutParams linearParams3 = (LayoutParams) this.listCustomTime.getLayoutParams();
            linearParams3.height = this.StartTimeitems.size() * this.mAlarmTimeItemHeight;
            this.listCustomTime.setLayoutParams(linearParams3);
            this.listCustomTime.setAdapter(this.adapter);
            if (LocalDefines._AlarmAndPromptConfig.isbMainAlarmSwitch()) {
                this.llSetAlarmTime.setVisibility(0);
                this.alarmline1.setVisibility(0);
                this.ServerIsCheckTime = this.CustomTimeSize;
                if (LocalDefines.ServerAlarmSwitch1 == 0 && LocalDefines.ServerAlarmSwitch2 == 0 && LocalDefines.ServerAlarmSwitch3 == 0) {
                    this.imgTimeArrow.setBackgroundResource(C0470R.drawable.arrow_selector2);
                    this.rBtnAllTime.setChecked(true);
                    this.rBtnSetTime.setChecked(false);
                    this.listCustomTime.setVisibility(8);
                    this.rl_addTime.setVisibility(8);
                } else {
                    this.rBtnAllTime.setChecked(false);
                    this.rBtnSetTime.setChecked(true);
                    this.imgTimeArrow.setBackgroundResource(C0470R.drawable.btn_dropup);
                    this.listCustomTime.setVisibility(0);
                    this.rl_addTime.setVisibility(0);
                }
            } else {
                this.llSetAlarmTime.setVisibility(8);
                this.alarmline1.setVisibility(8);
            }
        } else {
            this.btMotionDetect.setEnabled(false);
            this.btAlarmMianSwitch.setEnabled(false);
        }
        if (LocalDefines._AlarmAndPromptConfig.isHasVoicePromptsConfig()) {
            this.btAudioMianSwitch.setEnabled(true);
            this.rBtnLanguageCN.setEnabled(true);
            this.rBtnLanguageEN.setEnabled(true);
            this.btAlarmAudio.setEnabled(true);
            if (LocalDefines._AlarmAndPromptConfig.isbVoicePromptsMainSwitch()) {
                this.btAudioMianSwitch.setChecked(true);
            } else {
                this.btAudioMianSwitch.setChecked(false);
            }
            if (LocalDefines._AlarmAndPromptConfig.isbAlarmVoiceSwitch()) {
                this.btAlarmAudio.setChecked(true);
            } else {
                this.btAlarmAudio.setChecked(false);
            }
            if (LocalDefines._AlarmAndPromptConfig.getnLanguage() != 1100) {
                this.rBtnLanguageCN.setChecked(true);
                this.rBtnLanguageEN.setChecked(false);
            } else {
                this.rBtnLanguageCN.setChecked(false);
                this.rBtnLanguageEN.setChecked(true);
            }
        } else {
            this.btAudioMianSwitch.setEnabled(false);
            this.rBtnLanguageCN.setEnabled(false);
            this.rBtnLanguageEN.setEnabled(false);
            this.btAlarmAudio.setEnabled(false);
        }
        if (LocalDefines._AlarmAndPromptConfig.isHasExIOConfig()) {
            this.loayoutIOModePanel.setEnabled(true);
            this.rIORadioGroup1.clearCheck();
            this.rIORadioGroup2.clearCheck();
            this.rBtnIOModeExternal.setEnabled(true);
            this.rBtnIOModeInternal.setEnabled(true);
            this.rBtnIOModeManualOff.setEnabled(true);
            this.rBtnIOModeManualOn.setEnabled(true);
            switch (LocalDefines._AlarmAndPromptConfig.getnIOMode()) {
                case 10:
                    this.rBtnIOModeExternal.setChecked(true);
                    break;
                case 11:
                    this.rBtnIOModeInternal.setChecked(true);
                    break;
                case 12:
                    this.rBtnIOModeManualOff.setChecked(true);
                    break;
                case 13:
                    this.rBtnIOModeManualOn.setChecked(true);
                    break;
            }
        }
        this.loayoutIOModePanel.setEnabled(false);
        this.rIORadioGroup1.clearCheck();
        this.rIORadioGroup2.clearCheck();
        this.rBtnIOModeExternal.setEnabled(false);
        this.rBtnIOModeInternal.setEnabled(false);
        this.rBtnIOModeManualOff.setEnabled(false);
        this.rBtnIOModeManualOn.setEnabled(false);
        this.mHasAlarmConfig = LocalDefines._AlarmAndPromptConfig.isHasAlarmConfig();
        this.mBMainAlarmSwitch = LocalDefines._AlarmAndPromptConfig.isbMainAlarmSwitch();
        this.mBMotionAlarmSwitch = LocalDefines._AlarmAndPromptConfig.isbMotionAlarmSwitch();
        this.mBPIRAlarmSwitch = LocalDefines._AlarmAndPromptConfig.isbPIRAlarmSwitch();
        this.mBSmokeAlarmSwitch = LocalDefines._AlarmAndPromptConfig.isbSmokeAlarmSwitch();
        this.mHasVoicePromptsConfig = LocalDefines._AlarmAndPromptConfig.isHasVoicePromptsConfig();
        this.mBVoicePromptsMainSwitch = LocalDefines._AlarmAndPromptConfig.isbVoicePromptsMainSwitch();
        this.mBAlarmVoiceSwitch = LocalDefines._AlarmAndPromptConfig.isbAlarmVoiceSwitch();
        this.mLanguage = LocalDefines._AlarmAndPromptConfig.getnLanguage();
        this.mHasExIOConfig = LocalDefines._AlarmAndPromptConfig.isHasExIOConfig();
        this.mIOMode = LocalDefines._AlarmAndPromptConfig.getnIOMode();
    }

    public void hindKeyboard() {
        if (this.relateAtivity != null) {
            try {
                InputMethodManager imm = (InputMethodManager) this.relateAtivity.getSystemService("input_method");
                if (imm != null) {
                    imm.hideSoftInputFromWindow(this.relateAtivity.getCurrentFocus().getWindowToken(), 2);
                }
            } catch (Exception e) {
            }
        }
    }

    public void ShowAlert(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowAlert(title, msg);
        }
    }

    public void onSaveAndBack(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowNotic(title, msg);
            ShowConfigSetting();
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.btnRelecance:
                LocalDefines.alarmRelecanceDeviceInfo = this.mServerInfo;
                startActivity(new Intent(this.relateAtivity, DeviceAlarmRelecanceActivity.class));
                return;
            case C0470R.id.btnAlarmAndPromptBack:
                this.isGetFinish = false;
                ShowConfigSetting();
                return;
            case C0470R.id.rBtnAllTime:
                isAllTime = true;
                this.rl_addTime.setVisibility(8);
                this.listCustomTime.setVisibility(8);
                LocalDefines.ServerAlarmSwitch1 = 0;
                LocalDefines.ServerAlarmSwitch2 = 0;
                LocalDefines.ServerAlarmSwitch3 = 0;
                this.imgTimeArrow.setBackgroundResource(C0470R.drawable.arrow_selector2);
                return;
            case C0470R.id.rBtnSetTime:
                if (LocalDefines.CanSetTime == 0) {
                    Toast.makeText(getActivity(), getString(C0470R.string.str_device_does_not_support_custom), 0).show();
                    return;
                }
                this.rl_addTime.setVisibility(0);
                isAllTime = false;
                this.imgTimeArrow.setBackgroundResource(C0470R.drawable.btn_dropup);
                if (this.CustomTimeSize == 0 && this.CustomTimeSize != 3) {
                    if (((Integer) LocalDefines.ServerStartHour.get(0)).intValue() == 0 && ((Integer) LocalDefines.ServerStartHour.get(1)).intValue() == 0 && ((Integer) LocalDefines.ServerStartHour.get(2)).intValue() == 0 && ((Integer) LocalDefines.ServerStartMin.get(0)).intValue() == 0 && ((Integer) LocalDefines.ServerStartMin.get(1)).intValue() == 0 && ((Integer) LocalDefines.ServerStartMin.get(2)).intValue() == 0 && ((Integer) LocalDefines.ServerEndHour.get(0)).intValue() == 0 && ((Integer) LocalDefines.ServerEndHour.get(1)).intValue() == 0 && ((Integer) LocalDefines.ServerEndHour.get(2)).intValue() == 0 && ((Integer) LocalDefines.ServerEndMin.get(0)).intValue() == 0 && ((Integer) LocalDefines.ServerEndMin.get(1)).intValue() == 0 && ((Integer) LocalDefines.ServerEndMin.get(2)).intValue() == 0) {
                        this.CustomTimeSize = 1;
                        this.startHourItem.add(0, Integer.valueOf(23));
                        this.startMinItem.add(0, Integer.valueOf(0));
                        this.endHourItem.add(0, Integer.valueOf(8));
                        this.endMinItem.add(0, Integer.valueOf(0));
                        this.StartTimeitems.add(0, "23:00");
                        this.EndTimeitems.add(0, "08:00");
                        this.isCheckItem.add(0, Integer.valueOf(0));
                    }
                    this.adapter = new CustomTimeAdapter(this.StartTimeitems, this.EndTimeitems);
                    ViewGroup.LayoutParams linearParams3 = (LayoutParams) this.listCustomTime.getLayoutParams();
                    linearParams3.height = this.StartTimeitems.size() * this.mAlarmTimeItemHeight;
                    this.listCustomTime.setLayoutParams(linearParams3);
                    Log.i("TAG", "StartTimeitems size" + this.CustomTimeSize);
                    this.listCustomTime.setAdapter(this.adapter);
                }
                if (this.listCustomTime.getVisibility() == 0) {
                    this.listCustomTime.setVisibility(8);
                    this.rl_addTime.setVisibility(8);
                    this.imgTimeArrow.setBackgroundResource(C0470R.drawable.arrow_selector2);
                    return;
                } else if (this.listCustomTime.getVisibility() == 8) {
                    this.rl_addTime.setVisibility(0);
                    this.listCustomTime.setVisibility(0);
                    this.imgTimeArrow.setBackgroundResource(C0470R.drawable.btn_dropup);
                    return;
                } else {
                    return;
                }
            case C0470R.id.rl_addTime:
                if (this.CustomTimeSize >= 3) {
                    Toast.makeText(getActivity(), getString(C0470R.string.str_time_quantity), 0).show();
                    return;
                } else {
                    this.startTimeSelectDialog.show();
                    return;
                }
            case C0470R.id.layoutAlarmArea:
                if (LocalDefines.CanSetTime == 0) {
                    Toast.makeText(getActivity(), getString(C0470R.string.str_device_does_not_support_custom), 0).show();
                    return;
                } else if (this.mBMainAlarmSwitch) {
                    this.loadingDialog.show();
                    new LoginThread(this.handler, this.mServerInfo, this.m_loginID, 200).start();
                    return;
                } else {
                    Toast.makeText(getActivity(), getString(C0470R.string.str_turn_on_alarm_switch), 0).show();
                    return;
                }
            case C0470R.id.rBtnLanguageCN:
                this.mLanguage = 1000;
                return;
            case C0470R.id.rBtnLanguageEN:
                this.mLanguage = 1100;
                return;
            case C0470R.id.btnAlarmAndPromptSave:
                hindKeyboard();
                isSaveArea = false;
                if (this.mServerInfo != null) {
                    if (this.CustomTimeSize == 1) {
                        this.startHour1 = ((Integer) this.startHourItem.get(0)).intValue();
                        this.startMin1 = ((Integer) this.startMinItem.get(0)).intValue();
                        this.endHour1 = ((Integer) this.endHourItem.get(0)).intValue();
                        this.endMin1 = ((Integer) this.endMinItem.get(0)).intValue();
                        LocalDefines.ServerAlarmSwitch2 = 0;
                        this.startHour2 = 0;
                        this.startMin2 = 0;
                        this.startSec2 = 0;
                        this.endHour2 = 0;
                        this.endMin2 = 0;
                        this.endSec2 = 0;
                        LocalDefines.ServerAlarmSwitch3 = 0;
                        this.startHour3 = 0;
                        this.startMin3 = 0;
                        this.startSec3 = 0;
                        this.endHour3 = 0;
                        this.endMin3 = 0;
                        this.endSec3 = 0;
                    } else if (this.CustomTimeSize == 2) {
                        this.startHour1 = ((Integer) this.startHourItem.get(0)).intValue();
                        this.startMin1 = ((Integer) this.startMinItem.get(0)).intValue();
                        this.endHour1 = ((Integer) this.endHourItem.get(0)).intValue();
                        this.endMin1 = ((Integer) this.endMinItem.get(0)).intValue();
                        this.startHour2 = ((Integer) this.startHourItem.get(1)).intValue();
                        this.startMin2 = ((Integer) this.startMinItem.get(1)).intValue();
                        this.endHour2 = ((Integer) this.endHourItem.get(1)).intValue();
                        this.endMin2 = ((Integer) this.endMinItem.get(1)).intValue();
                        this.startHour3 = 0;
                        this.startMin3 = 0;
                        this.startSec3 = 0;
                        this.endHour3 = 0;
                        this.endMin3 = 0;
                        this.endSec3 = 0;
                    } else if (this.CustomTimeSize == 3) {
                        this.startHour1 = ((Integer) this.startHourItem.get(0)).intValue();
                        this.startMin1 = ((Integer) this.startMinItem.get(0)).intValue();
                        this.endHour1 = ((Integer) this.endHourItem.get(0)).intValue();
                        this.endMin1 = ((Integer) this.endMinItem.get(0)).intValue();
                        this.startHour2 = ((Integer) this.startHourItem.get(1)).intValue();
                        this.startMin2 = ((Integer) this.startMinItem.get(1)).intValue();
                        this.endHour2 = ((Integer) this.endHourItem.get(1)).intValue();
                        this.endMin2 = ((Integer) this.endMinItem.get(1)).intValue();
                        this.startHour3 = ((Integer) this.startHourItem.get(2)).intValue();
                        this.startMin3 = ((Integer) this.startMinItem.get(2)).intValue();
                        this.endHour3 = ((Integer) this.endHourItem.get(2)).intValue();
                        this.endMin3 = ((Integer) this.endMinItem.get(2)).intValue();
                    } else if (this.CustomTimeSize == 0) {
                        LocalDefines.ServerAlarmSwitch1 = 0;
                        LocalDefines.ServerAlarmSwitch2 = 0;
                        LocalDefines.ServerAlarmSwitch3 = 0;
                    }
                    if (LocalDefines.Localmap_Update_area.get(Integer.valueOf(this.mServerInfo.getnDevID())) == null) {
                        setAlarmAndPromptConfig(this.mServerInfo, this.mHasAlarmConfig, this.mBMainAlarmSwitch, this.mHasVoicePromptsConfig, this.mBAlarmVoiceSwitch, this.mBVoicePromptsMainSwitch, this.mLanguage, this.mHasExIOConfig, this.mIOMode, 0, this.CustomTimeSize, LocalDefines.ServerAlarmSwitch1, this.startHour1, this.startMin1, this.startSec1, this.endHour1, this.endMin1, this.endSec1, LocalDefines.ServerAlarmSwitch2, this.startHour2, this.startMin2, this.startSec2, this.endHour2, this.endMin2, this.endSec2, LocalDefines.ServerAlarmSwitch3, this.startHour3, this.startMin3, this.startSec3, this.endHour3, this.endMin3, this.endSec3, LocalDefines.ServerAlarmAreaList);
                        return;
                    } else if (((Boolean) LocalDefines.Localmap_Update_area.get(Integer.valueOf(this.mServerInfo.getnDevID()))).booleanValue()) {
                        setAlarmAndPromptConfig(this.mServerInfo, this.mHasAlarmConfig, this.mBMainAlarmSwitch, this.mHasVoicePromptsConfig, this.mBAlarmVoiceSwitch, this.mBVoicePromptsMainSwitch, this.mLanguage, this.mHasExIOConfig, this.mIOMode, 0, this.CustomTimeSize, LocalDefines.ServerAlarmSwitch1, this.startHour1, this.startMin1, this.startSec1, this.endHour1, this.endMin1, this.endSec1, LocalDefines.ServerAlarmSwitch2, this.startHour2, this.startMin2, this.startSec2, this.endHour2, this.endMin2, this.endSec2, LocalDefines.ServerAlarmSwitch3, this.startHour3, this.startMin3, this.startSec3, this.endHour3, this.endMin3, this.endSec3, LocalDefines.LocalAlarmAreaList);
                        return;
                    } else {
                        setAlarmAndPromptConfig(this.mServerInfo, this.mHasAlarmConfig, this.mBMainAlarmSwitch, this.mHasVoicePromptsConfig, this.mBAlarmVoiceSwitch, this.mBVoicePromptsMainSwitch, this.mLanguage, this.mHasExIOConfig, this.mIOMode, 0, this.CustomTimeSize, LocalDefines.ServerAlarmSwitch1, this.startHour1, this.startMin1, this.startSec1, this.endHour1, this.endMin1, this.endSec1, LocalDefines.ServerAlarmSwitch2, this.startHour2, this.startMin2, this.startSec2, this.endHour2, this.endMin2, this.endSec2, LocalDefines.ServerAlarmSwitch3, this.startHour3, this.startMin3, this.startSec3, this.endHour3, this.endMin3, this.endSec3, LocalDefines.ServerAlarmAreaList);
                        return;
                    }
                }
                return;
            case C0470R.id.btnDatetimeSelectCancel:
                this.startTimeSelectDialog.dismiss();
                return;
            case C0470R.id.btnDatetimeSelectOK:
                this.endTimeSelectDialog.show();
                this.startTimeSelectDialog.dismiss();
                this.StartHour = (short) this.mSelectStartTimePicker.getCurrentHour().intValue();
                this.StartMin = (short) this.mSelectStartTimePicker.getCurrentMinute().intValue();
                this.StartSec = 0;
                return;
            case C0470R.id.btnDatetimeSelectCancel_endTime:
                this.endTimeSelectDialog.dismiss();
                return;
            case C0470R.id.btnDatetimeSelectOK_endTime:
                this.endTimeSelectDialog.dismiss();
                this.EndHour = (short) this.mSelectEndTimePicker.getCurrentHour().intValue();
                this.EndMin = (short) this.mSelectEndTimePicker.getCurrentMinute().intValue();
                this.EndSec = (short) 0;
                if (this.StartHour < 10) {
                    this.sStartHour = "0" + this.StartHour;
                } else {
                    this.sStartHour = this.StartHour;
                }
                if (this.StartMin < 10) {
                    this.sStartMin = "0" + this.StartMin;
                } else {
                    this.sStartMin = this.StartMin;
                }
                if (this.EndHour < (short) 10) {
                    this.sEndHour = "0" + this.EndHour;
                } else {
                    this.sEndHour = this.EndHour;
                }
                if (this.EndMin < (short) 10) {
                    this.sEndMin = "0" + this.EndMin;
                } else {
                    this.sEndMin = this.EndMin;
                }
                if (this.EndHour == this.StartHour && this.EndMin == this.StartMin) {
                    Toast toast = Toast.makeText(this.relateAtivity.getApplicationContext(), getString(C0470R.string.str_fail_to_set_time), 0);
                    toast.setGravity(17, 0, 0);
                    toast.show();
                    return;
                }
                this.StartTimeitems.add(this.CustomTimeSize, this.sStartHour + ":" + this.sStartMin);
                this.EndTimeitems.add(this.CustomTimeSize, this.sEndHour + ":" + this.sEndMin);
                this.startHourItem.add(this.CustomTimeSize, Integer.valueOf(this.sStartHour));
                this.startMinItem.add(this.CustomTimeSize, Integer.valueOf(this.sStartMin));
                this.endHourItem.add(this.CustomTimeSize, Integer.valueOf(this.sEndHour));
                this.endMinItem.add(this.CustomTimeSize, Integer.valueOf(this.sEndMin));
                this.isCheckItem.add(this.CustomTimeSize, Integer.valueOf(1));
                this.CustomTimeSize++;
                if (this.CustomTimeSize == 1) {
                    LocalDefines.ServerAlarmSwitch1 = 1;
                } else if (this.CustomTimeSize == 2) {
                    LocalDefines.ServerAlarmSwitch2 = 1;
                } else if (this.CustomTimeSize == 3) {
                    LocalDefines.ServerAlarmSwitch3 = 1;
                }
                this.listCustomTime.setVisibility(0);
                this.adapter = new CustomTimeAdapter(this.StartTimeitems, this.EndTimeitems);
                ViewGroup.LayoutParams linearParams2 = (LayoutParams) this.listCustomTime.getLayoutParams();
                linearParams2.height = this.StartTimeitems.size() * this.mAlarmTimeItemHeight;
                this.listCustomTime.setLayoutParams(linearParams2);
                this.listCustomTime.setAdapter(this.adapter);
                return;
            default:
                return;
        }
    }

    private void ShowConfigSetting() {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ChangeFragment(15, 13, this.mServerInfo);
        }
    }

    private boolean checkAccountSame(int nID, String strUsername, String strPassword) {
        if (this.nID != nID) {
            return false;
        }
        if (this.strSaveUsername == null && strUsername != null) {
            return false;
        }
        if (this.strSavePassword == null && strPassword != null) {
            return false;
        }
        if (this.strSaveUsername.equals(strUsername) && this.strSavePassword.equals(strPassword)) {
            return true;
        }
        return false;
    }

    private void getAlarmAndPromptConfig(DeviceInfo info) {
        if (info != null) {
            this.mLoadType = 1;
            this.loadingDialog.show();
            this.btnAlarmAndPromptSave.setEnabled(false);
            this.isGetFinish = false;
            new AlarmAndPromptConfigThread(info).start();
        }
    }

    private void setAlarmAndPromptConfig(DeviceInfo info, boolean hasAlarmConfig, boolean bMainAlarmSwitch, boolean hasVoicePromptsConfig, boolean bAlarmVoiceSwitch, boolean bVoicePromptsMainSwitch, int nLanguage, boolean hasExIOConfig, int nIOMode, int timeArea, int ntimequantum, int alarmswitch1, int starthour1, int startmin1, int startsec1, int endhour1, int endmin1, int endsec1, int alarmswith2, int starthour2, int startmin2, int startsec2, int endhour2, int endmin2, int endsec2, int alarmswitch3, int starthour3, int startmin3, int startsec3, int endhour3, int endmin3, int endsec3, ArrayList<Integer> alarmArea) {
        if (info != null) {
            this.mLoadType = 2;
            this.loadingDialog.show();
            this.btnAlarmAndPromptSave.setEnabled(false);
            new AlarmAndPromptConfigThread(hasAlarmConfig, bMainAlarmSwitch, hasVoicePromptsConfig, bAlarmVoiceSwitch, bVoicePromptsMainSwitch, nLanguage, hasExIOConfig, nIOMode, timeArea, ntimequantum, alarmswitch1, starthour1, startmin1, startsec1, alarmswith2, starthour2, startmin2, startsec2, alarmswitch3, starthour3, startmin3, startsec3, alarmArea, info).start();
        }
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C02886());
        this.loadingDialog.setOnDismissListener(new C02897());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }

    private void createDialogs() {
        this.startdatetimeSelectConctentView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.start_alarmtime_select_dialog, null);
        this.startTimeSelectDialog = new Dialog(this.relateAtivity, C0470R.style.dialog_bg_transparent);
        this.startTimeSelectDialog.setContentView(this.startdatetimeSelectConctentView);
        this.startTimeSelectDialog.setOnShowListener(new C02918());
        this.startTimeSelectDialog.setOnDismissListener(new C02929());
        this.enddatetimeSelectConctentView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.end_alarmtime_select_dialog, null);
        this.endTimeSelectDialog = new Dialog(this.relateAtivity, C0470R.style.dialog_bg_transparent);
        this.endTimeSelectDialog.setContentView(this.enddatetimeSelectConctentView);
        this.endTimeSelectDialog.setOnShowListener(new OnShowListener() {

            class C02821 implements OnTimeChangedListener {
                C02821() {
                }

                public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                    if (hourOfDay < 10 && minute < 10) {
                        DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":0" + minute);
                    } else if (hourOfDay >= 10 && minute < 10) {
                        DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":0" + minute);
                    } else if (hourOfDay >= 10 || minute < 10) {
                        DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText(hourOfDay + ":" + minute);
                    } else {
                        DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText("0" + hourOfDay + ":" + minute);
                    }
                }
            }

            public void onShow(DialogInterface dialog) {
                DeviceAlarmAndPromptSettingFragment.this.tvDateTimeTitle = (TextView) DeviceAlarmAndPromptSettingFragment.this.enddatetimeSelectConctentView.findViewById(C0470R.id.tvDateTimeTitle_endTime);
                DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent = (TextView) DeviceAlarmAndPromptSettingFragment.this.enddatetimeSelectConctentView.findViewById(C0470R.id.tvDateTimeCurrent_endTime);
                DeviceAlarmAndPromptSettingFragment.this.mSelectDatePicker = (DatePicker) DeviceAlarmAndPromptSettingFragment.this.enddatetimeSelectConctentView.findViewById(C0470R.id.mSelectDatePicker_endTime);
                DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker = (TimePicker) DeviceAlarmAndPromptSettingFragment.this.enddatetimeSelectConctentView.findViewById(C0470R.id.mSelectTimePicker_endTime);
                DeviceAlarmAndPromptSettingFragment.this.layoutDatePicker = (LinearLayout) DeviceAlarmAndPromptSettingFragment.this.enddatetimeSelectConctentView.findViewById(C0470R.id.layoutDatePicker_endTime);
                DeviceAlarmAndPromptSettingFragment.this.layoutTimePicker = (LinearLayout) DeviceAlarmAndPromptSettingFragment.this.enddatetimeSelectConctentView.findViewById(C0470R.id.layoutTimePicker_endTime);
                DeviceAlarmAndPromptSettingFragment.this.btnDatetimeSelectCancel = (Button) DeviceAlarmAndPromptSettingFragment.this.enddatetimeSelectConctentView.findViewById(C0470R.id.btnDatetimeSelectCancel_endTime);
                DeviceAlarmAndPromptSettingFragment.this.btnDatetimeSelectOK = (Button) DeviceAlarmAndPromptSettingFragment.this.enddatetimeSelectConctentView.findViewById(C0470R.id.btnDatetimeSelectOK_endTime);
                DeviceAlarmAndPromptSettingFragment.this.btnDatetimeSelectOK.setOnClickListener(DeviceAlarmAndPromptSettingFragment.this);
                DeviceAlarmAndPromptSettingFragment.this.btnDatetimeSelectCancel.setOnClickListener(DeviceAlarmAndPromptSettingFragment.this);
                DeviceAlarmAndPromptSettingFragment.this.layoutDatePicker.setVisibility(8);
                DeviceAlarmAndPromptSettingFragment.this.layoutTimePicker.setVisibility(0);
                DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.setIs24HourView(Boolean.valueOf(true));
                DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.setCurrentHour(Integer.valueOf(DeviceAlarmAndPromptSettingFragment.this.EndHour));
                DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.setCurrentMinute(Integer.valueOf(DeviceAlarmAndPromptSettingFragment.this.EndMin));
                DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.setOnTimeChangedListener(new C02821());
                if (DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentHour().intValue() < 10 && DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentMinute().intValue() < 10) {
                    DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText("0" + DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentHour() + ":0" + DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentMinute());
                } else if (DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentHour().intValue() >= 10 && DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentMinute().intValue() < 10) {
                    DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText(DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentHour() + ":0" + DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentMinute());
                } else if (DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentHour().intValue() >= 10 || DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentMinute().intValue() < 10) {
                    DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText(DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentHour() + ":" + DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentMinute());
                } else {
                    DeviceAlarmAndPromptSettingFragment.this.tvDateTimeCurrent.setText("0" + DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentHour() + ":" + DeviceAlarmAndPromptSettingFragment.this.mSelectEndTimePicker.getCurrentMinute());
                }
            }
        });
        this.endTimeSelectDialog.setOnDismissListener(new OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
            }
        });
    }

    public void StartLogin(DeviceInfo info, int nListMode) {
        if (info != null) {
            try {
                if (!Functions.isNetworkAvailable(this.relateAtivity.getApplicationContext())) {
                    Toast toast = Toast.makeText(this.relateAtivity.getApplicationContext(), getString(C0470R.string.toast_network_unreachable), 0);
                    toast.setGravity(17, 0, 0);
                    toast.show();
                    return;
                }
            } catch (Exception e) {
            }
            this.m_loginID++;
            if (info.getnSaveType() == Defines.SERVER_SAVE_TYPE_ADD) {
                if (!Functions.isIpAddress(info.getStrIP())) {
                    if (!Functions.hasDot(info.getStrIP())) {
                        info.setStrIP(info.getStrIP() + Defines.MV_DOMAIN_SUFFIX);
                    }
                }
            }
            this.m_strIP = info.getStrIP();
            this.m_nPort = info.getnPort();
            if (info.getStrUsername() == null || info.getStrUsername().length() <= 0) {
                this.m_strUsername = "admin";
                this.m_strPassword = Constants.MAIN_VERSION_TAG;
            } else {
                this.m_strUsername = info.getStrUsername();
                this.m_strPassword = info.getStrPassword();
            }
            this.m_strName = info.getStrName();
            new LoginThread(this.handler, info, this.m_loginID, nListMode).start();
        }
    }
}
