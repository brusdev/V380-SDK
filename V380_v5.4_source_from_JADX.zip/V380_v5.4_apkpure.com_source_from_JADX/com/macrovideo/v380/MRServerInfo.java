package com.macrovideo.v380;

public class MRServerInfo {
    private boolean bIsInit = false;
    private long lInitTime = 0;
    private int nID = -1;
    private int nServerID = 0;
    private String strDomain = null;
    private String strIP = null;

    public int getnID() {
        return this.nID;
    }

    public void setnID(int nID) {
        this.nID = nID;
    }

    public int getnServerID() {
        return this.nServerID;
    }

    public void setnServerID(int nServerID) {
        this.nServerID = nServerID;
    }

    public boolean isbIsInit() {
        return this.bIsInit;
    }

    public void setbIsInit(boolean bIsInit) {
        this.bIsInit = bIsInit;
    }

    public long getlInitTime() {
        return this.lInitTime;
    }

    public void setlInitTime(long lInitTime) {
        this.lInitTime = lInitTime;
    }

    public String getStrDomain() {
        return this.strDomain;
    }

    public void setStrDomain(String strDomain) {
        this.strDomain = strDomain;
    }

    public String getStrIP() {
        return this.strIP;
    }

    public void setStrIP(String strIP) {
        this.strIP = strIP;
    }

    public MRServerInfo(int nID, int nServerID, boolean bIsInit, long lInitTime, String strDomain, String strIP) {
        this.nID = nID;
        this.nServerID = nServerID;
        this.bIsInit = bIsInit;
        this.lInitTime = lInitTime;
        this.strDomain = strDomain;
        this.strIP = strIP;
    }
}
