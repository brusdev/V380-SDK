package com.macrovideo.v380;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Notification;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.BitmapDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Process;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.lock.SoftwarePasswordActivity;
import com.macrovideo.photo.PhotoActivity;
import com.macrovideo.sdk.tools.Functions;

public class HelpFragment extends Fragment implements OnClickListener {
    private static final int MY_PERMISSIONS_REQUEST_STORAGE = 0;
    private ImageView PresonalInfo;
    private View contentView = null;
    private IntentFilter intentFilter;
    private ImageView ivSystemBack;
    private LinearLayout llAreaSelection;
    private LinearLayout llDeviceImage;
    private LinearLayout llHelp;
    private LinearLayout llHelpBg;
    private LinearLayout llPhoneAlarm;
    private LinearLayout llSoftwarExit = null;
    private LinearLayout llSoftwarePassword;
    private LinearLayout llSoftwareUpdate;
    private LinearLayout llSoundShake;
    private int m_nVerCheckID = 0;
    private TabBroadcastReceiver receiver;
    private HomePageActivity relateAtivity = null;
    private TextView tvAccountName;

    class C03621 implements DialogInterface.OnClickListener {
        C03621() {
        }

        public void onClick(DialogInterface dialog, int which) {
            Intent intent = new Intent();
            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.fromParts("package", HelpFragment.this.getActivity().getPackageName(), null));
            HelpFragment.this.startActivity(intent);
        }
    }

    class TabBroadcastReceiver extends BroadcastReceiver {
        TabBroadcastReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            intent.getAction().equals("TAB1_ACTION");
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_help, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = (HomePageActivity) getActivity();
        }
        this.contentView = v;
        InitSubView();
        return v;
    }

    public String getVersionName() {
        String verName = Functions.getVerName(getActivity());
        if (verName == null || verName.length() <= 0) {
            return getString(C0470R.string.app_ver);
        }
        return verName;
    }

    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(this.receiver);
    }

    public void onResume() {
        super.onResume();
        if (HomePageActivity.AppMode != 1 || HomePageActivity.LoginAccount == null || HomePageActivity.LoginAccount.length() <= 0) {
            this.tvAccountName.setText(getString(C0470R.string.str_login_state_false));
        } else {
            this.tvAccountName.setText(HomePageActivity.LoginAccount);
        }
        this.receiver = new TabBroadcastReceiver();
        getActivity().registerReceiver(this.receiver, getIntentFilter());
    }

    private IntentFilter getIntentFilter() {
        if (this.intentFilter == null) {
            this.intentFilter = new IntentFilter();
            this.intentFilter.addAction("TAB1_ACTION");
        }
        return this.intentFilter;
    }

    private void InitSubView() {
        this.PresonalInfo = (ImageView) this.contentView.findViewById(C0470R.id.help_logo);
        this.PresonalInfo.setOnClickListener(this);
        this.llHelpBg = (LinearLayout) this.contentView.findViewById(C0470R.id.llHelpBg);
        this.llHelpBg.setBackgroundDrawable(new BitmapDrawable(Functions.readBitMap(this.relateAtivity, C0470R.drawable.help_bg)));
        this.ivSystemBack = (ImageView) this.contentView.findViewById(C0470R.id.ivSystemBack);
        this.ivSystemBack.setOnClickListener(this);
        this.llSoftwareUpdate = (LinearLayout) this.contentView.findViewById(C0470R.id.llSoftwareUpdate);
        this.llSoftwareUpdate.setOnClickListener(this);
        this.llSoundShake = (LinearLayout) this.contentView.findViewById(C0470R.id.llSoundShake);
        this.llSoundShake.setVisibility(8);
        this.llSoftwarePassword = (LinearLayout) this.contentView.findViewById(C0470R.id.llSoftwarePassword);
        this.llSoftwarePassword.setOnClickListener(this);
        this.llSoftwarExit = (LinearLayout) this.contentView.findViewById(C0470R.id.llSoftwarExit);
        this.llSoftwarExit.setOnClickListener(this);
        this.llPhoneAlarm = (LinearLayout) this.contentView.findViewById(C0470R.id.llPhoneAlarm);
        this.llPhoneAlarm.setOnClickListener(this);
        this.llDeviceImage = (LinearLayout) this.contentView.findViewById(C0470R.id.llDeviceImage);
        this.llDeviceImage.setOnClickListener(this);
        this.llAreaSelection = (LinearLayout) this.contentView.findViewById(C0470R.id.llAreaSelection);
        this.llAreaSelection.setOnClickListener(this);
        this.llHelp = (LinearLayout) this.contentView.findViewById(C0470R.id.llHelp);
        this.llHelp.setOnClickListener(this);
        this.tvAccountName = (TextView) this.contentView.findViewById(C0470R.id.tv_account_name);
    }

    public void onStart() {
        super.onStart();
    }

    public void onDestroy() {
        if (this.llHelpBg != null) {
            BitmapDrawable llHelpBgs = (BitmapDrawable) this.llHelpBg.getBackground();
            this.llHelpBg.setBackgroundResource(0);
            llHelpBgs.setCallback(null);
            llHelpBgs.getBitmap().recycle();
        }
        System.gc();
        super.onDestroy();
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != 0) {
            return;
        }
        if (permissions[0].equals("android.permission.WRITE_EXTERNAL_STORAGE") && grantResults[0] == 0) {
            startActivity(new Intent(getActivity(), PhotoActivity.class));
            return;
        }
        View view = View.inflate(getActivity(), C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getResources().getString(C0470R.string.str_permission_request));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getResources().getString(C0470R.string.str_permission_storage1));
        new Builder(getActivity()).setView(view).setNegativeButton(getResources().getString(C0470R.string.str_permission_neglect), null).setPositiveButton(getResources().getString(C0470R.string.str_permission_setting), new C03621()).show();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.llHelp:
                Intent intentHelp = new Intent(getActivity(), HelpActivity.class);
                try {
                    if (!Functions.isNetworkAvailable(this.relateAtivity.getApplicationContext())) {
                        Toast toast = Toast.makeText(this.relateAtivity.getApplicationContext(), getString(C0470R.string.toast_network_unreachable), 0);
                        toast.setGravity(17, 0, 0);
                        toast.show();
                        return;
                    }
                } catch (Exception e) {
                }
                intentHelp.putExtra("urlZh", "http://www.av380.cn/guide/index_v380.html");
                intentHelp.putExtra("urlEn", "http://www.av380.cn/guide/index_v380_en.html");
                startActivity(intentHelp);
                return;
            case C0470R.id.ivSystemBack:
                this.relateAtivity.ChangeFragment(10, 10, null);
                return;
            case C0470R.id.help_logo:
                if (HomePageActivity.AppMode == 1) {
                    Intent infoIntent = new Intent(getActivity(), PersonalInformationActivity.class);
                    infoIntent.putExtra("Login_Way", HomePageActivity.LoginWay);
                    startActivity(infoIntent);
                    return;
                }
                startActivity(new Intent(getActivity(), LoginActivity.class));
                this.relateAtivity.closeActivity();
                return;
            case C0470R.id.llPhoneAlarm:
                startActivity(new Intent(getActivity(), AlarmNoticeSettingActivity.class));
                return;
            case C0470R.id.llDeviceImage:
                if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this.relateAtivity, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                    startActivity(new Intent(getActivity(), PhotoManagerActivity.class));
                    return;
                }
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 0);
                return;
            case C0470R.id.llAreaSelection:
                startActivity(new Intent(getActivity(), AreaListActivity.class));
                return;
            case C0470R.id.llSoftwarePassword:
                startActivity(new Intent(getActivity(), SoftwarePasswordActivity.class));
                return;
            case C0470R.id.llSoftwareUpdate:
                startActivity(new Intent(getActivity(), AboutActivity.class));
                return;
            case C0470R.id.llSoftwarExit:
                if (HomePageActivity.AppMode == 1) {
                    showExitDialog();
                    return;
                } else {
                    this.relateAtivity.ShowApplicationExitAlert();
                    return;
                }
            default:
                return;
        }
    }

    private void setAlarmParams(Notification notification, boolean bSound, boolean bShock) {
        switch (((AudioManager) getActivity().getSystemService("audio")).getRingerMode()) {
            case 0:
                notification.sound = null;
                notification.vibrate = null;
                return;
            case 1:
                notification.sound = null;
                notification.defaults |= 2;
                return;
            case 2:
                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
                if (bSound) {
                    notification.defaults |= 1;
                }
                if (bShock) {
                    notification.defaults |= 2;
                }
                notification.flags |= 1;
                return;
            default:
                return;
        }
    }

    private void showExitDialog() {
        final AlertDialog exitDialog = new Builder(this.relateAtivity).create();
        View view = View.inflate(this.relateAtivity, C0470R.layout.exit_dialog, null);
        ((LinearLayout) view.findViewById(C0470R.id.ll_login_exit)).setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if (exitDialog != null && exitDialog.isShowing()) {
                    exitDialog.dismiss();
                }
                HelpFragment.this.relateAtivity.getSharedPreferences("ShareAPPMODE", 0).edit().putInt("GetModeNum", 0).commit();
                HomePageActivity.AppMode = 0;
                Editor editor = HelpFragment.this.relateAtivity.getSharedPreferences("SaveTimeTamp", 0).edit();
                editor.putInt("TimeTamp", 0);
                editor.commit();
                HelpFragment.this.startActivity(new Intent(HelpFragment.this.getActivity(), LoginActivity.class));
                HelpFragment.this.relateAtivity.closeActivity();
            }
        });
        ((LinearLayout) view.findViewById(C0470R.id.ll_app_exit)).setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if (exitDialog != null && exitDialog.isShowing()) {
                    exitDialog.dismiss();
                }
                LocalDefines.IsSoftwareRunning = false;
                HelpFragment.this.relateAtivity.m_bFinish = true;
                Process.killProcess(Process.myPid());
                System.exit(0);
                HelpFragment.this.relateAtivity.closeActivity();
            }
        });
        exitDialog.setView(view);
        exitDialog.setCanceledOnTouchOutside(true);
        exitDialog.show();
    }
}
