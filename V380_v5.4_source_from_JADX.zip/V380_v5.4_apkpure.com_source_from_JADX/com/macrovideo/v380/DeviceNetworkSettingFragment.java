package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import com.macrovideo.pull.lib.InnerListView;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.setting.DeviceNetwordSetting;
import com.macrovideo.sdk.setting.NetwordInfo;
import com.macrovideo.sdk.setting.WifiInfo;
import com.tencent.android.tpush.common.Constants;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

@SuppressLint({"ValidFragment"})
public class DeviceNetworkSettingFragment extends Fragment implements OnClickListener, OnItemClickListener {
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    private ImageView apCheckBoxPwdHiden;
    boolean bHidenPassword = false;
    private ImageView btnNetworkBack;
    private Button btnNetworkSave;
    private Button btnWifiDevRefresh;
    private LinearLayout cbModifyAP = null;
    private ImageView cbModifyAPCheckBox = null;
    private LinearLayout cbModifyStation = null;
    private ImageView cbModifyStationCheckBox = null;
    private View contentView = null;
    private EditText etWifiAPPassword = null;
    private EditText etWifiAPname = null;
    private EditText etWifiStationName = null;
    private EditText etWifiStationPassword = null;
    private Handler handler = new C03241();
    private boolean isActive = false;
    private boolean isChecked = true;
    boolean isCrypt = false;
    private boolean isGetFinish = false;
    private long lFreshTime = 0;
    private LinearLayout layoutLocalWifiList = null;
    private LinearLayout llWifi;
    private Dialog loadingDialog;
    private View loadingView;
    boolean mIsNeedFresh = false;
    boolean mIsSearchingWifiList = false;
    private int mLoadType = 1;
    private NetwordInfo mNetworkConfig = new NetwordInfo();
    private DeviceInfo mServerInfo = null;
    private boolean m_bAPModify = false;
    private boolean m_bStationModify = false;
    private int m_nWifiMode = 0;
    private int m_nwifiId = 0;
    private int nID = -1;
    private ProgressBar progressBarWifiSearching = null;
    private Activity relateAtivity = null;
    private ImageView stationCheckBoxPwdHiden;
    private String strSavePassword = null;
    private String strSaveUsername = null;
    private ScrollView svWifiListView;
    private TextView tvUsingWifiMode = null;
    private InnerListView wifiDeviceListView = null;
    private ArrayList<WifiInfo> wifiList = new ArrayList();

    class C03241 extends Handler {

        class C03221 implements DialogInterface.OnClickListener {
            C03221() {
            }

            public void onClick(DialogInterface dialog, int which) {
                DeviceNetworkSettingFragment.this.ShowConfigSetting();
            }
        }

        class C03232 implements DialogInterface.OnClickListener {
            C03232() {
            }

            public void onClick(DialogInterface dialog, int whichButton) {
                DeviceNetworkSettingFragment.this.relateAtivity.setResult(-1);
                ((HomePageActivity) DeviceNetworkSettingFragment.this.relateAtivity).openWifiSettingView();
                DeviceNetworkSettingFragment.this.ShowConfigSetting();
            }
        }

        C03241() {
        }

        public void handleMessage(Message msg) {
            if (DeviceNetworkSettingFragment.this.isActive) {
                DeviceNetworkSettingFragment.this.mIsNeedFresh = false;
                int nCurrentMode = 0;
                String strAPName = null;
                String strAPPassword = null;
                boolean isStationWifiConfig = false;
                String strStationWifiName = null;
                String strStationWifiPassword = null;
                int nDeviceVersion = 0;
                Bundle data;
                NetwordInfo networdHandler;
                if (msg.arg1 == 64) {
                    DeviceNetworkSettingFragment.this.contentView.findViewById(C0470R.id.layoutNetworkConfigPanel).setEnabled(true);
                    DeviceNetworkSettingFragment.this.loadingDialog.dismiss();
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR /*-272*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_PWD_ERR));
                            return;
                        case ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR_STATION /*-265*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_PWD_ERR_Station));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERR_AP /*-264*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_PWD_ERR_AP));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            return;
                        case 256:
                            if (DeviceNetworkSettingFragment.this.mNetworkConfig.getnDeviceVersion() > 0) {
                                if (DeviceNetworkSettingFragment.this.m_nWifiMode == 0) {
                                    DeviceNetworkSettingFragment.this.tvUsingWifiMode.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.wifi_current_mode))).append("UNKNOW").toString());
                                    DeviceNetworkSettingFragment.this.onWifiModeChange(0);
                                } else if (DeviceNetworkSettingFragment.this.m_nWifiMode == 1001) {
                                    DeviceNetworkSettingFragment.this.tvUsingWifiMode.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.wifi_current_mode))).append("AP").toString());
                                    DeviceNetworkSettingFragment.this.onWifiModeChange(1001);
                                } else if (DeviceNetworkSettingFragment.this.m_nWifiMode == 1002) {
                                    DeviceNetworkSettingFragment.this.tvUsingWifiMode.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.wifi_current_mode))).append("STATION").toString());
                                    DeviceNetworkSettingFragment.this.onWifiModeChange(1002);
                                }
                                DeviceNetworkSettingFragment.this.mNetworkConfig.setnMode(DeviceNetworkSettingFragment.this.m_nWifiMode);
                                if (DeviceNetworkSettingFragment.this.m_nWifiMode == 1001) {
                                    strAPName = DeviceNetworkSettingFragment.this.etWifiAPname.getText().toString();
                                    strAPPassword = DeviceNetworkSettingFragment.this.etWifiAPPassword.getText().toString();
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setbWifiSet(false);
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setStrApName(strAPName);
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setStrApPassword(strAPPassword);
                                } else if (DeviceNetworkSettingFragment.this.m_nWifiMode == 1002) {
                                    String strWifiName = DeviceNetworkSettingFragment.this.etWifiStationName.getText().toString();
                                    String trWifiPassword = DeviceNetworkSettingFragment.this.etWifiStationPassword.getText().toString();
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setbWifiSet(true);
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setStrWifiName(strWifiName);
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setStrWifiPassword(trWifiPassword);
                                }
                            } else {
                                data = msg.getData();
                                if (data != null) {
                                    networdHandler = (NetwordInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                                    if (networdHandler != null) {
                                        strAPName = networdHandler.getStrApName();
                                        strAPPassword = networdHandler.getStrApPassword();
                                        isStationWifiConfig = networdHandler.isbWifiSet();
                                        strStationWifiName = networdHandler.getStrWifiName();
                                        strStationWifiPassword = networdHandler.getStrWifiPassword();
                                    }
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setnMode(0);
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setStrApName(strAPName);
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setStrApPassword(strAPPassword);
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setbWifiSet(isStationWifiConfig);
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setStrWifiName(strStationWifiName);
                                    DeviceNetworkSettingFragment.this.mNetworkConfig.setStrWifiPassword(strStationWifiPassword);
                                }
                            }
                            DeviceNetworkSettingFragment.this.lFreshTime = System.currentTimeMillis();
                            View view = View.inflate(DeviceNetworkSettingFragment.this.relateAtivity, C0470R.layout.show_alert_dialog, null);
                            ((TextView) view.findViewById(C0470R.id.tv_title)).setText(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_ok));
                            ((TextView) view.findViewById(C0470R.id.tv_content)).setText(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_open_setting_view));
                            new Builder(DeviceNetworkSettingFragment.this.relateAtivity).setView(view).setNegativeButton(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_btn_NO), new C03221()).setPositiveButton(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_btn_YES), new C03232()).show();
                            DeviceNetworkSettingFragment.this.btnNetworkSave.setEnabled(true);
                            DeviceNetworkSettingFragment.this.btnNetworkSave.setVisibility(0);
                            return;
                        default:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            return;
                    }
                } else if (msg.arg1 == 48) {
                    DeviceNetworkSettingFragment.this.loadingDialog.dismiss();
                    DeviceNetworkSettingFragment.this.cbModifyAP.setClickable(false);
                    DeviceNetworkSettingFragment.this.cbModifyStation.setClickable(false);
                    DeviceNetworkSettingFragment.this.onWifiModeChange(0);
                    DeviceNetworkSettingFragment.this.btnNetworkSave.setEnabled(false);
                    DeviceNetworkSettingFragment.this.btnNetworkSave.setVisibility(8);
                    DeviceNetworkSettingFragment.this.contentView.findViewById(C0470R.id.layoutNetworkConfigPanel).setEnabled(false);
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR /*-272*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_PWD_ERR));
                            return;
                        case ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR_STATION /*-265*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_PWD_ERR_Station));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERR_AP /*-264*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_PWD_ERR_AP));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            return;
                        case 256:
                            DeviceNetworkSettingFragment.this.contentView.findViewById(C0470R.id.layoutNetworkConfigPanel).setEnabled(true);
                            DeviceNetworkSettingFragment.this.btnNetworkSave.setEnabled(true);
                            DeviceNetworkSettingFragment.this.btnNetworkSave.setVisibility(0);
                            DeviceNetworkSettingFragment.this.cbModifyAP.setEnabled(true);
                            DeviceNetworkSettingFragment.this.cbModifyStation.setEnabled(true);
                            DeviceNetworkSettingFragment.this.cbModifyAP.setClickable(true);
                            DeviceNetworkSettingFragment.this.cbModifyStation.setClickable(true);
                            data = msg.getData();
                            if (data == null) {
                                DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_BadResult));
                                DeviceNetworkSettingFragment.this.ShowConfigSetting();
                                return;
                            }
                            DeviceNetworkSettingFragment.this.isGetFinish = true;
                            networdHandler = (NetwordInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                            if (networdHandler != null) {
                                nCurrentMode = networdHandler.getnMode();
                                strAPName = networdHandler.getStrApName();
                                strAPPassword = networdHandler.getStrApPassword();
                                isStationWifiConfig = networdHandler.isbWifiSet();
                                strStationWifiName = networdHandler.getStrWifiName();
                                strStationWifiPassword = networdHandler.getStrWifiPassword();
                                nDeviceVersion = networdHandler.getnDeviceVersion();
                            }
                            if (DeviceNetworkSettingFragment.this.mServerInfo != null) {
                                DeviceNetworkSettingFragment.this.nID = DeviceNetworkSettingFragment.this.mServerInfo.getnID();
                                DeviceNetworkSettingFragment.this.strSaveUsername = DeviceNetworkSettingFragment.this.mServerInfo.getStrUsername();
                                DeviceNetworkSettingFragment.this.strSavePassword = DeviceNetworkSettingFragment.this.mServerInfo.getStrPassword();
                            } else {
                                DeviceNetworkSettingFragment.this.nID = -1;
                            }
                            DeviceNetworkSettingFragment.this.mNetworkConfig.setnMode(nCurrentMode);
                            DeviceNetworkSettingFragment.this.mNetworkConfig.setStrApName(strAPName);
                            DeviceNetworkSettingFragment.this.mNetworkConfig.setStrApPassword(strAPPassword);
                            DeviceNetworkSettingFragment.this.mNetworkConfig.setbWifiSet(isStationWifiConfig);
                            DeviceNetworkSettingFragment.this.mNetworkConfig.setStrWifiName(strStationWifiName);
                            DeviceNetworkSettingFragment.this.mNetworkConfig.setStrWifiPassword(strStationWifiPassword);
                            DeviceNetworkSettingFragment.this.mNetworkConfig.setnDeviceVersion(nDeviceVersion);
                            if (DeviceNetworkSettingFragment.this.mNetworkConfig.getnDeviceVersion() > 0) {
                                if (nCurrentMode == 0) {
                                    DeviceNetworkSettingFragment.this.tvUsingWifiMode.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.wifi_current_mode))).append("UNKNOW").toString());
                                    DeviceNetworkSettingFragment.this.onWifiModeChange(0);
                                } else if (nCurrentMode == 1001) {
                                    DeviceNetworkSettingFragment.this.tvUsingWifiMode.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.wifi_current_mode))).append("AP").toString());
                                    DeviceNetworkSettingFragment.this.onWifiModeChange(1001);
                                } else if (nCurrentMode == 1002) {
                                    DeviceNetworkSettingFragment.this.tvUsingWifiMode.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.wifi_current_mode))).append("STATION").toString());
                                    DeviceNetworkSettingFragment.this.onWifiModeChange(1002);
                                }
                                if (isStationWifiConfig) {
                                    DeviceNetworkSettingFragment.this.etWifiStationName.setText(strStationWifiName);
                                    DeviceNetworkSettingFragment.this.etWifiStationPassword.setText(strStationWifiPassword);
                                } else {
                                    DeviceNetworkSettingFragment.this.etWifiStationName.setText(Constants.MAIN_VERSION_TAG);
                                    DeviceNetworkSettingFragment.this.etWifiStationPassword.setText(Constants.MAIN_VERSION_TAG);
                                }
                                DeviceNetworkSettingFragment.this.etWifiAPname.setText(strAPName);
                                DeviceNetworkSettingFragment.this.etWifiAPPassword.setText(strAPPassword);
                            } else {
                                if (nCurrentMode == 0) {
                                    DeviceNetworkSettingFragment.this.tvUsingWifiMode.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.wifi_current_mode))).append("UNKNOW").toString());
                                } else if (nCurrentMode == 1001) {
                                    DeviceNetworkSettingFragment.this.tvUsingWifiMode.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.wifi_current_mode))).append("AP").toString());
                                } else if (nCurrentMode == 1002) {
                                    DeviceNetworkSettingFragment.this.tvUsingWifiMode.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.wifi_current_mode))).append("STATION").toString());
                                }
                                if (isStationWifiConfig) {
                                    DeviceNetworkSettingFragment.this.etWifiStationName.setText(strStationWifiName);
                                    DeviceNetworkSettingFragment.this.etWifiStationPassword.setText(strStationWifiPassword);
                                } else {
                                    DeviceNetworkSettingFragment.this.etWifiStationName.setText(Constants.MAIN_VERSION_TAG);
                                    DeviceNetworkSettingFragment.this.etWifiStationPassword.setText(Constants.MAIN_VERSION_TAG);
                                }
                                DeviceNetworkSettingFragment.this.etWifiAPname.setText(strAPName);
                                DeviceNetworkSettingFragment.this.etWifiAPPassword.setText(strAPPassword);
                                DeviceNetworkSettingFragment.this.m_bAPModify = false;
                                DeviceNetworkSettingFragment.this.m_bStationModify = false;
                                DeviceNetworkSettingFragment.this.onWifiModeChange(1003);
                            }
                            DeviceNetworkSettingFragment.this.lFreshTime = System.currentTimeMillis();
                            return;
                        default:
                            DeviceNetworkSettingFragment.this.ShowAlert(DeviceNetworkSettingFragment.this.getString(C0470R.string.alert_get_config_fail), DeviceNetworkSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            DeviceNetworkSettingFragment.this.ShowConfigSetting();
                            return;
                    }
                } else if (msg.arg1 == 32) {
                    DeviceNetworkSettingFragment.this.loadingDialog.dismiss();
                    DeviceNetworkSettingFragment.this.wifiDeviceListView.setEnabled(true);
                    switch (msg.arg2) {
                        case 17:
                            DeviceNetworkSettingFragment.this.StopSearchWifi();
                            DeviceNetworkSettingFragment.this.refleshWifiListView();
                            return;
                        case LocalDefines.WIFI_SEARCH_RESULT_CODE_FAIL_NET_POOL /*4114*/:
                            DeviceNetworkSettingFragment.this.StopSearchWifi();
                            DeviceNetworkSettingFragment.this.StartSearchWifi();
                            return;
                        default:
                            return;
                    }
                }
            }
        }
    }

    class C03252 implements OnClickListener {
        C03252() {
        }

        public void onClick(View arg0) {
            if (DeviceNetworkSettingFragment.this.isChecked) {
                DeviceNetworkSettingFragment.this.bHidenPassword = true;
                DeviceNetworkSettingFragment.this.isChecked = false;
                DeviceNetworkSettingFragment.this.etWifiAPPassword.setInputType(Defines.NV_IP_PTZX_REQUEST);
                DeviceNetworkSettingFragment.this.etWifiStationPassword.setInputType(Defines.NV_IP_PTZX_REQUEST);
                DeviceNetworkSettingFragment.this.apCheckBoxPwdHiden.setImageResource(C0470R.drawable.netword_hide);
                return;
            }
            DeviceNetworkSettingFragment.this.bHidenPassword = false;
            DeviceNetworkSettingFragment.this.isChecked = true;
            DeviceNetworkSettingFragment.this.etWifiAPPassword.setInputType(144);
            DeviceNetworkSettingFragment.this.etWifiStationPassword.setInputType(144);
            DeviceNetworkSettingFragment.this.apCheckBoxPwdHiden.setImageResource(C0470R.drawable.netword_show_password);
        }
    }

    class C03263 implements OnClickListener {
        C03263() {
        }

        public void onClick(View arg0) {
            if (DeviceNetworkSettingFragment.this.isChecked) {
                DeviceNetworkSettingFragment.this.bHidenPassword = true;
                DeviceNetworkSettingFragment.this.isChecked = false;
                DeviceNetworkSettingFragment.this.etWifiAPPassword.setInputType(Defines.NV_IP_PTZX_REQUEST);
                DeviceNetworkSettingFragment.this.etWifiStationPassword.setInputType(Defines.NV_IP_PTZX_REQUEST);
                DeviceNetworkSettingFragment.this.stationCheckBoxPwdHiden.setImageResource(C0470R.drawable.netword_hide);
                return;
            }
            DeviceNetworkSettingFragment.this.bHidenPassword = false;
            DeviceNetworkSettingFragment.this.isChecked = true;
            DeviceNetworkSettingFragment.this.etWifiAPPassword.setInputType(144);
            DeviceNetworkSettingFragment.this.etWifiStationPassword.setInputType(144);
            DeviceNetworkSettingFragment.this.stationCheckBoxPwdHiden.setImageResource(C0470R.drawable.netword_show_password);
        }
    }

    class C03274 implements OnShowListener {
        C03274() {
        }

        public void onShow(DialogInterface dialog) {
            TextView tv = (TextView) DeviceNetworkSettingFragment.this.loadingView.findViewById(C0470R.id.loginText);
            if (DeviceNetworkSettingFragment.this.mLoadType == 1) {
                tv.setText(DeviceNetworkSettingFragment.this.getString(C0470R.string.loading));
            } else if (DeviceNetworkSettingFragment.this.mLoadType == 2) {
                tv.setText(DeviceNetworkSettingFragment.this.getString(C0470R.string.str_saving));
            }
        }
    }

    class C03285 implements OnDismissListener {
        C03285() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    private class NetWorkConfigThread extends Thread {
        static final int OP_TYPE_GET = 10;
        static final int OP_TYPE_SET = 11;
        static final int OP_TYPE_SETEX = 12;
        boolean m_bAPSet;
        boolean m_bWifiSet;
        int m_nMode;
        String m_strAPName;
        String m_strAPPassword;
        String m_strWifiName;
        String m_strWifiPassword;
        private int nOPType;

        public NetWorkConfigThread() {
            this.m_nMode = 1001;
            this.m_bAPSet = false;
            this.m_strAPName = null;
            this.m_strAPPassword = null;
            this.m_bWifiSet = false;
            this.m_strWifiName = null;
            this.m_strWifiPassword = null;
            this.nOPType = 10;
            this.nOPType = 10;
        }

        public NetWorkConfigThread(boolean bAPModify, String strAPName, String strAPPassword, boolean bStationModify, String strWifiName, String strWifiPassword) {
            this.m_nMode = 1001;
            this.m_bAPSet = false;
            this.m_strAPName = null;
            this.m_strAPPassword = null;
            this.m_bWifiSet = false;
            this.m_strWifiName = null;
            this.m_strWifiPassword = null;
            this.nOPType = 10;
            this.nOPType = 11;
            this.m_bAPSet = bAPModify;
            this.m_strAPName = strAPName;
            this.m_strAPPassword = strAPPassword;
            this.m_bWifiSet = bStationModify;
            this.m_strWifiName = strWifiName;
            this.m_strWifiPassword = strWifiPassword;
        }

        public NetWorkConfigThread(int nWifiMode, String strWifiName, String strWifiPassword) {
            this.m_nMode = 1001;
            this.m_bAPSet = false;
            this.m_strAPName = null;
            this.m_strAPPassword = null;
            this.m_bWifiSet = false;
            this.m_strWifiName = null;
            this.m_strWifiPassword = null;
            this.nOPType = 10;
            this.nOPType = 12;
            this.m_nMode = nWifiMode;
            this.m_strWifiName = strWifiName;
            this.m_strWifiPassword = strWifiPassword;
        }

        public void run() {
            NetwordInfo deviceParam;
            Message msg;
            Bundle data;
            if (this.nOPType == 10) {
                deviceParam = DeviceNetwordSetting.getNetword(DeviceNetworkSettingFragment.this.mServerInfo);
                if (deviceParam != null) {
                    msg = DeviceNetworkSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 48;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceNetworkSettingFragment.this.handler.sendMessage(msg);
                }
            } else if (this.nOPType == 11) {
                deviceParam = DeviceNetwordSetting.setNetwordAP(DeviceNetworkSettingFragment.this.mServerInfo, this.m_bAPSet, this.m_strAPName, this.m_strAPPassword, this.m_bWifiSet, this.m_strWifiName, this.m_strWifiPassword);
                if (deviceParam != null) {
                    msg = DeviceNetworkSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 64;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceNetworkSettingFragment.this.handler.sendMessage(msg);
                }
            } else if (this.nOPType == 12) {
                deviceParam = DeviceNetwordSetting.setNetword(DeviceNetworkSettingFragment.this.mServerInfo, this.m_nMode, this.m_strWifiName, this.m_strWifiPassword);
                if (deviceParam != null) {
                    msg = DeviceNetworkSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 64;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceNetworkSettingFragment.this.handler.sendMessage(msg);
                }
            }
        }
    }

    private class WifiListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageButton btnFace;
            ImageButton btnSignal;
            TextView tvInfo;
            TextView tvName;

            private ItemViewHolder() {
            }
        }

        public WifiListViewAdapter(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.wifi_list_item, null);
                this.holder = new ItemViewHolder();
                this.holder.btnFace = (ImageButton) convertView.findViewById(this.valueViewID[0]);
                this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[1]);
                this.holder.tvInfo = (TextView) convertView.findViewById(this.valueViewID[2]);
                this.holder.btnSignal = (ImageButton) convertView.findViewById(this.valueViewID[3]);
                convertView.setTag(this.holder);
            }
            HashMap<String, Object> map = (HashMap) this.mAppList.get(position);
            if (map != null) {
                WifiInfo info = (WifiInfo) map.get("WifiInfo");
                this.holder.tvInfo.setVisibility(8);
                if (info != null) {
                    this.holder.tvName.setText(info.getSsid());
                    if (info.getFlags() == 0) {
                        this.holder.tvInfo.setText(Constants.MAIN_VERSION_TAG);
                        this.holder.tvInfo.setVisibility(8);
                        if (info.getSignalLevel() >= -55.0d) {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_4));
                        } else if (info.getSignalLevel() >= -70.0d) {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_3));
                        } else if (info.getSignalLevel() >= -85.0d) {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_2));
                        } else if (info.getSignalLevel() >= -100.0d) {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_1));
                        } else {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_unlock_0));
                        }
                    } else {
                        this.holder.tvInfo.setVisibility(0);
                        if (info.getProtectDesc().length() > 40) {
                            this.holder.tvInfo.setTextSize(8.0f);
                        } else {
                            this.holder.tvInfo.setTextSize(10.0f);
                        }
                        this.holder.tvInfo.setText(new StringBuilder(String.valueOf(DeviceNetworkSettingFragment.this.getString(C0470R.string.str_secured_with))).append(info.getProtectDesc()).toString());
                        if (info.getSignalLevel() >= -55.0d) {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_lock_4));
                        } else if (info.getSignalLevel() >= -70.0d) {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_lock_3));
                        } else if (info.getSignalLevel() >= -85.0d) {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_lock_2));
                        } else if (info.getSignalLevel() >= -100.0d) {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_lock_1));
                        } else {
                            this.holder.btnSignal.setBackgroundDrawable(DeviceNetworkSettingFragment.this.getResources().getDrawable(C0470R.drawable.wifi_lock_0));
                        }
                    }
                }
            }
            return convertView;
        }
    }

    public class WifiSearcher extends Thread {
        int nWifiId = 0;

        public WifiSearcher(int nWifiId) {
            this.nWifiId = nWifiId;
        }

        public void run() {
            DeviceNetworkSettingFragment.this.wifiList = (ArrayList) DeviceNetwordSetting.getNetwordWifiList(DeviceNetworkSettingFragment.this.mServerInfo, true);
            Message msg;
            if (DeviceNetworkSettingFragment.this.wifiList != null && DeviceNetworkSettingFragment.this.wifiList.size() > 0 && DeviceNetworkSettingFragment.this.m_nwifiId == this.nWifiId) {
                msg = DeviceNetworkSettingFragment.this.handler.obtainMessage();
                msg.arg1 = 32;
                msg.arg2 = 17;
                Collections.sort(DeviceNetworkSettingFragment.this.wifiList);
                DeviceNetworkSettingFragment.this.handler.sendMessage(msg);
            } else if (DeviceNetworkSettingFragment.this.m_nwifiId == this.nWifiId) {
                msg = DeviceNetworkSettingFragment.this.handler.obtainMessage();
                msg.arg1 = 32;
                msg.arg2 = LocalDefines.WIFI_SEARCH_RESULT_CODE_FAIL_NET_POOL;
                DeviceNetworkSettingFragment.this.handler.sendMessage(msg);
            }
        }
    }

    public DeviceNetworkSettingFragment(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public NetwordInfo getmNetworkConfig() {
        if (this.isGetFinish) {
            return this.mNetworkConfig;
        }
        return null;
    }

    public void setmNetworkConfig(NetwordInfo networkConfig) {
        if (networkConfig != null) {
            this.mNetworkConfig.setnMode(networkConfig.getnMode());
            this.mNetworkConfig.setStrApName(networkConfig.getStrApName());
            this.mNetworkConfig.setStrApPassword(networkConfig.getStrApPassword());
            this.mNetworkConfig.setbWifiSet(networkConfig.isbWifiSet());
            this.mNetworkConfig.setStrWifiName(networkConfig.getStrWifiName());
            this.mNetworkConfig.setStrWifiPassword(networkConfig.getStrWifiPassword());
        }
    }

    public boolean isGetFinish() {
        return this.isGetFinish;
    }

    public void setServerInfo(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public void setNeedFreshInterface(boolean bNeedFresh) {
        this.mIsNeedFresh = bNeedFresh;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_network_config, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        InitSubView();
        return v;
    }

    public void onStop() {
        super.onStop();
        this.relateAtivity = null;
        this.isActive = false;
    }

    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.relateAtivity = getActivity();
        this.isActive = true;
    }

    private void InitSubView() {
        createLoadingDialog();
        this.btnNetworkBack = (ImageView) this.contentView.findViewById(C0470R.id.btnNetworkBack);
        this.btnNetworkBack.setOnClickListener(this);
        this.btnNetworkSave = (Button) this.contentView.findViewById(C0470R.id.btnNetworkSave);
        this.btnNetworkSave.setOnClickListener(this);
        this.btnNetworkSave.setEnabled(false);
        this.btnNetworkSave.setVisibility(8);
        this.llWifi = (LinearLayout) this.contentView.findViewById(C0470R.id.llWifi);
        this.tvUsingWifiMode = (TextView) this.contentView.findViewById(C0470R.id.tvUsingWifiMode);
        this.etWifiAPname = (EditText) this.contentView.findViewById(C0470R.id.etWifiAPname);
        this.etWifiAPPassword = (EditText) this.contentView.findViewById(C0470R.id.etWifiAPPassword);
        this.etWifiStationName = (EditText) this.contentView.findViewById(C0470R.id.etWifiStationname);
        this.etWifiStationPassword = (EditText) this.contentView.findViewById(C0470R.id.etWifiStationPassword);
        this.cbModifyAP = (LinearLayout) this.contentView.findViewById(C0470R.id.cbModifyAP);
        this.cbModifyAP.setOnClickListener(this);
        this.cbModifyStation = (LinearLayout) this.contentView.findViewById(C0470R.id.cbModifyStation);
        this.cbModifyStation.setOnClickListener(this);
        this.cbModifyAPCheckBox = (ImageView) this.contentView.findViewById(C0470R.id.cbModifyAPCheckbox);
        this.cbModifyStationCheckBox = (ImageView) this.contentView.findViewById(C0470R.id.cbModifyStationCheckbox);
        this.layoutLocalWifiList = (LinearLayout) this.contentView.findViewById(C0470R.id.localWifiList);
        this.layoutLocalWifiList.setVisibility(8);
        this.svWifiListView = (ScrollView) this.contentView.findViewById(C0470R.id.svWifiListView);
        this.wifiDeviceListView = (InnerListView) this.contentView.findViewById(C0470R.id.lvWifiDevicesList);
        this.wifiDeviceListView.setParentScrollView(this.svWifiListView);
        this.progressBarWifiSearching = (ProgressBar) this.contentView.findViewById(C0470R.id.progressBarWifiSearching);
        this.wifiDeviceListView.setAdapter(null);
        this.progressBarWifiSearching.setVisibility(8);
        this.wifiDeviceListView.setEnabled(true);
        this.wifiDeviceListView.setOnItemClickListener(this);
        this.btnWifiDevRefresh = (Button) this.contentView.findViewById(C0470R.id.btnWifiListRefresh);
        this.btnWifiDevRefresh.setOnClickListener(this);
        this.cbModifyAP.setClickable(false);
        this.cbModifyStation.setClickable(false);
        this.cbModifyAPCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
        this.cbModifyStationCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
        this.m_bAPModify = false;
        this.m_bStationModify = false;
        this.contentView.findViewById(C0470R.id.tablelayoutStationSetting).setVisibility(8);
        this.contentView.findViewById(C0470R.id.tablelayoutAPSetting).setVisibility(8);
        this.apCheckBoxPwdHiden = (ImageView) this.contentView.findViewById(C0470R.id.apCheckBoxPwdHiden);
        this.apCheckBoxPwdHiden.setOnClickListener(new C03252());
        this.stationCheckBoxPwdHiden = (ImageView) this.contentView.findViewById(C0470R.id.stationCheckBoxPwdHiden);
        this.stationCheckBoxPwdHiden.setOnClickListener(new C03263());
        if (this.bHidenPassword) {
            this.etWifiAPPassword.setInputType(Defines.NV_IP_PTZX_REQUEST);
            this.etWifiStationPassword.setInputType(Defines.NV_IP_PTZX_REQUEST);
        } else {
            this.etWifiAPPassword.setInputType(144);
            this.etWifiStationPassword.setInputType(144);
        }
        if (this.mServerInfo == null || !this.mIsNeedFresh) {
            initUI();
        } else {
            getNetworkConfig(this.mServerInfo);
        }
    }

    private void initUI() {
        if (this.mNetworkConfig != null && this.mServerInfo != null) {
            this.isGetFinish = true;
            this.loadingDialog.dismiss();
            this.contentView.findViewById(C0470R.id.layoutNetworkConfigPanel).setEnabled(true);
            this.btnNetworkSave.setEnabled(true);
            this.btnNetworkSave.setVisibility(0);
            this.cbModifyAP.setEnabled(true);
            this.cbModifyStation.setEnabled(true);
            this.cbModifyAP.setClickable(true);
            this.cbModifyStation.setClickable(true);
            if (this.mNetworkConfig.getnDeviceVersion() > 0) {
                if (this.mNetworkConfig.getnMode() == 0) {
                    this.tvUsingWifiMode.setText(getString(C0470R.string.wifi_current_mode) + "UNKNOW");
                    onWifiModeChange(0);
                } else if (this.mNetworkConfig.getnMode() == 1001) {
                    this.tvUsingWifiMode.setText(getString(C0470R.string.wifi_current_mode) + "AP");
                    onWifiModeChange(1001);
                } else if (this.mNetworkConfig.getnMode() == 1002) {
                    this.tvUsingWifiMode.setText(getString(C0470R.string.wifi_current_mode) + "STATION");
                    onWifiModeChange(1002);
                }
                if (this.mNetworkConfig.isbWifiSet()) {
                    this.etWifiStationName.setText(this.mNetworkConfig.getStrWifiName());
                    this.etWifiStationPassword.setText(this.mNetworkConfig.getStrWifiPassword());
                } else {
                    this.etWifiStationName.setText(Constants.MAIN_VERSION_TAG);
                    this.etWifiStationPassword.setText(Constants.MAIN_VERSION_TAG);
                }
                this.etWifiAPname.setText(this.mNetworkConfig.getStrApName());
                this.etWifiAPPassword.setText(this.mNetworkConfig.getStrApPassword());
                return;
            }
            if (this.mNetworkConfig.getnMode() == 0) {
                this.tvUsingWifiMode.setText(getString(C0470R.string.wifi_current_mode) + "UNKNOW");
            } else if (this.mNetworkConfig.getnMode() == 1001) {
                this.tvUsingWifiMode.setText(getString(C0470R.string.wifi_current_mode) + "AP");
            } else if (this.mNetworkConfig.getnMode() == 1002) {
                this.tvUsingWifiMode.setText(getString(C0470R.string.wifi_current_mode) + "STATION");
            }
            if (this.mNetworkConfig.isbWifiSet()) {
                this.etWifiStationName.setText(this.mNetworkConfig.getStrWifiName());
                this.etWifiStationPassword.setText(this.mNetworkConfig.getStrWifiPassword());
            } else {
                this.etWifiStationName.setText(Constants.MAIN_VERSION_TAG);
                this.etWifiStationPassword.setText(Constants.MAIN_VERSION_TAG);
            }
            this.etWifiAPname.setText(this.mNetworkConfig.getStrApName());
            this.etWifiAPPassword.setText(this.mNetworkConfig.getStrApPassword());
            this.m_bAPModify = false;
            this.m_bStationModify = false;
            onWifiModeChange(1003);
        }
    }

    public void ShowAlert(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowAlert(title, msg);
        }
    }

    public void onClick(View v) {
        boolean z = false;
        switch (v.getId()) {
            case C0470R.id.btnNetworkBack:
                this.isGetFinish = false;
                ShowConfigSetting();
                return;
            case C0470R.id.cbModifyAP:
                this.llWifi.setVisibility(0);
                if (this.mNetworkConfig.getnDeviceVersion() > 0) {
                    onWifiModeChange(1001);
                    return;
                }
                if (!this.m_bAPModify) {
                    z = true;
                }
                this.m_bAPModify = z;
                onWifiModeChange(1003);
                return;
            case C0470R.id.cbModifyStation:
                this.llWifi.setVisibility(8);
                if (this.mNetworkConfig.getnDeviceVersion() > 0) {
                    onWifiModeChange(1002);
                    return;
                }
                if (!this.m_bStationModify) {
                    z = true;
                }
                this.m_bStationModify = z;
                onWifiModeChange(1003);
                return;
            case C0470R.id.btnWifiListRefresh:
                if (this.progressBarWifiSearching.getVisibility() != 0 && this.mServerInfo != null) {
                    if (this.mIsSearchingWifiList) {
                        Log.i("TAG", "StopSearchWifi");
                        StopSearchWifi();
                    }
                    Log.i("TAG", "StartSearchWifi");
                    StartSearchWifi();
                    return;
                }
                return;
            case C0470R.id.btnNetworkSave:
                hindKeyboard();
                String strWifiName;
                String strWifiPassword;
                if (this.mNetworkConfig.getnDeviceVersion() > 0) {
                    if (this.m_nWifiMode == 1001) {
                        strWifiName = this.etWifiAPname.getText().toString();
                        if (strWifiName.length() <= 0) {
                            ShowAlert(Constants.MAIN_VERSION_TAG, getString(C0470R.string.alert_station_name_is_null));
                            return;
                        }
                        strWifiPassword = this.etWifiAPPassword.getText().toString();
                        if (strWifiPassword != null && strWifiPassword.length() > 0 && strWifiPassword.length() < 8) {
                            ShowAlert(Constants.MAIN_VERSION_TAG, getString(C0470R.string.notice_Result_PWD_ERR_AP));
                            return;
                        }
                    } else if (this.m_nWifiMode == 1002) {
                        strWifiName = this.etWifiStationName.getText().toString();
                        strWifiPassword = this.etWifiStationPassword.getText().toString();
                        if (strWifiName.length() <= 0) {
                            ShowAlert(Constants.MAIN_VERSION_TAG, getString(C0470R.string.alert_ap_name_is_null));
                            return;
                        }
                        strWifiPassword = this.etWifiStationPassword.getText().toString();
                        if (strWifiPassword != null && strWifiPassword.length() > 0 && strWifiPassword.length() < 8) {
                            ShowAlert(Constants.MAIN_VERSION_TAG, getString(C0470R.string.notice_Result_PWD_ERR_Station));
                            return;
                        } else if (this.isCrypt && strWifiPassword.length() <= 0) {
                            ShowAlert(Constants.MAIN_VERSION_TAG, getString(C0470R.string.alert_station_password_is_null));
                            return;
                        }
                    } else {
                        return;
                    }
                    if (this.mServerInfo != null) {
                        setNetworkConfigEx(this.mServerInfo, this.m_nWifiMode, strWifiName, strWifiPassword);
                        return;
                    }
                    return;
                }
                boolean bAPModify = this.m_bAPModify;
                boolean bStationModify = this.m_bStationModify;
                String strAPName = this.etWifiAPname.getText().toString();
                if (strAPName.length() <= 0) {
                    ShowAlert(Constants.MAIN_VERSION_TAG, getString(C0470R.string.alert_station_name_is_null));
                    return;
                }
                String strAPPassword = this.etWifiAPPassword.getText().toString();
                if (strAPPassword == null || strAPPassword.length() <= 0 || strAPPassword.length() >= 8) {
                    if (this.mNetworkConfig.getStrApName() != null && this.mNetworkConfig.getStrApName().compareTo(strAPName) == 0 && this.mNetworkConfig.getStrApPassword().compareTo(strAPPassword) == 0) {
                        bAPModify = false;
                    }
                    strWifiName = this.etWifiStationName.getText().toString();
                    strWifiPassword = this.etWifiStationPassword.getText().toString();
                    if (strWifiPassword == null || strWifiPassword.length() <= 0 || strWifiPassword.length() >= 8) {
                        if (this.mNetworkConfig.getStrWifiName() == null || this.mNetworkConfig.getStrWifiPassword() == null) {
                            if (this.mNetworkConfig.getStrWifiName() == null) {
                                if (strWifiName == null || strWifiName.length() == 0) {
                                    bStationModify = false;
                                }
                            } else if (this.mNetworkConfig.getStrWifiName().compareTo(strWifiName) == 0 && (strWifiPassword == null || strWifiPassword.length() == 0)) {
                                bStationModify = false;
                            }
                        } else if (this.mNetworkConfig.getStrWifiName().compareTo(strWifiName) == 0 && this.mNetworkConfig.getStrWifiPassword().compareTo(strWifiPassword) == 0) {
                            bStationModify = false;
                        }
                        if (bStationModify && this.isCrypt && strWifiPassword.length() <= 0) {
                            ShowAlert(Constants.MAIN_VERSION_TAG, getString(C0470R.string.alert_station_password_is_null));
                            return;
                        } else if (this.mServerInfo != null) {
                            setNetworkConfig(this.mServerInfo, bAPModify, strAPName, strAPPassword, bStationModify, strWifiName, strWifiPassword);
                            return;
                        } else {
                            return;
                        }
                    }
                    ShowAlert(Constants.MAIN_VERSION_TAG, getString(C0470R.string.notice_Result_PWD_ERR_Station));
                    return;
                }
                ShowAlert(Constants.MAIN_VERSION_TAG, getString(C0470R.string.notice_Result_PWD_ERR_AP));
                return;
            default:
                return;
        }
    }

    private void ShowConfigSetting() {
        if (this.mIsSearchingWifiList) {
            StopSearchWifi();
        }
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ChangeFragment(14, 13, this.mServerInfo);
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View arg1, int selectIndex, long arg3) {
        if (this.wifiList != null && selectIndex >= 0 && selectIndex < this.wifiList.size()) {
            WifiInfo info = (WifiInfo) this.wifiList.get(selectIndex);
            if (info == null) {
                Log.i("TAG", "wifiListInfo is null");
            }
            if (info != null) {
                Log.i("TAG", "wifiListInfo is not null" + info.getSsid());
                this.etWifiStationName.setText(info.getSsid());
                this.etWifiStationPassword.setText(null);
                if (info.getFlags() == 0) {
                    this.etWifiStationPassword.setEnabled(false);
                    this.etWifiStationPassword.setVisibility(8);
                    this.stationCheckBoxPwdHiden.setVisibility(8);
                    this.isCrypt = false;
                    return;
                }
                this.etWifiStationPassword.setVisibility(0);
                this.stationCheckBoxPwdHiden.setVisibility(0);
                this.etWifiStationPassword.setEnabled(true);
                this.isCrypt = true;
            }
        }
    }

    private void onWifiModeChange(int nMode) {
        hindKeyboard();
        if (this.mNetworkConfig.getnDeviceVersion() > 0) {
            this.m_nWifiMode = nMode;
            if (this.m_nWifiMode == 1001) {
                this.contentView.findViewById(C0470R.id.tablelayoutAPSetting).setVisibility(0);
                this.cbModifyAPCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_check));
                this.contentView.findViewById(C0470R.id.tablelayoutStationSetting).setVisibility(8);
                this.cbModifyStationCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
                this.layoutLocalWifiList.setVisibility(8);
                return;
            } else if (this.m_nWifiMode == 1002) {
                this.contentView.findViewById(C0470R.id.tablelayoutAPSetting).setVisibility(8);
                this.cbModifyAPCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
                this.contentView.findViewById(C0470R.id.tablelayoutStationSetting).setVisibility(0);
                this.cbModifyStationCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_check));
                this.etWifiStationPassword.setText(null);
                this.layoutLocalWifiList.setVisibility(0);
                if (this.mServerInfo != null) {
                    StartSearchWifi();
                    return;
                }
                return;
            } else {
                this.layoutLocalWifiList.setVisibility(8);
                this.contentView.findViewById(C0470R.id.tablelayoutAPSetting).setVisibility(8);
                this.cbModifyAPCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
                return;
            }
        }
        if (this.m_bAPModify) {
            this.contentView.findViewById(C0470R.id.tablelayoutAPSetting).setVisibility(0);
            this.cbModifyAPCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_check));
        } else {
            this.contentView.findViewById(C0470R.id.tablelayoutAPSetting).setVisibility(8);
            this.cbModifyAPCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
        }
        if (this.m_bStationModify) {
            this.contentView.findViewById(C0470R.id.tablelayoutStationSetting).setVisibility(0);
            this.cbModifyStationCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_check));
            this.layoutLocalWifiList.setVisibility(0);
            if (this.mServerInfo != null) {
                StartSearchWifi();
            }
            this.layoutLocalWifiList.setVisibility(0);
            return;
        }
        this.contentView.findViewById(C0470R.id.tablelayoutStationSetting).setVisibility(8);
        this.cbModifyStationCheckBox.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
        this.layoutLocalWifiList.setVisibility(8);
    }

    public void hindKeyboard() {
        if (this.relateAtivity != null) {
            try {
                InputMethodManager imm = (InputMethodManager) this.relateAtivity.getSystemService("input_method");
                if (imm != null) {
                    imm.hideSoftInputFromWindow(this.relateAtivity.getCurrentFocus().getWindowToken(), 2);
                }
            } catch (Exception e) {
            }
        }
    }

    public boolean checkAccountSame(int nID, String strUsername, String strPassword) {
        if (this.nID != nID) {
            return false;
        }
        if (this.strSaveUsername == null && strUsername != null) {
            return false;
        }
        if (this.strSavePassword == null && strPassword != null) {
            return false;
        }
        if (this.strSaveUsername.equals(strUsername) && this.strSavePassword.equals(strPassword)) {
            return true;
        }
        return false;
    }

    private void getNetworkConfig(DeviceInfo info) {
        if (info != null) {
            this.mLoadType = 1;
            this.loadingDialog.show();
            this.contentView.findViewById(C0470R.id.layoutNetworkConfigPanel).setEnabled(false);
            this.isGetFinish = false;
            onWifiModeChange(0);
            new NetWorkConfigThread().start();
        }
    }

    private void setNetworkConfig(DeviceInfo info, boolean bAPModify, String strAPName, String strAPPassword, boolean bStationModify, String strWifiName, String strWifiPassword) {
        if (info != null) {
            this.mLoadType = 2;
            this.loadingDialog.show();
            this.contentView.findViewById(C0470R.id.layoutNetworkConfigPanel).setEnabled(false);
            new NetWorkConfigThread(bAPModify, strAPName, strAPPassword, bStationModify, strWifiName, strWifiPassword).start();
        }
    }

    private void setNetworkConfigEx(DeviceInfo info, int nMode, String strWifiName, String strWifiPassword) {
        if (info != null) {
            this.mLoadType = 2;
            this.loadingDialog.show();
            this.contentView.findViewById(C0470R.id.layoutNetworkConfigPanel).setEnabled(false);
            new NetWorkConfigThread(nMode, strWifiName, strWifiPassword).start();
        }
    }

    public boolean StartSearchWifi() {
        this.wifiList.clear();
        this.progressBarWifiSearching.setVisibility(0);
        this.mIsSearchingWifiList = true;
        this.wifiDeviceListView.setEnabled(false);
        this.m_nwifiId++;
        new WifiSearcher(this.m_nwifiId).start();
        return true;
    }

    public boolean StopSearchWifi() {
        this.mIsSearchingWifiList = false;
        this.m_nwifiId++;
        this.progressBarWifiSearching.setVisibility(8);
        this.wifiDeviceListView.setEnabled(true);
        return true;
    }

    public void refleshWifiListView() {
        if (this.wifiList != null) {
            ArrayList<HashMap<String, Object>> listItem = new ArrayList();
            for (int i = 0; i < this.wifiList.size(); i++) {
                WifiInfo info = (WifiInfo) this.wifiList.get(i);
                HashMap<String, Object> map = new HashMap();
                map.put("WifiInfo", info);
                listItem.add(map);
            }
            WifiListViewAdapter listItemAdapter = new WifiListViewAdapter(this.relateAtivity, listItem, C0470R.layout.wifi_list_item, new String[]{"ItemImgFace", "ItemTitleName", "ItemTitleDesc", "ItemImgSignal"}, new int[]{C0470R.id.WifiItemFace, C0470R.id.WifiItemTitleName, C0470R.id.WifiItemTitleDesc, C0470R.id.WifiItemTitleSignal});
            if (this.wifiDeviceListView == null) {
                this.wifiDeviceListView = (InnerListView) this.contentView.findViewById(C0470R.id.lvWifiDevicesList);
                this.wifiDeviceListView.setParentScrollView(this.svWifiListView);
            }
            if (this.wifiDeviceListView != null) {
                int padding_in_px = (int) ((((float) Defines.NV_IPC_WIFI_SEARCH_RESPONSE) * getResources().getDisplayMetrics().density) + 0.5f);
                this.wifiDeviceListView.setCacheColorHint(0);
                this.wifiDeviceListView.setAdapter(listItemAdapter);
                this.wifiDeviceListView.setParentScrollView(this.svWifiListView);
                this.wifiDeviceListView.setMaxHeight(padding_in_px);
                return;
            }
            return;
        }
        if (this.wifiDeviceListView == null) {
            this.wifiDeviceListView = (InnerListView) this.contentView.findViewById(C0470R.id.lvWifiDevicesList);
        }
        if (this.wifiDeviceListView != null) {
            this.wifiDeviceListView.setAdapter(null);
        }
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C03274());
        this.loadingDialog.setOnDismissListener(new C03285());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }
}
