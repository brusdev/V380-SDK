package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.setting.DateTimeInfo;
import com.macrovideo.sdk.setting.DeviceDateTimeSetting;
import com.tencent.android.tpush.common.Constants;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@SuppressLint({"ValidFragment"})
public class DeviceDateTimeSettingFragment extends Fragment implements OnClickListener {
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    private static List<String> timeZoneList = new ArrayList();
    private ImageView btnDatetimeBack;
    private Button btnDatetimeCancel;
    private Button btnDatetimeOK;
    private Button btnDatetimeSave;
    private Button btnOneKeySync;
    private View contentView = null;
    private DatePicker datePicker = null;
    private View datetimeConfigConctentView = null;
    private Dialog datetimeSelectedConfigDialog;
    private Handler handler = new C03001();
    private IntentFilter intentFilter;
    private boolean isActive = false;
    private boolean isGetFinish = false;
    private boolean isTimeZoneEnable = false;
    private ImageView ivListTimeZone;
    private ListAdapter listAdapter;
    private LinearLayout llDateTime;
    private LinearLayout llTimeZone;
    private Dialog loadingDialog;
    private View loadingView;
    private ListView lvTimeZone;
    private boolean mIsNeedFresh = true;
    private int mLoadType = 1;
    private DeviceInfo mServerInfo = null;
    private String mStrTime = "1970-01-01 00:00:00";
    private int mTimeZoneIndex = 20;
    private int m_nDateTimeSettingType = 0;
    private TabBroadcastReceiver receiver;
    private Activity relateAtivity = null;
    private TimePicker timePicker = null;
    private TableRow trDateSetting;
    private TableRow trTimeSetting;
    private TableRow trTimeZone;
    private TextView tvDate = null;
    private TextView tvDateTimeSelect = null;
    private TextView tvDatetimeNotice = null;
    private TextView tvTime = null;
    private TextView tvTimeZone;

    class C03001 extends Handler {
        C03001() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            if (DeviceDateTimeSettingFragment.this.isActive) {
                DeviceDateTimeSettingFragment.this.mIsNeedFresh = false;
                DateTimeInfo dateTimeHandler;
                if (msg.arg1 == 128) {
                    DeviceDateTimeSettingFragment.this.loadingDialog.dismiss();
                    DeviceDateTimeSettingFragment.this.btnDatetimeSave.setEnabled(true);
                    DeviceDateTimeSettingFragment.this.contentView.findViewById(C0470R.id.layoutDateTimeConfigPanel).setEnabled(true);
                    DeviceDateTimeSettingFragment.this.mStrTime = "1970-01-01 00:00:00";
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_NetError));
                            return;
                        case 256:
                            DeviceDateTimeSettingFragment.this.btnDatetimeSave.setEnabled(true);
                            dateTimeHandler = (DateTimeInfo) msg.getData().get(Defines.RECORD_FILE_RETURN_MESSAGE);
                            if (dateTimeHandler != null) {
                                DeviceDateTimeSettingFragment.this.mStrTime = dateTimeHandler.getStrTime();
                            }
                            DeviceDateTimeSettingFragment.this.initUI();
                            DeviceDateTimeSettingFragment.this.onSaveAndBack(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_ok), Constants.MAIN_VERSION_TAG);
                            return;
                        default:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            return;
                    }
                } else if (msg.arg1 == 112) {
                    DeviceDateTimeSettingFragment.this.loadingDialog.dismiss();
                    DeviceDateTimeSettingFragment.this.btnDatetimeSave.setEnabled(true);
                    DeviceDateTimeSettingFragment.this.mStrTime = "1970-01-01 00:00:00";
                    DeviceDateTimeSettingFragment.this.btnDatetimeSave.setEnabled(false);
                    DeviceDateTimeSettingFragment.this.btnOneKeySync.setEnabled(false);
                    DeviceDateTimeSettingFragment.this.tvDatetimeNotice.setText(DeviceDateTimeSettingFragment.this.getString(C0470R.string.getting_datetime_config_fail));
                    DeviceDateTimeSettingFragment.this.contentView.findViewById(C0470R.id.layoutDateTimeConfigPanel).setEnabled(false);
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            DeviceDateTimeSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            DeviceDateTimeSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            DeviceDateTimeSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            DeviceDateTimeSettingFragment.this.ShowConfigSetting();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_NetError));
                            DeviceDateTimeSettingFragment.this.ShowConfigSetting();
                            return;
                        case 256:
                            DeviceDateTimeSettingFragment.this.btnDatetimeSave.setEnabled(true);
                            DeviceDateTimeSettingFragment.this.btnOneKeySync.setEnabled(true);
                            DeviceDateTimeSettingFragment.this.contentView.findViewById(C0470R.id.layoutDateTimeConfigPanel).setEnabled(true);
                            Bundle data = msg.getData();
                            if (data == null) {
                                DeviceDateTimeSettingFragment.this.ShowAlert(Constants.MAIN_VERSION_TAG, DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_BadResult));
                                return;
                            }
                            DeviceDateTimeSettingFragment.this.isGetFinish = true;
                            dateTimeHandler = (DateTimeInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                            if (dateTimeHandler != null) {
                                DeviceDateTimeSettingFragment.this.mStrTime = dateTimeHandler.getStrTime();
                                DeviceDateTimeSettingFragment.this.isTimeZoneEnable = dateTimeHandler.isTimeZoneEnable();
                                DeviceDateTimeSettingFragment.this.mTimeZoneIndex = dateTimeHandler.getnTimeZoneIndex() + 12;
                                Log.w("mTimeZoneIndex=", DeviceDateTimeSettingFragment.this.mTimeZoneIndex);
                            }
                            DeviceDateTimeSettingFragment.this.initUI();
                            return;
                        default:
                            DeviceDateTimeSettingFragment.this.ShowAlert(DeviceDateTimeSettingFragment.this.getString(C0470R.string.alert_get_config_fail), DeviceDateTimeSettingFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            DeviceDateTimeSettingFragment.this.ShowConfigSetting();
                            return;
                    }
                }
            }
        }
    }

    class C03012 implements OnShowListener {
        C03012() {
        }

        public void onShow(DialogInterface dialog) {
            DeviceDateTimeSettingFragment.this.onDateTimeSelectConfigDialogShow();
        }
    }

    class C03023 implements OnClickListener {
        C03023() {
        }

        public void onClick(View arg0) {
            DeviceDateTimeSettingFragment.this.datetimeSelectedConfigDialog.dismiss();
        }
    }

    class C03034 implements OnItemClickListener {
        C03034() {
        }

        public void onItemClick(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
            DeviceDateTimeSettingFragment.this.tvTimeZone.setText(new StringBuilder(String.valueOf((String) DeviceDateTimeSettingFragment.timeZoneList.get(arg2))).toString());
            DeviceDateTimeSettingFragment.this.mTimeZoneIndex = arg2;
            DeviceDateTimeSettingFragment.this.datetimeSelectedConfigDialog.dismiss();
        }
    }

    class C03045 implements OnDateChangedListener {
        C03045() {
        }

        public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        }
    }

    class C03056 implements OnTimeChangedListener {
        C03056() {
        }

        public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
        }
    }

    class C03067 implements OnShowListener {
        C03067() {
        }

        public void onShow(DialogInterface dialog) {
            TextView tv = (TextView) DeviceDateTimeSettingFragment.this.loadingView.findViewById(C0470R.id.loginText);
            if (DeviceDateTimeSettingFragment.this.mLoadType == 1) {
                tv.setText(DeviceDateTimeSettingFragment.this.getString(C0470R.string.loading));
            } else if (DeviceDateTimeSettingFragment.this.mLoadType == 2) {
                tv.setText(DeviceDateTimeSettingFragment.this.getString(C0470R.string.str_saving));
            }
        }
    }

    class C03078 implements OnDismissListener {
        C03078() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    private class DateTimeConfigThread extends Thread {
        static final int OP_TYPE_GET = 10;
        static final int OP_TYPE_SET = 11;
        DeviceInfo info;
        int m_nTimeType;
        String m_strTime;
        private int nOPType;

        public DateTimeConfigThread(DeviceInfo info) {
            this.m_nTimeType = 0;
            this.m_strTime = null;
            this.nOPType = 10;
            this.nOPType = 10;
            this.info = info;
        }

        public DateTimeConfigThread(int nTimeType, String strTime, DeviceInfo info) {
            this.m_nTimeType = 0;
            this.m_strTime = null;
            this.nOPType = 10;
            this.nOPType = 11;
            this.m_nTimeType = nTimeType;
            this.m_strTime = strTime;
            this.info = info;
        }

        public void run() {
            DateTimeInfo deviceParam;
            Message msg;
            if (this.nOPType == 10) {
                deviceParam = DeviceDateTimeSetting.getDateTime(this.info);
                if (deviceParam != null) {
                    Log.w("deviceParam ", deviceParam.getnTimeZoneIndex());
                    msg = DeviceDateTimeSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 112;
                    msg.arg2 = deviceParam.getnResult();
                    Bundle data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceDateTimeSettingFragment.this.handler.sendMessage(msg);
                }
            } else if (this.nOPType == 11) {
                int timeZone = DeviceDateTimeSettingFragment.this.mTimeZoneIndex - 12;
                Log.w("tt", DeviceDateTimeSettingFragment.this.isTimeZoneEnable + ", " + timeZone);
                deviceParam = DeviceDateTimeSetting.setDateTime(this.info, this.m_strTime, this.m_nTimeType, DeviceDateTimeSettingFragment.this.isTimeZoneEnable, timeZone);
                if (deviceParam != null) {
                    msg = DeviceDateTimeSettingFragment.this.handler.obtainMessage();
                    msg.arg1 = 128;
                    msg.arg2 = deviceParam.getnResult();
                    new Bundle().putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    DeviceDateTimeSettingFragment.this.handler.sendMessage(msg);
                }
            }
        }
    }

    class TabBroadcastReceiver extends BroadcastReceiver {
        TabBroadcastReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            intent.getAction().equals("TAB1_ACTION");
        }
    }

    public class listAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private ArrayList<String> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            TextView tvTimeZone;

            private ItemViewHolder() {
            }
        }

        public listAdapter(Context c, ArrayList<String> appList, int resource, String[] from, int[] to) {
            this.mAppList = appList;
            this.mContext = c;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int arg0) {
            return (long) arg0;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.time_zone_item, null);
                this.holder = new ItemViewHolder();
                this.holder.tvTimeZone = (TextView) convertView.findViewById(C0470R.id.tvTimeZone);
                convertView.setTag(this.holder);
            }
            this.holder.tvTimeZone.setText(((String) this.mAppList.get(position)).toString());
            return convertView;
        }
    }

    public DeviceDateTimeSettingFragment(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public boolean isGetFinish() {
        return this.isGetFinish;
    }

    public void setServerInfo(DeviceInfo serverInfo) {
        this.mServerInfo = serverInfo;
    }

    public void setNeedFreshInterface(boolean bNeedFresh) {
        this.mIsNeedFresh = bNeedFresh;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_datetime_config, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        InitSubView();
        createDialogs();
        return v;
    }

    public void onStop() {
        super.onStop();
        this.relateAtivity = null;
        this.isActive = false;
    }

    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(this.receiver);
    }

    public void onResume() {
        super.onResume();
        this.receiver = new TabBroadcastReceiver();
        getActivity().registerReceiver(this.receiver, getIntentFilter());
        this.relateAtivity = getActivity();
        this.isActive = true;
    }

    private void createDialogs() {
        this.datetimeConfigConctentView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.activity_nvplayer_datetime_select, null);
        this.datetimeSelectedConfigDialog = new Dialog(this.relateAtivity, C0470R.style.dialog_bg_transparent);
        this.datetimeSelectedConfigDialog.setContentView(this.datetimeConfigConctentView);
        this.datetimeSelectedConfigDialog.setOnShowListener(new C03012());
    }

    public void onDateTimeSelectConfigDialogShow() {
        this.btnDatetimeOK = (Button) this.datetimeConfigConctentView.findViewById(C0470R.id.btnDatetimeOK);
        this.btnDatetimeOK.setOnClickListener(this);
        this.btnDatetimeCancel = (Button) this.datetimeConfigConctentView.findViewById(C0470R.id.btnDatetimeCancel);
        this.btnDatetimeCancel.setOnClickListener(this);
        this.ivListTimeZone = (ImageView) this.datetimeConfigConctentView.findViewById(C0470R.id.ivListTimeZone);
        this.llDateTime = (LinearLayout) this.datetimeConfigConctentView.findViewById(C0470R.id.llDateTime);
        this.llTimeZone = (LinearLayout) this.datetimeConfigConctentView.findViewById(C0470R.id.llTimeZone);
        this.lvTimeZone = (ListView) this.datetimeConfigConctentView.findViewById(C0470R.id.lvTimeZone);
        this.ivListTimeZone.setOnClickListener(new C03023());
        this.lvTimeZone.setOnItemClickListener(new C03034());
        this.tvDateTimeSelect = (TextView) this.datetimeConfigConctentView.findViewById(C0470R.id.tvDateTimeSelect);
        this.datePicker = (DatePicker) this.datetimeConfigConctentView.findViewById(C0470R.id.mDatePicker);
        this.timePicker = (TimePicker) this.datetimeConfigConctentView.findViewById(C0470R.id.mTimePicker);
        Calendar calendar = Calendar.getInstance();
        this.datePicker.init(calendar.get(1), calendar.get(2), calendar.get(5), new C03045());
        this.timePicker.setIs24HourView(Boolean.valueOf(true));
        this.timePicker.setCurrentMinute(Integer.valueOf(calendar.get(12)));
        this.timePicker.setCurrentHour(Integer.valueOf(calendar.get(11)));
        this.timePicker.setOnTimeChangedListener(new C03056());
        if (this.m_nDateTimeSettingType == 1) {
            this.llTimeZone.setVisibility(8);
            this.llDateTime.setVisibility(0);
            this.datePicker.setVisibility(0);
            this.tvDateTimeSelect.setText(getString(C0470R.string.date_current2));
            this.timePicker.setVisibility(8);
        } else if (this.m_nDateTimeSettingType == 2) {
            this.llTimeZone.setVisibility(8);
            this.llDateTime.setVisibility(0);
            this.datePicker.setVisibility(8);
            this.timePicker.setVisibility(0);
            this.tvDateTimeSelect.setText(getString(C0470R.string.time_current2));
            this.timePicker.setIs24HourView(Boolean.valueOf(true));
        } else if (this.m_nDateTimeSettingType == 3) {
            this.datePicker.setVisibility(8);
            this.timePicker.setVisibility(8);
            this.llDateTime.setVisibility(8);
            this.llTimeZone.setVisibility(0);
            listTimeZone();
        }
    }

    private void initTimeZoneList() {
        timeZoneList.clear();
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW12));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW11));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW10));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW9));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW8));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW7));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW6));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW5));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW4));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW3));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW2));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneW1));
        timeZoneList.add(getString(C0470R.string.lblTimeZoneZero));
        timeZoneList.add(getString(C0470R.string.lblTimeE1));
        timeZoneList.add(getString(C0470R.string.lblTimeE2));
        timeZoneList.add(getString(C0470R.string.lblTimeE3));
        timeZoneList.add(getString(C0470R.string.lblTimeE4));
        timeZoneList.add(getString(C0470R.string.lblTimeE5));
        timeZoneList.add(getString(C0470R.string.lblTimeE6));
        timeZoneList.add(getString(C0470R.string.lblTimeE7));
        timeZoneList.add(getString(C0470R.string.lblTimeE8));
        timeZoneList.add(getString(C0470R.string.lblTimeE9));
        timeZoneList.add(getString(C0470R.string.lblTimeE10));
        timeZoneList.add(getString(C0470R.string.lblTimeE11));
        timeZoneList.add(getString(C0470R.string.lblTimeE12));
    }

    private IntentFilter getIntentFilter() {
        if (this.intentFilter == null) {
            this.intentFilter = new IntentFilter();
            this.intentFilter.addAction("TAB1_ACTION");
        }
        return this.intentFilter;
    }

    private void InitSubView() {
        createLoadingDialog();
        this.btnDatetimeBack = (ImageView) this.contentView.findViewById(C0470R.id.btnDateTimeConfigBack);
        this.btnDatetimeBack.setOnClickListener(this);
        this.btnDatetimeSave = (Button) this.contentView.findViewById(C0470R.id.btnDateTimeConfigSave);
        this.btnDatetimeSave.setOnClickListener(this);
        this.btnDatetimeSave.setEnabled(false);
        this.btnOneKeySync = (Button) this.contentView.findViewById(C0470R.id.btnOneKeySync);
        this.btnOneKeySync.setOnClickListener(this);
        this.tvDatetimeNotice = (TextView) this.contentView.findViewById(C0470R.id.tvDateTimeNotice);
        this.trDateSetting = (TableRow) this.contentView.findViewById(C0470R.id.trDateSetting);
        this.trDateSetting.setOnClickListener(this);
        this.trTimeSetting = (TableRow) this.contentView.findViewById(C0470R.id.trTimeSetting);
        this.trTimeSetting.setOnClickListener(this);
        this.tvDate = (TextView) this.contentView.findViewById(C0470R.id.tvDate);
        this.tvTime = (TextView) this.contentView.findViewById(C0470R.id.tvTime);
        this.lvTimeZone = (ListView) this.contentView.findViewById(C0470R.id.lvTimeZone);
        this.trTimeZone = (TableRow) this.contentView.findViewById(C0470R.id.trTimeZone);
        this.trTimeZone.setOnClickListener(this);
        this.tvTimeZone = (TextView) this.contentView.findViewById(C0470R.id.tvTimeZone);
        this.tvTimeZone.setText(getString(C0470R.string.lblTimeE8));
        Calendar calendar = Calendar.getInstance();
        if (calendar.get(2) < 9 && calendar.get(5) < 10) {
            this.tvDate.setText(calendar.get(1) + "-0" + (calendar.get(2) + 1) + "-0" + calendar.get(5));
        } else if (calendar.get(2) >= 9 && calendar.get(5) < 10) {
            this.tvDate.setText(calendar.get(1) + "-" + (calendar.get(2) + 1) + "-0" + calendar.get(5));
        } else if (calendar.get(2) >= 9 || calendar.get(5) < 10) {
            this.tvDate.setText(calendar.get(1) + "-" + (calendar.get(2) + 1) + "-" + calendar.get(5));
        } else {
            this.tvDate.setText(calendar.get(1) + "-0" + (calendar.get(2) + 1) + "-" + calendar.get(5));
        }
        if (calendar.get(11) < 10 && calendar.get(12) < 10) {
            this.tvTime.setText("0" + this.timePicker.getCurrentHour() + ":0" + calendar.get(12));
        } else if (calendar.get(11) >= 10 && calendar.get(12) < 10) {
            this.tvTime.setText(calendar.get(11) + ":0" + calendar.get(12));
        } else if (calendar.get(11) >= 10 || calendar.get(12) < 10) {
            this.tvTime.setText(calendar.get(11) + ":" + calendar.get(12));
        } else {
            this.tvTime.setText("0" + calendar.get(11) + ":" + calendar.get(12));
        }
        initTimeZoneList();
        if (this.mServerInfo == null || !this.mIsNeedFresh) {
            initUI();
        } else {
            getDateTimeConfig(this.mServerInfo);
        }
    }

    private void initUI() {
        this.tvDatetimeNotice.setText(this.mStrTime);
        if (this.mTimeZoneIndex >= 0 && this.mTimeZoneIndex < timeZoneList.size()) {
            this.tvTimeZone.setText(new StringBuilder(String.valueOf((String) timeZoneList.get(this.mTimeZoneIndex))).toString());
        }
    }

    public void hindKeyboard() {
        if (this.relateAtivity != null) {
            try {
                InputMethodManager imm = (InputMethodManager) this.relateAtivity.getSystemService("input_method");
                if (imm != null) {
                    imm.hideSoftInputFromWindow(this.relateAtivity.getCurrentFocus().getWindowToken(), 2);
                }
            } catch (Exception e) {
            }
        }
    }

    public void ShowAlert(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowAlert(title, msg);
        }
    }

    public void onSaveAndBack(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowNotic(title, msg);
            ShowConfigSetting();
        }
    }

    private void showDateTimeSelect(int nType) {
        this.m_nDateTimeSettingType = nType;
        if (this.datetimeSelectedConfigDialog != null) {
            this.datetimeSelectedConfigDialog.show();
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.btnDateTimeConfigBack:
                this.isGetFinish = false;
                ShowConfigSetting();
                return;
            case C0470R.id.trDateSetting:
                showDateTimeSelect(1);
                return;
            case C0470R.id.trTimeSetting:
                showDateTimeSelect(2);
                return;
            case C0470R.id.trTimeZone:
                showDateTimeSelect(3);
                return;
            case C0470R.id.btnOneKeySync:
                hindKeyboard();
                if (this.mServerInfo != null) {
                    setDateTimeConfig(this.mServerInfo, 0, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(System.currentTimeMillis())));
                    return;
                }
                return;
            case C0470R.id.btnDateTimeConfigSave:
                hindKeyboard();
                if (this.mServerInfo != null) {
                    setDateTimeConfig(this.mServerInfo, 0, new StringBuilder(String.valueOf(this.tvDate.getText().toString())).append(" ").append(this.tvTime.getText().toString()).append(":00").toString());
                    return;
                }
                return;
            case C0470R.id.btnDatetimeCancel:
                this.m_nDateTimeSettingType = 0;
                this.datetimeSelectedConfigDialog.dismiss();
                return;
            case C0470R.id.btnDatetimeOK:
                hindKeyboard();
                if (this.m_nDateTimeSettingType == 1) {
                    if (this.datePicker.getMonth() + 1 < 10 && this.datePicker.getDayOfMonth() < 10) {
                        this.tvDate.setText(this.datePicker.getYear() + "-0" + (this.datePicker.getMonth() + 1) + "-0" + this.datePicker.getDayOfMonth());
                    } else if (this.datePicker.getMonth() + 1 >= 10 && this.datePicker.getDayOfMonth() < 10) {
                        this.tvDate.setText(this.datePicker.getYear() + "-" + (this.datePicker.getMonth() + 1) + "-0" + this.datePicker.getDayOfMonth());
                    } else if (this.datePicker.getMonth() + 1 >= 10 || this.datePicker.getDayOfMonth() < 10) {
                        this.tvDate.setText(this.datePicker.getYear() + "-" + (this.datePicker.getMonth() + 1) + "-" + this.datePicker.getDayOfMonth());
                    } else {
                        this.tvDate.setText(this.datePicker.getYear() + "-0" + (this.datePicker.getMonth() + 1) + "-" + this.datePicker.getDayOfMonth());
                    }
                } else if (this.timePicker.getCurrentHour().intValue() < 10 && this.timePicker.getCurrentMinute().intValue() < 10) {
                    this.tvTime.setText("0" + this.timePicker.getCurrentHour() + ":0" + this.timePicker.getCurrentMinute());
                } else if (this.timePicker.getCurrentHour().intValue() >= 10 && this.timePicker.getCurrentMinute().intValue() < 10) {
                    this.tvTime.setText(this.timePicker.getCurrentHour() + ":0" + this.timePicker.getCurrentMinute());
                } else if (this.timePicker.getCurrentHour().intValue() >= 10 || this.timePicker.getCurrentMinute().intValue() < 10) {
                    this.tvTime.setText(this.timePicker.getCurrentHour() + ":" + this.timePicker.getCurrentMinute());
                } else {
                    this.tvTime.setText("0" + this.timePicker.getCurrentHour() + ":" + this.timePicker.getCurrentMinute());
                }
                this.datetimeSelectedConfigDialog.dismiss();
                return;
            default:
                return;
        }
    }

    private void ShowConfigSetting() {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ChangeFragment(16, 13, this.mServerInfo);
        }
    }

    private void getDateTimeConfig(DeviceInfo info) {
        if (info != null) {
            this.mLoadType = 1;
            this.loadingDialog.show();
            this.btnDatetimeSave.setEnabled(false);
            this.isGetFinish = false;
            new DateTimeConfigThread(info).start();
        }
    }

    private void setDateTimeConfig(DeviceInfo info, int nTimeType, String strTime) {
        if (info != null) {
            this.mLoadType = 2;
            this.loadingDialog.show();
            this.btnDatetimeSave.setEnabled(false);
            new DateTimeConfigThread(nTimeType, strTime, info).start();
        }
    }

    public void listTimeZone() {
        this.listAdapter = new listAdapter(this.relateAtivity, (ArrayList) timeZoneList, C0470R.layout.time_zone_item, new String[]{"item_list"}, new int[]{C0470R.id.tvTimeZone});
        if (timeZoneList.size() > 0) {
            this.lvTimeZone.setAdapter(this.listAdapter);
        }
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new C03067());
        this.loadingDialog.setOnDismissListener(new C03078());
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }
}
