package com.macrovideo.v380;

public class DialogTipCode {
    public static final int LOGIN_FAIL_USERNAME_OR_PASSWORD_INCORRECT = 10006;
    public static final int LOGIN_SUCCESS = 0;
    public static final int MAILBOX_ADDRESS_IS_NOT_STANDARDLIZED = 113;
    public static final int MAILBOX_IS_EMPTY = 112;
    public static final int MAILBOX_IS_NOT_STANDARDLIZED = 111;
    public static final int MOBILE_PHONE_IS_EXIST = 10004;
    public static final int PASSWORD_IS_EMPTY = 102;
    public static final int PASSWORD_IS_NOT_MATCH = 110;
    public static final int PASSWORD_IS_NOT_STANDARDLIZED = 109;
    public static final int PHONE_NO_IS_EMPTY = 103;
    public static final int PHONE_NUMBER_IS_NOT_STANDARDLIZED = 104;
    public static final int REGISTER_ERROR = 10006;
    public static final int REGISTER_SUCCESS = 0;
    public static final int RESETPWD_FAIL_PASSWORD_IS_NOT_STANDARDLIZED = 10006;
    public static final int RESETPWD_SUCCESS = 0;
    public static final int USERNAME_IS_EMPTY = 101;
    public static final int USERNAME_IS_NOT_STANDARDLIZED = 108;
    public static final int USER_IS_XISTENCE = 21003;
    public static final int USER_NOT_ACTIVATED = 21008;
    public static final int VERIFY_CODE_ERROR = 20001;
    public static final int VERIFY_CODE_IS_NOT_STANDARDLIZED = 107;
    public static final int VERIFY_CODE_IS_OVERTIME = 10002;
    public static final int VERIFY_CODE_OVERTIME = 20002;
}
