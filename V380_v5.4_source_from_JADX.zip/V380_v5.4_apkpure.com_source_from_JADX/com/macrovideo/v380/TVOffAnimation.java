package com.macrovideo.v380;

import android.graphics.Matrix;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import com.macrovideo.photo.PhotoViewAttacher;

public class TVOffAnimation extends Animation {
    private int centerX = 0;
    private int centerY = 0;

    public void initialize(int width, int height, int parentWidth, int parentHeight) {
        setDuration(300);
        this.centerX = width / 2;
        this.centerY = height / 2;
        setInterpolator(new AccelerateDecelerateInterpolator());
    }

    protected void applyTransformation(float interpolatedTime, Transformation t) {
        Matrix matrix = t.getMatrix();
        if (((double) interpolatedTime) < 0.8d) {
            matrix.preScale((0.625f * interpolatedTime) + PhotoViewAttacher.DEFAULT_MIN_SCALE, (PhotoViewAttacher.DEFAULT_MIN_SCALE - (1.25f * interpolatedTime)) + 0.01f, (float) this.centerX, (float) this.centerY);
        } else {
            matrix.preScale(7.5f * (PhotoViewAttacher.DEFAULT_MIN_SCALE - interpolatedTime), 0.01f, (float) this.centerX, (float) this.centerY);
        }
    }
}
