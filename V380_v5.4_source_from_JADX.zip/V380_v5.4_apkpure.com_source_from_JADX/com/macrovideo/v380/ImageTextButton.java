package com.macrovideo.v380;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ImageTextButton extends LinearLayout {
    private ImageView mImage;
    private TextView mText;

    public ImageTextButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mImage = new ImageView(context, attrs);
        this.mImage.setPadding(0, 0, 0, 0);
        this.mText = new TextView(context, attrs);
        this.mText.setGravity(1);
        this.mText.setPadding(0, 0, 0, 0);
        setClickable(true);
        setFocusable(true);
        setOrientation(0);
        addView(this.mImage);
        addView(this.mText);
    }

    public void setText(String text) {
        this.mText.setText(text);
    }

    public void setImage(Drawable image) {
        this.mImage.setBackgroundDrawable(image);
    }
}
