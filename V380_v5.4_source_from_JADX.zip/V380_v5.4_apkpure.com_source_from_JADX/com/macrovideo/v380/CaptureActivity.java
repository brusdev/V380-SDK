package com.macrovideo.v380;

import android.app.Activity;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.macrovideo.Zxing.Demo.camera.CameraManager;
import com.macrovideo.Zxing.Demo.decoding.CaptureActivityHandler;
import com.macrovideo.Zxing.Demo.decoding.InactivityTimer;
import com.macrovideo.Zxing.Demo.view.ViewfinderView;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.tencent.android.tpush.common.Constants;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

public class CaptureActivity extends Activity implements Callback {
    private static final float BEEP_VOLUME = 0.1f;
    public static String CALL_BACK = "info";
    private static final long VIBRATE_DURATION = 200;
    private final OnCompletionListener beepListener = new C02531();
    private String characterSet;
    private Vector<BarcodeFormat> decodeFormats;
    private CaptureActivityHandler handler;
    private boolean hasSurface;
    private InactivityTimer inactivityTimer;
    private ImageView ivBack;
    private MediaPlayer mediaPlayer;
    private boolean playBeep;
    private boolean vibrate;
    private ViewfinderView viewfinderView;

    class C02531 implements OnCompletionListener {
        C02531() {
        }

        public void onCompletion(MediaPlayer mediaPlayer) {
            mediaPlayer.seekTo(0);
        }
    }

    class C02542 implements OnClickListener {
        C02542() {
        }

        public void onClick(View v) {
            if (v.getId() == C0470R.id.ivBack) {
                CaptureActivity.this.finish();
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0470R.layout.qrdecode_cam_view);
        CameraManager.init(getApplication());
        this.viewfinderView = (ViewfinderView) findViewById(C0470R.id.viewfinder_view);
        this.hasSurface = false;
        this.inactivityTimer = new InactivityTimer(this);
        this.ivBack = (ImageView) findViewById(C0470R.id.ivBack);
        this.ivBack.setOnClickListener(new C02542());
    }

    protected void onResume() {
        super.onResume();
        SurfaceHolder surfaceHolder = ((SurfaceView) findViewById(C0470R.id.preview_view)).getHolder();
        if (this.hasSurface) {
            initCamera(surfaceHolder);
        } else {
            surfaceHolder.addCallback(this);
            surfaceHolder.setType(3);
        }
        this.decodeFormats = null;
        this.characterSet = null;
        this.playBeep = true;
        if (((AudioManager) getSystemService("audio")).getRingerMode() != 2) {
            this.playBeep = false;
        }
        initBeepSound();
        this.vibrate = true;
    }

    protected void onPause() {
        super.onPause();
        if (this.handler != null) {
            this.handler.quitSynchronously();
            this.handler = null;
        }
        CameraManager.get().closeDriver();
    }

    protected void onDestroy() {
        this.inactivityTimer.shutdown();
        super.onDestroy();
    }

    private void initCamera(SurfaceHolder surfaceHolder) {
        try {
            CameraManager.get().openDriver(surfaceHolder);
            if (this.handler == null) {
                this.handler = new CaptureActivityHandler(this, this.decodeFormats, this.characterSet);
            }
        } catch (IOException e) {
        } catch (RuntimeException e2) {
        }
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    public void surfaceCreated(SurfaceHolder holder) {
        if (!this.hasSurface) {
            this.hasSurface = true;
            initCamera(holder);
        }
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
        this.hasSurface = false;
    }

    public ViewfinderView getViewfinderView() {
        return this.viewfinderView;
    }

    public Handler getHandler() {
        return this.handler;
    }

    public void drawViewfinder() {
        this.viewfinderView.drawViewfinder();
    }

    private DeviceInfo parseResult(String strResult) {
        int nDevID = 0;
        String strName = Constants.MAIN_VERSION_TAG;
        String strIP = "192.168.1.1";
        String strUsername = "admin";
        String strPassword = Constants.MAIN_VERSION_TAG;
        if (strResult != null) {
            strResult = strResult.trim();
        }
        if (strResult.indexOf("QRRESULT^111") != 0) {
            return null;
        }
        boolean bIsOK = false;
        StringTokenizer st = new StringTokenizer(strResult, "^");
        int nTokenIndex = 0;
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            switch (nTokenIndex) {
                case 2:
                    nDevID = Integer.parseInt(token);
                    bIsOK = true;
                    strName = token;
                    break;
                default:
                    break;
            }
            nTokenIndex++;
        }
        if (bIsOK) {
            return new DeviceInfo(0, nDevID, strName, strIP, 8800, "admin", Constants.MAIN_VERSION_TAG, "0", new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_ADD);
        }
        return null;
    }

    public void handleDecode(Result obj, Bitmap barcode) {
        this.inactivityTimer.onActivity();
        playBeepSoundAndVibrate();
        String strResult = obj.getText();
        if (strResult == null || strResult.indexOf("QRRESULT^111") != 0) {
            LocalDefines._isQRResultOK = true;
            LocalDefines._nQRResultDevice = 0;
            Toast toast = Toast.makeText(this, getString(C0470R.string.QRcodeErrorDevice), 0);
            toast.setGravity(17, 0, 0);
            toast.show();
        } else {
            DeviceInfo info = parseResult(strResult);
            if (info != null) {
                LocalDefines._isQRResultOK = true;
                LocalDefines._nQRResultDevice = info.getnDevID();
            } else {
                LocalDefines._isQRResultOK = true;
                LocalDefines._nQRResultDevice = 0;
            }
        }
        finish();
        finish();
    }

    private void initBeepSound() {
        if (this.playBeep && this.mediaPlayer == null) {
            setVolumeControlStream(3);
            this.mediaPlayer = new MediaPlayer();
            this.mediaPlayer.setAudioStreamType(3);
            this.mediaPlayer.setOnCompletionListener(this.beepListener);
            AssetFileDescriptor file = getResources().openRawResourceFd(C0470R.raw.beep);
            try {
                this.mediaPlayer.setDataSource(file.getFileDescriptor(), file.getStartOffset(), file.getLength());
                file.close();
                this.mediaPlayer.setVolume(BEEP_VOLUME, BEEP_VOLUME);
                this.mediaPlayer.prepare();
            } catch (IOException e) {
                this.mediaPlayer = null;
            }
        }
    }

    private void playBeepSoundAndVibrate() {
        if (this.playBeep && this.mediaPlayer != null) {
            this.mediaPlayer.start();
        }
        if (this.vibrate) {
            ((Vibrator) getSystemService("vibrator")).vibrate(VIBRATE_DURATION);
        }
    }
}
