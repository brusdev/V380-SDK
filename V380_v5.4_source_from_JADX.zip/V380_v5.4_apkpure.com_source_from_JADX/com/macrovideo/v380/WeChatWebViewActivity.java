package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.aes.Aes;
import com.macrovideo.aes.DES3;
import com.tencent.android.tpush.SettingsContentProvider;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@SuppressLint({"SetJavaScriptEnabled"})
public class WeChatWebViewActivity extends Activity implements OnClickListener {
    public static String mAccesstoken;
    private String Aesdecode = "0";
    private WebView contentWebView = null;
    private TextView mBtnClose;
    private ProgressBar mProgressBar;
    private StringBuffer sb;
    private String url;

    class C04951 implements Runnable {
        C04951() {
        }

        public void run() {
            Toast.makeText(WeChatWebViewActivity.this, "show", 3000).show();
        }
    }

    class C04962 extends WebViewClient {
        C04962() {
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
        }
    }

    class C04973 extends WebChromeClient {
        C04973() {
        }

        public void onProgressChanged(WebView view, int newProgress) {
            if (newProgress == 100) {
                WeChatWebViewActivity.this.mProgressBar.setVisibility(8);
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_wechatpay_webview);
        Intent intent = getIntent();
        if (intent != null) {
            this.url = intent.getStringExtra("url");
        }
        setWebView();
        this.contentWebView.addJavascriptInterface(this, "android");
        this.contentWebView.getSettings().setCacheMode(2);
    }

    protected void onDestroy() {
        System.gc();
        super.onDestroy();
    }

    @JavascriptInterface
    public void startFunction() {
        runOnUiThread(new C04951());
    }

    @JavascriptInterface
    public void startFunction(String context) {
        try {
            String str3;
            JSONArray jsonarray = new JSONArray(new String(Base64.decode(context.getBytes(), 0)));
            JSONObject obj2 = (JSONObject) jsonarray.get(1);
            JSONObject obj3 = (JSONObject) jsonarray.get(2);
            String type = ((JSONObject) jsonarray.get(0)).getString("type");
            String key = obj2.getString(SettingsContentProvider.KEY);
            String str = obj3.getString("str");
            if (type.equals(this.Aesdecode)) {
                Aes.keyBytes = key;
                str3 = Aes.decode(str);
            } else {
                DES3.secretKey = key;
                str3 = DES3.decode(str);
            }
            Intent intent = new Intent();
            intent.setFlags(1207959552);
            intent.setClass(this, WeChatPayActivity.class);
            intent.putExtra("WeChatData", str3);
            startActivity(intent);
            finish();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void setWebView() {
        this.mBtnClose = (TextView) findViewById(C0470R.id.iv_close);
        this.mBtnClose.setOnClickListener(this);
        this.mProgressBar = (ProgressBar) findViewById(C0470R.id.pb_cloud_storage);
        this.contentWebView = (WebView) findViewById(C0470R.id.webview);
        this.mProgressBar.setVisibility(0);
        this.contentWebView.getSettings().setJavaScriptEnabled(true);
        this.contentWebView.loadUrl(this.url);
        this.contentWebView.setWebViewClient(new C04962());
        this.contentWebView.setWebChromeClient(new C04973());
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.contentWebView.canGoBack()) {
                this.contentWebView.goBack();
                return true;
            }
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0470R.id.iv_close:
                setResult(13);
                finish();
                return;
            default:
                return;
        }
    }
}
