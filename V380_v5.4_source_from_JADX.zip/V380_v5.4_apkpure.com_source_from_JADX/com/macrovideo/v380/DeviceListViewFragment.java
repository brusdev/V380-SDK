package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.httptool.HttpUtils;
import com.macrovideo.materialshowcaseview.MaterialShowcaseSequence;
import com.macrovideo.materialshowcaseview.MaterialShowcaseView;
import com.macrovideo.materialshowcaseview.MaterialShowcaseView.Builder;
import com.macrovideo.materialshowcaseview.ShowcaseConfig;
import com.macrovideo.pull.lib.PullToRefreshBase.OnRefreshListener;
import com.macrovideo.pull.lib.PullToRefreshListView;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.media.LoginHandle;
import com.macrovideo.sdk.media.LoginHelperEX;
import com.macrovideo.sdk.objects.ObjectUserInfo;
import com.macrovideo.sdk.setting.AccountInfo;
import com.macrovideo.sdk.setting.AlarmAndPromptInfo;
import com.macrovideo.sdk.setting.DeviceAccountMessageSetting;
import com.macrovideo.sdk.setting.DeviceAlarmAndPromptSetting;
import com.macrovideo.sdk.tools.DeviceScanner;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.sdk.tools.SpSaveList;
import com.macrovideo.xingepush.RegistClientWithDeviceArrayToServer;
import com.tencent.android.tpush.common.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StreamCorruptedException;
import java.net.DatagramSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.apache.http.cookie.ClientCookie;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@SuppressLint({"HandlerLeak", "InlinedApi"})
public class DeviceListViewFragment extends Fragment implements OnClickListener, OnItemClickListener, OnItemLongClickListener {
    private static int BIND_DEVICE_RESULT_CODE = 801;
    private static int DELETE_DEVICE_RESULT_CODE = 802;
    private static final int DEVICE_HAVE_NEW_VERSION = 2;
    static final int DEVICE_IS_EXISTANCE = 10004;
    private static int EDIT_DEVICE_RESULT_CODE = LocalDefines.BIND_DEVICE_RESULT_CODE;
    static final int GET_PREVIEW_LIST_FAIL_NET_ERR = -11;
    static final int GET_PREVIEW_LIST_OK = 10;
    static final int HANDLE_MESSAGE_UPDATE_FRESHFACE = 64;
    static final int HANDLE_MESSAGE_UPDATE_FRESHTIME = 32;
    private static final int HANDLE_MSG_CODE_GET_DEVICE_LIST_FROM_NETWORK = 363;
    static final int HANDLE_MSG_CODE_LOGIN_RESULT = 16;
    static final int HANDLE_PREVIEW_LIST_UPDATE = 80;
    public static String INTENT_DEVICE_ID = "device";
    static final int LOGIN_COMMUNICATION_BUFFER_SIZE = 520;
    static final int LOGIN_RESULT_CODE_FAIL_NET_DOWN = 4097;
    static final int LOGIN_RESULT_CODE_FAIL_NET_POOL = 4098;
    static final int LOGIN_RESULT_CODE_FAIL_OLD_VERSON = 4103;
    static final int LOGIN_RESULT_CODE_FAIL_PWD_ERROR = 4102;
    static final int LOGIN_RESULT_CODE_FAIL_SERVER_OFFLINE = 4099;
    static final int LOGIN_RESULT_CODE_FAIL_USER_NOEXIST = 4101;
    static final int LOGIN_RESULT_CODE_FAIL_VERIFY_FAILED = 4100;
    static final int LOGIN_RESULT_CODE_SUCCESS = 1;
    private static int LayoutSignnum = 1;
    static final int MR_LOGIN_COMMUNICATION_BUFFER_SIZE = 256;
    private static final int MY_PERMISSIONS_REQUEST_CAMERA = 1;
    private static final int MY_PERMISSION_REQUEST_LOCATION = 5;
    static int NewLocalTimeTamp = 0;
    private static final int ONE_KEY_ALARM_DEVICE_ALARM_AND_PROMPT_SETTING = 67;
    private static final int ONE_KEY_ALARM_SETTING = 66;
    private static final int TYPE_LOADING = 1;
    private static final int TYPE_SAVING = 2;
    static final int VIEW_INDEX_CONFIG = 1005;
    static final int VIEW_INDEX_DATETIME_CONFIG = 1008;
    static final int VIEW_INDEX_DEVICE_EDIT = 1003;
    static final int VIEW_INDEX_FILE_LIST = 1011;
    static final int VIEW_INDEX_LOGIN = 1000;
    static final int VIEW_INDEX_NETWORK_CONFIG = 1006;
    static final int VIEW_INDEX_RECORD_CONFIG = 1007;
    static final int VIEW_INDEX_SEARCH = 1002;
    static final int VIEW_INDEX_SERVERLIST = 1001;
    static final int VIEW_INDEX_USER_CONFIG = 1009;
    static final int VIEW_INDEX_VER_INFO = 1010;
    public static String _Token = null;
    static Dialog addDeviceDialog;
    static Dialog deleteDeviceDialog;
    static Dialog mOneKeyAlarmSettingDialog;
    static final Object searchLock = new Object();
    static SharedPreferences share;
    public static boolean shouldUpdateUI = true;
    static SharedPreferences sp_alarmList;
    private List Alarmlist = new ArrayList();
    private String[] DeviceAccount_array;
    private int[] DeviceId_array;
    private String[] DevicePassword_array;
    private int[] DeviceProductId_array;
    private DeviceInfo Editinfo;
    public int SevriceTimeTamp = 0;
    private long _lBroadcastTime = 0;
    private int _nOnlineStatCheckID = 0;
    AlarmGettingMessageThread alarmGettingMessageThread = null;
    private boolean alarmType = false;
    private boolean bCheck = true;
    private boolean bDemoOrDevice = true;
    boolean bFirsh = true;
    boolean bHasUpdate = false;
    private boolean bIsSearching = false;
    private boolean bLanguage = false;
    boolean bNewDevFound = false;
    private int bindDevice_result = -1;
    private int bindDevice_way = -1;
    private Button btnDemo;
    private Button btnDeviceConfigAdd;
    private Button btnDeviceHotspot;
    private Button btnDeviceInfoSave;
    private Button btnDeviceQuickAdd;
    private Button btnModifyDeviceInfo;
    private Button btnReverSelect = null;
    private Button btnSelectAll = null;
    private Button btnVisitDeviceInfoSave;
    private View connectConctentView = null;
    private Dialog connectingDialog = null;
    private View contentView = null;
    private int deleteDevice_item = -1;
    private int deleteDevice_result = -1;
    private ArrayList<DeviceInfo> demoSeverInfoListDataTemp = new ArrayList();
    private Dialog deviceAddDialog = null;
    private ArrayList<DeviceInfo> deviceIPList = null;
    private ArrayList<DeviceInfo> deviceList = null;
    public DeviceListViewAdapter deviceListItemAdapter = null;
    private int editDevice_result = -1;
    private EditText etDeviceIDAdd;
    private EditText etDeviceNewPwd;
    private EditText etDeviceOldConfirm;
    private EditText etDeviceOldPwd;
    private EditText etDeviceUserName;
    private Handler handler = new C03081();
    private int height;
    DatagramSocket ipuAPudpSocket = null;
    DatagramSocket ipuStationudpSocket = null;
    private int isNotSynchronized_code = -1;
    private int isSynchronized_code = 0;
    private ImageView ivBack;
    private ImageView ivDeviceAdd;
    private LinearLayout llDeviceHotspot;
    private LinearLayout llDeviceIDAdd;
    private FrameLayout llDeviceQuickAdd;
    private LinearLayout llLocalNetWordSeek;
    private LinearLayout llModifyDeviceInfoLayout;
    private LinearLayout llSeekFine;
    private LinearLayout llSmartLink;
    private LinearLayout llTwoCodeAdd;
    private LinearLayout llVisitDeviceInfoLayout;
    private Dialog loadingDialog;
    private View loadingView;
    boolean mIsModifyDeviceInfo;
    boolean mIsSearchingMode = false;
    private int mLoadType = 1;
    private int m_loginID = 0;
    private int m_nBindForSearchDeviceId;
    private int m_nIPUpdateID = 0;
    private int m_nMsgGetThreadID = 0;
    private int m_nOneKeyAlarmDeviceAlarmAndPromptSettingID = 1;
    private int m_nOneKeyAlarmSettingID = 0;
    private int m_nPort = 8800;
    private int m_nPreviewListGetThreadID = 0;
    private int m_nSearchID = 0;
    private String m_strIP = "127.0.0.1";
    private String m_strName = "IPC";
    private String m_strPassword = Constants.MAIN_VERSION_TAG;
    private String m_strUsername = Constants.MAIN_VERSION_TAG;
    private int nUserID = 0;
    private int n_BindDeviceThreadID = 0;
    private int n_DeviceListThreadID = 0;
    private int n_UnbindDeviceThreadID = 0;
    private int n_UpdateDeviceThreadID = 0;
    private PopupWindow popuWindowEditDelete;
    private PopupWindow popupWindowAdd;
    private PopupWindow popupWindowEdit;
    private int popupWindowMoreMarginRight;
    private PopupWindow popup_more;
    GetPreviewDeviceListThread previewListGetThread = null;
    private PullToRefreshListView pullToRefreshListView = null;
    private PushUpdateReceiver pushUpdateReceiver;
    private Activity relateAtivity = null;
    private RelativeLayout rlListView;
    private ProgressBar searchingProgress;
    private GridView servergridView = null;
    private ListView serverlistView = null;
    private String strDeviceID;
    private String strName;
    private String strPassword;
    private String strUserName;
    private TextView tvTitle = null;
    private ObjectUserInfo userInfo = new ObjectUserInfo();
    private int width;
    private WindowManager windowManager;

    class C03081 extends Handler {
        C03081() {
        }

        @SuppressLint({"HandlerLeak"})
        public void handleMessage(Message msg) {
            DeviceListViewFragment.this.searchingProgress.setVisibility(8);
            if (DeviceListViewFragment.this.searchingProgress.getVisibility() == 0) {
                DeviceListViewFragment.this.searchingProgress.setVisibility(8);
            }
            if (msg.arg1 == 257) {
                if (DeviceListViewFragment.this.deviceListItemAdapter != null) {
                    DeviceListViewFragment.this.deviceListItemAdapter.notifyDataSetChanged();
                }
            } else if (msg.arg1 == 273) {
                DeviceListViewFragment.this.deviceIDAdd();
            } else {
                Bundle data;
                Bundle bundle;
                DeviceInfo info;
                String searchResultMsg;
                Toast toast;
                String strUsername;
                String strPassword;
                DeviceInfo info2;
                int i;
                if (msg.arg1 != 1002) {
                    if (msg.arg1 != 80) {
                        int nDevID;
                        if (msg.arg1 != 64) {
                            if (msg.arg1 != 32) {
                                if (msg.arg1 != 16) {
                                    if (msg.arg1 != 1001) {
                                        if (msg.arg1 != 1200) {
                                            if (msg.arg1 != DeviceListViewFragment.ONE_KEY_ALARM_SETTING) {
                                                if (msg.arg1 != DeviceListViewFragment.ONE_KEY_ALARM_DEVICE_ALARM_AND_PROMPT_SETTING) {
                                                    if (msg.arg1 == DeviceListViewFragment.HANDLE_MSG_CODE_GET_DEVICE_LIST_FROM_NETWORK) {
                                                        DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                                                        switch (msg.arg2) {
                                                            case -1:
                                                                if (DeviceListViewFragment.shouldUpdateUI) {
                                                                    Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getString(C0470R.string.str_get_device_list_network_error), 0).show();
                                                                    break;
                                                                }
                                                                break;
                                                            case 0:
                                                                LocalDefines.shouldLoadUserDeviceList = false;
                                                                if (HomePageActivity.AppMode == 1) {
                                                                    DeviceListViewFragment.this.LoadUserDevice(DeviceListViewFragment.this.DeviceId_array, DeviceListViewFragment.this.DeviceAccount_array, DeviceListViewFragment.this.DevicePassword_array, DeviceListViewFragment.this.DeviceProductId_array);
                                                                    break;
                                                                }
                                                                break;
                                                            case 401:
                                                                DeviceListViewFragment.this.httpResult401();
                                                                break;
                                                            case 500:
                                                                Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.str_get_device_list_server_error), 0).show();
                                                                break;
                                                            case HttpUtils.RESULT_CODE_NOT_FOUND_PARAMETER /*10005*/:
                                                                break;
                                                            case 10007:
                                                                LocalDefines.shouldLoadUserDeviceList = false;
                                                                Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getString(C0470R.string.str_lastest_list), 0).show();
                                                                break;
                                                            default:
                                                                Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getString(C0470R.string.str_get_device_list_error), 0).show();
                                                                break;
                                                        }
                                                    }
                                                }
                                                switch (msg.arg2) {
                                                    case 256:
                                                        DeviceListViewFragment.mOneKeyAlarmSettingDialog.dismiss();
                                                        if (DeviceListViewFragment.this.alarmType) {
                                                            Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_deactivate_success), 0).show();
                                                        } else {
                                                            Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_activate_success), 0).show();
                                                        }
                                                        data = msg.getData();
                                                        if (data != null) {
                                                            DatabaseManager.updateServerInfoOneKeyDeviceAlarmAndPromptSetting(data.getInt("key_device_id"), data.getBoolean("key_one_key_alarm_state"));
                                                            LocalDefines.reloadDeviceInfoList();
                                                            DeviceListViewFragment.this.updateListView();
                                                            break;
                                                        }
                                                        break;
                                                    default:
                                                        DeviceListViewFragment.mOneKeyAlarmSettingDialog.dismiss();
                                                        if (!DeviceListViewFragment.this.alarmType) {
                                                            Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_activate_fail), 0).show();
                                                            break;
                                                        } else {
                                                            Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_deactivate_fail), 0).show();
                                                            break;
                                                        }
                                                }
                                            }
                                            switch (msg.arg2) {
                                                case 256:
                                                    DeviceListViewFragment.mOneKeyAlarmSettingDialog.dismiss();
                                                    if (DeviceListViewFragment.this.alarmType) {
                                                        Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_deactivate_success), 0).show();
                                                    } else {
                                                        Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_activate_success), 0).show();
                                                    }
                                                    bundle = msg.getData();
                                                    DatabaseManager.updateServerInfoOneKeyAlarmSetting(bundle.getInt("key_device_id"), bundle.getBoolean("key_one_key_alarm_state"));
                                                    LocalDefines.reloadDeviceInfoList();
                                                    DeviceListViewFragment.this.updateListView();
                                                    break;
                                                default:
                                                    DeviceListViewFragment.mOneKeyAlarmSettingDialog.dismiss();
                                                    if (!DeviceListViewFragment.this.alarmType) {
                                                        Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_activate_fail), 0).show();
                                                        break;
                                                    } else {
                                                        Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_deactivate_fail), 0).show();
                                                        break;
                                                    }
                                            }
                                        }
                                        int nIndex = msg.arg2;
                                        if (nIndex >= 0 && nIndex < LocalDefines._severInfoListData.size()) {
                                            info = (DeviceInfo) LocalDefines._severInfoListData.get(nIndex);
                                            if (info != null) {
                                                if (info.getIsAlarmOn() == 0) {
                                                    DatabaseManager.UpdateServerInfoStateAndCanUpdateInfo(info);
                                                } else {
                                                    DatabaseManager.UpdateServerInfoStateWithAlarmStateAndCanUpdateInfo(info);
                                                }
                                                if (DeviceListViewFragment.this.deviceListItemAdapter != null) {
                                                    Iterator it = DeviceListViewFragment.this.deviceListItemAdapter.getAppList().iterator();
                                                    while (it.hasNext()) {
                                                        DeviceInfo adapterDevice = (DeviceInfo) ((HashMap) it.next()).get("server");
                                                        if (adapterDevice.getnDevID() == info.getnDevID()) {
                                                            adapterDevice.setCanUpdateDevice(info.isCanUpdateDevice());
                                                            break;
                                                        }
                                                    }
                                                    DeviceListViewFragment.this.deviceListItemAdapter.notifyDataSetChanged();
                                                }
                                            }
                                        }
                                    } else if (LocalDefines._nListMode == 200) {
                                        DeviceListViewFragment.this.pullToRefreshListView.onRefreshComplete();
                                        DeviceListViewFragment.this.StopSearchDevice();
                                        switch (msg.arg2) {
                                            case 101:
                                                if (DeviceListViewFragment.this.deviceList != null && DeviceListViewFragment.this.deviceList.size() > 0) {
                                                    boolean bNewDevFound;
                                                    boolean bHasUpdate;
                                                    if (HomePageActivity.AppMode != 1) {
                                                        bNewDevFound = false;
                                                        bHasUpdate = false;
                                                        searchResultMsg = DeviceListViewFragment.this.getString(C0470R.string.add_device);
                                                        for (i = 0; i < DeviceListViewFragment.this.deviceList.size(); i++) {
                                                            info = (DeviceInfo) DeviceListViewFragment.this.deviceList.get(i);
                                                            info.setnOnLineStat(101);
                                                            info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                                            if (!(info == null || info.getnDevID() == 0)) {
                                                                bNewDevFound = true;
                                                                if (DatabaseManager.IsInfoExist(info)) {
                                                                    if (info.getIsAlarmOn() == 0) {
                                                                        DatabaseManager.UpdateServerInfoState(info);
                                                                    } else {
                                                                        DatabaseManager.UpdateServerInfoStateWithAlarmState(info);
                                                                    }
                                                                    bHasUpdate = true;
                                                                } else if (DatabaseManager.AddServerInfo(info)) {
                                                                    if (i == 0) {
                                                                        searchResultMsg = new StringBuilder(String.valueOf(searchResultMsg)).append(info.getStrName()).toString();
                                                                    } else {
                                                                        searchResultMsg = new StringBuilder(String.valueOf(searchResultMsg)).append(", ").append(info.getStrName()).toString();
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        if (DeviceListViewFragment.this.deviceList.size() <= 0) {
                                                            toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.no_dev_found), 0);
                                                            toast.setGravity(17, 0, 0);
                                                            toast.show();
                                                            break;
                                                        }
                                                        if (bHasUpdate) {
                                                            LocalDefines.reloadDeviceInfoList();
                                                            if (DeviceListViewFragment.this.deviceListItemAdapter != null) {
                                                                DeviceListViewFragment.this.deviceListItemAdapter.notifyDataSetChanged();
                                                            }
                                                        }
                                                        if (bNewDevFound) {
                                                            LocalDefines.isDeviceListSet = true;
                                                            LocalDefines.nClientDeviceSettingThreadID++;
                                                            new RegistClientWithDeviceArrayToServer((Handler) this, LocalDefines.nClientDeviceSettingThreadID).start();
                                                            toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), searchResultMsg, 0);
                                                            toast.setGravity(17, 0, 0);
                                                            toast.show();
                                                        } else {
                                                            toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.search_finish), 0);
                                                            toast.setGravity(17, 0, 0);
                                                            toast.show();
                                                        }
                                                        DeviceListViewFragment.this.refleshListView();
                                                        break;
                                                    }
                                                    DeviceListViewFragment.this.searchingProgress.setVisibility(0);
                                                    DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                                                    bNewDevFound = false;
                                                    bHasUpdate = false;
                                                    searchResultMsg = DeviceListViewFragment.this.getString(C0470R.string.add_device);
                                                    for (i = 0; i < DeviceListViewFragment.this.deviceList.size(); i++) {
                                                        info = (DeviceInfo) DeviceListViewFragment.this.deviceList.get(i);
                                                        info.setnOnLineStat(101);
                                                        info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                                        if (!(info == null || info.getnDevID() == 0)) {
                                                            bNewDevFound = true;
                                                            if (DatabaseManager.IsInfoExist(info)) {
                                                                if (info.getIsAlarmOn() == 0) {
                                                                    DatabaseManager.UpdateServerInfoState(info);
                                                                } else {
                                                                    DatabaseManager.UpdateServerInfoStateWithAlarmState(info);
                                                                }
                                                                bHasUpdate = true;
                                                            } else {
                                                                info.setisSynchronized(DeviceListViewFragment.this.isNotSynchronized_code);
                                                                DatabaseManager.updateSynchronizedCode(info.getnDevID(), DeviceListViewFragment.this.isNotSynchronized_code);
                                                                if (DatabaseManager.AddServerInfo(info)) {
                                                                    LocalDefines.shouldLoadUserDeviceList = true;
                                                                    if (i == 0) {
                                                                        searchResultMsg = new StringBuilder(String.valueOf(searchResultMsg)).append(info.getStrName()).toString();
                                                                    } else {
                                                                        searchResultMsg = new StringBuilder(String.valueOf(searchResultMsg)).append(", ").append(info.getStrName()).toString();
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    if (DeviceListViewFragment.this.deviceList.size() <= 0) {
                                                        toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.no_dev_found), 0);
                                                        toast.setGravity(17, 0, 0);
                                                        toast.show();
                                                        break;
                                                    }
                                                    if (bHasUpdate) {
                                                        LocalDefines.reloadDeviceInfoList();
                                                        if (DeviceListViewFragment.this.deviceListItemAdapter != null) {
                                                            DeviceListViewFragment.this.deviceListItemAdapter.notifyDataSetChanged();
                                                        }
                                                    }
                                                    if (bNewDevFound) {
                                                        LocalDefines.isDeviceListSet = true;
                                                        LocalDefines.nClientDeviceSettingThreadID++;
                                                        LocalDefines.nClientDeviceSettingThreadID++;
                                                        new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
                                                        toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), searchResultMsg, 0);
                                                        toast.setGravity(17, 0, 0);
                                                        toast.show();
                                                    } else {
                                                        toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.search_finish), 0);
                                                        toast.setGravity(17, 0, 0);
                                                        toast.show();
                                                    }
                                                    DeviceListViewFragment.this.refleshListView();
                                                    break;
                                                }
                                                toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.no_dev_found), 0);
                                                toast.setGravity(17, 0, 0);
                                                toast.show();
                                                break;
                                                break;
                                            case 102:
                                                toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.no_dev_found), 0);
                                                toast.setGravity(17, 0, 0);
                                                toast.show();
                                                break;
                                            default:
                                                break;
                                        }
                                    } else {
                                        return;
                                    }
                                }
                                DeviceListViewFragment.this.connectingDialog.dismiss();
                                switch (msg.arg2) {
                                    case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                                        DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_PWDError));
                                        break;
                                    case 256:
                                        data = msg.getData();
                                        if (data != null) {
                                            int listMode = data.getInt("list_mode");
                                            if (!DeviceListViewFragment.this.m_strUsername.equals("admin") || !DeviceListViewFragment.this.m_strPassword.equals(Constants.MAIN_VERSION_TAG) || 200 != listMode) {
                                                data.putBoolean("isSelectArea", false);
                                                data.putString("name", DeviceListViewFragment.this.m_strName);
                                                data.putString("server", DeviceListViewFragment.this.m_strIP);
                                                data.putString("username", DeviceListViewFragment.this.m_strUsername);
                                                data.putString("password", DeviceListViewFragment.this.m_strPassword);
                                                data.putInt("nPort", DeviceListViewFragment.this.m_nPort);
                                                DeviceListViewFragment deviceListViewFragment = DeviceListViewFragment.this;
                                                deviceListViewFragment.m_nMsgGetThreadID = deviceListViewFragment.m_nMsgGetThreadID + 1;
                                                int camType = ((LoginHandle) data.getParcelable(Defines.RECORD_FILE_RETURN_MESSAGE)).getCamType();
                                                Intent intent;
                                                if (camType != 1 && camType != 2) {
                                                    intent = new Intent(DeviceListViewFragment.this.relateAtivity, NVPlayerPlayActivity.class);
                                                    intent.putExtras(data);
                                                    DeviceListViewFragment.this.relateAtivity.startActivity(intent);
                                                    DeviceListViewFragment.this.relateAtivity.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                                                    ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).closeActivity();
                                                    break;
                                                }
                                                intent = new Intent(DeviceListViewFragment.this.relateAtivity, NVPlayerPlayFishEyeActivity.class);
                                                intent.putExtras(data);
                                                DeviceListViewFragment.this.relateAtivity.startActivity(intent);
                                                DeviceListViewFragment.this.relateAtivity.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                                                ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).closeActivity();
                                                break;
                                            }
                                            DeviceListViewFragment.this.showAlertSafetyDialog(data);
                                            break;
                                        }
                                        DeviceListViewFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed))).append("(").append(DeviceListViewFragment.this.getString(C0470R.string.notice_Result_BadResult)).append(")").toString(), DeviceListViewFragment.this.getString(C0470R.string.alert_connect_tips));
                                        return;
                                        break;
                                    case 4097:
                                        DeviceListViewFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(DeviceListViewFragment.this.getString(C0470R.string.notice_Result_BadResult)).append(")").toString(), DeviceListViewFragment.this.getString(C0470R.string.alert_connect_tips));
                                        break;
                                    case 4098:
                                        DeviceListViewFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(DeviceListViewFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed)).append(")").toString(), DeviceListViewFragment.this.getString(C0470R.string.alert_connect_tips));
                                        break;
                                    case 4099:
                                        DeviceListViewFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(DeviceListViewFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed)).append(")").toString(), DeviceListViewFragment.this.getString(C0470R.string.alert_connect_tips));
                                        break;
                                    case 4100:
                                        DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_VerifyFailed));
                                        break;
                                    case 4101:
                                        DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                                        break;
                                    case 4102:
                                        DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_PWDError));
                                        break;
                                    case 4103:
                                        DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                                        break;
                                    default:
                                        DeviceListViewFragment.this.ShowAlert(new StringBuilder(String.valueOf(DeviceListViewFragment.this.getString(C0470R.string.alert_title_login_failed))).append("  (").append(DeviceListViewFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed)).append(")").toString(), DeviceListViewFragment.this.getString(C0470R.string.alert_connect_tips));
                                        break;
                                }
                            }
                            data = msg.getData();
                            if (!(data == null || LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0)) {
                                nDevID = data.getInt("dev_id");
                                int nNewMsgCount = data.getInt("msg_count");
                                strUsername = data.getString("username");
                                strPassword = data.getString("password");
                                long lLastFreshTime = data.getLong("last_fresh_time");
                                DatabaseManager.UpdateServerInfoMsgCount(nDevID, lLastFreshTime, data.getLong("last_get_time"), nNewMsgCount, strUsername, strPassword);
                                System.out.println("new AlarmFaceGettingMessageThread: " + nDevID + ", " + strUsername + ", " + strPassword);
                                new AlarmFaceGettingMessageThread(DeviceListViewFragment.this.handler, DeviceListViewFragment.this.m_nMsgGetThreadID, nDevID, strUsername, strPassword).start();
                                i = LocalDefines._severInfoListData.size() - 1;
                                while (i >= 0 && i < LocalDefines._severInfoListData.size()) {
                                    info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                                    if (info.isMatch(nDevID, strUsername, strPassword)) {
                                        info.setnNewMsgCount(nNewMsgCount);
                                        info.setlLastMsgFreshTime(lLastFreshTime);
                                    }
                                    i--;
                                }
                                if (DeviceListViewFragment.this.deviceListItemAdapter != null) {
                                    DeviceListViewFragment.this.deviceListItemAdapter.notifyDataSetChanged();
                                }
                            }
                        } else if (LocalDefines._nListMode == 200) {
                            data = msg.getData();
                            if (data != null) {
                                nDevID = data.getInt("dev_id");
                                strUsername = data.getString("username");
                                strPassword = data.getString("password");
                                Bitmap image = (Bitmap) data.getParcelable("image");
                                if (nDevID > 0 && image != null && LocalDefines._severInfoListData != null && LocalDefines._severInfoListData.size() > 0) {
                                    DatabaseManager.setFaceForDevID(nDevID, image, strUsername, strPassword);
                                    boolean hasUpdate = false;
                                    i = LocalDefines._severInfoListData.size() - 1;
                                    while (i >= 0 && i < LocalDefines._severInfoListData.size()) {
                                        info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                                        if (info != null && info.isMatch(nDevID, strUsername, strPassword)) {
                                            info.setFaceImage(image);
                                            hasUpdate = true;
                                        }
                                        i--;
                                    }
                                    if (DeviceListViewFragment.this.deviceListItemAdapter != null && hasUpdate) {
                                        DeviceListViewFragment.this.deviceListItemAdapter.notifyDataSetChanged();
                                    }
                                }
                            }
                        } else {
                            return;
                        }
                    } else if (msg.arg2 == 10) {
                        LocalDefines._demoSeverInfoListData.clear();
                        for (i = 0; i < DeviceListViewFragment.this.demoSeverInfoListDataTemp.size(); i++) {
                            LocalDefines._demoSeverInfoListData.add((DeviceInfo) DeviceListViewFragment.this.demoSeverInfoListDataTemp.get(i));
                        }
                        if (LocalDefines._demoSeverInfoListData.size() > 0) {
                            LocalDefines._isNeedGetPreviewDeviceList = false;
                        }
                        System.out.println("GetPreviewDeviceListThread Defines._demoSeverInfoListData.size=" + LocalDefines._demoSeverInfoListData.size());
                        if (LocalDefines._nListMode == 204) {
                            DeviceListViewFragment.this.updateDemoListView();
                        }
                    }
                } else {
                    DeviceScanner.reset();
                    long lNow = new Date().getTime();
                    boolean isUpdate = false;
                    for (i = DeviceListViewFragment.this.deviceIPList.size() - 1; i >= 0; i--) {
                        DeviceInfo info1 = (DeviceInfo) DeviceListViewFragment.this.deviceIPList.get(i);
                        if (info1 != null) {
                            int j = LocalDefines._severInfoListData.size() - 1;
                            while (j >= 0 && j < LocalDefines._severInfoListData.size()) {
                                info2 = (DeviceInfo) LocalDefines._severInfoListData.get(j);
                                if (info1.getnDevID() == info2.getnDevID()) {
                                    isUpdate = true;
                                    info2.setStrIP(info1.getStrIP());
                                    info2.setlOnLineStatChaneTime(lNow);
                                    info2.setnOnLineStat(101);
                                    info2.setnSaveType(Defines.SERVER_SAVE_TYPE_SEARCH);
                                    if (info1.getIsAlarmOn() != 0) {
                                        info2.setIsAlarmOn(info1.getIsAlarmOn());
                                        DatabaseManager.UpdateServerInfoStateWithAlarmState(info2);
                                    } else {
                                        DatabaseManager.UpdateServerInfoState(info2);
                                    }
                                } else {
                                    j--;
                                }
                            }
                        }
                    }
                    if (DeviceListViewFragment.this.deviceListItemAdapter != null && r51 && LocalDefines._severInfoListData != null && LocalDefines._severInfoListData.size() > 0) {
                        ArrayList<HashMap<String, Object>> listItem = new ArrayList();
                        i = LocalDefines._severInfoListData.size() - 1;
                        while (i >= 0 && i < LocalDefines._severInfoListData.size()) {
                            info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                            HashMap<String, Object> map = new HashMap();
                            map.put("index", Integer.valueOf(i));
                            map.put("ID", Integer.valueOf(info.getnID()));
                            map.put("DevID", Integer.valueOf(info.getnDevID()));
                            map.put("server", info);
                            listItem.add(map);
                            i--;
                        }
                        int i2 = 15;
                        DeviceListViewFragment.this.deviceListItemAdapter = new DeviceListViewAdapter(DeviceListViewFragment.this.relateAtivity, listItem, C0470R.layout.server_list_item2, new String[]{"ItemBtnFace", "ItemTitleName", "ItemTitleID", "ItemLlDeviceState", "ItemTrHomeListing", "ivRedPot", "llDelete", "llEdit", "llAlarm", "llMsg", "ivDeviceState", "llCloudSave", "tvCloudSave", "ivCloud", "ivCanUpdate"}, new int[]{C0470R.id.item_face, C0470R.id.ItemTitleName, C0470R.id.ItemTitleID, C0470R.id.llDeviceState, C0470R.id.ll_more, C0470R.id.redpot, C0470R.id.ll_device_delete, C0470R.id.ll_device_edit, C0470R.id.ll_device_alarm, C0470R.id.ll_device_msg, C0470R.id.ivDeviceState, C0470R.id.ll_cloud_storage, C0470R.id.tv_cloud_storage, C0470R.id.iv_cloud, C0470R.id.item_iv_device_can_update}, 1);
                        DeviceListViewFragment.this.deviceListItemAdapter.notifyDataSetChanged();
                    }
                }
                if (msg.arg1 == DeviceListViewFragment.EDIT_DEVICE_RESULT_CODE) {
                    boolean isModifyDeviceInfo = ((Boolean) msg.obj).booleanValue();
                    DeviceListViewFragment.this.loadingDialog.dismiss();
                    if (isModifyDeviceInfo) {
                        DeviceListViewFragment.this.btnDeviceInfoSave.setEnabled(true);
                    } else {
                        DeviceListViewFragment.this.btnModifyDeviceInfo.setEnabled(true);
                        DeviceListViewFragment.this.btnVisitDeviceInfoSave.setEnabled(true);
                    }
                    if (DeviceListViewFragment.this.editDevice_result == 0) {
                        if (isModifyDeviceInfo) {
                            DeviceListViewFragment.this.setUserInfo(DeviceListViewFragment.this.Editinfo, DeviceListViewFragment.this.etDeviceUserName.getText().toString().trim(), DeviceListViewFragment.this.etDeviceNewPwd.getText().toString().trim());
                        } else if (DatabaseManager.modifyServerInfo(new DeviceInfo(DeviceListViewFragment.this.Editinfo.getnID(), Integer.valueOf(DeviceListViewFragment.this.strDeviceID).intValue(), DeviceListViewFragment.this.strName, DeviceListViewFragment.this.Editinfo.getStrIP(), DeviceListViewFragment.this.Editinfo.getnPort(), DeviceListViewFragment.this.strUserName, DeviceListViewFragment.this.strPassword, DeviceListViewFragment.this.Editinfo.getStrDomain(), DeviceListViewFragment.this.Editinfo.getnSaveType(), Constants.MAIN_VERSION_TAG, 0))) {
                            DeviceListViewFragment.this.refleshListView();
                            if (DeviceListViewFragment.this.popupWindowEdit != null) {
                                DeviceListViewFragment.this.popupWindowEdit.dismiss();
                            }
                        }
                    } else if (DeviceListViewFragment.this.editDevice_result == -1) {
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.str_network_error), 0).show();
                    } else if (DeviceListViewFragment.this.editDevice_result == 401) {
                        DeviceListViewFragment.this.httpResult401();
                    } else if (DeviceListViewFragment.this.editDevice_result == 500) {
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.str_server_error), 0).show();
                    } else {
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.Edit_Device_Fail), 0).show();
                    }
                } else if (msg.arg1 == DeviceListViewFragment.BIND_DEVICE_RESULT_CODE) {
                    bundle = msg.getData();
                    DeviceInfo bundleinfo = (DeviceInfo) bundle.getParcelable("Bind_info");
                    int id = Integer.parseInt(DeviceListViewFragment.this.strDeviceID);
                    info = new DeviceInfo(-1, id, DeviceListViewFragment.this.strDeviceID, "192.168.1.1", 8800, DeviceListViewFragment.this.strUserName, DeviceListViewFragment.this.strPassword, Constants.MAIN_VERSION_TAG, new StringBuilder(String.valueOf(id)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_ADD);
                    boolean updateSign;
                    boolean bResult;
                    if (msg.arg2 == 0) {
                        info.setisSynchronized(DeviceListViewFragment.this.isSynchronized_code);
                        updateSign = DatabaseManager.updateSynchronizedCode(id, DeviceListViewFragment.this.isSynchronized_code);
                        if (DeviceListViewFragment.addDeviceDialog != null) {
                            DeviceListViewFragment.addDeviceDialog.dismiss();
                        }
                        if (DeviceListViewFragment.this.bindDevice_way == 1) {
                            if (DatabaseManager.IsInfoExist(info)) {
                                bResult = DatabaseManager.UpdateServerInfo(info);
                            } else {
                                bResult = DatabaseManager.AddServerInfo(info);
                            }
                            if (!DeviceListViewFragment.shouldUpdateUI) {
                                return;
                            }
                            if (bResult) {
                                Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddSucceed), 0).show();
                                DeviceListViewFragment.this.refleshListView();
                                LocalDefines.isDeviceListSet = false;
                                LocalDefines.reloadDeviceInfoList();
                                Log.i("XinGeTAG", " " + LocalDefines._severInfoWithoutImageListData.size());
                                LocalDefines.nClientDeviceSettingThreadID++;
                                new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
                                if (DeviceListViewFragment.this.popupWindowAdd != null) {
                                    DeviceListViewFragment.this.popupWindowAdd.dismiss();
                                    return;
                                }
                                return;
                            }
                            Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddFail), 0).show();
                            return;
                        }
                        info2 = (DeviceInfo) msg.getData().getParcelable("Bind_info");
                        int index = bundle.getInt("Bind_index");
                        searchResultMsg = DeviceListViewFragment.this.getString(C0470R.string.add_device);
                        if (!DatabaseManager.AddServerInfo(info2)) {
                            if (info.getIsAlarmOn() == 0) {
                                DatabaseManager.UpdateServerInfoState(info2);
                            } else {
                                DatabaseManager.UpdateServerInfoStateWithAlarmState(info2);
                            }
                            DeviceListViewFragment.this.bHasUpdate = true;
                        } else if (index == 0) {
                            searchResultMsg = new StringBuilder(String.valueOf(searchResultMsg)).append(info2.getStrName()).toString();
                        } else {
                            searchResultMsg = new StringBuilder(String.valueOf(searchResultMsg)).append(", ").append(info2.getStrName()).toString();
                        }
                        if (DeviceListViewFragment.this.deviceList.size() > 0) {
                            if (DeviceListViewFragment.this.bHasUpdate) {
                                LocalDefines.reloadDeviceInfoList();
                                if (DeviceListViewFragment.this.deviceListItemAdapter != null) {
                                    DeviceListViewFragment.this.deviceListItemAdapter.notifyDataSetChanged();
                                }
                            }
                            if (DeviceListViewFragment.this.bNewDevFound) {
                                LocalDefines.isDeviceListSet = true;
                                LocalDefines.nClientDeviceSettingThreadID++;
                                new RegistClientWithDeviceArrayToServer((Handler) this, LocalDefines.nClientDeviceSettingThreadID).start();
                            } else {
                                toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.search_finish), 0);
                                toast.setGravity(17, 0, 0);
                                toast.show();
                            }
                            DeviceListViewFragment.this.refleshListView();
                            return;
                        }
                        toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.no_dev_found), 0);
                        toast.setGravity(17, 0, 0);
                        toast.show();
                    } else if (msg.arg2 == -1) {
                        if (DeviceListViewFragment.addDeviceDialog != null) {
                            DeviceListViewFragment.addDeviceDialog.dismiss();
                        }
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), C0470R.string.Network_Error, 0).show();
                    } else if (msg.arg2 == 10004) {
                        if (DeviceListViewFragment.addDeviceDialog != null) {
                            DeviceListViewFragment.addDeviceDialog.dismiss();
                        }
                        if (!DatabaseManager.IsInfoExist(info)) {
                            bResult = false;
                            if (!DatabaseManager.IsInfoExist(info)) {
                                System.out.println("数据不同步，添加到本地数据");
                                bResult = DatabaseManager.AddServerInfo(info);
                            }
                            if (bResult) {
                                Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddSucceed), 0).show();
                                DeviceListViewFragment.this.refleshListView();
                                LocalDefines.isDeviceListSet = false;
                                LocalDefines.reloadDeviceInfoList();
                                LocalDefines.nClientDeviceSettingThreadID++;
                                new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
                                if (DeviceListViewFragment.this.popupWindowAdd != null) {
                                    DeviceListViewFragment.this.popupWindowAdd.dismiss();
                                    return;
                                }
                                return;
                            }
                            Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddFail), 0).show();
                        } else if (DatabaseManager.getSynchronizedCode(info.getnDevID()) == DeviceListViewFragment.this.isNotSynchronized_code) {
                            info.setisSynchronized(DeviceListViewFragment.this.isSynchronized_code);
                            updateSign = DatabaseManager.updateSynchronizedCode(id, DeviceListViewFragment.this.isSynchronized_code);
                            LocalDefines.reloadDeviceInfoList();
                        } else {
                            Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.Device_Is_Existence), 0).show();
                        }
                    } else if (msg.arg2 == 401) {
                        if (DeviceListViewFragment.addDeviceDialog != null) {
                            DeviceListViewFragment.addDeviceDialog.dismiss();
                        }
                        DeviceListViewFragment.this.httpResult401();
                    } else if (msg.arg2 == 500) {
                        if (DeviceListViewFragment.addDeviceDialog != null) {
                            DeviceListViewFragment.addDeviceDialog.dismiss();
                        }
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), C0470R.string.str_server_error, 0).show();
                    } else {
                        if (DeviceListViewFragment.addDeviceDialog != null) {
                            DeviceListViewFragment.addDeviceDialog.dismiss();
                        }
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), C0470R.string.str_bind_device_error, 0).show();
                    }
                } else if (msg.arg1 == DeviceListViewFragment.DELETE_DEVICE_RESULT_CODE) {
                    if (DeviceListViewFragment.this.deleteDevice_result == 0) {
                        DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                        if (DatabaseManager.DeleteServerInfo(DeviceListViewFragment.this.Editinfo)) {
                            if (DeviceListViewFragment.this.deleteDevice_item < LocalDefines._severInfoListData.size() && DeviceListViewFragment.this.deleteDevice_item < LocalDefines._severInfoWithoutImageListData.size()) {
                                LocalDefines._severInfoListData.remove(DeviceListViewFragment.this.deleteDevice_item);
                                LocalDefines._severInfoWithoutImageListData.remove(DeviceListViewFragment.this.deleteDevice_item);
                                LocalDefines.isDeviceListSet = false;
                                LocalDefines.nClientDeviceSettingThreadID++;
                                new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
                            }
                            if (DeviceListViewFragment.this.Editinfo.isCanUpdateDevice()) {
                                ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).setCanUpdateDeviceNum(((HomePageActivity) DeviceListViewFragment.this.relateAtivity).getCanUpdateDeviceNum() - 1);
                            }
                            DeviceListViewFragment.this.updateListView();
                            if (LocalDefines._severInfoListData.size() > 0) {
                                DeviceListViewFragment.this.llDeviceQuickAdd.setVisibility(8);
                                DeviceListViewFragment.this.rlListView.setVisibility(0);
                                DeviceListViewFragment.this.bCheck = true;
                            } else {
                                DeviceListViewFragment.this.llDeviceQuickAdd.setVisibility(0);
                                DeviceListViewFragment.this.rlListView.setVisibility(8);
                                DeviceListViewFragment.this.bCheck = false;
                            }
                            Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceDelete), 0).show();
                            return;
                        }
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deleteFail), 0).show();
                    } else if (DeviceListViewFragment.this.deleteDevice_result == -1) {
                        DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.str_network_error), 0).show();
                    } else if (DeviceListViewFragment.this.deleteDevice_result == 401) {
                        DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                        DeviceListViewFragment.this.httpResult401();
                    } else if (DeviceListViewFragment.this.deleteDevice_result == 500) {
                        DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), C0470R.string.str_server_error, 0).show();
                    } else if (DeviceListViewFragment.this.deleteDevice_result == HttpUtils.RESULT_CODE_USER_HAS_NOT_DEVICE) {
                        DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                        boolean bDelete = false;
                        if (DatabaseManager.IsInfoExist(DeviceListViewFragment.this.Editinfo)) {
                            bDelete = DatabaseManager.DeleteServerInfo(DeviceListViewFragment.this.Editinfo);
                        }
                        if (bDelete) {
                            if (DeviceListViewFragment.this.deleteDevice_item < LocalDefines._severInfoListData.size() && DeviceListViewFragment.this.deleteDevice_item < LocalDefines._severInfoWithoutImageListData.size()) {
                                LocalDefines._severInfoListData.remove(DeviceListViewFragment.this.deleteDevice_item);
                                LocalDefines._severInfoWithoutImageListData.remove(DeviceListViewFragment.this.deleteDevice_item);
                                LocalDefines.isDeviceListSet = false;
                                LocalDefines.nClientDeviceSettingThreadID++;
                                new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
                            }
                            DeviceListViewFragment.this.updateListView();
                            if (LocalDefines._severInfoListData.size() > 0) {
                                DeviceListViewFragment.this.llDeviceQuickAdd.setVisibility(8);
                                DeviceListViewFragment.this.rlListView.setVisibility(0);
                                DeviceListViewFragment.this.bCheck = true;
                            } else {
                                DeviceListViewFragment.this.llDeviceQuickAdd.setVisibility(0);
                                DeviceListViewFragment.this.rlListView.setVisibility(8);
                                DeviceListViewFragment.this.bCheck = false;
                            }
                            Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceDelete), 0).show();
                            return;
                        }
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deleteFail), 0).show();
                    } else {
                        DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deleteFail), 0).show();
                    }
                } else if (msg.arg1 == 144) {
                    DeviceListViewFragment.this.loadingDialog.dismiss();
                    DeviceListViewFragment.this.btnVisitDeviceInfoSave.setEnabled(true);
                    DeviceListViewFragment.this.btnModifyDeviceInfo.setEnabled(true);
                    strUsername = Constants.MAIN_VERSION_TAG;
                    strPassword = Constants.MAIN_VERSION_TAG;
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            DeviceListViewFragment.this.showVisitDeviceInfoLayout();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            DeviceListViewFragment.this.showVisitDeviceInfoLayout();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            DeviceListViewFragment.this.showVisitDeviceInfoLayout();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            DeviceListViewFragment.this.showVisitDeviceInfoLayout();
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_NetError));
                            DeviceListViewFragment.this.showVisitDeviceInfoLayout();
                            return;
                        case 256:
                            DeviceListViewFragment.this.btnModifyDeviceInfo.setEnabled(true);
                            DeviceListViewFragment.this.showModifyDeviceInfoLayout();
                            data = msg.getData();
                            if (data == null) {
                                DeviceListViewFragment.this.showVisitDeviceInfoLayout();
                                DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.notice_Result_BadResult), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_BadResult));
                                return;
                            }
                            accountHandler = (AccountInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                            strUsername = accountHandler.getStrUserName();
                            strPassword = accountHandler.getStrPassword();
                            int nUID = accountHandler.getnUserID();
                            DeviceListViewFragment.this.nUserID = nUID;
                            DeviceListViewFragment.this.userInfo.setnUID(nUID);
                            DeviceListViewFragment.this.userInfo.setStrUsername(strUsername);
                            DeviceListViewFragment.this.userInfo.setStrPassword(strPassword);
                            DeviceListViewFragment.this.etDeviceUserName.setText(strUsername);
                            DeviceListViewFragment.this.etDeviceOldPwd.setText(Constants.MAIN_VERSION_TAG);
                            DeviceListViewFragment.this.etDeviceNewPwd.setText(Constants.MAIN_VERSION_TAG);
                            DeviceListViewFragment.this.etDeviceOldConfirm.setText(Constants.MAIN_VERSION_TAG);
                            return;
                        default:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_get_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            DeviceListViewFragment.this.showVisitDeviceInfoLayout();
                            return;
                    }
                } else if (msg.arg1 == 256) {
                    DeviceListViewFragment.this.loadingDialog.dismiss();
                    DeviceListViewFragment.this.btnDeviceInfoSave.setEnabled(true);
                    DeviceListViewFragment.this.showVisitDeviceInfoLayout();
                    DeviceListViewFragment.this.hideEditDevice();
                    switch (msg.arg2) {
                        case ResultCode.RESULT_CODE_FAIL_OLD_VERSON /*-262*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_Old_Version));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_PWD_ERROR /*-261*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_PWDError));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_USER_NOEXIST /*-260*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_UserNoExist));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED /*-259*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_NOPRI));
                            return;
                        case ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL /*-257*/:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_NetError));
                            return;
                        case 256:
                            data = msg.getData();
                            if (data == null) {
                                DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.notice_Result_BadResult), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_BadResult));
                                return;
                            }
                            accountHandler = (AccountInfo) data.get(Defines.RECORD_FILE_RETURN_MESSAGE);
                            String strNewUsername = data.getString("new_user_name");
                            String strNewPassword = data.getString("new_password");
                            DeviceListViewFragment.this.userInfo.setnUID(accountHandler.getnUserID());
                            DeviceListViewFragment.this.userInfo.setStrUsername(strNewUsername);
                            DeviceListViewFragment.this.userInfo.setStrPassword(strNewPassword);
                            if (!(DeviceListViewFragment.this.Editinfo == null || DeviceListViewFragment.this.userInfo == null)) {
                                DeviceListViewFragment.this.Editinfo.setStrUsername(accountHandler.getStrUserName());
                                DeviceListViewFragment.this.Editinfo.setStrPassword(accountHandler.getStrPassword());
                                DatabaseManager.modifyServerInfo(DeviceListViewFragment.this.Editinfo);
                            }
                            ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).ShowNotic(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_ok), Constants.MAIN_VERSION_TAG);
                            return;
                        default:
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.notice_Result_ConnectServerFailed));
                            return;
                    }
                }
            }
        }
    }

    class C03093 implements OnClickListener {
        C03093() {
        }

        public void onClick(View v) {
            if (DeviceListViewFragment.this.bIsSearching) {
                DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                DeviceListViewFragment.this.StopSearchDevice();
            }
            DeviceListViewFragment deviceListViewFragment = DeviceListViewFragment.this;
            deviceListViewFragment.m_nMsgGetThreadID = deviceListViewFragment.m_nMsgGetThreadID + 1;
            DeviceListViewFragment.this.deviceAddDialog.dismiss();
            if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(DeviceListViewFragment.this.getActivity(), "android.permission.ACCESS_COARSE_LOCATION") == 0) {
                DeviceListViewFragment.this.startActivity(new Intent(DeviceListViewFragment.this.getActivity(), SmartLinkQuickWifiConfigActivity.class));
                ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).closeActivity();
                return;
            }
            ActivityCompat.requestPermissions(DeviceListViewFragment.this.relateAtivity, new String[]{"android.permission.ACCESS_COARSE_LOCATION"}, 5);
        }
    }

    class C03104 implements OnClickListener {
        C03104() {
        }

        public void onClick(View v) {
            if (DeviceListViewFragment.this.bIsSearching) {
                DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                DeviceListViewFragment.this.StopSearchDevice();
            }
            DeviceListViewFragment.this.deviceIDAdd();
            DeviceListViewFragment.this.deviceAddDialog.dismiss();
        }
    }

    class C03115 implements OnShowListener {
        C03115() {
        }

        public void onShow(DialogInterface dialog) {
            TextView tv = (TextView) DeviceListViewFragment.this.connectConctentView.findViewById(C0470R.id.loginText);
            if (DeviceListViewFragment.this.mIsSearchingMode) {
                tv.setText(DeviceListViewFragment.this.getString(C0470R.string.searching));
            } else {
                tv.setText(DeviceListViewFragment.this.getString(C0470R.string.loading));
            }
        }
    }

    class C03126 implements OnDismissListener {
        C03126() {
        }

        public void onDismiss(DialogInterface dialog) {
            DeviceListViewFragment deviceListViewFragment;
            if (DeviceListViewFragment.this.mIsSearchingMode) {
                deviceListViewFragment = DeviceListViewFragment.this;
                deviceListViewFragment.m_nSearchID = deviceListViewFragment.m_nSearchID + 1;
                DeviceListViewFragment.this.bIsSearching = false;
            } else {
                deviceListViewFragment = DeviceListViewFragment.this;
                deviceListViewFragment.m_loginID = deviceListViewFragment.m_loginID + 1;
            }
            DeviceListViewFragment.this.mIsSearchingMode = false;
        }
    }

    class C03137 implements OnScrollListener {
        C03137() {
        }

        public void onScrollStateChanged(AbsListView view, int scrollState) {
            if (scrollState == 0) {
                if (LocalDefines._nListMode == 200) {
                    LocalDefines._listviewFisrtPosition = DeviceListViewFragment.this.serverlistView.getFirstVisiblePosition();
                    if (DeviceListViewFragment.this.btnDemo != null) {
                        DeviceListViewFragment.this.btnDemo.setEnabled(true);
                    }
                }
            } else if (scrollState == 1 && DeviceListViewFragment.this.btnDemo != null) {
                DeviceListViewFragment.this.btnDemo.setEnabled(false);
            }
        }

        public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        }
    }

    class C03159 implements OnClickListener {
        C03159() {
        }

        public void onClick(View arg0) {
            if (DeviceListViewFragment.this.bIsSearching) {
                DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                DeviceListViewFragment.this.StopSearchDevice();
            }
            if (VERSION.SDK_INT < 23) {
                DeviceListViewFragment.this.startActivity(new Intent(DeviceListViewFragment.this.getActivity(), CaptureActivity.class));
            } else if (ContextCompat.checkSelfPermission(DeviceListViewFragment.this.getActivity(), "android.permission.CAMERA") != 0) {
                ActivityCompat.requestPermissions(DeviceListViewFragment.this.getActivity(), new String[]{"android.permission.CAMERA"}, 1);
            } else {
                DeviceListViewFragment.this.startActivity(new Intent(DeviceListViewFragment.this.getActivity(), CaptureActivity.class));
            }
        }
    }

    public class AlarmFaceGettingMessageThread extends Thread {
        private Handler mHandler = null;
        private String m_ThreadPassword = "admin";
        private String m_ThreadUsername = "admin";
        private int m_nDeviceID = 0;
        private int nThreadID = 0;

        public AlarmFaceGettingMessageThread(Handler lhandler, int nThreadID, int nDeviceID, String strUsername, String strPassword) {
            this.nThreadID = nThreadID;
            this.mHandler = lhandler;
            this.m_nDeviceID = nDeviceID;
            this.m_ThreadUsername = strUsername;
            this.m_ThreadPassword = strPassword;
        }

        public void run() {
            if (this.m_nDeviceID > 0) {
                JSONObject jsObject = new JSONObject();
                jsObject.put("last_fresh_time", 0);
                jsObject.put("dev_id", this.m_nDeviceID);
                jsObject.put("max_count", 1);
                if (this.m_ThreadUsername == null || this.m_ThreadUsername.length() <= 0) {
                    try {
                        jsObject.put("username", Constants.MAIN_VERSION_TAG);
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }
                } else {
                    jsObject.put("username", this.m_ThreadUsername);
                }
                String requestResult;
                if (this.m_ThreadPassword == null || this.m_ThreadPassword.length() <= 0) {
                    jsObject.put("password", Constants.MAIN_VERSION_TAG);
                    requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strAlarmServerRecv, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_CONNECT_PICTURE).append(jsObject.toString()).toString());
                    if (requestResult != null && requestResult.length() > 0) {
                        try {
                            JSONObject objStr = new JSONObject(requestResult);
                            if (objStr != null) {
                                int result = objStr.getInt("result");
                                String value = objStr.getString("value");
                                if (value != null && value.length() > 0) {
                                    JSONArray jsonArray = new JSONArray(value);
                                    if (0 < jsonArray.length()) {
                                        JSONObject obj = (JSONObject) jsonArray.get(0);
                                        int nTempSaveId = obj.getInt("id");
                                        int nAlarmID = obj.getInt("alarm_id");
                                        int nTempDevID = obj.getInt("dev_id");
                                        int nTempAlarmType = obj.getInt("alarm_type");
                                        int nTempAlarmLevel = obj.getInt("alarm_level");
                                        String strTempAlarmContent = obj.getString("alarm_msg");
                                        String strTempAlarmTime = obj.getString("alarm_time");
                                        String strTempImage = obj.getString("alarm_image");
                                        long lTempLastFreshTime = obj.getLong("last_fresh_time");
                                        Bitmap image = null;
                                        if (strTempImage != null) {
                                            image = Functions.decodeStringtoBitmap(strTempImage);
                                        }
                                        if (image != null) {
                                            Message msg = DeviceListViewFragment.this.handler.obtainMessage();
                                            msg.arg1 = 64;
                                            Bundle data = new Bundle();
                                            data.putInt("dev_id", this.m_nDeviceID);
                                            data.putString("username", this.m_ThreadUsername);
                                            data.putString("password", this.m_ThreadPassword);
                                            data.putParcelable("image", image);
                                            msg.setData(data);
                                            if (this.nThreadID == DeviceListViewFragment.this.m_nMsgGetThreadID) {
                                                DeviceListViewFragment.this.handler.sendMessage(msg);
                                                return;
                                            }
                                            return;
                                        }
                                        return;
                                    }
                                    return;
                                }
                                return;
                            }
                            return;
                        } catch (Exception e) {
                            return;
                        }
                    }
                }
                jsObject.put("password", this.m_ThreadPassword);
                requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strAlarmServerRecv, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_CONNECT_PICTURE).append(jsObject.toString()).toString());
                if (requestResult != null) {
                }
            }
        }
    }

    public class AlarmGettingMessageThread extends Thread {
        private int nThreadID = 0;

        public AlarmGettingMessageThread(Handler mHandler, int nThreadID) {
            this.nThreadID = nThreadID;
        }

        public void run() {
            int i;
            JSONObject obj;
            ServerInfoForAlarm info;
            String strUsername;
            String strPassword;
            JSONArray jsonArray = new JSONArray();
            if (LocalDefines._severInfoListDataForAlarm != null && LocalDefines._severInfoListDataForAlarm.size() > 0) {
                for (i = 0; i < LocalDefines._severInfoListDataForAlarm.size(); i++) {
                    obj = new JSONObject();
                    info = (ServerInfoForAlarm) LocalDefines._severInfoListDataForAlarm.get(i);
                    if (info != null) {
                        int nDevID = info.getnDevID();
                        long lLastFreshTime = info.getlLastMsgFreshTime();
                        strUsername = info.getStrUsername();
                        strPassword = info.getStrPassword();
                        obj.put("last_fresh_time", lLastFreshTime);
                        obj.put("dev_id", nDevID);
                        if (strUsername == null || strUsername.length() <= 0) {
                            obj.put("username", Constants.MAIN_VERSION_TAG);
                        } else {
                            obj.put("username", strUsername);
                        }
                        if (strPassword == null || strPassword.length() <= 0) {
                            try {
                                obj.put("password", Constants.MAIN_VERSION_TAG);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            jsonArray.put(obj);
                        } else {
                            obj.put("password", strPassword);
                            jsonArray.put(obj);
                        }
                    }
                }
            }
            String requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strAlarmServerRecv, LocalDefines._nAlarmPort, new StringBuilder(LocalDefines.JSP_SERVER_CONNECT_MSG).append(jsonArray.toString()).toString());
            if (requestResult != null && requestResult.length() > 0) {
                try {
                    JSONObject objj = new JSONObject(requestResult);
                    if (objj != null && objj.getInt("result") > 0) {
                        JSONArray msgArray = new JSONArray(objj.getString("value"));
                        for (int j = 0; j < msgArray.length(); j++) {
                            obj = (JSONObject) msgArray.get(j);
                            nDevID = obj.getInt("dev_id");
                            int nMsgCount = obj.getInt("msg_count");
                            strUsername = obj.getString("username");
                            strPassword = obj.getString("password");
                            long lNewFreshTime = obj.getLong("last_fresh_time");
                            for (i = 0; i < LocalDefines._severInfoListDataForAlarm.size(); i++) {
                                info = (ServerInfoForAlarm) LocalDefines._severInfoListDataForAlarm.get(i);
                                if (info != null && info.isMatch(nDevID, strUsername, strPassword)) {
                                    nMsgCount += info.getnNewAlarmMsg();
                                    info.setnNewAlarmMsg(nMsgCount);
                                    info.setlLastMsgFreshTime(lNewFreshTime);
                                    Message msg = DeviceListViewFragment.this.handler.obtainMessage();
                                    msg.arg1 = 32;
                                    Bundle data = new Bundle();
                                    data.putInt("dev_id", nDevID);
                                    data.putInt("msg_count", nMsgCount);
                                    data.putString("username", strUsername);
                                    data.putString("password", strPassword);
                                    data.putLong("last_fresh_time", lNewFreshTime);
                                    data.putLong("last_get_time", info.getlLastMsgGetTime());
                                    msg.setData(data);
                                    if (this.nThreadID == DeviceListViewFragment.this.m_nMsgGetThreadID) {
                                        DeviceListViewFragment.this.handler.sendMessage(msg);
                                    }
                                }
                            }
                        }
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    class BindDeviceThread extends Thread {
        private Handler handler;
        private DeviceInfo info;
        private int infoIndex;
        private int m_BindDeviceThreadID;
        private int m_BindWay;
        private int m_DeviceId;
        private String m_DeviceName;
        private String m_DevicePassword;

        public BindDeviceThread(int BindDeviceThreadID, String DeviceName, String DevicePassword, Handler handler, int DeviceId, int BindWay, DeviceInfo info, int infoIndex) {
            this.m_BindDeviceThreadID = BindDeviceThreadID;
            this.handler = handler;
            this.m_DeviceId = DeviceId;
            this.m_DeviceName = DeviceName;
            this.m_DevicePassword = DevicePassword;
            this.m_BindWay = BindWay;
            this.info = info;
            this.infoIndex = infoIndex;
        }

        public void run() {
            super.run();
            if (this.m_BindDeviceThreadID == DeviceListViewFragment.this.n_BindDeviceThreadID) {
                try {
                    DeviceListViewFragment.this.postBindDeviceData(this.m_DeviceId, this.m_DeviceName, this.m_DevicePassword, this.m_BindWay, this.info, this.infoIndex);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = DeviceListViewFragment.BIND_DEVICE_RESULT_CODE;
            msg.arg2 = DeviceListViewFragment.this.bindDevice_result;
            Bundle data = new Bundle();
            data.putParcelable("Bind_info", this.info);
            data.putInt("Bind_index", this.infoIndex);
            msg.setData(data);
            this.handler.sendMessage(msg);
        }
    }

    class BindForSearchDeviceThread extends Thread {
        boolean bHasUpdate = false;
        private int nBindForSearchDeviceId;
        private List<DeviceInfo> searchList;

        public BindForSearchDeviceThread(int m_nBindForSearchDeviceId, List<DeviceInfo> searchList) {
            this.nBindForSearchDeviceId = m_nBindForSearchDeviceId;
            this.searchList = searchList;
        }

        public void run() {
            try {
                if (DeviceListViewFragment.this.m_nBindForSearchDeviceId == this.nBindForSearchDeviceId && this.searchList != null && this.searchList.size() > 0) {
                    final List<DeviceInfo> addList = new ArrayList();
                    for (int i = 0; i < this.searchList.size(); i++) {
                        DeviceInfo info = (DeviceInfo) this.searchList.get(i);
                        if (info.getisSynchronized() != DeviceListViewFragment.this.isNotSynchronized_code || this.searchList.size() <= 1) {
                            info.setnOnLineStat(101);
                            info.setlOnLineStatChaneTime(System.currentTimeMillis());
                        } else {
                            info.setnOnLineStat(102);
                            info.setlOnLineStatChaneTime(System.currentTimeMillis());
                        }
                        if (!(info == null || info.getnDevID() == 0)) {
                            if (DatabaseManager.IsInfoExist(info)) {
                                if (info.getIsAlarmOn() == 0) {
                                    DatabaseManager.UpdateServerInfoState(info);
                                } else {
                                    DatabaseManager.UpdateServerInfoStateWithAlarmState(info);
                                }
                            }
                            this.bHasUpdate = true;
                            String strPassword = Base64.encodeToString(info.getStrPassword().getBytes(), 0);
                            long time = System.currentTimeMillis();
                            String MDLoginSign = LoginActivity.md5("accesstoken=" + DeviceListViewFragment._Token + "&deviceaccount=" + info.getStrUsername() + "&deviceid=" + info.getnDevID() + "&devicepassword=" + strPassword + "&timestamp=" + (time / 1000) + "hsshop2016");
                            JSONObject json = new JSONObject();
                            json.put("sign", MDLoginSign);
                            json.put("timestamp", time / 1000);
                            json.put("accesstoken", DeviceListViewFragment._Token);
                            json.put("deviceid", info.getnDevID());
                            json.put("deviceaccount", info.getStrUsername());
                            json.put("devicepassword", strPassword);
                            String httpResult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/device/bind", json.toString());
                            if (!(httpResult == null || httpResult.length() <= 0 || httpResult.equals("-1"))) {
                                JSONObject jsonObject = new JSONObject(httpResult);
                                if (jsonObject.getInt("result") == 0) {
                                    addList.add(info);
                                    int update_timestamp = jsonObject.getInt("update_timestamp");
                                    DatabaseManager.updateSynchronizedCode(info.getnDevID(), DeviceListViewFragment.this.isSynchronized_code);
                                    DeviceListViewFragment.SaveUpdateDeviceTime(update_timestamp);
                                }
                            }
                        }
                    }
                    if (DeviceListViewFragment.this.m_nBindForSearchDeviceId == this.nBindForSearchDeviceId) {
                        DeviceListViewFragment.this.relateAtivity.runOnUiThread(new Runnable() {
                            public void run() {
                                DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                                if (BindForSearchDeviceThread.this.bHasUpdate) {
                                    LocalDefines.reloadDeviceInfoList();
                                    if (DeviceListViewFragment.this.deviceListItemAdapter != null) {
                                        DeviceListViewFragment.this.deviceListItemAdapter.notifyDataSetChanged();
                                    }
                                }
                                if (addList == null || addList.size() <= 0) {
                                    Toast toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.search_finish), 0);
                                    toast.setGravity(17, 0, 0);
                                    toast.show();
                                } else {
                                    LocalDefines.isDeviceListSet = true;
                                    LocalDefines.nClientDeviceSettingThreadID++;
                                    new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.relateAtivity, LocalDefines.nClientDeviceSettingThreadID).start();
                                }
                                DeviceListViewFragment.this.refleshListView();
                            }
                        });
                    }
                    DeviceListViewFragment deviceListViewFragment = DeviceListViewFragment.this;
                    deviceListViewFragment.n_DeviceListThreadID = deviceListViewFragment.n_DeviceListThreadID + 1;
                    new CheckUserDeviceListThread(DeviceListViewFragment.this.handler, DeviceListViewFragment.this.n_DeviceListThreadID, 0).start();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public class CheckUserDeviceListThread extends Thread {
        private int DeviceListThreadID = 0;
        private int UpdateTimesTamp = 0;
        private Handler handler;

        public CheckUserDeviceListThread(Handler handler, int n_DeviceListThreadID, int m_Updatetimestamp) {
            this.handler = handler;
            this.DeviceListThreadID = n_DeviceListThreadID;
            this.UpdateTimesTamp = m_Updatetimestamp;
        }

        public void run() {
            super.run();
            try {
                if (this.DeviceListThreadID == DeviceListViewFragment.this.n_DeviceListThreadID) {
                    long time = System.currentTimeMillis();
                    String MDLoginSign = LoginActivity.md5("accesstoken=" + DeviceListViewFragment._Token + "&timestamp=" + (time / 1000) + "&updatetimestamp=" + this.UpdateTimesTamp + "hsshop2016");
                    JSONObject json = new JSONObject();
                    json.put("sign", MDLoginSign);
                    json.put("timestamp", time / 1000);
                    json.put("accesstoken", DeviceListViewFragment._Token);
                    json.put("updatetimestamp", this.UpdateTimesTamp);
                    String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/device/list", json.toString());
                    System.out.println("服务器返回设备列表数据 = " + Recresult);
                    int resultCode = -1;
                    if (Recresult != null && Recresult.length() > 0) {
                        if (Recresult.equals("-1")) {
                            resultCode = -1;
                        } else {
                            JSONObject jSONObject = new JSONObject(Recresult);
                            resultCode = Integer.valueOf(jSONObject.getString("result")).intValue();
                            if (resultCode == 0) {
                                JSONArray devicelist_data = new JSONArray(jSONObject.getString("data"));
                                int[] deviceIdlist = new int[devicelist_data.length()];
                                String[] deviceAccountlist = new String[devicelist_data.length()];
                                String[] devicePasswordlist = new String[devicelist_data.length()];
                                int[] productIdList = new int[devicelist_data.length()];
                                for (int i = 0; i < devicelist_data.length(); i++) {
                                    JSONObject temp = (JSONObject) devicelist_data.get(i);
                                    String device_id = temp.getString("device_id");
                                    String device_account = temp.getString("device_account");
                                    String device_password = new String(Base64.decode(temp.getString("device_password").getBytes(), 0));
                                    int productId = temp.getInt("service_id");
                                    deviceIdlist[i] = Integer.valueOf(device_id).intValue();
                                    deviceAccountlist[i] = device_account;
                                    devicePasswordlist[i] = device_password;
                                    productIdList[i] = productId;
                                }
                                DeviceListViewFragment.this.DeviceId_array = deviceIdlist;
                                DeviceListViewFragment.this.DeviceAccount_array = deviceAccountlist;
                                DeviceListViewFragment.this.DevicePassword_array = devicePasswordlist;
                                DeviceListViewFragment.this.DeviceProductId_array = productIdList;
                            }
                        }
                    }
                    if (this.DeviceListThreadID == DeviceListViewFragment.this.n_DeviceListThreadID) {
                        Message message = this.handler.obtainMessage();
                        message.arg1 = DeviceListViewFragment.HANDLE_MSG_CODE_GET_DEVICE_LIST_FROM_NETWORK;
                        message.arg2 = resultCode;
                        this.handler.sendMessage(message);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class DeviceListViewAdapter extends BaseAdapter {
        private ItemViewHolder holder;
        private String[] keyString;
        private int layoutSign;
        private ArrayList<HashMap<String, Object>> mAppList;
        private Context mContext;
        private LayoutInflater mInflater = ((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        private int[] valueViewID;

        private class ItemViewHolder {
            ImageView btnFace;
            ImageView ivCanUpdate;
            ImageView ivCloud;
            ImageView ivDeviceState;
            ImageView ivRedPot;
            LinearLayout llAlarm;
            LinearLayout llCloudStorage;
            LinearLayout llDelete;
            LinearLayout llDeviceState;
            LinearLayout llEdit;
            LinearLayout llMore;
            RelativeLayout llMsg;
            TextView tvCloudStorage;
            TextView tvName;
            TextView tvState;

            private ItemViewHolder() {
            }
        }

        class ListViewButtonListener implements OnClickListener {
            private int listSize;
            private int position;

            ListViewButtonListener(int pos, int listSize) {
                this.position = pos;
                this.listSize = listSize;
            }

            public void onClick(View v) {
                int vid = v.getId();
            }
        }

        private ArrayList<HashMap<String, Object>> getAppList() {
            return this.mAppList;
        }

        public DeviceListViewAdapter(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to, int sign) {
            this.mAppList = appList;
            this.mContext = c;
            this.layoutSign = sign;
            this.keyString = new String[from.length];
            this.valueViewID = new int[to.length];
            System.arraycopy(from, 0, this.keyString, 0, from.length);
            System.arraycopy(to, 0, this.valueViewID, 0, to.length);
        }

        public int getCount() {
            return this.mAppList.size();
        }

        public Object getItem(int position) {
            return this.mAppList.get(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                this.holder = (ItemViewHolder) convertView.getTag();
            } else if (this.layoutSign == 1) {
                convertView = this.mInflater.inflate(C0470R.layout.server_list_item2, null);
                this.holder = new ItemViewHolder();
                this.holder.btnFace = (ImageView) convertView.findViewById(this.valueViewID[0]);
                this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[1]);
                this.holder.tvState = (TextView) convertView.findViewById(this.valueViewID[2]);
                this.holder.llDeviceState = (LinearLayout) convertView.findViewById(this.valueViewID[3]);
                this.holder.llMore = (LinearLayout) convertView.findViewById(this.valueViewID[4]);
                this.holder.ivRedPot = (ImageView) convertView.findViewById(this.valueViewID[5]);
                this.holder.llDelete = (LinearLayout) convertView.findViewById(this.valueViewID[6]);
                this.holder.llEdit = (LinearLayout) convertView.findViewById(this.valueViewID[7]);
                this.holder.llAlarm = (LinearLayout) convertView.findViewById(this.valueViewID[8]);
                this.holder.llMsg = (RelativeLayout) convertView.findViewById(this.valueViewID[9]);
                this.holder.ivDeviceState = (ImageView) convertView.findViewById(this.valueViewID[10]);
                this.holder.llCloudStorage = (LinearLayout) convertView.findViewById(this.valueViewID[11]);
                this.holder.tvCloudStorage = (TextView) convertView.findViewById(this.valueViewID[12]);
                this.holder.ivCloud = (ImageView) convertView.findViewById(this.valueViewID[13]);
                this.holder.ivCanUpdate = (ImageView) convertView.findViewById(this.valueViewID[14]);
                convertView.setTag(this.holder);
            } else {
                convertView = this.mInflater.inflate(C0470R.layout.server_list_item_g, null);
                this.holder = new ItemViewHolder();
                this.holder.btnFace = (ImageView) convertView.findViewById(this.valueViewID[0]);
                this.holder.tvName = (TextView) convertView.findViewById(this.valueViewID[1]);
                this.holder.tvState = (TextView) convertView.findViewById(this.valueViewID[2]);
                this.holder.llDeviceState = (LinearLayout) convertView.findViewById(this.valueViewID[3]);
                this.holder.llMore = (LinearLayout) convertView.findViewById(this.valueViewID[4]);
                this.holder.ivRedPot = (ImageView) convertView.findViewById(this.valueViewID[5]);
                this.holder.llDelete = (LinearLayout) convertView.findViewById(this.valueViewID[6]);
                this.holder.llEdit = (LinearLayout) convertView.findViewById(this.valueViewID[7]);
                this.holder.llAlarm = (LinearLayout) convertView.findViewById(this.valueViewID[8]);
                this.holder.llMsg = (RelativeLayout) convertView.findViewById(this.valueViewID[9]);
                this.holder.ivDeviceState = (ImageView) convertView.findViewById(this.valueViewID[10]);
                this.holder.llCloudStorage = (LinearLayout) convertView.findViewById(this.valueViewID[11]);
                this.holder.tvCloudStorage = (TextView) convertView.findViewById(this.valueViewID[12]);
                this.holder.ivCloud = (ImageView) convertView.findViewById(this.valueViewID[13]);
                this.holder.ivCanUpdate = (ImageView) convertView.findViewById(this.valueViewID[14]);
                convertView.setTag(this.holder);
            }
            if (((HashMap) this.mAppList.get(position)) == null) {
                return convertView;
            }
            DeviceInfo servernfo = null;
            if (LocalDefines._nListMode == 204) {
                if (LocalDefines._demoSeverInfoListData != null && position >= 0 && position < LocalDefines._demoSeverInfoListData.size()) {
                    servernfo = (DeviceInfo) LocalDefines._demoSeverInfoListData.get(position);
                }
            } else if (LocalDefines._severInfoListData != null && position >= 0 && position < LocalDefines._severInfoListData.size()) {
                servernfo = (DeviceInfo) LocalDefines._severInfoListData.get(position);
            }
            if (servernfo == null) {
                return null;
            }
            String name = servernfo.getStrName();
            this.holder.tvName.setVisibility(0);
            this.holder.llMore.setVisibility(0);
            if (name == null || name.length() <= 0) {
                this.holder.tvName.setText(servernfo.getnDevID());
            } else {
                this.holder.tvName.setText(name);
            }
            if (LocalDefines.isZh(DeviceListViewFragment.this.getActivity())) {
                this.holder.llCloudStorage.setVisibility(0);
                this.holder.ivCanUpdate.setImageResource(C0470R.drawable.device_update_txt_zh);
            } else {
                this.holder.llCloudStorage.setVisibility(4);
                this.holder.ivCanUpdate.setImageResource(C0470R.drawable.device_update_txt_en);
            }
            this.holder.llCloudStorage.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    if (HomePageActivity.AppMode != 1) {
                        Toast.makeText(DeviceListViewFragment.this.relateAtivity, DeviceListViewFragment.this.getString(C0470R.string.str_login_to_use_function), 0).show();
                        return;
                    }
                    if (DeviceListViewFragment.this.bIsSearching) {
                        DeviceListViewFragment.this.StopSearchDevice();
                    }
                    Intent intent = new Intent(DeviceListViewFragment.this.getActivity(), CloudStorageActivity.class);
                    intent.putExtra("position", position);
                    intent.putExtra(Constants.FLAG_DEVICE_ID, ((DeviceInfo) LocalDefines._severInfoListData.get(position)).getnDevID());
                    intent.putExtra("productId", ((DeviceInfo) LocalDefines._severInfoListData.get(position)).getnProductId());
                    DeviceListViewFragment.this.startActivity(intent);
                    ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).closeActivity();
                }
            });
            if (servernfo.getnProductId() == 0) {
                this.holder.ivCloud.setBackgroundResource(C0470R.drawable.storage_unbind);
                this.holder.tvCloudStorage.setText(DeviceListViewFragment.this.getString(C0470R.string.str_not_bind_service));
            } else if (servernfo.getnProductId() < 0) {
                this.holder.ivCloud.setBackgroundResource(C0470R.drawable.storage_overdue);
                if (LocalDefines.unbindingServiceFromMail) {
                    this.holder.tvCloudStorage.setText(DeviceListViewFragment.this.getString(C0470R.string.str_unbinding_service));
                } else {
                    this.holder.tvCloudStorage.setText(DeviceListViewFragment.this.getString(C0470R.string.str_service_out_of_date));
                }
            } else {
                this.holder.ivCloud.setBackgroundResource(C0470R.drawable.storage_bind);
                if (LocalDefines.unbindingServiceFromMail) {
                    this.holder.tvCloudStorage.setText(DeviceListViewFragment.this.getString(C0470R.string.str_unbinding_service));
                } else {
                    this.holder.tvCloudStorage.setText(DeviceListViewFragment.this.getString(C0470R.string.str_has_bind_service));
                }
            }
            TextView tv_defend = (TextView) this.holder.llAlarm.findViewById(C0470R.id.tv_defend);
            ImageView iv_defend = (ImageView) this.holder.llAlarm.findViewById(C0470R.id.iv_defend);
            final int isAlarmOn = servernfo.getIsAlarmOn();
            if (isAlarmOn == 2 || isAlarmOn == 20) {
                tv_defend.setText(DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_deactivate));
                iv_defend.setImageResource(C0470R.drawable.device_defending);
            } else if (isAlarmOn == 1 || isAlarmOn == 10 || isAlarmOn == 0) {
                tv_defend.setText(DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_activate));
                iv_defend.setImageResource(C0470R.drawable.btn_position);
            }
            this.holder.llAlarm.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    boolean z = false;
                    Editor alarmList_edit = DeviceListViewFragment.sp_alarmList.edit();
                    try {
                        DeviceListViewFragment.this.Alarmlist = SpSaveList.String2SceneList(DeviceListViewFragment.sp_alarmList.getString("spArea_list_for" + ((DeviceInfo) LocalDefines._severInfoListData.get(position)).getnDevID(), Constants.MAIN_VERSION_TAG));
                        for (int j = 0; j < DeviceListViewFragment.this.Alarmlist.size(); j++) {
                            System.out.println("list2 = " + DeviceListViewFragment.this.Alarmlist.get(j));
                        }
                    } catch (StreamCorruptedException e1) {
                        e1.printStackTrace();
                    } catch (ClassNotFoundException e12) {
                        e12.printStackTrace();
                    } catch (IOException e13) {
                        e13.printStackTrace();
                    }
                    if (DeviceListViewFragment.this.Alarmlist.size() == 0) {
                        for (int i = 0; i < 64; i++) {
                            DeviceListViewFragment.this.Alarmlist.add(i, Integer.valueOf(1));
                        }
                    }
                    try {
                        if (!Functions.isNetworkAvailable(DeviceListViewFragment.this.relateAtivity.getApplicationContext())) {
                            Toast toast = Toast.makeText(DeviceListViewFragment.this.relateAtivity.getApplicationContext(), DeviceListViewFragment.this.getString(C0470R.string.toast_network_unreachable), 0);
                            toast.setGravity(17, 0, 0);
                            toast.show();
                            return;
                        }
                    } catch (Exception e) {
                    }
                    if (isAlarmOn == 2 || isAlarmOn == 20) {
                        DeviceListViewFragment.this.alarmType = true;
                    } else {
                        DeviceListViewFragment.this.alarmType = false;
                    }
                    DeviceListViewFragment.mOneKeyAlarmSettingDialog.show();
                    if (isAlarmOn == 1 || isAlarmOn == 2) {
                        DeviceListViewFragment access$2 = DeviceListViewFragment.this;
                        access$2.m_nOneKeyAlarmSettingID = access$2.m_nOneKeyAlarmSettingID + 1;
                        DeviceListViewFragment access$22 = DeviceListViewFragment.this;
                        DeviceInfo deviceInfo = (DeviceInfo) LocalDefines._severInfoListData.get(position);
                        if (isAlarmOn != 2) {
                            z = true;
                        }
                        new OneKeyAlarmSettingThread(deviceInfo, z, DeviceListViewFragment.this.m_nOneKeyAlarmSettingID, DeviceListViewAdapter.this.holder.llMsg).start();
                        return;
                    }
                    access$2 = DeviceListViewFragment.this;
                    access$2.m_nOneKeyAlarmDeviceAlarmAndPromptSettingID = access$2.m_nOneKeyAlarmDeviceAlarmAndPromptSettingID + 1;
                    DeviceListViewFragment access$23 = DeviceListViewFragment.this;
                    DeviceInfo deviceInfo2 = (DeviceInfo) LocalDefines._severInfoListData.get(position);
                    if (isAlarmOn != 20) {
                        z = true;
                    }
                    new OneKeyAlarmDeviceAlarmAndPromptSettingThread(deviceInfo2, z, DeviceListViewFragment.this.m_nOneKeyAlarmDeviceAlarmAndPromptSettingID).start();
                }
            });
            this.holder.llMsg.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    if (!DeviceListViewFragment.mOneKeyAlarmSettingDialog.isShowing()) {
                        DeviceListViewAdapter.this.holder.ivRedPot.setVisibility(4);
                        DeviceListViewFragment.this.onShowAlarmMessage(position);
                    }
                }
            });
            this.holder.llEdit.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    if (DeviceListViewFragment.this.popupWindowEdit != null && DeviceListViewFragment.this.popupWindowEdit.isShowing()) {
                        DeviceListViewFragment.this.popupWindowEdit.dismiss();
                    }
                    DeviceListViewFragment.this.setEditDevice((DeviceInfo) LocalDefines._severInfoListData.get(position));
                }
            });
            this.holder.llDelete.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(position);
                    DeviceListViewFragment.this.Editinfo = info;
                    if (HomePageActivity.AppMode == 1) {
                        DeviceListViewFragment.this.DeleteDeviceDialog(info, position);
                    } else {
                        DeviceListViewFragment.this.DeleteDeviceDialog(info, position);
                    }
                }
            });
            if (servernfo.getlLastMsgFreshTime() <= 0) {
                this.holder.ivRedPot.setVisibility(4);
            } else if (servernfo.getnNewMsgCount() > 0) {
                this.holder.ivRedPot.setVisibility(0);
            } else {
                this.holder.ivRedPot.setVisibility(4);
            }
            if (LocalDefines._nListMode == 204) {
                this.holder.tvState.setVisibility(8);
                this.holder.llMore.setVisibility(8);
                this.holder.ivDeviceState.setVisibility(8);
                this.holder.llCloudStorage.setVisibility(8);
                this.holder.llDeviceState.setVisibility(8);
            } else {
                int i;
                if (servernfo.getnOnLineStat() == 100) {
                    this.holder.tvState.setText(DeviceListViewFragment.this.getString(C0470R.string.strWanOffline));
                    this.holder.ivDeviceState.setImageResource(C0470R.drawable.offline);
                } else if (servernfo.getnOnLineStat() == 101) {
                    this.holder.tvState.setText(DeviceListViewFragment.this.getString(C0470R.string.strLanOnline));
                    this.holder.ivDeviceState.setImageResource(C0470R.drawable.online);
                } else if (servernfo.getnOnLineStat() == 102) {
                    this.holder.tvState.setText(DeviceListViewFragment.this.getString(C0470R.string.strWanOnline));
                    this.holder.ivDeviceState.setImageResource(C0470R.drawable.online);
                } else {
                    this.holder.tvState.setText(DeviceListViewFragment.this.getString(C0470R.string.strOnlineChecking));
                    this.holder.ivDeviceState.setImageResource(C0470R.drawable.online);
                }
                ImageView imageView = this.holder.ivCanUpdate;
                if (servernfo.isCanUpdateDevice()) {
                    i = 0;
                } else {
                    i = 4;
                }
                imageView.setVisibility(i);
            }
            Bitmap faceImage = servernfo.getFaceImage();
            if (faceImage != null) {
                this.holder.btnFace.setImageDrawable(new BitmapDrawable(faceImage));
                return convertView;
            }
            this.holder.btnFace.setImageDrawable(null);
            return convertView;
        }
    }

    public class DeviceSearchThread extends Thread {
        private int nSearchID = 0;
        private boolean searchReasult = false;

        public DeviceSearchThread(int m_nSearchID) {
            this.nSearchID = m_nSearchID;
        }

        public void run() {
            for (int i = 0; i < 2; i++) {
                DeviceListViewFragment.this.deviceList = DeviceScanner.getDeviceListFromLan();
                if (DeviceListViewFragment.this.deviceList != null && DeviceListViewFragment.this.deviceList.size() > 0 && DeviceListViewFragment.this.m_nSearchID == this.nSearchID) {
                    this.searchReasult = true;
                    Message msg = DeviceListViewFragment.this.handler.obtainMessage();
                    msg.arg1 = 1001;
                    msg.arg2 = 101;
                    DeviceListViewFragment.this.handler.sendMessage(msg);
                    break;
                }
            }
            if (!this.searchReasult && DeviceListViewFragment.this.m_nSearchID == this.nSearchID) {
                msg = DeviceListViewFragment.this.handler.obtainMessage();
                msg.arg1 = 1001;
                msg.arg2 = 102;
                DeviceListViewFragment.this.handler.sendMessage(msg);
            }
        }
    }

    public class GetPreviewDeviceListThread extends Thread {
        static final String strBase64 = "get_priview_device";
        private int nThreadID = 0;

        public GetPreviewDeviceListThread(Handler lhandler, int nThreadID) {
            this.nThreadID = nThreadID;
        }

        public void run() {
            String requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strDeviceDemoServer, LocalDefines._nAlarmPort, "/GetPreviewServer/PreviewSelectServletDeviceInfo?param=get_priview_device");
            if (requestResult == null || requestResult.length() <= 0) {
                requestResult = Functions.GetJsonStringFromServerByHTTP(LocalDefines._strAlarmServerRecv, LocalDefines._nAlarmPort, "/GetAlarmMsg/PreviewSelectServletDeviceInfo?param=get_priview_device");
            }
            Message msg;
            if (requestResult != null && requestResult.length() > 0) {
                int nDeviceCount = 0;
                try {
                    JSONObject objStr = new JSONObject(requestResult);
                    if (objStr != null) {
                        int result = objStr.getInt("result");
                        String value = objStr.getString("devices");
                        if (value != null && value.length() > 0) {
                            JSONArray jSONArray = new JSONArray(value);
                            int j = 0;
                            while (true) {
                                if (j < jSONArray.length()) {
                                    JSONObject obj = (JSONObject) jSONArray.get(j);
                                    String strName = obj.getString("name");
                                    String strNameEn = obj.getString("name_en");
                                    int nDevID = obj.getInt("dev_id");
                                    int nPort = obj.getInt(ClientCookie.PORT_ATTR);
                                    String strUsername = obj.getString("username");
                                    String strPassword = obj.getString("password");
                                    String strMRServer = obj.getString("mrserver");
                                    int nMRPort = obj.getInt("mrport");
                                    String strImage = obj.getString("image");
                                    Bitmap image = null;
                                    if (strImage != null) {
                                        image = Functions.decodeStringtoBitmap(strImage);
                                    }
                                    if (this.nThreadID != DeviceListViewFragment.this.m_nPreviewListGetThreadID) {
                                        break;
                                    }
                                    if (DeviceListViewFragment.this.bLanguage) {
                                        DeviceListViewFragment.this.demoSeverInfoListDataTemp.add(new DeviceInfo(nDeviceCount, nDevID, strName, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), nPort, strUsername, strPassword, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_DEMO, strMRServer, nMRPort, image));
                                    } else {
                                        DeviceListViewFragment.this.demoSeverInfoListDataTemp.add(new DeviceInfo(nDeviceCount, nDevID, strNameEn, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), nPort, strUsername, strPassword, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_DEMO, strMRServer, nMRPort, image));
                                    }
                                    nDeviceCount++;
                                    j++;
                                } else {
                                    break;
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (this.nThreadID == DeviceListViewFragment.this.m_nPreviewListGetThreadID) {
                    msg = DeviceListViewFragment.this.handler.obtainMessage();
                    msg.arg1 = 80;
                    msg.arg2 = 10;
                    DeviceListViewFragment.this.handler.sendMessage(msg);
                }
            } else if (this.nThreadID == DeviceListViewFragment.this.m_nPreviewListGetThreadID) {
                msg = DeviceListViewFragment.this.handler.obtainMessage();
                msg.arg1 = 80;
                msg.arg2 = -11;
                DeviceListViewFragment.this.handler.sendMessage(msg);
            }
        }
    }

    public class IPUpdateThread extends Thread {
        private int nTreadSearchID = 0;

        public IPUpdateThread(int nUpdateID) {
            this.nTreadSearchID = nUpdateID;
        }

        public void run() {
            while (this.nTreadSearchID == DeviceListViewFragment.this.m_nIPUpdateID) {
                if (DeviceListViewFragment.this.relateAtivity == null) {
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        if (!Functions.isNetworkWifi(DeviceListViewFragment.this.relateAtivity.getApplicationContext())) {
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e2) {
                            }
                        } else if (DeviceListViewFragment.this.bIsSearching) {
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e3) {
                            }
                        } else {
                            DeviceListViewFragment.this.deviceIPList = DeviceScanner.getDeviceListFromLan();
                            if (DeviceListViewFragment.this.deviceIPList == null || DeviceListViewFragment.this.deviceIPList.size() <= 0) {
                                try {
                                    Thread.sleep(5000);
                                } catch (InterruptedException e4) {
                                    e4.printStackTrace();
                                }
                            } else if (!DeviceListViewFragment.this.bIsSearching && DeviceListViewFragment.this.m_nIPUpdateID == this.nTreadSearchID) {
                                Message msg = DeviceListViewFragment.this.handler.obtainMessage();
                                msg.arg1 = 1002;
                                msg.arg2 = 101;
                                DeviceListViewFragment.this.handler.sendMessage(msg);
                                return;
                            } else {
                                return;
                            }
                        }
                    } catch (Exception e5) {
                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e6) {
                        }
                    }
                }
            }
        }
    }

    class LoginThread extends Thread {
        private Handler handler;
        private DeviceInfo info = null;
        private int m_ThreadLoginID = 0;
        private int m_nListMode;

        public LoginThread(Handler handler, DeviceInfo info, int nLoginID, int nListMode) {
            this.handler = handler;
            this.info = info;
            this.m_ThreadLoginID = nLoginID;
            this.m_nListMode = nListMode;
        }

        public void run() {
            if (this.m_ThreadLoginID == DeviceListViewFragment.this.m_loginID) {
                LoginHandle deviceParam;
                if (this.info.getnSaveType() == Defines.SERVER_SAVE_TYPE_DEMO) {
                    deviceParam = LoginHelperEX.getDeviceParamEX(this.info, this.info.getStrMRServer(), this.info.getnMRPort());
                    deviceParam.setSetMRServer(true);
                } else {
                    deviceParam = LoginHelperEX.getDeviceParamEX(this.info);
                }
                if (this.m_ThreadLoginID != DeviceListViewFragment.this.m_loginID) {
                    return;
                }
                Message msg;
                if (deviceParam != null && deviceParam.getnResult() == 256) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 16;
                    msg.arg2 = 256;
                    Bundle data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    data.putInt("list_mode", this.m_nListMode);
                    msg.setData(data);
                    this.handler.sendMessage(msg);
                } else if (deviceParam != null) {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 16;
                    msg.arg2 = deviceParam.getnResult();
                    this.handler.sendMessage(msg);
                } else {
                    msg = this.handler.obtainMessage();
                    msg.arg1 = 16;
                    msg.arg2 = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                    this.handler.sendMessage(msg);
                }
            }
        }
    }

    public class OneKeyAlarmDeviceAlarmAndPromptSettingThread extends Thread {
        private DeviceInfo mDevice;
        private boolean mIsAlarm;
        private int nOneKeyAlarmDeviceAlarmAndPromptSettingID = 0;

        public OneKeyAlarmDeviceAlarmAndPromptSettingThread(DeviceInfo deviceInfo, boolean isAlarm, int m_nOneKeyAlarmDeviceAlarmAndPromptSettingID) {
            this.mDevice = deviceInfo;
            this.mIsAlarm = isAlarm;
            this.nOneKeyAlarmDeviceAlarmAndPromptSettingID = m_nOneKeyAlarmDeviceAlarmAndPromptSettingID;
        }

        public void run() {
            AlarmAndPromptInfo alarmAndPromptInfo = new AlarmAndPromptInfo();
            alarmAndPromptInfo.setHasAlarmConfig(true);
            ArrayList<Integer> arealist = new ArrayList();
            for (int i = 0; i < 32; i++) {
                arealist.add(i, Integer.valueOf(1));
            }
            AlarmAndPromptInfo deviceParam = DeviceAlarmAndPromptSetting.setAlarmAndPropmt(this.mDevice, alarmAndPromptInfo.isHasAlarmConfig(), this.mIsAlarm, false, false, false, alarmAndPromptInfo.getnLanguage(), false, alarmAndPromptInfo.getnIOMode(), this.mIsAlarm, 0, 0, 0, 0, 0, 0, 23, 59, 59, 0, 0, 0, 0, 23, 59, 59, 0, 0, 0, 0, 23, 59, 59, DeviceListViewFragment.this.Alarmlist);
            if (deviceParam != null && this.nOneKeyAlarmDeviceAlarmAndPromptSettingID == DeviceListViewFragment.this.m_nOneKeyAlarmDeviceAlarmAndPromptSettingID) {
                Message msg = DeviceListViewFragment.this.handler.obtainMessage();
                msg.arg1 = DeviceListViewFragment.ONE_KEY_ALARM_DEVICE_ALARM_AND_PROMPT_SETTING;
                msg.arg2 = deviceParam.getnResult();
                Bundle data = new Bundle();
                data.putInt("key_device_id", this.mDevice.getnDevID());
                Bundle bundle = data;
                bundle.putBoolean("key_one_key_alarm_state", this.mIsAlarm);
                msg.setData(data);
                DeviceListViewFragment.this.handler.sendMessage(msg);
            }
        }
    }

    public class OneKeyAlarmSettingThread extends Thread {
        private DeviceInfo mDevice;
        private boolean mIsAlarm;
        private int nOneKeyAlarmSettingID = 0;
        private RelativeLayout rl;

        public OneKeyAlarmSettingThread(DeviceInfo deviceInfo, boolean isAlarm, int m_nOneKeyAlarmSettingID, RelativeLayout Rl) {
            this.mDevice = deviceInfo;
            this.mIsAlarm = isAlarm;
            this.nOneKeyAlarmSettingID = m_nOneKeyAlarmSettingID;
            this.rl = Rl;
        }

        public void run() {
            int setOneKeyAlarmResult = DeviceAlarmAndPromptSetting.setOneKeyAlarmSetting(this.mDevice, this.mIsAlarm);
            if (this.nOneKeyAlarmSettingID == DeviceListViewFragment.this.m_nOneKeyAlarmSettingID) {
                Message msg = DeviceListViewFragment.this.handler.obtainMessage();
                msg.arg1 = DeviceListViewFragment.ONE_KEY_ALARM_SETTING;
                msg.arg2 = setOneKeyAlarmResult;
                Bundle data = new Bundle();
                data.putInt("key_device_id", this.mDevice.getnDevID());
                data.putBoolean("key_one_key_alarm_state", this.mIsAlarm);
                msg.setData(data);
                DeviceListViewFragment.this.handler.sendMessage(msg);
            }
        }
    }

    private class OnlineStatCheckThread extends Thread {
        byte[] buffer = new byte[64];
        private Handler handler;
        private int m_nThreadID = 0;

        public OnlineStatCheckThread(Handler handler, int nThreadID) {
            this.handler = handler;
            this.m_nThreadID = nThreadID;
        }

        private OnlineResult getStatFromMR(DeviceInfo info) {
            OnlineResult onlineStat = new OnlineResult();
            onlineStat.setnOnlineStat(10);
            onlineStat.setnReuslt(2001);
            OutputStream writer = null;
            InputStream reader = null;
            Socket sSocket = null;
            int nConfigResultCode = 0;
            if (DeviceListViewFragment.this._nOnlineStatCheckID == this.m_nThreadID) {
                sSocket = Functions.connectToMRServer(null, Defines._OnLinePort, 8000, info.getnDevID());
                if (sSocket != null) {
                    try {
                        if (sSocket.isConnected()) {
                            writer = sSocket.getOutputStream();
                            reader = sSocket.getInputStream();
                        } else {
                            nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                        }
                        if (DeviceListViewFragment.this._nOnlineStatCheckID == this.m_nThreadID && nConfigResultCode == 0) {
                            Arrays.fill(this.buffer, (byte) 0);
                            Functions.IntToBytes((long) LocalDefines.NV_IPC_ONLINE_CHECK_REQUEST, this.buffer, 0);
                            Functions.IntToBytes(1002, this.buffer, 4);
                            if (info.getStrDomain() != null) {
                                System.arraycopy(info.getStrDomain().getBytes(), 0, this.buffer, 8, info.getStrDomain().getBytes().length);
                            }
                            Functions.IntToBytes((long) info.getnPort(), this.buffer, 40);
                            Functions.IntToBytes((long) info.getnDevID(), this.buffer, 44);
                            try {
                                writer.write(this.buffer, 0, 64);
                                writer.flush();
                            } catch (IOException e) {
                                try {
                                    writer.close();
                                    reader.close();
                                } catch (IOException e2) {
                                    e2.printStackTrace();
                                }
                            }
                            Arrays.fill(this.buffer, (byte) 0);
                            boolean bReadOK = false;
                            int i = 0;
                            while (i < 50) {
                                try {
                                    if (reader.available() >= 16) {
                                        reader.read(this.buffer, 0, 16);
                                        bReadOK = true;
                                        break;
                                    }
                                    try {
                                        Thread.sleep(20);
                                    } catch (InterruptedException e3) {
                                        e3.printStackTrace();
                                    }
                                    i++;
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                            if (bReadOK) {
                                onlineStat.setnReuslt(1001);
                                int nResultCmd = Functions.BytesToInt(this.buffer, 0);
                                int nOnlineStat = Functions.BytesToInt(this.buffer, 4);
                                int nAlarmStat = this.buffer[12];
                                info.setCanUpdateDevice(this.buffer[13] == (byte) 2);
                                if (nResultCmd == 272 && Functions.BytesToInt(this.buffer, 8) == info.getnDevID()) {
                                    onlineStat.setnOnlineStat(nOnlineStat);
                                    onlineStat.setnAlarmStat(nAlarmStat);
                                }
                            }
                        }
                    } catch (IOException e4) {
                        System.out.println("服务器连接IO失败");
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e5) {
                            }
                        }
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (IOException e6) {
                            }
                        }
                        if (sSocket != null) {
                            try {
                                sSocket.close();
                            } catch (IOException e7) {
                            }
                        }
                    }
                }
                return onlineStat;
            }
            if (sSocket != null && sSocket.isConnected()) {
                try {
                    sSocket.close();
                } catch (IOException e8) {
                }
            }
            return onlineStat;
        }

        private boolean checkStatFromLan() {
            return false;
        }

        public void run() {
            while (DeviceListViewFragment.this._nOnlineStatCheckID == this.m_nThreadID) {
                if (!(DeviceListViewFragment.this.bIsSearching || LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0)) {
                    DeviceInfo info;
                    if (System.currentTimeMillis() - DeviceListViewFragment.this._lBroadcastTime >= 60000 && checkStatFromLan()) {
                        DeviceListViewFragment.this._lBroadcastTime = System.currentTimeMillis();
                    }
                    int canUpdateDeviceNum = 0;
                    int i = LocalDefines._severInfoListData.size() - 1;
                    while (i >= 0 && DeviceListViewFragment.this._nOnlineStatCheckID == this.m_nThreadID && !DeviceListViewFragment.this.bIsSearching && i < LocalDefines._severInfoListData.size()) {
                        info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                        if (info != null && (System.currentTimeMillis() - info.getlOnLineStatChaneTime() >= 50000 || info.getnOnLineStat() == -1 || info.getnOnLineStat() == 0)) {
                            OnlineResult onlineStat = getStatFromMR(info);
                            int nStat = onlineStat.getnOnlineStat();
                            if (onlineStat.getnAlarmStat() != 0) {
                                info.setIsAlarmOn(onlineStat.getnAlarmStat());
                            }
                            if (System.currentTimeMillis() - info.getlOnLineStatChaneTime() >= 50000) {
                                Message msg;
                                if (nStat != 10) {
                                    if (nStat == 1) {
                                        info.setnOnLineStat(102);
                                    } else if (nStat == 0) {
                                        info.setnOnLineStat(100);
                                    }
                                    info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                    if (DeviceListViewFragment.this._nOnlineStatCheckID == this.m_nThreadID && !DeviceListViewFragment.this.bIsSearching) {
                                        msg = this.handler.obtainMessage();
                                        msg.arg1 = 1200;
                                        msg.arg2 = i;
                                        this.handler.sendMessage(msg);
                                    }
                                } else {
                                    info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                    info.setnOnLineStat(0);
                                    if (DeviceListViewFragment.this._nOnlineStatCheckID == this.m_nThreadID && !DeviceListViewFragment.this.bIsSearching) {
                                        msg = this.handler.obtainMessage();
                                        msg.arg1 = 1200;
                                        msg.arg2 = i;
                                        this.handler.sendMessage(msg);
                                    }
                                }
                            }
                        }
                        i--;
                    }
                    for (i = LocalDefines._severInfoListData.size() - 1; i >= 0; i--) {
                        info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                        if (info != null && info.isCanUpdateDevice()) {
                            canUpdateDeviceNum++;
                        }
                    }
                    ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).setCanUpdateDeviceNum(canUpdateDeviceNum);
                    try {
                        sleep(10000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private class PushUpdateReceiver extends BroadcastReceiver {
        private PushUpdateReceiver() {
        }

        public void onReceive(Context arg0, Intent intent) {
            if (intent != null) {
                Bundle data = intent.getExtras();
                int nDevID = 0;
                long lAlarmTime = 0;
                String strAlarmTitle = Constants.MAIN_VERSION_TAG;
                String strAlarmMsg = Constants.MAIN_VERSION_TAG;
                if (data != null) {
                    try {
                        nDevID = data.getInt(LocalDefines.PUSH_ID);
                        lAlarmTime = data.getLong(LocalDefines.PUSH_TIME);
                        int nAlarmType = data.getInt(LocalDefines.PUSH_TYPE);
                        strAlarmTitle = data.getString(LocalDefines.PUSH_TITLE);
                        strAlarmMsg = data.getString(LocalDefines.PUSH_MSG);
                    } catch (Exception e) {
                    }
                }
                if (LocalDefines._severInfoListData != null && LocalDefines._severInfoListData.size() > 0 && nDevID > 0 && LocalDefines._severInfoListData != null && LocalDefines._severInfoListData.size() > 0) {
                    DeviceInfo deviceInfo = null;
                    int i = LocalDefines._severInfoListData.size() - 1;
                    while (i >= 0 && i < LocalDefines._severInfoListData.size()) {
                        DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                        if (info != null && nDevID == info.getnDevID()) {
                            deviceInfo = info;
                            break;
                        }
                        i--;
                    }
                    if (deviceInfo != null) {
                        String strUsername = deviceInfo.getStrUsername();
                        String strPassword = deviceInfo.getStrPassword();
                        deviceInfo.setlLastMsgFreshTime(lAlarmTime);
                        deviceInfo.setnNewMsgCount(1);
                        DatabaseManager.UpdateServerInfoMsgCount(nDevID, lAlarmTime, deviceInfo.getlLastMsgGetTime(), 1, strUsername, strPassword);
                        new AlarmFaceGettingMessageThread(DeviceListViewFragment.this.handler, DeviceListViewFragment.this.m_nMsgGetThreadID, nDevID, strUsername, strPassword).start();
                    }
                }
            }
        }
    }

    class UnbindDeviceThread extends Thread {
        private Handler handler;
        private int m_DeviceId;
        private int m_UnbindDeviceThreadID;
        private int m_position;

        public UnbindDeviceThread(int UnbindDeviceThreadID, Handler handler, int deviceId, int position) {
            this.m_UnbindDeviceThreadID = UnbindDeviceThreadID;
            this.handler = handler;
            this.m_DeviceId = deviceId;
            this.m_position = position;
        }

        public void run() {
            super.run();
            if (this.m_UnbindDeviceThreadID == DeviceListViewFragment.this.n_UnbindDeviceThreadID) {
                try {
                    DeviceListViewFragment.this.postUnbindDeviceData(this.m_DeviceId, this.m_position);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = DeviceListViewFragment.DELETE_DEVICE_RESULT_CODE;
            this.handler.sendMessage(msg);
        }
    }

    public class UpdateDeviceThread extends Thread {
        private String device_Account;
        private String device_Password;
        private int device_id;
        private Handler handler;
        private boolean isModifyDeviceInfo;
        private int m_UpdataDeviceThreadID = 0;

        public UpdateDeviceThread(int UpdataDeviceThreadID, Handler handler, int deviceid, String deviceAccount, String devicePassword, boolean isModifyDeviceInfo) {
            this.m_UpdataDeviceThreadID = UpdataDeviceThreadID;
            this.handler = handler;
            this.device_id = deviceid;
            this.device_Account = deviceAccount;
            this.device_Password = devicePassword;
            this.isModifyDeviceInfo = isModifyDeviceInfo;
        }

        public void run() {
            super.run();
            try {
                if (this.m_UpdataDeviceThreadID == DeviceListViewFragment.this.n_UpdateDeviceThreadID) {
                    System.out.println("进入线程");
                    DeviceListViewFragment.this.PostUpdateDecviceData(this.device_id, this.device_Account, this.device_Password);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = DeviceListViewFragment.EDIT_DEVICE_RESULT_CODE;
            msg.obj = Boolean.valueOf(this.isModifyDeviceInfo);
            this.handler.sendMessage(msg);
        }
    }

    private class UserConfigThread extends Thread {
        static final int OP_TYPE_GET = 10;
        static final int OP_TYPE_SET = 11;
        DeviceInfo info;
        private String m_newPassword;
        private String m_newUsername;
        private int nOPType;

        public UserConfigThread(DeviceInfo info) {
            this.m_newUsername = "admin";
            this.m_newPassword = "admin";
            this.info = null;
            this.nOPType = 10;
            this.nOPType = 10;
            this.info = info;
        }

        public UserConfigThread(String newUsername, String newPassword, DeviceInfo info) {
            this.m_newUsername = "admin";
            this.m_newPassword = "admin";
            this.info = null;
            this.nOPType = 10;
            this.nOPType = 11;
            this.m_newUsername = newUsername;
            this.m_newPassword = newPassword;
            this.info = info;
        }

        public void run() {
            AccountInfo deviceParam;
            Message msg;
            Bundle data;
            if (this.nOPType == 10) {
                deviceParam = DeviceAccountMessageSetting.getAccountMessage(this.info);
                if (deviceParam != null) {
                    msg = DeviceListViewFragment.this.handler.obtainMessage();
                    msg.arg1 = 144;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    msg.setData(data);
                    DeviceListViewFragment.this.handler.sendMessage(msg);
                }
            } else if (this.nOPType == 11) {
                deviceParam = DeviceAccountMessageSetting.setAccountMessage(this.info, this.m_newUsername, this.m_newPassword, DeviceListViewFragment.this.nUserID);
                if (deviceParam != null) {
                    msg = DeviceListViewFragment.this.handler.obtainMessage();
                    msg.arg1 = 256;
                    msg.arg2 = deviceParam.getnResult();
                    data = new Bundle();
                    data.putParcelable(Defines.RECORD_FILE_RETURN_MESSAGE, deviceParam);
                    data.putString("new_user_name", this.m_newUsername);
                    data.putString("new_password", this.m_newPassword);
                    msg.setData(data);
                    DeviceListViewFragment.this.handler.sendMessage(msg);
                }
            }
        }
    }

    class C08362 implements OnRefreshListener {
        C08362() {
        }

        public void onRefresh() {
            if (LocalDefines._nListMode != 200) {
                DeviceListViewFragment.this.pullToRefreshListView.onRefreshComplete();
            } else if (!DeviceListViewFragment.this.bIsSearching) {
                DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                if (!DeviceListViewFragment.this.StartSearchDevice()) {
                    DeviceListViewFragment.this.pullToRefreshListView.onRefreshComplete();
                }
            }
        }
    }

    public boolean IsEditMode() {
        if (LocalDefines._nListMode == 200) {
            return false;
        }
        return true;
    }

    private void StartIPUpdateThread() {
        this.m_nIPUpdateID++;
        ((HomePageActivity) this.relateAtivity).closeMulticast();
        ((HomePageActivity) this.relateAtivity).openMulticast();
        new IPUpdateThread(this.m_nIPUpdateID).start();
    }

    private void StopIPUpdateThread() {
        this.m_nIPUpdateID++;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        share = getActivity().getSharedPreferences("SaveTimeTamp", 0);
        sp_alarmList = getActivity().getSharedPreferences("scenelist", 0);
        NewLocalTimeTamp = share.getInt("TimeTamp", -101);
        _Token = getActivity().getSharedPreferences("SaveSign", 0).getString("saveToken", Constants.MAIN_VERSION_TAG);
        View v = inflater.inflate(C0470R.layout.activity_nvplayer_serverlist, container, false);
        if (this.relateAtivity == null) {
            this.relateAtivity = getActivity();
        }
        this.contentView = v;
        this.windowManager = (WindowManager) getActivity().getSystemService("window");
        this.width = this.windowManager.getDefaultDisplay().getWidth();
        this.height = this.windowManager.getDefaultDisplay().getHeight();
        getActivity();
        InitSubView();
        createDialogs();
        presentShowcaseSequence();
        LocalDefines.initNoticeSound(this.relateAtivity);
        LocalDefines.loadAlarmSettings(this.relateAtivity);
        if (Locale.getDefault().getLanguage().equals("zh")) {
            this.bLanguage = true;
        } else {
            this.bLanguage = false;
        }
        LocalDefines.reloadDeviceInfoList();
        return v;
    }

    public void onDestroyView() {
        super.onDestroyView();
    }

    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(this.pushUpdateReceiver);
        this.pushUpdateReceiver = null;
        this.m_nPreviewListGetThreadID++;
        this.m_nMsgGetThreadID++;
        StopSearchDevice();
        StopAlarmMsgCheck();
        StopIPUpdateThread();
        stopBindforDeviceThread();
        stopDeviceListThread();
        StopBindDeviceThread();
        shouldUpdateUI = false;
    }

    public void onStart() {
        super.onStart();
    }

    public void onResume() {
        super.onResume();
        shouldUpdateUI = true;
        if (LocalDefines._isQRResultOK) {
            if (LocalDefines._nQRResultDevice > 0 && this.etDeviceIDAdd != null && this.popupWindowAdd != null && this.popupWindowAdd.isShowing()) {
                this.etDeviceIDAdd.setText(LocalDefines._nQRResultDevice);
            }
            LocalDefines._isQRResultOK = false;
            LocalDefines._nQRResultDevice = 0;
        }
        if (this.deviceAddDialog != null && this.deviceAddDialog.isShowing()) {
            this.deviceAddDialog.dismiss();
        }
        if (LocalDefines._isNeedGetPreviewDeviceList) {
            startPreviewListGet();
        }
        StartIPUpdateThread();
        if (LocalDefines.B_UPDATE_LISTVIEW && LocalDefines._nListMode != 204) {
            LocalDefines.B_UPDATE_LISTVIEW = false;
            refleshListView();
        } else if (LocalDefines._nListMode != 204) {
            updateListView();
        }
        if (LocalDefines._nListMode != 204) {
            if (LocalDefines._severInfoListData.size() > 0) {
                this.llDeviceQuickAdd.setVisibility(8);
                this.rlListView.setVisibility(0);
                this.bCheck = true;
            } else {
                this.llDeviceQuickAdd.setVisibility(0);
                this.rlListView.setVisibility(8);
                this.bCheck = false;
            }
        }
        this.pushUpdateReceiver = new PushUpdateReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(LocalDefines.PUSH_RECEIVER);
        this.relateAtivity.registerReceiver(this.pushUpdateReceiver, intentFilter);
        NewLocalTimeTamp = share.getInt("TimeTamp", -101);
        if (HomePageActivity.AppMode == 1 && LocalDefines.shouldLoadUserDeviceList) {
            DeviceInfo[] infoarray = DatabaseManager.GetAllServerInfo();
            if (infoarray != null) {
                this.searchingProgress.setVisibility(0);
                ArrayList<DeviceInfo> list = new ArrayList();
                for (DeviceInfo deviceinfo : infoarray) {
                    if (DatabaseManager.getSynchronizedCode(deviceinfo.getnDevID()) == this.isNotSynchronized_code) {
                        list.add(deviceinfo);
                        this.strDeviceID = deviceinfo.getnDevID();
                    }
                }
                if (list.size() > 0) {
                    this.m_nBindForSearchDeviceId++;
                    new BindForSearchDeviceThread(this.m_nBindForSearchDeviceId, list).start();
                }
            }
            startDeviceListThread();
        }
        if (HomePageActivity.AppMode == 1 && LocalDefines.shouldRefreshDeviceList) {
            LocalDefines.reloadDeviceInfoList();
            updateListView();
            LocalDefines.shouldRefreshDeviceList = false;
        }
    }

    public void onStop() {
        super.onStop();
        this._nOnlineStatCheckID++;
        LocalDefines.B_UPDATE_LISTVIEW = true;
        StopSearchDevice();
        if (this.popup_more != null && this.popup_more.isShowing()) {
            this.popup_more.dismiss();
        }
    }

    public void startPreviewListGet() {
        this.m_nPreviewListGetThreadID++;
        this.demoSeverInfoListDataTemp.clear();
        this.previewListGetThread = new GetPreviewDeviceListThread(this.handler, this.m_nPreviewListGetThreadID);
        this.previewListGetThread.start();
    }

    public void startAlarmMsgCheck() {
        if (LocalDefines.isRecvMsg) {
            this.m_nMsgGetThreadID++;
            this.alarmGettingMessageThread = new AlarmGettingMessageThread(this.handler, this.m_nMsgGetThreadID);
            this.alarmGettingMessageThread.start();
        }
    }

    public void StopAlarmMsgCheck() {
        this.m_nMsgGetThreadID++;
    }

    private void InitSubView() {
        this.pullToRefreshListView = (PullToRefreshListView) this.contentView.findViewById(C0470R.id.pull_refresh_list);
        this.llDeviceHotspot = (LinearLayout) this.contentView.findViewById(C0470R.id.llDeviceHotspot);
        this.llDeviceHotspot.setOnClickListener(this);
        this.llDeviceHotspot.setVisibility(8);
        this.searchingProgress = (ProgressBar) this.contentView.findViewById(C0470R.id.searching_progress);
        this.llDeviceQuickAdd = (FrameLayout) this.contentView.findViewById(C0470R.id.llDeviceQuickConfig);
        this.btnDeviceConfigAdd = (Button) this.contentView.findViewById(C0470R.id.btnDeviceConfigAdd);
        this.btnDeviceConfigAdd.setOnClickListener(this);
        this.btnDeviceQuickAdd = (Button) this.contentView.findViewById(C0470R.id.btnDeviceQuickAdd);
        this.btnDeviceQuickAdd.setOnClickListener(this);
        this.btnDeviceHotspot = (Button) this.contentView.findViewById(C0470R.id.btnAPHotspot);
        this.btnDeviceHotspot.setOnClickListener(this);
        this.btnDeviceHotspot.setVisibility(8);
        this.rlListView = (RelativeLayout) this.contentView.findViewById(C0470R.id.rlListView);
        this.pullToRefreshListView.setOnRefreshListener(new C08362());
        this.ivBack = (ImageView) this.contentView.findViewById(C0470R.id.ivBack);
        this.ivBack.setOnClickListener(this);
        this.btnDemo = (Button) this.contentView.findViewById(C0470R.id.btnDemo);
        this.btnDemo.setOnClickListener(this);
        this.tvTitle = (TextView) this.contentView.findViewById(C0470R.id.tvTitle);
        this.ivDeviceAdd = (ImageView) this.contentView.findViewById(C0470R.id.ivDeviceAdd);
        this.ivDeviceAdd.setOnClickListener(this);
        this.pullToRefreshListView.showBackToTopView(false);
        this.servergridView = (GridView) this.contentView.findViewById(C0470R.id.demo_gridview);
        this.serverlistView = (ListView) this.pullToRefreshListView.getRefreshableView();
        this.serverlistView.setOnItemLongClickListener(this);
        setListviewOnScrollListener();
        this.tvTitle.setText(getString(C0470R.string.myDevice));
        if (LayoutSignnum == 1) {
            this.ivDeviceAdd.setEnabled(true);
            this.ivDeviceAdd.setImageResource(C0470R.drawable.more_function_btn);
            this.serverlistView.setVisibility(0);
            this.servergridView.setVisibility(8);
        }
        if (LayoutSignnum == 2) {
            this.ivDeviceAdd.setImageResource(C0470R.drawable.background_title);
            this.ivDeviceAdd.setEnabled(false);
            this.serverlistView.setVisibility(8);
            this.servergridView.setVisibility(0);
        }
        if (LocalDefines._nListMode == 201) {
            if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() == 0) {
                LocalDefines._nListMode = 200;
                if (this.pullToRefreshListView != null) {
                    this.pullToRefreshListView.showBackToTopView(true);
                    this.pullToRefreshListView.visibleHeaderLayout(true);
                }
                updateListView();
                return;
            }
            LocalDefines._nListMode = 201;
            if (this.pullToRefreshListView != null) {
                this.pullToRefreshListView.showBackToTopView(false);
                this.pullToRefreshListView.visibleHeaderLayout(false);
            }
            updateListView();
        } else if (LocalDefines._nListMode == 200) {
            this.bFirsh = true;
            this.btnDemo.setVisibility(0);
            this.ivBack.setVisibility(8);
            if (LocalDefines.B_UPDATE_LISTVIEW) {
                refleshListView();
                LocalDefines.B_UPDATE_LISTVIEW = false;
            } else {
                updateListView();
            }
            this.ivDeviceAdd.setImageResource(C0470R.drawable.more_function_btn);
        } else if (LocalDefines._nListMode == 204) {
            this.tvTitle.setText(getString(C0470R.string.demoPoint));
            this.bFirsh = false;
            this.btnDemo.setVisibility(8);
            this.ivBack.setVisibility(0);
            showDemonstrateListView();
        }
    }

    private void createDialogs() {
        createConnectingDialog();
        createDeviceAddDialog();
        createOneKeyAlarmSettingDialog();
        createAddDeviceDialog();
    }

    private void createDeviceAddDialog() {
        View deviceAddView = View.inflate(this.relateAtivity, C0470R.layout.dialog_add_device_layout, null);
        ((LinearLayout) deviceAddView.findViewById(C0470R.id.llNoConfigNetwork)).setOnClickListener(new C03093());
        ((LinearLayout) deviceAddView.findViewById(C0470R.id.llConfigNetwork)).setOnClickListener(new C03104());
        this.deviceAddDialog = new Dialog(this.relateAtivity, C0470R.style.device_add_dialog_style);
        this.deviceAddDialog.setContentView(deviceAddView);
        this.deviceAddDialog.setCancelable(true);
        this.deviceAddDialog.setCanceledOnTouchOutside(true);
        this.deviceAddDialog.getWindow().setWindowAnimations(C0470R.style.dialog_add_device_anim);
    }

    private void createConnectingDialog() {
        this.connectConctentView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.connectConctentView.setAlpha(0.775f);
        this.connectingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.connectingDialog.setContentView(this.connectConctentView);
        this.connectingDialog.setOnShowListener(new C03115());
        this.connectingDialog.setOnDismissListener(new C03126());
        this.connectingDialog.setCanceledOnTouchOutside(false);
        this.connectingDialog.setCancelable(true);
    }

    private void setListviewOnScrollListener() {
        if (this.serverlistView != null) {
            this.serverlistView.setOnScrollListener(new C03137());
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View arg1, int nSelectIndex, long arg3) {
        DeviceInfo info;
        if (LocalDefines._nListMode == 200) {
            if (LocalDefines._severInfoListData != null && nSelectIndex >= 0 && nSelectIndex < LocalDefines._severInfoListData.size()) {
                info = (DeviceInfo) LocalDefines._severInfoListData.get(nSelectIndex);
                LocalDefines._PlatbackListviewSelectedPosition = nSelectIndex;
                StartLogin(info, 200);
            }
        } else if (LocalDefines._nListMode == 204) {
            if (LocalDefines._demoSeverInfoListData != null && nSelectIndex >= 0 && nSelectIndex < LocalDefines._demoSeverInfoListData.size()) {
                info = (DeviceInfo) LocalDefines._demoSeverInfoListData.get(nSelectIndex);
                LocalDefines._DemoMRServer = info.getStrMRServer();
                LocalDefines._DemoMRPort = info.getnMRPort();
                StartLogin(info, 204);
            }
        } else if (LocalDefines._nListMode == 201 && LocalDefines._severInfoListData != null && nSelectIndex >= 0 && nSelectIndex < LocalDefines._severInfoListData.size()) {
            DeviceInfo deviceInfo = (DeviceInfo) LocalDefines._severInfoListData.get(nSelectIndex);
        }
    }

    public void ShowServerListMode() {
        if (LocalDefines._nListMode == 204) {
            this.tvTitle.setText(getString(C0470R.string.myDevice));
            LocalDefines._nListMode = 200;
            if (this.pullToRefreshListView != null) {
                this.pullToRefreshListView.showBackToTopView(true);
                this.pullToRefreshListView.visibleHeaderLayout(true);
            }
            refleshListView();
            return;
        }
        showNormalListView();
    }

    public void StartLogin(DeviceInfo info, int nListMode) {
        if (this.bIsSearching) {
            StopSearchDevice();
        }
        if (info != null) {
            try {
                if (!Functions.isNetworkAvailable(this.relateAtivity.getApplicationContext())) {
                    Toast toast = Toast.makeText(this.relateAtivity.getApplicationContext(), getString(C0470R.string.toast_network_unreachable), 0);
                    toast.setGravity(17, 0, 0);
                    toast.show();
                    return;
                }
            } catch (Exception e) {
            }
            this.m_loginID++;
            this.connectingDialog.show();
            if (info.getnSaveType() == Defines.SERVER_SAVE_TYPE_ADD) {
                if (!Functions.isIpAddress(info.getStrIP())) {
                    if (!Functions.hasDot(info.getStrIP())) {
                        info.setStrIP(info.getStrIP() + Defines.MV_DOMAIN_SUFFIX);
                    }
                }
            }
            this.m_strIP = info.getStrIP();
            this.m_nPort = info.getnPort();
            if (info.getStrUsername() == null || info.getStrUsername().length() <= 0) {
                this.m_strUsername = "admin";
                this.m_strPassword = Constants.MAIN_VERSION_TAG;
            } else {
                this.m_strUsername = info.getStrUsername();
                this.m_strPassword = info.getStrPassword();
            }
            this.m_strName = info.getStrName();
            new LoginThread(this.handler, info, this.m_loginID, nListMode).start();
        }
    }

    public void ShowAlert(String title, String msg) {
        if (this.relateAtivity != null) {
            ((HomePageActivity) this.relateAtivity).ShowAlert(title, msg);
        }
    }

    private void showNormalListView() {
        this.tvTitle.setText(getString(C0470R.string.myDevice));
        LocalDefines._nListMode = 200;
        if (this.pullToRefreshListView != null) {
            this.pullToRefreshListView.showBackToTopView(true);
            this.pullToRefreshListView.visibleHeaderLayout(true);
        }
        initAlarmList();
        updateListView();
    }

    private void showDemonstrateListView() {
        if (this.bIsSearching) {
            StopSearchDevice();
        }
        LocalDefines._nListMode = 204;
        this.tvTitle.setText(getString(C0470R.string.demoPoint));
        if (this.pullToRefreshListView != null) {
            this.pullToRefreshListView.showBackToTopView(false);
            this.pullToRefreshListView.visibleHeaderLayout(false);
        }
        updateDemoListView();
    }

    private void onSelectChange() {
        if (LocalDefines._severInfoListData.size() <= 0) {
            Drawable image = getResources().getDrawable(C0470R.drawable.btn_checkbox_normal);
            int y = (this.btnSelectAll.getHeight() - ((int) (((double) this.btnSelectAll.getHeight()) * 0.8d))) / 2;
            this.btnSelectAll.setCompoundDrawablesWithIntrinsicBounds(image, null, null, null);
            this.btnReverSelect.setCompoundDrawablesWithIntrinsicBounds(image, null, null, null);
            return;
        }
        boolean bIsSelectAll = true;
        boolean bDisselectAll = true;
        for (int i = 0; i < LocalDefines._severInfoListData.size(); i++) {
            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
            if (info != null) {
                if (info.isCheck()) {
                    bDisselectAll = false;
                } else {
                    bIsSelectAll = false;
                }
            }
        }
        if (bIsSelectAll) {
            y = (this.btnSelectAll.getHeight() - ((int) (((double) this.btnSelectAll.getHeight()) * 0.8d))) / 2;
            this.btnSelectAll.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(C0470R.drawable.btn_checkbox_check), null, null, null);
        } else {
            y = (this.btnSelectAll.getHeight() - ((int) (((double) this.btnSelectAll.getHeight()) * 0.8d))) / 2;
            this.btnSelectAll.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal), null, null, null);
        }
        if (bDisselectAll) {
            y = (this.btnReverSelect.getHeight() - ((int) (((double) this.btnReverSelect.getHeight()) * 0.8d))) / 2;
            this.btnReverSelect.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(C0470R.drawable.btn_checkbox_check), null, null, null);
            return;
        }
        y = (this.btnReverSelect.getHeight() - ((int) (((double) this.btnReverSelect.getHeight()) * 0.8d))) / 2;
        this.btnReverSelect.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal), null, null, null);
    }

    private void initAlarmList() {
        LocalDefines._severInfoListDataForAlarm.clear();
        if (LocalDefines._severInfoListData.size() > 0) {
            int i = LocalDefines._severInfoListData.size() - 1;
            while (i >= 0 && i < LocalDefines._severInfoListData.size()) {
                DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
                if (info != null && info.getnDevID() > 0) {
                    if (LocalDefines._severInfoListDataForAlarm.size() <= 0) {
                        LocalDefines._severInfoListDataForAlarm.add(new ServerInfoForAlarm(info.getnID(), info.getnDevID(), info.getnNewMsgCount(), info.getStrUsername(), info.getStrPassword(), info.getlLastMsgFreshTime(), info.getlLastMsgGetTime()));
                    } else {
                        boolean isNew = true;
                        for (int j = LocalDefines._severInfoListDataForAlarm.size() - 1; j >= 0; j--) {
                            ServerInfoForAlarm saInfo = (ServerInfoForAlarm) LocalDefines._severInfoListDataForAlarm.get(j);
                            if (saInfo.getnDevID() == info.getnDevID() && saInfo.getStrUsername() == info.getStrUsername() && saInfo.getStrPassword() == info.getStrDomain()) {
                                isNew = false;
                                break;
                            }
                        }
                        if (isNew) {
                            LocalDefines._severInfoListDataForAlarm.add(new ServerInfoForAlarm(info.getnID(), info.getnDevID(), info.getnNewMsgCount(), info.getStrUsername(), info.getStrPassword(), info.getlLastMsgFreshTime(), info.getlLastMsgGetTime()));
                        }
                    }
                }
                i--;
            }
        }
    }

    public void onClick(View v) {
        if (v != null) {
            switch (v.getId()) {
                case C0470R.id.ivBack:
                    this.searchingProgress.setVisibility(8);
                    if (!this.bCheck) {
                        this.rlListView.setVisibility(8);
                        this.llDeviceQuickAdd.setVisibility(0);
                    }
                    this.servergridView.setVisibility(8);
                    this.serverlistView.setVisibility(0);
                    this.bFirsh = true;
                    this.tvTitle.setText(getString(C0470R.string.myDevice));
                    LocalDefines._nListMode = 200;
                    this.ivBack.setVisibility(8);
                    this.btnDemo.setVisibility(0);
                    LayoutSignnum = 1;
                    this.ivDeviceAdd.setEnabled(true);
                    this.ivDeviceAdd.setImageResource(C0470R.drawable.more_function_btn);
                    if (this.pullToRefreshListView != null) {
                        this.pullToRefreshListView.showBackToTopView(true);
                        this.pullToRefreshListView.visibleHeaderLayout(true);
                    }
                    if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
                        refleshListView();
                        return;
                    } else {
                        updateListView();
                        return;
                    }
                case C0470R.id.btnDemo:
                    if (this.bIsSearching) {
                        this.searchingProgress.setVisibility(8);
                        StopSearchDevice();
                    }
                    if (!this.bCheck) {
                        this.rlListView.setVisibility(0);
                        this.llDeviceQuickAdd.setVisibility(8);
                    }
                    this.bFirsh = false;
                    this.servergridView.setVisibility(0);
                    this.serverlistView.setVisibility(8);
                    this.ivBack.setVisibility(0);
                    this.btnDemo.setVisibility(8);
                    LayoutSignnum = 2;
                    LocalDefines._nListMode = 200;
                    showDemonstrateListView();
                    System.out.println("TitleName = " + this.tvTitle.getText().toString());
                    this.ivDeviceAdd.setImageResource(C0470R.drawable.background_title);
                    this.ivDeviceAdd.setEnabled(false);
                    return;
                case C0470R.id.ivDeviceAdd:
                    if (this.bFirsh) {
                        this.deviceAddDialog.show();
                        return;
                    }
                    this.searchingProgress.setVisibility(0);
                    startPreviewListGet();
                    return;
                case C0470R.id.llDeviceHotspot:
                    if (this.bIsSearching) {
                        this.searchingProgress.setVisibility(8);
                        StopSearchDevice();
                    }
                    startActivity(new Intent(getActivity(), DeviceAPConnectActivity.class));
                    ((HomePageActivity) this.relateAtivity).closeActivity();
                    return;
                case C0470R.id.btnDeviceQuickAdd:
                    if (this.bIsSearching) {
                        this.searchingProgress.setVisibility(8);
                        StopSearchDevice();
                    }
                    if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(getActivity(), "android.permission.ACCESS_COARSE_LOCATION") == 0) {
                        startActivity(new Intent(getActivity(), SmartLinkQuickWifiConfigActivity.class));
                        ((HomePageActivity) this.relateAtivity).closeActivity();
                        return;
                    }
                    ActivityCompat.requestPermissions(this.relateAtivity, new String[]{"android.permission.ACCESS_COARSE_LOCATION"}, 5);
                    return;
                case C0470R.id.btnDeviceConfigAdd:
                    if (this.bIsSearching) {
                        this.searchingProgress.setVisibility(8);
                        StopSearchDevice();
                    }
                    this.searchingProgress.setVisibility(0);
                    StartSearchDevice();
                    return;
                case C0470R.id.btnAPHotspot:
                    if (this.bIsSearching) {
                        this.searchingProgress.setVisibility(8);
                        StopSearchDevice();
                    }
                    startActivity(new Intent(getActivity(), DeviceAPConnectActivity.class));
                    ((HomePageActivity) this.relateAtivity).closeActivity();
                    return;
                case C0470R.id.llTWoCodeAdd:
                    if (this.bIsSearching) {
                        this.searchingProgress.setVisibility(8);
                        StopSearchDevice();
                    }
                    startActivity(new Intent(getActivity(), CaptureActivity.class));
                    ((HomePageActivity) this.relateAtivity).closeActivity();
                    return;
                default:
                    return;
            }
        }
    }

    private void deviceIDAdd() {
        if (getActivity() != null) {
            View view = ((LayoutInflater) this.relateAtivity.getSystemService("layout_inflater")).inflate(C0470R.layout.add_id_device_popuwindow, null);
            final View view2 = view;
            ((LinearLayout) view.findViewById(C0470R.id.llViewContent)).setOnTouchListener(new OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    ((InputMethodManager) DeviceListViewFragment.this.getActivity().getSystemService("input_method")).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                    return false;
                }
            });
            LinearLayout llContent = (LinearLayout) view.findViewById(C0470R.id.llcontent);
            this.etDeviceIDAdd = (EditText) view.findViewById(C0470R.id.etDeviceIDAdd);
            final EditText etUserNameAdd = (EditText) view.findViewById(C0470R.id.etUserNameAdd);
            final EditText etPasswordAdd = (EditText) view.findViewById(C0470R.id.etPasswordAdd);
            ImageView ivDeviceAddBack = (ImageView) view.findViewById(C0470R.id.ivDeviceAddBack);
            Button btnDeviceManageAdd = (Button) view.findViewById(C0470R.id.btnDeviceManageAdd);
            Button btnLocalNetWordSeek = (Button) view.findViewById(C0470R.id.btnLocalNetWordSeek);
            ImageView ivQRButton = (ImageView) view.findViewById(C0470R.id.ivQRButton);
            if (VERSION.SDK_INT < 22) {
                Rect frame = new Rect();
                this.relateAtivity.getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
                ((LayoutParams) llContent.getLayoutParams()).setMargins(0, frame.top, 0, 0);
            }
            etUserNameAdd.setText("admin");
            ivQRButton.setOnClickListener(new C03159());
            ivDeviceAddBack.setOnClickListener(new OnClickListener() {
                public void onClick(View arg0) {
                    if (DeviceListViewFragment.this.popupWindowAdd != null) {
                        DeviceListViewFragment.this.popupWindowAdd.dismiss();
                    }
                }
            });
            btnDeviceManageAdd.setOnClickListener(new OnClickListener() {
                public void onClick(View arg0) {
                    DeviceListViewFragment.this.strDeviceID = DeviceListViewFragment.this.etDeviceIDAdd.getText().toString().trim();
                    DeviceListViewFragment.this.strUserName = etUserNameAdd.getText().toString().trim();
                    DeviceListViewFragment.this.strPassword = etPasswordAdd.getText().toString().trim();
                    String Password = Base64.encodeToString(DeviceListViewFragment.this.strPassword.getBytes(), 0);
                    if (DeviceListViewFragment.this.strDeviceID == null || DeviceListViewFragment.this.strDeviceID.length() <= 0 || DeviceListViewFragment.this.strDeviceID.length() > 9) {
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddEditTextInputType), 0).show();
                        return;
                    }
                    int id = Integer.parseInt(DeviceListViewFragment.this.strDeviceID);
                    if (HomePageActivity.AppMode == 1) {
                        DeviceListViewFragment.addDeviceDialog.show();
                        DeviceListViewFragment.this.StartBindDeviceThread(id, DeviceListViewFragment.this.strUserName, Password, 1, null, -1);
                        return;
                    }
                    boolean bResult;
                    DeviceInfo info = new DeviceInfo(-1, id, DeviceListViewFragment.this.strDeviceID, "192.168.1.1", 8800, DeviceListViewFragment.this.strUserName, DeviceListViewFragment.this.strPassword, Constants.MAIN_VERSION_TAG, new StringBuilder(String.valueOf(id)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_ADD);
                    if (DatabaseManager.IsInfoExist(info)) {
                        bResult = DatabaseManager.UpdateServerInfo(info);
                    } else {
                        bResult = DatabaseManager.AddServerInfo(info);
                    }
                    if (bResult) {
                        Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddSucceed), 0).show();
                        DeviceListViewFragment.this.refleshListView();
                        LocalDefines.isDeviceListSet = false;
                        LocalDefines.reloadDeviceInfoList();
                        LocalDefines.nClientDeviceSettingThreadID++;
                        new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
                        if (DeviceListViewFragment.this.popupWindowAdd != null) {
                            DeviceListViewFragment.this.popupWindowAdd.dismiss();
                            return;
                        }
                        return;
                    }
                    Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddFail), 0).show();
                }
            });
            btnLocalNetWordSeek.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    if (DeviceListViewFragment.this.bIsSearching) {
                        DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                        DeviceListViewFragment.this.StopSearchDevice();
                        Log.i("btnLocalNetWordSeek", "========================test btnLocalNetWordSeek=================");
                    }
                    DeviceListViewFragment.this.searchingProgress.setVisibility(0);
                    DeviceListViewFragment.this.StartSearchDevice();
                    DeviceListViewFragment.this.popupWindowAdd.dismiss();
                }
            });
            if (LocalDefines._isQRResultOK) {
                if (LocalDefines._nQRResultDevice > 0) {
                    this.etDeviceIDAdd.setText(LocalDefines._nQRResultDevice);
                }
                LocalDefines._isQRResultOK = false;
                LocalDefines._nQRResultDevice = 0;
            }
            if (-1 < 200) {
                this.popupWindowAdd = new PopupWindow(view, -1, -1);
                this.popupWindowAdd.setFocusable(true);
                this.popupWindowAdd.setOutsideTouchable(true);
                this.popupWindowAdd.setBackgroundDrawable(new ColorDrawable(0));
                this.popupWindowAdd.showAtLocation(view, 0, 0, 0);
                return;
            }
            this.popupWindowAdd = new PopupWindow(view, -1, -1);
            this.popupWindowAdd.setFocusable(true);
            this.popupWindowAdd.setOutsideTouchable(true);
            this.popupWindowAdd.setBackgroundDrawable(new ColorDrawable(0));
            this.popupWindowAdd.showAsDropDown(view);
        }
    }

    private void deviceIDAdd1() {
        View view = ((LayoutInflater) this.relateAtivity.getSystemService("layout_inflater")).inflate(C0470R.layout.add_id_device_popuwindow, null);
        final EditText etDeviceIDAdd = (EditText) view.findViewById(C0470R.id.etDeviceIDAdd);
        final EditText etUserNameAdd = (EditText) view.findViewById(C0470R.id.etUserNameAdd);
        final EditText etPasswordAdd = (EditText) view.findViewById(C0470R.id.etPasswordAdd);
        ImageView ivDeviceAddBack = (ImageView) view.findViewById(C0470R.id.ivDeviceAddBack);
        Button btnDeviceManageAdd = (Button) view.findViewById(C0470R.id.btnDeviceManageAdd);
        ImageView ivQRButton = (ImageView) view.findViewById(C0470R.id.ivQRButton);
        etUserNameAdd.setText("admin");
        ivQRButton.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if (DeviceListViewFragment.this.popupWindowAdd != null) {
                    DeviceListViewFragment.this.popupWindowAdd.dismiss();
                }
                if (DeviceListViewFragment.this.bIsSearching) {
                    DeviceListViewFragment.this.searchingProgress.setVisibility(8);
                    DeviceListViewFragment.this.StopSearchDevice();
                }
                LocalDefines._isQRResultOK = true;
                DeviceListViewFragment.this.startActivity(new Intent(DeviceListViewFragment.this.getActivity(), CaptureActivity.class));
                ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).closeActivity();
            }
        });
        ivDeviceAddBack.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if (DeviceListViewFragment.this.popupWindowAdd != null) {
                    DeviceListViewFragment.this.popupWindowAdd.dismiss();
                }
            }
        });
        btnDeviceManageAdd.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                String strDeviceID = etDeviceIDAdd.getText().toString().trim();
                String strUserName = etUserNameAdd.getText().toString().trim();
                String strPassword = etPasswordAdd.getText().toString().trim();
                if (strDeviceID == null || strDeviceID.length() <= 0 || strDeviceID.length() > 11) {
                    Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddEditTextInputType), 0).show();
                    return;
                }
                boolean bResult;
                int id = Integer.parseInt(strDeviceID);
                DeviceInfo info = new DeviceInfo(-1, id, strDeviceID, "192.168.1.1", 8800, strUserName, strPassword, Constants.MAIN_VERSION_TAG, new StringBuilder(String.valueOf(id)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_ADD);
                if (DatabaseManager.IsInfoExist(info)) {
                    bResult = DatabaseManager.UpdateServerInfo(info);
                } else {
                    bResult = DatabaseManager.AddServerInfo(info);
                }
                if (bResult) {
                    Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddSucceed), 0).show();
                    DeviceListViewFragment.this.refleshListView();
                    LocalDefines.isDeviceListSet = false;
                    LocalDefines.reloadDeviceInfoList();
                    LocalDefines.nClientDeviceSettingThreadID++;
                    new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
                    if (DeviceListViewFragment.this.popupWindowAdd != null) {
                        DeviceListViewFragment.this.popupWindowAdd.dismiss();
                        return;
                    }
                    return;
                }
                Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceAddFail), 0).show();
            }
        });
        if (LocalDefines._isQRResultOK) {
            if (LocalDefines._nQRResultDevice > 0) {
                etDeviceIDAdd.setText(LocalDefines._nQRResultDevice);
            }
            LocalDefines._isQRResultOK = false;
            LocalDefines._nQRResultDevice = 0;
        }
        if (-1 < 200) {
            this.popupWindowAdd = new PopupWindow(view, this.width, this.height);
            this.popupWindowAdd.setFocusable(true);
            this.popupWindowAdd.setOutsideTouchable(true);
            this.popupWindowAdd.setBackgroundDrawable(new ColorDrawable(0));
            this.popupWindowAdd.showAtLocation(view, 0, 0, 0);
            return;
        }
        this.popupWindowAdd = new PopupWindow(view, -1, -1);
        this.popupWindowAdd.setFocusable(true);
        this.popupWindowAdd.setOutsideTouchable(true);
        this.popupWindowAdd.setBackgroundDrawable(new ColorDrawable(0));
        this.popupWindowAdd.showAsDropDown(view);
    }

    private void setEditDelete(View v, final DeviceInfo info, final int index) {
        View view = LayoutInflater.from(getActivity()).inflate(C0470R.layout.popupwind_edit_delete, null);
        Button btnDelete = (Button) view.findViewById(C0470R.id.btnDelete);
        Button btnCancel = (Button) view.findViewById(C0470R.id.btnCancel);
        Button btnAllDelete = (Button) view.findViewById(C0470R.id.btnAllDelete);
        ((Button) view.findViewById(C0470R.id.btnEdit)).setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                DeviceListViewFragment.this.setEditDevice(info);
                if (DeviceListViewFragment.this.popuWindowEditDelete != null) {
                    DeviceListViewFragment.this.popuWindowEditDelete.dismiss();
                }
            }
        });
        btnDelete.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if (DatabaseManager.DeleteServerInfo(info)) {
                    if (index < LocalDefines._severInfoListData.size() && index < LocalDefines._severInfoWithoutImageListData.size()) {
                        LocalDefines._severInfoListData.remove(index);
                        LocalDefines._severInfoWithoutImageListData.remove(index);
                        LocalDefines.isDeviceListSet = false;
                        LocalDefines.nClientDeviceSettingThreadID++;
                        new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
                    }
                    DeviceListViewFragment.this.updateListView();
                    Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceDelete), 0).show();
                } else {
                    Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deleteFail), 0).show();
                }
                if (DeviceListViewFragment.this.popuWindowEditDelete != null) {
                    DeviceListViewFragment.this.popuWindowEditDelete.dismiss();
                }
            }
        });
        btnAllDelete.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                DeviceListViewFragment.this.startActivity(new Intent(DeviceListViewFragment.this.getActivity(), DeviceDeleteActivity.class));
                LocalDefines.B_UPDATE_LISTVIEW = true;
                ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).closeActivity();
                if (DeviceListViewFragment.this.popuWindowEditDelete != null) {
                    DeviceListViewFragment.this.popuWindowEditDelete.dismiss();
                }
            }
        });
        btnCancel.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if (DeviceListViewFragment.this.popuWindowEditDelete != null) {
                    DeviceListViewFragment.this.popuWindowEditDelete.dismiss();
                }
            }
        });
        this.popuWindowEditDelete = new PopupWindow(view, -1, -1);
        this.popuWindowEditDelete.setFocusable(true);
        this.popuWindowEditDelete.setOutsideTouchable(true);
        this.popuWindowEditDelete.setBackgroundDrawable(new BitmapDrawable());
        this.popuWindowEditDelete.showAsDropDown(view);
    }

    private void showVisitDeviceInfoLayout() {
        this.llVisitDeviceInfoLayout.setVisibility(0);
        this.llModifyDeviceInfoLayout.setVisibility(8);
        this.mIsModifyDeviceInfo = false;
    }

    private void showModifyDeviceInfoLayout() {
        this.llVisitDeviceInfoLayout.setVisibility(8);
        this.llModifyDeviceInfoLayout.setVisibility(0);
        this.mIsModifyDeviceInfo = true;
    }

    private void hideEditDevice() {
        if (this.popupWindowEdit != null && this.popupWindowEdit.isShowing()) {
            this.popupWindowEdit.dismiss();
        }
    }

    private void setEditDevice(final DeviceInfo info) {
        this.Editinfo = info;
        View view = ((LayoutInflater) getActivity().getSystemService("layout_inflater")).inflate(C0470R.layout.activity_nvplayer_device_edit, null);
        ImageView ivBack = (ImageView) view.findViewById(C0470R.id.btn_device_edit_cancel);
        TextView tvTitle = (TextView) view.findViewById(C0470R.id.DeviceEditViewTitleText);
        tvTitle.setText(tvTitle.getText() + "(" + info.getnDevID() + ")");
        this.llVisitDeviceInfoLayout = (LinearLayout) view.findViewById(C0470R.id.ll_visit_device_info);
        this.llVisitDeviceInfoLayout.setVisibility(0);
        final TextView etDeviceID = (TextView) view.findViewById(C0470R.id.et_device_edit_dev_id);
        etDeviceID.setText(new StringBuilder(String.valueOf(info.getnDevID())).toString());
        final EditText etDeviceName = (EditText) view.findViewById(C0470R.id.et_device_edit_name);
        final EditText etUserName = (EditText) view.findViewById(C0470R.id.et_device_edit_username);
        final EditText etPassword = (EditText) view.findViewById(C0470R.id.et_device_edit_password);
        this.btnVisitDeviceInfoSave = (Button) view.findViewById(C0470R.id.btn_save_visit_info);
        this.btnModifyDeviceInfo = (Button) view.findViewById(C0470R.id.btn_modify_device_info);
        if (info.getStrName() == null || info.getStrName().length() <= 0) {
            etDeviceName.setText(null);
        } else {
            etDeviceName.setText(info.getStrName());
        }
        etUserName.setText(info.getStrUsername());
        etPassword.setText(info.getStrPassword());
        this.llModifyDeviceInfoLayout = (LinearLayout) view.findViewById(C0470R.id.ll_modify_device_info);
        this.llModifyDeviceInfoLayout.setVisibility(8);
        this.etDeviceUserName = (EditText) view.findViewById(C0470R.id.et_modify_device_username);
        this.etDeviceOldPwd = (EditText) view.findViewById(C0470R.id.et_modify_device_pwd_old);
        this.etDeviceNewPwd = (EditText) view.findViewById(C0470R.id.et_modify_device_pwd_new);
        this.etDeviceOldConfirm = (EditText) view.findViewById(C0470R.id.et_modify_device_pwd_confirm);
        this.btnDeviceInfoSave = (Button) view.findViewById(C0470R.id.btn_modify_device_info_save);
        ivBack.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (DeviceListViewFragment.this.mIsModifyDeviceInfo) {
                    DeviceListViewFragment.this.showVisitDeviceInfoLayout();
                } else {
                    DeviceListViewFragment.this.hideEditDevice();
                }
            }
        });
        final DeviceInfo deviceInfo = info;
        this.btnVisitDeviceInfoSave.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                DeviceListViewFragment.this.hideKeyboard();
                DeviceListViewFragment.this.strName = etDeviceName.getText().toString().trim();
                DeviceListViewFragment.this.strUserName = etUserName.getText().toString().trim();
                DeviceListViewFragment.this.strPassword = etPassword.getText().toString();
                String Password = Base64.encodeToString(DeviceListViewFragment.this.strPassword.getBytes(), 0);
                DeviceListViewFragment.this.strDeviceID = etDeviceID.getText().toString().trim();
                if (DeviceListViewFragment.this.strUserName == null || DeviceListViewFragment.this.strUserName.length() == 0) {
                    DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title), DeviceListViewFragment.this.getString(C0470R.string.notice_UsernameIsNULL));
                } else if (DeviceListViewFragment.this.strDeviceID == null || DeviceListViewFragment.this.strDeviceID.length() == 0) {
                    DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title), DeviceListViewFragment.this.getString(C0470R.string.notice_DevIsNULL));
                } else if (HomePageActivity.AppMode == 1) {
                    DeviceListViewFragment.this.mLoadType = 2;
                    if (DeviceListViewFragment.this.loadingDialog == null) {
                        DeviceListViewFragment.this.createLoadingDialog();
                    }
                    DeviceListViewFragment.this.loadingDialog.show();
                    DeviceListViewFragment.this.btnVisitDeviceInfoSave.setEnabled(false);
                    DeviceListViewFragment.this.btnModifyDeviceInfo.setEnabled(false);
                    DeviceListViewFragment.this.startUpdateDeviceThread(Integer.valueOf(DeviceListViewFragment.this.strDeviceID).intValue(), DeviceListViewFragment.this.strUserName, Password, false);
                } else {
                    int nDeviceID = Integer.valueOf(DeviceListViewFragment.this.strDeviceID).intValue();
                    try {
                        nDeviceID = Integer.parseInt(etDeviceID.getText().toString());
                    } catch (Exception e) {
                    }
                    if (DatabaseManager.modifyServerInfo(new DeviceInfo(deviceInfo.getnID(), nDeviceID, DeviceListViewFragment.this.strName, deviceInfo.getStrIP(), deviceInfo.getnPort(), DeviceListViewFragment.this.strUserName, DeviceListViewFragment.this.strPassword, deviceInfo.getStrDomain(), deviceInfo.getnSaveType(), Constants.MAIN_VERSION_TAG, 0))) {
                        DeviceListViewFragment.this.refleshListView();
                        if (DeviceListViewFragment.this.popupWindowEdit != null) {
                            DeviceListViewFragment.this.popupWindowEdit.dismiss();
                            return;
                        }
                        return;
                    }
                    Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.Edit_Device_Fail), 0).show();
                }
            }
        });
        this.btnModifyDeviceInfo.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                DeviceListViewFragment.this.getUserInfo(info);
            }
        });
        this.btnDeviceInfoSave.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                DeviceListViewFragment.this.hideKeyboard();
                if (DeviceListViewFragment.this.Editinfo != null) {
                    String strUsername;
                    String strNewPassword;
                    if (DeviceListViewFragment.this.mIsModifyDeviceInfo) {
                        strUsername = DeviceListViewFragment.this.etDeviceUserName.getText().toString().trim();
                        strNewPassword = DeviceListViewFragment.this.etDeviceNewPwd.getText().toString().trim();
                        String strConfirm = DeviceListViewFragment.this.etDeviceOldConfirm.getText().toString().trim();
                        String strOldPassword = DeviceListViewFragment.this.etDeviceOldPwd.getText().toString().trim();
                        if (strUsername.compareTo(Constants.MAIN_VERSION_TAG) == 0) {
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title), DeviceListViewFragment.this.getString(C0470R.string.alert_username_is_invalide));
                            return;
                        } else if (strNewPassword.compareTo(strConfirm) != 0) {
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title), DeviceListViewFragment.this.getString(C0470R.string.alert_password_confirm_err));
                            return;
                        } else if (strOldPassword.compareTo(DeviceListViewFragment.this.userInfo.getStrPassword().trim()) != 0) {
                            DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title), DeviceListViewFragment.this.getString(C0470R.string.alert_password_err));
                            return;
                        }
                    }
                    strUsername = DeviceListViewFragment.this.etDeviceUserName.getText().toString().trim();
                    if (strUsername.compareTo(Constants.MAIN_VERSION_TAG) == 0) {
                        DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_title), DeviceListViewFragment.this.getString(C0470R.string.alert_username_is_invalide));
                        return;
                    }
                    strNewPassword = DeviceListViewFragment.this.userInfo.getStrPassword();
                    if (strNewPassword == null && ((DeviceListViewFragment.this.userInfo.getStrPassword() == null || DeviceListViewFragment.this.userInfo.getStrPassword().length() == 0) && strUsername.compareTo(DeviceListViewFragment.this.userInfo.getStrUsername()) == 0)) {
                        DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), Constants.MAIN_VERSION_TAG);
                    } else if (strNewPassword != null && strNewPassword.compareTo(DeviceListViewFragment.this.userInfo.getStrPassword()) == 0 && strUsername.compareTo(DeviceListViewFragment.this.userInfo.getStrUsername()) == 0) {
                        DeviceListViewFragment.this.ShowAlert(DeviceListViewFragment.this.getString(C0470R.string.alert_set_config_fail), DeviceListViewFragment.this.getString(C0470R.string.newPasswordAndOldPassword));
                    } else if (HomePageActivity.AppMode == 1) {
                        DeviceListViewFragment.this.mLoadType = 2;
                        if (DeviceListViewFragment.this.loadingDialog == null) {
                            DeviceListViewFragment.this.createLoadingDialog();
                        }
                        DeviceListViewFragment.this.loadingDialog.show();
                        DeviceListViewFragment.this.btnDeviceInfoSave.setEnabled(false);
                        DeviceListViewFragment.this.startUpdateDeviceThread(DeviceListViewFragment.this.Editinfo.getnDevID(), strUsername, Base64.encodeToString(strNewPassword.getBytes(), 0), true);
                    } else {
                        DeviceListViewFragment.this.setUserInfo(DeviceListViewFragment.this.Editinfo, strUsername, strNewPassword);
                    }
                }
            }
        });
        if (-1 < 200) {
            this.popupWindowEdit = new PopupWindow(view, this.width, this.height);
            this.popupWindowEdit.setFocusable(true);
            this.popupWindowEdit.setOutsideTouchable(true);
            this.popupWindowEdit.setBackgroundDrawable(new BitmapDrawable());
            this.popupWindowEdit.showAtLocation(view, 0, 0, 0);
            return;
        }
        this.popupWindowEdit = new PopupWindow(view, this.width, this.height);
        this.popupWindowEdit.setFocusable(true);
        this.popupWindowEdit.setOutsideTouchable(true);
        this.popupWindowEdit.setBackgroundDrawable(new BitmapDrawable());
        this.popupWindowEdit.showAsDropDown(view);
    }

    public void updateDemoListView() {
        this.bDemoOrDevice = false;
        if (LocalDefines._demoSeverInfoListData == null || LocalDefines._demoSeverInfoListData.size() <= 0) {
            if (this.serverlistView == null) {
                this.serverlistView = (ListView) this.pullToRefreshListView.getRefreshableView();
                setListviewOnScrollListener();
            }
            if (this.serverlistView != null) {
                this.serverlistView.setAdapter(null);
                return;
            }
            return;
        }
        ArrayList<HashMap<String, Object>> listItem2 = new ArrayList();
        for (int i = 0; i < LocalDefines._demoSeverInfoListData.size(); i++) {
            DeviceInfo info = (DeviceInfo) LocalDefines._demoSeverInfoListData.get(i);
            HashMap<String, Object> map = new HashMap();
            map.put("index", Integer.valueOf(i));
            map.put("ID", Integer.valueOf(info.getnID()));
            map.put("DevID", Integer.valueOf(info.getnDevID()));
            map.put("server", info);
            listItem2.add(map);
        }
        this.deviceListItemAdapter = new DeviceListViewAdapter(this.relateAtivity, listItem2, C0470R.layout.server_list_item_g, new String[]{"ItemBtnFace", "ItemTitleName", "ItemTitleID", "ItemLlDeviceState", "ItemTrHomeListing", "ivRedPot", "llDelete", "llEdit", "llAlarm", "llMsg", "ivDeviceState", "llCloudSave", "tvCloudSave", "ivCloud", "ivCanUpdate"}, new int[]{C0470R.id.item_face_G, C0470R.id.ItemTitleName_G, C0470R.id.ItemTitleID_G, C0470R.id.llDeviceState_G, C0470R.id.ll_more, C0470R.id.redpot, C0470R.id.ll_device_delete, C0470R.id.ll_device_edit, C0470R.id.ll_device_alarm, C0470R.id.ll_device_msg, C0470R.id.ivDeviceState_G, C0470R.id.ll_cloud_storage, C0470R.id.tv_cloud_storage, C0470R.id.iv_cloud, C0470R.id.item_iv_device_can_update}, 2);
        if (this.servergridView != null) {
            this.servergridView.setCacheColorHint(0);
            this.servergridView.setAdapter(this.deviceListItemAdapter);
            this.servergridView.setOnItemClickListener(this);
            if (LocalDefines._nListMode != 200 || LocalDefines._listviewFisrtPosition <= 0) {
                this.servergridView.setSelection(0);
            } else {
                this.servergridView.setSelection(LocalDefines._listviewFisrtPosition);
            }
        }
    }

    public void loadDeviceInfoList() {
        LocalDefines.loadDeviceList(false);
        initAlarmList();
    }

    public void updateListView() {
        this.bDemoOrDevice = true;
        if (LocalDefines._severInfoListData == null || LocalDefines._severInfoListData.size() <= 0) {
            if (this.serverlistView == null) {
                this.serverlistView = (ListView) this.pullToRefreshListView.getRefreshableView();
                setListviewOnScrollListener();
            }
            if (this.serverlistView != null) {
                this.serverlistView.setAdapter(null);
                return;
            }
            return;
        }
        ArrayList<HashMap<String, Object>> listItem = new ArrayList();
        int i = LocalDefines._severInfoListData.size() - 1;
        while (i >= 0 && i < LocalDefines._severInfoListData.size()) {
            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(i);
            HashMap<String, Object> map = new HashMap();
            map.put("index", Integer.valueOf(i));
            map.put("ID", Integer.valueOf(info.getnID()));
            map.put("DevID", Integer.valueOf(info.getnDevID()));
            map.put("server", info);
            listItem.add(map);
            i--;
        }
        this.deviceListItemAdapter = new DeviceListViewAdapter(this.relateAtivity, listItem, C0470R.layout.server_list_item2, new String[]{"ItemBtnFace", "ItemTitleName", "ItemTitleID", "ItemLlDeviceState", "ItemTrHomeListing", "ivRedPot", "llDelete", "llEdit", "llAlarm", "llMsg", "ivDeviceState", "llCloudSave", "tvCloudSave", "ivCloud", "ivCanUpdate"}, new int[]{C0470R.id.item_face, C0470R.id.ItemTitleName, C0470R.id.ItemTitleID, C0470R.id.llDeviceState, C0470R.id.ll_more, C0470R.id.redpot, C0470R.id.ll_device_delete, C0470R.id.ll_device_edit, C0470R.id.ll_device_alarm, C0470R.id.ll_device_msg, C0470R.id.ivDeviceState, C0470R.id.ll_cloud_storage, C0470R.id.tv_cloud_storage, C0470R.id.iv_cloud, C0470R.id.item_iv_device_can_update}, 1);
        if (this.serverlistView == null) {
            this.serverlistView = (ListView) this.pullToRefreshListView.getRefreshableView();
            setListviewOnScrollListener();
        }
        if (this.serverlistView != null) {
            this.serverlistView.setCacheColorHint(0);
            this.serverlistView.setAdapter(this.deviceListItemAdapter);
            this.serverlistView.setOnItemClickListener(this);
            if (LocalDefines._nListMode != 200 || LocalDefines._listviewFisrtPosition <= 0) {
                this.serverlistView.setSelection(0);
            } else {
                this.serverlistView.setSelection(LocalDefines._listviewFisrtPosition);
            }
        }
    }

    public void refleshListView() {
        LocalDefines.loadDeviceList(false);
        if (LocalDefines._severInfoListData.size() > 0) {
            this.llDeviceQuickAdd.setVisibility(8);
            this.rlListView.setVisibility(0);
            this.bCheck = true;
        } else {
            this.llDeviceQuickAdd.setVisibility(0);
            this.rlListView.setVisibility(8);
            this.bCheck = false;
        }
        initAlarmList();
        updateListView();
        startAlarmMsgCheck();
        StartOnlineStatCheck();
    }

    public boolean StartSearchDevice() {
        System.out.println("StartSearchDevice");
        try {
            if (Functions.isNetworkAvailable(this.relateAtivity.getApplicationContext())) {
                this.m_nSearchID++;
                this.bIsSearching = true;
                ((HomePageActivity) this.relateAtivity).closeMulticast();
                ((HomePageActivity) this.relateAtivity).openMulticast();
                new DeviceSearchThread(this.m_nSearchID).start();
                return true;
            }
            this.searchingProgress.setVisibility(8);
            this.connectingDialog.dismiss();
            Toast toast = Toast.makeText(this.relateAtivity.getApplicationContext(), getString(C0470R.string.toast_network_unreachable), 0);
            toast.setGravity(17, 0, 0);
            toast.show();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public void StopSearchDevice() {
        ((HomePageActivity) this.relateAtivity).closeMulticast();
        this.bIsSearching = false;
        this.m_nSearchID++;
        this.mIsSearchingMode = false;
        this.pullToRefreshListView.onRefreshComplete();
        if (this.connectingDialog != null) {
            this.connectingDialog.dismiss();
        }
        DeviceScanner.reset();
    }

    public void onDeviceInfoSelectChange(int nIndex, ImageButton imgButton) {
        if (LocalDefines._severInfoListData != null && nIndex >= 0 && nIndex < LocalDefines._severInfoListData.size()) {
            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(nIndex);
            if (info != null) {
                info.setCheck(!info.isCheck());
                if (imgButton != null) {
                    if (info.isCheck()) {
                        imgButton.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_check));
                    } else {
                        imgButton.setBackgroundDrawable(getResources().getDrawable(C0470R.drawable.btn_checkbox_normal));
                    }
                }
            }
        }
        onSelectChange();
    }

    public void onShowAlarmMessage(int nIndex) {
        if (LocalDefines._severInfoListData != null && nIndex >= 0 && nIndex < LocalDefines._severInfoListData.size()) {
            DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(nIndex);
            if (info != null) {
                this.m_nMsgGetThreadID++;
                Intent intent = new Intent(this.relateAtivity, NVAlarmMsgListViewActivity.class);
                Bundle data = new Bundle();
                data.putInt("id", info.getnID());
                data.putInt("device_id", info.getnDevID());
                data.putInt("new_msg_count", info.getnNewMsgCount());
                data.putString("name", info.getStrName());
                data.putString("server", info.getStrIP());
                data.putInt(ClientCookie.PORT_ATTR, info.getnPort());
                data.putString(ClientCookie.DOMAIN_ATTR, info.getStrDomain());
                data.putString("username", info.getStrUsername());
                data.putString("password", info.getStrPassword());
                data.putInt("save_type", info.getnSaveType());
                data.putLong("last_fresh_time", info.getlLastMsgFreshTime());
                data.putLong("last_get_time", info.getlLastMsgGetTime());
                intent.putExtras(data);
                this.relateAtivity.startActivity(intent);
                this.relateAtivity.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                ((HomePageActivity) this.relateAtivity).closeActivity();
            }
        }
    }

    public boolean onItemLongClick(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
        if (HomePageActivity.AppMode != 1) {
            startActivity(new Intent(getActivity(), DeviceDeleteActivity.class));
            LocalDefines.B_UPDATE_LISTVIEW = true;
            ((HomePageActivity) this.relateAtivity).closeActivity();
        }
        return true;
    }

    private void StartOnlineStatCheck() {
        this._nOnlineStatCheckID++;
        new OnlineStatCheckThread(this.handler, this._nOnlineStatCheckID).start();
    }

    private void presentShowcaseSequence() {
        ShowcaseConfig config = new ShowcaseConfig();
        config.setDelay(0);
        MaterialShowcaseSequence sequence = new MaterialShowcaseSequence(getActivity(), "DeviceListFragment");
        MaterialShowcaseView sequenceItem2 = new Builder(getActivity()).setTarget(this.ivDeviceAdd).setContentText(getResources().getString(C0470R.string.str_showcase_fra_devicelist2)).withCircleShape().setDismissOnTouch(true).build();
        sequenceItem2.setContentTextGravity(5);
        sequenceItem2.setTopImage(C0470R.drawable.guide_tr, 5);
        sequence.addSequenceItem(sequenceItem2);
        sequence.setConfig(config);
        sequence.start();
    }

    private void createOneKeyAlarmSettingDialog() {
        final View view = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        view.setAlpha(0.775f);
        mOneKeyAlarmSettingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        mOneKeyAlarmSettingDialog.setContentView(view);
        mOneKeyAlarmSettingDialog.setOnShowListener(new OnShowListener() {
            public void onShow(DialogInterface dialog) {
                TextView tv = (TextView) view.findViewById(C0470R.id.loginText);
                if (DeviceListViewFragment.this.alarmType) {
                    tv.setText(DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_deactivating));
                } else {
                    tv.setText(DeviceListViewFragment.this.getResources().getString(C0470R.string.str_monitor_activating));
                }
            }
        });
        mOneKeyAlarmSettingDialog.setOnDismissListener(new OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
                DeviceListViewFragment deviceListViewFragment = DeviceListViewFragment.this;
                deviceListViewFragment.m_nOneKeyAlarmSettingID = deviceListViewFragment.m_nOneKeyAlarmSettingID + 1;
                deviceListViewFragment = DeviceListViewFragment.this;
                deviceListViewFragment.m_nOneKeyAlarmDeviceAlarmAndPromptSettingID = deviceListViewFragment.m_nOneKeyAlarmDeviceAlarmAndPromptSettingID + 1;
            }
        });
        mOneKeyAlarmSettingDialog.setCanceledOnTouchOutside(false);
        mOneKeyAlarmSettingDialog.setCancelable(false);
    }

    private void createAddDeviceDialog() {
        final View view = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        view.setAlpha(0.775f);
        addDeviceDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        addDeviceDialog.setContentView(view);
        addDeviceDialog.setOnShowListener(new OnShowListener() {
            public void onShow(DialogInterface dialog) {
                ((TextView) view.findViewById(C0470R.id.loginText)).setText(DeviceListViewFragment.this.getResources().getString(C0470R.string.str_adding));
            }
        });
        addDeviceDialog.setOnDismissListener(new OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
            }
        });
        addDeviceDialog.setCanceledOnTouchOutside(false);
        addDeviceDialog.setCancelable(false);
    }

    public void LoadUserDevice(int[] IDarrayData, String[] AccoutarrayData, String[] PasswordarrayData, int[] ProductIdarrayData) {
        if (IDarrayData != null) {
            DeviceInfo[] dbAllDeviceData = DatabaseManager.GetAllServerInfo();
            int i;
            if (dbAllDeviceData == null) {
                for (i = 0; i < IDarrayData.length; i++) {
                    DeviceInfo info = new DeviceInfo(-1, IDarrayData[i], IDarrayData[i], "192.168.1.1", 8800, AccoutarrayData[i], PasswordarrayData[i], Constants.MAIN_VERSION_TAG, IDarrayData[i] + Defines.MV_DOMAIN_SUFFIX, Defines.SERVER_SAVE_TYPE_ADD);
                    info.setnProductId(ProductIdarrayData[i]);
                    DatabaseManager.AddServerInfo(info);
                }
            } else {
                List<DeviceInfo> newDeviceList = new ArrayList();
                for (i = 0; i < IDarrayData.length; i++) {
                    int deviceIdFromNetwork = IDarrayData[i];
                    boolean isSame = false;
                    for (DeviceInfo deviceInfoDb : dbAllDeviceData) {
                        if (deviceIdFromNetwork == deviceInfoDb.getnDevID()) {
                            isSame = true;
                            DeviceInfo deviceInfo = new DeviceInfo(deviceInfoDb.getnID(), deviceInfoDb.getnDevID(), deviceInfoDb.getStrName(), deviceInfoDb.getStrIP(), deviceInfoDb.getnPort(), AccoutarrayData[i], PasswordarrayData[i], IDarrayData[i] + Defines.MV_DOMAIN_SUFFIX, deviceInfoDb.getIsAlarmOn(), deviceInfoDb.getnSaveType(), deviceInfoDb.getlLastMsgFreshTime(), deviceInfoDb.getlLastMsgGetTime(), deviceInfoDb.getnNewMsgCount(), deviceInfoDb.getnOnLineStat(), deviceInfoDb.getlOnLineStatChaneTime(), deviceInfoDb.getFaceImage(), ProductIdarrayData[i]);
                            deviceInfo.setStrMac(deviceInfoDb.getStrMac());
                            newDeviceList.add(deviceInfo);
                            break;
                        }
                    }
                    if (!isSame) {
                        DeviceInfo deviceInfo2 = new DeviceInfo(-1, IDarrayData[i], IDarrayData[i], "192.168.1.1", 8800, AccoutarrayData[i], PasswordarrayData[i], Constants.MAIN_VERSION_TAG, IDarrayData[i] + Defines.MV_DOMAIN_SUFFIX, Defines.SERVER_SAVE_TYPE_ADD);
                        deviceInfo2.setnProductId(ProductIdarrayData[i]);
                        newDeviceList.add(deviceInfo2);
                    }
                }
                DatabaseManager.ClearServerInfo();
                for (i = 0; i < newDeviceList.size(); i++) {
                    DatabaseManager.AddServerInfo((DeviceInfo) newDeviceList.get(i));
                }
            }
            LocalDefines.isDeviceListSet = false;
            LocalDefines.reloadDeviceInfoList();
            refleshListView();
            LocalDefines.nClientDeviceSettingThreadID++;
            new RegistClientWithDeviceArrayToServer(getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
        }
    }

    public void startDeviceListThread() {
        this.n_DeviceListThreadID++;
        new CheckUserDeviceListThread(this.handler, this.n_DeviceListThreadID, NewLocalTimeTamp).start();
    }

    private void stopDeviceListThread() {
        this.n_DeviceListThreadID++;
    }

    private void stopBindforDeviceThread() {
        this.m_nBindForSearchDeviceId++;
    }

    public void startUpdateDeviceThread(int deviceid, String deviceAccount, String devicePassword, boolean isModifyDeviceInfo) {
        this.n_UpdateDeviceThreadID++;
        new UpdateDeviceThread(this.n_UpdateDeviceThreadID, this.handler, deviceid, deviceAccount, devicePassword, isModifyDeviceInfo).start();
    }

    private void PostUpdateDecviceData(int deviceId, String deviceAccount, String devicePassword) throws JSONException {
        long time = System.currentTimeMillis();
        String MDLoginSign = LoginActivity.md5("accesstoken=" + _Token + "&deviceaccount=" + deviceAccount + "&deviceid=" + deviceId + "&devicepassword=" + devicePassword + "&timestamp=" + (time / 1000) + "hsshop2016");
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", time / 1000);
        json.put("accesstoken", _Token);
        json.put("deviceaccount", deviceAccount);
        json.put("deviceid", deviceId);
        json.put("devicepassword", devicePassword);
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/device/update-info", json.toString());
        if (Recresult != null && Recresult.length() > 0) {
            if (Recresult.equals("-1")) {
                this.editDevice_result = -1;
                return;
            }
            JSONObject list_json = new JSONObject(Recresult);
            int result = Integer.valueOf(list_json.getString("result")).intValue();
            this.editDevice_result = result;
            if (result == 0) {
                SaveUpdateDeviceTime(Integer.valueOf(list_json.getString("update_timestamp")).intValue());
            }
        }
    }

    private void PostDeviceInfoData(int UpdateTimesTamp, int n_DeviceListThreadID) throws JSONException {
        long time = System.currentTimeMillis();
        String MDLoginSign = LoginActivity.md5("accesstoken=" + _Token + "&timestamp=" + (time / 1000) + "&updatetimestamp=" + UpdateTimesTamp + "hsshop2016");
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", time / 1000);
        json.put("accesstoken", _Token);
        json.put("updatetimestamp", UpdateTimesTamp);
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/device/list", json.toString());
        System.out.println("服务器返回设备列表数据 = " + Recresult);
        int resultCode = -1;
        if (Recresult != null && Recresult.length() > 0) {
            if (Recresult.equals("-1")) {
                resultCode = -1;
            } else {
                JSONObject jSONObject = new JSONObject(Recresult);
                resultCode = Integer.valueOf(jSONObject.getString("result")).intValue();
                if (resultCode == 0) {
                    JSONArray devicelist_data = new JSONArray(jSONObject.getString("data"));
                    int[] deviceIdlist = new int[devicelist_data.length()];
                    String[] deviceAccountlist = new String[devicelist_data.length()];
                    String[] devicePasswordlist = new String[devicelist_data.length()];
                    int[] productIdList = new int[devicelist_data.length()];
                    for (int i = 0; i < devicelist_data.length(); i++) {
                        JSONObject temp = (JSONObject) devicelist_data.get(i);
                        String device_id = temp.getString("device_id");
                        String device_account = temp.getString("device_account");
                        String device_password = new String(Base64.decode(temp.getString("device_password").getBytes(), 0));
                        int productId = temp.getInt("product_id");
                        deviceIdlist[i] = Integer.valueOf(device_id).intValue();
                        deviceAccountlist[i] = device_account;
                        devicePasswordlist[i] = device_password;
                        productIdList[i] = productId;
                    }
                    this.DeviceId_array = deviceIdlist;
                    this.DeviceAccount_array = deviceAccountlist;
                    this.DevicePassword_array = devicePasswordlist;
                    this.DeviceProductId_array = productIdList;
                }
            }
        }
        Message message = this.handler.obtainMessage();
        message.arg1 = HANDLE_MSG_CODE_GET_DEVICE_LIST_FROM_NETWORK;
        message.arg2 = resultCode;
        this.handler.sendMessage(message);
    }

    static void SaveUpdateDeviceTime(int ServiceTime) {
        Editor editor = share.edit();
        editor.putInt("TimeTamp", ServiceTime);
        editor.commit();
        NewLocalTimeTamp = share.getInt("TimeTamp", -101);
    }

    public void StartBindDeviceThread(int DeviceId, String DeviceName, String DevicePassword, int BindWay, DeviceInfo info, int infoIndex) {
        new BindDeviceThread(this.n_BindDeviceThreadID, DeviceName, DevicePassword, this.handler, DeviceId, BindWay, info, infoIndex).start();
    }

    public void StopBindDeviceThread() {
        this.n_BindDeviceThreadID++;
    }

    public void postBindDeviceData(int DeviceId, String DeviceName, String DevicePassword, int BindWay, DeviceInfo info, int infoIndex) throws JSONException {
        long time = System.currentTimeMillis();
        this.bindDevice_way = BindWay;
        this.Editinfo = info;
        String MDLoginSign = LoginActivity.md5("accesstoken=" + _Token + "&deviceaccount=" + DeviceName + "&deviceid=" + DeviceId + "&devicepassword=" + DevicePassword + "&timestamp=" + (time / 1000) + "hsshop2016");
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", time / 1000);
        json.put("accesstoken", _Token);
        json.put("deviceid", DeviceId);
        json.put("deviceaccount", DeviceName);
        json.put("devicepassword", DevicePassword);
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/device/bind", json.toString());
        System.out.println("绑定设备，服务器返回结果 = " + Recresult);
        if (Recresult != null && Recresult.length() > 0) {
            if (Recresult.equals("-1")) {
                this.bindDevice_result = -1;
                return;
            }
            JSONObject Bindjson = new JSONObject(Recresult);
            int result = Bindjson.getInt("result");
            this.bindDevice_result = Bindjson.getInt("error_code");
            if (result == 0) {
                SaveUpdateDeviceTime(Integer.valueOf(Bindjson.getInt("update_timestamp")).intValue());
            }
        }
    }

    public void startUnbindDeviceThread(int deviceId, int position) {
        this.n_UnbindDeviceThreadID++;
        new UnbindDeviceThread(this.n_UnbindDeviceThreadID, this.handler, deviceId, position).start();
    }

    public void postUnbindDeviceData(int deviceId, int position) throws JSONException {
        long time = System.currentTimeMillis();
        this.deleteDevice_item = position;
        String MDLoginSign = LoginActivity.md5("accesstoken=" + _Token + "&deviceid=" + deviceId + "&timestamp=" + (time / 1000) + "hsshop2016");
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", time / 1000);
        json.put("accesstoken", _Token);
        json.put("deviceid", deviceId);
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/device/unbind", json.toString());
        System.out.println("解绑设备，服务器返回结果 = " + Recresult);
        if (Recresult != null && Recresult.length() > 0) {
            if (Recresult.equals("-1")) {
                this.deleteDevice_result = -1;
                return;
            }
            JSONObject Unbindjson = new JSONObject(Recresult);
            int resultCode = Unbindjson.getInt("result");
            int error_code = Unbindjson.getInt("error_code");
            System.out.println("unbindresult " + resultCode);
            this.deleteDevice_result = error_code;
            if (resultCode == 0) {
                SaveUpdateDeviceTime(Integer.valueOf(Unbindjson.getInt("update_timestamp")).intValue());
            }
        }
    }

    private void httpResult401() {
        View view = View.inflate(getActivity(), C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.str_Notic_Close_APP));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.str_401));
        AlertDialog dialog = new AlertDialog.Builder(getActivity()).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                Editor modeEditor = DeviceListViewFragment.this.getActivity().getSharedPreferences("ShareAPPMODE", 0).edit();
                modeEditor.putInt("GetModeNum", 0);
                modeEditor.commit();
                DeviceListViewFragment.SaveUpdateDeviceTime(0);
                DeviceListViewFragment.this.startActivity(new Intent(DeviceListViewFragment.this.getActivity(), LoginActivity.class));
                ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).closeActivity();
            }
        }).create();
        dialog.setCancelable(false);
        dialog.show();
    }

    public void DeleteDeviceDialog(final DeviceInfo info, final int position) {
        View view = View.inflate(getActivity(), C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(C0470R.string.Delete_device);
        ((TextView) view.findViewById(C0470R.id.tv_content)).setVisibility(8);
        deleteDeviceDialog = new AlertDialog.Builder(getActivity()).setCancelable(false).setView(view).setNegativeButton(getString(C0470R.string.alert_btn_NO), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        }).setPositiveButton(getString(C0470R.string.alert_btn_YES), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                if (HomePageActivity.AppMode == 1) {
                    DeviceListViewFragment.this.searchingProgress.setVisibility(0);
                    DeviceListViewFragment.this.startUnbindDeviceThread(info.getnDevID(), position);
                    return;
                }
                if (DatabaseManager.DeleteServerInfo(info)) {
                    if (position < LocalDefines._severInfoListData.size() && position < LocalDefines._severInfoWithoutImageListData.size()) {
                        LocalDefines._severInfoListData.remove(position);
                        LocalDefines._severInfoWithoutImageListData.remove(position);
                        LocalDefines.isDeviceListSet = false;
                        LocalDefines.nClientDeviceSettingThreadID++;
                        new RegistClientWithDeviceArrayToServer(DeviceListViewFragment.this.getActivity(), LocalDefines.nClientDeviceSettingThreadID).start();
                    }
                    if (info.isCanUpdateDevice()) {
                        ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).setCanUpdateDeviceNum(((HomePageActivity) DeviceListViewFragment.this.relateAtivity).getCanUpdateDeviceNum() - 1);
                    }
                    DeviceListViewFragment.this.updateListView();
                    if (LocalDefines._severInfoListData.size() > 0) {
                        DeviceListViewFragment.this.llDeviceQuickAdd.setVisibility(8);
                        DeviceListViewFragment.this.rlListView.setVisibility(0);
                        DeviceListViewFragment.this.bCheck = true;
                    } else {
                        DeviceListViewFragment.this.llDeviceQuickAdd.setVisibility(0);
                        DeviceListViewFragment.this.rlListView.setVisibility(8);
                        DeviceListViewFragment.this.bCheck = false;
                    }
                    Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deviceDelete), 0).show();
                } else {
                    Toast.makeText(DeviceListViewFragment.this.getActivity(), DeviceListViewFragment.this.getString(C0470R.string.deleteFail), 0).show();
                }
                if (DeviceListViewFragment.this.popuWindowEditDelete != null) {
                    DeviceListViewFragment.this.popuWindowEditDelete.dismiss();
                }
            }
        }).show();
    }

    private void showAlertSafetyDialog(final Bundle data) {
        AlertDialog safetyDialog = new AlertDialog.Builder(getActivity()).setTitle(getActivity().getString(C0470R.string.str_security_notice)).setMessage(getActivity().getString(C0470R.string.str_notice_pwd_need_set)).setPositiveButton(getActivity().getString(C0470R.string.str_permission_setting), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                DeviceInfo info = (DeviceInfo) LocalDefines._severInfoListData.get(LocalDefines._PlatbackListviewSelectedPosition);
                if (info != null) {
                    DeviceListViewFragment.this.setEditDevice(info);
                    DeviceListViewFragment.this.getUserInfo(info);
                }
            }
        }).setNegativeButton(getActivity().getString(C0470R.string.str_permission_neglect), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                data.putString("name", DeviceListViewFragment.this.m_strName);
                data.putString("server", DeviceListViewFragment.this.m_strIP);
                data.putString("username", DeviceListViewFragment.this.m_strUsername);
                data.putString("password", DeviceListViewFragment.this.m_strPassword);
                data.putInt("nPort", DeviceListViewFragment.this.m_nPort);
                DeviceListViewFragment deviceListViewFragment = DeviceListViewFragment.this;
                deviceListViewFragment.m_nMsgGetThreadID = deviceListViewFragment.m_nMsgGetThreadID + 1;
                int camType = ((LoginHandle) data.getParcelable(Defines.RECORD_FILE_RETURN_MESSAGE)).getCamType();
                if (camType == 1 || camType == 2) {
                    Intent intent = new Intent(DeviceListViewFragment.this.relateAtivity, NVPlayerPlayFishEyeActivity.class);
                    intent.putExtras(data);
                    DeviceListViewFragment.this.relateAtivity.startActivity(intent);
                    DeviceListViewFragment.this.relateAtivity.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                    ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).closeActivity();
                    return;
                }
                intent = new Intent(DeviceListViewFragment.this.relateAtivity, NVPlayerPlayActivity.class);
                intent.putExtras(data);
                DeviceListViewFragment.this.relateAtivity.startActivity(intent);
                DeviceListViewFragment.this.relateAtivity.overridePendingTransition(C0470R.anim.zoomin, C0470R.anim.zoomout);
                ((HomePageActivity) DeviceListViewFragment.this.relateAtivity).closeActivity();
            }
        }).create();
        safetyDialog.show();
        final Button btnPositive = safetyDialog.getButton(-1);
        final Button btnNegative = safetyDialog.getButton(-2);
        btnPositive.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case 0:
                        btnNegative.setEnabled(false);
                        break;
                    case 1:
                        btnNegative.setEnabled(true);
                        break;
                }
                return false;
            }
        });
        btnNegative.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case 0:
                        btnPositive.setEnabled(false);
                        break;
                    case 1:
                        btnPositive.setEnabled(true);
                        break;
                }
                return false;
            }
        });
    }

    private void createLoadingDialog() {
        this.loadingView = LayoutInflater.from(this.relateAtivity).inflate(C0470R.layout.logindialog, null);
        this.loadingView.setAlpha(0.775f);
        this.loadingDialog = new Dialog(this.relateAtivity, C0470R.style.selectorDialog);
        this.loadingDialog.setContentView(this.loadingView);
        this.loadingDialog.setOnShowListener(new OnShowListener() {
            public void onShow(DialogInterface dialog) {
                TextView tv = (TextView) DeviceListViewFragment.this.loadingView.findViewById(C0470R.id.loginText);
                if (DeviceListViewFragment.this.mLoadType == 1) {
                    tv.setText(DeviceListViewFragment.this.getString(C0470R.string.loading));
                } else if (DeviceListViewFragment.this.mLoadType == 2) {
                    tv.setText(DeviceListViewFragment.this.getString(C0470R.string.str_saving));
                }
            }
        });
        this.loadingDialog.setOnDismissListener(new OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
            }
        });
        this.loadingDialog.setCanceledOnTouchOutside(false);
        this.loadingDialog.setCancelable(true);
    }

    private void getUserInfo(DeviceInfo info) {
        if (info != null) {
            this.mLoadType = 1;
            if (this.loadingDialog == null) {
                createLoadingDialog();
            }
            this.loadingDialog.show();
            this.btnVisitDeviceInfoSave.setEnabled(false);
            this.btnModifyDeviceInfo.setEnabled(false);
            new UserConfigThread(info).start();
        }
    }

    private void setUserInfo(DeviceInfo info, String strUsername, String strPassword) {
        if (info != null) {
            this.mLoadType = 2;
            if (this.loadingDialog == null) {
                createLoadingDialog();
            }
            this.loadingDialog.show();
            this.btnDeviceInfoSave.setEnabled(false);
            new UserConfigThread(strUsername, strPassword, info).start();
        }
    }

    public void hideKeyboard() {
        if (this.relateAtivity != null) {
            try {
                InputMethodManager imm = (InputMethodManager) this.relateAtivity.getSystemService("input_method");
                if (imm != null) {
                    imm.hideSoftInputFromWindow(this.relateAtivity.getCurrentFocus().getWindowToken(), 2);
                }
            } catch (Exception e) {
            }
        }
    }
}
