package com.macrovideo.v380;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.macrovideo.httptool.HttpUtils;
import com.macrovideo.sdk.defines.Defines;
import java.text.DecimalFormat;
import org.json.JSONException;
import org.json.JSONObject;

public class PersonalInformationActivity extends Activity implements OnClickListener {
    int MailBoxLogin = 2;
    int MobilePhoneLogin = 1;
    private String NewPassword;
    private String NewPassword2;
    final int OLD_PASSWORD_IS_INCORRECT = 21007;
    private String OldPassword;
    final int PASSWORD_EXAMPLAR_IS_INCORRECT = 21004;
    private int SET_PASSWORD_RESULT = 100;
    private Dialog SetNewPwdDlg;
    final int VERIFY_CODE_IS_INCORRECT = 20001;
    final int VERIFY_CODE_IS_OVERTIME = 20002;
    private int VERIFY_CODE_RESULT = LocalDefines.BIND_DEVICE_RESULT_CODE;
    private int Verification_way = 1;
    private Button btn_changeByOldpwd;
    private Button btn_changeByVerify;
    private Button btn_info_newPwd_finish1;
    private Button btn_info_newPwd_finish2;
    private Button btn_info_verifycode;
    private Button btn_set_Pwd;
    private CheckBox check_oldpasswordType;
    private CheckBox check_passwordType;
    private CheckBox check_passwordType2;
    private DialogTimeCount dialog_showtime;
    private int errorResult;
    @SuppressLint({"HandlerLeak"})
    private Handler handler = new C04351();
    private ImageView img_info_phoneOrmail;
    private RelativeLayout info_accout_layout;
    private RelativeLayout info_newPwd2_layout;
    private RelativeLayout info_newPwd_layout;
    private RelativeLayout info_oldPwd_layout;
    private RelativeLayout info_password_layout;
    private LinearLayout info_phone_display_layout;
    private RelativeLayout info_phone_layout;
    private RelativeLayout info_security_layout;
    private ImageView iv_information_back;
    private ImageView iv_information_back2;
    private Dialog lDialog;
    private int loginway = this.MobilePhoneLogin;
    private Dialog mResetDlg;
    private int n_ResetPasswordThreadID = 0;
    private int n_VerifyPasswordThreadID = 0;
    private RelativeLayout newPwd_verify_layout;
    private int oldPassword_way = 2;
    private int resetPwdResult = 0;
    private int resetway = 1;
    private TimeCount time;
    private TextView txt_account_info;
    private EditText txt_info_newPwd;
    private EditText txt_info_newPwd2;
    private EditText txt_info_oldPwd;
    private TextView txt_info_phoneOrmail;
    private TextView txt_info_phone_display;
    private EditText txt_info_verify;
    private int verifycodeResult;

    class C04351 extends Handler {
        C04351() {
        }

        public void handleMessage(Message msg) {
            if (msg.arg1 == PersonalInformationActivity.this.SET_PASSWORD_RESULT) {
                if (PersonalInformationActivity.this.errorResult == 0) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(PersonalInformationActivity.this.errorResult);
                    PersonalInformationActivity.this.btn_info_newPwd_finish1.setEnabled(false);
                } else if (PersonalInformationActivity.this.errorResult == 21007) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(PersonalInformationActivity.this.errorResult);
                } else if (PersonalInformationActivity.this.errorResult == 21004) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(PersonalInformationActivity.this.errorResult);
                } else if (PersonalInformationActivity.this.errorResult == 20001) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(PersonalInformationActivity.this.errorResult);
                } else if (PersonalInformationActivity.this.errorResult == 20002) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(PersonalInformationActivity.this.errorResult);
                } else if (PersonalInformationActivity.this.errorResult == -1) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(PersonalInformationActivity.this.errorResult);
                } else if (PersonalInformationActivity.this.errorResult == 500) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(PersonalInformationActivity.this.errorResult);
                } else if (PersonalInformationActivity.this.errorResult == 401) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.httpResult401();
                } else {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(-101);
                }
            } else if (msg.arg1 != PersonalInformationActivity.this.VERIFY_CODE_RESULT) {
            } else {
                if (msg.arg2 == 0) {
                    PersonalInformationActivity.this.time.start();
                    PersonalInformationActivity.this.info_phone_display_layout.setVisibility(0);
                    PersonalInformationActivity.this.txt_info_phone_display.setText(HomePageActivity.LoginAccount);
                    PersonalInformationActivity.this.btn_info_verifycode.setBackground(PersonalInformationActivity.this.getResources().getDrawable(C0470R.drawable.verification_code));
                    PersonalInformationActivity.this.btn_info_verifycode.setTextColor(Color.parseColor("#666666"));
                } else if (msg.arg2 == -1) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(msg.arg2);
                } else if (msg.arg2 == 401) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.httpResult401();
                } else if (msg.arg2 == 500) {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(msg.arg2);
                } else {
                    PersonalInformationActivity.this.closeResetingDlg();
                    PersonalInformationActivity.this.showResetPwdMessage(-102);
                }
            }
        }
    }

    class C04362 implements OnCheckedChangeListener {
        C04362() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            PersonalInformationActivity.this.setPasswordVisibility(isChecked, 1);
        }
    }

    class C04373 implements OnCheckedChangeListener {
        C04373() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            PersonalInformationActivity.this.setPasswordVisibility(isChecked, 3);
        }
    }

    class C04384 implements OnCheckedChangeListener {
        C04384() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            PersonalInformationActivity.this.setPasswordVisibility(isChecked, 2);
        }
    }

    class C04395 implements OnClickListener {
        C04395() {
        }

        public void onClick(View v) {
            PersonalInformationActivity.this.lDialog.dismiss();
            Toast.makeText(PersonalInformationActivity.this.getApplicationContext(), PersonalInformationActivity.this.getString(C0470R.string.alert_btn_OK), 0).show();
        }
    }

    class C04406 implements OnClickListener {
        C04406() {
        }

        public void onClick(View v) {
            PersonalInformationActivity.this.lDialog.dismiss();
            Toast.makeText(PersonalInformationActivity.this.getApplicationContext(), PersonalInformationActivity.this.getString(C0470R.string.alert_btn_Cancel), 0).show();
        }
    }

    class C04417 implements DialogInterface.OnClickListener {
        C04417() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            Editor modeEditor = PersonalInformationActivity.this.getSharedPreferences("ShareAPPMODE", 0).edit();
            modeEditor.putInt("GetModeNum", 0);
            modeEditor.commit();
            Editor editor = PersonalInformationActivity.this.getSharedPreferences("SaveTimeTamp", 0).edit();
            editor.putInt("TimeTamp", 0);
            editor.commit();
            PersonalInformationActivity.this.startActivity(new Intent(PersonalInformationActivity.this, LoginActivity.class));
            PersonalInformationActivity.this.finish();
            if (LocalDefines.homePageActivity != null) {
                LocalDefines.homePageActivity.closeActivity();
            }
        }
    }

    class DialogTimeCount extends CountDownTimer {
        public DialogTimeCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        public void onFinish() {
            PersonalInformationActivity.this.lDialog.dismiss();
            if (HomePageActivity.AppMode == 1 && PersonalInformationActivity.this.errorResult == 0) {
                PersonalInformationActivity.this.getSharedPreferences("ShareAPPMODE", 0).edit().putInt("GetModeNum", 0).commit();
                HomePageActivity.AppMode = 0;
                PersonalInformationActivity.this.startActivity(new Intent(PersonalInformationActivity.this, LoginActivity.class));
                PersonalInformationActivity.this.finish();
                if (LocalDefines.homePageActivity != null) {
                    LocalDefines.homePageActivity.closeActivity();
                }
            }
        }

        public void onTick(long millisUntilFinished) {
        }
    }

    public class ResetPasswordThread extends Thread {
        private Handler handler;
        private int m_ResetPasswordThreadID = 0;
        private int resetWay;

        public ResetPasswordThread(Handler handler, int n_ResetPWD_ID, int resetWay) {
            this.handler = handler;
            this.m_ResetPasswordThreadID = n_ResetPWD_ID;
            this.resetWay = resetWay;
        }

        public void run() {
            super.run();
            try {
                if (this.m_ResetPasswordThreadID == PersonalInformationActivity.this.n_ResetPasswordThreadID) {
                    PersonalInformationActivity.this.PostResetPasswordData(this.resetWay);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = PersonalInformationActivity.this.SET_PASSWORD_RESULT;
            msg.arg2 = PersonalInformationActivity.this.errorResult;
            this.handler.sendMessage(msg);
        }
    }

    class TimeCount extends CountDownTimer {
        public TimeCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        public void onFinish() {
            PersonalInformationActivity.this.btn_info_verifycode.setText(C0470R.string.str_verify_code);
            PersonalInformationActivity.this.btn_info_verifycode.setClickable(true);
            PersonalInformationActivity.this.btn_info_verifycode.setBackground(PersonalInformationActivity.this.getResources().getDrawable(C0470R.drawable.verification_code_send));
            PersonalInformationActivity.this.btn_info_verifycode.setTextColor(PersonalInformationActivity.this.getResources().getColor(C0470R.color.font_color_sky_blue));
        }

        public void onTick(long millisUntilFinished) {
            PersonalInformationActivity.this.btn_info_verifycode.setClickable(false);
            PersonalInformationActivity.this.btn_info_verifycode.setText((millisUntilFinished / 1000) + "s");
        }
    }

    public class VerifyCodeThread extends Thread {
        private Handler handler;
        private int m_VerifyCodeThreadID = 0;

        public VerifyCodeThread(Handler handler, int VerifyPasswordThreadID) {
            this.m_VerifyCodeThreadID = VerifyPasswordThreadID;
            this.handler = handler;
        }

        public void run() {
            super.run();
            try {
                if (this.m_VerifyCodeThreadID == PersonalInformationActivity.this.n_VerifyPasswordThreadID) {
                    PersonalInformationActivity.this.PostVerifyCodeData();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Message msg = this.handler.obtainMessage();
            msg.arg1 = PersonalInformationActivity.this.VERIFY_CODE_RESULT;
            msg.arg2 = PersonalInformationActivity.this.errorResult;
            this.handler.sendMessage(msg);
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0470R.layout.activity_perosonal_information);
        initView();
    }

    public void initView() {
        this.time = new TimeCount(60000, 1000);
        this.dialog_showtime = new DialogTimeCount(2000, 1000);
        initLoginingDlg();
        this.info_phone_display_layout = (LinearLayout) findViewById(C0470R.id.info_phone_display_layout);
        this.newPwd_verify_layout = (RelativeLayout) findViewById(C0470R.id.newPwd_verify_layout);
        this.info_phone_layout = (RelativeLayout) findViewById(C0470R.id.info_phone_layout);
        this.info_newPwd_layout = (RelativeLayout) findViewById(C0470R.id.info_newPwd_layout);
        this.info_accout_layout = (RelativeLayout) findViewById(C0470R.id.info_accout_layout);
        this.info_security_layout = (RelativeLayout) findViewById(C0470R.id.info_security_layout);
        this.info_password_layout = (RelativeLayout) findViewById(C0470R.id.info_password_layout);
        this.info_oldPwd_layout = (RelativeLayout) findViewById(C0470R.id.info_oldPwd_layout);
        this.info_newPwd2_layout = (RelativeLayout) findViewById(C0470R.id.info_newPwd2_layout);
        this.btn_set_Pwd = (Button) findViewById(C0470R.id.btn_set_newPwd);
        this.btn_set_Pwd.setOnClickListener(this);
        this.txt_info_phone_display = (TextView) findViewById(C0470R.id.txt_info_phone_display);
        this.txt_account_info = (TextView) findViewById(C0470R.id.txt_account_info);
        this.txt_info_phoneOrmail = (TextView) findViewById(C0470R.id.txt_info_phoneOrmail);
        this.img_info_phoneOrmail = (ImageView) findViewById(C0470R.id.img_info_phoneOrmail);
        this.iv_information_back = (ImageView) findViewById(C0470R.id.iv_information_back);
        this.iv_information_back.setOnClickListener(this);
        this.iv_information_back2 = (ImageView) findViewById(C0470R.id.iv_information_back2);
        this.iv_information_back2.setOnClickListener(this);
        this.check_passwordType = (CheckBox) findViewById(C0470R.id.check_passwordType);
        this.check_passwordType.setOnCheckedChangeListener(new C04362());
        this.check_oldpasswordType = (CheckBox) findViewById(C0470R.id.check_oldpasswordType);
        this.check_oldpasswordType.setOnCheckedChangeListener(new C04373());
        this.check_passwordType2 = (CheckBox) findViewById(C0470R.id.check_passwordType2);
        this.check_passwordType2.setOnCheckedChangeListener(new C04384());
        this.txt_info_newPwd = (EditText) findViewById(C0470R.id.txt_info_newPwd);
        this.txt_info_verify = (EditText) findViewById(C0470R.id.txt_info_verify);
        this.txt_info_oldPwd = (EditText) findViewById(C0470R.id.txt_info_oldPwd);
        this.txt_info_newPwd2 = (EditText) findViewById(C0470R.id.txt_info_newPwd2);
        this.btn_info_verifycode = (Button) findViewById(C0470R.id.btn_info_verifycode);
        this.btn_info_verifycode.setOnClickListener(this);
        this.btn_info_newPwd_finish1 = (Button) findViewById(C0470R.id.btn_info_newPwd_finish1);
        this.btn_info_newPwd_finish1.setOnClickListener(this);
        this.btn_info_newPwd_finish2 = (Button) findViewById(C0470R.id.btn_info_newPwd_finish2);
        this.btn_info_newPwd_finish2.setOnClickListener(this);
        this.loginway = getIntent().getIntExtra("Login_Way", -1);
        System.out.println("登录方式" + this.loginway);
        if (this.loginway == this.MobilePhoneLogin) {
            this.img_info_phoneOrmail.setBackground(getResources().getDrawable(C0470R.drawable.icon_phone));
            this.txt_account_info.setText(HomePageActivity.LoginAccount);
            this.txt_info_phoneOrmail.setText(C0470R.string.str_mobile_phone);
        }
        if (this.loginway == this.MailBoxLogin) {
            this.img_info_phoneOrmail.setBackground(getResources().getDrawable(C0470R.drawable.icon_mailbox));
            this.txt_account_info.setText(HomePageActivity.LoginAccount);
            this.txt_info_phoneOrmail.setText(C0470R.string.Mailbox);
        }
    }

    public void onClick(View v) {
        if (v == this.btn_set_Pwd) {
            initSetNewPwdDlg();
        } else if (v == this.iv_information_back) {
            finish();
        } else if (v == this.iv_information_back2) {
            this.info_accout_layout.setVisibility(0);
            this.info_security_layout.setVisibility(0);
            this.info_password_layout.setVisibility(0);
            this.info_phone_layout.setVisibility(0);
            this.btn_info_newPwd_finish2.setVisibility(8);
            this.info_newPwd2_layout.setVisibility(8);
            this.info_oldPwd_layout.setVisibility(8);
            this.btn_info_newPwd_finish1.setVisibility(8);
            this.newPwd_verify_layout.setVisibility(8);
            this.info_newPwd_layout.setVisibility(8);
            this.iv_information_back2.setVisibility(8);
            this.iv_information_back.setVisibility(0);
            this.info_phone_display_layout.setVisibility(8);
        } else if (v == this.btn_changeByVerify) {
            if (this.loginway == this.MobilePhoneLogin) {
                this.SetNewPwdDlg.dismiss();
                this.info_accout_layout.setVisibility(8);
                this.info_security_layout.setVisibility(8);
                this.info_password_layout.setVisibility(8);
                this.info_phone_layout.setVisibility(8);
                this.btn_info_newPwd_finish1.setVisibility(0);
                this.newPwd_verify_layout.setVisibility(0);
                this.info_newPwd_layout.setVisibility(0);
                this.iv_information_back2.setVisibility(0);
                this.iv_information_back.setVisibility(8);
            }
            if (this.loginway == this.MailBoxLogin) {
                this.SetNewPwdDlg.dismiss();
                this.info_accout_layout.setVisibility(8);
                this.info_security_layout.setVisibility(8);
                this.info_password_layout.setVisibility(8);
                this.info_phone_layout.setVisibility(8);
                this.btn_info_newPwd_finish1.setVisibility(0);
                this.newPwd_verify_layout.setVisibility(0);
                this.txt_info_verify.setEnabled(false);
                this.txt_info_verify.setHint(C0470R.string.Do_not_need_code);
                this.txt_info_verify.setHintTextColor(getResources().getColor(C0470R.color.font_color_gray));
                this.btn_info_verifycode.setEnabled(false);
                this.btn_info_verifycode.setTextColor(getResources().getColor(C0470R.color.font_color_gray));
                this.info_newPwd_layout.setVisibility(0);
                this.iv_information_back2.setVisibility(0);
                this.iv_information_back.setVisibility(8);
            }
        } else if (v == this.btn_changeByOldpwd) {
            this.SetNewPwdDlg.dismiss();
            this.info_accout_layout.setVisibility(8);
            this.info_security_layout.setVisibility(8);
            this.info_password_layout.setVisibility(8);
            this.info_phone_layout.setVisibility(8);
            this.btn_info_newPwd_finish2.setVisibility(0);
            this.info_newPwd2_layout.setVisibility(0);
            this.info_oldPwd_layout.setVisibility(0);
            this.iv_information_back2.setVisibility(0);
            this.iv_information_back.setVisibility(8);
        } else if (v == this.btn_info_verifycode) {
            startVerifyCodeThread();
        } else if (v == this.btn_info_newPwd_finish1) {
            this.resetway = this.Verification_way;
            showResetingDlg();
            startResetPasswordThread(this.Verification_way);
        } else if (v == this.btn_info_newPwd_finish2) {
            this.resetway = this.oldPassword_way;
            showResetingDlg();
            startResetPasswordThread(this.oldPassword_way);
        }
    }

    private void initSetNewPwdDlg() {
        this.SetNewPwdDlg = new Dialog(this, 16973840);
        this.SetNewPwdDlg.requestWindowFeature(1);
        this.SetNewPwdDlg.setContentView(C0470R.layout.dialog_set_password_layout);
        this.btn_changeByVerify = (Button) this.SetNewPwdDlg.findViewById(C0470R.id.setPasswordButton2);
        this.btn_changeByVerify.setOnClickListener(this);
        this.btn_changeByOldpwd = (Button) this.SetNewPwdDlg.findViewById(C0470R.id.setPasswordButton1);
        this.btn_changeByOldpwd.setOnClickListener(this);
        Window dialogWindow = this.SetNewPwdDlg.getWindow();
        LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(17);
        WindowManager m = getWindowManager();
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        lp.width = (int) (((double) metrics.widthPixels) * 0.9d);
        lp.height = (int) (((double) metrics.heightPixels) * 0.4d);
        lp.flags = 2;
        lp.dimAmount = 0.5f;
        dialogWindow.setAttributes(lp);
        this.SetNewPwdDlg.show();
        this.SetNewPwdDlg.setCanceledOnTouchOutside(true);
    }

    private void setPasswordVisibility(boolean isVisible, int editId) {
        if (isVisible) {
            if (editId == 1) {
                this.txt_info_newPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                this.txt_info_newPwd.setSelection(this.txt_info_newPwd.getText().toString().length());
            }
            if (editId == 2) {
                this.txt_info_newPwd2.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                this.txt_info_newPwd2.setSelection(this.txt_info_newPwd.getText().toString().length());
            }
            if (editId == 3) {
                this.txt_info_oldPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                this.txt_info_oldPwd.setSelection(this.txt_info_newPwd.getText().toString().length());
                return;
            }
            return;
        }
        if (editId == 1) {
            this.txt_info_newPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
            this.txt_info_newPwd.setSelection(this.txt_info_newPwd.getText().toString().length());
        }
        if (editId == 2) {
            this.txt_info_newPwd2.setTransformationMethod(PasswordTransformationMethod.getInstance());
            this.txt_info_newPwd2.setSelection(this.txt_info_newPwd.getText().toString().length());
        }
        if (editId == 3) {
            this.txt_info_oldPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
            this.txt_info_oldPwd.setSelection(this.txt_info_newPwd.getText().toString().length());
        }
    }

    public void startResetPasswordThread(int ResetWay) {
        this.n_ResetPasswordThreadID++;
        new ResetPasswordThread(this.handler, this.n_ResetPasswordThreadID, ResetWay).start();
    }

    private void PostResetPasswordData(int resetWay) throws JSONException {
        String MDLoginSign;
        JSONObject json;
        String Recresult;
        JSONObject jsonForResult;
        DecimalFormat df = new DecimalFormat("#.##");
        long time = System.currentTimeMillis();
        String content = null;
        try {
            this.NewPassword = LoginActivity.byte2hex(LoginActivity.encrypt(this.txt_info_newPwd.getText().toString().getBytes(), LoginActivity.key.getBytes()));
            this.NewPassword2 = LoginActivity.byte2hex(LoginActivity.encrypt(this.txt_info_newPwd2.getText().toString().getBytes(), LoginActivity.key.getBytes()));
            this.OldPassword = LoginActivity.byte2hex(LoginActivity.encrypt(this.txt_info_oldPwd.getText().toString().getBytes(), LoginActivity.key.getBytes()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (resetWay == 1) {
            String password;
            if (this.loginway == this.MobilePhoneLogin) {
                password = this.NewPassword;
                MDLoginSign = LoginActivity.md5("newpassword=" + password + "&timestamp=" + (time / 1000) + "&username=" + this.txt_account_info.getText().toString() + "&validcode=" + this.txt_info_verify.getText().toString() + "&validtype=mobile" + "hsshop2016");
                json = new JSONObject();
                json.put("sign", MDLoginSign);
                json.put("timestamp", (time / 1000));
                json.put("newpassword", password);
                json.put("username", this.txt_account_info.getText().toString());
                json.put("validcode", this.txt_info_verify.getText().toString());
                json.put("validtype", "mobile");
                content = json.toString();
            }
            if (this.loginway == this.MailBoxLogin) {
                password = this.NewPassword;
                MDLoginSign = LoginActivity.md5("newpassword=" + password + "&timestamp=" + (time / 1000) + "&username=" + this.txt_account_info.getText().toString() + "&validcode=" + this.txt_info_verify.getText().toString() + "&validtype=email" + "hsshop2016");
                json = new JSONObject();
                json.put("sign", MDLoginSign);
                json.put("timestamp", (time / 1000));
                json.put("newpassword", password);
                json.put("username", this.txt_account_info.getText().toString());
                json.put("validcode", this.txt_info_verify.getText().toString());
                json.put("validtype", "email");
                content = json.toString();
            }
            Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/user/reset-password", content);
            System.out.println("服务器返回的修改密码数据 = " + Recresult);
            if (Recresult != null) {
                if (Recresult.equals("-1")) {
                    this.errorResult = -1;
                    return;
                }
                jsonForResult = new JSONObject(Recresult);
                if (jsonForResult != null) {
                    this.resetPwdResult = Integer.valueOf(jsonForResult.getString("result")).intValue();
                    this.errorResult = Integer.valueOf(jsonForResult.getString("error_code")).intValue();
                }
            }
        }
        if (resetWay == 2) {
            String password_old = this.OldPassword;
            String password2 = this.NewPassword2;
            String RegisterSign = "accesstoken=" + DeviceListViewFragment._Token + "&newpassword=" + password2 + "&oldpassword=" + password_old + "&timestamp=" + (time / 1000) + "hsshop2016";
            System.out.println("RegisterSign " + RegisterSign);
            MDLoginSign = LoginActivity.md5(RegisterSign);
            json = new JSONObject();
            json.put("sign", MDLoginSign);
            json.put("timestamp", (time / 1000));
            json.put("accesstoken", DeviceListViewFragment._Token);
            json.put("newpassword", password2);
            json.put("oldpassword", password_old);
            Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/user/update-password", json.toString());
            System.out.println("服务器返回的修改密码数据 = " + Recresult);
            if (Recresult == null) {
                return;
            }
            if (Recresult.equals("-1")) {
                this.errorResult = -1;
                return;
            }
            jsonForResult = new JSONObject(Recresult);
            if (jsonForResult != null) {
                this.resetPwdResult = Integer.valueOf(jsonForResult.getString("result")).intValue();
                this.errorResult = Integer.valueOf(jsonForResult.getString("error_code")).intValue();
            }
        }
    }

    public void startVerifyCodeThread() {
        this.n_VerifyPasswordThreadID++;
        new VerifyCodeThread(this.handler, this.n_VerifyPasswordThreadID).start();
    }

    private void PostVerifyCodeData() throws JSONException {
        DecimalFormat df = new DecimalFormat("#.##");
        long time = System.currentTimeMillis();
        String VerifyCodeSign = "codetype=resetpwd&target=" + this.txt_account_info.getText().toString() + "&timestamp=" + (time / 1000) + "hsshop2016";
        String MDLoginSign = LoginActivity.md5(VerifyCodeSign);
        JSONObject json = new JSONObject();
        json.put("sign", MDLoginSign);
        json.put("timestamp", (time / 1000));
        json.put("codetype", "resetpwd");
        json.put("target", this.txt_account_info.getText().toString());
        String content = json.toString();
        System.out.println("LoginSign = " + VerifyCodeSign);
        String Recresult = HttpUtils.HttpPostData("http://cloud.av380.net:8002/tool/send-valid-code", content);
        if (Recresult == null) {
            return;
        }
        if (Recresult.equals("-1")) {
            this.errorResult = -1;
            return;
        }
        JSONObject json2 = new JSONObject(Recresult);
        this.verifycodeResult = Integer.valueOf(json2.getString("result")).intValue();
        this.errorResult = Integer.valueOf(json2.getString("error_code")).intValue();
    }

    private void showResetPwdMessage(int dialogNo) {
        this.lDialog = new Dialog(this, 16973840);
        this.lDialog.requestWindowFeature(1);
        this.lDialog.setContentView(C0470R.layout.dialog_registere_layout);
        TextView messageTxt = (TextView) this.lDialog.findViewById(C0470R.id.message_register);
        messageTxt.getBackground().setAlpha(Defines.REC_FILE_SEARCH);
        switch (dialogNo) {
            case -1:
                messageTxt.setText(C0470R.string.Network_Error);
                break;
            case 0:
                if (this.loginway == this.MobilePhoneLogin) {
                    messageTxt.setText(C0470R.string.Update_password);
                }
                if (this.loginway == this.MailBoxLogin) {
                    if (this.resetway != this.Verification_way) {
                        messageTxt.setText(C0470R.string.Update_password);
                        break;
                    } else {
                        messageTxt.setText(C0470R.string.Mailbox_reset_successfully);
                        break;
                    }
                }
                break;
            case 500:
                messageTxt.setText(C0470R.string.str_server_error);
                break;
            case 20001:
                messageTxt.setText(C0470R.string.Verify_code_is_incorrect);
                break;
            case 20002:
                messageTxt.setText(C0470R.string.verify_codes_is_overtime);
                break;
            case 21004:
                messageTxt.setText(C0470R.string.Set_Pwd_tip);
                break;
            case 21007:
                messageTxt.setText(C0470R.string.Old_pwd_error);
                break;
        }
        ((Button) this.lDialog.findViewById(C0470R.id.positiveButton)).setOnClickListener(new C04395());
        ((Button) this.lDialog.findViewById(C0470R.id.negativeButton)).setOnClickListener(new C04406());
        this.lDialog.show();
        this.dialog_showtime.start();
    }

    private void initLoginingDlg() {
        this.mResetDlg = new Dialog(this, C0470R.style.loginingDlg);
        this.mResetDlg.setContentView(C0470R.layout.logining_dlg);
        LayoutParams params = this.mResetDlg.getWindow().getAttributes();
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int cxScreen = dm.widthPixels;
        int height = (int) getResources().getDimension(C0470R.dimen.loginingdlg_height);
        int lrMargin = (int) getResources().getDimension(C0470R.dimen.loginingdlg_lr_margin);
        int topMargin = (int) getResources().getDimension(C0470R.dimen.loginingdlg_top_margin);
        params.y = ((-(dm.heightPixels - height)) / 2) + topMargin;
        params.width = cxScreen;
        params.height = height;
        this.mResetDlg.setCanceledOnTouchOutside(true);
    }

    private void showResetingDlg() {
        if (this.mResetDlg != null) {
            this.mResetDlg.show();
        }
    }

    private void closeResetingDlg() {
        if (this.mResetDlg != null && this.mResetDlg.isShowing()) {
            this.mResetDlg.dismiss();
        }
    }

    private void httpResult401() {
        View view = View.inflate(this, C0470R.layout.show_alert_dialog, null);
        ((TextView) view.findViewById(C0470R.id.tv_title)).setText(getString(C0470R.string.str_Notic_Close_APP));
        ((TextView) view.findViewById(C0470R.id.tv_content)).setText(getString(C0470R.string.str_401));
        AlertDialog dialog = new Builder(this).setView(view).setPositiveButton(getString(C0470R.string.alert_btn_OK), new C04417()).create();
        dialog.setCancelable(false);
        dialog.show();
    }
}
