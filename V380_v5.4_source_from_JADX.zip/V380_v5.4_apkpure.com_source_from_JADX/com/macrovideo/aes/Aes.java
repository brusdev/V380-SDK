package com.macrovideo.aes;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

public class Aes {
    private static final Object TAG = "AES";
    static final String algorithmStr = "AES/ECB/PKCS5Padding";
    private static Cipher cipher;
    static boolean isInited = false;
    public static String keyBytes = "1234567890123456";
    private static KeyGenerator keyGen;

    private static void init() {
        try {
            keyGen = KeyGenerator.getInstance("AES");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        keyGen.init(128);
        try {
            cipher = Cipher.getInstance(algorithmStr);
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
        } catch (NoSuchPaddingException e3) {
            e3.printStackTrace();
        }
        isInited = true;
    }

    private static byte[] genKey() {
        if (!isInited) {
            init();
        }
        return keyGen.generateKey().getEncoded();
    }

    private static byte[] encrypt(byte[] content, byte[] keyBytes) {
        byte[] encryptedText = null;
        if (!isInited) {
            init();
        }
        try {
            cipher.init(1, new SecretKeySpec(keyBytes, "AES"));
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        }
        try {
            encryptedText = cipher.doFinal(content);
        } catch (IllegalBlockSizeException e2) {
            e2.printStackTrace();
        } catch (BadPaddingException e3) {
            e3.printStackTrace();
        }
        return encryptedText;
    }

    private static byte[] encrypt(String content, String password) {
        try {
            SecretKeySpec key = new SecretKeySpec(getKey(password), "AES");
            Cipher cipher = Cipher.getInstance(algorithmStr);
            byte[] byteContent = content.getBytes("utf-8");
            cipher.init(1, key);
            return cipher.doFinal(byteContent);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (NoSuchPaddingException e2) {
            e2.printStackTrace();
            return null;
        } catch (InvalidKeyException e3) {
            e3.printStackTrace();
            return null;
        } catch (UnsupportedEncodingException e4) {
            e4.printStackTrace();
            return null;
        } catch (IllegalBlockSizeException e5) {
            e5.printStackTrace();
            return null;
        } catch (BadPaddingException e6) {
            e6.printStackTrace();
            return null;
        }
    }

    private static byte[] decrypt(byte[] content, String password) {
        try {
            SecretKeySpec key = new SecretKeySpec(getKey(password), "AES");
            Cipher cipher = Cipher.getInstance(algorithmStr);
            cipher.init(2, key);
            return cipher.doFinal(content);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (NoSuchPaddingException e2) {
            e2.printStackTrace();
            return null;
        } catch (InvalidKeyException e3) {
            e3.printStackTrace();
            return null;
        } catch (IllegalBlockSizeException e4) {
            e4.printStackTrace();
            return null;
        } catch (BadPaddingException e5) {
            e5.printStackTrace();
            return null;
        }
    }

    private static byte[] getKey(String password) {
        if (password != null) {
            return password.getBytes();
        }
        return new byte[24];
    }

    public static String parseByte2HexStr(byte[] buf) {
        StringBuffer sb = new StringBuffer();
        for (byte b : buf) {
            String hex = Integer.toHexString(b & 255);
            if (hex.length() == 1) {
                hex = new StringBuilder(String.valueOf('0')).append(hex).toString();
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }

    public static byte[] parseHexStr2Byte(String hexStr) {
        if (hexStr.length() < 1) {
            return null;
        }
        byte[] result = new byte[(hexStr.length() / 2)];
        for (int i = 0; i < hexStr.length() / 2; i++) {
            int high = Integer.parseInt(hexStr.substring(i * 2, (i * 2) + 1), 16);
            result[i] = (byte) ((high * 16) + Integer.parseInt(hexStr.substring((i * 2) + 1, (i * 2) + 2), 16));
        }
        return result;
    }

    public static String encode(String content) {
        return parseByte2HexStr(encrypt(content, keyBytes));
    }

    public static String decode(String content) {
        return new String(decrypt(parseHexStr2Byte(content), keyBytes));
    }

    public static void test1() {
        String content = "hello abcdefggsdfasdfasdf";
        String pStr = encode(content);
        System.out.println("加密前：" + content);
        System.out.println("加密后:" + pStr);
        System.out.println("解密后：" + decode("2bb09aa74b45f79ba82b3159ef2182fff057bab0a63ed64c87a25e3fd2ccc941c305b703c5636e1fe4eef79abb01f739fa6f1180a4091515c262577e9c13b41197f37f8789feb3e7582b251adc4821126d21658f127894f4d8a769c4c941a1be32e9a501698691c0168cb4febc485f4127abf157fa8daf13c340083537c01c7d8e01670832391a0d257d4e2775675207d588baff477ee849c51aa536afc9cf5b17a734b211178d358cb4e2898e0a4b0cc15eb92b468d7e7f6d77acfb761325ce290346691cb986ecc7abb6e4b687dd83"));
    }

    public static void main(String[] args) {
        test1();
    }
}
