package com.macrovideo.aes;

import android.support.v4.view.MotionEventCompat;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class DES3 {
    private static final String encoding = "utf-8";
    private static final String iv = "01234567";
    public static String secretKey = "123456789012345678901234";

    public static class Base64 {
        private static final char[] legalChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();

        public static String encode(byte[] data) {
            int len = data.length;
            StringBuffer buf = new StringBuffer((data.length * 3) / 2);
            int end = len - 3;
            int i = 0;
            int n = 0;
            while (i <= end) {
                int d = (((data[i] & 255) << 16) | ((data[i + 1] & 255) << 8)) | (data[i + 2] & 255);
                buf.append(legalChars[(d >> 18) & 63]);
                buf.append(legalChars[(d >> 12) & 63]);
                buf.append(legalChars[(d >> 6) & 63]);
                buf.append(legalChars[d & 63]);
                i += 3;
                int n2 = n + 1;
                if (n >= 14) {
                    n2 = 0;
                    buf.append(" ");
                }
                n = n2;
            }
            if (i == (0 + len) - 2) {
                d = ((data[i] & 255) << 16) | ((data[i + 1] & 255) << 8);
                buf.append(legalChars[(d >> 18) & 63]);
                buf.append(legalChars[(d >> 12) & 63]);
                buf.append(legalChars[(d >> 6) & 63]);
                buf.append("=");
            } else if (i == (0 + len) - 1) {
                d = (data[i] & 255) << 16;
                buf.append(legalChars[(d >> 18) & 63]);
                buf.append(legalChars[(d >> 12) & 63]);
                buf.append("==");
            }
            return buf.toString();
        }

        private static int decode(char c) {
            if (c >= 'A' && c <= 'Z') {
                return c - 65;
            }
            if (c >= 'a' && c <= 'z') {
                return (c - 97) + 26;
            }
            if (c >= '0' && c <= '9') {
                return ((c - 48) + 26) + 26;
            }
            switch (c) {
                case MotionEventCompat.AXIS_GENERIC_12 /*43*/:
                    return 62;
                case MotionEventCompat.AXIS_GENERIC_16 /*47*/:
                    return 63;
                case '=':
                    return 0;
                default:
                    throw new RuntimeException("unexpected code: " + c);
            }
        }

        public static byte[] decode(String s) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try {
                decode(s, bos);
                byte[] decodedBytes = bos.toByteArray();
                try {
                    bos.close();
                } catch (IOException ex) {
                    System.err.println("Error while decoding BASE64: " + ex.toString());
                }
                return decodedBytes;
            } catch (IOException e) {
                throw new RuntimeException();
            }
        }

        private static void decode(String s, OutputStream os) throws IOException {
            int i = 0;
            int len = s.length();
            while (true) {
                if (i < len && s.charAt(i) <= ' ') {
                    i++;
                } else if (i != len) {
                    int tri = (((decode(s.charAt(i)) << 18) + (decode(s.charAt(i + 1)) << 12)) + (decode(s.charAt(i + 2)) << 6)) + decode(s.charAt(i + 3));
                    os.write((tri >> 16) & 255);
                    if (s.charAt(i + 2) != '=') {
                        os.write((tri >> 8) & 255);
                        if (s.charAt(i + 3) != '=') {
                            os.write(tri & 255);
                            i += 4;
                        } else {
                            return;
                        }
                    }
                    return;
                } else {
                    return;
                }
            }
        }
    }

    public static String encode(String plainText) throws Exception {
        Key deskey = SecretKeyFactory.getInstance("desede").generateSecret(new DESedeKeySpec(secretKey.getBytes()));
        Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
        cipher.init(1, deskey, new IvParameterSpec(iv.getBytes()));
        return Base64.encode(cipher.doFinal(plainText.getBytes(encoding)));
    }

    public static String decode(String encryptText) throws Exception {
        Key deskey = SecretKeyFactory.getInstance("desede").generateSecret(new DESedeKeySpec(secretKey.getBytes()));
        Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
        cipher.init(2, deskey, new IvParameterSpec(iv.getBytes()));
        return new String(cipher.doFinal(Base64.decode(encryptText)), encoding);
    }

    public static String padding(String str) {
        try {
            byte[] oldByteArray = str.getBytes("UTF8");
            byte[] newByteArray = new byte[(oldByteArray.length + (8 - (oldByteArray.length % 8)))];
            System.arraycopy(oldByteArray, 0, newByteArray, 0, oldByteArray.length);
            for (int i = oldByteArray.length; i < newByteArray.length; i++) {
                newByteArray[i] = (byte) 0;
            }
            return new String(newByteArray, "UTF8");
        } catch (UnsupportedEncodingException e) {
            System.out.println("Crypter.padding UnsupportedEncodingException");
            return null;
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println(encode("1234567890123456"));
        System.out.println(decode("IlKk9ampIvQPbk7yhYBWLMoQImiHVXy2xe9T1p+F02BRTcMAnvoM9v6kj9xVIQevyiN3cjEFCDaE0M6GMxmV+CJc4QLzbc5UvZTUhERAvt47lrJqVjWVfg3gT4vy91RvohGqxHemRLmSp+gEjIjCNiLSCYT6zdbYaMCjUB6ntWyLH4sFn87l88KcBwtiaphhkNiOccRuwL251FPGAXjJp8fYejHlyEUWm4VCHYvezNEGdm9FG5SikMjncLM1gjNUBxymLzVp2M8="));
    }
}
