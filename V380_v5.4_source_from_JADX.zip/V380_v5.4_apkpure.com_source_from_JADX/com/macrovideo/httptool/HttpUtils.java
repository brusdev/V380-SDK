package com.macrovideo.httptool;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AUTH;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;

public class HttpUtils {
    public static final String HTTP_REQUEST_PREFIX = "http://cloud.av380.net:8002/";
    public static final int NEWERROR = -1;
    public static final int RESULT_CODE_DEVICE_HAD_BINDED_SERVICE = 23004;
    public static final int RESULT_CODE_ERROR_IDENTITY = 401;
    public static final int RESULT_CODE_INVALID_PARAMETER = 10006;
    public static final int RESULT_CODE_MISSING_PARAMETER = 10003;
    public static final int RESULT_CODE_NOT_FOUND_PARAMETER = 10005;
    public static final int RESULT_CODE_NOT_SET_EMAIL = 21010;
    public static final int RESULT_CODE_OTHER_ERROR = 10099;
    public static final int RESULT_CODE_REPEATED_VALUE = 10004;
    public static final int RESULT_CODE_REQUEST_EXPIRED = 10002;
    public static final int RESULT_CODE_SERVER_ERROR = 500;
    public static final int RESULT_CODE_SERVICE_HAD_BINDED_OTHER_DEVIVE = 23003;
    public static final int RESULT_CODE_SIGN = 10001;
    public static final int RESULT_CODE_SUCCESS = 0;
    public static final int RESULT_CODE_THE_LATEST = 10007;
    public static final int RESULT_CODE_USER_HAS_NOT_DEVICE = 22001;
    public static final int RESULT_CODE_USER_NOT_BUY_SERVICE = 23001;
    public static final int RESULT_CODE_VALID_CODE_ERROR = 20001;
    public static final int RESULT_CODE_VALID_CODE_OUT_OF_DATE = 20002;

    public static java.lang.String loginOfGet(java.lang.String r9) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find block by offset: 0x003c in list [B:7:0x0039]
	at jadx.core.utils.BlockUtils.getBlockByOffset(BlockUtils.java:42)
	at jadx.core.dex.instructions.IfNode.initBlocks(IfNode.java:60)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.initBlocksInIfNodes(BlockFinish.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:33)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = 0;
        r6 = new java.net.URL;	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r6.<init>(r9);	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r7 = r6.openConnection();	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r0 = r7;	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r0 = (java.net.HttpURLConnection) r0;	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r2 = r0;	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r7 = "GET";	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r2.setRequestMethod(r7);	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r7 = 10000; // 0x2710 float:1.4013E-41 double:4.9407E-320;	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r2.setConnectTimeout(r7);	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r7 = 5000; // 0x1388 float:7.006E-42 double:2.4703E-320;	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r2.setReadTimeout(r7);	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r2.connect();	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r1 = r2.getResponseCode();	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r7 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        if (r1 != r7) goto L_0x004f;	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
    L_0x0028:
        r7 = java.lang.System.out;	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r8 = "�������ӳɹ�";	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r7.println(r8);	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r4 = r2.getInputStream();	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        r5 = getStringFromInputStream(r4);	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        if (r2 == 0) goto L_0x003c;
    L_0x0039:
        r2.disconnect();
    L_0x003c:
        return r5;
    L_0x003d:
        r3 = move-exception;
        r3.printStackTrace();	 Catch:{ Exception -> 0x003d, all -> 0x0048 }
        if (r2 == 0) goto L_0x0046;
    L_0x0043:
        r2.disconnect();
    L_0x0046:
        r5 = 0;
        goto L_0x003c;
    L_0x0048:
        r7 = move-exception;
        if (r2 == 0) goto L_0x004e;
    L_0x004b:
        r2.disconnect();
    L_0x004e:
        throw r7;
    L_0x004f:
        if (r2 == 0) goto L_0x0046;
    L_0x0051:
        r2.disconnect();
        goto L_0x0046;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.macrovideo.httptool.HttpUtils.loginOfGet(java.lang.String):java.lang.String");
    }

    public static String submitPostData(String strUrlPath, Map<String, String> params, String encode) {
        byte[] data = getRequestData(params, encode).toString().getBytes();
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(strUrlPath).openConnection();
            if (httpURLConnection == null) {
                System.out.println("û�����Ϸ�����");
            } else {
                System.out.println("�����Ϸ�����");
            }
            httpURLConnection.setConnectTimeout(3000);
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod(HttpPost.METHOD_NAME);
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setRequestProperty(HTTP.CONTENT_LEN, String.valueOf(data.length));
            httpURLConnection.getOutputStream().write(data);
            int response = httpURLConnection.getResponseCode();
            System.out.println("responseresponse" + response);
            if (response != 200) {
                return "-1";
            }
            InputStream inptStream = httpURLConnection.getInputStream();
            System.out.println("���ͳɹ�,��ȡ���");
            String result = dealResponseResult(inptStream);
            System.out.println("json_result111  " + result);
            return result;
        } catch (IOException e) {
            return "err: " + e.getMessage().toString();
        }
    }

    public static String dealResponseResult(InputStream inputStream) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] data = new byte[1024];
        while (true) {
            try {
                int len = inputStream.read(data);
                if (len == -1) {
                    break;
                }
                byteArrayOutputStream.write(data, 0, len);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return new String(byteArrayOutputStream.toByteArray());
    }

    public static StringBuffer getRequestData(Map<String, String> params, String encode) {
        StringBuffer stringBuffer = new StringBuffer();
        try {
            for (Entry<String, String> entry : params.entrySet()) {
                stringBuffer.append((String) entry.getKey()).append("=").append(URLEncoder.encode((String) entry.getValue(), encode)).append("&");
            }
            stringBuffer.deleteCharAt(stringBuffer.length() - 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stringBuffer;
    }

    private static String getStringFromInputStream(InputStream is) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buff = new byte[1024];
        while (true) {
            int len = is.read(buff);
            if (len == -1) {
                is.close();
                String html = baos.toString();
                baos.close();
                return html;
            }
            baos.write(buff, 0, len);
        }
    }

    public static String HttpPostData(String Str_url, String Str_data) {
        try {
            HttpPost httppost = new HttpPost(Str_url);
            HttpParams httpParameters = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpParameters, 5000);
            HttpClient httpclient = new DefaultHttpClient(httpParameters);
            httppost.addHeader(AUTH.WWW_AUTH_RESP, "your token");
            httppost.addHeader(HTTP.CONTENT_TYPE, "application/json");
            httppost.addHeader(HTTP.USER_AGENT, "imgfornote");
            httppost.setEntity(new StringEntity(Str_data));
            HttpResponse response = httpclient.execute(httppost);
            if (response.getStatusLine().getStatusCode() == 200) {
                return getStringFromInputStream(response.getEntity().getContent());
            }
        } catch (ClientProtocolException e) {
            System.out.println("ClientProtocolException e.printStackTrace()" + e);
            return "-2";
        } catch (IOException e2) {
            System.out.println("IOException e.printStackTrace()" + e2);
            return "-1";
        } catch (Exception e3) {
            System.out.println("Exception e.printStackTrace()" + e3);
        }
        return "-1";
    }
}
