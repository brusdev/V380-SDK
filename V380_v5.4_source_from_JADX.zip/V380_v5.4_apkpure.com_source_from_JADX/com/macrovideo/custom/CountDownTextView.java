package com.macrovideo.custom;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.widget.TextView;

public class CountDownTextView extends CountDownTimer {
    public static final int TIME_COUNT_FUTURE = 60000;
    public static final int TIME_COUNT_INTERVAL = 1000;
    private Context mContext;
    private Drawable mOriginalBackground;
    private String mOriginalText;
    private int mOriginalTextColor;
    private TextView mTextView;
    private Drawable mTickBackground;
    private int nCount = 0;

    public CountDownTextView() {
        super(60000, 1000);
    }

    public CountDownTextView(long millisInFuture, long countDownInterval) {
        super(millisInFuture, countDownInterval);
    }

    public void init(Context context, TextView textView, int nCount) {
        this.nCount = nCount;
        this.mContext = context;
        this.mTextView = textView;
        this.mOriginalText = this.nCount;
        this.mOriginalBackground = this.mTextView.getBackground();
        this.mTickBackground = this.mOriginalBackground;
        this.mOriginalTextColor = this.mTextView.getCurrentTextColor();
    }

    public void setTickDrawable(Drawable tickDrawable) {
        this.mTickBackground = tickDrawable;
    }

    public void onFinish() {
        if (this.mContext == null) {
        }
    }

    public void onTick(long millisUntilFinished) {
        if (this.mContext != null && this.mTextView != null) {
            this.nCount--;
            if (this.nCount < 0) {
                this.nCount = 0;
            }
            try {
                this.mTextView.setText(this.nCount);
            } catch (Exception e) {
            }
        }
    }
}
