package com.macrovideo.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.view.View;
import android.widget.GridView;

public class LineGridView extends GridView {
    public LineGridView(Context context) {
        super(context);
    }

    public LineGridView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public LineGridView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        int column = getWidth() / getChildAt(0).getWidth();
        int childCount = getChildCount();
        Paint localPaint = new Paint();
        localPaint.setStyle(Style.STROKE);
        localPaint.setColor(Color.parseColor("#ffffff"));
        for (int i = 0; i < childCount; i++) {
            View cellView = getChildAt(i);
            if ((i + 1) % column == 0) {
                canvas.drawLine((float) cellView.getLeft(), (float) cellView.getBottom(), (float) cellView.getRight(), (float) cellView.getBottom(), localPaint);
            } else if (i + 1 > childCount - (childCount % column)) {
                canvas.drawLine((float) cellView.getRight(), (float) cellView.getTop(), (float) cellView.getRight(), (float) cellView.getBottom(), localPaint);
            } else {
                canvas.drawLine((float) cellView.getRight(), (float) cellView.getTop(), (float) cellView.getRight(), (float) cellView.getBottom(), localPaint);
                canvas.drawLine((float) cellView.getLeft(), (float) cellView.getBottom(), (float) cellView.getRight(), (float) cellView.getBottom(), localPaint);
            }
        }
        if (childCount % column != 0) {
            for (int j = 0; j < column - (childCount % column); j++) {
                View lastView = getChildAt(childCount - 1);
                canvas.drawLine((float) (lastView.getRight() + (lastView.getWidth() * j)), (float) lastView.getTop(), (float) (lastView.getRight() + (lastView.getWidth() * j)), (float) lastView.getBottom(), localPaint);
            }
        }
    }
}
