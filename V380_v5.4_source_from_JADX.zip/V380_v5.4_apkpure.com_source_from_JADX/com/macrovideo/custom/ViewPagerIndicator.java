package com.macrovideo.custom;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.macrovideo.photo.PhotoViewAttacher;
import com.macrovideo.v380.C0470R;
import java.util.List;

public class ViewPagerIndicator extends LinearLayout {
    private int height;
    private boolean isAutoSelect;
    private boolean isSetData;
    private Context mContext;
    private int mCurrentPosition;
    private List<String> mDatas;
    private float mHeight;
    private int mItemCount;
    private float mLeft;
    private int mPadding;
    private Paint mPaint;
    private float mRadiusX;
    private float mRadiusY;
    private float mReBoundOffset;
    private float mTop;
    private ViewPager mViewPager;
    private int mVisiblemItemCount;
    private float mWidth;
    private int width;

    class C08292 implements OnPageChangeListener {
        C08292() {
        }

        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            if (ViewPagerIndicator.this.isAutoSelect && ViewPagerIndicator.this.mCurrentPosition == 0) {
                if (positionOffset > ViewPagerIndicator.this.mReBoundOffset / 2.0f) {
                    ViewPagerIndicator.this.mLeft = (((float) position) + ((positionOffset - (ViewPagerIndicator.this.mReBoundOffset / 2.0f)) * 2.0f)) * ViewPagerIndicator.this.mWidth;
                } else if (positionOffset <= ViewPagerIndicator.this.mReBoundOffset / 3.0f || positionOffset >= ViewPagerIndicator.this.mReBoundOffset / 2.0f) {
                    ViewPagerIndicator.this.mLeft = (((((float) position) + positionOffset) * ViewPagerIndicator.this.mWidth) * 6.0f) / 12.0f;
                } else {
                    ViewPagerIndicator.this.mLeft = ((((((float) position) + (ViewPagerIndicator.this.mReBoundOffset / 2.0f)) - positionOffset) * ViewPagerIndicator.this.mWidth) * 6.0f) / 12.0f;
                }
                ViewPagerIndicator.this.invalidate();
            } else if (ViewPagerIndicator.this.isAutoSelect && ViewPagerIndicator.this.mCurrentPosition == ViewPagerIndicator.this.mItemCount - 1) {
                if (positionOffset >= ViewPagerIndicator.this.mReBoundOffset && positionOffset < PhotoViewAttacher.DEFAULT_MIN_SCALE - ((PhotoViewAttacher.DEFAULT_MIN_SCALE - ViewPagerIndicator.this.mReBoundOffset) / 2.0f)) {
                    ViewPagerIndicator.this.mLeft = (((float) position) + (positionOffset / (PhotoViewAttacher.DEFAULT_MIN_SCALE - ((PhotoViewAttacher.DEFAULT_MIN_SCALE - ViewPagerIndicator.this.mReBoundOffset) / 2.0f)))) * ViewPagerIndicator.this.mWidth;
                    if (ViewPagerIndicator.this.mVisiblemItemCount < ViewPagerIndicator.this.mItemCount) {
                        ViewPagerIndicator.this.scrollTo((int) (((ViewPagerIndicator.this.mWidth * positionOffset) / (PhotoViewAttacher.DEFAULT_MIN_SCALE - ((PhotoViewAttacher.DEFAULT_MIN_SCALE - ViewPagerIndicator.this.mReBoundOffset) / 2.0f))) + (((float) ((position - ViewPagerIndicator.this.mVisiblemItemCount) + 1)) * ViewPagerIndicator.this.mWidth)), 0);
                    }
                    if (ViewPagerIndicator.this.mLeft + ViewPagerIndicator.this.mWidth > ((float) ViewPagerIndicator.this.getChildCount()) * ViewPagerIndicator.this.mWidth) {
                        ViewPagerIndicator.this.mLeft = ((float) (ViewPagerIndicator.this.mItemCount - 1)) * ViewPagerIndicator.this.mWidth;
                    }
                } else if (positionOffset > PhotoViewAttacher.DEFAULT_MIN_SCALE - ((PhotoViewAttacher.DEFAULT_MIN_SCALE - ViewPagerIndicator.this.mReBoundOffset) / 2.0f) && positionOffset < PhotoViewAttacher.DEFAULT_MIN_SCALE - ((PhotoViewAttacher.DEFAULT_MIN_SCALE - ViewPagerIndicator.this.mReBoundOffset) / 4.0f)) {
                    if (ViewPagerIndicator.this.mVisiblemItemCount < ViewPagerIndicator.this.mItemCount && ((float) ViewPagerIndicator.this.getScrollX()) != ((float) (ViewPagerIndicator.this.mItemCount - ViewPagerIndicator.this.mVisiblemItemCount)) * ViewPagerIndicator.this.mWidth) {
                        ViewPagerIndicator.this.scrollTo((int) (((float) (ViewPagerIndicator.this.mItemCount - ViewPagerIndicator.this.mVisiblemItemCount)) * ViewPagerIndicator.this.mWidth), 0);
                    }
                    ViewPagerIndicator.this.mLeft = (((float) (position + 1)) * ViewPagerIndicator.this.mWidth) - ((((positionOffset - (PhotoViewAttacher.DEFAULT_MIN_SCALE - ((PhotoViewAttacher.DEFAULT_MIN_SCALE - ViewPagerIndicator.this.mReBoundOffset) / 2.0f))) * ViewPagerIndicator.this.mWidth) * 7.0f) / 12.0f);
                } else if (positionOffset != 0.0f) {
                    ViewPagerIndicator.this.mLeft = (((float) (position + 1)) * ViewPagerIndicator.this.mWidth) - ((((PhotoViewAttacher.DEFAULT_MIN_SCALE - positionOffset) * ViewPagerIndicator.this.mWidth) * 7.0f) / 12.0f);
                    if (ViewPagerIndicator.this.mLeft > ((float) (ViewPagerIndicator.this.mItemCount - 1)) * ViewPagerIndicator.this.mWidth) {
                        ViewPagerIndicator.this.mLeft = ((float) (ViewPagerIndicator.this.mItemCount - 1)) * ViewPagerIndicator.this.mWidth;
                    }
                } else {
                    ViewPagerIndicator.this.mLeft = ((float) (ViewPagerIndicator.this.mItemCount - 1)) * ViewPagerIndicator.this.mWidth;
                }
                ViewPagerIndicator.this.invalidate();
            } else {
                ViewPagerIndicator.this.scrollTo(position, positionOffset);
                ViewPagerIndicator.this.mReBoundOffset = positionOffset;
            }
            ViewPagerIndicator.this.setTitleColor();
        }

        public void onPageSelected(int position) {
            ViewPagerIndicator.this.mCurrentPosition = position;
        }

        public void onPageScrollStateChanged(int state) {
            if (state == 2) {
                ViewPagerIndicator.this.isAutoSelect = true;
            }
            if (state == 0) {
                ViewPagerIndicator.this.isAutoSelect = false;
            }
        }
    }

    public ViewPagerIndicator(Context context) {
        this(context, null);
    }

    public ViewPagerIndicator(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mVisiblemItemCount = 3;
        this.mItemCount = 3;
        this.mRadiusX = 10.0f;
        this.mRadiusY = 10.0f;
        this.mPadding = 8;
        this.mContext = context;
        init();
    }

    private void init() {
        this.mPaint = new Paint();
        this.mPaint.setStyle(Style.FILL);
        this.mPaint.setColor(Color.parseColor("#ffffff"));
        this.mPaint.setAntiAlias(true);
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        this.width = getMeasuredWidth();
        this.height = getMeasuredHeight();
        this.mWidth = (float) (this.width / this.mVisiblemItemCount);
        this.mHeight = (float) this.height;
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (this.isSetData) {
            this.isSetData = false;
            removeAllViews();
            for (int i = 0; i < this.mDatas.size(); i++) {
                TextView tv = new TextView(this.mContext);
                tv.setPadding(this.mPadding, this.mPadding, this.mPadding, this.mPadding);
                tv.setText((CharSequence) this.mDatas.get(i));
                LayoutParams lp = new LayoutParams(-1, -1);
                lp.width = this.width / this.mVisiblemItemCount;
                lp.height = this.height;
                tv.setGravity(17);
                tv.setTextColor(getResources().getColor(C0470R.color.font_color_blue));
                tv.setTextSize(2, 16.0f);
                tv.setLayoutParams(lp);
                final int finalI = i;
                tv.setOnClickListener(new OnClickListener() {
                    public void onClick(View v) {
                        if (ViewPagerIndicator.this.mViewPager != null) {
                            ViewPagerIndicator.this.mViewPager.setCurrentItem(finalI);
                        }
                    }
                });
                addView(tv);
            }
            setTitleColor();
        }
    }

    @SuppressLint({"NewApi"})
    protected void onDraw(Canvas canvas) {
        if (VERSION.SDK_INT >= 21) {
            Canvas canvas2 = canvas;
            canvas2.drawRoundRect(((float) this.mPadding) + this.mLeft, ((float) this.mPadding) + this.mTop, (this.mLeft + this.mWidth) - ((float) this.mPadding), (this.mTop + this.mHeight) - ((float) this.mPadding), this.mRadiusX, this.mRadiusY, this.mPaint);
            return;
        }
        canvas.drawRoundRect(new RectF(this.mLeft + ((float) this.mPadding), this.mTop + ((float) this.mPadding), (this.mLeft + this.mWidth) - ((float) this.mPadding), (this.mTop + this.mHeight) - ((float) this.mPadding)), this.mRadiusX, this.mRadiusY, this.mPaint);
    }

    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
    }

    public void setViewPager(ViewPager viewpager, int position) {
        this.mViewPager = viewpager;
        this.mCurrentPosition = position;
        if (this.mViewPager != null) {
            viewpager.addOnPageChangeListener(new C08292());
        }
    }

    private void setTitleColor() {
        if (getChildCount() > 0) {
            for (int i = 0; i < getChildCount(); i++) {
                if (i == this.mCurrentPosition) {
                    ((TextView) getChildAt(this.mCurrentPosition)).setTextColor(getResources().getColor(C0470R.color.font_color_blue));
                } else {
                    ((TextView) getChildAt(i)).setTextColor(getResources().getColor(C0470R.color.font_color_white));
                }
            }
        }
    }

    private void scrollTo(int position, float positionOffset) {
        if (this.mVisiblemItemCount < this.mItemCount && positionOffset > 0.0f && position > this.mVisiblemItemCount - 2) {
            scrollTo((int) ((this.mWidth * positionOffset) + (((float) ((position - this.mVisiblemItemCount) + 1)) * this.mWidth)), 0);
        }
        this.mLeft = (((float) position) + positionOffset) * this.mWidth;
        invalidate();
    }

    public void setDatas(List<String> mDatas) {
        this.isSetData = true;
        this.mDatas = mDatas;
        this.mItemCount = mDatas.size();
        if (this.mItemCount < this.mVisiblemItemCount) {
            this.mVisiblemItemCount = this.mItemCount;
        }
    }

    public void setViewPager(ViewPager viewpager) {
        setViewPager(viewpager, 0);
    }
}
