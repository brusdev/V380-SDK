package com.macrovideo.sdk.tools;

import android.util.Log;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.tencent.android.tpush.common.Constants;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class DeviceScanner {
    static final int MAX_DATA_PACKET_LENGTH = 128;
    private static int _nSearchID = 0;
    private static byte[] buffer = new byte[128];
    static final Object searchLock = new Object();
    private int nSearchID = 0;

    public static synchronized ArrayList<DeviceInfo> getDeviceListFromLan() {
        ArrayList<DeviceInfo> list;
        synchronized (DeviceScanner.class) {
            list = new ArrayList();
            _nSearchID++;
            int nSearchID = _nSearchID;
            Hashtable<String, DeviceInfo> tableResult = searchWithBroadCast(nSearchID);
            if (tableResult == null || tableResult.isEmpty()) {
                tableResult = searchP2P(nSearchID);
            }
            if (!(tableResult == null || tableResult.isEmpty())) {
                Object[] array = tableResult.values().toArray();
                for (Object obj : array) {
                    list.add((DeviceInfo) obj);
                }
            }
        }
        return list;
    }

    public static synchronized ArrayList<DeviceInfo> getDeviceListFromLan(int nConfigID) {
        ArrayList<DeviceInfo> list;
        synchronized (DeviceScanner.class) {
            list = new ArrayList();
            _nSearchID++;
            int nSearchID = _nSearchID;
            Hashtable<String, DeviceInfo> tableResult = searchWithBroadCast(nSearchID, nConfigID);
            if (tableResult == null || tableResult.isEmpty()) {
                tableResult = searchP2P(nSearchID, nConfigID);
            }
            if (!(tableResult == null || tableResult.isEmpty())) {
                Object[] array = tableResult.values().toArray();
                for (Object obj : array) {
                    list.add((DeviceInfo) obj);
                }
            }
        }
        return list;
    }

    public static void reset() {
        _nSearchID++;
    }

    private static Hashtable<String, DeviceInfo> searchWithBroadCast(int nSearchID) {
        DatagramPacket datagramPacket;
        Hashtable<String, DeviceInfo> hashtable;
        byte[] receiveData;
        int j;
        boolean bIsOK;
        int nTokenIndex;
        DeviceInfo info;
        Throwable th;
        synchronized (searchLock) {
            try {
                String searchCMD = "NVDEVSEARCH^100";
                DatagramSocket udpSocket = null;
                try {
                    DatagramSocket datagramSocket = new DatagramSocket(Defines.DEFAULT_SEND_PORT);
                    try {
                        DatagramPacket datagramPacket2 = new DatagramPacket(buffer, 128);
                        try {
                            StringBuilder strBulder;
                            StringTokenizer stringTokenizer;
                            String token;
                            byte[] data = searchCMD.getBytes();
                            datagramPacket2.setData(data);
                            datagramPacket2.setLength(data.length);
                            datagramPacket2.setPort(Defines.DEFAULT_SEND_PORT);
                            datagramPacket2.setAddress(InetAddress.getByName("255.255.255.255"));
                            datagramSocket.send(datagramPacket2);
                            Hashtable<String, DeviceInfo> table = new Hashtable();
                            byte[] recvData = new byte[2048];
                            int nDevID = 0;
                            String strName = null;
                            String strIP = null;
                            int nPort = 8800;
                            String strMac = null;
                            int nTimeouts = 0;
                            DatagramSocket recvUDPSocket = null;
                            try {
                                datagramSocket = new DatagramSocket(Defines.DEFAULT_RECV_PORT);
                                try {
                                    datagramSocket.setReceiveBufferSize(16384);
                                    datagramSocket.setSoTimeout(200);
                                    recvUDPSocket = datagramSocket;
                                } catch (SocketException e) {
                                    recvUDPSocket = datagramSocket;
                                    if (recvUDPSocket != null) {
                                        try {
                                            recvUDPSocket.close();
                                        } catch (Exception e2) {
                                        }
                                    }
                                    recvUDPSocket = null;
                                    while (nSearchID == _nSearchID) {
                                        try {
                                            Arrays.fill(recvData, (byte) 0);
                                            datagramPacket2 = new DatagramPacket(recvData, 512);
                                            try {
                                                recvUDPSocket.receive(datagramPacket2);
                                            } catch (SocketTimeoutException e3) {
                                                nTimeouts++;
                                            } catch (IOException e4) {
                                                nTimeouts = 20;
                                            }
                                            if (nTimeouts >= 10) {
                                                if (nSearchID == _nSearchID) {
                                                    if (recvUDPSocket != null) {
                                                        try {
                                                            recvUDPSocket.close();
                                                        } catch (Exception e5) {
                                                        }
                                                    }
                                                    if (datagramSocket != null) {
                                                        try {
                                                            datagramSocket.close();
                                                        } catch (Exception e6) {
                                                        }
                                                    }
                                                    udpSocket = datagramSocket;
                                                    datagramPacket = datagramPacket2;
                                                    hashtable = table;
                                                    return table;
                                                }
                                            }
                                            strBulder = new StringBuilder();
                                            receiveData = datagramPacket2.getData();
                                            j = 0;
                                            while (j < receiveData.length) {
                                                if (receiveData[j] != (byte) 0) {
                                                    if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                                        if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                                            continue;
                                                        }
                                                    }
                                                    bIsOK = false;
                                                    stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                                    nTokenIndex = 0;
                                                    while (stringTokenizer.hasMoreTokens()) {
                                                        token = stringTokenizer.nextToken();
                                                        switch (nTokenIndex) {
                                                            case 2:
                                                                strMac = token;
                                                                break;
                                                            case 3:
                                                                strIP = token;
                                                                break;
                                                            case 9:
                                                                try {
                                                                    nPort = Integer.parseInt(token);
                                                                    break;
                                                                } catch (Exception e7) {
                                                                    nPort = 8800;
                                                                    break;
                                                                }
                                                            case 12:
                                                                nDevID = Integer.parseInt(token);
                                                                bIsOK = true;
                                                                strName = nDevID;
                                                                break;
                                                            default:
                                                                break;
                                                        }
                                                        nTokenIndex++;
                                                    }
                                                    if (bIsOK) {
                                                        info = new DeviceInfo(-1, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                                        if (!table.containsKey(strMac)) {
                                                            table.put(strMac, info);
                                                        }
                                                    }
                                                } else {
                                                    strBulder.append((char) receiveData[j]);
                                                    j++;
                                                }
                                            }
                                            if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                                if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                                    continue;
                                                }
                                            }
                                            bIsOK = false;
                                            stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                            nTokenIndex = 0;
                                            while (stringTokenizer.hasMoreTokens()) {
                                                token = stringTokenizer.nextToken();
                                                switch (nTokenIndex) {
                                                    case 2:
                                                        strMac = token;
                                                        break;
                                                    case 3:
                                                        strIP = token;
                                                        break;
                                                    case 9:
                                                        nPort = Integer.parseInt(token);
                                                        break;
                                                    case 12:
                                                        nDevID = Integer.parseInt(token);
                                                        bIsOK = true;
                                                        strName = nDevID;
                                                        break;
                                                    default:
                                                        break;
                                                }
                                                nTokenIndex++;
                                            }
                                            if (bIsOK) {
                                                info = new DeviceInfo(-1, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                                if (!table.containsKey(strMac)) {
                                                    table.put(strMac, info);
                                                }
                                            }
                                        } catch (Throwable th2) {
                                            th = th2;
                                            hashtable = table;
                                        }
                                    }
                                    if (recvUDPSocket != null) {
                                        recvUDPSocket.close();
                                    }
                                    if (datagramSocket != null) {
                                        datagramSocket.close();
                                    }
                                    udpSocket = datagramSocket;
                                    datagramPacket = datagramPacket2;
                                    hashtable = table;
                                    return table;
                                }
                            } catch (SocketException e8) {
                                if (recvUDPSocket != null) {
                                    recvUDPSocket.close();
                                }
                                recvUDPSocket = null;
                                while (nSearchID == _nSearchID) {
                                    Arrays.fill(recvData, (byte) 0);
                                    datagramPacket2 = new DatagramPacket(recvData, 512);
                                    recvUDPSocket.receive(datagramPacket2);
                                    if (nTimeouts >= 10) {
                                        if (nSearchID == _nSearchID) {
                                            if (recvUDPSocket != null) {
                                                recvUDPSocket.close();
                                            }
                                            if (datagramSocket != null) {
                                                datagramSocket.close();
                                            }
                                            udpSocket = datagramSocket;
                                            datagramPacket = datagramPacket2;
                                            hashtable = table;
                                            return table;
                                        }
                                    }
                                    strBulder = new StringBuilder();
                                    receiveData = datagramPacket2.getData();
                                    j = 0;
                                    while (j < receiveData.length) {
                                        if (receiveData[j] != (byte) 0) {
                                            strBulder.append((char) receiveData[j]);
                                            j++;
                                        } else {
                                            if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                                if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                                    continue;
                                                }
                                            }
                                            bIsOK = false;
                                            stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                            nTokenIndex = 0;
                                            while (stringTokenizer.hasMoreTokens()) {
                                                token = stringTokenizer.nextToken();
                                                switch (nTokenIndex) {
                                                    case 2:
                                                        strMac = token;
                                                        break;
                                                    case 3:
                                                        strIP = token;
                                                        break;
                                                    case 9:
                                                        nPort = Integer.parseInt(token);
                                                        break;
                                                    case 12:
                                                        nDevID = Integer.parseInt(token);
                                                        bIsOK = true;
                                                        strName = nDevID;
                                                        break;
                                                    default:
                                                        break;
                                                }
                                                nTokenIndex++;
                                            }
                                            if (bIsOK) {
                                                info = new DeviceInfo(-1, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                                if (!table.containsKey(strMac)) {
                                                    table.put(strMac, info);
                                                }
                                            }
                                        }
                                    }
                                    if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                        if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                            continue;
                                        }
                                    }
                                    bIsOK = false;
                                    stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                    nTokenIndex = 0;
                                    while (stringTokenizer.hasMoreTokens()) {
                                        token = stringTokenizer.nextToken();
                                        switch (nTokenIndex) {
                                            case 2:
                                                strMac = token;
                                                break;
                                            case 3:
                                                strIP = token;
                                                break;
                                            case 9:
                                                nPort = Integer.parseInt(token);
                                                break;
                                            case 12:
                                                nDevID = Integer.parseInt(token);
                                                bIsOK = true;
                                                strName = nDevID;
                                                break;
                                            default:
                                                break;
                                        }
                                        nTokenIndex++;
                                    }
                                    if (bIsOK) {
                                        info = new DeviceInfo(-1, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                        if (!table.containsKey(strMac)) {
                                            table.put(strMac, info);
                                        }
                                    }
                                }
                                if (recvUDPSocket != null) {
                                    recvUDPSocket.close();
                                }
                                if (datagramSocket != null) {
                                    datagramSocket.close();
                                }
                                udpSocket = datagramSocket;
                                datagramPacket = datagramPacket2;
                                hashtable = table;
                                return table;
                            }
                            while (nSearchID == _nSearchID && recvUDPSocket != null) {
                                Arrays.fill(recvData, (byte) 0);
                                datagramPacket2 = new DatagramPacket(recvData, 512);
                                recvUDPSocket.receive(datagramPacket2);
                                if (nTimeouts >= 10) {
                                    if (nSearchID == _nSearchID) {
                                    }
                                }
                                strBulder = new StringBuilder();
                                receiveData = datagramPacket2.getData();
                                j = 0;
                                while (j < receiveData.length) {
                                    if (receiveData[j] != (byte) 0) {
                                        strBulder.append((char) receiveData[j]);
                                        j++;
                                    } else {
                                        if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                            if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                                continue;
                                            }
                                        }
                                        bIsOK = false;
                                        stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                        nTokenIndex = 0;
                                        while (stringTokenizer.hasMoreTokens()) {
                                            token = stringTokenizer.nextToken();
                                            switch (nTokenIndex) {
                                                case 2:
                                                    strMac = token;
                                                    break;
                                                case 3:
                                                    strIP = token;
                                                    break;
                                                case 9:
                                                    nPort = Integer.parseInt(token);
                                                    break;
                                                case 12:
                                                    nDevID = Integer.parseInt(token);
                                                    bIsOK = true;
                                                    strName = nDevID;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nTokenIndex++;
                                        }
                                        if (bIsOK) {
                                            info = new DeviceInfo(-1, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                            if (!table.containsKey(strMac)) {
                                                table.put(strMac, info);
                                            }
                                        }
                                    }
                                }
                                if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                    if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                        continue;
                                    }
                                }
                                bIsOK = false;
                                stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                nTokenIndex = 0;
                                while (stringTokenizer.hasMoreTokens()) {
                                    token = stringTokenizer.nextToken();
                                    switch (nTokenIndex) {
                                        case 2:
                                            strMac = token;
                                            break;
                                        case 3:
                                            strIP = token;
                                            break;
                                        case 9:
                                            nPort = Integer.parseInt(token);
                                            break;
                                        case 12:
                                            nDevID = Integer.parseInt(token);
                                            bIsOK = true;
                                            strName = nDevID;
                                            break;
                                        default:
                                            break;
                                    }
                                    nTokenIndex++;
                                }
                                if (bIsOK) {
                                    info = new DeviceInfo(-1, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                    if (!table.containsKey(strMac)) {
                                        table.put(strMac, info);
                                    }
                                }
                            }
                            if (recvUDPSocket != null) {
                                recvUDPSocket.close();
                            }
                            if (datagramSocket != null) {
                                datagramSocket.close();
                            }
                            udpSocket = datagramSocket;
                            datagramPacket = datagramPacket2;
                            hashtable = table;
                            return table;
                        } catch (SocketException e9) {
                            udpSocket = datagramSocket;
                            datagramPacket = datagramPacket2;
                            if (udpSocket != null) {
                                try {
                                    udpSocket.close();
                                } catch (Exception e10) {
                                }
                            }
                            return null;
                        } catch (UnknownHostException e11) {
                            udpSocket = datagramSocket;
                            datagramPacket = datagramPacket2;
                            if (udpSocket != null) {
                                try {
                                    udpSocket.close();
                                } catch (Exception e12) {
                                }
                            }
                            return null;
                        } catch (IOException e13) {
                            udpSocket = datagramSocket;
                            datagramPacket = datagramPacket2;
                            if (udpSocket != null) {
                                try {
                                    udpSocket.close();
                                } catch (Exception e14) {
                                }
                            }
                            return null;
                        }
                    } catch (SocketException e15) {
                        udpSocket = datagramSocket;
                        if (udpSocket != null) {
                            udpSocket.close();
                        }
                        return null;
                    } catch (UnknownHostException e16) {
                        udpSocket = datagramSocket;
                        if (udpSocket != null) {
                            udpSocket.close();
                        }
                        return null;
                    } catch (IOException e17) {
                        udpSocket = datagramSocket;
                        if (udpSocket != null) {
                            udpSocket.close();
                        }
                        return null;
                    }
                } catch (SocketException e18) {
                    if (udpSocket != null) {
                        udpSocket.close();
                    }
                    return null;
                } catch (UnknownHostException e19) {
                    if (udpSocket != null) {
                        udpSocket.close();
                    }
                    return null;
                } catch (IOException e20) {
                    if (udpSocket != null) {
                        udpSocket.close();
                    }
                    return null;
                }
            } catch (Throwable th3) {
                th = th3;
                throw th;
            }
        }
    }

    private static Hashtable<String, DeviceInfo> searchP2P(int nSearchID) {
        byte[] data;
        Hashtable<String, DeviceInfo> table;
        int nTimeouts;
        byte[] recvData;
        DatagramPacket datagramPacket;
        Hashtable<String, DeviceInfo> hashtable;
        StringBuilder strBulder;
        byte[] receiveData;
        int j;
        boolean bIsOK;
        StringTokenizer stringTokenizer;
        DeviceInfo info;
        Throwable th;
        synchronized (searchLock) {
            int nTokenIndex;
            String token;
            Log.d("dqx", "searchP2P(int nSearchID)");
            int nDevID = 0;
            String strName = null;
            String strIP = null;
            int nPort = 8800;
            String strMac = null;
            DatagramSocket udpSocket = null;
            InetAddress serverAddress = null;
            try {
                DatagramSocket datagramSocket = new DatagramSocket(Defines.AP_UDP_PORT);
                try {
                    datagramSocket.setSoTimeout(200);
                    serverAddress = InetAddress.getByName(Defines.AP_MODE_IP);
                    udpSocket = datagramSocket;
                } catch (SocketException e) {
                    udpSocket = datagramSocket;
                    if (udpSocket != null) {
                        try {
                            udpSocket.close();
                        } catch (Exception e2) {
                        }
                        return null;
                    }
                    data = "NVDEVSEARCH^100".getBytes();
                    try {
                        udpSocket.send(new DatagramPacket(data, data.length, serverAddress, 4000));
                        table = new Hashtable();
                        nTimeouts = 0;
                        recvData = new byte[2048];
                        while (nSearchID == _nSearchID) {
                            try {
                                Arrays.fill(recvData, (byte) 0);
                                datagramPacket = new DatagramPacket(recvData, 512);
                                try {
                                    udpSocket.receive(datagramPacket);
                                } catch (SocketTimeoutException e3) {
                                    nTimeouts++;
                                } catch (IOException e4) {
                                    nTimeouts = 20;
                                }
                                if (nTimeouts >= 10) {
                                    if (nSearchID == _nSearchID) {
                                        if (udpSocket != null) {
                                            udpSocket.close();
                                        }
                                        hashtable = table;
                                        return table;
                                    }
                                }
                                strBulder = new StringBuilder();
                                receiveData = datagramPacket.getData();
                                j = 0;
                                while (j < receiveData.length) {
                                    if (receiveData[j] != (byte) 0) {
                                        if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                            if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                                continue;
                                            }
                                        }
                                        bIsOK = false;
                                        stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                        nTokenIndex = 0;
                                        while (stringTokenizer.hasMoreTokens()) {
                                            token = stringTokenizer.nextToken();
                                            switch (nTokenIndex) {
                                                case 2:
                                                    strMac = token;
                                                    break;
                                                case 3:
                                                    strIP = token;
                                                    break;
                                                case 9:
                                                    try {
                                                        nPort = Integer.parseInt(token);
                                                        break;
                                                    } catch (Exception e5) {
                                                        nPort = 8800;
                                                        break;
                                                    }
                                                case 12:
                                                    nDevID = Integer.parseInt(token);
                                                    bIsOK = true;
                                                    strName = nDevID;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nTokenIndex++;
                                        }
                                        if (bIsOK) {
                                            info = new DeviceInfo(0, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                            if (!table.containsKey(strMac)) {
                                                table.put(strMac, info);
                                            }
                                            if (udpSocket != null) {
                                                udpSocket.close();
                                            }
                                            hashtable = table;
                                            return table;
                                        }
                                    } else {
                                        strBulder.append((char) receiveData[j]);
                                        j++;
                                    }
                                }
                                if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                    if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                        continue;
                                    }
                                }
                                bIsOK = false;
                                stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                nTokenIndex = 0;
                                while (stringTokenizer.hasMoreTokens()) {
                                    token = stringTokenizer.nextToken();
                                    switch (nTokenIndex) {
                                        case 2:
                                            strMac = token;
                                            break;
                                        case 3:
                                            strIP = token;
                                            break;
                                        case 9:
                                            nPort = Integer.parseInt(token);
                                            break;
                                        case 12:
                                            nDevID = Integer.parseInt(token);
                                            bIsOK = true;
                                            strName = nDevID;
                                            break;
                                        default:
                                            break;
                                    }
                                    nTokenIndex++;
                                }
                                if (bIsOK) {
                                    info = new DeviceInfo(0, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                    if (table.containsKey(strMac)) {
                                        table.put(strMac, info);
                                    }
                                    if (udpSocket != null) {
                                        udpSocket.close();
                                    }
                                    hashtable = table;
                                    return table;
                                }
                            } catch (Exception e6) {
                            } catch (Throwable th2) {
                                th = th2;
                                hashtable = table;
                            }
                        }
                        if (udpSocket != null) {
                            udpSocket.close();
                        }
                        hashtable = table;
                        return table;
                    } catch (IOException e7) {
                        try {
                            udpSocket.close();
                        } catch (Exception e8) {
                        }
                        return null;
                    }
                } catch (UnknownHostException e9) {
                    udpSocket = datagramSocket;
                    try {
                        udpSocket.close();
                    } catch (Exception e10) {
                    }
                    return null;
                }
            } catch (SocketException e11) {
                if (udpSocket != null) {
                    udpSocket.close();
                    return null;
                }
                data = "NVDEVSEARCH^100".getBytes();
                udpSocket.send(new DatagramPacket(data, data.length, serverAddress, 4000));
                table = new Hashtable();
                nTimeouts = 0;
                recvData = new byte[2048];
                while (nSearchID == _nSearchID) {
                    Arrays.fill(recvData, (byte) 0);
                    datagramPacket = new DatagramPacket(recvData, 512);
                    udpSocket.receive(datagramPacket);
                    if (nTimeouts >= 10) {
                        if (nSearchID == _nSearchID) {
                            if (udpSocket != null) {
                                udpSocket.close();
                            }
                            hashtable = table;
                            return table;
                        }
                    }
                    strBulder = new StringBuilder();
                    receiveData = datagramPacket.getData();
                    j = 0;
                    while (j < receiveData.length) {
                        if (receiveData[j] != (byte) 0) {
                            strBulder.append((char) receiveData[j]);
                            j++;
                        } else {
                            if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                    continue;
                                }
                            }
                            bIsOK = false;
                            stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                            nTokenIndex = 0;
                            while (stringTokenizer.hasMoreTokens()) {
                                token = stringTokenizer.nextToken();
                                switch (nTokenIndex) {
                                    case 2:
                                        strMac = token;
                                        break;
                                    case 3:
                                        strIP = token;
                                        break;
                                    case 9:
                                        nPort = Integer.parseInt(token);
                                        break;
                                    case 12:
                                        nDevID = Integer.parseInt(token);
                                        bIsOK = true;
                                        strName = nDevID;
                                        break;
                                    default:
                                        break;
                                }
                                nTokenIndex++;
                            }
                            if (bIsOK) {
                                info = new DeviceInfo(0, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                if (table.containsKey(strMac)) {
                                    table.put(strMac, info);
                                }
                                if (udpSocket != null) {
                                    udpSocket.close();
                                }
                                hashtable = table;
                                return table;
                            }
                        }
                    }
                    if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                        if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                            continue;
                        }
                    }
                    bIsOK = false;
                    stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                    nTokenIndex = 0;
                    while (stringTokenizer.hasMoreTokens()) {
                        token = stringTokenizer.nextToken();
                        switch (nTokenIndex) {
                            case 2:
                                strMac = token;
                                break;
                            case 3:
                                strIP = token;
                                break;
                            case 9:
                                nPort = Integer.parseInt(token);
                                break;
                            case 12:
                                nDevID = Integer.parseInt(token);
                                bIsOK = true;
                                strName = nDevID;
                                break;
                            default:
                                break;
                        }
                        nTokenIndex++;
                    }
                    if (bIsOK) {
                        info = new DeviceInfo(0, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                        if (table.containsKey(strMac)) {
                            table.put(strMac, info);
                        }
                        if (udpSocket != null) {
                            udpSocket.close();
                        }
                        hashtable = table;
                        return table;
                    }
                }
                if (udpSocket != null) {
                    udpSocket.close();
                }
                hashtable = table;
                return table;
            } catch (UnknownHostException e12) {
                udpSocket.close();
                return null;
            }
            try {
                data = "NVDEVSEARCH^100".getBytes();
                udpSocket.send(new DatagramPacket(data, data.length, serverAddress, 4000));
                table = new Hashtable();
                nTimeouts = 0;
                recvData = new byte[2048];
                while (nSearchID == _nSearchID && udpSocket != null) {
                    Arrays.fill(recvData, (byte) 0);
                    datagramPacket = new DatagramPacket(recvData, 512);
                    udpSocket.receive(datagramPacket);
                    if (nTimeouts >= 10) {
                        if (nSearchID == _nSearchID) {
                        }
                    }
                    strBulder = new StringBuilder();
                    receiveData = datagramPacket.getData();
                    j = 0;
                    while (j < receiveData.length) {
                        if (receiveData[j] != (byte) 0) {
                            strBulder.append((char) receiveData[j]);
                            j++;
                        } else {
                            if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                    continue;
                                }
                            }
                            bIsOK = false;
                            stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                            nTokenIndex = 0;
                            while (stringTokenizer.hasMoreTokens()) {
                                token = stringTokenizer.nextToken();
                                switch (nTokenIndex) {
                                    case 2:
                                        strMac = token;
                                        break;
                                    case 3:
                                        strIP = token;
                                        break;
                                    case 9:
                                        nPort = Integer.parseInt(token);
                                        break;
                                    case 12:
                                        nDevID = Integer.parseInt(token);
                                        bIsOK = true;
                                        strName = nDevID;
                                        break;
                                    default:
                                        break;
                                }
                                nTokenIndex++;
                            }
                            if (bIsOK) {
                                info = new DeviceInfo(0, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                if (table.containsKey(strMac)) {
                                    table.put(strMac, info);
                                }
                            }
                        }
                    }
                    if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                        if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                            continue;
                        }
                    }
                    bIsOK = false;
                    stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                    nTokenIndex = 0;
                    while (stringTokenizer.hasMoreTokens()) {
                        token = stringTokenizer.nextToken();
                        switch (nTokenIndex) {
                            case 2:
                                strMac = token;
                                break;
                            case 3:
                                strIP = token;
                                break;
                            case 9:
                                nPort = Integer.parseInt(token);
                                break;
                            case 12:
                                nDevID = Integer.parseInt(token);
                                bIsOK = true;
                                strName = nDevID;
                                break;
                            default:
                                break;
                        }
                        nTokenIndex++;
                    }
                    if (bIsOK) {
                        info = new DeviceInfo(0, nDevID, strName, strIP, nPort, "admin", Constants.MAIN_VERSION_TAG, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                        if (table.containsKey(strMac)) {
                            table.put(strMac, info);
                        }
                    }
                }
                if (udpSocket != null) {
                    udpSocket.close();
                }
                hashtable = table;
                return table;
            } catch (Throwable th3) {
                th = th3;
                throw th;
            }
        }
    }

    private static Hashtable<String, DeviceInfo> searchWithBroadCast(int nSearchID, int nConfigID) {
        DatagramPacket datagramPacket;
        Hashtable<String, DeviceInfo> hashtable;
        StringBuilder strBulder;
        int nCID;
        boolean bIsOK;
        StringTokenizer stringTokenizer;
        String strUsername;
        String strPassword;
        DeviceInfo info;
        Throwable th;
        synchronized (searchLock) {
            try {
                String searchCMD = "NVDEVSEARCH^100";
                DatagramSocket udpSocket = null;
                try {
                    DatagramSocket datagramSocket = new DatagramSocket(Defines.DEFAULT_SEND_PORT);
                    try {
                        DatagramPacket datagramPacket2 = new DatagramPacket(buffer, 128);
                        try {
                            byte[] receiveData;
                            int j;
                            int nTokenIndex;
                            String token;
                            byte[] data = searchCMD.getBytes();
                            datagramPacket2.setData(data);
                            datagramPacket2.setLength(data.length);
                            datagramPacket2.setPort(Defines.DEFAULT_SEND_PORT);
                            datagramPacket2.setAddress(InetAddress.getByName("255.255.255.255"));
                            datagramSocket.send(datagramPacket2);
                            Hashtable<String, DeviceInfo> table = new Hashtable();
                            byte[] recvData = new byte[2048];
                            int nDevID = 0;
                            String strName = null;
                            String strIP = null;
                            int nPort = 8800;
                            String strMac = null;
                            int nTimeouts = 0;
                            DatagramSocket recvUDPSocket = null;
                            try {
                                datagramSocket = new DatagramSocket(Defines.DEFAULT_RECV_PORT);
                                try {
                                    datagramSocket.setReceiveBufferSize(16384);
                                    datagramSocket.setSoTimeout(200);
                                    recvUDPSocket = datagramSocket;
                                } catch (SocketException e) {
                                    recvUDPSocket = datagramSocket;
                                    if (recvUDPSocket != null) {
                                        try {
                                            recvUDPSocket.close();
                                        } catch (Exception e2) {
                                        }
                                    }
                                    recvUDPSocket = null;
                                    while (nSearchID == _nSearchID) {
                                        try {
                                            Arrays.fill(recvData, (byte) 0);
                                            datagramPacket2 = new DatagramPacket(recvData, 512);
                                            try {
                                                recvUDPSocket.receive(datagramPacket2);
                                            } catch (SocketTimeoutException e3) {
                                                nTimeouts++;
                                            } catch (IOException e4) {
                                                nTimeouts = 20;
                                            }
                                            if (nTimeouts >= 10) {
                                                if (nSearchID == _nSearchID) {
                                                    if (recvUDPSocket != null) {
                                                        try {
                                                            recvUDPSocket.close();
                                                        } catch (Exception e5) {
                                                        }
                                                    }
                                                    if (datagramSocket != null) {
                                                        try {
                                                            datagramSocket.close();
                                                        } catch (Exception e6) {
                                                        }
                                                    }
                                                    udpSocket = datagramSocket;
                                                    datagramPacket = datagramPacket2;
                                                    hashtable = table;
                                                    return table;
                                                }
                                            }
                                            strBulder = new StringBuilder();
                                            receiveData = datagramPacket2.getData();
                                            j = 0;
                                            while (j < receiveData.length) {
                                                if (receiveData[j] != (byte) 0) {
                                                    nCID = 0;
                                                    if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                                        if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                                            continue;
                                                        }
                                                    }
                                                    bIsOK = false;
                                                    stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                                    nTokenIndex = 0;
                                                    while (stringTokenizer.hasMoreTokens()) {
                                                        token = stringTokenizer.nextToken();
                                                        switch (nTokenIndex) {
                                                            case 2:
                                                                strMac = token;
                                                                break;
                                                            case 3:
                                                                strIP = token;
                                                                break;
                                                            case 9:
                                                                try {
                                                                    nPort = Integer.parseInt(token);
                                                                    break;
                                                                } catch (Exception e7) {
                                                                    nPort = 8800;
                                                                    break;
                                                                }
                                                            case 12:
                                                                nDevID = Integer.parseInt(token);
                                                                strName = nDevID;
                                                                break;
                                                            case 13:
                                                                break;
                                                            default:
                                                                break;
                                                        }
                                                        nCID = Integer.parseInt(token);
                                                        bIsOK = true;
                                                        nTokenIndex++;
                                                    }
                                                    if (bIsOK) {
                                                        strUsername = "admin";
                                                        strPassword = Constants.MAIN_VERSION_TAG;
                                                        if (nCID == nConfigID) {
                                                            info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                                            info.setnOnLineStat(101);
                                                            info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                                            if (!table.containsKey(strMac)) {
                                                                table.put(strMac, info);
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    strBulder.append((char) receiveData[j]);
                                                    j++;
                                                }
                                            }
                                            nCID = 0;
                                            if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                                if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                                    continue;
                                                }
                                            }
                                            bIsOK = false;
                                            stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                            nTokenIndex = 0;
                                            while (stringTokenizer.hasMoreTokens()) {
                                                token = stringTokenizer.nextToken();
                                                switch (nTokenIndex) {
                                                    case 2:
                                                        strMac = token;
                                                        break;
                                                    case 3:
                                                        strIP = token;
                                                        break;
                                                    case 9:
                                                        nPort = Integer.parseInt(token);
                                                        break;
                                                    case 12:
                                                        nDevID = Integer.parseInt(token);
                                                        strName = nDevID;
                                                        break;
                                                    case 13:
                                                        break;
                                                    default:
                                                        break;
                                                }
                                                nCID = Integer.parseInt(token);
                                                bIsOK = true;
                                                nTokenIndex++;
                                            }
                                            if (bIsOK) {
                                                strUsername = "admin";
                                                strPassword = Constants.MAIN_VERSION_TAG;
                                                if (nCID == nConfigID) {
                                                    info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                                    info.setnOnLineStat(101);
                                                    info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                                    if (!table.containsKey(strMac)) {
                                                        table.put(strMac, info);
                                                    }
                                                }
                                            }
                                        } catch (Throwable th2) {
                                            th = th2;
                                            hashtable = table;
                                        }
                                    }
                                    if (recvUDPSocket != null) {
                                        recvUDPSocket.close();
                                    }
                                    if (datagramSocket != null) {
                                        datagramSocket.close();
                                    }
                                    udpSocket = datagramSocket;
                                    datagramPacket = datagramPacket2;
                                    hashtable = table;
                                    return table;
                                }
                            } catch (SocketException e8) {
                                if (recvUDPSocket != null) {
                                    recvUDPSocket.close();
                                }
                                recvUDPSocket = null;
                                while (nSearchID == _nSearchID) {
                                    Arrays.fill(recvData, (byte) 0);
                                    datagramPacket2 = new DatagramPacket(recvData, 512);
                                    recvUDPSocket.receive(datagramPacket2);
                                    if (nTimeouts >= 10) {
                                        if (nSearchID == _nSearchID) {
                                            if (recvUDPSocket != null) {
                                                recvUDPSocket.close();
                                            }
                                            if (datagramSocket != null) {
                                                datagramSocket.close();
                                            }
                                            udpSocket = datagramSocket;
                                            datagramPacket = datagramPacket2;
                                            hashtable = table;
                                            return table;
                                        }
                                    }
                                    strBulder = new StringBuilder();
                                    receiveData = datagramPacket2.getData();
                                    j = 0;
                                    while (j < receiveData.length) {
                                        if (receiveData[j] != (byte) 0) {
                                            strBulder.append((char) receiveData[j]);
                                            j++;
                                        } else {
                                            nCID = 0;
                                            if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                                if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                                    continue;
                                                }
                                            }
                                            bIsOK = false;
                                            stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                            nTokenIndex = 0;
                                            while (stringTokenizer.hasMoreTokens()) {
                                                token = stringTokenizer.nextToken();
                                                switch (nTokenIndex) {
                                                    case 2:
                                                        strMac = token;
                                                        break;
                                                    case 3:
                                                        strIP = token;
                                                        break;
                                                    case 9:
                                                        nPort = Integer.parseInt(token);
                                                        break;
                                                    case 12:
                                                        nDevID = Integer.parseInt(token);
                                                        strName = nDevID;
                                                        break;
                                                    case 13:
                                                        break;
                                                    default:
                                                        break;
                                                }
                                                nCID = Integer.parseInt(token);
                                                bIsOK = true;
                                                nTokenIndex++;
                                            }
                                            if (bIsOK) {
                                                strUsername = "admin";
                                                strPassword = Constants.MAIN_VERSION_TAG;
                                                if (nCID == nConfigID) {
                                                    info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                                    info.setnOnLineStat(101);
                                                    info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                                    if (!table.containsKey(strMac)) {
                                                        table.put(strMac, info);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    nCID = 0;
                                    if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                        if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                            continue;
                                        }
                                    }
                                    bIsOK = false;
                                    stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                    nTokenIndex = 0;
                                    while (stringTokenizer.hasMoreTokens()) {
                                        token = stringTokenizer.nextToken();
                                        switch (nTokenIndex) {
                                            case 2:
                                                strMac = token;
                                                break;
                                            case 3:
                                                strIP = token;
                                                break;
                                            case 9:
                                                nPort = Integer.parseInt(token);
                                                break;
                                            case 12:
                                                nDevID = Integer.parseInt(token);
                                                strName = nDevID;
                                                break;
                                            case 13:
                                                break;
                                            default:
                                                break;
                                        }
                                        nCID = Integer.parseInt(token);
                                        bIsOK = true;
                                        nTokenIndex++;
                                    }
                                    if (bIsOK) {
                                        strUsername = "admin";
                                        strPassword = Constants.MAIN_VERSION_TAG;
                                        if (nCID == nConfigID) {
                                            info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                            info.setnOnLineStat(101);
                                            info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                            if (!table.containsKey(strMac)) {
                                                table.put(strMac, info);
                                            }
                                        }
                                    }
                                }
                                if (recvUDPSocket != null) {
                                    recvUDPSocket.close();
                                }
                                if (datagramSocket != null) {
                                    datagramSocket.close();
                                }
                                udpSocket = datagramSocket;
                                datagramPacket = datagramPacket2;
                                hashtable = table;
                                return table;
                            }
                            while (nSearchID == _nSearchID && recvUDPSocket != null) {
                                Arrays.fill(recvData, (byte) 0);
                                datagramPacket2 = new DatagramPacket(recvData, 512);
                                recvUDPSocket.receive(datagramPacket2);
                                if (nTimeouts >= 10) {
                                    if (nSearchID == _nSearchID) {
                                    }
                                }
                                strBulder = new StringBuilder();
                                receiveData = datagramPacket2.getData();
                                j = 0;
                                while (j < receiveData.length) {
                                    if (receiveData[j] != (byte) 0) {
                                        strBulder.append((char) receiveData[j]);
                                        j++;
                                    } else {
                                        nCID = 0;
                                        if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                            if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                                continue;
                                            }
                                        }
                                        bIsOK = false;
                                        stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                        nTokenIndex = 0;
                                        while (stringTokenizer.hasMoreTokens()) {
                                            token = stringTokenizer.nextToken();
                                            switch (nTokenIndex) {
                                                case 2:
                                                    strMac = token;
                                                    break;
                                                case 3:
                                                    strIP = token;
                                                    break;
                                                case 9:
                                                    nPort = Integer.parseInt(token);
                                                    break;
                                                case 12:
                                                    nDevID = Integer.parseInt(token);
                                                    strName = nDevID;
                                                    break;
                                                case 13:
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nCID = Integer.parseInt(token);
                                            bIsOK = true;
                                            nTokenIndex++;
                                        }
                                        if (bIsOK) {
                                            strUsername = "admin";
                                            strPassword = Constants.MAIN_VERSION_TAG;
                                            if (nCID == nConfigID) {
                                                info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                                info.setnOnLineStat(101);
                                                info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                                if (!table.containsKey(strMac)) {
                                                    table.put(strMac, info);
                                                }
                                            }
                                        }
                                    }
                                }
                                nCID = 0;
                                if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                    if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                        continue;
                                    }
                                }
                                bIsOK = false;
                                stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                nTokenIndex = 0;
                                while (stringTokenizer.hasMoreTokens()) {
                                    token = stringTokenizer.nextToken();
                                    switch (nTokenIndex) {
                                        case 2:
                                            strMac = token;
                                            break;
                                        case 3:
                                            strIP = token;
                                            break;
                                        case 9:
                                            nPort = Integer.parseInt(token);
                                            break;
                                        case 12:
                                            nDevID = Integer.parseInt(token);
                                            strName = nDevID;
                                            break;
                                        case 13:
                                            break;
                                        default:
                                            break;
                                    }
                                    nCID = Integer.parseInt(token);
                                    bIsOK = true;
                                    nTokenIndex++;
                                }
                                if (bIsOK) {
                                    strUsername = "admin";
                                    strPassword = Constants.MAIN_VERSION_TAG;
                                    if (nCID == nConfigID) {
                                        info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                        info.setnOnLineStat(101);
                                        info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                        if (!table.containsKey(strMac)) {
                                            table.put(strMac, info);
                                        }
                                    }
                                }
                            }
                            if (recvUDPSocket != null) {
                                recvUDPSocket.close();
                            }
                            if (datagramSocket != null) {
                                datagramSocket.close();
                            }
                            udpSocket = datagramSocket;
                            datagramPacket = datagramPacket2;
                            hashtable = table;
                            return table;
                        } catch (SocketException e9) {
                            udpSocket = datagramSocket;
                            datagramPacket = datagramPacket2;
                            if (udpSocket != null) {
                                try {
                                    udpSocket.close();
                                } catch (Exception e10) {
                                }
                            }
                            return null;
                        } catch (UnknownHostException e11) {
                            udpSocket = datagramSocket;
                            datagramPacket = datagramPacket2;
                            if (udpSocket != null) {
                                try {
                                    udpSocket.close();
                                } catch (Exception e12) {
                                }
                            }
                            return null;
                        } catch (IOException e13) {
                            udpSocket = datagramSocket;
                            datagramPacket = datagramPacket2;
                            if (udpSocket != null) {
                                try {
                                    udpSocket.close();
                                } catch (Exception e14) {
                                }
                            }
                            return null;
                        }
                    } catch (SocketException e15) {
                        udpSocket = datagramSocket;
                        if (udpSocket != null) {
                            udpSocket.close();
                        }
                        return null;
                    } catch (UnknownHostException e16) {
                        udpSocket = datagramSocket;
                        if (udpSocket != null) {
                            udpSocket.close();
                        }
                        return null;
                    } catch (IOException e17) {
                        udpSocket = datagramSocket;
                        if (udpSocket != null) {
                            udpSocket.close();
                        }
                        return null;
                    }
                } catch (SocketException e18) {
                    if (udpSocket != null) {
                        udpSocket.close();
                    }
                    return null;
                } catch (UnknownHostException e19) {
                    if (udpSocket != null) {
                        udpSocket.close();
                    }
                    return null;
                } catch (IOException e20) {
                    if (udpSocket != null) {
                        udpSocket.close();
                    }
                    return null;
                }
            } catch (Throwable th3) {
                th = th3;
                throw th;
            }
        }
    }

    private static Hashtable<String, DeviceInfo> searchP2P(int nSearchID, int nConfigID) {
        Hashtable<String, DeviceInfo> table;
        int nTimeouts;
        byte[] recvData;
        DatagramPacket datagramPacket;
        Hashtable<String, DeviceInfo> hashtable;
        int nCID;
        boolean bIsOK;
        StringTokenizer stringTokenizer;
        int nTokenIndex;
        String token;
        DeviceInfo info;
        synchronized (searchLock) {
            byte[] data;
            StringBuilder strBulder;
            byte[] receiveData;
            int j;
            String strUsername;
            String strPassword;
            int nDevID = 0;
            String strName = null;
            String strIP = null;
            int nPort = 8800;
            String strMac = null;
            DatagramSocket udpSocket = null;
            InetAddress serverAddress = null;
            try {
                DatagramSocket datagramSocket = new DatagramSocket(Defines.AP_UDP_PORT);
                try {
                    datagramSocket.setSoTimeout(200);
                    serverAddress = InetAddress.getByName(Defines.AP_MODE_IP);
                    udpSocket = datagramSocket;
                } catch (SocketException e) {
                    udpSocket = datagramSocket;
                    if (udpSocket != null) {
                        try {
                            udpSocket.close();
                        } catch (Exception e2) {
                        }
                        return null;
                    }
                    data = "NVDEVSEARCH^100".getBytes();
                    try {
                        udpSocket.send(new DatagramPacket(data, data.length, serverAddress, 4000));
                        table = new Hashtable();
                        nTimeouts = 0;
                        recvData = new byte[2048];
                        while (nSearchID == _nSearchID) {
                            Arrays.fill(recvData, (byte) 0);
                            datagramPacket = new DatagramPacket(recvData, 512);
                            try {
                                udpSocket.receive(datagramPacket);
                            } catch (SocketTimeoutException e3) {
                                nTimeouts++;
                            } catch (IOException e4) {
                                nTimeouts = 20;
                            }
                            if (nTimeouts >= 10) {
                                try {
                                    if (nSearchID == _nSearchID) {
                                        if (udpSocket != null) {
                                            udpSocket.close();
                                        }
                                        hashtable = table;
                                        return table;
                                    }
                                } catch (Exception e5) {
                                } catch (Throwable th) {
                                    th = th;
                                    hashtable = table;
                                }
                            }
                            strBulder = new StringBuilder();
                            receiveData = datagramPacket.getData();
                            j = 0;
                            while (j < receiveData.length) {
                                if (receiveData[j] != (byte) 0) {
                                    nCID = 0;
                                    if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                        if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                            continue;
                                        }
                                    }
                                    bIsOK = false;
                                    stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                                    nTokenIndex = 0;
                                    while (stringTokenizer.hasMoreTokens()) {
                                        token = stringTokenizer.nextToken();
                                        switch (nTokenIndex) {
                                            case 2:
                                                strMac = token;
                                                break;
                                            case 3:
                                                strIP = token;
                                                break;
                                            case 9:
                                                try {
                                                    nPort = Integer.parseInt(token);
                                                    break;
                                                } catch (Exception e6) {
                                                    nPort = 8800;
                                                    break;
                                                }
                                            case 12:
                                                nDevID = Integer.parseInt(token);
                                                strName = nDevID;
                                                break;
                                            case 13:
                                                break;
                                            default:
                                                break;
                                        }
                                        nCID = Integer.parseInt(token);
                                        bIsOK = true;
                                        nTokenIndex++;
                                    }
                                    if (bIsOK) {
                                        strUsername = "admin";
                                        strPassword = Constants.MAIN_VERSION_TAG;
                                        if (nCID == nConfigID) {
                                            info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                            info.setnOnLineStat(101);
                                            info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                            if (!table.containsKey(strMac)) {
                                                table.put(strMac, info);
                                            }
                                        }
                                    }
                                } else {
                                    strBulder.append((char) receiveData[j]);
                                    j++;
                                }
                            }
                            nCID = 0;
                            if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                    continue;
                                }
                            }
                            bIsOK = false;
                            stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                            nTokenIndex = 0;
                            while (stringTokenizer.hasMoreTokens()) {
                                token = stringTokenizer.nextToken();
                                switch (nTokenIndex) {
                                    case 2:
                                        strMac = token;
                                        break;
                                    case 3:
                                        strIP = token;
                                        break;
                                    case 9:
                                        nPort = Integer.parseInt(token);
                                        break;
                                    case 12:
                                        nDevID = Integer.parseInt(token);
                                        strName = nDevID;
                                        break;
                                    case 13:
                                        break;
                                    default:
                                        break;
                                }
                                nCID = Integer.parseInt(token);
                                bIsOK = true;
                                nTokenIndex++;
                            }
                            if (bIsOK) {
                                strUsername = "admin";
                                strPassword = Constants.MAIN_VERSION_TAG;
                                if (nCID == nConfigID) {
                                    info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                    info.setnOnLineStat(101);
                                    info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                    if (!table.containsKey(strMac)) {
                                        table.put(strMac, info);
                                    }
                                }
                            }
                        }
                        if (udpSocket != null) {
                            udpSocket.close();
                        }
                        hashtable = table;
                        return table;
                    } catch (IOException e7) {
                        try {
                            udpSocket.close();
                        } catch (Exception e8) {
                        }
                        return null;
                    }
                } catch (UnknownHostException e9) {
                    udpSocket = datagramSocket;
                    try {
                        udpSocket.close();
                    } catch (Exception e10) {
                    }
                    return null;
                } catch (Throwable th2) {
                    Throwable th3;
                    th3 = th2;
                    udpSocket = datagramSocket;
                    throw th3;
                }
            } catch (SocketException e11) {
                if (udpSocket != null) {
                    udpSocket.close();
                    return null;
                }
                data = "NVDEVSEARCH^100".getBytes();
                udpSocket.send(new DatagramPacket(data, data.length, serverAddress, 4000));
                table = new Hashtable();
                nTimeouts = 0;
                recvData = new byte[2048];
                while (nSearchID == _nSearchID) {
                    Arrays.fill(recvData, (byte) 0);
                    datagramPacket = new DatagramPacket(recvData, 512);
                    udpSocket.receive(datagramPacket);
                    if (nTimeouts >= 10) {
                        if (nSearchID == _nSearchID) {
                            if (udpSocket != null) {
                                udpSocket.close();
                            }
                            hashtable = table;
                            return table;
                        }
                    }
                    strBulder = new StringBuilder();
                    receiveData = datagramPacket.getData();
                    j = 0;
                    while (j < receiveData.length) {
                        if (receiveData[j] != (byte) 0) {
                            strBulder.append((char) receiveData[j]);
                            j++;
                        } else {
                            nCID = 0;
                            if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                    continue;
                                }
                            }
                            bIsOK = false;
                            stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                            nTokenIndex = 0;
                            while (stringTokenizer.hasMoreTokens()) {
                                token = stringTokenizer.nextToken();
                                switch (nTokenIndex) {
                                    case 2:
                                        strMac = token;
                                        break;
                                    case 3:
                                        strIP = token;
                                        break;
                                    case 9:
                                        nPort = Integer.parseInt(token);
                                        break;
                                    case 12:
                                        nDevID = Integer.parseInt(token);
                                        strName = nDevID;
                                        break;
                                    case 13:
                                        break;
                                    default:
                                        break;
                                }
                                nCID = Integer.parseInt(token);
                                bIsOK = true;
                                nTokenIndex++;
                            }
                            if (bIsOK) {
                                strUsername = "admin";
                                strPassword = Constants.MAIN_VERSION_TAG;
                                if (nCID == nConfigID) {
                                    info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                    info.setnOnLineStat(101);
                                    info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                    if (!table.containsKey(strMac)) {
                                        table.put(strMac, info);
                                    }
                                }
                            }
                        }
                    }
                    nCID = 0;
                    if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                        if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                            continue;
                        }
                    }
                    bIsOK = false;
                    stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                    nTokenIndex = 0;
                    while (stringTokenizer.hasMoreTokens()) {
                        token = stringTokenizer.nextToken();
                        switch (nTokenIndex) {
                            case 2:
                                strMac = token;
                                break;
                            case 3:
                                strIP = token;
                                break;
                            case 9:
                                nPort = Integer.parseInt(token);
                                break;
                            case 12:
                                nDevID = Integer.parseInt(token);
                                strName = nDevID;
                                break;
                            case 13:
                                break;
                            default:
                                break;
                        }
                        nCID = Integer.parseInt(token);
                        bIsOK = true;
                        nTokenIndex++;
                    }
                    if (bIsOK) {
                        strUsername = "admin";
                        strPassword = Constants.MAIN_VERSION_TAG;
                        if (nCID == nConfigID) {
                            info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                            info.setnOnLineStat(101);
                            info.setlOnLineStatChaneTime(System.currentTimeMillis());
                            if (!table.containsKey(strMac)) {
                                table.put(strMac, info);
                            }
                        }
                    }
                }
                if (udpSocket != null) {
                    udpSocket.close();
                }
                hashtable = table;
                return table;
            } catch (UnknownHostException e12) {
                udpSocket.close();
                return null;
            }
            try {
                data = "NVDEVSEARCH^100".getBytes();
                udpSocket.send(new DatagramPacket(data, data.length, serverAddress, 4000));
                table = new Hashtable();
                nTimeouts = 0;
                recvData = new byte[2048];
                while (nSearchID == _nSearchID && udpSocket != null) {
                    Arrays.fill(recvData, (byte) 0);
                    datagramPacket = new DatagramPacket(recvData, 512);
                    udpSocket.receive(datagramPacket);
                    if (nTimeouts >= 10) {
                        if (nSearchID == _nSearchID) {
                        }
                    }
                    strBulder = new StringBuilder();
                    receiveData = datagramPacket.getData();
                    j = 0;
                    while (j < receiveData.length) {
                        if (receiveData[j] != (byte) 0) {
                            strBulder.append((char) receiveData[j]);
                            j++;
                        } else {
                            nCID = 0;
                            if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                                if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                                    continue;
                                }
                            }
                            bIsOK = false;
                            stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                            nTokenIndex = 0;
                            while (stringTokenizer.hasMoreTokens()) {
                                token = stringTokenizer.nextToken();
                                switch (nTokenIndex) {
                                    case 2:
                                        strMac = token;
                                        break;
                                    case 3:
                                        strIP = token;
                                        break;
                                    case 9:
                                        nPort = Integer.parseInt(token);
                                        break;
                                    case 12:
                                        nDevID = Integer.parseInt(token);
                                        strName = nDevID;
                                        break;
                                    case 13:
                                        break;
                                    default:
                                        break;
                                }
                                nCID = Integer.parseInt(token);
                                bIsOK = true;
                                nTokenIndex++;
                            }
                            if (bIsOK) {
                                strUsername = "admin";
                                strPassword = Constants.MAIN_VERSION_TAG;
                                if (nCID == nConfigID) {
                                    info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                                    info.setnOnLineStat(101);
                                    info.setlOnLineStatChaneTime(System.currentTimeMillis());
                                    if (!table.containsKey(strMac)) {
                                        table.put(strMac, info);
                                    }
                                }
                            }
                        }
                    }
                    nCID = 0;
                    if (strBulder.indexOf("NVDEVRESULT^100") != 0) {
                        if (strBulder.indexOf("NVDEVRESULT^200") != 0) {
                            continue;
                        }
                    }
                    bIsOK = false;
                    stringTokenizer = new StringTokenizer(strBulder.toString(), "^");
                    nTokenIndex = 0;
                    while (stringTokenizer.hasMoreTokens()) {
                        token = stringTokenizer.nextToken();
                        switch (nTokenIndex) {
                            case 2:
                                strMac = token;
                                break;
                            case 3:
                                strIP = token;
                                break;
                            case 9:
                                nPort = Integer.parseInt(token);
                                break;
                            case 12:
                                nDevID = Integer.parseInt(token);
                                strName = nDevID;
                                break;
                            case 13:
                                break;
                            default:
                                break;
                        }
                        nCID = Integer.parseInt(token);
                        bIsOK = true;
                        nTokenIndex++;
                    }
                    if (bIsOK) {
                        strUsername = "admin";
                        strPassword = Constants.MAIN_VERSION_TAG;
                        if (nCID == nConfigID) {
                            info = new DeviceInfo(0, nDevID, strName, strIP, nPort, strUsername, strPassword, strMac, new StringBuilder(String.valueOf(nDevID)).append(Defines.MV_DOMAIN_SUFFIX).toString(), Defines.SERVER_SAVE_TYPE_SEARCH);
                            info.setnOnLineStat(101);
                            info.setlOnLineStatChaneTime(System.currentTimeMillis());
                            if (!table.containsKey(strMac)) {
                                table.put(strMac, info);
                            }
                        }
                    }
                }
                if (udpSocket != null) {
                    udpSocket.close();
                }
                hashtable = table;
                return table;
            } catch (Throwable th4) {
                th3 = th4;
                throw th3;
            }
        }
    }
}
