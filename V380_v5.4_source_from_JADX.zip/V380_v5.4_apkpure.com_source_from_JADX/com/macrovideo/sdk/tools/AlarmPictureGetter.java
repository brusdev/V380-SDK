package com.macrovideo.sdk.tools;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.objects.AlarmImageResult;
import com.macrovideo.sdk.objects.ObjectAlarmMessage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AlarmPictureGetter {
    public static final int OSS_GET_ALARM_IMAGE_CANCEL = 11111;
    private static byte[] _imageBuffer = new byte[102400];
    private static int _nGettingID = 0;
    private static byte[] buffer = new byte[512];

    public static void reset() {
        _nGettingID++;
    }

    public static AlarmImageResult getAlarmPic(ObjectAlarmMessage message, String strUsername, String strPassword) {
        _nGettingID++;
        return getAlarmPicFromServer(message, strUsername, strPassword, _nGettingID);
    }

    private static AlarmImageResult getAlarmPicFromServer(ObjectAlarmMessage message, String strUsername, String strPassword, int nGettingID) {
        AlarmImageResult aResult = new AlarmImageResult();
        JSONArray jsonArray = null;
        int nPCount = 0;
        aResult.setnReuslt(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        OutputStream writer = null;
        InputStream reader = null;
        Socket sSocket = Functions.connectToServer(message.getStrImageIp(), 8889, Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return null;
        }
        boolean isConnectOK;
        try {
            if (sSocket.isConnected()) {
                writer = sSocket.getOutputStream();
                reader = sSocket.getInputStream();
                isConnectOK = true;
                if (isConnectOK) {
                    Arrays.fill(buffer, (byte) 0);
                    Functions.ShortToBytes((short) 8004, buffer, 0);
                    Functions.IntToBytes((long) message.getnDevID(), buffer, 2);
                    if (strUsername != null) {
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 6, strUsername.getBytes().length);
                    }
                    if (strPassword != null) {
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 38, strPassword.getBytes().length);
                    }
                    buffer[70] = (byte) 0;
                    Functions.LongToBytes(message.getLSaveTime(), buffer, 71);
                    Functions.IntToBytes((long) message.getnAlarmID(), buffer, 79);
                    try {
                        writer.write(buffer, 0, 128);
                        writer.flush();
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 8) {
                                    reader.read(buffer, 0, 8);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        aResult.setnReuslt(ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL);
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToShort(buffer, 0);
                            int nResultValue = Functions.BytesToShort(buffer, 2);
                            int nResultDes = Functions.BytesToShort(buffer, 4);
                            int nRecvSize = 0;
                            if (nResultCmd == 8005) {
                                Arrays.fill(buffer, (byte) 0);
                                Functions.ShortToBytes((short) 8006, buffer, 0);
                                try {
                                    writer.write(buffer, 0, 16);
                                    writer.flush();
                                } catch (IOException e2) {
                                    if (writer != null) {
                                        try {
                                            writer.close();
                                        } catch (IOException e3) {
                                        }
                                    }
                                    writer = null;
                                    if (reader != null) {
                                        try {
                                            reader.close();
                                        } catch (IOException e4) {
                                        }
                                    }
                                    reader = null;
                                    if (sSocket != null) {
                                        try {
                                            sSocket.close();
                                        } catch (IOException e5) {
                                        }
                                    }
                                    sSocket = null;
                                }
                                Arrays.fill(_imageBuffer, (byte) 0);
                                bReadOK = false;
                                int nTryCount = 0;
                                while (nGettingID == _nGettingID && !sSocket.isOutputShutdown()) {
                                    nTryCount++;
                                    try {
                                        Log.w("AAA", "reader.available = " + reader.available());
                                        if (reader.available() < 512) {
                                            try {
                                                Thread.sleep(1000);
                                            } catch (InterruptedException e6) {
                                                e6.printStackTrace();
                                            }
                                            if (nTryCount >= 10) {
                                                bReadOK = false;
                                                break;
                                            }
                                        } else {
                                            Arrays.fill(buffer, (byte) 0);
                                            reader.read(buffer, 0, 512);
                                            nTryCount = 0;
                                            byte byPType;
                                            short uPCount;
                                            short uPNum;
                                            short uDataSize;
                                            if (buffer[0] == (byte) -95) {
                                                byPType = buffer[1];
                                                uPCount = (short) Functions.BytesToShort(buffer, 2);
                                                uPNum = (short) Functions.BytesToShort(buffer, 4);
                                                uDataSize = (short) Functions.BytesToShort(buffer, 6);
                                                Log.w("AAA", "PACKET_FLAG_PICTURE " + uPNum + ", " + uPCount + ", " + uDataSize);
                                                if (uPCount <= (short) 0 || uPCount <= uPNum || uDataSize > (short) 504 || uDataSize <= (short) 0) {
                                                    bReadOK = false;
                                                    Log.w("AAA", "PACKET_FLAG_PICTURE break");
                                                    break;
                                                }
                                                System.arraycopy(buffer, 8, _imageBuffer, nRecvSize, uDataSize);
                                                nRecvSize += uDataSize;
                                                Log.w("AAA", "PACKET_FLAG_PICTURE " + uPNum + ", " + uPCount + ", " + uDataSize);
                                                if (uPNum == uPCount - 1) {
                                                    bReadOK = true;
                                                    break;
                                                }
                                            } else if (buffer[0] == (byte) -94) {
                                                byPType = buffer[1];
                                                uPCount = (short) Functions.BytesToShort(buffer, 2);
                                                uPNum = (short) Functions.BytesToShort(buffer, 4);
                                                uDataSize = (short) Functions.BytesToShort(buffer, 6);
                                                if (uPCount <= (short) 0 || uDataSize > (short) 504 || uDataSize <= (short) 0) {
                                                    bReadOK = false;
                                                    Log.w("AAA", "PACKET_FLAG_POSITION break");
                                                    break;
                                                }
                                                Log.w("AAA", "PACKET_FLAG_POSITION ok");
                                                if (uDataSize == uPCount * 8) {
                                                    nPCount = uPCount;
                                                    jsonArray = new JSONArray();
                                                    for (short i2 = (short) 0; i2 < nPCount; i2++) {
                                                        short uTX = (short) Functions.BytesToShort(buffer, (i2 * 8) + 8);
                                                        short uTY = (short) Functions.BytesToShort(buffer, (i2 * 8) + 10);
                                                        short uBX = (short) Functions.BytesToShort(buffer, (i2 * 8) + 12);
                                                        short uBY = (short) Functions.BytesToShort(buffer, (i2 * 8) + 14);
                                                        Log.w("AAA", "PACKET_FLAG_POSITION " + uTX + ", " + uTY + "," + uBX + ", " + uBY);
                                                        JSONObject obj = new JSONObject();
                                                        try {
                                                            obj.put("tx", uTX);
                                                            obj.put("ty", uTY);
                                                            obj.put("bx", uBX);
                                                            obj.put("by", uBY);
                                                            jsonArray.put(obj);
                                                        } catch (JSONException e7) {
                                                        }
                                                    }
                                                }
                                            } else {
                                                continue;
                                            }
                                        }
                                    } catch (IOException e8) {
                                        bReadOK = false;
                                    }
                                }
                            }
                            if (bReadOK && nRecvSize > 0) {
                                Bitmap image;
                                if (nPCount > 0 && jsonArray != null) {
                                    aResult.setnPCount(nPCount);
                                    aResult.setStrPositionSet(jsonArray.toString());
                                }
                                try {
                                    image = BitmapFactory.decodeByteArray(_imageBuffer, 0, nRecvSize);
                                } catch (Exception e9) {
                                    Log.w("AAA", "Exception : " + e9.toString());
                                    image = null;
                                }
                                Log.w("AAA", "test ok: " + nRecvSize + ", " + aResult.getStrPositionSet());
                                aResult.setnReuslt(256);
                                aResult.setaImage(image);
                            }
                        } else {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e10) {
                                }
                            }
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e11) {
                                }
                            }
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e12) {
                                }
                            }
                            if (nGettingID == _nGettingID) {
                                return aResult;
                            }
                            aResult.setnReuslt(OSS_GET_ALARM_IMAGE_CANCEL);
                            return aResult;
                        }
                    } catch (IOException e13) {
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e14) {
                            }
                        }
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (IOException e15) {
                            }
                        }
                        if (sSocket != null) {
                            try {
                                sSocket.close();
                            } catch (IOException e16) {
                            }
                        }
                        if (nGettingID == _nGettingID) {
                            return aResult;
                        }
                        aResult.setnReuslt(OSS_GET_ALARM_IMAGE_CANCEL);
                        return aResult;
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e17) {
                    }
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e18) {
                    }
                }
                if (sSocket != null) {
                    try {
                        sSocket.close();
                    } catch (IOException e19) {
                    }
                }
                if (nGettingID == _nGettingID) {
                    return aResult;
                }
                aResult.setnReuslt(OSS_GET_ALARM_IMAGE_CANCEL);
                return aResult;
            } else if (nGettingID == _nGettingID) {
                return aResult;
            } else {
                aResult.setnReuslt(OSS_GET_ALARM_IMAGE_CANCEL);
                return aResult;
            }
        } catch (IOException e20) {
            isConnectOK = false;
        }
    }
}
