package com.macrovideo.sdk.tools;

import android.util.Log;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.media.LoginHelperEX;
import com.tencent.android.tpush.common.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;

public class DispatchServerGetter {
    private static final int CMD_REQUEST = 100;
    private static final int CMD_RESPONSE_GET_MR_SERVER_FAIL = 250;
    private static final int CMD_RESPONSE_SUCCESS = 200;
    private static final int DISPATCH_SERVER_BUFFER_SIZE_RECEIVE = 64;
    private static final int DISPATCH_SERVER_BUFFER_SIZE_SEND = 144;
    private static byte[] buffer = new byte[144];
    private static String dispatchServerHostName = "dispa1.av380.net";
    private static String dispatchServerIP1_as30 = Functions.MR_SERVER_IP2;
    private static String dispatchServerIP1_hk2 = "47.90.0.159";
    private static String dispatchServerIP2_as34 = "121.42.39.129";
    private static String dispatchServerIP2_hk5 = "47.52.0.59";
    private static String dispatchServerIP3_as128 = "118.190.44.8";
    private static String dispatchServerIP3_sg3 = "47.88.188.193";
    private static int dispatchServerPort = 8000;
    private static int dispatchServerTimeout = Defines.CMD_MR_WAIT;
    private static String[] dispatchServer_cn = new String[]{dispatchServerIP1_as30, dispatchServerIP2_as34, dispatchServerIP3_as128};
    private static String[] dispatchServer_foreign = new String[]{dispatchServerIP1_hk2, dispatchServerIP2_hk5, dispatchServerIP3_sg3};
    public DispatchServerResult mDispatchServerResult;
    private boolean tagFlag = true;

    class DispatchServerResult {
        public static final int RESULT_ERROR = 200;
        public static final int RESULT_SUCCESS = 100;
        public static final int TYPE_BOTH = 52;
        public static final int TYPE_NORMAL = 50;
        public static final int TYPE_PANO = 51;
        ArrayList<String> mrServerList = new ArrayList();
        private int numNormal = 0;
        private int numPano = 0;
        private int result;
        private int type;

        DispatchServerResult() {
        }

        public int getNumNormal() {
            return this.numNormal;
        }

        public void setNumNormal(int numNormal) {
            this.numNormal = numNormal;
        }

        public int getNumPano() {
            return this.numPano;
        }

        public void setNumPano(int numPano) {
            this.numPano = numPano;
        }

        private void resetMrServerList() {
            if (this.mrServerList != null) {
                this.mrServerList.clear();
            } else {
                this.mrServerList = new ArrayList();
            }
        }

        public ArrayList<String> getMrServerList() {
            return this.mrServerList;
        }

        public void setMrServerList(ArrayList<String> mrServerList) {
            this.mrServerList = mrServerList;
        }

        public int getType() {
            return this.type;
        }

        public void setType(int type) {
            this.type = type;
        }

        void setResult(int result) {
            this.result = result;
        }

        int getResult() {
            return this.result;
        }
    }

    private void logd(String tag, String content) {
        if (this.tagFlag) {
            Log.d(tag, content);
        }
    }

    private Socket getDispatchSocketFromArray(String[] arr, String ip) {
        Socket socket = null;
        int i = 0;
        while (i < arr.length) {
            if (ip == null || !ip.equals(arr[i])) {
                socket = Functions.connectToServer(arr[i], dispatchServerPort, dispatchServerTimeout);
                if (socket != null) {
                    break;
                }
            }
            i++;
        }
        return socket;
    }

    private Socket getDispatchAddressSocket() {
        String dispatchIP;
        try {
            dispatchIP = InetAddress.getByName(dispatchServerHostName).getHostAddress();
        } catch (UnknownHostException e1) {
            e1.printStackTrace();
            dispatchIP = null;
        }
        if (dispatchIP != null) {
            Socket socket = Functions.connectToServer(dispatchIP, dispatchServerPort, dispatchServerTimeout);
            if (socket != null) {
                return socket;
            }
            if (dispatchIP.startsWith("47")) {
                return getDispatchSocketFromArray(dispatchServer_foreign, dispatchIP);
            }
            return getDispatchSocketFromArray(dispatchServer_cn, dispatchIP);
        } else if ((Functions.getZoneIndex() == 0 && Functions._strLanguage.equalsIgnoreCase("cn")) || Functions.getZoneIndex() == 1) {
            return getDispatchSocketFromArray(dispatchServer_cn, dispatchIP);
        } else {
            return getDispatchSocketFromArray(dispatchServer_foreign, dispatchIP);
        }
    }

    public DispatchServerResult getDispatchServer(String phoneUserName, int deviceID) {
        DispatchServerResult dispatchServerResult = new DispatchServerResult();
        dispatchServerResult.setResult(200);
        OutputStream writer = null;
        InputStream reader = null;
        boolean isConnectOK = false;
        Socket socket = getDispatchAddressSocket();
        if (socket == null) {
            dispatchServerResult.setResult(200);
        } else {
            try {
                if (socket.isConnected()) {
                    writer = socket.getOutputStream();
                    reader = socket.getInputStream();
                    isConnectOK = true;
                }
            } catch (IOException e) {
                isConnectOK = false;
            }
            if (isConnectOK) {
                try {
                    int i;
                    String baseKey = LoginHelperEX.randomkey;
                    byte[] byteRandomKey = LoginHelperEX.getCharAndNumr(16).getBytes();
                    byte[] byteRandomKey16 = new byte[16];
                    System.arraycopy(byteRandomKey, 0, byteRandomKey16, 0, byteRandomKey.length);
                    byte[] encryptedUserName = LoginHelperEX.encrypt(LoginHelperEX.encrypt(phoneUserName.getBytes(), baseKey.getBytes()), byteRandomKey);
                    short encryptedUserNameLength = (short) encryptedUserName.length;
                    byte[] deviceIDandKey = new byte[20];
                    Functions.IntToBytes((long) deviceID, deviceIDandKey, 0);
                    System.arraycopy(byteRandomKey16, 0, deviceIDandKey, 4, byteRandomKey16.length);
                    byte[] encryptedIDandKey = LoginHelperEX.encrypt(LoginHelperEX.encrypt(deviceIDandKey, baseKey.getBytes()), byteRandomKey);
                    short encryptedIDandKeyLength = (short) encryptedIDandKey.length;
                    Arrays.fill(buffer, (byte) 0);
                    Functions.ShortToBytes((short) 100, buffer, 0);
                    Functions.ShortToBytes(encryptedUserNameLength, buffer, 2);
                    System.arraycopy(encryptedUserName, 0, buffer, 4, encryptedUserNameLength);
                    Functions.ShortToBytes(encryptedIDandKeyLength, buffer, encryptedUserNameLength + 4);
                    System.arraycopy(encryptedIDandKey, 0, buffer, encryptedUserNameLength + 6, encryptedIDandKeyLength);
                    System.arraycopy(byteRandomKey, 0, buffer, (encryptedUserNameLength + 6) + encryptedIDandKeyLength, byteRandomKey.length);
                    writer.write(buffer, 0, 144);
                    writer.flush();
                    Arrays.fill(buffer, (byte) 0);
                    boolean isReadOK = false;
                    for (i = 0; i < 5; i++) {
                        if (reader.available() >= 64) {
                            reader.read(buffer, 0, 64);
                            isReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e2) {
                            try {
                                e2.printStackTrace();
                            } catch (IOException e3) {
                                e3.printStackTrace();
                            }
                        }
                    }
                    if (isReadOK) {
                        short CMD_RECV = (short) Functions.BytesToShort(buffer, 0);
                        if (CMD_RECV == (short) 200) {
                            int numNormal = buffer[6];
                            int numPano = buffer[7];
                            dispatchServerResult.setNumNormal(numNormal);
                            dispatchServerResult.setNumPano(numPano);
                            if (numNormal > 0 && numPano > 0) {
                                dispatchServerResult.setType(52);
                            } else if (numNormal > 0 && numPano <= 0) {
                                dispatchServerResult.setType(50);
                            } else if (numNormal <= 0 && numPano > 0) {
                                dispatchServerResult.setType(51);
                            }
                            dispatchServerResult.resetMrServerList();
                            for (i = 0; i < numNormal + numPano; i++) {
                                dispatchServerResult.getMrServerList().add(longToIP(Functions.getUnsignedInt(Functions.BytesToInt(buffer, (i * 4) + 8))));
                            }
                            dispatchServerResult.setResult(100);
                        } else if (CMD_RECV == (short) 250) {
                            dispatchServerResult.setResult(200);
                        } else {
                            dispatchServerResult.setResult(200);
                        }
                    }
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e4) {
                        }
                    }
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e5) {
                        }
                    }
                    if (socket != null) {
                        try {
                            socket.close();
                        } catch (IOException e6) {
                        }
                    }
                } catch (Exception e7) {
                    e7.printStackTrace();
                    dispatchServerResult.setResult(200);
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e8) {
                        }
                    }
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e9) {
                        }
                    }
                    if (socket != null) {
                        try {
                            socket.close();
                        } catch (IOException e10) {
                        }
                    }
                } catch (Throwable th) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e11) {
                        }
                    }
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e12) {
                        }
                    }
                    if (socket != null) {
                        try {
                            socket.close();
                        } catch (IOException e13) {
                        }
                    }
                }
            } else {
                dispatchServerResult.setResult(200);
            }
        }
        return dispatchServerResult;
    }

    public static String longToIP(long longIp) {
        StringBuffer sb = new StringBuffer(Constants.MAIN_VERSION_TAG);
        sb.append(String.valueOf(255 & longIp));
        sb.append(".");
        sb.append(String.valueOf((65535 & longIp) >>> 8));
        sb.append(".");
        sb.append(String.valueOf((16777215 & longIp) >>> 16));
        sb.append(".");
        sb.append(String.valueOf(longIp >>> 24));
        return sb.toString();
    }
}
