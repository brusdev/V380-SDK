package com.macrovideo.sdk.tools;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import java.io.UnsupportedEncodingException;
import java.util.UUID;

public class DeviceUuidFactory {
    protected static final String PREFS_DEVICE_ID = "device_id";
    protected static final String PREFS_FILE = "device_unique_id";
    protected static String uuid;

    public static String getUniqueUUID(Context context) {
        if (uuid == null) {
            synchronized (DeviceUuidFactory.class) {
                if (uuid == null) {
                    SharedPreferences prefs = context.getSharedPreferences(PREFS_FILE, 0);
                    String id = prefs.getString(PREFS_DEVICE_ID, null);
                    if (id != null) {
                        uuid = id;
                    } else {
                        String androidId = Secure.getString(context.getContentResolver(), "android_id");
                        if ("9774d56d682e549c".equals(androidId) || androidId == null) {
                            try {
                                String deviceId = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
                                if (deviceId == null || !isValidDeviceID(deviceId)) {
                                    uuid = UUID.randomUUID().toString();
                                } else {
                                    uuid = UUID.nameUUIDFromBytes(deviceId.getBytes("utf8")).toString();
                                }
                            } catch (UnsupportedEncodingException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        uuid = UUID.nameUUIDFromBytes(androidId.getBytes("utf8")).toString();
                        prefs.edit().putString(PREFS_DEVICE_ID, uuid).commit();
                    }
                }
            }
        }
        return uuid;
    }

    private static boolean isValidDeviceID(String deviceId) {
        boolean result = false;
        for (int i = 0; i < deviceId.length(); i++) {
            if (deviceId.charAt(i) != '0') {
                result = true;
                break;
            }
        }
        if (!result || deviceId.contains("*")) {
            return false;
        }
        return true;
    }
}
