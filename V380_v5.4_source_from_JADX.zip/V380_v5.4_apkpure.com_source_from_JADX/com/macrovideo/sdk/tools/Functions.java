package com.macrovideo.sdk.tools;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Matrix;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Environment;
import android.util.Base64;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.v380.AppApplication;
import com.macrovideo.v380.HomePageActivity;
import com.macrovideo.v380.LocalDefines;
import com.tencent.android.tpush.common.Constants;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Pattern;
import org.apache.http.HttpHost;

public class Functions {
    private static final String EN_MR_SERVER_IP1 = "47.90.0.159";
    private static final String EN_MR_SERVER_IP2 = "47.88.0.218";
    private static final String EN_MR_SERVER_IP3 = "47.90.0.159";
    private static final String EN_MR_SERVER_IPAM = "47.90.0.159";
    private static final String EN_MR_SERVER_IPHK = "47.88.0.218";
    private static final String EN_MR_SERVER_IPSGP = "47.90.0.159";
    private static final String EN_MR_SERVER_RS1 = "hk1.nvcam.net";
    private static final String EN_MR_SERVER_RS2 = "hk2.nvcam.net";
    private static final String EN_MR_SERVER_RS3 = "hk3.nvcam.net";
    private static final String IP_REGEX = "\\b((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\b";
    private static final String LAN_IP_REGEX = "(127[.]0[.]0[.]1)|(10[.]\\d{1,3}[.]\\d{1,3}[.]\\d{1,3})|(172[.]((1[6-9])|(2\\d)|(3[01]))[.]\\d{1,3}[.]\\d{1,3})|(192[.]168[.]\\d{1,3}[.]\\d{1,3})";
    private static final int LIST_TYPE_MULTIPLE_BOTH = 4;
    private static final int LIST_TYPE_MULTIPLE_NORMAL = 2;
    private static final int LIST_TYPE_MULTIPLE_PANO = 3;
    private static final int LIST_TYPE_NULL = 0;
    private static final int LIST_TYPE_ONE_DEVICE = 1;
    private static final String MR_PANO_SERVER_IP1 = "118.190.44.8";
    private static final String MR_PANO_SERVER_IP2 = "120.26.209.166";
    private static final String MR_PANO_SERVER_IP3 = "121.42.39.129";
    private static final String MR_PANO_SERVER_RS1 = "vr1.av380.net";
    private static final String MR_PANO_SERVER_RS2 = "vr2.av380.net";
    private static final String MR_PANO_SERVER_RS3 = "vr3.av380.net";
    private static final String MR_SERVER_AF1 = "zoneaf1.nvcam.net";
    private static final String MR_SERVER_AF2 = "zoneaf2.nvcam.net";
    private static final String MR_SERVER_AS1 = "zoneas1.nvcam.net";
    private static final String MR_SERVER_AS2 = "zoneas2.nvcam.net";
    private static final String MR_SERVER_AS3 = "zoneas3.nvcam.net";
    private static final String MR_SERVER_AS4 = "zoneas4.nvcam.net";
    private static final String MR_SERVER_EU1 = "zoneeu1.nvcam.net";
    private static final String MR_SERVER_EU2 = "zoneeu2.nvcam.net";
    public static final String MR_SERVER_IP1 = "120.55.167.226";
    public static final String MR_SERVER_IP2 = "120.26.209.166";
    public static final String MR_SERVER_IP3 = "115.28.131.189";
    private static final String MR_SERVER_NA1 = "zonena1.nvcam.net";
    private static final String MR_SERVER_OA1 = "zoneOa1.nvcam.net";
    private static final String MR_SERVER_RS1 = "rs591.nvcam.net";
    private static final String MR_SERVER_RS2 = "rs592.nvcam.net";
    private static final String MR_SERVER_RS3 = "rs593.nvcam.net";
    private static final String MR_SERVER_RS4 = "rs594.nvcam.net";
    private static final String MR_SERVER_SA1 = "zonesa1.nvcam.net";
    public static long _lUseMRTime = 0;
    public static int _nCurrentMRPort = 8800;
    public static int _nCurrentPanoMRPort = 8800;
    public static String _strCurrentMRServer = null;
    public static String _strCurrentPanoMRServer = null;
    public static String _strLanguage = "cn";
    private static long dispatchServerGetInterval = 300000;
    private static long dispatchServerGetTime = 0;
    private static int listType = 0;
    private static int nSaveZoneIndex = 0;
    private static int nZoneIndex = 0;
    private static ArrayList<String> normalMRList = new ArrayList();
    private static ArrayList<String> panoMRList = new ArrayList();

    public static boolean isMRMode(int nDeviceID) {
        return false;
    }

    public static void changeMRParam(int nDeviceID, boolean isMRMode) {
    }

    public static int getVersionName(Context context) {
        try {
            int versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
            if (versionName < 0) {
                return 0;
            }
            return versionName;
        } catch (NameNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static int getSystemVersion() {
        return VERSION.SDK_INT;
    }

    public static Bitmap zoomBitmap(Bitmap bitmap, int width, int height) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        Matrix matrix = new Matrix();
        matrix.postScale(((float) width) / ((float) w), ((float) height) / ((float) h));
        return Bitmap.createBitmap(bitmap, 0, 0, w, h, matrix, true);
    }

    public static String GetJsonStringFromServerByHTTP(String strHost, int nPort, String requestURL) {
        String resultData = Constants.MAIN_VERSION_TAG;
        HttpURLConnection urlConn = null;
        BufferedReader buffer = null;
        try {
            urlConn = (HttpURLConnection) new URL(HttpHost.DEFAULT_SCHEME_NAME, strHost, nPort, requestURL).openConnection();
            if (urlConn == null) {
                return null;
            }
            urlConn.setDoInput(true);
            urlConn.setConnectTimeout(Constants.ERRORCODE_UNKNOWN);
            urlConn.setReadTimeout(30000);
            urlConn.setUseCaches(false);
            BufferedReader buffer2 = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
            try {
                String str = Constants.MAIN_VERSION_TAG;
                while (true) {
                    str = buffer2.readLine();
                    if (str == null) {
                        break;
                    }
                    resultData = new StringBuilder(String.valueOf(resultData)).append(str).append("\n").toString();
                }
                buffer2.close();
                urlConn.disconnect();
                buffer = buffer2;
            } catch (IOException e) {
                buffer = buffer2;
                resultData = null;
                if (buffer != null) {
                    try {
                        buffer.close();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (urlConn != null) {
                    urlConn.disconnect();
                }
                return resultData;
            }
            return resultData;
        } catch (IOException e2) {
            resultData = null;
            if (buffer != null) {
                buffer.close();
            }
            if (urlConn != null) {
                urlConn.disconnect();
            }
            return resultData;
        }
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivity == null) {
            return false;
        }
        NetworkInfo info = connectivity.getActiveNetworkInfo();
        if (info != null && info.isConnected() && info.getState() == State.CONNECTED) {
            return true;
        }
        return false;
    }

    public static boolean isNetworkWifi(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivity != null) {
            NetworkInfo info = connectivity.getActiveNetworkInfo();
            if (info != null && info.getType() == 1) {
                return true;
            }
        }
        return false;
    }

    public static void LongToBytes(long n, byte[] buf, int offset) {
        try {
            buf[offset + 0] = (byte) ((int) (n & 255));
            buf[offset + 1] = (byte) ((int) ((n >> 8) & 255));
            buf[offset + 2] = (byte) ((int) ((n >> 16) & 255));
            buf[offset + 3] = (byte) ((int) ((n >> 24) & 255));
            buf[offset + 4] = (byte) ((int) ((n >> 32) & 255));
            buf[offset + 5] = (byte) ((int) ((n >> 40) & 255));
            buf[offset + 6] = (byte) ((int) ((n >> 48) & 255));
            buf[offset + 7] = (byte) ((int) ((n >> 56) & 255));
        } catch (ArrayIndexOutOfBoundsException e) {
        }
    }

    public static void IntToBytes(long n, byte[] buf, int offset) {
        try {
            buf[offset + 0] = (byte) ((int) (n & 255));
            buf[offset + 1] = (byte) ((int) ((n >> 8) & 255));
            buf[offset + 2] = (byte) ((int) ((n >> 16) & 255));
            buf[offset + 3] = (byte) ((int) ((n >> 24) & 255));
        } catch (ArrayIndexOutOfBoundsException e) {
        }
    }

    public static int BytesToInt(byte[] buf, int offset) {
        try {
            return (((0 + (buf[offset + 0] & 255)) + ((buf[offset + 1] & 255) << 8)) + ((buf[offset + 2] & 255) << 16)) + ((buf[offset + 3] & 255) << 24);
        } catch (ArrayIndexOutOfBoundsException e) {
            return 0;
        }
    }

    public static int BytesToShort(byte[] buf, int offset) {
        try {
            return (0 + (buf[offset + 0] & 255)) + (buf[(offset + 1) & 255] << 8);
        } catch (ArrayIndexOutOfBoundsException e) {
            return 0;
        }
    }

    public static void ShortToBytes(short s, byte[] buf, int offset) {
        try {
            buf[offset + 0] = (byte) (s & 255);
            buf[offset + 1] = (byte) ((s >> 8) & 255);
        } catch (ArrayIndexOutOfBoundsException e) {
        }
    }

    public static String GetInetAddress(String host) {
        String IPAddress = Constants.MAIN_VERSION_TAG;
        try {
            return InetAddress.getByName(host).getHostAddress();
        } catch (UnknownHostException e) {
            return host;
        }
    }

    public static boolean hasDot(String host) {
        boolean bResult = false;
        if (host != null && host.length() > 0) {
            for (int i = 0; i < host.length(); i++) {
                if (host.charAt(i) == '.') {
                    bResult = true;
                }
            }
        }
        return bResult;
    }

    public static boolean isIpAddress(String strServer) {
        return Pattern.compile(IP_REGEX).matcher(strServer).matches();
    }

    public static boolean isLanIP(String strServer) {
        return Pattern.compile(LAN_IP_REGEX).matcher(strServer).matches();
    }

    public static void setZoneIndex(int nIndex) {
        nZoneIndex = nIndex;
    }

    public static int getZoneIndex() {
        return nZoneIndex;
    }

    public static int getMRPort() {
        return 8800;
    }

    public static void initLanguageContext(Context context) {
        if (context.getResources().getConfiguration().locale.getLanguage().endsWith("zh")) {
            _strLanguage = "cn";
        } else {
            _strLanguage = "en";
        }
    }

    public static Socket connectToServer(String strIP, int nPort, int nTimeout) {
        Socket socket;
        if (strIP == null || strIP.length() <= 0 || nPort <= 0) {
            return null;
        }
        try {
            Socket sSocket = new Socket();
            try {
                sSocket.connect(new InetSocketAddress(strIP, nPort), nTimeout);
                return sSocket;
            } catch (UnknownHostException e) {
                socket = sSocket;
                return null;
            } catch (IOException e2) {
                socket = sSocket;
                return null;
            }
        } catch (UnknownHostException e3) {
            return null;
        } catch (IOException e4) {
            return null;
        }
    }

    private static Socket connectToDispatchResultServer(boolean isPanoDevice, int nPort, int nTimeout) {
        Socket sSocket = null;
        int nMRPort = 8800;
        int i;
        String strMRServer;
        if (!isPanoDevice) {
            for (i = 0; i < normalMRList.size(); i++) {
                strMRServer = (String) normalMRList.get(i);
                if (nPort <= 0) {
                    nMRPort = getMRPort();
                }
                sSocket = connectToServer(strMRServer, nMRPort, nTimeout);
                if (sSocket != null) {
                    break;
                }
            }
        } else {
            for (i = 0; i < panoMRList.size(); i++) {
                strMRServer = (String) panoMRList.get(i);
                if (nPort <= 0) {
                    nMRPort = getMRPort();
                }
                sSocket = connectToServer(strMRServer, nMRPort, nTimeout);
                if (sSocket != null) {
                    break;
                }
            }
        }
        return sSocket;
    }

    private static boolean handleDispatchResult(DispatchServerResult dispatchServerResult, int type) {
        if (dispatchServerResult == null || dispatchServerResult.getResult() != 100) {
            return false;
        }
        listType = type;
        if (dispatchServerResult.getType() == 50) {
            normalMRList = dispatchServerResult.getMrServerList();
        } else if (dispatchServerResult.getType() == 51) {
            panoMRList = dispatchServerResult.getMrServerList();
        } else {
            int i;
            int numNormal = dispatchServerResult.getNumNormal();
            int numPano = dispatchServerResult.getNumPano();
            ArrayList<String> list = dispatchServerResult.getMrServerList();
            for (i = 0; i < numNormal; i++) {
                normalMRList.add((String) list.get(i));
            }
            for (i = numNormal; i < numNormal + numPano; i++) {
                panoMRList.add((String) list.get(i));
            }
        }
        dispatchServerGetTime = System.currentTimeMillis();
        return true;
    }

    private static boolean startGetMrServerFromDispatch(int deviceId, int port) {
        int type = getDeviceListType();
        if ((System.currentTimeMillis() - dispatchServerGetTime <= dispatchServerGetInterval && type == listType && nSaveZoneIndex == nZoneIndex) || port != 0) {
            return false;
        }
        String phoneUserName = getPhoneUserName();
        DispatchServerGetter dispatchServerGetter = new DispatchServerGetter();
        if (type == 1) {
            return handleDispatchResult(dispatchServerGetter.getDispatchServer(phoneUserName, deviceId), type);
        }
        if (type == 4) {
            return handleDispatchResult(dispatchServerGetter.getDispatchServer(phoneUserName, 88889999), type);
        }
        if (type == 2) {
            return handleDispatchResult(dispatchServerGetter.getDispatchServer(phoneUserName, 88888888), type);
        }
        if (type == 3) {
            return handleDispatchResult(dispatchServerGetter.getDispatchServer(phoneUserName, 99999999), type);
        }
        return false;
    }

    public static Socket connectToMRServer(String strIP, int nPort, int nTimeout, int deviceId) {
        Socket sSocket = null;
        boolean isPanoDevice = getIsPanoDevice(deviceId);
        boolean isSave = true;
        if (strIP != null && strIP.length() > 0 && nPort > 0) {
            sSocket = connectToServer(strIP, nPort, nTimeout);
            if (sSocket == null && String.valueOf(deviceId).length() == 4) {
                return null;
            }
        }
        boolean isGetFromDispatch = startGetMrServerFromDispatch(deviceId, nPort);
        if ((strIP != null && strIP.length() > 0) || nPort > 0) {
            isSave = false;
        }
        if (sSocket == null) {
            String strMRServer;
            int nMRPort = 8800;
            if (nPort > 0) {
                nMRPort = nPort;
            }
            if (isPanoDevice) {
                if (nSaveZoneIndex == nZoneIndex && System.currentTimeMillis() - _lUseMRTime < 600000 && _strCurrentPanoMRServer != null && !isGetFromDispatch) {
                    strMRServer = _strCurrentPanoMRServer;
                    if (nPort <= 0) {
                        nMRPort = _nCurrentPanoMRPort;
                    }
                    sSocket = connectToServer(strMRServer, nMRPort, nTimeout);
                }
            } else if (nSaveZoneIndex == nZoneIndex && System.currentTimeMillis() - _lUseMRTime < 600000 && _strCurrentMRServer != null && !isGetFromDispatch) {
                strMRServer = _strCurrentMRServer;
                if (nPort <= 0) {
                    nMRPort = _nCurrentMRPort;
                }
                sSocket = connectToServer(strMRServer, nMRPort, nTimeout);
            }
            if (sSocket == null) {
                sSocket = connectToDispatchResultServer(isPanoDevice, nPort, nTimeout);
                if (sSocket == null) {
                    strMRServer = getMRServerDomain(deviceId);
                    if (nPort <= 0) {
                        nMRPort = getMRPort();
                    }
                    sSocket = connectToServer(strMRServer, nMRPort, nTimeout);
                    if (sSocket == null) {
                        for (int i = 0; i < 3; i++) {
                            strMRServer = getMRServerIP(i, deviceId);
                            if (nPort <= 0) {
                                nMRPort = getMRPort();
                            }
                            sSocket = connectToServer(strMRServer, nMRPort, nTimeout);
                            if (sSocket != null) {
                                break;
                            }
                        }
                    }
                }
            }
            if (isSave && sSocket != null && sSocket.isConnected()) {
                if (isPanoDevice) {
                    _strCurrentPanoMRServer = sSocket.getInetAddress().getHostAddress();
                    _nCurrentPanoMRPort = nMRPort;
                } else {
                    _strCurrentMRServer = sSocket.getInetAddress().getHostAddress();
                    _nCurrentMRPort = nMRPort;
                }
                _lUseMRTime = System.currentTimeMillis();
                nSaveZoneIndex = nZoneIndex;
            }
        }
        return sSocket;
    }

    public static Bitmap ScaleImage(Bitmap bitmap, float fWidth, float fHeight) {
        Matrix matrix = new Matrix();
        matrix.postScale(fWidth / ((float) bitmap.getWidth()), fHeight / ((float) bitmap.getHeight()));
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static String GetSDPath() {
        if (Environment.getExternalStorageState().equals("mounted")) {
            return Environment.getExternalStorageDirectory().toString();
        }
        return null;
    }

    public static Bitmap decodeBitmapFromByteArray(byte[] bitmapData, int reqWidth, int reqHeight) {
        Options options = new Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bitmapData, 0, bitmapData.length, options);
        options.inSampleSize = calculateInSampleaSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Config.RGB_565;
        return BitmapFactory.decodeByteArray(bitmapData, 0, bitmapData.length, options);
    }

    private static int calculateInSampleaSize(Options options, int reqWidth, int reqHeight) {
        int height = options.outHeight;
        int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            int halfHeight = height / 2;
            int halfWidth = width / 2;
            while (halfHeight / inSampleSize > reqHeight && halfWidth / inSampleSize > reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    public static Bitmap decodeStringtoBitmap(String string, int reqWidth, int reqHeight) {
        try {
            return decodeBitmapFromByteArray(Base64.decode(string, 0), reqWidth, reqHeight);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String encodeBitmapToString(Bitmap bitmap) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(CompressFormat.JPEG, 100, baos);
            return Base64.encodeToString(baos.toByteArray(), 0);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap decodeStringtoBitmap(String string) {
        try {
            byte[] bitmapArray = Base64.decode(string, 0);
            return BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            return null;
        }
    }

    public static Bitmap readBitMap(Context context, int resId) {
        Options opt = new Options();
        opt.inPreferredConfig = Config.RGB_565;
        opt.inPurgeable = true;
        opt.inInputShareable = true;
        return BitmapFactory.decodeStream(context.getResources().openRawResource(resId), null, opt);
    }

    public static void SharePhoto(List<String> photoUri, Activity activity) {
        boolean multiple = true;
        int lenght = photoUri.size();
        List<Uri> listUri = new ArrayList();
        if (photoUri != null && lenght > 0) {
            for (int i = 0; i < lenght; i++) {
                listUri.add(Uri.fromFile(new File((String) photoUri.get(i))));
            }
            if (listUri.size() < 1) {
                multiple = false;
            }
            Intent shareIntent = new Intent(multiple ? "android.intent.action.SEND_MULTIPLE" : "android.intent.action.SEND");
            shareIntent.setType("image/*");
            shareIntent.putParcelableArrayListExtra("android.intent.extra.STREAM", (ArrayList) listUri);
            activity.startActivity(Intent.createChooser(shareIntent, activity.getTitle()));
        }
    }

    public static void ShortToBytesOne(short s, byte[] buf, int offset) {
        try {
            buf[offset + 0] = (byte) (s & 255);
        } catch (ArrayIndexOutOfBoundsException e) {
        }
    }

    public static String getVerName(Context context) {
        String verName = Constants.MAIN_VERSION_TAG;
        try {
            return context.getPackageManager().getPackageInfo("com.myapp", 0).versionName;
        } catch (NameNotFoundException e) {
            return verName;
        }
    }

    public static String getMRServerDomain(int deviceId) {
        String strMRServer = "127.0.0.1";
        boolean isPanoDevice = getIsPanoDevice(deviceId);
        if (nZoneIndex == 0) {
            if (!_strLanguage.equalsIgnoreCase("cn")) {
                switch (new Random().nextInt(3)) {
                    case 0:
                        return EN_MR_SERVER_RS1;
                    case 1:
                        return EN_MR_SERVER_RS2;
                    case 2:
                        return EN_MR_SERVER_RS3;
                    default:
                        return EN_MR_SERVER_RS1;
                }
            } else if (isPanoDevice) {
                switch (new Random().nextInt(3)) {
                    case 0:
                        return MR_PANO_SERVER_RS1;
                    case 1:
                        return MR_PANO_SERVER_RS2;
                    case 2:
                        return MR_PANO_SERVER_RS3;
                    default:
                        return MR_PANO_SERVER_RS1;
                }
            } else {
                switch (new Random().nextInt(3)) {
                    case 0:
                        return MR_SERVER_RS1;
                    case 1:
                        return MR_SERVER_RS2;
                    case 2:
                        return MR_SERVER_RS3;
                    default:
                        return MR_SERVER_RS4;
                }
            }
        } else if (nZoneIndex == 1) {
            if (isPanoDevice) {
                switch (new Random().nextInt(3)) {
                    case 0:
                        return MR_PANO_SERVER_RS1;
                    case 1:
                        return MR_PANO_SERVER_RS2;
                    case 2:
                        return MR_PANO_SERVER_RS3;
                    default:
                        return MR_PANO_SERVER_RS1;
                }
            }
            switch (new Random().nextInt(3)) {
                case 0:
                    return MR_SERVER_RS1;
                case 1:
                    return MR_SERVER_RS2;
                case 2:
                    strMRServer = MR_SERVER_RS3;
                    break;
            }
            return MR_SERVER_RS4;
        } else if (nZoneIndex == 2) {
            return MR_SERVER_AS1;
        } else {
            if (nZoneIndex == 3) {
                return MR_SERVER_AS2;
            }
            if (nZoneIndex == 4) {
                return MR_SERVER_AS3;
            }
            if (nZoneIndex == 5) {
                return MR_SERVER_AS4;
            }
            if (nZoneIndex == 6) {
                return MR_SERVER_NA1;
            }
            if (nZoneIndex == 7) {
                return MR_SERVER_SA1;
            }
            if (nZoneIndex == 8) {
                return MR_SERVER_EU1;
            }
            if (nZoneIndex == 9) {
                return MR_SERVER_EU2;
            }
            if (nZoneIndex == 10) {
                return MR_SERVER_OA1;
            }
            if (nZoneIndex == 11) {
                return MR_SERVER_AF1;
            }
            if (nZoneIndex == 12) {
                return MR_SERVER_AF2;
            }
            return strMRServer;
        }
    }

    public static String getMRServerIP(int nIndex, int deviceId) {
        String strMRServer = "127.0.0.1";
        boolean isPanoDevice = getIsPanoDevice(deviceId);
        if (nZoneIndex == 0) {
            if (_strLanguage.equalsIgnoreCase("cn")) {
                if (isPanoDevice) {
                    if (nIndex == 0) {
                        return MR_PANO_SERVER_IP1;
                    }
                    if (nIndex == 1) {
                        return "120.26.209.166";
                    }
                    if (nIndex == 2) {
                        return MR_PANO_SERVER_IP3;
                    }
                    return MR_PANO_SERVER_IP1;
                } else if (nIndex == 0) {
                    return MR_SERVER_IP1;
                } else {
                    if (nIndex == 1) {
                        return "120.26.209.166";
                    }
                    if (nIndex == 2) {
                        return MR_SERVER_IP3;
                    }
                    return MR_SERVER_IP1;
                }
            } else if (nIndex == 0) {
                return "47.90.0.159";
            } else {
                if (nIndex == 1) {
                    return "47.88.0.218";
                }
                if (nIndex == 2) {
                    return "47.90.0.159";
                }
                return "47.90.0.159";
            }
        } else if (nZoneIndex == 1) {
            if (isPanoDevice) {
                if (nIndex == 0) {
                    return MR_PANO_SERVER_IP1;
                }
                if (nIndex == 1) {
                    return "120.26.209.166";
                }
                if (nIndex == 2) {
                    return MR_PANO_SERVER_IP3;
                }
                return MR_PANO_SERVER_IP1;
            } else if (nIndex == 0) {
                return MR_SERVER_IP1;
            } else {
                if (nIndex == 1) {
                    return "120.26.209.166";
                }
                if (nIndex == 2) {
                    return MR_SERVER_IP3;
                }
                return MR_SERVER_IP1;
            }
        } else if (nZoneIndex == 2) {
            if (nIndex == 0) {
                return "47.88.0.218";
            }
            if (nIndex == 1) {
                return "47.90.0.159";
            }
            if (nIndex == 2) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex == 3) {
            if (nIndex == 1) {
                return "47.88.0.218";
            }
            if (nIndex == 0) {
                return "47.90.0.159";
            }
            if (nIndex == 2) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex == 4) {
            if (nIndex == 2) {
                return "47.88.0.218";
            }
            if (nIndex == 0) {
                return "47.90.0.159";
            }
            if (nIndex == 1) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex == 5) {
            if (nIndex == 1) {
                return "47.88.0.218";
            }
            if (nIndex == 0) {
                return "47.90.0.159";
            }
            if (nIndex == 2) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex == 6) {
            if (nIndex == 1) {
                return "47.88.0.218";
            }
            if (nIndex == 2) {
                return "47.90.0.159";
            }
            if (nIndex == 0) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex == 7) {
            if (nIndex == 2) {
                return "47.88.0.218";
            }
            if (nIndex == 1) {
                return "47.90.0.159";
            }
            if (nIndex == 0) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex == 8) {
            if (nIndex == 2) {
                return "47.88.0.218";
            }
            if (nIndex == 0) {
                return "47.90.0.159";
            }
            if (nIndex == 1) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex == 9) {
            if (nIndex == 2) {
                return "47.88.0.218";
            }
            if (nIndex == 1) {
                return "47.90.0.159";
            }
            if (nIndex == 0) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex == 10) {
            if (nIndex == 1) {
                return "47.88.0.218";
            }
            if (nIndex == 0) {
                return "47.90.0.159";
            }
            if (nIndex == 2) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex == 11) {
            if (nIndex == 0) {
                return "47.88.0.218";
            }
            if (nIndex == 2) {
                return "47.90.0.159";
            }
            if (nIndex == 0) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        } else if (nZoneIndex != 12) {
            return strMRServer;
        } else {
            if (nIndex == 0) {
                return "47.88.0.218";
            }
            if (nIndex == 2) {
                return "47.90.0.159";
            }
            if (nIndex == 1) {
                return "47.90.0.159";
            }
            return "47.88.0.218";
        }
    }

    public static boolean getIsPanoDevice(int deviceId) {
        String strDeviceId = String.valueOf(deviceId);
        if (strDeviceId.length() < 8) {
            return false;
        }
        if (strDeviceId.startsWith("22") || strDeviceId.startsWith("23") || strDeviceId.startsWith("25") || strDeviceId.startsWith("27") || strDeviceId.startsWith("28")) {
            return true;
        }
        return false;
    }

    public static boolean is26DevicePano(String strDeviceId, int nDeviceId) {
        if (!strDeviceId.startsWith("26") || nDeviceId < 26200000 || nDeviceId > 26799999) {
            return false;
        }
        return true;
    }

    public static long getUnsignedInt(int data) {
        return ((long) data) & 4294967295L;
    }

    public static int getDeviceListType() {
        boolean hasPanoDevice = false;
        boolean hasNormalDevice = false;
        ArrayList<DeviceInfo> list = LocalDefines._severInfoListData;
        if (list == null || list.size() <= 0) {
            return 0;
        }
        int listSize = list.size();
        for (int i = 0; i < list.size(); i++) {
            if (getIsPanoDevice(((DeviceInfo) list.get(i)).getnDevID())) {
                hasPanoDevice = true;
            } else {
                hasNormalDevice = true;
            }
        }
        if (listSize == 1) {
            return 1;
        }
        if (hasNormalDevice && hasPanoDevice) {
            return 4;
        }
        if (hasNormalDevice && !hasPanoDevice) {
            return 2;
        }
        if (hasNormalDevice || !hasPanoDevice) {
            return 0;
        }
        return 3;
    }

    private static String getPhoneUserName() {
        if (HomePageActivity.AppMode == 1) {
            return HomePageActivity.LoginAccount;
        }
        return DeviceUuidFactory.getUniqueUUID(AppApplication.appApplicationContext);
    }
}
