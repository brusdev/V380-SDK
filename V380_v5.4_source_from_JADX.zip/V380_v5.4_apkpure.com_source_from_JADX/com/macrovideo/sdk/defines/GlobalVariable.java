package com.macrovideo.sdk.defines;

import android.app.Application;

public class GlobalVariable extends Application {
}
