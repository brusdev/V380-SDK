package com.macrovideo.sdk.setting;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class VersionInfoAndUpdateInfo implements Parcelable {
    public static final Creator CREATOR = new C02431();
    private int nDeviceVersionUpdate = 0;
    private int nDeviceVersionUpdateInformation = 0;
    private int nNewVersionNum = 0;
    private int nOldVersionNum = 0;
    private int nResult = -1;
    private String strAPPVersion = null;
    private String strAPPVersionDate = null;
    private String strDeviceNewVersionName = null;
    private String strHWVersion = null;
    private String strHWVersionDate = null;
    private String strKelVersion = null;
    private String strKelVersionDate = null;
    private String strNewVersionFunction = null;
    private String strNewVersionName = null;
    private String strNewVersionUpdateTime = null;
    private String strOldVersionName = null;
    private String strOldVersionUpdateTime = null;

    class C02431 implements Creator {
        C02431() {
        }

        public VersionInfoAndUpdateInfo createFromParcel(Parcel in) {
            return new VersionInfoAndUpdateInfo(in);
        }

        public VersionInfoAndUpdateInfo[] newArray(int size) {
            return new VersionInfoAndUpdateInfo[size];
        }
    }

    public int getnOldVersionNum() {
        return this.nOldVersionNum;
    }

    public void setnOldVersionNum(int nOldVersionNum) {
        this.nOldVersionNum = nOldVersionNum;
    }

    public String getStrOldVersionName() {
        return this.strOldVersionName;
    }

    public void setStrOldVersionName(String strOldVersionName) {
        this.strOldVersionName = strOldVersionName;
    }

    public String getStrOldVersionUpdateTime() {
        return this.strOldVersionUpdateTime;
    }

    public void setStrOldVersionUpdateTime(String strOldVersionUpdateTime) {
        this.strOldVersionUpdateTime = strOldVersionUpdateTime;
    }

    public int getnNewVersionNum() {
        return this.nNewVersionNum;
    }

    public void setnNewVersionNum(int nNewVersionNum) {
        this.nNewVersionNum = nNewVersionNum;
    }

    public String getStrNewVersionName() {
        return this.strNewVersionName;
    }

    public void setStrNewVersionName(String strNewVersionName) {
        this.strNewVersionName = strNewVersionName;
    }

    public String getStrNewVersionUpdateTime() {
        return this.strNewVersionUpdateTime;
    }

    public void setStrNewVersionUpdateTime(String strNewVersionUpdateTime) {
        this.strNewVersionUpdateTime = strNewVersionUpdateTime;
    }

    public String getStrNewVersionFunction() {
        return this.strNewVersionFunction;
    }

    public void setStrNewVersionFunction(String strNewVersionFunction) {
        this.strNewVersionFunction = strNewVersionFunction;
    }

    public int getnResult() {
        return this.nResult;
    }

    public void setnResult(int nResult) {
        this.nResult = nResult;
    }

    public String getStrAPPVersion() {
        return this.strAPPVersion;
    }

    public void setStrAPPVersion(String strAPPVersion) {
        this.strAPPVersion = strAPPVersion;
    }

    public String getStrKelVersion() {
        return this.strKelVersion;
    }

    public void setStrKelVersion(String strKelVersion) {
        this.strKelVersion = strKelVersion;
    }

    public String getStrHWVersion() {
        return this.strHWVersion;
    }

    public void setStrHWVersion(String strHWVersion) {
        this.strHWVersion = strHWVersion;
    }

    public String getStrAPPVersionDate() {
        return this.strAPPVersionDate;
    }

    public void setStrAPPVersionDate(String strAPPVersionDate) {
        this.strAPPVersionDate = strAPPVersionDate;
    }

    public String getStrKelVersionDate() {
        return this.strKelVersionDate;
    }

    public void setStrKelVersionDate(String strKelVersionDate) {
        this.strKelVersionDate = strKelVersionDate;
    }

    public String getStrHWVersionDate() {
        return this.strHWVersionDate;
    }

    public void setStrHWVersionDate(String strHWVersionDate) {
        this.strHWVersionDate = strHWVersionDate;
    }

    public int getnDeviceVersionUpdateInformation() {
        return this.nDeviceVersionUpdateInformation;
    }

    public void setnDeviceVersionUpdateInformation(int nDeviceVersionUpdateInformation) {
        this.nDeviceVersionUpdateInformation = nDeviceVersionUpdateInformation;
    }

    public int getnDeviceVersionUpdate() {
        return this.nDeviceVersionUpdate;
    }

    public void setnDeviceVersionUpdate(int nDeviceVersionUpdate) {
        this.nDeviceVersionUpdate = nDeviceVersionUpdate;
    }

    public String getStrDeviceNewVersionName() {
        return this.strDeviceNewVersionName;
    }

    public void setStrDeviceNewVersionName(String strDeviceNewVersionName) {
        this.strDeviceNewVersionName = strDeviceNewVersionName;
    }

    public int describeContents() {
        return 0;
    }

    public VersionInfoAndUpdateInfo(Parcel in) {
        this.nResult = in.readInt();
        this.strAPPVersion = in.readString();
        this.strKelVersion = in.readString();
        this.strHWVersion = in.readString();
        this.strAPPVersionDate = in.readString();
        this.strKelVersionDate = in.readString();
        this.strHWVersionDate = in.readString();
        this.nDeviceVersionUpdateInformation = in.readInt();
        this.nDeviceVersionUpdate = in.readInt();
        this.strDeviceNewVersionName = in.readString();
        this.nOldVersionNum = in.readInt();
        this.strOldVersionName = in.readString();
        this.strOldVersionUpdateTime = in.readString();
        this.nNewVersionNum = in.readInt();
        this.strNewVersionName = in.readString();
        this.strNewVersionUpdateTime = in.readString();
        this.strNewVersionFunction = in.readString();
    }

    public void writeToParcel(Parcel parcel, int arg1) {
        parcel.writeInt(this.nResult);
        parcel.writeString(this.strAPPVersion);
        parcel.writeString(this.strKelVersion);
        parcel.writeString(this.strHWVersion);
        parcel.writeString(this.strAPPVersionDate);
        parcel.writeString(this.strKelVersionDate);
        parcel.writeString(this.strHWVersionDate);
        parcel.writeInt(this.nDeviceVersionUpdateInformation);
        parcel.writeInt(this.nDeviceVersionUpdate);
        parcel.writeString(this.strDeviceNewVersionName);
        parcel.writeInt(this.nOldVersionNum);
        parcel.writeString(this.strOldVersionName);
        parcel.writeString(this.strOldVersionUpdateTime);
        parcel.writeInt(this.nNewVersionNum);
        parcel.writeString(this.strNewVersionName);
        parcel.writeString(this.strNewVersionUpdateTime);
        parcel.writeString(this.strNewVersionFunction);
    }
}
