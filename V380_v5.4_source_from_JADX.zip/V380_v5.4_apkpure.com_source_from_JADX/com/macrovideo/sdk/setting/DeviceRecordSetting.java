package com.macrovideo.sdk.setting;

import android.support.v4.media.TransportMediator;
import android.util.Log;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.LocalDefines;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Arrays;

public class DeviceRecordSetting {
    private static final int COMMUNICATIONS_BUFFER_SIZE = 412;
    private static final int MR_COMMUNICATIONS_BUFFER_SIZE = 256;
    private static final int SERVER_RETURN_BUFFER_SIZE = 412;
    private static byte[] buffer = new byte[412];

    public static RecordInfo getRecordSetting(DeviceInfo device) {
        RecordInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                RecordInfo deviceParams = new RecordInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = getRecordSettingServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = getRecordSettingMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        return deviceParam;
    }

    public static RecordInfo setRecordSetting(DeviceInfo device, boolean m_bAutoRecord, boolean m_bAlarmRecord, int nFullRecordOP, int nFrameSize, int m_isAudioEnable) {
        RecordInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                RecordInfo deviceParams = new RecordInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = setRecordSettingServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID(), m_bAutoRecord, m_bAlarmRecord, nFullRecordOP, nFrameSize, m_isAudioEnable);
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = setRecordSettingMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID(), m_bAutoRecord, m_bAlarmRecord, nFullRecordOP, nFrameSize, m_isAudioEnable);
            }
        }
        return deviceParam;
    }

    private static RecordInfo setRecordSettingServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID, boolean m_bAutoRecord, boolean m_bAlarmRecord, int nFullRecordOP, int nFrameSize, int m_isAudioEnable) {
        OutputStream writer = null;
        InputStream reader = null;
        RecordInfo recordHandler = new RecordInfo();
        recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("set server IP:" + strIP + " Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_RECORD_CONFIG_SET_REQUEST, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        if (m_bAutoRecord) {
                            Functions.IntToBytes(1100, buffer, 68);
                        } else {
                            Functions.IntToBytes(1200, buffer, 68);
                        }
                        if (m_bAlarmRecord) {
                            Functions.IntToBytes(1100, buffer, 72);
                        } else {
                            Functions.IntToBytes(1200, buffer, 72);
                        }
                        Functions.IntToBytes((long) nFullRecordOP, buffer, 76);
                        Functions.IntToBytes((long) nDeviceID, buffer, 80);
                        Functions.ShortToBytes((short) nFrameSize, buffer, 84);
                        Functions.ShortToBytes((short) m_isAudioEnable, buffer, 86);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            if (nResultCmd == 214) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                recordHandler.setnResult(256);
                                recordHandler.setnFullRecordOP(nFullRecordOP);
                                recordHandler.setbAutoRecord(m_bAutoRecord);
                                recordHandler.setbAlarmRecord(m_bAlarmRecord);
                                recordHandler.setnFrameSize(nFrameSize);
                                recordHandler.setnAudioEnable(m_isAudioEnable);
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return recordHandler;
    }

    private static RecordInfo setRecordSettingMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID, boolean m_bAutoRecord, boolean m_bAlarmRecord, int nFullRecordOP, int nFrameSize, int m_isAudioEnable) {
        OutputStream writer = null;
        InputStream reader = null;
        RecordInfo recordHandler = new RecordInfo();
        recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("MR set server IP:" + strMRServerIP + " Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        Log.e("dqx", "setRecordSettingMRServer 1");
        if (sSocket == null) {
            Log.e("dqx", "setRecordSettingMRServer socket == null");
        } else {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Log.e("dqx", "setRecordSettingMRServer isConnectOK");
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_RECORD_CONFIG_SET_REQUEST, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        if (m_bAutoRecord) {
                            Functions.IntToBytes(1100, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        } else {
                            Functions.IntToBytes(1200, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        }
                        if (m_bAlarmRecord) {
                            Functions.IntToBytes(1100, buffer, 130);
                        } else {
                            Functions.IntToBytes(1200, buffer, 130);
                        }
                        Functions.IntToBytes((long) nFullRecordOP, buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST);
                        Functions.IntToBytes((long) nDeviceID, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_SEND_REQUEST);
                        Functions.ShortToBytes((short) nFrameSize, buffer, Defines.NV_IPC_IP_CONFIG_GET_REQUEST);
                        Functions.ShortToBytes((short) m_isAudioEnable, buffer, 144);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            Log.e("dqx", "setRecordSettingMRServer reader.available() = " + reader.available());
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        Log.e("dqx", "setRecordSettingMRServer bReadOK = " + bReadOK);
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            Log.e("dqx", "setRecordSettingMRServer nResultCmd = " + nResultCmd + " nResultValue = " + nResultValue + " nResultDesc = " + nResultDesc);
                            if (nResultCmd == 214) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                recordHandler.setnResult(256);
                                recordHandler.setnFullRecordOP(nFullRecordOP);
                                recordHandler.setbAutoRecord(m_bAutoRecord);
                                recordHandler.setbAlarmRecord(m_bAlarmRecord);
                                recordHandler.setnFrameSize(nFrameSize);
                                recordHandler.setnAudioEnable(m_isAudioEnable);
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return recordHandler;
    }

    private static RecordInfo getRecordSettingServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        RecordInfo recordHandler = new RecordInfo();
        recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("get server IP:" + strIP + " Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 113, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        Functions.IntToBytes((long) nDeviceID, buffer, 68);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 213) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                recordHandler.setnResult(256);
                                int nAutoRecord = Functions.BytesToInt(buffer, 8);
                                int nAlarmRecord = Functions.BytesToInt(buffer, 12);
                                recordHandler.setnFullRecordOP(Functions.BytesToInt(buffer, 16));
                                recordHandler.setnDiskSize(Functions.BytesToInt(buffer, 20));
                                recordHandler.setnDiskRemainSize(Functions.BytesToInt(buffer, 24));
                                if (buffer[28] == (byte) 1) {
                                    recordHandler.setIs1080PEnable(true);
                                } else {
                                    recordHandler.setIs1080PEnable(false);
                                }
                                if (buffer[29] == (byte) 1) {
                                    recordHandler.setIs720Enable(true);
                                } else {
                                    recordHandler.setIs720Enable(false);
                                }
                                if (buffer[30] == (byte) 1) {
                                    recordHandler.setD1Enable(true);
                                } else {
                                    recordHandler.setD1Enable(false);
                                }
                                if (buffer[31] == (byte) 1) {
                                    recordHandler.setVGAEnable(true);
                                } else {
                                    recordHandler.setVGAEnable(false);
                                }
                                if (buffer[32] == (byte) 1) {
                                    recordHandler.setCIFEnable(true);
                                } else {
                                    recordHandler.setCIFEnable(false);
                                }
                                if (buffer[33] == (byte) 1) {
                                    recordHandler.setQVGAEnable(true);
                                } else {
                                    recordHandler.setQVGAEnable(false);
                                }
                                if (buffer[34] == (byte) 1) {
                                    recordHandler.setQCIFEnable(true);
                                } else {
                                    recordHandler.setQCIFEnable(false);
                                }
                                recordHandler.setnFrameSize(Functions.BytesToShort(buffer, 36));
                                recordHandler.setnAudioEnable(Functions.BytesToShort(buffer, 38));
                                recordHandler.setnRecordStat(Functions.BytesToShort(buffer, 40));
                                if (buffer[42] == (byte) 1) {
                                    recordHandler.setSDCardFormatting(true);
                                } else {
                                    recordHandler.setSDCardFormatting(false);
                                }
                                if (nAutoRecord == 1100) {
                                    recordHandler.setbAutoRecord(true);
                                } else {
                                    recordHandler.setbAutoRecord(false);
                                }
                                if (nAlarmRecord == 1100) {
                                    recordHandler.setbAlarmRecord(true);
                                } else {
                                    recordHandler.setbAlarmRecord(false);
                                }
                                if (recordHandler.getnAudioEnable() == 1000) {
                                    recordHandler.setAudioEnable(true);
                                } else {
                                    recordHandler.setAudioEnable(false);
                                }
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e6) {
                                    e6.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return recordHandler;
    }

    private static RecordInfo getRecordSettingMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        RecordInfo recordHandler = new RecordInfo();
        recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("MR get server IP:" + strMRServerIP + " Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 113, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 213) {
                                Functions.changeMRParam(nDeviceID, true);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            recordHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                recordHandler.setnResult(256);
                                int nAutoRecord = Functions.BytesToInt(buffer, 8);
                                int nAlarmRecord = Functions.BytesToInt(buffer, 12);
                                recordHandler.setnFullRecordOP(Functions.BytesToInt(buffer, 16));
                                recordHandler.setnDiskSize(Functions.BytesToInt(buffer, 20));
                                recordHandler.setnDiskRemainSize(Functions.BytesToInt(buffer, 24));
                                if (buffer[28] == (byte) 1) {
                                    recordHandler.setIs1080PEnable(true);
                                } else {
                                    recordHandler.setIs1080PEnable(false);
                                }
                                if (buffer[29] == (byte) 1) {
                                    recordHandler.setIs720Enable(true);
                                } else {
                                    recordHandler.setIs720Enable(false);
                                }
                                if (buffer[30] == (byte) 1) {
                                    recordHandler.setD1Enable(true);
                                } else {
                                    recordHandler.setD1Enable(false);
                                }
                                if (buffer[31] == (byte) 1) {
                                    recordHandler.setVGAEnable(true);
                                } else {
                                    recordHandler.setVGAEnable(false);
                                }
                                if (buffer[32] == (byte) 1) {
                                    recordHandler.setCIFEnable(true);
                                } else {
                                    recordHandler.setCIFEnable(false);
                                }
                                if (buffer[33] == (byte) 1) {
                                    recordHandler.setQVGAEnable(true);
                                } else {
                                    recordHandler.setQVGAEnable(false);
                                }
                                if (buffer[34] == (byte) 1) {
                                    recordHandler.setQCIFEnable(true);
                                } else {
                                    recordHandler.setQCIFEnable(false);
                                }
                                recordHandler.setnFrameSize(Functions.BytesToShort(buffer, 36));
                                recordHandler.setnAudioEnable(Functions.BytesToShort(buffer, 38));
                                recordHandler.setnRecordStat(Functions.BytesToShort(buffer, 40));
                                if (buffer[42] == (byte) 1) {
                                    recordHandler.setSDCardFormatting(true);
                                } else {
                                    recordHandler.setSDCardFormatting(false);
                                }
                                if (nAutoRecord == 1100) {
                                    recordHandler.setbAutoRecord(true);
                                } else {
                                    recordHandler.setbAutoRecord(false);
                                }
                                if (nAlarmRecord == 1100) {
                                    recordHandler.setbAlarmRecord(true);
                                } else {
                                    recordHandler.setbAlarmRecord(false);
                                }
                                if (recordHandler.getnAudioEnable() == 1000) {
                                    recordHandler.setAudioEnable(true);
                                } else {
                                    recordHandler.setAudioEnable(false);
                                }
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e6) {
                                    e6.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return recordHandler;
    }
}
