package com.macrovideo.sdk.setting;

import android.support.v4.media.TransportMediator;
import android.util.Log;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.LocalDefines;
import com.tencent.android.tpush.common.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DeviceNetwordSetting {
    private static final int COMMUNICATIONS_BUFFER_SIZE = 412;
    private static final int MR_COMMUNICATIONS_BUFFER_SIZE = 256;
    private static final int SERVER_RETURN_BUFFER_SIZE = 412;
    private static boolean bWifiSwitchs = false;
    private static byte[] buffer = new byte[412];

    public static IPConfigInfo getIPConfig(DeviceInfo device) {
        IPConfigInfo ipConfig = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                ipConfig = new IPConfigInfo();
                ipConfig.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return ipConfig;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                ipConfig = getIPConfigServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (ipConfig == null || ipConfig.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                ipConfig = getIPConfigMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        return ipConfig;
    }

    public static int setIPConfig(DeviceInfo device, IPConfigInfo ipConfig) {
        int nResult = 0;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                return 0;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                nResult = setIPConfigServer(device, ipConfig);
            }
            if (nResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                nResult = setIPConfigMRServer(device, ipConfig);
            }
        }
        return nResult;
    }

    public static NetwordInfo getNetword(DeviceInfo device) {
        NetwordInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                NetwordInfo deviceParams = new NetwordInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = getNetwordServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = getNetwordMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        return deviceParam;
    }

    public static List<WifiInfo> getNetwordWifiList(DeviceInfo device, boolean bWifiSwitch) {
        List<WifiInfo> deviceParam = null;
        bWifiSwitchs = bWifiSwitch;
        if (device == null || device.getnDevID() <= 0 || device.getnPort() <= 0 || !bWifiSwitch) {
            return null;
        }
        if (Functions.isIpAddress(device.getStrIP())) {
            deviceParam = getNetwordWifiServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword());
        }
        if (deviceParam == null || deviceParam.size() <= 0) {
            return getNetwordWifiMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
        }
        return deviceParam;
    }

    public static NetwordInfo setNetword(DeviceInfo device, int nMode, String strWifiName, String strWifiPassword) {
        NetwordInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                NetwordInfo deviceParams = new NetwordInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = setNetwordServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID(), nMode, strWifiName, strWifiPassword);
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = setNetwordMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID(), nMode, strWifiName, strWifiPassword);
            }
        }
        return deviceParam;
    }

    public static NetwordInfo setNetwordWithBSSID(DeviceInfo device, int nMode, String strWifiName, String strWifiPassword, String strBSSID) {
        NetwordInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                NetwordInfo deviceParams = new NetwordInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = setNetwordServerWithBSSID(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID(), nMode, strWifiName, strWifiPassword, strBSSID);
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = setNetwordMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID(), nMode, strWifiName, strWifiPassword);
            }
        }
        return deviceParam;
    }

    public static NetwordInfo setNetwordAP(DeviceInfo device, boolean bAPSet, String strAPName, String strAPPassword, boolean bWifiSet, String strWifiName, String strWifiPassword) {
        NetwordInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                NetwordInfo deviceParams = new NetwordInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            deviceParam = setNetwordAp(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID(), bAPSet, strAPName, strAPPassword, bWifiSet, strWifiName, strWifiPassword);
        }
        return deviceParam;
    }

    private static NetwordInfo setNetwordAp(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID, boolean bAPSet, String strAPName, String strAPPassword, boolean bWifiSet, String strWifiName, String strWifiPassword) {
        OutputStream writer = null;
        InputStream reader = null;
        NetwordInfo networdHandler = new NetwordInfo();
        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("set server IP:" + strIP + "Port : " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 112, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        if (bAPSet) {
                            Functions.IntToBytes(1001, buffer, 68);
                            System.arraycopy(strAPName.getBytes(), 0, buffer, 72, strAPName.getBytes().length);
                            System.arraycopy(strAPPassword.getBytes(), 0, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_REQUEST, strAPPassword.getBytes().length);
                        } else {
                            Functions.IntToBytes(1000, buffer, 68);
                        }
                        if (bWifiSet) {
                            Functions.IntToBytes(1001, buffer, 168);
                            System.arraycopy(strWifiName.getBytes(), 0, buffer, LocalDefines.NV_IPC_ONLINE_CHECK_REQUEST, strWifiName.getBytes().length);
                            System.arraycopy(strWifiPassword.getBytes(), 0, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_RESPONSE, strWifiPassword.getBytes().length);
                        } else {
                            Functions.IntToBytes(1000, buffer, 168);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, 268);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            if (nResultCmd == 212) {
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        case 1015:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERR_AP);
                                            break;
                                        case 1016:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR_STATION);
                                            break;
                                        case 1017:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                networdHandler.setnResult(256);
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return networdHandler;
    }

    private static NetwordInfo setNetwordServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID, int nMode, String strWifiName, String strWifiPassword) {
        OutputStream writer = null;
        InputStream reader = null;
        NetwordInfo networdHandler = new NetwordInfo();
        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 120, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        Functions.IntToBytes((long) nMode, buffer, 68);
                        byte[] byWifiName = null;
                        if (strWifiName != null) {
                            try {
                                byWifiName = strWifiName.getBytes("GBK");
                            } catch (UnsupportedEncodingException e) {
                                byWifiName = strWifiName.getBytes();
                            }
                        }
                        if (byWifiName != null) {
                            System.arraycopy(byWifiName, 0, buffer, 72, byWifiName.length);
                        }
                        byte[] byWifiPassword = null;
                        if (strWifiPassword != null) {
                            try {
                                byWifiPassword = strWifiPassword.getBytes("GBK");
                            } catch (UnsupportedEncodingException e2) {
                                byWifiPassword = strWifiPassword.getBytes();
                            }
                        }
                        if (byWifiPassword != null) {
                            System.arraycopy(byWifiPassword, 0, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_REQUEST, byWifiPassword.length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, 168);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e3) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e4) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e5) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e6) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e7) {
                                    e7.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            if (nResultCmd == 220) {
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        case 1015:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERR_AP);
                                            break;
                                        case 1016:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR_STATION);
                                            break;
                                        case 1017:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                networdHandler.setnResult(256);
                            } else {
                                switch (nResultDesc) {
                                    case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                        break;
                                    case 1015:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERR_AP);
                                        break;
                                    case 1016:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR_STATION);
                                        break;
                                    case 1017:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e8) {
                                e8.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e9) {
                isConnectOK = false;
            }
        }
        return networdHandler;
    }

    private static NetwordInfo setNetwordServerWithBSSID(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID, int nMode, String strWifiName, String strWifiPassword, String strBSSID) {
        OutputStream writer = null;
        InputStream reader = null;
        NetwordInfo networdHandler = new NetwordInfo();
        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 120, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        Functions.IntToBytes((long) nMode, buffer, 68);
                        byte[] byWifiName = null;
                        if (strWifiName != null) {
                            try {
                                byWifiName = strWifiName.getBytes("GBK");
                            } catch (UnsupportedEncodingException e) {
                                byWifiName = strWifiName.getBytes();
                            }
                        }
                        if (byWifiName != null) {
                            System.arraycopy(byWifiName, 0, buffer, 72, byWifiName.length);
                        }
                        byte[] byWifiPassword = null;
                        if (strWifiPassword != null) {
                            try {
                                byWifiPassword = strWifiPassword.getBytes("GBK");
                            } catch (UnsupportedEncodingException e2) {
                                byWifiPassword = strWifiPassword.getBytes();
                            }
                        }
                        if (byWifiPassword != null) {
                            System.arraycopy(byWifiPassword, 0, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_REQUEST, byWifiPassword.length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, 168);
                        if (strBSSID == null || strBSSID.length() <= 0) {
                            Functions.IntToBytes(0, buffer, LocalDefines.NV_IPC_ONLINE_CHECK_REQUEST);
                        } else {
                            Functions.IntToBytes(1, buffer, LocalDefines.NV_IPC_ONLINE_CHECK_REQUEST);
                            System.arraycopy(strBSSID.getBytes(), 0, buffer, 173, strBSSID.getBytes().length);
                        }
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e3) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e4) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e5) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e6) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e7) {
                                try {
                                    e7.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            if (nResultCmd == 220) {
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        case 1015:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERR_AP);
                                            break;
                                        case 1016:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR_STATION);
                                            break;
                                        case 1017:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                networdHandler.setnResult(256);
                            } else {
                                switch (nResultDesc) {
                                    case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                        break;
                                    case 1015:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERR_AP);
                                        break;
                                    case 1016:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR_STATION);
                                        break;
                                    case 1017:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e8) {
                                e8.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e9) {
                isConnectOK = false;
            }
        }
        return networdHandler;
    }

    private static NetwordInfo setNetwordMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID, int nMode, String strWifiName, String strWifiPassword) {
        OutputStream writer = null;
        InputStream reader = null;
        NetwordInfo networdHandler = new NetwordInfo();
        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("MR set server IP:" + strMRServerIP + "Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 120, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nMode, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        byte[] byWifiName = null;
                        if (strWifiName != null) {
                            try {
                                byWifiName = strWifiName.getBytes("GBK");
                            } catch (UnsupportedEncodingException e) {
                                byWifiName = strWifiName.getBytes();
                            }
                        }
                        if (byWifiName != null) {
                            System.arraycopy(byWifiName, 0, buffer, 130, byWifiName.length);
                        }
                        byte[] byWifiPassword = null;
                        if (strWifiPassword != null) {
                            try {
                                byWifiPassword = strWifiPassword.getBytes("GBK");
                            } catch (UnsupportedEncodingException e2) {
                                byWifiPassword = strWifiPassword.getBytes();
                            }
                        }
                        if (byWifiPassword != null) {
                            System.arraycopy(byWifiPassword, 0, buffer, 194, byWifiPassword.length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, 226);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e3) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e4) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e5) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e6) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e7) {
                                    e7.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            if (nResultCmd == 220) {
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        case 1015:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERR_AP);
                                            break;
                                        case 1016:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR_STATION);
                                            break;
                                        case 1017:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                networdHandler.setnResult(256);
                            } else {
                                switch (nResultDesc) {
                                    case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                        break;
                                    case 1015:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERR_AP);
                                        break;
                                    case 1016:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_CODE_FAIL_PWD_ERR_STATION);
                                        break;
                                    case 1017:
                                        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e8) {
                                e8.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e9) {
                isConnectOK = false;
            }
        }
        return networdHandler;
    }

    private static IPConfigInfo getIPConfigServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        IPConfigInfo ipConfig = new IPConfigInfo();
        ipConfig.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_IP_CONFIG_GET_REQUEST, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        Functions.IntToBytes((long) nDeviceID, buffer, 68);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 242) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            ipConfig.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            ipConfig.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            ipConfig.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                ipConfig.setnResult(256);
                                if (buffer[8] == (byte) 1) {
                                    ipConfig.setDisableDHCP(true);
                                    int len = 0;
                                    while (len < 16 && ((char) buffer[len + 9]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] ip = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 9, ip, 0, len);
                                    try {
                                        ipConfig.setStrIP(new String(ip, "GBK"));
                                    } catch (UnsupportedEncodingException e6) {
                                        ipConfig.setStrIP(new String(ip));
                                    }
                                    len = 0;
                                    while (len < 16 && ((char) buffer[len + 25]) != '\u0000') {
                                        len++;
                                    }
                                    Object mask = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 25, mask, 0, len);
                                    try {
                                        ipConfig.setStrMask(new String(mask, "GBK"));
                                    } catch (UnsupportedEncodingException e7) {
                                        ipConfig.setStrMask(new String(mask));
                                    }
                                    len = 0;
                                    while (len < 16 && ((char) buffer[len + 41]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] gateway = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 41, gateway, 0, len);
                                    try {
                                        ipConfig.setStrGateway(new String(gateway, "GBK"));
                                    } catch (UnsupportedEncodingException e8) {
                                        ipConfig.setStrGateway(new String(gateway));
                                    }
                                    len = 0;
                                    while (len < 16 && ((char) buffer[len + 57]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] dns1 = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 57, dns1, 0, len);
                                    try {
                                        ipConfig.setStrDNS1(new String(dns1, "GBK"));
                                    } catch (UnsupportedEncodingException e9) {
                                        ipConfig.setStrDNS1(new String(dns1));
                                    }
                                    len = 0;
                                    while (len < 16 && ((char) buffer[len + 73]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] dns2 = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 73, dns2, 0, len);
                                    try {
                                        ipConfig.setStrDNS2(new String(dns2, "GBK"));
                                    } catch (UnsupportedEncodingException e10) {
                                        ipConfig.setStrDNS2(new String(dns2));
                                    }
                                } else {
                                    ipConfig.setDisableDHCP(false);
                                    ipConfig.setStrDNS1(null);
                                    ipConfig.setStrDNS2(null);
                                    ipConfig.setStrIP(null);
                                    ipConfig.setStrGateway(null);
                                    ipConfig.setStrMask(null);
                                }
                            } else if (nResultCmd == -100) {
                                ipConfig.setnResult(ResultCode.RESULE_CODE_FAIL_CMD_NO_SUPORT);
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e11) {
                                    e11.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e12) {
                isConnectOK = false;
            }
        }
        return ipConfig;
    }

    private static IPConfigInfo getIPConfigMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        IPConfigInfo ipConfig = new IPConfigInfo();
        ipConfig.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 880, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        Functions.IntToBytes((long) Defines.NV_IPC_IP_CONFIG_GET_REQUEST, buffer, 130);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            Log.w("tt", "���յ�¼���: OK:242, " + nResultCmd + "_" + nResultValue);
                            if (nResultCmd == 242) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            ipConfig.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            ipConfig.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            ipConfig.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                ipConfig.setnResult(256);
                                if (buffer[8] == (byte) 1) {
                                    ipConfig.setDisableDHCP(true);
                                    int len = 0;
                                    while (len < 16 && ((char) buffer[len + 9]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] ip = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 9, ip, 0, len);
                                    try {
                                        ipConfig.setStrIP(new String(ip, "GBK"));
                                    } catch (UnsupportedEncodingException e6) {
                                        ipConfig.setStrIP(new String(ip));
                                    }
                                    len = 0;
                                    while (len < 16 && ((char) buffer[len + 25]) != '\u0000') {
                                        len++;
                                    }
                                    Object mask = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 25, mask, 0, len);
                                    try {
                                        ipConfig.setStrMask(new String(mask, "GBK"));
                                    } catch (UnsupportedEncodingException e7) {
                                        ipConfig.setStrMask(new String(mask));
                                    }
                                    len = 0;
                                    while (len < 16 && ((char) buffer[len + 41]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] gateway = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 41, gateway, 0, len);
                                    try {
                                        ipConfig.setStrGateway(new String(gateway, "GBK"));
                                    } catch (UnsupportedEncodingException e8) {
                                        ipConfig.setStrGateway(new String(gateway));
                                    }
                                    len = 0;
                                    while (len < 16 && ((char) buffer[len + 57]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] dns1 = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 57, dns1, 0, len);
                                    try {
                                        ipConfig.setStrDNS1(new String(dns1, "GBK"));
                                    } catch (UnsupportedEncodingException e9) {
                                        ipConfig.setStrDNS1(new String(dns1));
                                    }
                                    len = 0;
                                    while (len < 16 && ((char) buffer[len + 73]) != '\u0000') {
                                        len++;
                                    }
                                    byte[] dns2 = new byte[len];
                                    Arrays.fill(ip, (byte) 0);
                                    System.arraycopy(buffer, 73, dns2, 0, len);
                                    try {
                                        ipConfig.setStrDNS2(new String(dns2, "GBK"));
                                    } catch (UnsupportedEncodingException e10) {
                                        ipConfig.setStrDNS2(new String(dns2));
                                    }
                                } else {
                                    ipConfig.setDisableDHCP(false);
                                    ipConfig.setStrDNS1(null);
                                    ipConfig.setStrDNS2(null);
                                    ipConfig.setStrIP(null);
                                    ipConfig.setStrGateway(null);
                                    ipConfig.setStrMask(null);
                                }
                            } else if (nResultCmd == -100) {
                                ipConfig.setnResult(ResultCode.RESULE_CODE_FAIL_CMD_NO_SUPORT);
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e11) {
                                    e11.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e12) {
                isConnectOK = false;
            }
        }
        return ipConfig;
    }

    private static NetwordInfo getNetwordServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        NetwordInfo networdHandler = new NetwordInfo();
        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("get server IP:" + strIP + "Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 111, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        Functions.IntToBytes((long) nDeviceID, buffer, 68);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 211) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                networdHandler.setnResult(256);
                                networdHandler.setnMode(Functions.BytesToInt(buffer, 8));
                                int len = 0;
                                while (len < 64 && ((char) buffer[len + 12]) != '\u0000') {
                                    len++;
                                }
                                byte[] apUsername = new byte[len];
                                Arrays.fill(apUsername, (byte) 0);
                                System.arraycopy(buffer, 12, apUsername, 0, len);
                                try {
                                    networdHandler.setStrApName(new String(apUsername, "GBK"));
                                } catch (UnsupportedEncodingException e6) {
                                    networdHandler.setStrApName(new String(apUsername));
                                }
                                len = 0;
                                while (len < 32 && ((char) buffer[len + 76]) != '\u0000') {
                                    len++;
                                }
                                byte[] apPassword = new byte[len];
                                Arrays.fill(apPassword, (byte) 0);
                                System.arraycopy(buffer, 76, apPassword, 0, len);
                                try {
                                    networdHandler.setStrApPassword(new String(apPassword, "GBK"));
                                } catch (UnsupportedEncodingException e7) {
                                    networdHandler.setStrApPassword(new String(apPassword));
                                }
                                if (Functions.BytesToInt(buffer, 108) == 1001) {
                                    networdHandler.setbWifiSet(true);
                                }
                                if (networdHandler.isbWifiSet()) {
                                    len = 0;
                                    while (len < 64 && ((char) buffer[len + 112]) != '\u0000') {
                                        len++;
                                    }
                                    Object wifiUsername = new byte[len];
                                    Arrays.fill(wifiUsername, (byte) 0);
                                    System.arraycopy(buffer, 112, wifiUsername, 0, len);
                                    try {
                                        networdHandler.setStrWifiName(new String(wifiUsername, "GBK"));
                                    } catch (UnsupportedEncodingException e8) {
                                        networdHandler.setStrWifiName(new String(wifiUsername));
                                    }
                                    len = 0;
                                    while (len < 32 && ((char) buffer[len + 176]) != '\u0000') {
                                        len++;
                                    }
                                    Object wifiPassword = new byte[len];
                                    Arrays.fill(wifiPassword, (byte) 0);
                                    System.arraycopy(buffer, 176, wifiPassword, 0, len);
                                    try {
                                        networdHandler.setStrWifiPassword(new String(wifiPassword, "GBK"));
                                    } catch (UnsupportedEncodingException e9) {
                                        networdHandler.setStrWifiPassword(new String(wifiPassword));
                                    }
                                }
                                networdHandler.setnDeviceVersion(buffer[208]);
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e10) {
                                    e10.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e11) {
                isConnectOK = false;
            }
        }
        return networdHandler;
    }

    private static NetwordInfo getNetwordMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        NetwordInfo networdHandler = new NetwordInfo();
        networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("MR get server IP:" + strMRServerIP + "Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 111, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 211) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            networdHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                networdHandler.setnResult(256);
                                networdHandler.setnMode(Functions.BytesToInt(buffer, 8));
                                int len = 0;
                                while (len < 64 && ((char) buffer[len + 12]) != '\u0000') {
                                    len++;
                                }
                                byte[] apUsername = new byte[len];
                                Arrays.fill(apUsername, (byte) 0);
                                System.arraycopy(buffer, 12, apUsername, 0, len);
                                try {
                                    networdHandler.setStrApName(new String(apUsername, "GBK"));
                                } catch (UnsupportedEncodingException e6) {
                                    networdHandler.setStrApName(new String(apUsername));
                                }
                                len = 0;
                                while (len < 32 && ((char) buffer[len + 76]) != '\u0000') {
                                    len++;
                                }
                                byte[] apPassword = new byte[len];
                                Arrays.fill(apPassword, (byte) 0);
                                System.arraycopy(buffer, 76, apPassword, 0, len);
                                try {
                                    networdHandler.setStrApPassword(new String(apPassword, "GBK"));
                                } catch (UnsupportedEncodingException e7) {
                                    networdHandler.setStrApPassword(new String(apPassword));
                                }
                                if (Functions.BytesToInt(buffer, 108) == 1001) {
                                    networdHandler.setbWifiSet(true);
                                }
                                if (networdHandler.isbWifiSet()) {
                                    len = 0;
                                    while (len < 64 && ((char) buffer[len + 112]) != '\u0000') {
                                        len++;
                                    }
                                    Object wifiUsername = new byte[len];
                                    Arrays.fill(wifiUsername, (byte) 0);
                                    System.arraycopy(buffer, 112, wifiUsername, 0, len);
                                    try {
                                        networdHandler.setStrWifiName(new String(wifiUsername, "GBK"));
                                    } catch (UnsupportedEncodingException e8) {
                                        networdHandler.setStrWifiName(new String(wifiUsername));
                                    }
                                    len = 0;
                                    while (len < 32 && ((char) buffer[len + 176]) != '\u0000') {
                                        len++;
                                    }
                                    Object wifiPassword = new byte[len];
                                    Arrays.fill(wifiPassword, (byte) 0);
                                    System.arraycopy(buffer, 176, wifiPassword, 0, len);
                                    try {
                                        networdHandler.setStrWifiPassword(new String(wifiPassword, "GBK"));
                                    } catch (UnsupportedEncodingException e9) {
                                        networdHandler.setStrWifiPassword(new String(wifiPassword));
                                    }
                                }
                                networdHandler.setnDeviceVersion(buffer[208]);
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e10) {
                                    e10.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e11) {
                isConnectOK = false;
            }
        }
        return networdHandler;
    }

    private static List<WifiInfo> getNetwordWifiServer(String strIP, int nPort, String strUsername, String strPassword) {
        OutputStream writer = null;
        InputStream reader = null;
        List<WifiInfo> wifiList = new ArrayList();
        System.out.println("get wifi list server IP:" + strIP + "Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return null;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return null;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 110, buffer, 0);
                System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                try {
                    writer.write(buffer, 0, 412);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                while (bWifiSwitchs && tryTimes < 50 && !sSocket.isClosed() && !sSocket.isInputShutdown() && !sSocket.isOutputShutdown()) {
                    Arrays.fill(buffer, (byte) 0);
                    boolean bReadOK = false;
                    do {
                        if (reader.available() >= 412) {
                            reader.read(buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(200);
                        } catch (InterruptedException e5) {
                            try {
                                e5.printStackTrace();
                            } catch (IOException e6) {
                            }
                        }
                        tryTimes++;
                        if (tryTimes < 50) {
                            if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                break;
                            }
                        } else {
                            break;
                        }
                    } while (bWifiSwitchs);
                    if (bReadOK) {
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int nWifiCount = Functions.BytesToInt(buffer, 4);
                        if (nCMD != 310 && nCMD == 210 && nWifiCount > 0 && nWifiCount <= 20) {
                            int nWifiNo = Functions.BytesToInt(buffer, 8);
                            int nFrequency = Functions.BytesToInt(buffer, 32);
                            int nSignalLevel = Functions.BytesToInt(buffer, 36);
                            int nFlag = Functions.BytesToInt(buffer, 40);
                            int len = 0;
                            while (len < 20 && ((char) buffer[len + 12]) != '\u0000') {
                                len++;
                            }
                            byte[] bssid = new byte[len];
                            Arrays.fill(bssid, (byte) 0);
                            System.arraycopy(buffer, 12, bssid, 0, len);
                            len = 0;
                            while (len < 64 && ((char) buffer[len + 44]) != '\u0000') {
                                len++;
                            }
                            Object ssid = new byte[len];
                            Arrays.fill(ssid, (byte) 0);
                            System.arraycopy(buffer, 44, ssid, 0, len);
                            String strProtectDesc = null;
                            if (nFlag == 1) {
                                len = 0;
                                while (len < 128 && ((char) buffer[len + 108]) != '\u0000') {
                                    len++;
                                }
                                Object protectDesc = new byte[len];
                                Arrays.fill(protectDesc, (byte) 0);
                                System.arraycopy(buffer, 108, protectDesc, 0, len);
                                strProtectDesc = new String(protectDesc);
                            }
                            String strBSSID = new String(bssid);
                            String str = Constants.MAIN_VERSION_TAG;
                            try {
                                str = new String(ssid, "GBK");
                            } catch (UnsupportedEncodingException e7) {
                                str = new String(ssid);
                            }
                            wifiList.add(new WifiInfo(strBSSID, nFrequency, nSignalLevel, nFlag, str, strProtectDesc));
                            if (nWifiCount == nWifiNo + 1) {
                                break;
                            }
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e8) {
                    e8.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return wifiList;
        } catch (IOException e9) {
            isConnectOK = false;
            wifiList = null;
        }
    }

    private static List<WifiInfo> getNetwordWifiMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        List<WifiInfo> wifiList = new ArrayList();
        System.out.println("MR get wifi list server IP:" + strMRServerIP + "Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 5000, nDeviceID);
        if (sSocket == null) {
            return null;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return null;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 110, buffer, 0);
                System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 110, buffer, 0);
                Functions.IntToBytes(1002, buffer, 4);
                if (strDomain != null) {
                    System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                }
                Functions.IntToBytes((long) nPort, buffer, 58);
                if (strUsername != null) {
                    System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                }
                if (strPassword != null) {
                    System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                }
                Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                int tryTimes = 0;
                while (bWifiSwitchs && tryTimes < 50 && !sSocket.isClosed() && !sSocket.isInputShutdown() && !sSocket.isOutputShutdown()) {
                    Arrays.fill(buffer, (byte) 0);
                    boolean bReadOK = false;
                    do {
                        try {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e5) {
                                e5.printStackTrace();
                            }
                            tryTimes++;
                            if (tryTimes < 50) {
                                if (sSocket.isClosed() || sSocket.isInputShutdown() || sSocket.isOutputShutdown()) {
                                    break;
                                }
                            } else {
                                break;
                            }
                        } catch (IOException e6) {
                        }
                    } while (bWifiSwitchs);
                    if (bReadOK) {
                        int nCMD = Functions.BytesToInt(buffer, 0);
                        int nWifiCount = Functions.BytesToInt(buffer, 4);
                        if (nCMD != 310 && nCMD == 210 && nWifiCount > 0 && nWifiCount <= 20) {
                            int nWifiNo = Functions.BytesToInt(buffer, 8);
                            int nFrequency = Functions.BytesToInt(buffer, 32);
                            int nSignalLevel = Functions.BytesToInt(buffer, 36);
                            int nFlag = Functions.BytesToInt(buffer, 40);
                            int len = 0;
                            while (len < 20 && ((char) buffer[len + 12]) != '\u0000') {
                                len++;
                            }
                            byte[] bssid = new byte[len];
                            Arrays.fill(bssid, (byte) 0);
                            System.arraycopy(buffer, 12, bssid, 0, len);
                            len = 0;
                            while (len < 64 && ((char) buffer[len + 44]) != '\u0000') {
                                len++;
                            }
                            Object ssid = new byte[len];
                            Arrays.fill(ssid, (byte) 0);
                            System.arraycopy(buffer, 44, ssid, 0, len);
                            String strProtectDesc = null;
                            if (nFlag == 1) {
                                len = 0;
                                while (len < 128 && ((char) buffer[len + 108]) != '\u0000') {
                                    len++;
                                }
                                Object protectDesc = new byte[len];
                                Arrays.fill(protectDesc, (byte) 0);
                                System.arraycopy(buffer, 108, protectDesc, 0, len);
                                strProtectDesc = new String(protectDesc);
                            }
                            String strBSSID = new String(bssid);
                            String str = Constants.MAIN_VERSION_TAG;
                            try {
                                str = new String(ssid, "GBK");
                            } catch (UnsupportedEncodingException e7) {
                                str = new String(ssid);
                            }
                            wifiList.add(new WifiInfo(strBSSID, nFrequency, nSignalLevel, nFlag, str, strProtectDesc));
                            if (nWifiCount == nWifiNo + 1) {
                                break;
                            }
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e8) {
                    e8.printStackTrace();
                    return wifiList;
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
            return wifiList;
        } catch (IOException e9) {
            isConnectOK = false;
        }
    }

    private static int setIPConfigServer(DeviceInfo device, IPConfigInfo ipConfig) {
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        Socket sSocket = Functions.connectToServer(device.getStrIP(), device.getnPort(), Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) Defines.NV_IPC_IP_CONFIG_SET_REQUEST, buffer, 0);
                if (device.getStrUsername() != null) {
                    System.arraycopy(device.getStrUsername().getBytes(), 0, buffer, 4, device.getStrUsername().getBytes().length);
                }
                if (device.getStrPassword() != null) {
                    System.arraycopy(device.getStrPassword().getBytes(), 0, buffer, 36, device.getStrPassword().getBytes().length);
                }
                Functions.IntToBytes((long) device.getnDevID(), buffer, 68);
                if (ipConfig.isDisableDHCP()) {
                    buffer[72] = (byte) 1;
                    byte[] byIP = null;
                    if (ipConfig.getStrIP() != null) {
                        try {
                            byIP = ipConfig.getStrIP().getBytes("GBK");
                        } catch (UnsupportedEncodingException e) {
                            byIP = ipConfig.getStrIP().getBytes();
                        }
                    }
                    if (byIP != null) {
                        System.arraycopy(byIP, 0, buffer, 73, byIP.length);
                    }
                    byte[] byMask = null;
                    if (ipConfig.getStrMask() != null) {
                        try {
                            byMask = ipConfig.getStrMask().getBytes("GBK");
                        } catch (UnsupportedEncodingException e2) {
                            byMask = ipConfig.getStrMask().getBytes();
                        }
                    }
                    if (byMask != null) {
                        System.arraycopy(byMask, 0, buffer, 89, byMask.length);
                    }
                    byte[] byGateway = null;
                    if (ipConfig.getStrGateway() != null) {
                        try {
                            byGateway = ipConfig.getStrGateway().getBytes("GBK");
                        } catch (UnsupportedEncodingException e3) {
                            byGateway = ipConfig.getStrGateway().getBytes();
                        }
                    }
                    if (byGateway != null) {
                        System.arraycopy(byGateway, 0, buffer, 105, byGateway.length);
                    }
                    byte[] byDNS1 = null;
                    if (ipConfig.getStrDNS1() != null) {
                        try {
                            byDNS1 = ipConfig.getStrDNS1().getBytes("GBK");
                        } catch (UnsupportedEncodingException e4) {
                            byDNS1 = ipConfig.getStrDNS1().getBytes();
                        }
                    }
                    if (byDNS1 != null) {
                        System.arraycopy(byDNS1, 0, buffer, Defines.NV_IP_SWITCH_GET_REQUEST, byDNS1.length);
                    }
                    byte[] byDNS2 = null;
                    if (ipConfig.getStrDNS2() != null) {
                        try {
                            byDNS2 = ipConfig.getStrDNS2().getBytes("GBK");
                        } catch (UnsupportedEncodingException e5) {
                            byDNS2 = ipConfig.getStrDNS2().getBytes();
                        }
                    }
                    if (byDNS2 != null) {
                        System.arraycopy(byDNS2, 0, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_FREE_REQUEST, byDNS2.length);
                    }
                } else {
                    buffer[72] = (byte) 0;
                }
                try {
                    writer.write(buffer, 0, 412);
                    writer.flush();
                } catch (IOException e6) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e7) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e8) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e9) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 5) {
                    try {
                        if (reader.available() >= 412) {
                            reader.read(buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e10) {
                            e10.printStackTrace();
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK) {
                    int nResultCmd = Functions.BytesToInt(buffer, 0);
                    int nResultValue = Functions.BytesToInt(buffer, 4);
                    int nResultDesc = Functions.BytesToInt(buffer, 8);
                    if (nResultCmd == 243) {
                        if (nResultValue == 1001) {
                            nResult = 256;
                        } else {
                            switch (nResultDesc) {
                                case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_USER_NOEXIST;
                                    break;
                                case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_PWD_ERROR;
                                    break;
                                case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                    break;
                            }
                            nResult = ResultCode.RESULE_CODE_FAIL_PARAM_ERR;
                        }
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e11) {
                        e11.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
            }
            return nResult;
        } catch (IOException e12) {
            isConnectOK = false;
        }
    }

    private static int setIPConfigMRServer(DeviceInfo device, IPConfigInfo ipConfig) {
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        Socket sSocket = Functions.connectToMRServer(device.getStrMRServer(), device.getnMRPort(), 8000, device.getnDevID());
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 881, buffer, 0);
                Functions.IntToBytes(1002, buffer, 4);
                if (device.getStrDomain() != null) {
                    System.arraycopy(device.getStrDomain().getBytes(), 0, buffer, 8, device.getStrDomain().getBytes().length);
                }
                Functions.IntToBytes((long) device.getnPort(), buffer, 58);
                if (device.getStrUsername() != null) {
                    System.arraycopy(device.getStrUsername().getBytes(), 0, buffer, 62, device.getStrUsername().getBytes().length);
                }
                if (device.getStrPassword() != null) {
                    System.arraycopy(device.getStrPassword().getBytes(), 0, buffer, 94, device.getStrPassword().getBytes().length);
                }
                Functions.IntToBytes((long) device.getnDevID(), buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                Functions.IntToBytes((long) Defines.NV_IPC_IP_CONFIG_SET_REQUEST, buffer, 130);
                if (ipConfig.isDisableDHCP()) {
                    buffer[LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST] = (byte) 1;
                    byte[] byIP = null;
                    if (ipConfig.getStrIP() != null) {
                        try {
                            byIP = ipConfig.getStrIP().getBytes("GBK");
                        } catch (UnsupportedEncodingException e) {
                            byIP = ipConfig.getStrIP().getBytes();
                        }
                    }
                    if (byIP != null) {
                        System.arraycopy(byIP, 0, buffer, 135, byIP.length);
                    }
                    byte[] byMask = null;
                    if (ipConfig.getStrMask() != null) {
                        try {
                            byMask = ipConfig.getStrMask().getBytes("GBK");
                        } catch (UnsupportedEncodingException e2) {
                            byMask = ipConfig.getStrMask().getBytes();
                        }
                    }
                    if (byMask != null) {
                        System.arraycopy(byMask, 0, buffer, Defines.REC_FILE_DOWNLOAD, byMask.length);
                    }
                    byte[] byGateway = null;
                    if (ipConfig.getStrGateway() != null) {
                        try {
                            byGateway = ipConfig.getStrGateway().getBytes("GBK");
                        } catch (UnsupportedEncodingException e3) {
                            byGateway = ipConfig.getStrGateway().getBytes();
                        }
                    }
                    if (byGateway != null) {
                        System.arraycopy(byGateway, 0, buffer, 167, byGateway.length);
                    }
                    byte[] byDNS1 = null;
                    if (ipConfig.getStrDNS1() != null) {
                        try {
                            byDNS1 = ipConfig.getStrDNS1().getBytes("GBK");
                        } catch (UnsupportedEncodingException e4) {
                            byDNS1 = ipConfig.getStrDNS1().getBytes();
                        }
                    }
                    if (byDNS1 != null) {
                        System.arraycopy(byDNS1, 0, buffer, 183, byDNS1.length);
                    }
                    byte[] byDNS2 = null;
                    if (ipConfig.getStrDNS2() != null) {
                        try {
                            byDNS2 = ipConfig.getStrDNS2().getBytes("GBK");
                        } catch (UnsupportedEncodingException e5) {
                            byDNS2 = ipConfig.getStrDNS2().getBytes();
                        }
                    }
                    if (byDNS2 != null) {
                        System.arraycopy(byDNS2, 0, buffer, 199, byDNS2.length);
                    }
                } else {
                    buffer[LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST] = (byte) 0;
                }
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e6) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e7) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e8) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e9) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 5) {
                    try {
                        if (reader.available() >= 412) {
                            reader.read(buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e10) {
                            e10.printStackTrace();
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK) {
                    int nResultCmd = Functions.BytesToInt(buffer, 0);
                    int nResultValue = Functions.BytesToInt(buffer, 4);
                    int nResultDesc = Functions.BytesToInt(buffer, 8);
                    if (nResultCmd == 243) {
                        if (nResultValue != 1001) {
                            switch (nResultDesc) {
                                case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_USER_NOEXIST;
                                    break;
                                case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_PWD_ERROR;
                                    break;
                                case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED;
                                    break;
                                default:
                                    nResult = ResultCode.RESULE_CODE_FAIL_PARAM_ERR;
                                    break;
                            }
                        }
                        nResult = 256;
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e11) {
                        e11.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
            }
            return nResult;
        } catch (IOException e12) {
            isConnectOK = false;
        }
    }
}
