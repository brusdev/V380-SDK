package com.macrovideo.sdk.setting;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class AccountInfo implements Parcelable {
    public static final Creator CREATOR = new C02371();
    private int nResult = -1;
    private int nUserID = 0;
    private String strPassword = null;
    private String strUserName = null;

    class C02371 implements Creator {
        C02371() {
        }

        public AccountInfo createFromParcel(Parcel in) {
            return new AccountInfo(in);
        }

        public AccountInfo[] newArray(int size) {
            return new AccountInfo[size];
        }
    }

    public int getnResult() {
        return this.nResult;
    }

    public void setnResult(int nResult) {
        this.nResult = nResult;
    }

    public int getnUserID() {
        return this.nUserID;
    }

    public void setnUserID(int nUserID) {
        this.nUserID = nUserID;
    }

    public String getStrUserName() {
        return this.strUserName;
    }

    public void setStrUserName(String strUserName) {
        this.strUserName = strUserName;
    }

    public String getStrPassword() {
        return this.strPassword;
    }

    public void setStrPassword(String strPassword) {
        this.strPassword = strPassword;
    }

    public int describeContents() {
        return 0;
    }

    public AccountInfo(Parcel in) {
        this.nResult = in.readInt();
        this.nUserID = in.readInt();
        this.strUserName = in.readString();
        this.strPassword = in.readString();
    }

    public void writeToParcel(Parcel parcel, int arg1) {
        parcel.writeInt(this.nResult);
        parcel.writeInt(this.nUserID);
        parcel.writeString(this.strUserName);
        parcel.writeString(this.strPassword);
    }
}
