package com.macrovideo.sdk.setting;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class AlarmAndPromptInfo implements Parcelable {
    public static final Creator CREATOR = new C02381();
    private int alarmcolumns = 8;
    private int alarmrows = 4;
    private boolean bAlarmVoiceSwitch = false;
    private boolean bMainAlarmSwitch = false;
    private boolean bMotionAlarmSwitch = false;
    private boolean bPIRAlarmSwitch = false;
    private boolean bSmokeAlarmSwitch = false;
    private boolean bVoicePromptsMainSwitch = false;
    private int canSetTime = 0;
    private int endhour1;
    private int endhour2;
    private int endhour3;
    private int endmin1;
    private int endmin2;
    private int endmin3;
    private int endsec1;
    private int endsec2;
    private int endsec3 = 0;
    private boolean hasAlarmConfig = false;
    private boolean hasExIOConfig = false;
    private boolean hasVoicePromptsConfig = false;
    private int nIOMode = 0;
    private int nLanguage = 1000;
    private int nResult = 0;
    private int serverAlarmSwitch1 = 0;
    private int serverAlarmSwitch2 = 0;
    private int serverAlarmSwitch3 = 0;
    private int starthour1;
    private int starthour2;
    private int starthour3;
    private int startmin1;
    private int startmin2;
    private int startmin3;
    private int startsec1;
    private int startsec2;
    private int startsec3 = 0;

    class C02381 implements Creator {
        C02381() {
        }

        public AlarmAndPromptInfo createFromParcel(Parcel in) {
            return new AlarmAndPromptInfo(in);
        }

        public AlarmAndPromptInfo[] newArray(int size) {
            return new AlarmAndPromptInfo[size];
        }
    }

    public int getStarthour1() {
        return this.starthour1;
    }

    public void setStarthour1(int starthour1) {
        this.starthour1 = starthour1;
    }

    public int getStarthour2() {
        return this.starthour2;
    }

    public void setStarthour2(int starthour2) {
        this.starthour2 = starthour2;
    }

    public int getStarthour3() {
        return this.starthour3;
    }

    public void setStarthour3(int starthour3) {
        this.starthour3 = starthour3;
    }

    public int getStartmin1() {
        return this.startmin1;
    }

    public void setStartmin1(int startmin1) {
        this.startmin1 = startmin1;
    }

    public int getStartmin2() {
        return this.startmin2;
    }

    public void setStartmin2(int startmin2) {
        this.startmin2 = startmin2;
    }

    public int getStartmin3() {
        return this.startmin3;
    }

    public void setStartmin3(int startmin3) {
        this.startmin3 = startmin3;
    }

    public int getStartsec1() {
        return this.startsec1;
    }

    public void setStartsec1(int startsec1) {
        this.startsec1 = startsec1;
    }

    public int getStartsec2() {
        return this.startsec2;
    }

    public void setStartsec2(int startsec2) {
        this.startsec2 = startsec2;
    }

    public int getStartsec3() {
        return this.startsec3;
    }

    public void setStartsec3(int startsec3) {
        this.startsec3 = startsec3;
    }

    public int getEndhour1() {
        return this.endhour1;
    }

    public void setEndhour1(int endhour1) {
        this.endhour1 = endhour1;
    }

    public int getEndhour2() {
        return this.endhour2;
    }

    public void setEndhour2(int endhour2) {
        this.endhour2 = endhour2;
    }

    public int getEndhour3() {
        return this.endhour3;
    }

    public void setEndhour3(int endhour3) {
        this.endhour3 = endhour3;
    }

    public int getEndmin1() {
        return this.endmin1;
    }

    public void setEndmin1(int endmin1) {
        this.endmin1 = endmin1;
    }

    public int getEndmin2() {
        return this.endmin2;
    }

    public void setEndmin2(int endmin2) {
        this.endmin2 = endmin2;
    }

    public int getEndmin3() {
        return this.endmin3;
    }

    public void setEndmin3(int endmin3) {
        this.endmin3 = endmin3;
    }

    public int getEndsec1() {
        return this.endsec1;
    }

    public void setEndsec1(int endsec1) {
        this.endsec1 = endsec1;
    }

    public int getEndsec2() {
        return this.endsec2;
    }

    public void setEndsec2(int endsec2) {
        this.endsec2 = endsec2;
    }

    public int getEndsec3() {
        return this.endsec3;
    }

    public void setEndsec3(int endsec3) {
        this.endsec3 = endsec3;
    }

    public int getnResult() {
        return this.nResult;
    }

    public void setnResult(int nResult) {
        this.nResult = nResult;
    }

    public boolean isHasAlarmConfig() {
        return this.hasAlarmConfig;
    }

    public void setHasAlarmConfig(boolean hasAlarmConfig) {
        this.hasAlarmConfig = hasAlarmConfig;
    }

    public boolean isbMainAlarmSwitch() {
        return this.bMainAlarmSwitch;
    }

    public void setbMainAlarmSwitch(boolean bMainAlarmSwitch) {
        this.bMainAlarmSwitch = bMainAlarmSwitch;
    }

    public boolean isbMotionAlarmSwitch() {
        return this.bMotionAlarmSwitch;
    }

    public void setbMotionAlarmSwitch(boolean bMotionAlarmSwitch) {
        this.bMotionAlarmSwitch = bMotionAlarmSwitch;
    }

    public boolean isbPIRAlarmSwitch() {
        return this.bPIRAlarmSwitch;
    }

    public void setbPIRAlarmSwitch(boolean bPIRAlarmSwitch) {
        this.bPIRAlarmSwitch = bPIRAlarmSwitch;
    }

    public boolean isbSmokeAlarmSwitch() {
        return this.bSmokeAlarmSwitch;
    }

    public void setbSmokeAlarmSwitch(boolean bSmokeAlarmSwitch) {
        this.bSmokeAlarmSwitch = bSmokeAlarmSwitch;
    }

    public boolean isHasVoicePromptsConfig() {
        return this.hasVoicePromptsConfig;
    }

    public void setHasVoicePromptsConfig(boolean hasVoicePromptsConfig) {
        this.hasVoicePromptsConfig = hasVoicePromptsConfig;
    }

    public boolean isbVoicePromptsMainSwitch() {
        return this.bVoicePromptsMainSwitch;
    }

    public void setbVoicePromptsMainSwitch(boolean bVoicePromptsMainSwitch) {
        this.bVoicePromptsMainSwitch = bVoicePromptsMainSwitch;
    }

    public boolean isbAlarmVoiceSwitch() {
        return this.bAlarmVoiceSwitch;
    }

    public void setbAlarmVoiceSwitch(boolean bAlarmVoiceSwitch) {
        this.bAlarmVoiceSwitch = bAlarmVoiceSwitch;
    }

    public int getnLanguage() {
        return this.nLanguage;
    }

    public void setnLanguage(int nLanguage) {
        this.nLanguage = nLanguage;
    }

    public boolean isHasExIOConfig() {
        return this.hasExIOConfig;
    }

    public void setHasExIOConfig(boolean hasExIOConfig) {
        this.hasExIOConfig = hasExIOConfig;
    }

    public int getnIOMode() {
        return this.nIOMode;
    }

    public void setnIOMode(int nIOMode) {
        this.nIOMode = nIOMode;
    }

    public AlarmAndPromptInfo(Parcel in) {
        boolean z;
        boolean z2 = true;
        this.nResult = in.readInt();
        this.hasAlarmConfig = in.readByte() == (byte) 1;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bMainAlarmSwitch = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bMotionAlarmSwitch = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bPIRAlarmSwitch = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bSmokeAlarmSwitch = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.hasVoicePromptsConfig = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bVoicePromptsMainSwitch = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bAlarmVoiceSwitch = z;
        this.nLanguage = in.readInt();
        if (in.readByte() != (byte) 1) {
            z2 = false;
        }
        this.hasExIOConfig = z2;
        this.nIOMode = in.readInt();
        this.canSetTime = in.readInt();
        this.alarmrows = in.readInt();
        this.alarmcolumns = in.readInt();
        this.serverAlarmSwitch1 = in.readInt();
        this.serverAlarmSwitch2 = in.readInt();
        this.serverAlarmSwitch3 = in.readInt();
        this.starthour1 = in.readInt();
        this.starthour2 = in.readInt();
        this.starthour3 = in.readInt();
        this.startmin1 = in.readInt();
        this.startmin2 = in.readInt();
        this.startmin3 = in.readInt();
        this.startsec1 = in.readInt();
        this.startsec2 = in.readInt();
        this.startsec3 = in.readInt();
        this.endhour1 = in.readInt();
        this.endhour2 = in.readInt();
        this.endhour3 = in.readInt();
        this.endmin1 = in.readInt();
        this.endmin2 = in.readInt();
        this.endmin3 = in.readInt();
        this.endsec1 = in.readInt();
        this.endsec2 = in.readInt();
        this.endsec3 = in.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int arg1) {
        int i;
        int i2 = 1;
        parcel.writeInt(this.nResult);
        parcel.writeByte((byte) (this.hasAlarmConfig ? 1 : 0));
        if (this.bMainAlarmSwitch) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.bMotionAlarmSwitch) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.bPIRAlarmSwitch) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.bSmokeAlarmSwitch) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.hasVoicePromptsConfig) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.bVoicePromptsMainSwitch) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.bAlarmVoiceSwitch) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (!this.hasExIOConfig) {
            i2 = 0;
        }
        parcel.writeByte((byte) i2);
        parcel.writeInt(this.nLanguage);
        parcel.writeInt(this.nIOMode);
        parcel.writeInt(this.canSetTime);
        parcel.writeInt(this.alarmrows);
        parcel.writeInt(this.alarmcolumns);
        parcel.writeInt(this.serverAlarmSwitch1);
        parcel.writeInt(this.serverAlarmSwitch2);
        parcel.writeInt(this.serverAlarmSwitch3);
        parcel.writeInt(this.starthour1);
        parcel.writeInt(this.starthour2);
        parcel.writeInt(this.starthour3);
        parcel.writeInt(this.startmin1);
        parcel.writeInt(this.startmin2);
        parcel.writeInt(this.startmin3);
        parcel.writeInt(this.startsec1);
        parcel.writeInt(this.startsec2);
        parcel.writeInt(this.startsec3);
        parcel.writeInt(this.endhour1);
        parcel.writeInt(this.endhour2);
        parcel.writeInt(this.endhour3);
        parcel.writeInt(this.endmin1);
        parcel.writeInt(this.endmin2);
        parcel.writeInt(this.endmin3);
        parcel.writeInt(this.endsec1);
        parcel.writeInt(this.endsec2);
        parcel.writeInt(this.endsec3);
    }

    public int getCanSetTime() {
        return this.canSetTime;
    }

    public void setCanSetTime(int canSetTime) {
        this.canSetTime = canSetTime;
    }

    public int getAlarmrows() {
        return this.alarmrows;
    }

    public void setAlarmrows(int alarmrows) {
        this.alarmrows = alarmrows;
    }

    public int getAlarmcolumns() {
        return this.alarmcolumns;
    }

    public void setAlarmcolumns(int alarmcolumns) {
        this.alarmcolumns = alarmcolumns;
    }

    public int getServerAlarmSwitch1() {
        return this.serverAlarmSwitch1;
    }

    public void setServerAlarmSwitch1(int serverAlarmSwitch1) {
        this.serverAlarmSwitch1 = serverAlarmSwitch1;
    }

    public int getServerAlarmSwitch2() {
        return this.serverAlarmSwitch2;
    }

    public void setServerAlarmSwitch2(int serverAlarmSwitch2) {
        this.serverAlarmSwitch2 = serverAlarmSwitch2;
    }

    public int getServerAlarmSwitch3() {
        return this.serverAlarmSwitch3;
    }

    public void setServerAlarmSwitch3(int serverAlarmSwitch3) {
        this.serverAlarmSwitch3 = serverAlarmSwitch3;
    }
}
