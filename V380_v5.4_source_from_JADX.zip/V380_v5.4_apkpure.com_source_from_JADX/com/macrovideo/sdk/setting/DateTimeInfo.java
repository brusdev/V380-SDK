package com.macrovideo.sdk.setting;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class DateTimeInfo implements Parcelable {
    public static final Creator CREATOR = new C02391();
    private boolean isTimeZoneEnable = false;
    private int nResult = -1;
    private int nTimeType = 0;
    private int nTimeZoneIndex = 0;
    private String strTime = null;

    class C02391 implements Creator {
        C02391() {
        }

        public DateTimeInfo createFromParcel(Parcel in) {
            return new DateTimeInfo(in);
        }

        public DateTimeInfo[] newArray(int size) {
            return new DateTimeInfo[size];
        }
    }

    public int getnResult() {
        return this.nResult;
    }

    public void setnResult(int nResult) {
        this.nResult = nResult;
    }

    public int getnTimeType() {
        return this.nTimeType;
    }

    public void setnTimeType(int nTimeType) {
        this.nTimeType = nTimeType;
    }

    public String getStrTime() {
        return this.strTime;
    }

    public void setStrTime(String strTime) {
        this.strTime = strTime;
    }

    public boolean isTimeZoneEnable() {
        return this.isTimeZoneEnable;
    }

    public void setTimeZoneEnable(boolean isTimeZoneEnable) {
        this.isTimeZoneEnable = isTimeZoneEnable;
    }

    public int getnTimeZoneIndex() {
        return this.nTimeZoneIndex;
    }

    public void setnTimeZoneIndex(int nTimeZoneIndex) {
        this.nTimeZoneIndex = nTimeZoneIndex;
    }

    public DateTimeInfo(Parcel in) {
        boolean z = true;
        this.nResult = in.readInt();
        this.nTimeType = in.readInt();
        this.strTime = in.readString();
        if (in.readByte() != (byte) 1) {
            z = false;
        }
        this.isTimeZoneEnable = z;
        this.nTimeZoneIndex = in.readInt();
    }

    public void writeToParcel(Parcel parcel, int arg1) {
        parcel.writeInt(this.nResult);
        parcel.writeInt(this.nTimeType);
        parcel.writeString(this.strTime);
        parcel.writeByte((byte) (this.isTimeZoneEnable ? 1 : 0));
        parcel.writeInt(this.nTimeZoneIndex);
    }

    public int describeContents() {
        return 0;
    }
}
