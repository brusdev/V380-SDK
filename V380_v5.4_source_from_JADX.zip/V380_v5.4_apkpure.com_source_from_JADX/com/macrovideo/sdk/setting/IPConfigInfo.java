package com.macrovideo.sdk.setting;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class IPConfigInfo implements Parcelable {
    public static final Creator CREATOR = new C02401();
    private boolean isDisableDHCP = false;
    private int nResult = -1;
    private String strDNS1 = null;
    private String strDNS2 = null;
    private String strGateway = null;
    private String strIP = null;
    private String strMask = null;

    class C02401 implements Creator {
        C02401() {
        }

        public IPConfigInfo createFromParcel(Parcel in) {
            return new IPConfigInfo(in);
        }

        public IPConfigInfo[] newArray(int size) {
            return new IPConfigInfo[size];
        }
    }

    public int getnResult() {
        return this.nResult;
    }

    public void setnResult(int nResult) {
        this.nResult = nResult;
    }

    public String getStrIP() {
        return this.strIP;
    }

    public void setStrIP(String strIP) {
        this.strIP = strIP;
    }

    public String getStrMask() {
        return this.strMask;
    }

    public void setStrMask(String strMask) {
        this.strMask = strMask;
    }

    public String getStrGateway() {
        return this.strGateway;
    }

    public void setStrGateway(String strGateway) {
        this.strGateway = strGateway;
    }

    public String getStrDNS1() {
        return this.strDNS1;
    }

    public void setStrDNS1(String strDNS1) {
        this.strDNS1 = strDNS1;
    }

    public String getStrDNS2() {
        return this.strDNS2;
    }

    public void setStrDNS2(String strDNS2) {
        this.strDNS2 = strDNS2;
    }

    public IPConfigInfo(Parcel in) {
        this.nResult = in.readInt();
    }

    public void writeToParcel(Parcel parcel, int arg1) {
        parcel.writeInt(this.nResult);
    }

    public int describeContents() {
        return 0;
    }

    public boolean isDisableDHCP() {
        return this.isDisableDHCP;
    }

    public void setDisableDHCP(boolean isDisableDHCP) {
        this.isDisableDHCP = isDisableDHCP;
    }
}
