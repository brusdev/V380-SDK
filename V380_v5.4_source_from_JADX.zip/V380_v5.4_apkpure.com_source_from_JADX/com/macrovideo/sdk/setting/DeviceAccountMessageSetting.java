package com.macrovideo.sdk.setting;

import android.support.v4.media.TransportMediator;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.DialogTipCode;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Arrays;

public class DeviceAccountMessageSetting {
    private static final int ACCOUNT_COMMUNICATIONS_BUFFER_SIZE = 412;
    private static final int ACCOUNT_SERVER_RETURN_BUFFER_SIZE = 412;
    private static final int MR_ACCOUNT_COMMUNICATIONS_BUFFER_SIZE = 256;
    private static byte[] buffer = new byte[412];

    public static AccountInfo getAccountMessage(DeviceInfo device) {
        AccountInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                AccountInfo deviceParams = new AccountInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = getAccountMessageServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = getAccountMessageMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        return deviceParam;
    }

    public static AccountInfo setAccountMessage(DeviceInfo device, String strNewUsername, String strNewPassword, int nUserID) {
        AccountInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0 || strNewUsername == null || strNewUsername.length() <= 0) {
                AccountInfo deviceParams = new AccountInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = setAccountMessageServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), strNewUsername, device.getStrPassword(), strNewPassword, device.getnDevID(), nUserID);
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = setAccountMessageMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), strNewUsername, device.getStrPassword(), strNewPassword, device.getnDevID(), nUserID);
            }
        }
        return deviceParam;
    }

    private static AccountInfo setAccountMessageServer(String strIP, int nPort, String strOldUsername, String strNewUsername, String strOldPassword, String strNewPassword, int nDeviceID, int nUserID) {
        OutputStream writer = null;
        InputStream reader = null;
        AccountInfo accountHandler = new AccountInfo();
        accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("set server IP:" + strIP + "Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_USERINFO_SET_REQUEST, buffer, 0);
                        if (strOldUsername != null && strOldUsername.length() > 0) {
                            System.arraycopy(strOldUsername.getBytes(), 0, buffer, 4, strOldUsername.getBytes().length);
                        }
                        if (strOldPassword != null && strOldPassword.length() > 0) {
                            System.arraycopy(strOldPassword.getBytes(), 0, buffer, 36, strOldPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nUserID, buffer, 68);
                        if (strNewUsername != null && strNewUsername.length() > 0) {
                            System.arraycopy(strNewUsername.getBytes(), 0, buffer, 72, strNewUsername.getBytes().length);
                        }
                        if (strNewPassword != null && strNewPassword.length() > 0) {
                            System.arraycopy(strNewPassword.getBytes(), 0, buffer, DialogTipCode.PHONE_NUMBER_IS_NOT_STANDARDLIZED, strNewPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_REQUEST);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            if (nResultCmd == 218) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                accountHandler.setnResult(256);
                                accountHandler.setStrUserName(strNewUsername);
                                accountHandler.setStrPassword(strNewPassword);
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return accountHandler;
    }

    private static AccountInfo setAccountMessageMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strOldUsername, String strNewUsername, String strOldPassword, String strNewPassword, int nDeviceID, int nUserID) {
        OutputStream writer = null;
        InputStream reader = null;
        AccountInfo accountHandler = new AccountInfo();
        accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("MR set server IP:" + strMRServerIP + " Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_USERINFO_SET_REQUEST, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strOldUsername != null) {
                            System.arraycopy(strOldUsername.getBytes(), 0, buffer, 62, strOldUsername.getBytes().length);
                        }
                        if (strOldPassword != null) {
                            System.arraycopy(strOldPassword.getBytes(), 0, buffer, 94, strOldPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nUserID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        if (strNewUsername != null && strNewUsername.length() > 0) {
                            System.arraycopy(strNewUsername.getBytes(), 0, buffer, 130, strNewUsername.getBytes().length);
                        }
                        if (strNewPassword != null && strNewPassword.length() > 0) {
                            System.arraycopy(strNewPassword.getBytes(), 0, buffer, Defines.PACKET_FLAG_POSITION, strNewPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, 194);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            if (nResultCmd == 218) {
                                Functions.changeMRParam(nDeviceID, true);
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                accountHandler.setnResult(256);
                                accountHandler.setStrUserName(strNewUsername);
                                accountHandler.setStrPassword(strNewPassword);
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return accountHandler;
    }

    private static AccountInfo getAccountMessageServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        AccountInfo accountHandler = new AccountInfo();
        accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("get server IP:" + strIP + "  Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_USERINFO_GET_REQUEST, buffer, 0);
                        if (strUsername != null && strUsername.length() > 0) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        }
                        if (strPassword != null && strPassword.length() > 0) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, 68);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 217) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                accountHandler.setnResult(256);
                                int nUserCount = Functions.BytesToInt(buffer, 8);
                                int nUserSeq = Functions.BytesToInt(buffer, 12);
                                int nUserID = Functions.BytesToInt(buffer, 16);
                                int len = 0;
                                while (len < 32 && ((char) buffer[len + 20]) != '\u0000') {
                                    len++;
                                }
                                Object username = new byte[len];
                                Arrays.fill(username, (byte) 0);
                                System.arraycopy(buffer, 20, username, 0, len);
                                String strNewUserName = new String(username);
                                len = 0;
                                while (len < 32 && ((char) buffer[len + 52]) != '\u0000') {
                                    len++;
                                }
                                Object password = new byte[len];
                                Arrays.fill(password, (byte) 0);
                                System.arraycopy(buffer, 52, password, 0, len);
                                String str = new String(password);
                                accountHandler.setnUserID(nUserID);
                                accountHandler.setStrUserName(strNewUserName);
                                accountHandler.setStrPassword(str);
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e6) {
                                    e6.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return accountHandler;
    }

    private static AccountInfo getAccountMessageMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        AccountInfo accountHandler = new AccountInfo();
        accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("MR get server IP:" + strMRServerIP + " Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_USERINFO_GET_REQUEST, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 217) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            accountHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                accountHandler.setnResult(256);
                                int nUserCount = Functions.BytesToInt(buffer, 8);
                                int nUserSeq = Functions.BytesToInt(buffer, 12);
                                int nUserID = Functions.BytesToInt(buffer, 16);
                                int len = 0;
                                while (len < 32 && ((char) buffer[len + 20]) != '\u0000') {
                                    len++;
                                }
                                Object username = new byte[len];
                                Arrays.fill(username, (byte) 0);
                                System.arraycopy(buffer, 20, username, 0, len);
                                String strNewUserName = new String(username);
                                len = 0;
                                while (len < 32 && ((char) buffer[len + 52]) != '\u0000') {
                                    len++;
                                }
                                Object password = new byte[len];
                                Arrays.fill(password, (byte) 0);
                                System.arraycopy(buffer, 52, password, 0, len);
                                String str = new String(password);
                                accountHandler.setnUserID(nUserID);
                                accountHandler.setStrUserName(strNewUserName);
                                accountHandler.setStrPassword(str);
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e6) {
                                    e6.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return accountHandler;
    }
}
