package com.macrovideo.sdk.setting;

public class WifiInfo implements Comparable<Object> {
    private String bssid = null;
    private int flags = 0;
    private int frequency = 0;
    private String protectDesc = null;
    private int signalLevel = 0;
    private String ssid = null;

    public WifiInfo(String bssid, int frequency, int signalLevel, int flags, String ssid, String protectDesc) {
        this.bssid = bssid;
        this.ssid = ssid;
        this.frequency = frequency;
        this.signalLevel = signalLevel;
        this.flags = flags;
        this.protectDesc = protectDesc;
    }

    public String getProtectDesc() {
        return this.protectDesc;
    }

    public String getBssid() {
        return this.bssid;
    }

    public int getFrequency() {
        return this.frequency;
    }

    public double getSignalLevel() {
        return (double) this.signalLevel;
    }

    public int getFlags() {
        return this.flags;
    }

    public String getSsid() {
        return this.ssid;
    }

    public int compareTo(Object another) {
        WifiInfo info = (WifiInfo) another;
        if (this.signalLevel == info.signalLevel) {
            if (this.flags == info.flags) {
                if (this.ssid.compareToIgnoreCase(info.getSsid()) > 0) {
                    return -1;
                }
                return 1;
            } else if (this.flags <= info.getFlags()) {
                return 1;
            } else {
                return -1;
            }
        } else if (((double) this.signalLevel) <= info.getSignalLevel()) {
            return 1;
        } else {
            return -1;
        }
    }
}
