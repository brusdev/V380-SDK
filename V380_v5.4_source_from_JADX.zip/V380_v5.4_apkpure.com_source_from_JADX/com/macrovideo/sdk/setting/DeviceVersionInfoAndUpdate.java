package com.macrovideo.sdk.setting;

import android.support.v4.media.TransportMediator;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.LocalDefines;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Arrays;

public class DeviceVersionInfoAndUpdate {
    private static final int COMMUNICATIONS_BUFFER_SIZE = 412;
    private static final int MR_COMMUNICATIONS_BUFFER_SIZE = 256;
    private static final int SERVER_RETURN_BUFFER_SIZE = 412;
    private static byte[] buffer = new byte[412];

    public static VersionInfoAndUpdateInfo getVersionInfo(DeviceInfo device) {
        VersionInfoAndUpdateInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                VersionInfoAndUpdateInfo deviceParams = new VersionInfoAndUpdateInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = getVersionInfoServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = getVersionInfoMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        return deviceParam;
    }

    public static VersionInfoAndUpdateInfo getVersionUpdate(DeviceInfo device) {
        VersionInfoAndUpdateInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                VersionInfoAndUpdateInfo deviceParams = new VersionInfoAndUpdateInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = getVersionUpdateServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = getVersionUpdateMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        return deviceParam;
    }

    public static VersionInfoAndUpdateInfo setVersionUpdate(DeviceInfo device) {
        VersionInfoAndUpdateInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                VersionInfoAndUpdateInfo deviceParams = new VersionInfoAndUpdateInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = setVerionUpdateServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = setVersionUpdateMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        return deviceParam;
    }

    private static VersionInfoAndUpdateInfo setVerionUpdateServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        VersionInfoAndUpdateInfo versionInfoAndUpdateHandler = new VersionInfoAndUpdateInfo();
        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("set server  IP:" + strIP + " Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 128, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        Functions.IntToBytes((long) nDeviceID, buffer, 68);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 228) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                versionInfoAndUpdateHandler.setnResult(1021);
                                int len = 0;
                                while (len < 4 && ((char) buffer[len + 8]) != '\u0000') {
                                    len++;
                                }
                                byte[] deviceResultFunction = new byte[len];
                                Arrays.fill(deviceResultFunction, (byte) 0);
                                System.arraycopy(buffer, 8, deviceResultFunction, 0, len);
                                String str = new String(deviceResultFunction);
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return versionInfoAndUpdateHandler;
    }

    private static VersionInfoAndUpdateInfo setVersionUpdateMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        VersionInfoAndUpdateInfo versionInfoAndUpdateHandler = new VersionInfoAndUpdateInfo();
        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("MR set server IP:" + strMRServerIP + " Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 128, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 228) {
                                Functions.changeMRParam(nDeviceID, true);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                versionInfoAndUpdateHandler.setnResult(1021);
                                int len = 0;
                                while (len < 4 && ((char) buffer[len + 8]) != '\u0000') {
                                    len++;
                                }
                                byte[] deviceResultFunction = new byte[len];
                                Arrays.fill(deviceResultFunction, (byte) 0);
                                System.arraycopy(buffer, 8, deviceResultFunction, 0, len);
                                String str = new String(deviceResultFunction);
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return versionInfoAndUpdateHandler;
    }

    private static VersionInfoAndUpdateInfo getVersionInfoServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        VersionInfoAndUpdateInfo versionInfoAndUpdateHandler = new VersionInfoAndUpdateInfo();
        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("get server IP:" + strIP + " Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_VERSION_INFO_GET_REQUEST, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        Functions.IntToBytes((long) nDeviceID, buffer, 68);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 219) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                versionInfoAndUpdateHandler.setnResult(256);
                                int len = 0;
                                while (len < 64 && ((char) buffer[len + 8]) != '\u0000') {
                                    len++;
                                }
                                byte[] appVersion = new byte[len];
                                Arrays.fill(appVersion, (byte) 0);
                                System.arraycopy(buffer, 8, appVersion, 0, len);
                                versionInfoAndUpdateHandler.setStrAPPVersion(new String(appVersion));
                                len = 0;
                                while (len < 10 && ((char) buffer[len + 72]) != '\u0000') {
                                    len++;
                                }
                                byte[] appVersionDate = new byte[len];
                                Arrays.fill(appVersionDate, (byte) 0);
                                System.arraycopy(buffer, 72, appVersionDate, 0, len);
                                versionInfoAndUpdateHandler.setStrAPPVersionDate(new String(appVersionDate));
                                len = 0;
                                while (len < 64 && ((char) buffer[len + 82]) != '\u0000') {
                                    len++;
                                }
                                Object kerVersion = new byte[len];
                                Arrays.fill(kerVersion, (byte) 0);
                                System.arraycopy(buffer, 82, kerVersion, 0, len);
                                versionInfoAndUpdateHandler.setStrKelVersion(new String(kerVersion));
                                len = 0;
                                while (len < 10 && ((char) buffer[len + 146]) != '\u0000') {
                                    len++;
                                }
                                Object kerVersionDate = new byte[len];
                                Arrays.fill(kerVersionDate, (byte) 0);
                                System.arraycopy(buffer, 146, kerVersionDate, 0, len);
                                versionInfoAndUpdateHandler.setStrKelVersionDate(new String(kerVersionDate));
                                len = 0;
                                while (len < 64 && ((char) buffer[len + Defines.REC_FILE_GET_DATA_ACK]) != '\u0000') {
                                    len++;
                                }
                                byte[] hwVersion = new byte[len];
                                Arrays.fill(hwVersion, (byte) 0);
                                System.arraycopy(buffer, Defines.REC_FILE_GET_DATA_ACK, hwVersion, 0, len);
                                versionInfoAndUpdateHandler.setStrHWVersion(new String(hwVersion));
                                len = 0;
                                while (len < 10 && ((char) buffer[len + Defines.NV_IPC_WIFI_SELECT_RESPONSE]) != '\u0000') {
                                    len++;
                                }
                                byte[] hwVersionDate = new byte[len];
                                Arrays.fill(hwVersionDate, (byte) 0);
                                System.arraycopy(buffer, Defines.NV_IPC_WIFI_SELECT_RESPONSE, hwVersionDate, 0, len);
                                versionInfoAndUpdateHandler.setStrHWVersionDate(new String(hwVersionDate));
                                versionInfoAndUpdateHandler.setnDeviceVersionUpdateInformation(Functions.BytesToInt(buffer, LocalDefines.NV_IP_ALARM_DEVICE_LIST_RESPONSE));
                                versionInfoAndUpdateHandler.setnDeviceVersionUpdate(Functions.BytesToInt(buffer, LocalDefines.NV_IP_ALARM_DEVICE_SEARCH_RESPONSE));
                                len = 0;
                                while (len < 32 && ((char) buffer[len + 235]) != '\u0000') {
                                    len++;
                                }
                                byte[] deviceNewVersionName = new byte[len];
                                Arrays.fill(deviceNewVersionName, (byte) 0);
                                System.arraycopy(buffer, 235, deviceNewVersionName, 0, len);
                                versionInfoAndUpdateHandler.setStrDeviceNewVersionName(new String(deviceNewVersionName));
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e6) {
                                    e6.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return versionInfoAndUpdateHandler;
    }

    private static VersionInfoAndUpdateInfo getVersionInfoMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        VersionInfoAndUpdateInfo versionInfoAndUpdateHandler = new VersionInfoAndUpdateInfo();
        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("MR get server IP:" + strMRServerIP + " Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_VERSION_INFO_GET_REQUEST, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 219) {
                                Functions.changeMRParam(nDeviceID, true);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                versionInfoAndUpdateHandler.setnResult(256);
                                int len = 0;
                                while (len < 64 && ((char) buffer[len + 8]) != '\u0000') {
                                    len++;
                                }
                                byte[] appVersion = new byte[len];
                                Arrays.fill(appVersion, (byte) 0);
                                System.arraycopy(buffer, 8, appVersion, 0, len);
                                versionInfoAndUpdateHandler.setStrAPPVersion(new String(appVersion));
                                len = 0;
                                while (len < 10 && ((char) buffer[len + 72]) != '\u0000') {
                                    len++;
                                }
                                byte[] appVersionDate = new byte[len];
                                Arrays.fill(appVersionDate, (byte) 0);
                                System.arraycopy(buffer, 72, appVersionDate, 0, len);
                                versionInfoAndUpdateHandler.setStrAPPVersionDate(new String(appVersionDate));
                                len = 0;
                                while (len < 64 && ((char) buffer[len + 82]) != '\u0000') {
                                    len++;
                                }
                                Object kerVersion = new byte[len];
                                Arrays.fill(kerVersion, (byte) 0);
                                System.arraycopy(buffer, 82, kerVersion, 0, len);
                                versionInfoAndUpdateHandler.setStrKelVersion(new String(kerVersion));
                                len = 0;
                                while (len < 10 && ((char) buffer[len + 146]) != '\u0000') {
                                    len++;
                                }
                                Object kerVersionDate = new byte[len];
                                Arrays.fill(kerVersionDate, (byte) 0);
                                System.arraycopy(buffer, 146, kerVersionDate, 0, len);
                                versionInfoAndUpdateHandler.setStrKelVersionDate(new String(kerVersionDate));
                                len = 0;
                                while (len < 64 && ((char) buffer[len + Defines.REC_FILE_GET_DATA_ACK]) != '\u0000') {
                                    len++;
                                }
                                byte[] hwVersion = new byte[len];
                                Arrays.fill(hwVersion, (byte) 0);
                                System.arraycopy(buffer, Defines.REC_FILE_GET_DATA_ACK, hwVersion, 0, len);
                                versionInfoAndUpdateHandler.setStrHWVersion(new String(hwVersion));
                                len = 0;
                                while (len < 10 && ((char) buffer[len + Defines.NV_IPC_WIFI_SELECT_RESPONSE]) != '\u0000') {
                                    len++;
                                }
                                byte[] hwVersionDate = new byte[len];
                                Arrays.fill(hwVersionDate, (byte) 0);
                                System.arraycopy(buffer, Defines.NV_IPC_WIFI_SELECT_RESPONSE, hwVersionDate, 0, len);
                                versionInfoAndUpdateHandler.setStrHWVersionDate(new String(hwVersionDate));
                                versionInfoAndUpdateHandler.setnDeviceVersionUpdateInformation(Functions.BytesToInt(buffer, LocalDefines.NV_IP_ALARM_DEVICE_LIST_RESPONSE));
                                versionInfoAndUpdateHandler.setnDeviceVersionUpdate(Functions.BytesToInt(buffer, LocalDefines.NV_IP_ALARM_DEVICE_SEARCH_RESPONSE));
                                len = 0;
                                while (len < 32 && ((char) buffer[len + 235]) != '\u0000') {
                                    len++;
                                }
                                byte[] deviceNewVersionName = new byte[len];
                                Arrays.fill(deviceNewVersionName, (byte) 0);
                                System.arraycopy(buffer, 235, deviceNewVersionName, 0, len);
                                versionInfoAndUpdateHandler.setStrDeviceNewVersionName(new String(deviceNewVersionName));
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e6) {
                                    e6.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return versionInfoAndUpdateHandler;
    }

    private static VersionInfoAndUpdateInfo getVersionUpdateServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        VersionInfoAndUpdateInfo versionInfoAndUpdateHandler = new VersionInfoAndUpdateInfo();
        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("get server IP:" + strIP + " Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 127, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        Functions.IntToBytes((long) nDeviceID, buffer, 68);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd != 227) {
                                switch (Functions.BytesToInt(buffer, 8)) {
                                    case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                        break;
                                    default:
                                        break;
                                }
                            }
                            Functions.changeMRParam(nDeviceID, false);
                            if (nResultValue == 1019) {
                                versionInfoAndUpdateHandler.setnResult(Defines.NV_RESULT_NO_NEW_VERSION);
                            } else if (nResultValue == 1020) {
                                versionInfoAndUpdateHandler.setnResult(Defines.NV_RESULT_NET_NO_SUPORT);
                            } else {
                                versionInfoAndUpdateHandler.setnResult(256);
                            }
                            versionInfoAndUpdateHandler.setnOldVersionNum(Functions.BytesToInt(buffer, 8));
                            int len = 0;
                            while (len < 32 && ((char) buffer[len + 12]) != '\u0000') {
                                len++;
                            }
                            Object oldVersionName = new byte[len];
                            Arrays.fill(oldVersionName, (byte) 0);
                            System.arraycopy(buffer, 12, oldVersionName, 0, len);
                            versionInfoAndUpdateHandler.setStrOldVersionName(new String(oldVersionName));
                            len = 0;
                            while (len < 20 && ((char) buffer[len + 44]) != '\u0000') {
                                len++;
                            }
                            Object oldUpdateData = new byte[len];
                            Arrays.fill(oldUpdateData, (byte) 0);
                            System.arraycopy(buffer, 44, oldUpdateData, 0, len);
                            versionInfoAndUpdateHandler.setStrOldVersionUpdateTime(new String(oldUpdateData));
                            versionInfoAndUpdateHandler.setnNewVersionNum(Functions.BytesToInt(buffer, 64));
                            len = 0;
                            while (len < 32 && ((char) buffer[len + 68]) != '\u0000') {
                                len++;
                            }
                            Object newVersionName = new byte[len];
                            Arrays.fill(newVersionName, (byte) 0);
                            System.arraycopy(buffer, 68, newVersionName, 0, len);
                            versionInfoAndUpdateHandler.setStrNewVersionName(new String(newVersionName));
                            len = 0;
                            while (len < 20 && ((char) buffer[len + 100]) != '\u0000') {
                                len++;
                            }
                            Object newUpdateData = new byte[len];
                            Arrays.fill(newUpdateData, (byte) 0);
                            System.arraycopy(buffer, 100, newUpdateData, 0, len);
                            versionInfoAndUpdateHandler.setStrNewVersionUpdateTime(new String(newUpdateData));
                            len = 0;
                            while (len < 64 && ((char) buffer[len + 120]) != '\u0000') {
                                len++;
                            }
                            Object newFunction = new byte[len];
                            Arrays.fill(newFunction, (byte) 0);
                            System.arraycopy(buffer, 120, newFunction, 0, len);
                            versionInfoAndUpdateHandler.setStrNewVersionFunction(new String(newFunction));
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return versionInfoAndUpdateHandler;
    }

    private static VersionInfoAndUpdateInfo getVersionUpdateMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        VersionInfoAndUpdateInfo versionInfoAndUpdateHandler = new VersionInfoAndUpdateInfo();
        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        System.out.println("MR get server IP:" + strMRServerIP + " Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 5000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) 127, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (int i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd != 227) {
                                switch (Functions.BytesToInt(buffer, 8)) {
                                    case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                        break;
                                    case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                        versionInfoAndUpdateHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                        break;
                                    default:
                                        break;
                                }
                            }
                            Functions.changeMRParam(nDeviceID, true);
                            if (nResultValue == 1019) {
                                versionInfoAndUpdateHandler.setnResult(Defines.NV_RESULT_NO_NEW_VERSION);
                            } else if (nResultValue == 1020) {
                                versionInfoAndUpdateHandler.setnResult(Defines.NV_RESULT_NET_NO_SUPORT);
                            } else {
                                versionInfoAndUpdateHandler.setnResult(256);
                            }
                            versionInfoAndUpdateHandler.setnOldVersionNum(Functions.BytesToInt(buffer, 8));
                            int len = 0;
                            while (len < 32 && ((char) buffer[len + 12]) != '\u0000') {
                                len++;
                            }
                            Object oldVersionName = new byte[len];
                            Arrays.fill(oldVersionName, (byte) 0);
                            System.arraycopy(buffer, 12, oldVersionName, 0, len);
                            versionInfoAndUpdateHandler.setStrOldVersionName(new String(oldVersionName));
                            len = 0;
                            while (len < 20 && ((char) buffer[len + 44]) != '\u0000') {
                                len++;
                            }
                            Object oldUpdateData = new byte[len];
                            Arrays.fill(oldUpdateData, (byte) 0);
                            System.arraycopy(buffer, 44, oldUpdateData, 0, len);
                            versionInfoAndUpdateHandler.setStrOldVersionUpdateTime(new String(oldUpdateData));
                            versionInfoAndUpdateHandler.setnNewVersionNum(Functions.BytesToInt(buffer, 64));
                            len = 0;
                            while (len < 32 && ((char) buffer[len + 68]) != '\u0000') {
                                len++;
                            }
                            Object newVersionName = new byte[len];
                            Arrays.fill(newVersionName, (byte) 0);
                            System.arraycopy(buffer, 68, newVersionName, 0, len);
                            versionInfoAndUpdateHandler.setStrNewVersionName(new String(newVersionName));
                            len = 0;
                            while (len < 20 && ((char) buffer[len + 100]) != '\u0000') {
                                len++;
                            }
                            Object newUpdateData = new byte[len];
                            Arrays.fill(newUpdateData, (byte) 0);
                            System.arraycopy(buffer, 100, newUpdateData, 0, len);
                            versionInfoAndUpdateHandler.setStrNewVersionUpdateTime(new String(newUpdateData));
                            len = 0;
                            while (len < 64 && ((char) buffer[len + 120]) != '\u0000') {
                                len++;
                            }
                            Object newFunction = new byte[len];
                            Arrays.fill(newFunction, (byte) 0);
                            System.arraycopy(buffer, 120, newFunction, 0, len);
                            versionInfoAndUpdateHandler.setStrNewVersionFunction(new String(newFunction));
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return versionInfoAndUpdateHandler;
    }
}
