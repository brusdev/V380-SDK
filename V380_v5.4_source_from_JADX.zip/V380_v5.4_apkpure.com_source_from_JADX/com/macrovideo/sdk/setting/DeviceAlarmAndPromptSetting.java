package com.macrovideo.sdk.setting;

import android.support.v4.media.TransportMediator;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.LocalDefines;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DeviceAlarmAndPromptSetting {
    private static final int COMMUNICATIONS_BUFFER_SIZE = 412;
    private static final int MR_COMMUNICATIONS_BUFFER_SIZE = 256;
    private static final int SERVER_RETURN_BUFFER_SIZE = 412;
    public static ArrayList<Integer> ServerAlarmAreaList = new ArrayList();
    private static byte[] buffer = new byte[412];

    public static AlarmAndPromptInfo getAlarmAndPropmt(DeviceInfo device) {
        AlarmAndPromptInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                AlarmAndPromptInfo deviceParams = new AlarmAndPromptInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = getAlarmAndPropmtServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = getAlarmAndPromptMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        return deviceParam;
    }

    public static int setOneKeyAlarmSetting(DeviceInfo device, boolean isAlarm) {
        int nResult = 0;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                return 0;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                nResult = setOneKeyAlarmSetServer(device, isAlarm);
            }
            if (nResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                nResult = setOneKeyAlarmSetMRServer(device, isAlarm);
            }
        }
        return nResult;
    }

    public static AlarmAndPromptInfo setAlarmAndPropmt(DeviceInfo device, boolean hasAlarmConfig, boolean bMainAlarmSwitch, boolean hasVoicePromptsConfig, boolean bAlarmVoiceSwitch, boolean bVoicePromptsMainSwitch, int nLanguage, boolean hasExIOConfig, int nIOMode, boolean bMotionAlarmSwitch, int timeArea, int ntimequantum, int alarmswitch1, int starthour1, int startmin1, int startsec1, int endhour1, int endmin1, int endsec1, int alarmswitch2, int starthour2, int startmin2, int startsec2, int endhour2, int endmin2, int endsec2, int alarmswitch3, int starthour3, int startmin3, int startsec3, int endhour3, int endmin3, int endsec3, List alarmArea) {
        AlarmAndPromptInfo deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                AlarmAndPromptInfo deviceParams = new AlarmAndPromptInfo();
                deviceParams.setnResult(ResultCode.RESULE_CODE_FAIL_USER_NULL);
                return deviceParams;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = setAlarmAndPromptServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID(), hasAlarmConfig, bMainAlarmSwitch, hasVoicePromptsConfig, bAlarmVoiceSwitch, bVoicePromptsMainSwitch, nLanguage, hasExIOConfig, nIOMode, bMotionAlarmSwitch, timeArea, ntimequantum, alarmswitch1, starthour1, startmin1, startsec1, endhour1, endmin1, endsec1, alarmswitch2, starthour2, startmin2, startsec2, endhour2, endmin2, endsec2, alarmswitch3, starthour3, startmin3, startsec3, endhour3, endmin3, endsec3, alarmArea);
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
                deviceParam = setAlarmAndPromptMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID(), hasAlarmConfig, bMainAlarmSwitch, hasVoicePromptsConfig, bAlarmVoiceSwitch, bVoicePromptsMainSwitch, nLanguage, hasExIOConfig, nIOMode, bMotionAlarmSwitch, timeArea, ntimequantum, alarmswitch1, starthour1, startmin1, startsec1, endhour1, endmin1, endsec1, alarmswitch2, starthour2, startmin2, startsec2, endhour2, endmin2, endsec2, alarmswitch3, starthour3, startmin3, startsec3, endhour3, endmin3, endsec3, alarmArea);
            }
        }
        return deviceParam;
    }

    private static AlarmAndPromptInfo setAlarmAndPromptServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID, boolean hasAlarmConfig, boolean bMainAlarmSwitch, boolean hasVoicePromptsConfig, boolean bAlarmVoiceSwitch, boolean bVoicePromptsMainSwitch, int nLanguage, boolean hasExIOConfig, int nIOMode, boolean bMotionAlarmSwitch, int timeArea, int ntimequantum, int alarmswitch1, int starthour1, int startmin1, int startsec1, int endhour1, int endmin1, int endsec1, int alarmswitch2, int starthour2, int startmin2, int startsec2, int endhour2, int endmin2, int endsec2, int alarmswitch3, int starthour3, int startmin3, int startsec3, int endhour3, int endmin3, int endsec3, List<Integer> alarmArea) {
        OutputStream writer = null;
        InputStream reader = null;
        AlarmAndPromptInfo alarmAndPromptHandler = new AlarmAndPromptInfo();
        alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        int i;
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IP_SWITCH_SET_REQUEST, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        if (hasVoicePromptsConfig) {
                            Functions.IntToBytes(1000, buffer, 68);
                            if (bVoicePromptsMainSwitch) {
                                Functions.IntToBytes(1000, buffer, 72);
                            } else {
                                Functions.IntToBytes(1001, buffer, 72);
                            }
                            if (bAlarmVoiceSwitch) {
                                Functions.IntToBytes(1000, buffer, 76);
                            } else {
                                Functions.IntToBytes(1001, buffer, 76);
                            }
                            Functions.IntToBytes((long) nLanguage, buffer, 80);
                        } else {
                            Functions.IntToBytes(1001, buffer, 68);
                        }
                        if (hasExIOConfig) {
                            Functions.IntToBytes(1000, buffer, 84);
                            Functions.IntToBytes((long) nIOMode, buffer, 88);
                        } else {
                            Functions.IntToBytes(1001, buffer, 84);
                        }
                        if (hasAlarmConfig) {
                            Functions.IntToBytes(1000, buffer, 92);
                            if (bMainAlarmSwitch) {
                                Functions.IntToBytes(1000, buffer, 96);
                            } else {
                                Functions.IntToBytes(1001, buffer, 96);
                            }
                        } else {
                            Functions.IntToBytes(1001, buffer, 92);
                        }
                        if (bMotionAlarmSwitch) {
                            Functions.IntToBytes(1000, buffer, 100);
                        } else {
                            Functions.IntToBytes(1001, buffer, 100);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, 112);
                        buffer[Defines.NV_IPC_TIME_SET_REQUEST] = (byte) 1;
                        buffer[Defines.NV_IPC_USERINFO_GET_REQUEST] = (byte) ntimequantum;
                        buffer[Defines.NV_IPC_USERINFO_SET_REQUEST] = (byte) alarmswitch1;
                        buffer[Defines.NV_IPC_VERSION_INFO_GET_REQUEST] = (byte) starthour1;
                        buffer[120] = (byte) startmin1;
                        buffer[Defines.NV_IP_SWITCH_GET_REQUEST] = (byte) startsec1;
                        buffer[Defines.NV_IP_SWITCH_SET_REQUEST] = (byte) endhour1;
                        buffer[123] = (byte) endmin1;
                        buffer[124] = (byte) endsec1;
                        buffer[125] = (byte) alarmswitch2;
                        buffer[TransportMediator.KEYCODE_MEDIA_PLAY] = (byte) starthour2;
                        buffer[127] = (byte) startmin2;
                        buffer[128] = (byte) startsec2;
                        buffer[Defines.NV_IP_PTZX_REQUEST] = (byte) endhour2;
                        buffer[130] = (byte) endmin2;
                        buffer[LocalDefines.NV_IP_ALARM_DEVICE_SEARCH_REQUEST] = (byte) endsec2;
                        buffer[LocalDefines.NV_IP_ALARM_DEVICE_ADD_REQUEST] = (byte) alarmswitch3;
                        buffer[LocalDefines.NV_IP_ALARM_DEVICE_MODIFY_REQUEST] = (byte) starthour3;
                        buffer[LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST] = (byte) startmin3;
                        buffer[135] = (byte) startsec3;
                        buffer[Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_REQUEST] = (byte) endhour3;
                        buffer[Defines.NV_IPC_CUSTOM_TRANSPORT_FREE_REQUEST] = (byte) endmin3;
                        buffer[Defines.NV_IPC_CUSTOM_TRANSPORT_SEND_REQUEST] = (byte) endsec3;
                        for (i = 0; i < alarmArea.size(); i++) {
                            buffer[i + Defines.NV_IPC_CUSTOM_TRANSPORT_RECV_REQUEST] = (byte) ((Integer) alarmArea.get(i)).intValue();
                        }
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            if (nResultCmd == 222) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL);
                                            break;
                                    }
                                }
                                alarmAndPromptHandler.setnResult(256);
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return alarmAndPromptHandler;
    }

    private static AlarmAndPromptInfo setAlarmAndPromptMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID, boolean hasAlarmConfig, boolean bMainAlarmSwitch, boolean hasVoicePromptsConfig, boolean bAlarmVoiceSwitch, boolean bVoicePromptsMainSwitch, int nLanguage, boolean hasExIOConfig, int nIOMode, boolean bMotionAlarmSwitch, int timeArea, int ntimequantum, int alarmswitch1, int starthour1, int startmin1, int startsec1, int endhour1, int endmin1, int endsec1, int alarmswitch2, int starthour2, int startmin2, int startsec2, int endhour2, int endmin2, int endsec2, int alarmswitch3, int starthour3, int startmin3, int startsec3, int endhour3, int endmin3, int endsec3, List<Integer> alarmArea) {
        OutputStream writer = null;
        InputStream reader = null;
        AlarmAndPromptInfo alarmAndPromptHandler = new AlarmAndPromptInfo();
        alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        int i;
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IP_SWITCH_SET_REQUEST, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        if (hasVoicePromptsConfig) {
                            Functions.IntToBytes(1000, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                            if (bVoicePromptsMainSwitch) {
                                Functions.IntToBytes(1000, buffer, 130);
                            } else {
                                Functions.IntToBytes(1001, buffer, 130);
                            }
                            if (bAlarmVoiceSwitch) {
                                Functions.IntToBytes(1000, buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST);
                            } else {
                                Functions.IntToBytes(1001, buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST);
                            }
                            Functions.IntToBytes((long) nLanguage, buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_SEND_REQUEST);
                        } else {
                            Functions.IntToBytes(1001, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        }
                        if (hasExIOConfig) {
                            Functions.IntToBytes(1000, buffer, Defines.NV_IPC_IP_CONFIG_GET_REQUEST);
                            Functions.IntToBytes((long) nIOMode, buffer, 146);
                        } else {
                            Functions.IntToBytes(1001, buffer, Defines.NV_IPC_IP_CONFIG_GET_REQUEST);
                        }
                        if (hasAlarmConfig) {
                            Functions.IntToBytes(1000, buffer, Defines.REC_FILE_SEARCH);
                            if (bMainAlarmSwitch) {
                                Functions.IntToBytes(1000, buffer, Defines.CMD_LOGIN_EX);
                            } else {
                                Functions.IntToBytes(1001, buffer, Defines.CMD_LOGIN_EX);
                            }
                            if (bMotionAlarmSwitch) {
                                Functions.IntToBytes(1000, buffer, Defines.REC_FILE_PLAYBACK_GET_DATA);
                            } else {
                                Functions.IntToBytes(1001, buffer, Defines.REC_FILE_PLAYBACK_GET_DATA);
                            }
                        } else {
                            Functions.IntToBytes(1001, buffer, Defines.REC_FILE_SEARCH);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, Defines.NV_IPC_PTZ__REQUEST);
                        buffer[174] = (byte) 1;
                        buffer[175] = (byte) ntimequantum;
                        buffer[176] = (byte) alarmswitch1;
                        buffer[177] = (byte) starthour1;
                        buffer[178] = (byte) startmin1;
                        buffer[179] = (byte) startsec1;
                        buffer[180] = (byte) endhour1;
                        buffer[181] = (byte) endmin1;
                        buffer[182] = (byte) endsec1;
                        buffer[183] = (byte) alarmswitch2;
                        buffer[184] = (byte) starthour2;
                        buffer[185] = (byte) startmin2;
                        buffer[186] = (byte) startsec2;
                        buffer[187] = (byte) endhour2;
                        buffer[188] = (byte) endmin2;
                        buffer[189] = (byte) endsec2;
                        buffer[190] = (byte) alarmswitch3;
                        buffer[191] = (byte) starthour3;
                        buffer[192] = (byte) startmin3;
                        buffer[193] = (byte) startsec3;
                        buffer[194] = (byte) endhour3;
                        buffer[195] = (byte) endmin3;
                        buffer[196] = (byte) endsec3;
                        for (i = 0; i < alarmArea.size(); i++) {
                            buffer[i + 197] = (byte) ((Integer) alarmArea.get(i)).intValue();
                        }
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        for (i = 0; i < 5; i++) {
                            if (reader.available() >= 412) {
                                reader.read(buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e5) {
                                try {
                                    e5.printStackTrace();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            int nResultDesc = Functions.BytesToInt(buffer, 8);
                            if (nResultCmd == 222) {
                                Functions.changeMRParam(nDeviceID, true);
                                if (nResultValue != 1001) {
                                    switch (nResultDesc) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL);
                                            break;
                                    }
                                }
                                alarmAndPromptHandler.setnResult(256);
                            }
                        }
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (reader != null) {
                            reader.close();
                        }
                        if (sSocket != null) {
                            sSocket.close();
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return alarmAndPromptHandler;
    }

    private static AlarmAndPromptInfo getAlarmAndPropmtServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        ArrayList<Integer> alarmarea = new ArrayList();
        AlarmAndPromptInfo alarmAndPromptHandler = new AlarmAndPromptInfo();
        alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IP_SWITCH_GET_REQUEST, buffer, 0);
                        System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                        System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                        Functions.IntToBytes((long) nDeviceID, buffer, 68);
                        try {
                            writer.write(buffer, 0, 412);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 221) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL);
                                            break;
                                    }
                                }
                                alarmAndPromptHandler.setnResult(256);
                                int nHasVoicePromptsConfig = Functions.BytesToInt(buffer, 8);
                                int nVoicePromptsMainSwitch = Functions.BytesToInt(buffer, 12);
                                int nAlarmVoiceSwitch = Functions.BytesToInt(buffer, 16);
                                int nVLanguage = Functions.BytesToInt(buffer, 20);
                                int nHasExIOConfig = Functions.BytesToInt(buffer, 24);
                                int nExIOMode = Functions.BytesToInt(buffer, 28);
                                int nHasAlarmConfig = Functions.BytesToInt(buffer, 32);
                                int nMainAlarmSwitch = Functions.BytesToInt(buffer, 36);
                                int nMotionAlarmSwitch = Functions.BytesToInt(buffer, 40);
                                int nPIRAlarmSwitch = Functions.BytesToInt(buffer, 44);
                                int nSmokeAlarmSwitch = Functions.BytesToInt(buffer, 48);
                                int ntimeArea = buffer[52];
                                int ntimequantum = buffer[53];
                                int alarmswitch1 = buffer[54];
                                int starthour1 = buffer[55];
                                int startmin1 = buffer[56];
                                int startsec1 = buffer[57];
                                int endhour1 = buffer[58];
                                int endmin1 = buffer[59];
                                int endsec1 = buffer[60];
                                int alarmswitch2 = buffer[61];
                                int starthour2 = buffer[62];
                                int startmin2 = buffer[63];
                                int startsec2 = buffer[64];
                                int endhour2 = buffer[65];
                                int endmin2 = buffer[66];
                                int endsec2 = buffer[67];
                                int alarmswitch3 = buffer[68];
                                int starthour3 = buffer[69];
                                int startmin3 = buffer[70];
                                int startsec3 = buffer[71];
                                int endhour3 = buffer[72];
                                int endmin3 = buffer[73];
                                int endsec3 = buffer[74];
                                int alarmrows = buffer[75];
                                int alarmcolumns = buffer[76];
                                for (i = 77; i < (alarmrows * alarmcolumns) + 77; i++) {
                                    alarmarea.add(i - 77, Integer.valueOf(buffer[i]));
                                }
                                ServerAlarmAreaList = alarmarea;
                                alarmAndPromptHandler.setCanSetTime(ntimeArea);
                                alarmAndPromptHandler.setAlarmcolumns(alarmcolumns);
                                alarmAndPromptHandler.setAlarmrows(alarmrows);
                                alarmAndPromptHandler.setServerAlarmSwitch1(alarmswitch1);
                                alarmAndPromptHandler.setServerAlarmSwitch2(alarmswitch2);
                                alarmAndPromptHandler.setServerAlarmSwitch3(alarmswitch3);
                                alarmAndPromptHandler.setStarthour1(starthour1);
                                alarmAndPromptHandler.setStarthour2(starthour2);
                                alarmAndPromptHandler.setStarthour3(starthour3);
                                alarmAndPromptHandler.setStartmin1(startmin1);
                                alarmAndPromptHandler.setStartmin2(startmin2);
                                alarmAndPromptHandler.setStartmin3(startmin3);
                                alarmAndPromptHandler.setStartsec1(startsec1);
                                alarmAndPromptHandler.setStartsec2(startsec2);
                                alarmAndPromptHandler.setStartsec3(startsec3);
                                alarmAndPromptHandler.setEndhour1(endhour1);
                                alarmAndPromptHandler.setEndhour2(endhour2);
                                alarmAndPromptHandler.setEndhour3(endhour3);
                                alarmAndPromptHandler.setEndmin1(endmin1);
                                alarmAndPromptHandler.setEndmin2(endmin2);
                                alarmAndPromptHandler.setEndmin3(endmin3);
                                alarmAndPromptHandler.setEndsec1(endsec1);
                                alarmAndPromptHandler.setEndsec2(endsec2);
                                alarmAndPromptHandler.setEndsec3(endsec3);
                                if (nHasVoicePromptsConfig == 1000) {
                                    alarmAndPromptHandler.setHasVoicePromptsConfig(true);
                                } else {
                                    alarmAndPromptHandler.setHasVoicePromptsConfig(false);
                                }
                                if (nVoicePromptsMainSwitch == 1000) {
                                    alarmAndPromptHandler.setbVoicePromptsMainSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbVoicePromptsMainSwitch(false);
                                }
                                if (nAlarmVoiceSwitch == 1000) {
                                    alarmAndPromptHandler.setbAlarmVoiceSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbAlarmVoiceSwitch(false);
                                }
                                if (nHasExIOConfig == 1000) {
                                    alarmAndPromptHandler.setHasExIOConfig(true);
                                } else {
                                    alarmAndPromptHandler.setHasExIOConfig(false);
                                }
                                alarmAndPromptHandler.setnLanguage(nVLanguage);
                                alarmAndPromptHandler.setnIOMode(nExIOMode);
                                if (nHasAlarmConfig == 1000) {
                                    alarmAndPromptHandler.setHasAlarmConfig(true);
                                } else {
                                    alarmAndPromptHandler.setHasAlarmConfig(false);
                                }
                                if (nMainAlarmSwitch == 1000) {
                                    alarmAndPromptHandler.setbMainAlarmSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbMainAlarmSwitch(false);
                                }
                                if (nMotionAlarmSwitch == 1000) {
                                    alarmAndPromptHandler.setbMotionAlarmSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbMotionAlarmSwitch(false);
                                }
                                if (nPIRAlarmSwitch == 1000) {
                                    alarmAndPromptHandler.setbPIRAlarmSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbPIRAlarmSwitch(false);
                                }
                                if (nSmokeAlarmSwitch == 1000) {
                                    alarmAndPromptHandler.setbSmokeAlarmSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbSmokeAlarmSwitch(false);
                                }
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e6) {
                                    e6.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return alarmAndPromptHandler;
    }

    private static AlarmAndPromptInfo getAlarmAndPromptMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        ArrayList<Integer> alarmarea = new ArrayList();
        AlarmAndPromptInfo alarmAndPromptHandler = new AlarmAndPromptInfo();
        alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket != null) {
            boolean isConnectOK;
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                    if (isConnectOK) {
                        Arrays.fill(buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IP_SWITCH_GET_REQUEST, buffer, 0);
                        Functions.IntToBytes(1002, buffer, 4);
                        if (strDomain != null) {
                            System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                        }
                        Functions.IntToBytes((long) nPort, buffer, 58);
                        if (strUsername != null) {
                            System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                        }
                        if (strPassword != null) {
                            System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                        }
                        Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                        try {
                            writer.write(buffer, 0, 256);
                            writer.flush();
                        } catch (IOException e) {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e2) {
                                }
                            }
                            writer = null;
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e3) {
                                }
                            }
                            reader = null;
                            if (sSocket != null) {
                                try {
                                    sSocket.close();
                                } catch (IOException e4) {
                                }
                            }
                            sSocket = null;
                        }
                        Arrays.fill(buffer, (byte) 0);
                        boolean bReadOK = false;
                        int i = 0;
                        while (i < 5) {
                            try {
                                if (reader.available() >= 412) {
                                    reader.read(buffer, 0, 412);
                                    bReadOK = true;
                                    break;
                                }
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e5) {
                                    e5.printStackTrace();
                                }
                                i++;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                        }
                        if (bReadOK) {
                            int nResultCmd = Functions.BytesToInt(buffer, 0);
                            int nResultValue = Functions.BytesToInt(buffer, 4);
                            if (nResultCmd == 221) {
                                Functions.changeMRParam(nDeviceID, false);
                                if (nResultValue != 1001) {
                                    switch (Functions.BytesToInt(buffer, 8)) {
                                        case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                            break;
                                        case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                            break;
                                        default:
                                            alarmAndPromptHandler.setnResult(ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL);
                                            break;
                                    }
                                }
                                alarmAndPromptHandler.setnResult(256);
                                int nHasVoicePromptsConfig = Functions.BytesToInt(buffer, 8);
                                int nVoicePromptsMainSwitch = Functions.BytesToInt(buffer, 12);
                                int nAlarmVoiceSwitch = Functions.BytesToInt(buffer, 16);
                                int nVLanguage = Functions.BytesToInt(buffer, 20);
                                int nHasExIOConfig = Functions.BytesToInt(buffer, 24);
                                int nExIOMode = Functions.BytesToInt(buffer, 28);
                                int nHasAlarmConfig = Functions.BytesToInt(buffer, 32);
                                int nMainAlarmSwitch = Functions.BytesToInt(buffer, 36);
                                int nMotionAlarmSwitch = Functions.BytesToInt(buffer, 40);
                                int nPIRAlarmSwitch = Functions.BytesToInt(buffer, 44);
                                int nSmokeAlarmSwitch = Functions.BytesToInt(buffer, 48);
                                int ntimeArea = buffer[52];
                                int ntimequantum = buffer[53];
                                int alarmswitch1 = buffer[54];
                                int starthour1 = buffer[55];
                                int startmin1 = buffer[56];
                                int startsec1 = buffer[57];
                                int endhour1 = buffer[58];
                                int endmin1 = buffer[59];
                                int endsec1 = buffer[60];
                                int alarmswitch2 = buffer[61];
                                int starthour2 = buffer[62];
                                int startmin2 = buffer[63];
                                int startsec2 = buffer[64];
                                int endhour2 = buffer[65];
                                int endmin2 = buffer[66];
                                int endsec2 = buffer[67];
                                int alarmswitch3 = buffer[68];
                                int starthour3 = buffer[69];
                                int startmin3 = buffer[70];
                                int startsec3 = buffer[71];
                                int endhour3 = buffer[72];
                                int endmin3 = buffer[73];
                                int endsec3 = buffer[74];
                                int alarmrows = buffer[75];
                                int alarmcolumns = buffer[76];
                                for (i = 77; i < (alarmrows * alarmcolumns) + 77; i++) {
                                    alarmarea.add(i - 77, Integer.valueOf(buffer[i]));
                                }
                                ServerAlarmAreaList = alarmarea;
                                alarmAndPromptHandler.setCanSetTime(ntimeArea);
                                alarmAndPromptHandler.setAlarmcolumns(alarmcolumns);
                                alarmAndPromptHandler.setAlarmrows(alarmrows);
                                alarmAndPromptHandler.setServerAlarmSwitch1(alarmswitch1);
                                alarmAndPromptHandler.setServerAlarmSwitch2(alarmswitch2);
                                alarmAndPromptHandler.setServerAlarmSwitch3(alarmswitch3);
                                alarmAndPromptHandler.setStarthour1(starthour1);
                                alarmAndPromptHandler.setStarthour2(starthour2);
                                alarmAndPromptHandler.setStarthour3(starthour3);
                                alarmAndPromptHandler.setStartmin1(startmin1);
                                alarmAndPromptHandler.setStartmin2(startmin2);
                                alarmAndPromptHandler.setStartmin3(startmin3);
                                alarmAndPromptHandler.setStartsec1(startsec1);
                                alarmAndPromptHandler.setStartsec2(startsec2);
                                alarmAndPromptHandler.setStartsec3(startsec3);
                                alarmAndPromptHandler.setEndhour1(endhour1);
                                alarmAndPromptHandler.setEndhour2(endhour2);
                                alarmAndPromptHandler.setEndhour3(endhour3);
                                alarmAndPromptHandler.setEndmin1(endmin1);
                                alarmAndPromptHandler.setEndmin2(endmin2);
                                alarmAndPromptHandler.setEndmin3(endmin3);
                                alarmAndPromptHandler.setEndsec1(endsec1);
                                alarmAndPromptHandler.setEndsec2(endsec2);
                                alarmAndPromptHandler.setEndsec3(endsec3);
                                if (nHasVoicePromptsConfig == 1000) {
                                    alarmAndPromptHandler.setHasVoicePromptsConfig(true);
                                } else {
                                    alarmAndPromptHandler.setHasVoicePromptsConfig(false);
                                }
                                if (nVoicePromptsMainSwitch == 1000) {
                                    alarmAndPromptHandler.setbVoicePromptsMainSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbVoicePromptsMainSwitch(false);
                                }
                                if (nAlarmVoiceSwitch == 1000) {
                                    alarmAndPromptHandler.setbAlarmVoiceSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbAlarmVoiceSwitch(false);
                                }
                                if (nHasExIOConfig == 1000) {
                                    alarmAndPromptHandler.setHasExIOConfig(true);
                                } else {
                                    alarmAndPromptHandler.setHasExIOConfig(false);
                                }
                                alarmAndPromptHandler.setnLanguage(nVLanguage);
                                alarmAndPromptHandler.setnIOMode(nExIOMode);
                                if (nHasAlarmConfig == 1000) {
                                    alarmAndPromptHandler.setHasAlarmConfig(true);
                                } else {
                                    alarmAndPromptHandler.setHasAlarmConfig(false);
                                }
                                if (nMainAlarmSwitch == 1000) {
                                    alarmAndPromptHandler.setbMainAlarmSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbMainAlarmSwitch(false);
                                }
                                if (nMotionAlarmSwitch == 1000) {
                                    alarmAndPromptHandler.setbMotionAlarmSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbMotionAlarmSwitch(false);
                                }
                                if (nPIRAlarmSwitch == 1000) {
                                    alarmAndPromptHandler.setbPIRAlarmSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbPIRAlarmSwitch(false);
                                }
                                if (nSmokeAlarmSwitch == 1000) {
                                    alarmAndPromptHandler.setbSmokeAlarmSwitch(true);
                                } else {
                                    alarmAndPromptHandler.setbSmokeAlarmSwitch(false);
                                }
                            }
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e6) {
                                    e6.printStackTrace();
                                }
                            }
                            if (reader != null) {
                                reader.close();
                            }
                            if (sSocket != null) {
                                sSocket.close();
                            }
                        }
                    }
                }
            } catch (IOException e7) {
                isConnectOK = false;
            }
        }
        return alarmAndPromptHandler;
    }

    private static int setOneKeyAlarmSetServer(DeviceInfo device, boolean isAlarm) {
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        Socket sSocket = Functions.connectToServer(device.getStrIP(), device.getnPort(), Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 144, buffer, 0);
                if (device.getStrUsername() != null) {
                    System.arraycopy(device.getStrUsername().getBytes(), 0, buffer, 4, device.getStrUsername().getBytes().length);
                }
                if (device.getStrPassword() != null) {
                    System.arraycopy(device.getStrPassword().getBytes(), 0, buffer, 36, device.getStrPassword().getBytes().length);
                }
                Functions.IntToBytes((long) device.getnDevID(), buffer, 68);
                if (isAlarm) {
                    Functions.IntToBytes(1000, buffer, 72);
                } else {
                    Functions.IntToBytes(1001, buffer, 72);
                }
                try {
                    writer.write(buffer, 0, 412);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                for (int i = 0; i < 5; i++) {
                    if (reader.available() >= 412) {
                        reader.read(buffer, 0, 412);
                        bReadOK = true;
                        break;
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e5) {
                        try {
                            e5.printStackTrace();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                }
                if (bReadOK) {
                    int nResultCmd = Functions.BytesToInt(buffer, 0);
                    int nResultValue = Functions.BytesToInt(buffer, 4);
                    int nResultDesc = Functions.BytesToInt(buffer, 8);
                    if (nResultCmd == 244) {
                        if (nResultValue != 1001) {
                            switch (nResultDesc) {
                                case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_USER_NOEXIST;
                                    break;
                                case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_PWD_ERROR;
                                    break;
                                case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED;
                                    break;
                                default:
                                    nResult = ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL;
                                    break;
                            }
                        }
                        nResult = 256;
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
            }
            return nResult;
        } catch (IOException e7) {
            isConnectOK = false;
        }
    }

    private static int setOneKeyAlarmSetMRServer(DeviceInfo device, boolean isAlarm) {
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        Socket sSocket = Functions.connectToMRServer(device.getStrMRServer(), device.getnMRPort(), 8000, device.getnDevID());
        if (sSocket == null) {
            return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 881, buffer, 0);
                Functions.IntToBytes(1002, buffer, 4);
                if (device.getStrDomain() != null) {
                    System.arraycopy(device.getStrDomain().getBytes(), 0, buffer, 8, device.getStrDomain().getBytes().length);
                }
                Functions.IntToBytes((long) device.getnPort(), buffer, 58);
                if (device.getStrUsername() != null) {
                    System.arraycopy(device.getStrUsername().getBytes(), 0, buffer, 62, device.getStrUsername().getBytes().length);
                }
                if (device.getStrPassword() != null) {
                    System.arraycopy(device.getStrPassword().getBytes(), 0, buffer, 94, device.getStrPassword().getBytes().length);
                }
                Functions.IntToBytes((long) device.getnDevID(), buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                Functions.IntToBytes((long) 144, buffer, 130);
                if (isAlarm) {
                    Functions.IntToBytes(1000, buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST);
                } else {
                    Functions.IntToBytes(1001, buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST);
                }
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                for (int i = 0; i < 5; i++) {
                    if (reader.available() >= 412) {
                        reader.read(buffer, 0, 412);
                        bReadOK = true;
                        break;
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e5) {
                        try {
                            e5.printStackTrace();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                }
                if (bReadOK) {
                    int nResultCmd = Functions.BytesToInt(buffer, 0);
                    int nResultValue = Functions.BytesToInt(buffer, 4);
                    int nResultDesc = Functions.BytesToInt(buffer, 8);
                    if (nResultCmd == 244) {
                        if (nResultValue != 1001) {
                            switch (nResultDesc) {
                                case ResultCode.NV_RESULT_DESC_NO_USER /*1011*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_USER_NOEXIST;
                                    break;
                                case ResultCode.NV_RESULT_DESC_PWD_ERR /*1012*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_PWD_ERROR;
                                    break;
                                case ResultCode.NV_RESULT_DESC_NO_PRI /*1013*/:
                                    nResult = ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED;
                                    break;
                                default:
                                    nResult = ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL;
                                    break;
                            }
                        }
                        nResult = 256;
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
            }
            return nResult;
        } catch (IOException e7) {
            isConnectOK = false;
        }
    }
}
