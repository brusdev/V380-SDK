package com.macrovideo.sdk.setting;

import android.support.v4.media.TransportMediator;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.tools.Functions;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Arrays;

public class DeviceSDCardFormatSetting {
    private static final int COMMUNICATIONS_BUFFER_SIZE = 412;
    private static final int MR_COMMUNICATIONS_BUFFER_SIZE = 256;
    private static final int SERVER_RETURN_BUFFER_SIZE = 412;
    private static byte[] buffer = new byte[412];

    public static int setSDCardFormat(DeviceInfo device) {
        int nSDCardResult = 0;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (device.getStrUsername() == null || device.getStrUsername().length() <= 0) {
                return 0;
            }
            if (Functions.isIpAddress(device.getStrIP())) {
                nSDCardResult = setSDCardFormatServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (nSDCardResult == -1 || nSDCardResult == 0) {
                nSDCardResult = setSDCardFormatMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        return nSDCardResult;
    }

    private static int setSDCardFormatServer(String strIP, int nPort, String strUsername, String strPassword, int nDevice) {
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = -1;
        System.out.println("set server IP:" + strIP + " Port: " + nPort);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        if (sSocket == null) {
            return -1;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return -1;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                nResult = 0;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) Defines.NV_IPC_FORMAT_SDCARD_REQUEST, buffer, 0);
                System.arraycopy(strUsername.getBytes(), 0, buffer, 4, strUsername.getBytes().length);
                System.arraycopy(strPassword.getBytes(), 0, buffer, 36, strPassword.getBytes().length);
                Functions.IntToBytes((long) nDevice, buffer, 68);
                try {
                    writer.write(buffer, 0, 412);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 5) {
                    try {
                        if (reader.available() >= 412) {
                            reader.read(buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e5) {
                            e5.printStackTrace();
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK && Functions.BytesToInt(buffer, 0) == 241) {
                    nResult = Functions.BytesToInt(buffer, 4);
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
            }
            return nResult;
        } catch (IOException e7) {
            isConnectOK = false;
        }
    }

    private static int setSDCardFormatMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        int nResult = -1;
        System.out.println("MR set server IP:" + strMRServerIP + " Port: " + nMRPort);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 8000, nDeviceID);
        if (sSocket == null) {
            return -1;
        }
        boolean isConnectOK;
        try {
            if (!sSocket.isConnected()) {
                return -1;
            }
            writer = sSocket.getOutputStream();
            reader = sSocket.getInputStream();
            isConnectOK = true;
            if (isConnectOK) {
                nResult = 0;
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 881, buffer, 0);
                Functions.IntToBytes(1002, buffer, 4);
                if (strDomain != null) {
                    System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                }
                Functions.IntToBytes((long) nPort, buffer, 58);
                if (strUsername != null) {
                    System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                }
                if (strPassword != null) {
                    System.arraycopy(strPassword.getBytes(), 0, buffer, 94, strPassword.getBytes().length);
                }
                Functions.IntToBytes((long) nDeviceID, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                System.out.println("AAAAAAAAAAACCCC::::" + Functions.BytesToInt(buffer, TransportMediator.KEYCODE_MEDIA_PLAY));
                Functions.IntToBytes((long) Defines.NV_IPC_FORMAT_SDCARD_REQUEST, buffer, 130);
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e2) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e3) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e4) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 5) {
                    try {
                        if (reader.available() >= 412) {
                            reader.read(buffer, 0, 412);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e5) {
                            e5.printStackTrace();
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK) {
                    int nResultCmd = Functions.BytesToInt(buffer, 0);
                    System.out.println("AAAAAAA:::::" + nResultCmd);
                    if (nResultCmd == 241) {
                        nResult = Functions.BytesToInt(buffer, 4);
                    }
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                }
                if (reader != null) {
                    reader.close();
                }
                if (sSocket != null) {
                    sSocket.close();
                }
            }
            return nResult;
        } catch (IOException e7) {
            isConnectOK = false;
        }
    }
}
