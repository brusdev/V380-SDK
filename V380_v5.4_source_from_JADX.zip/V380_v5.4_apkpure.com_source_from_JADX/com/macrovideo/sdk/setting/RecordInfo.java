package com.macrovideo.sdk.setting;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class RecordInfo implements Parcelable {
    public static final Creator CREATOR = new C02421();
    private boolean bAlarmRecord = false;
    private boolean bAutoRecord = false;
    private boolean is1080PEnable = false;
    private boolean is720Enable = false;
    private boolean is960PEnable = false;
    private boolean isAudioEnable = false;
    private boolean isCIFEnable = false;
    private boolean isD1Enable = false;
    private boolean isNewVersion = false;
    private boolean isQCIFEnable = false;
    private boolean isQVGAEnable = false;
    private boolean isSDCardFormatting = false;
    private boolean isVGAEnable = false;
    private int nAudioEnable = 0;
    private int nDiskRemainSize = 0;
    private int nDiskSize = 0;
    private int nFrameSize = 0;
    private int nFullRecordOP = 0;
    private int nRecordStat;
    private int nResult = 0;

    class C02421 implements Creator {
        C02421() {
        }

        public RecordInfo createFromParcel(Parcel in) {
            return new RecordInfo(in);
        }

        public RecordInfo[] newArray(int size) {
            return new RecordInfo[size];
        }
    }

    public boolean isSDCardFormatting() {
        return this.isSDCardFormatting;
    }

    public void setSDCardFormatting(boolean isSDCardFormatting) {
        this.isSDCardFormatting = isSDCardFormatting;
    }

    public int getnAudioEnable() {
        return this.nAudioEnable;
    }

    public void setnAudioEnable(int nAudioEnable) {
        this.nAudioEnable = nAudioEnable;
    }

    public int getnFrameSize() {
        return this.nFrameSize;
    }

    public void setnFrameSize(int nFrameSize) {
        this.nFrameSize = nFrameSize;
    }

    public int getnResult() {
        return this.nResult;
    }

    public void setnResult(int nResult) {
        this.nResult = nResult;
    }

    public boolean isbAutoRecord() {
        return this.bAutoRecord;
    }

    public void setbAutoRecord(boolean bAutoRecord) {
        this.bAutoRecord = bAutoRecord;
    }

    public boolean isbAlarmRecord() {
        return this.bAlarmRecord;
    }

    public void setbAlarmRecord(boolean bAlarmRecord) {
        this.bAlarmRecord = bAlarmRecord;
    }

    public int getnFullRecordOP() {
        return this.nFullRecordOP;
    }

    public void setnFullRecordOP(int nFullRecordOP) {
        this.nFullRecordOP = nFullRecordOP;
    }

    public int getnDiskSize() {
        return this.nDiskSize;
    }

    public void setnDiskSize(int nDiskSize) {
        this.nDiskSize = nDiskSize;
    }

    public int getnDiskRemainSize() {
        return this.nDiskRemainSize;
    }

    public void setnDiskRemainSize(int nDiskRemainSize) {
        this.nDiskRemainSize = nDiskRemainSize;
    }

    public boolean isNewVersion() {
        return this.isNewVersion;
    }

    public void setNewVersion(boolean isNewVersion) {
        this.isNewVersion = isNewVersion;
    }

    public int getnRecordStat() {
        return this.nRecordStat;
    }

    public void setnRecordStat(int nRecordStat) {
        this.nRecordStat = nRecordStat;
    }

    public boolean isAudioEnable() {
        return this.isAudioEnable;
    }

    public void setAudioEnable(boolean isAudioEnable) {
        this.isAudioEnable = isAudioEnable;
    }

    public boolean isIs1080PEnable() {
        return this.is1080PEnable;
    }

    public void setIs1080PEnable(boolean is1080pEnable) {
        this.is1080PEnable = is1080pEnable;
    }

    public boolean isIs720Enable() {
        return this.is720Enable;
    }

    public void setIs720Enable(boolean is720Enable) {
        this.is720Enable = is720Enable;
    }

    public boolean isD1Enable() {
        return this.isD1Enable;
    }

    public void setD1Enable(boolean isD1Enable) {
        this.isD1Enable = isD1Enable;
    }

    public boolean isVGAEnable() {
        return this.isVGAEnable;
    }

    public void setVGAEnable(boolean isVGAEnable) {
        this.isVGAEnable = isVGAEnable;
    }

    public boolean isCIFEnable() {
        return this.isCIFEnable;
    }

    public void setCIFEnable(boolean isCIFEnable) {
        this.isCIFEnable = isCIFEnable;
    }

    public boolean isQVGAEnable() {
        return this.isQVGAEnable;
    }

    public void setQVGAEnable(boolean isQVGAEnable) {
        this.isQVGAEnable = isQVGAEnable;
    }

    public boolean isQCIFEnable() {
        return this.isQCIFEnable;
    }

    public void setQCIFEnable(boolean isQCIFEnable) {
        this.isQCIFEnable = isQCIFEnable;
    }

    public boolean isIs960PEnable() {
        return this.is960PEnable;
    }

    public void setIs960PEnable(boolean is960pEnable) {
        this.is960PEnable = is960pEnable;
    }

    public RecordInfo(Parcel in) {
        boolean z;
        boolean z2 = true;
        this.nResult = in.readInt();
        this.nFrameSize = in.readInt();
        this.nAudioEnable = in.readInt();
        this.bAutoRecord = in.readByte() == (byte) 1;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bAlarmRecord = z;
        this.nFullRecordOP = in.readInt();
        this.nDiskSize = in.readInt();
        this.nDiskRemainSize = in.readInt();
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isNewVersion = z;
        this.nRecordStat = in.readInt();
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isAudioEnable = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.is1080PEnable = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.is720Enable = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isD1Enable = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isVGAEnable = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isCIFEnable = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isQVGAEnable = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isQCIFEnable = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.is960PEnable = z;
        if (in.readByte() != (byte) 1) {
            z2 = false;
        }
        this.isSDCardFormatting = z2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int arg1) {
        int i;
        int i2 = 1;
        parcel.writeInt(this.nResult);
        parcel.writeInt(this.nFrameSize);
        parcel.writeInt(this.nAudioEnable);
        parcel.writeByte((byte) (this.bAutoRecord ? 1 : 0));
        if (this.bAlarmRecord) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        parcel.writeInt(this.nFullRecordOP);
        parcel.writeInt(this.nDiskSize);
        parcel.writeInt(this.nDiskRemainSize);
        if (this.isNewVersion) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        parcel.writeInt(this.nRecordStat);
        if (this.isAudioEnable) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.is1080PEnable) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.is720Enable) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.isD1Enable) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.isVGAEnable) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.isCIFEnable) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.isQVGAEnable) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.isQCIFEnable) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (this.is960PEnable) {
            i = 1;
        } else {
            i = 0;
        }
        parcel.writeByte((byte) i);
        if (!this.isSDCardFormatting) {
            i2 = 0;
        }
        parcel.writeByte((byte) i2);
    }
}
