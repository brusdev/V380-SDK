package com.macrovideo.sdk.push;

public class PhoneClient {
    private boolean isRecvMsg;
    private boolean isSound;
    private boolean isVibrate;
    private Long lChannelID;
    private int nID = 0;
    private String strAPIKey;
    private String strClientID;
    private String strPhoneNum;
    private String strSecretKey;
    private String strSoundFile;
    private String strUserID;
    private String strlan;

    public PhoneClient(String strClientID, String strPhoneNum, String strAPIKey, String strSecretKey, Long lChannelID, String strUserID, boolean isRecvMsg, boolean isVibrate, boolean isSound, String strSoundFile, String strlan) {
        this.strClientID = strClientID;
        this.strPhoneNum = strPhoneNum;
        this.strAPIKey = strAPIKey;
        this.strSecretKey = strSecretKey;
        this.lChannelID = lChannelID;
        this.strUserID = strUserID;
        setVibrate(isVibrate);
        setSound(isSound);
        this.strSoundFile = strSoundFile;
        this.strlan = strlan;
        this.isRecvMsg = isRecvMsg;
    }

    public int getnID() {
        return this.nID;
    }

    public void setnID(int nID) {
        this.nID = nID;
    }

    public String getStrlan() {
        return this.strlan;
    }

    public void setStrlan(String strlan) {
        this.strlan = strlan;
    }

    public boolean isRecvMsg() {
        return this.isRecvMsg;
    }

    public void setRecvMsg(boolean isRecvMsg) {
        this.isRecvMsg = isRecvMsg;
    }

    public String getStrSoundFile() {
        return this.strSoundFile;
    }

    public void setStrSoundFile(String strSoundFile) {
        this.strSoundFile = strSoundFile;
    }

    public String getStrPhoneNum() {
        return this.strPhoneNum;
    }

    public void setStrPhoneNum(String strPhoneNum) {
        this.strPhoneNum = strPhoneNum;
    }

    public String getStrClientID() {
        return this.strClientID;
    }

    public void setStrClientID(String strClientID) {
        this.strClientID = strClientID;
    }

    public String getStrAPIKey() {
        return this.strAPIKey;
    }

    public void setStrAPIKey(String strAPIKey) {
        this.strAPIKey = strAPIKey;
    }

    public String getStrSecretKey() {
        return this.strSecretKey;
    }

    public void setStrSecretKey(String strSecretKey) {
        this.strSecretKey = strSecretKey;
    }

    public Long getlChannelID() {
        return this.lChannelID;
    }

    public void setlChannelID(Long lChannelID) {
        this.lChannelID = lChannelID;
    }

    public String getStrUserID() {
        return this.strUserID;
    }

    public void setStrUserID(String strUserID) {
        this.strUserID = strUserID;
    }

    public boolean isVibrate() {
        return this.isVibrate;
    }

    public void setVibrate(boolean isVibrate) {
        this.isVibrate = isVibrate;
    }

    public boolean isSound() {
        return this.isSound;
    }

    public void setSound(boolean isSound) {
        this.isSound = isSound;
    }
}
