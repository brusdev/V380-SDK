package com.macrovideo.sdk.push;

import android.graphics.Bitmap;
import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.objects.AlarmMessage;
import com.macrovideo.sdk.objects.AlarmMessageResult;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.common.MessageKey;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PushMessageUtils {
    private static final int ALARM_FALLURE = 1;
    private static final int ALARM_SUCCESS = 0;
    private static final String JSP_SERVER_CONNECT_MSG = "/YZJPushServer/AlarmSelectServletMsg?param=";
    private static final String JSP_SERVER_CONNECT_PICTUER_PREVIEW = "/YZJPushServer/PreviewSelectServletDeviceInfo?param=";
    private static final String JSP_SERVER_CONNECT_PICTUER_PREVIEW_DEFAULT = "/GetPreviewServer/PreviewSelectServletDeviceInfo?param=";
    private static final String JSP_SERVER_CONNECT_PICTURE = "/YZJPushServer/AlarmSelectServletPicture?param=";
    private static final String JSP_SERVER_CONNECT_PICTURE_CONDITION = "/YZJPushServer/AlarmSelectServletPictureCondition?param=";
    private static final String JSP_SERVER_CONNECT_PICTURE_LARGE = "/YZJPushServer/AlarmSelectServletPictureByID?param=";
    public static final String JSP_SERVER_REGIST_CLIENT = "/YZJPushServer/XGPhoneClientRegistered?param=";
    public static final String JSP_SERVER_SET_DEVICE_ALARM = "/YZJPushServer/ClientWithDeivceRegistered?param=";
    public static final String JSP_SERVER_SET_DEVICE_ARRAY_ALARM = "/YZJPushServer/ClientWithDeivceArrayRegistered?param=";
    public static final int PUSH_RESULT_FAIL = -1;
    public static final int PUSH_RESULT_FAIL_CONNECT_FAIL = 0;
    public static final int PUSH_RESULT_PARAM_ERR = -2;
    public static final int PUSH_RESULT_SUCCEED = 1;
    private static int _nAlarmPort = 8888;
    private static String _strAlarmServerRecv = "alarmrec2.nvdvr.cn";
    private static String _strAlarmServerSend = "192.168.1.115";
    private static String _strDeviceDemoServer = "preview.nvdvr.cn";

    public static int RegestPhone(PhoneClient client) {
        int nResult = 0;
        JSONObject jsObject = new JSONObject();
        try {
            jsObject.put("client_id", client.getStrClientID());
            jsObject.put("phone_type", 1002);
            jsObject.put("phone_num", client.getStrPhoneNum());
            jsObject.put("apikey", client.getStrAPIKey());
            jsObject.put("secretkey", client.getStrSecretKey());
            jsObject.put("channel_id", client.getlChannelID());
            jsObject.put("user_id", client.getStrUserID());
            if (client.isVibrate()) {
                jsObject.put(MessageKey.MSG_VIBRATE, 1);
            } else {
                jsObject.put(MessageKey.MSG_VIBRATE, 0);
            }
            if (client.isSound()) {
                jsObject.put("sound", 1);
            } else {
                jsObject.put("sound", 0);
            }
            jsObject.put("sound_file", client.getStrSoundFile());
            if (client.isRecvMsg()) {
                jsObject.put("recv_msg_pri", 1);
            } else {
                jsObject.put("recv_msg_pri", 0);
            }
            if (client.getStrlan() != null) {
                jsObject.put("sys_lan", client.getStrlan());
            } else {
                jsObject.put("sys_lan", "cn");
            }
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
        String requestResult = Functions.GetJsonStringFromServerByHTTP(_strAlarmServerSend, _nAlarmPort, new StringBuilder(JSP_SERVER_REGIST_CLIENT).append(jsObject.toString()).toString());
        if (requestResult == null || requestResult.length() <= 0) {
            return 0;
        }
        try {
            JSONObject objStr = new JSONObject(requestResult);
            if (objStr == null) {
                nResult = -1;
            } else if (objStr.getInt("result") > 0) {
                nResult = 1;
            } else {
                nResult = -1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return nResult;
    }

    public static int SetDeviceList(String strClientID, ArrayList<DeviceInfo> deviceList) {
        int nResult = 0;
        JSONObject jsObject = new JSONObject();
        jsObject.put("client_id", strClientID);
        JSONArray jsArray = new JSONArray();
        if (deviceList != null && deviceList.size() > 0) {
            for (int i = deviceList.size() - 1; i >= 0; i--) {
                DeviceInfo info = (DeviceInfo) deviceList.get(i);
                if (info != null && info.getnDevID() > 0) {
                    JSONObject jsDev = new JSONObject();
                    String strUsername = info.getStrUsername();
                    String strPassword = info.getStrPassword();
                    jsDev.put("dev_id", info.getnDevID());
                    if (info.isRecvMsg()) {
                        jsDev.put("recv_msg_pri", 1);
                    } else {
                        jsDev.put("recv_msg_pri", 0);
                    }
                    if (strUsername == null || strUsername.length() <= 0) {
                        try {
                            jsDev.put("username", Constants.MAIN_VERSION_TAG);
                        } catch (JSONException e1) {
                            e1.printStackTrace();
                        }
                    } else {
                        jsDev.put("username", strUsername);
                    }
                    if (strPassword == null || strPassword.length() <= 0) {
                        jsDev.put("password", Constants.MAIN_VERSION_TAG);
                    } else {
                        jsDev.put("password", strPassword);
                    }
                    jsArray.put(jsDev);
                }
            }
        }
        jsObject.put("dev_list", jsArray);
        String requestResult = Functions.GetJsonStringFromServerByHTTP(_strAlarmServerSend, _nAlarmPort, new StringBuilder(JSP_SERVER_SET_DEVICE_ARRAY_ALARM).append(jsObject.toString()).toString());
        if (requestResult == null || requestResult.length() <= 0) {
            return 0;
        }
        try {
            JSONObject objStr = new JSONObject(requestResult);
            if (objStr == null) {
                nResult = -1;
            } else if (objStr.getInt("result") > 0) {
                nResult = 1;
            } else {
                nResult = -1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return nResult;
    }

    public static AlarmMessageResult GetNewAlarmMessage(int nDeviceID, String strUsername, String strPassword, long lLastFreshTime) {
        AlarmMessageResult list = new AlarmMessageResult();
        list.setnReuslt(0);
        if (nDeviceID <= 0) {
            list.setnReuslt(-2);
        } else {
            JSONObject jsObject = new JSONObject();
            jsObject.put("last_fresh_time", lLastFreshTime);
            jsObject.put("dev_id", nDeviceID);
            jsObject.put("max_count", 5);
            if (strUsername == null || strUsername.length() <= 0) {
                try {
                    jsObject.put("username", Constants.MAIN_VERSION_TAG);
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
            } else {
                jsObject.put("username", strUsername);
            }
            String requestResult;
            JSONObject objStr;
            int result;
            String value;
            JSONArray jSONArray;
            int j;
            JSONObject obj;
            int nTempSaveId;
            int nTempAlarmID;
            int nTempDevID;
            int nTempAlarmType;
            int nTempAlarmLevel;
            int nFloor;
            int nRoom;
            String strTempAlarmContent;
            String strTempAlarmTime;
            String strTempImage;
            long lTempLastFreshTime;
            AlarmMessage aMessage;
            if (strPassword == null || strPassword.length() <= 0) {
                jsObject.put("password", Constants.MAIN_VERSION_TAG);
                requestResult = Functions.GetJsonStringFromServerByHTTP(_strAlarmServerRecv, _nAlarmPort, new StringBuilder(JSP_SERVER_CONNECT_PICTURE).append(jsObject.toString()).toString());
                if (requestResult != null && requestResult.length() > 0) {
                    if (!requestResult.contains("\"result\":0")) {
                        list.setnReuslt(1);
                        try {
                            objStr = new JSONObject(requestResult);
                            if (objStr != null) {
                                result = objStr.getInt("result");
                                value = objStr.getString("value");
                                if (result > 0 && value != null && value.length() > 0) {
                                    jSONArray = new JSONArray(value);
                                    for (j = 0; j < jSONArray.length(); j++) {
                                        obj = (JSONObject) jSONArray.get(j);
                                        nTempSaveId = obj.getInt("id");
                                        nTempAlarmID = obj.getInt("alarm_id");
                                        nTempDevID = obj.getInt("dev_id");
                                        nTempAlarmType = obj.getInt("alarm_type");
                                        nTempAlarmLevel = obj.getInt("alarm_level");
                                        nFloor = obj.getInt("floor");
                                        nRoom = obj.getInt("room");
                                        strTempAlarmContent = obj.getString("alarm_msg");
                                        strTempAlarmTime = obj.getString("alarm_time");
                                        strTempImage = obj.getString("alarm_image");
                                        lTempLastFreshTime = obj.getLong("last_fresh_time");
                                        list.setlLastAlarmTime(lTempLastFreshTime);
                                        aMessage = new AlarmMessage(0, nTempSaveId, nTempAlarmID, nTempDevID, nTempAlarmType, nTempAlarmLevel, nFloor, nRoom, strTempAlarmContent, strTempAlarmTime, lTempLastFreshTime);
                                        aMessage.setImage(Functions.decodeStringtoBitmap(strTempImage));
                                        list.addToList(aMessage);
                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (requestResult.contains("\"result\":0")) {
                    list.setnReuslt(-1);
                }
            } else {
                jsObject.put("password", strPassword);
                requestResult = Functions.GetJsonStringFromServerByHTTP(_strAlarmServerRecv, _nAlarmPort, new StringBuilder(JSP_SERVER_CONNECT_PICTURE).append(jsObject.toString()).toString());
                if (requestResult.contains("\"result\":0")) {
                    list.setnReuslt(1);
                    objStr = new JSONObject(requestResult);
                    if (objStr != null) {
                        result = objStr.getInt("result");
                        value = objStr.getString("value");
                        jSONArray = new JSONArray(value);
                        for (j = 0; j < jSONArray.length(); j++) {
                            obj = (JSONObject) jSONArray.get(j);
                            nTempSaveId = obj.getInt("id");
                            nTempAlarmID = obj.getInt("alarm_id");
                            nTempDevID = obj.getInt("dev_id");
                            nTempAlarmType = obj.getInt("alarm_type");
                            nTempAlarmLevel = obj.getInt("alarm_level");
                            nFloor = obj.getInt("floor");
                            nRoom = obj.getInt("room");
                            strTempAlarmContent = obj.getString("alarm_msg");
                            strTempAlarmTime = obj.getString("alarm_time");
                            strTempImage = obj.getString("alarm_image");
                            lTempLastFreshTime = obj.getLong("last_fresh_time");
                            list.setlLastAlarmTime(lTempLastFreshTime);
                            aMessage = new AlarmMessage(0, nTempSaveId, nTempAlarmID, nTempDevID, nTempAlarmType, nTempAlarmLevel, nFloor, nRoom, strTempAlarmContent, strTempAlarmTime, lTempLastFreshTime);
                            aMessage.setImage(Functions.decodeStringtoBitmap(strTempImage));
                            list.addToList(aMessage);
                        }
                    }
                }
                if (requestResult.contains("\"result\":0")) {
                    list.setnReuslt(-1);
                }
            }
        }
        return list;
    }

    public static AlarmMessageResult GetMoreNewAlarmMessage(int nDeviceID, String strUsername, String strPassword, long lStartTime, long lEndTime) {
        AlarmMessageResult list = new AlarmMessageResult();
        list.setnReuslt(0);
        if (nDeviceID <= 0) {
            list.setnReuslt(-2);
        } else {
            JSONObject jsObject = new JSONObject();
            jsObject.put("from_time", lStartTime);
            jsObject.put("to_time", lEndTime);
            jsObject.put("dev_id", nDeviceID);
            jsObject.put("max_count", 5);
            if (strUsername == null || strUsername.length() <= 0) {
                try {
                    jsObject.put("username", Constants.MAIN_VERSION_TAG);
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
            } else {
                jsObject.put("username", strUsername);
            }
            String requestResult;
            JSONObject objStr;
            int result;
            String value;
            JSONArray jSONArray;
            int j;
            JSONObject obj;
            int nTempSaveId;
            int nTempAlarmID;
            int nTempDevID;
            int nTempAlarmType;
            int nTempAlarmLevel;
            int nFloor;
            int nRoom;
            String strTempAlarmContent;
            String strTempAlarmTime;
            String strTempImage;
            long lTempLastFreshTime;
            AlarmMessage aMessage;
            if (strPassword == null || strPassword.length() <= 0) {
                jsObject.put("password", Constants.MAIN_VERSION_TAG);
                requestResult = Functions.GetJsonStringFromServerByHTTP(_strAlarmServerRecv, _nAlarmPort, new StringBuilder(JSP_SERVER_CONNECT_PICTURE_CONDITION).append(jsObject.toString()).toString());
                if (requestResult != null && requestResult.length() > 0) {
                    if (!requestResult.contains("\"result\":0")) {
                        list.setnReuslt(1);
                        try {
                            objStr = new JSONObject(requestResult);
                            if (objStr != null) {
                                result = objStr.getInt("result");
                                value = objStr.getString("value");
                                if (result > 0 && value != null && value.length() > 0) {
                                    jSONArray = new JSONArray(value);
                                    for (j = 0; j < jSONArray.length(); j++) {
                                        obj = (JSONObject) jSONArray.get(j);
                                        nTempSaveId = obj.getInt("id");
                                        nTempAlarmID = obj.getInt("alarm_id");
                                        nTempDevID = obj.getInt("dev_id");
                                        nTempAlarmType = obj.getInt("alarm_type");
                                        nTempAlarmLevel = obj.getInt("alarm_level");
                                        nFloor = obj.getInt("floor");
                                        nRoom = obj.getInt("room");
                                        strTempAlarmContent = obj.getString("alarm_msg");
                                        strTempAlarmTime = obj.getString("alarm_time");
                                        strTempImage = obj.getString("alarm_image");
                                        lTempLastFreshTime = obj.getLong("last_fresh_time");
                                        list.setlLastAlarmTime(lTempLastFreshTime);
                                        aMessage = new AlarmMessage(0, nTempSaveId, nTempAlarmID, nTempDevID, nTempAlarmType, nTempAlarmLevel, nFloor, nRoom, strTempAlarmContent, strTempAlarmTime, lTempLastFreshTime);
                                        aMessage.setImage(Functions.decodeStringtoBitmap(strTempImage));
                                        list.addToList(aMessage);
                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (requestResult.contains("\"result\":0")) {
                    list.setnReuslt(-1);
                }
            } else {
                jsObject.put("password", strPassword);
                requestResult = Functions.GetJsonStringFromServerByHTTP(_strAlarmServerRecv, _nAlarmPort, new StringBuilder(JSP_SERVER_CONNECT_PICTURE_CONDITION).append(jsObject.toString()).toString());
                if (requestResult.contains("\"result\":0")) {
                    list.setnReuslt(1);
                    objStr = new JSONObject(requestResult);
                    if (objStr != null) {
                        result = objStr.getInt("result");
                        value = objStr.getString("value");
                        jSONArray = new JSONArray(value);
                        for (j = 0; j < jSONArray.length(); j++) {
                            obj = (JSONObject) jSONArray.get(j);
                            nTempSaveId = obj.getInt("id");
                            nTempAlarmID = obj.getInt("alarm_id");
                            nTempDevID = obj.getInt("dev_id");
                            nTempAlarmType = obj.getInt("alarm_type");
                            nTempAlarmLevel = obj.getInt("alarm_level");
                            nFloor = obj.getInt("floor");
                            nRoom = obj.getInt("room");
                            strTempAlarmContent = obj.getString("alarm_msg");
                            strTempAlarmTime = obj.getString("alarm_time");
                            strTempImage = obj.getString("alarm_image");
                            lTempLastFreshTime = obj.getLong("last_fresh_time");
                            list.setlLastAlarmTime(lTempLastFreshTime);
                            aMessage = new AlarmMessage(0, nTempSaveId, nTempAlarmID, nTempDevID, nTempAlarmType, nTempAlarmLevel, nFloor, nRoom, strTempAlarmContent, strTempAlarmTime, lTempLastFreshTime);
                            aMessage.setImage(Functions.decodeStringtoBitmap(strTempImage));
                            list.addToList(aMessage);
                        }
                    }
                }
                if (requestResult.contains("\"result\":0")) {
                    list.setnReuslt(-1);
                }
            }
        }
        return list;
    }

    public static AlarmMessage GetAlarmMessageImage(AlarmMessage aMessage, String strUsername, String strPassword) {
        if (aMessage == null || aMessage.getnDevID() <= 0) {
            return null;
        }
        JSONObject jsObject = new JSONObject();
        jsObject.put("dev_id", aMessage.getnDevID());
        jsObject.put("alarm_id", aMessage.getnAlarmID());
        if (strUsername == null || strUsername.length() <= 0) {
            try {
                jsObject.put("username", Constants.MAIN_VERSION_TAG);
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
        } else {
            jsObject.put("username", strUsername);
        }
        String requestResult;
        if (strPassword == null || strPassword.length() <= 0) {
            jsObject.put("password", Constants.MAIN_VERSION_TAG);
            requestResult = Functions.GetJsonStringFromServerByHTTP(_strAlarmServerRecv, _nAlarmPort, new StringBuilder(JSP_SERVER_CONNECT_PICTURE_LARGE).append(jsObject.toString()).toString());
            if (requestResult == null && requestResult.length() > 0) {
                try {
                    JSONObject objStr = new JSONObject(requestResult);
                    if (objStr == null || objStr.getInt("result") != 1) {
                        return aMessage;
                    }
                    String strTempImage = objStr.getString("alarm_image");
                    Bitmap image = null;
                    if (strTempImage != null) {
                        image = Functions.decodeStringtoBitmap(strTempImage);
                    }
                    aMessage.setImage(image);
                    return aMessage;
                } catch (Exception e) {
                    e.printStackTrace();
                    return aMessage;
                }
            }
        }
        jsObject.put("password", strPassword);
        requestResult = Functions.GetJsonStringFromServerByHTTP(_strAlarmServerRecv, _nAlarmPort, new StringBuilder(JSP_SERVER_CONNECT_PICTURE_LARGE).append(jsObject.toString()).toString());
        return requestResult == null ? aMessage : aMessage;
    }
}
