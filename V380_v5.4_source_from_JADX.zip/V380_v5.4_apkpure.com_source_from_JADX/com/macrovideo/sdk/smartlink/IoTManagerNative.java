package com.macrovideo.sdk.smartlink;

import android.util.Log;

class IoTManagerNative {
    public static native byte[][] Scan(String str, int i, byte b);

    public static native int StartSmartConnection(byte[] bArr, int i, byte[] bArr2, int i2, byte b);

    public static native int StopSmartConnection();

    public static native String getSmartConnectionVersion();

    IoTManagerNative() {
    }

    static {
        Log.d("IoTManager", "install  zerolink");
        System.loadLibrary("zerolink");
    }
}
