package com.macrovideo.sdk.smartlink;

import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class SmarkLinkTool {
    private static byte[] baPWD = new byte[128];
    private static byte[] baSSID = new byte[128];

    public static int StartSmartConnection(String strSSID, String strPassword) {
        if (strSSID == null || strSSID.length() <= 0) {
            return -1;
        }
        if (strPassword == null || strPassword.length() <= 0) {
            strPassword = new StringBuilder(String.valueOf(0)).toString();
        } else {
            strPassword = new StringBuilder(String.valueOf(0)).append(strPassword).toString();
        }
        byte[] bytSSID = null;
        try {
            bytSSID = strSSID.getBytes("GBK");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        byte[] bytPWD = null;
        try {
            bytPWD = strPassword.getBytes("GBK");
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        }
        int nSSIDLen = 0;
        if (strSSID != null) {
            nSSIDLen = strSSID.length() * 2;
        }
        int nPWDLen = 0;
        if (strPassword != null) {
            nPWDLen = strPassword.length() * 2;
        }
        Arrays.fill(baSSID, (byte) 0);
        Arrays.fill(baPWD, (byte) 0);
        System.arraycopy(bytSSID, 0, baSSID, 0, bytSSID.length);
        System.arraycopy(bytPWD, 0, baPWD, 0, bytPWD.length);
        System.out.println("IoTManagerNative.StartSmartConnection: " + strSSID + ", " + strPassword);
        IoTManagerNative.StopSmartConnection();
        System.out.println("IoTManagerNative.StartSmartConnection: 2");
        return IoTManagerNative.StartSmartConnection(baSSID, nSSIDLen, baPWD, nPWDLen, (byte) 0);
    }

    public static int StartSmartConnection(int nConfigID, String strSSID, String strPassword) {
        if (strSSID == null || strSSID.length() <= 0) {
            return -1;
        }
        if (strPassword == null || strPassword.length() <= 0) {
            strPassword = new StringBuilder(String.valueOf(nConfigID)).toString();
        } else {
            strPassword = new StringBuilder(String.valueOf(nConfigID)).append(strPassword).toString();
        }
        byte[] bytSSID = null;
        try {
            bytSSID = strSSID.getBytes("GBK");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        byte[] bytPWD = null;
        try {
            bytPWD = strPassword.getBytes("GBK");
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        }
        int nSSIDLen = 0;
        if (strSSID != null) {
            nSSIDLen = strSSID.length() * 2;
        }
        int nPWDLen = 0;
        if (strPassword != null) {
            nPWDLen = strPassword.length() * 2;
        }
        Arrays.fill(baSSID, (byte) 0);
        Arrays.fill(baPWD, (byte) 0);
        System.arraycopy(bytSSID, 0, baSSID, 0, bytSSID.length);
        System.arraycopy(bytPWD, 0, baPWD, 0, bytPWD.length);
        System.out.println("IoTManagerNative.StartSmartConnection: " + strSSID + ", " + strPassword);
        IoTManagerNative.StopSmartConnection();
        System.out.println("IoTManagerNative.StartSmartConnection: 2");
        if (isInvalidSSIDName(strSSID)) {
            return IoTManagerNative.StartSmartConnection(null, nSSIDLen, baPWD, nPWDLen, (byte) 0);
        }
        return IoTManagerNative.StartSmartConnection(baSSID, nSSIDLen, baPWD, nPWDLen, (byte) 0);
    }

    public static int StopSmartConnection() {
        return IoTManagerNative.StopSmartConnection();
    }

    public static boolean isInvalidSSIDName(String strSSID) {
        for (int i = 0; i < strSSID.length(); i++) {
            char ch = strSSID.charAt(i);
            Log.i("dqx", "smarklink(32 ~ 126) ch = " + ch + " num = " + ch);
            if (isInvalidChar(ch)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isInvalidChar(char ch) {
        return ch < ' ' || ch > '~';
    }
}
