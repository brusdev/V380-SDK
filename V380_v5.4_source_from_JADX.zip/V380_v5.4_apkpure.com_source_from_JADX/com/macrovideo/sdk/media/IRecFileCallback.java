package com.macrovideo.sdk.media;

import com.macrovideo.sdk.custom.RecordFileInfo;
import java.util.ArrayList;

public interface IRecFileCallback {
    void onReceiveFile(int i, int i2, ArrayList<RecordFileInfo> arrayList);
}
