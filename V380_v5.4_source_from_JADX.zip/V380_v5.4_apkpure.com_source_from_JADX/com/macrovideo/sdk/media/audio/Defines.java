package com.macrovideo.sdk.media.audio;

import android.app.Application;

public class Defines extends Application {
    static final int FRAMETYPE_AAC = 24;
    public static final int FRAMETYPE_ADPCM = 22;
    static final int FRAMETYPE_B = 6;
    static final int FRAMETYPE_END = 38;
    static final int FRAMETYPE_I = 0;
    static final int FRAMETYPE_JPEG = 9;
    static final int FRAMETYPE_MD = 8;
    static final int FRAMETYPE_MEPG4_I = 36;
    static final int FRAMETYPE_MEPG4_P = 37;
    static final int FRAMETYPE_MP2 = 4;
    static final int FRAMETYPE_MP3 = 23;
    static final int FRAMETYPE_MR_CONNETING = 33;
    static final int FRAMETYPE_MR_DISCONNET = 34;
    static final int FRAMETYPE_MR_MAKING_HOLE = 32;
    static final int FRAMETYPE_P = 1;
    public static final int FRAMETYPE_PCM = 21;
    static final int FRAMETYPE_SYSHEADER = 16;
    static final int FRAMETYPE_ULAWPCM = 5;
    static final int FRAME_BUF_MAX_SIZE = 1216512;
    static final int SUBFRAMETYPE_B = 7;
    static final int SUBFRAMETYPE_I = 2;
    static final int SUBFRAMETYPE_P = 3;
}
