package com.macrovideo.sdk.media.audio;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class AudioDataCache {
    static final int MAX_QUEUE_SIZE = 100;
    private int m_nChn = 0;
    private int m_nCodecID = 0;
    int nCurrentSize = 0;
    private BlockingQueue<AudioDataObject> queue = new ArrayBlockingQueue(100);

    public int getM_nCodecID() {
        return this.m_nCodecID;
    }

    public void setM_nCodecID(int m_nCodecID) {
        this.m_nCodecID = m_nCodecID;
    }

    public int getM_nChn() {
        return this.m_nChn;
    }

    public boolean ReleaseImageDataCache() {
        return true;
    }

    public boolean hasData() {
        return !this.queue.isEmpty();
    }

    public int queueSize() {
        return this.queue.size();
    }

    public int PutData(byte[] data, int nStartIndex, int nEndIndex, int nType) {
        int nDataSize = nEndIndex - nStartIndex;
        if (this.m_nCodecID == 0) {
            this.m_nCodecID = nType;
        }
        if (data == null || nDataSize <= 0 || data.length <= 0 || nEndIndex > data.length || nStartIndex < 0) {
            return 0;
        }
        try {
            this.queue.put(new AudioDataObject(data, nStartIndex, nEndIndex, nType));
            return nDataSize;
        } catch (InterruptedException e) {
            return 0;
        }
    }

    public AudioDataObject getData() {
        if (this.queue.isEmpty()) {
            return null;
        }
        AudioDataObject dataOject;
        try {
            dataOject = (AudioDataObject) this.queue.take();
        } catch (InterruptedException e) {
            dataOject = null;
        }
        return dataOject;
    }

    public int PutDataEx(byte[] data, int nDataSize, int nId, int nFrameType) {
        System.out.println("PutData: " + nDataSize);
        if (nDataSize <= 0) {
            return nDataSize;
        }
        if (data.length < nDataSize) {
            nDataSize = data.length;
        }
        try {
            this.queue.put(new AudioDataObject(data, nDataSize, nId, nFrameType));
            return nDataSize;
        } catch (InterruptedException e) {
            return 0;
        }
    }

    public int getCurrentSize() {
        return this.nCurrentSize;
    }

    public boolean clearCache() {
        this.m_nCodecID = 0;
        if (this.queue != null) {
            this.queue.clear();
        }
        return true;
    }
}
