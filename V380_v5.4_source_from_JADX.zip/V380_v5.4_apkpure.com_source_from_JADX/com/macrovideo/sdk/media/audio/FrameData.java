package com.macrovideo.sdk.media.audio;

import android.graphics.Bitmap;

public class FrameData {
    Bitmap image = null;
    int m_nFrameRate = 0;
    int m_nFrameType = 0;
    int m_nId = -1;

    public FrameData(Bitmap image, int nId, int nFrameRate, int nFrameType) {
        this.m_nId = nId;
        this.m_nFrameType = nFrameType;
        this.m_nFrameRate = nFrameRate;
        this.image = image;
    }
}
