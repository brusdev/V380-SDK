package com.macrovideo.sdk.media.audio;

public class AudioParam {
    private int mChannel;
    private int mFrequency;
    private int mSampBit;

    public AudioParam() {
        this.mFrequency = 8000;
        this.mChannel = 4;
        this.mSampBit = 2;
        this.mFrequency = 8000;
        this.mChannel = 4;
        this.mSampBit = 2;
    }

    public AudioParam(int nFrequency, int nChannel, int nSampBit) {
        this.mFrequency = 8000;
        this.mChannel = 4;
        this.mSampBit = 2;
        this.mFrequency = nFrequency;
        this.mChannel = nChannel;
        this.mSampBit = nSampBit;
    }

    public int getmFrequency() {
        return this.mFrequency;
    }

    public void setmFrequency(int mFrequency) {
        this.mFrequency = mFrequency;
    }

    public int getmChannel() {
        return this.mChannel;
    }

    public void setmChannel(int mChannel) {
        this.mChannel = mChannel;
    }

    public int getmSampBit() {
        return this.mSampBit;
    }

    public void setmSampBit(int mSampBit) {
        this.mSampBit = mSampBit;
    }
}
