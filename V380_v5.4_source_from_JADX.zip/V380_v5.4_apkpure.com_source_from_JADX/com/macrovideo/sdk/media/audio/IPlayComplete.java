package com.macrovideo.sdk.media.audio;

public interface IPlayComplete {
    void onPlayComplete();
}
