package com.macrovideo.sdk.media;

import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class LoginHelper {
    static final int LOGIN_COMMUNICATION_BUFFER_SIZE = 520;
    static final int MR_LOGIN_COMMUNICATION_BUFFER_SIZE = 256;
    private static byte[] buffer = new byte[520];

    public static LoginHandle test(int lLoginHandle, int nDeviceID, String strDomain, String strIP, String strLanIP, int nPort, String strUsername, String strPassword, boolean isMRMode, String strMRServer, int nMRPort) {
        LoginHandle deviceParam = new LoginHandle();
        deviceParam.setnResult(lLoginHandle);
        deviceParam.setnDeviceID(nDeviceID);
        deviceParam.setStrUsername(strUsername);
        deviceParam.setStrPassword(strPassword);
        deviceParam.setStrDomain(strDomain);
        deviceParam.setStrIP(strIP);
        deviceParam.setStrLanIP(strLanIP);
        deviceParam.setnPort(nPort);
        deviceParam.setMRMode(isMRMode);
        deviceParam.setStrMRServer(strMRServer);
        deviceParam.setnMRPort(nMRPort);
        return deviceParam;
    }

    public static LoginHandle getDeviceParam(DeviceInfo device) {
        LoginHandle deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = LoginFromServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_ID_ERR) {
                deviceParam = LoginFromMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        if (deviceParam != null) {
            if (deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_ID_ERR) {
                deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
            } else if (deviceParam.getnResult() == 256) {
                deviceParam.setnDeviceID(device.getnDevID());
                deviceParam.setStrUsername(device.getStrUsername());
                deviceParam.setStrPassword(device.getStrPassword());
                deviceParam.setStrDomain(device.getStrDomain());
            }
        }
        return deviceParam;
    }

    public static LoginHandle getDeviceParam(DeviceInfo device, String strMRServerIP, int nMRPort) {
        LoginHandle deviceParam = LoginFromMRServer(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
        if (deviceParam != null) {
            if (deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_ID_ERR) {
                deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
            } else if (deviceParam.getnResult() == 256) {
                deviceParam.setnDeviceID(device.getnDevID());
                deviceParam.setStrUsername(device.getStrUsername());
                deviceParam.setStrPassword(device.getStrPassword());
                deviceParam.setStrDomain(device.getStrDomain());
            }
        }
        return deviceParam;
    }

    private static LoginHandle LoginFromServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        boolean bAudio_PRI = false;
        boolean bPTZ_PRI = false;
        boolean bSpeak_PRI = false;
        boolean bReverse_PRI = false;
        boolean bPTZX_PRI = false;
        int nPTZXCount = 0;
        LoginHandle deviceParam = new LoginHandle();
        deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        boolean isConnectOK = false;
        if (sSocket != null) {
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                }
            } catch (IOException e) {
                isConnectOK = false;
            }
            if (isConnectOK) {
                String strDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(System.currentTimeMillis()));
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 167, buffer, 0);
                Functions.IntToBytes((long) 120, buffer, 4);
                if (strUsername != null) {
                    System.arraycopy(strUsername.getBytes(), 0, buffer, 8, strUsername.getBytes().length);
                }
                if (strPassword != null) {
                    System.arraycopy(strPassword.getBytes(), 0, buffer, 58, strPassword.getBytes().length);
                }
                Functions.IntToBytes((long) nDeviceID, buffer, 108);
                if (strDateTime != null) {
                    System.arraycopy(strDateTime.getBytes(), 0, buffer, 112, strDateTime.getBytes().length);
                }
                try {
                    writer.write(buffer, 0, 520);
                    writer.flush();
                } catch (IOException e2) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e3) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e4) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e5) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                for (int i = 0; i < 5; i++) {
                    if (reader.available() >= 520) {
                        reader.read(buffer, 0, 520);
                        bReadOK = true;
                        break;
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e6) {
                        try {
                            e6.printStackTrace();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                }
                if (bReadOK) {
                    int nLoginResult = Functions.BytesToInt(buffer, 0);
                    int nResultValue = Functions.BytesToInt(buffer, 8);
                    if (nLoginResult == 168) {
                        nResultValue -= (nResultValue / 100) * 100;
                        if (nResultValue == -2) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                        } else if (nResultValue == -1) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                        } else if (nResultValue == 0) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                        } else if (nResultValue == 1) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                        } else {
                            deviceParam.setnResult(256);
                            if ((nResultValue & 2) > 0) {
                            }
                            if ((nResultValue & 8) > 0) {
                            }
                            if ((nResultValue & 16) > 0) {
                            }
                            if ((nResultValue & 32) > 0) {
                            }
                            if (buffer[48] == (byte) 1) {
                                bAudio_PRI = true;
                            }
                            if (buffer[49] == (byte) 1) {
                                bSpeak_PRI = true;
                            }
                            if (buffer[50] == (byte) 1) {
                                bPTZ_PRI = true;
                            }
                            if (buffer[51] == (byte) 1) {
                                bReverse_PRI = true;
                            }
                            if (buffer[52] == (byte) 1) {
                                bPTZX_PRI = true;
                                nPTZXCount = buffer[53];
                            }
                            deviceParam.setbAudio(bAudio_PRI);
                            deviceParam.setbPTZ(bPTZ_PRI);
                            deviceParam.setbPTZX(bPTZX_PRI);
                            deviceParam.setbReversePRI(bReverse_PRI);
                            deviceParam.setbSpeak(bSpeak_PRI);
                            deviceParam.setnPTZXCount(nPTZXCount);
                            deviceParam.setbInLan(true);
                            deviceParam.setStrIP(strIP);
                            deviceParam.setStrLanIP(strIP);
                            deviceParam.setnPort(nPort);
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e7) {
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e8) {
                }
            }
            if (sSocket != null) {
                try {
                    sSocket.close();
                } catch (IOException e9) {
                }
            }
        }
        return deviceParam;
    }

    private static LoginHandle LoginFromMRServer(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        boolean bAudio_PRI = false;
        boolean bPTZ_PRI = false;
        boolean bSpeak_PRI = false;
        boolean bReverse_PRI = false;
        boolean bPTZX_PRI = false;
        int nPTZXCount = 0;
        String strIP = Constants.MAIN_VERSION_TAG;
        String strLanIP = Constants.MAIN_VERSION_TAG;
        LoginHandle deviceParam = new LoginHandle();
        deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, 5000, nDeviceID);
        System.out.println("MR Login: " + strMRServerIP + ", " + nMRPort);
        boolean isConnectOK = false;
        if (sSocket != null) {
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                }
            } catch (IOException e) {
                isConnectOK = false;
            }
            if (isConnectOK) {
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 1001, buffer, 0);
                Functions.IntToBytes((long) 1002, buffer, 4);
                if (strDomain != null) {
                    System.arraycopy(strDomain.getBytes(), 0, buffer, 8, strDomain.getBytes().length);
                }
                Functions.IntToBytes((long) nPort, buffer, 58);
                if (strUsername != null) {
                    System.arraycopy(strUsername.getBytes(), 0, buffer, 62, strUsername.getBytes().length);
                }
                if (strPassword != null) {
                    System.arraycopy(strPassword.getBytes(), 0, buffer, 112, strPassword.getBytes().length);
                }
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e2) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e3) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e4) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e5) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 5) {
                    try {
                        if (reader.available() >= 256) {
                            reader.read(buffer, 0, 520);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e6) {
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK) {
                    int nLoginCMD = Functions.BytesToInt(buffer, 0);
                    int nResultCode = Functions.BytesToInt(buffer, 4);
                    int nResultValue = Functions.BytesToInt(buffer, 8);
                    byte bIsInSameLan = buffer[12];
                    int nLen = 0;
                    for (i = 0; i < 32; i++) {
                        if (((char) buffer[i + 13]) == '\u0000') {
                            nLen = i;
                            break;
                        }
                    }
                    Object strServerIP = new byte[nLen];
                    Arrays.fill(strServerIP, (byte) 0);
                    System.arraycopy(buffer, 13, strServerIP, 0, nLen);
                    int nServerPort = Functions.BytesToInt(buffer, 45);
                    nLen = 0;
                    for (i = 0; i < 32; i++) {
                        if (((char) buffer[i + 49]) == '\u0000') {
                            nLen = i;
                            break;
                        }
                    }
                    Object strServerLanIP = new byte[nLen];
                    Arrays.fill(strServerLanIP, (byte) 0);
                    System.arraycopy(buffer, 49, strServerLanIP, 0, nLen);
                    if (nLoginCMD == 169) {
                        if (nResultCode != 1001) {
                            switch (nResultValue) {
                                case -11:
                                    deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_OLD_VERSON);
                                    break;
                                case 0:
                                    deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                    break;
                                case 1:
                                    deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                    break;
                                case 2:
                                    deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                    break;
                                default:
                                    break;
                            }
                        }
                        String str = new String(strServerIP);
                        str.trim();
                        new String(strServerLanIP).trim();
                        if (buffer[81] == (byte) 1) {
                            bAudio_PRI = true;
                        }
                        if (buffer[82] == (byte) 1) {
                            bSpeak_PRI = true;
                        }
                        if (buffer[83] == (byte) 1) {
                            bPTZ_PRI = true;
                        }
                        if (buffer[84] == (byte) 1) {
                            bReverse_PRI = true;
                        }
                        if (buffer[85] == (byte) 1) {
                            bPTZX_PRI = true;
                            nPTZXCount = buffer[86];
                        }
                        if (bIsInSameLan == (byte) 1) {
                        }
                        nResultValue -= (nResultValue / 100) * 100;
                        if (nResultValue == -1) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                        } else if (nResultValue == 0) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                        } else if (nResultValue == 1) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                        } else {
                            System.out.println("MR Login OK " + str + ", " + nMRPort);
                            deviceParam.setnResult(256);
                            if ((nResultValue & 2) > 0) {
                            }
                            if ((nResultValue & 8) > 0) {
                            }
                            if ((nResultValue & 16) > 0) {
                            }
                            if ((nResultValue & 32) > 0) {
                            }
                            deviceParam.setbAudio(bAudio_PRI);
                            deviceParam.setbPTZ(bPTZ_PRI);
                            deviceParam.setbPTZX(bPTZX_PRI);
                            deviceParam.setbReversePRI(bReverse_PRI);
                            deviceParam.setbSpeak(bSpeak_PRI);
                            deviceParam.setnPTZXCount(nPTZXCount);
                            deviceParam.setbInLan(false);
                            deviceParam.setStrIP(str);
                            deviceParam.setStrLanIP(str);
                            deviceParam.setnPort(nPort);
                            deviceParam.setMRMode(true);
                            System.out.println("setMRMode = " + deviceParam.isMRMode());
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e7) {
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e8) {
                }
            }
            if (sSocket != null) {
                try {
                    sSocket.close();
                } catch (IOException e9) {
                }
            }
        }
        return deviceParam;
    }
}
