package com.macrovideo.sdk.media;

import android.support.v4.media.TransportMediator;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.LocalDefines;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Arrays;

class PTZXCotroller {
    private static byte[] buffer = new byte[412];
    private static int m_nPTZXID = 0;

    PTZXCotroller() {
    }

    public static int setPTZXPoint(LoginHandle lhandle, int nPTZXID, int nPTZXAction, int nDeviceId) {
        m_nPTZXID++;
        if (lhandle == null) {
            return ResultCode.RESULE_CODE_FAIL_PARAM_ERR;
        }
        int nResult = setPTZXConfigFromServer(lhandle, nPTZXID, nPTZXAction, m_nPTZXID);
        if (nResult == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL) {
            return setPTZXConfigFromMRServer(lhandle, nPTZXID, nPTZXAction, m_nPTZXID, nDeviceId);
        }
        return nResult;
    }

    private static int setPTZXConfigFromServer(LoginHandle lhandle, int nPTZXID, int nPTZXAction, int m_ThreadConfigID) {
        OutputStream writer = null;
        InputStream reader = null;
        int nConfigResultCode = 0;
        if (m_nPTZXID == m_ThreadConfigID) {
            Socket sSocket = Functions.connectToServer(lhandle.getStrLanIP(), lhandle.getnPort(), Defines.CMD_MR_WAIT);
            if (sSocket == null) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                } else {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
            } catch (IOException e) {
                nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e2) {
                    }
                }
                writer = null;
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e3) {
                    }
                }
                reader = null;
                if (sSocket != null) {
                    try {
                        sSocket.close();
                    } catch (IOException e4) {
                    }
                }
                sSocket = null;
            }
            if (m_nPTZXID == m_ThreadConfigID && nConfigResultCode == 0) {
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) Defines.NV_IP_PTZX_REQUEST, buffer, 0);
                if (lhandle.getStrUsername() != null) {
                    System.arraycopy(lhandle.getStrUsername().getBytes(), 0, buffer, 4, lhandle.getStrUsername().getBytes().length);
                }
                if (lhandle.getStrPassword() != null) {
                    System.arraycopy(lhandle.getStrPassword().getBytes(), 0, buffer, 36, lhandle.getStrPassword().getBytes().length);
                }
                Functions.IntToBytes((long) nPTZXAction, buffer, 68);
                Functions.IntToBytes((long) nPTZXID, buffer, 72);
                Functions.IntToBytes((long) lhandle.getnDeviceID(), buffer, 76);
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e5) {
                    try {
                        writer.close();
                        reader.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 5) {
                    try {
                        if (reader.available() >= 64) {
                            reader.read(buffer, 0, 64);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e7) {
                            e7.printStackTrace();
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK) {
                    int nResultCmd = Functions.BytesToInt(buffer, 0);
                    int nResultValue = Functions.BytesToInt(buffer, 4);
                    if (nResultCmd == Defines.NV_IP_PTZX_RESPONSE && nResultValue == 1001) {
                        nConfigResultCode = 256;
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e62) {
                    e62.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
        }
        return nConfigResultCode;
    }

    private static int setPTZXConfigFromMRServer(LoginHandle lhandle, int nPTZXID, int nPTZXAction, int m_ThreadConfigID, int deviceId) {
        OutputStream writer = null;
        InputStream reader = null;
        int nConfigResultCode = 0;
        if (m_nPTZXID == m_ThreadConfigID) {
            Socket sSocket = Functions.connectToMRServer(null, 0, 8000, deviceId);
            if (sSocket == null) {
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                } else {
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
            } catch (IOException e) {
                nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e2) {
                    }
                }
                writer = null;
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e3) {
                    }
                }
                reader = null;
                if (sSocket != null) {
                    try {
                        sSocket.close();
                    } catch (IOException e4) {
                    }
                }
                sSocket = null;
            }
            if (m_nPTZXID == m_ThreadConfigID && nConfigResultCode == 0) {
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) Defines.NV_IP_PTZX_REQUEST, buffer, 0);
                Functions.IntToBytes(1002, buffer, 4);
                if (lhandle.getStrDomain() != null) {
                    System.arraycopy(lhandle.getStrDomain().getBytes(), 0, buffer, 8, lhandle.getStrDomain().getBytes().length);
                }
                Functions.IntToBytes((long) lhandle.getnPort(), buffer, 58);
                if (lhandle.getStrUsername() != null) {
                    System.arraycopy(lhandle.getStrUsername().getBytes(), 0, buffer, 62, lhandle.getStrUsername().getBytes().length);
                }
                if (lhandle.getStrPassword() != null) {
                    System.arraycopy(lhandle.getStrPassword().getBytes(), 0, buffer, 94, lhandle.getStrPassword().getBytes().length);
                }
                Functions.IntToBytes((long) nPTZXAction, buffer, TransportMediator.KEYCODE_MEDIA_PLAY);
                Functions.IntToBytes((long) nPTZXID, buffer, 130);
                Functions.IntToBytes((long) lhandle.getnDeviceID(), buffer, LocalDefines.NV_IP_ALARM_DEVICE_DELETE_REQUEST);
                try {
                    writer.write(buffer, 0, 412);
                    writer.flush();
                } catch (IOException e5) {
                    try {
                        writer.close();
                        reader.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                    nConfigResultCode = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 5) {
                    try {
                        if (reader.available() >= 64) {
                            reader.read(buffer, 0, 64);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e7) {
                            e7.printStackTrace();
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK) {
                    int nResultCmd = Functions.BytesToInt(buffer, 0);
                    int nResultValue = Functions.BytesToInt(buffer, 4);
                    if (nResultCmd == Defines.NV_IP_PTZX_RESPONSE && nResultValue == 1001) {
                        nConfigResultCode = 256;
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e62) {
                    e62.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
            if (sSocket != null) {
                sSocket.close();
            }
        }
        return nConfigResultCode;
    }
}
