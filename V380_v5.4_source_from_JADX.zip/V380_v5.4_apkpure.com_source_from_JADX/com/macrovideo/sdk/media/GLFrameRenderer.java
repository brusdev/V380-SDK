package com.macrovideo.sdk.media;

import android.annotation.SuppressLint;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.Renderer;
import android.util.Log;
import com.macrovideo.sdk.defines.Defines;
import java.nio.ByteBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

@SuppressLint({"SdCardPath"})
class GLFrameRenderer implements Renderer {
    private String Tag = "GLFrameRenderer";
    private boolean isCaptureEnable = false;
    boolean isReverse = false;
    private boolean isSreenSaving = false;
    private int mScreenHeight = -1;
    private int mScreenWidth = -1;
    private int mVideoHeight = -1;
    private int mVideoWidth = -1;
    int nDevID = 0;
    int nID = -1;
    private int nPlayerIndex = 0;
    private int orientation;
    private GLProgram prog;
    String strPassword = null;
    String strUsername = null;
    private ByteBuffer f17u = null;
    private ByteBuffer f18v = null;
    private ByteBuffer f19y = null;

    public void disableCapture() {
        System.out.println("disableCapture: isCaptureEnable=false");
        this.isCaptureEnable = false;
    }

    public int Screenshot() {
        if (Defines._ImagePixel == null) {
            return 0;
        }
        this.isSreenSaving = true;
        Defines._capWidth = this.mVideoWidth;
        Defines._capHeight = this.mVideoHeight;
        int bResult = (this.mVideoWidth * this.mVideoHeight) * 3;
        Defines._capbuffer.clear();
        bResult = LibContext.ConvertYUV2RGB(0, Defines.y0Buf, Defines.u0Buf, Defines.v0Buf, 0, Defines._ImagePixel, this.mVideoWidth, this.mVideoHeight);
        this.isSreenSaving = false;
        return bResult;
    }

    public GLFrameRenderer(GLSurfaceView surface, int orien, int nIndex) {
        this.nPlayerIndex = nIndex;
        switch (this.nPlayerIndex) {
            case 0:
                this.f19y = Defines.y0;
                this.f17u = Defines.u0;
                this.f18v = Defines.v0;
                break;
            case 1:
                this.f19y = Defines.y1;
                this.f17u = Defines.u1;
                this.f18v = Defines.v1;
                break;
            case 2:
                this.f19y = Defines.y2;
                this.f17u = Defines.u2;
                this.f18v = Defines.v2;
                break;
            case 3:
                this.f19y = Defines.y3;
                this.f17u = Defines.u3;
                this.f18v = Defines.v3;
                break;
            default:
                this.nPlayerIndex = 0;
                this.f19y = Defines.y0;
                this.f17u = Defines.u0;
                this.f18v = Defines.v0;
                break;
        }
        this.orientation = orien;
    }

    public void onOreintationChange(int oreintation) {
        if (this.prog != null) {
            this.prog.ResetBuffer(oreintation);
        }
    }

    public void scale(float fX, float fY) {
        this.prog.scale(fX, fY);
    }

    public void onSurfaceChanged(GL10 gl, int width, int height) {
        try {
            GLES20.glViewport(0, 0, width, height);
            this.mScreenWidth = width;
            this.mScreenHeight = height;
        } catch (Exception e) {
            System.out.println("GLFrameRenderer :: onSurfaceChanged err");
        }
        Log.i(this.Tag, "onSurfaceChanged (" + this.mScreenWidth + ",  " + height + ")");
    }

    public boolean updateRenderData(byte[] data, int nWidth, int nHeight) {
        if (this.isSreenSaving || this.f19y == null || this.f17u == null || this.f18v == null || data == null || nWidth <= 0 || nHeight <= 0) {
            return false;
        }
        synchronized (this) {
            this.f19y.clear();
            this.f17u.clear();
            this.f18v.clear();
            this.mVideoWidth = nWidth;
            this.mVideoHeight = nHeight;
            try {
                this.f19y.put(data, 0, nWidth * nHeight);
                this.f17u.put(data, nWidth * nHeight, (nWidth * nHeight) / 4);
                this.f18v.put(data, ((nWidth * nHeight) * 5) / 4, (nWidth * nHeight) / 4);
                this.f19y.flip();
                this.f17u.flip();
                this.f18v.flip();
            } catch (Exception e) {
                Log.i("update", e.toString());
                switch (this.nPlayerIndex) {
                    case 0:
                        this.f19y = Defines.y0;
                        this.f17u = Defines.u0;
                        this.f18v = Defines.v0;
                        break;
                    case 1:
                        this.f19y = Defines.y1;
                        this.f17u = Defines.u1;
                        this.f18v = Defines.v1;
                        break;
                    case 2:
                        this.f19y = Defines.y2;
                        this.f17u = Defines.u2;
                        this.f18v = Defines.v2;
                        break;
                    case 3:
                        this.f19y = Defines.y3;
                        this.f17u = Defines.u3;
                        this.f18v = Defines.v3;
                        break;
                    default:
                        this.nPlayerIndex = 0;
                        this.f19y = Defines.y0;
                        this.f17u = Defines.u0;
                        this.f18v = Defines.v0;
                        break;
                }
                return false;
            }
        }
        return true;
    }

    public void onDrawFrame(GL10 gl) {
        synchronized (this) {
            if (this.f19y != null) {
                GLES20.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
                GLES20.glClear(16384);
                if (this.mVideoWidth > 0 && this.mVideoHeight > 0) {
                    this.prog.buildTextures(this.f19y, this.f17u, this.f18v, this.mVideoWidth, this.mVideoHeight);
                    this.prog.drawFrame();
                }
            }
            if (this.isCaptureEnable) {
                this.isCaptureEnable = false;
            }
        }
    }

    public void setReverse(boolean isReverse) {
        this.isReverse = isReverse;
        if (this.prog != null) {
            this.prog.setReverse(isReverse);
        }
    }

    public void captureScreenAndSave(int nID, int nDevID, String strUsername, String strPassword) {
        this.nID = nID;
        this.nDevID = nDevID;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.isCaptureEnable = true;
    }

    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        this.prog = new GLProgram(this.orientation);
        if (this.prog != null) {
            this.prog.setReverse(this.isReverse);
        }
        if (!this.prog.isProgramBuilt()) {
            this.prog.buildProgram();
        }
    }

    public GLProgram getProgram() {
        return this.prog;
    }
}
