package com.macrovideo.sdk.media;

import android.util.Log;
import android.widget.ProgressBar;

public class Player {
    public static final int BOTTOM = 1;
    public static final int DOUBLE_CLICK_VAL = 350;
    public static final int PLAYER_NUM = 4;
    public static final int TOP = 0;
    public static final int WND_ID_0 = 0;
    public static final int WND_ID_1 = 1;
    public static final int WND_ID_2 = 2;
    public static final int WND_ID_3 = 3;
    private static boolean[] isPlaying = new boolean[4];
    private static boolean[] isSelected = new boolean[4];
    private static ProgressBar[] prog_b = new ProgressBar[4];
    private static int selWnd = 4;

    public static void SelectWindow(int WndID) {
        boolean[] zArr;
        switch (WndID) {
            case 0:
                selWnd = 0;
                zArr = isSelected;
                if (isSelected[0]) {
                    zArr[0] = true;
                    zArr = isSelected;
                } else {
                    zArr[0] = true;
                    zArr = isSelected;
                }
                if (isSelected[1]) {
                    zArr[1] = false;
                    zArr = isSelected;
                } else {
                    zArr[1] = false;
                    zArr = isSelected;
                }
                if (isSelected[2]) {
                    zArr[2] = false;
                    zArr = isSelected;
                } else {
                    zArr[2] = false;
                    zArr = isSelected;
                }
                if (isSelected[3]) {
                    zArr[3] = false;
                } else {
                    zArr[3] = false;
                }
                return;
            case 1:
                selWnd = 1;
                zArr = isSelected;
                if (isSelected[0]) {
                    zArr[0] = false;
                    zArr = isSelected;
                } else {
                    zArr[0] = false;
                    zArr = isSelected;
                }
                if (isSelected[1]) {
                    zArr[1] = true;
                    zArr = isSelected;
                } else {
                    zArr[1] = true;
                    zArr = isSelected;
                }
                if (isSelected[2]) {
                    zArr[2] = false;
                    zArr = isSelected;
                } else {
                    zArr[2] = false;
                    zArr = isSelected;
                }
                if (isSelected[3]) {
                    zArr[3] = false;
                } else {
                    zArr[3] = false;
                }
                return;
            case 2:
                selWnd = 2;
                zArr = isSelected;
                if (isSelected[0]) {
                    zArr[0] = false;
                    zArr = isSelected;
                } else {
                    zArr[0] = false;
                    zArr = isSelected;
                }
                if (isSelected[1]) {
                    zArr[1] = false;
                    zArr = isSelected;
                } else {
                    zArr[1] = false;
                    zArr = isSelected;
                }
                if (isSelected[2]) {
                    zArr[2] = true;
                    zArr = isSelected;
                } else {
                    zArr[2] = true;
                    zArr = isSelected;
                }
                if (isSelected[3]) {
                    zArr[3] = false;
                } else {
                    zArr[3] = false;
                }
                return;
            case 3:
                selWnd = 3;
                zArr = isSelected;
                if (isSelected[0]) {
                    zArr[0] = false;
                    zArr = isSelected;
                } else {
                    zArr[0] = false;
                    zArr = isSelected;
                }
                if (isSelected[1]) {
                    zArr[1] = false;
                    zArr = isSelected;
                } else {
                    zArr[1] = false;
                    zArr = isSelected;
                }
                if (isSelected[2]) {
                    zArr[2] = false;
                    zArr = isSelected;
                } else {
                    zArr[2] = false;
                    zArr = isSelected;
                }
                if (isSelected[3]) {
                    zArr[3] = true;
                } else {
                    zArr[3] = true;
                }
                return;
            default:
                return;
        }
    }

    public static void setPlaying(int WndID, boolean _isPlaying) {
        if (WndID >= 0 && WndID < isSelected.length) {
            isPlaying[WndID] = _isPlaying;
        }
    }

    public static boolean isWindowPlaying(int WndID) {
        if (WndID < 0 || WndID >= isSelected.length) {
            return false;
        }
        return isPlaying[WndID];
    }

    public static boolean isWindowSelected(int WndID) {
        if (WndID < 0 || WndID >= isSelected.length) {
            return false;
        }
        return isPlaying[WndID];
    }

    public static int CurrentSelPlayer() {
        return selWnd;
    }

    public static void ClearGLESScreen(NVMediaPlayer[] glViews, boolean isAll, int WndID) {
        if (isAll) {
            for (int i = 0; i < 4; i++) {
                glViews[i].ClearRenderWithFace();
            }
        } else if (WndID >= 0 && WndID < 4) {
            glViews[WndID].ClearRenderWithFace();
        }
    }

    public static void ClearGLESScreen(NVPanoPlayer[] glViews, boolean isAll, int WndID) {
        if (isAll) {
            for (int i = 0; i < 4; i++) {
                glViews[i].ClearRenderWithFace();
            }
        } else if (WndID >= 0 && WndID < 4) {
            glViews[WndID].ClearRenderWithFace();
        }
    }

    public static void GLESRenderEnable(NVMediaPlayer[] glViews, boolean isAll, int WndID, boolean isEnable) {
        if (!isAll && (WndID < 0 || WndID >= glViews.length)) {
            return;
        }
        if (isAll) {
            for (int i = 0; i < glViews.length; i++) {
                if (isEnable) {
                    glViews[i].EnableRender();
                } else {
                    glViews[i].DisableRender();
                }
            }
        } else if (WndID >= 0 && WndID < 4) {
            if (isEnable) {
                glViews[WndID].EnableRender();
            } else {
                glViews[WndID].DisableRender();
            }
        }
    }

    public static void ShowProgressBar(int WndID, boolean isShow) {
        if (WndID >= 0 && WndID < 4) {
            if (isShow) {
                Log.d("Player", "Show Progress Bar");
                prog_b[WndID].setVisibility(0);
                return;
            }
            Log.d("Player", "Hide Progress Bar");
            prog_b[WndID].setVisibility(8);
        }
    }

    public static void GetProgressBars(ProgressBar prog, int WndID) {
        prog_b[WndID] = prog;
    }
}
