package com.macrovideo.sdk.media;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.EGLConfigChooser;
import android.opengl.GLSurfaceView.EGLContextFactory;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.macrovideo.sdk.custom.RecordFileInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.media.audio.AudioDataCache;
import com.macrovideo.sdk.media.audio.AudioDataObject;
import com.macrovideo.sdk.tools.Functions;
import java.util.Arrays;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;

public class NVMediaPlayer extends GLSurfaceView {
    private static final boolean DEBUG = false;
    private static final int STAT_PLAYING = 12;
    private static final int STAT_PUASE = 10;
    private static final int STAT_STOP = 11;
    static int currentapiVersion = VERSION.SDK_INT;
    private Handler hdl;
    private Bitmap image = null;
    private boolean isCaptureEnable = false;
    private boolean isPlaying = false;
    private boolean isRenderEnable = false;
    private boolean isReverse = false;
    private AudioDataCache mAudioCache = new AudioDataCache();
    private AudioPlayerThread mAudioPlayer = null;
    private boolean mIsSpeaking = false;
    private boolean mPlaySound = true;
    private GLFrameRenderer mRenderer;
    private int nCurrentPlayWnd = -1;
    private int nPlayAudioStat = 11;
    private int nPlayerIndex = 0;
    private Saudioclient nSAudioRecorder = null;
    private int nServerID = 0;
    private int orientation;

    private class AudioPlayerThread extends Thread {
        private boolean isSpeakingPuase;
        private AudioTrack mAudioTrack;
        int mChannel;
        int mFrequency;
        private int mPlayOffset;
        private int mPrimePlaySize;
        int mSampBit;
        private int mStat;
        int minBufSize;
        private int nPCMDataSize;
        private byte[] pcmData;

        private AudioPlayerThread() {
            this.nPCMDataSize = 2048;
            this.pcmData = new byte[this.nPCMDataSize];
            this.mStat = 1;
            this.mFrequency = 8000;
            this.mChannel = 4;
            this.mSampBit = 2;
            this.minBufSize = AudioTrack.getMinBufferSize(this.mFrequency, this.mChannel, this.mSampBit);
            this.mAudioTrack = new AudioTrack(3, this.mFrequency, this.mChannel, this.mSampBit, this.minBufSize * 4, 1);
            this.mPrimePlaySize = 0;
            this.mPlayOffset = 0;
            this.isSpeakingPuase = false;
        }

        public void setStat(int stat) {
            this.mStat = stat;
        }

        public void run() {
            this.mAudioTrack.play();
            this.mPrimePlaySize = this.minBufSize * 4;
            while (this.mStat == 1) {
                if (NVMediaPlayer.this.nPlayAudioStat == 10 || NVMediaPlayer.this.mIsSpeaking) {
                    this.mAudioTrack.stop();
                    this.isSpeakingPuase = true;
                } else if (this.isSpeakingPuase) {
                    this.mAudioTrack.play();
                    this.isSpeakingPuase = false;
                }
                AudioDataObject dataOject = NVMediaPlayer.this.getAudioData();
                if (dataOject == null || !NVMediaPlayer.this.mPlaySound || NVMediaPlayer.this.nPlayAudioStat != 12 || NVMediaPlayer.this.mIsSpeaking) {
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else {
                    this.nPCMDataSize = 0;
                    byte[] data = dataOject.getM_Data();
                    if (data.length <= 2048) {
                        System.arraycopy(data, 0, this.pcmData, 0, data.length);
                        this.nPCMDataSize = data.length;
                        if (data != null && this.mStat == 1) {
                            this.mPlayOffset = 0;
                            while (this.mStat == 1) {
                                try {
                                    this.mPlayOffset += this.mAudioTrack.write(this.pcmData, this.mPlayOffset, this.nPCMDataSize - this.mPlayOffset);
                                    if (this.mPlayOffset >= this.nPCMDataSize) {
                                        break;
                                    }
                                } catch (Exception e2) {
                                    System.out.println("S: " + e2.toString());
                                }
                            }
                        }
                    }
                }
            }
            this.mAudioTrack.stop();
        }
    }

    private static class ConfigChooser implements EGLConfigChooser {
        private static int EGL_OPENGL_ES2_BIT = 4;
        private static int[] s_configAttribs2 = new int[]{12324, 4, 12323, 4, 12322, 4, 12352, EGL_OPENGL_ES2_BIT, 12344};
        protected int mAlphaSize;
        protected int mBlueSize;
        protected int mDepthSize;
        protected int mGreenSize;
        protected int mRedSize;
        protected int mStencilSize;
        private int[] mValue = new int[1];

        public ConfigChooser(int r, int g, int b, int a, int depth, int stencil) {
            this.mRedSize = r;
            this.mGreenSize = g;
            this.mBlueSize = b;
            this.mAlphaSize = a;
            this.mDepthSize = depth;
            this.mStencilSize = stencil;
        }

        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
            int[] num_config = new int[1];
            egl.eglChooseConfig(display, s_configAttribs2, null, 0, num_config);
            int numConfigs = num_config[0];
            if (numConfigs <= 0) {
                throw new IllegalArgumentException("No configs match configSpec");
            }
            EGLConfig[] configs = new EGLConfig[numConfigs];
            egl.eglChooseConfig(display, s_configAttribs2, configs, numConfigs, num_config);
            return chooseConfig(egl, display, configs);
        }

        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
            for (EGLConfig config : configs) {
                int d = findConfigAttrib(egl, display, config, 12325, 0);
                int s = findConfigAttrib(egl, display, config, 12326, 0);
                if (d >= this.mDepthSize && s >= this.mStencilSize) {
                    int r = findConfigAttrib(egl, display, config, 12324, 0);
                    int g = findConfigAttrib(egl, display, config, 12323, 0);
                    int b = findConfigAttrib(egl, display, config, 12322, 0);
                    int a = findConfigAttrib(egl, display, config, 12321, 0);
                    if (r == this.mRedSize && g == this.mGreenSize && b == this.mBlueSize && a == this.mAlphaSize) {
                        return config;
                    }
                }
            }
            return null;
        }

        private int findConfigAttrib(EGL10 egl, EGLDisplay display, EGLConfig config, int attribute, int defaultValue) {
            if (egl.eglGetConfigAttrib(display, config, attribute, this.mValue)) {
                return this.mValue[0];
            }
            return defaultValue;
        }

        private void printConfigs(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
            for (EGLConfig printConfig : configs) {
                printConfig(egl, display, printConfig);
            }
        }

        private void printConfig(EGL10 egl, EGLDisplay display, EGLConfig config) {
            int[] attributes = new int[]{12320, 12321, 12322, 12323, 12324, 12325, 12326, 12327, 12328, 12329, 12330, 12331, 12332, 12333, 12334, 12335, 12336, 12337, 12338, 12339, 12340, 12343, 12342, 12341, 12345, 12346, 12347, 12348, 12349, 12350, 12351, 12352, 12354};
            String[] names = new String[]{"EGL_BUFFER_SIZE", "EGL_ALPHA_SIZE", "EGL_BLUE_SIZE", "EGL_GREEN_SIZE", "EGL_RED_SIZE", "EGL_DEPTH_SIZE", "EGL_STENCIL_SIZE", "EGL_CONFIG_CAVEAT", "EGL_CONFIG_ID", "EGL_LEVEL", "EGL_MAX_PBUFFER_HEIGHT", "EGL_MAX_PBUFFER_PIXELS", "EGL_MAX_PBUFFER_WIDTH", "EGL_NATIVE_RENDERABLE", "EGL_NATIVE_VISUAL_ID", "EGL_NATIVE_VISUAL_TYPE", "EGL_PRESERVED_RESOURCES", "EGL_SAMPLES", "EGL_SAMPLE_BUFFERS", "EGL_SURFACE_TYPE", "EGL_TRANSPARENT_TYPE", "EGL_TRANSPARENT_RED_VALUE", "EGL_TRANSPARENT_GREEN_VALUE", "EGL_TRANSPARENT_BLUE_VALUE", "EGL_BIND_TO_TEXTURE_RGB", "EGL_BIND_TO_TEXTURE_RGBA", "EGL_MIN_SWAP_INTERVAL", "EGL_MAX_SWAP_INTERVAL", "EGL_LUMINANCE_SIZE", "EGL_ALPHA_MASK_SIZE", "EGL_COLOR_BUFFER_TYPE", "EGL_RENDERABLE_TYPE", "EGL_CONFORMANT"};
            int[] value = new int[1];
            for (int i = 0; i < attributes.length; i++) {
                int attribute = attributes[i];
                String name = names[i];
                if (!egl.eglGetConfigAttrib(display, config, attribute, value)) {
                    do {
                    } while (egl.eglGetError() != Defines.PARAM_NONE);
                }
            }
        }
    }

    private static class ContextFactory implements EGLContextFactory {
        private static int EGL_CONTEXT_CLIENT_VERSION = 12440;

        private ContextFactory() {
        }

        public EGLContext createContext(EGL10 egl, EGLDisplay display, EGLConfig eglConfig) {
            NVMediaPlayer.checkEglError("Before eglCreateContext", egl);
            EGLContext context = egl.eglCreateContext(display, eglConfig, EGL10.EGL_NO_CONTEXT, new int[]{EGL_CONTEXT_CLIENT_VERSION, 2, 12344});
            NVMediaPlayer.checkEglError("After eglCreateContext", egl);
            return context;
        }

        public void destroyContext(EGL10 egl, EGLDisplay display, EGLContext context) {
            egl.eglDestroyContext(display, context);
        }
    }

    public class Saudioclient extends Thread {
        protected int inMinBufferSize = 1024;
        private boolean isInit = false;
        protected AudioRecord mAudioRecorder;
        protected byte[] mBuffers = null;
        int mChannel = 16;
        int mFrequency = 8000;
        private boolean mIsRecording = false;
        protected boolean mIsThreadRunning = true;
        int mSampBit = 2;

        public void StartRecord() {
            if (this.mAudioRecorder != null) {
                try {
                    this.mAudioRecorder.startRecording();
                    this.mIsRecording = true;
                } catch (Exception e) {
                    this.mIsRecording = false;
                }
            }
        }

        public void StopRecord() {
            if (this.mAudioRecorder != null) {
                try {
                    this.mAudioRecorder.stop();
                } catch (Exception e) {
                }
            }
            this.mIsRecording = false;
        }

        public void run() {
            int nID = 0;
            while (this.mIsThreadRunning) {
                if (!this.mIsRecording) {
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else if (this.mAudioRecorder.getState() == 1 && this.mIsThreadRunning) {
                    int nDataRead;
                    Arrays.fill(this.mBuffers, (byte) 0);
                    try {
                        nDataRead = this.mAudioRecorder.read(this.mBuffers, 0, 1010);
                    } catch (Exception e2) {
                        nDataRead = 0;
                    }
                    if (nDataRead > 0) {
                        nID++;
                        LibContext.SendSpeakAudioData(0, this.mBuffers, nDataRead, nID, 21);
                    }
                }
            }
            this.mIsThreadRunning = false;
        }

        public void init() {
            if (!this.isInit) {
                this.inMinBufferSize = AudioRecord.getMinBufferSize(this.mFrequency, this.mChannel, this.mSampBit);
                if (this.inMinBufferSize < 1010) {
                    this.inMinBufferSize = 1010;
                }
                this.mBuffers = new byte[this.inMinBufferSize];
                this.mAudioRecorder = new AudioRecord(1, this.mFrequency, this.mChannel, this.mSampBit, this.inMinBufferSize);
                this.mIsThreadRunning = true;
                this.isInit = true;
            }
        }

        public void release() {
            this.mIsThreadRunning = false;
            try {
                this.mAudioRecorder.stop();
                this.mAudioRecorder = null;
            } catch (Exception e) {
            }
        }
    }

    public void pauseAudio() {
        this.nPlayAudioStat = 10;
        if (this.isPlaying) {
            LibContext.SetAudioParam(this.nCurrentPlayWnd, false, true);
        }
    }

    public void playAudio() {
        this.nPlayAudioStat = 12;
        if (this.isPlaying) {
            LibContext.SetAudioParam(this.nCurrentPlayWnd, true, true);
        }
    }

    public void setReverse(boolean isReverse) {
        this.isReverse = isReverse;
        if (this.mRenderer != null) {
            this.mRenderer.setReverse(isReverse);
        }
    }

    public NVMediaPlayer(Context context) {
        super(context);
        init(false, 0, 0);
    }

    public NVMediaPlayer(Context context, int orien, int nIndex) {
        super(context);
        this.nPlayerIndex = nIndex;
        this.orientation = orien;
        init(false, 0, 0);
    }

    public NVMediaPlayer(Context context, boolean translucent, int depth, int stencil) {
        super(context);
        init(translucent, depth, stencil);
    }

    public void scale(float fX, float fY) {
        if (this.mRenderer != null) {
            this.mRenderer.scale(fX, fY);
        }
    }

    private void init(boolean translucent, int depth, int stencil) {
        EGLConfigChooser configChooser;
        if (translucent) {
            getHolder().setFormat(-3);
        }
        setEGLContextFactory(new ContextFactory());
        if (translucent) {
            configChooser = new ConfigChooser(8, 8, 8, 8, depth, stencil);
        } else {
            configChooser = new ConfigChooser(5, 6, 5, 0, depth, stencil);
        }
        setEGLConfigChooser(configChooser);
        this.mRenderer = new GLFrameRenderer(this, this.orientation, this.nPlayerIndex);
        if (this.mRenderer != null) {
            this.mRenderer.setReverse(this.isReverse);
        }
        setRenderer(this.mRenderer);
    }

    public Bitmap Screenshot() {
        if (this.mRenderer == null || !this.isCaptureEnable) {
            return null;
        }
        System.out.println("Screenshot ");
        if (this.image != null) {
            this.image.recycle();
            this.image = null;
        }
        if (this.mRenderer.Screenshot() > 0) {
            this.image = Bitmap.createBitmap(Defines._capWidth, Defines._capHeight, Config.RGB_565);
            this.image.copyPixelsFromBuffer(Defines._capbuffer);
            Defines._capbuffer.position(0);
        }
        return this.image;
    }

    public void setnServerID(int nServerID) {
        this.nServerID = nServerID;
    }

    public void updateRenderData(int nWidth, int nHeight, byte[] data, long lTime) {
        if (this.isRenderEnable && this.mRenderer != null && data != null && nWidth > 0 && nHeight > 0 && this.mRenderer.updateRenderData(data, nWidth, nHeight)) {
            requestRender();
            this.isCaptureEnable = true;
        }
    }

    public void updatePlayBackIndex(int nWndID, int nTimeIndex) {
        System.out.println("updatePlayBackIndex: " + nWndID + ", " + nTimeIndex);
        if (this.hdl != null) {
            Message msg = this.hdl.obtainMessage();
            msg.arg1 = 2;
            msg.arg2 = nTimeIndex;
            this.hdl.sendMessage(msg);
        }
    }

    public void captureScreenAndSave(int nID, int nDevID, String strUsername, String strPassword) {
        if (this.isPlaying && this.isCaptureEnable && this.isRenderEnable && this.mRenderer != null) {
            this.mRenderer.captureScreenAndSave(nID, nDevID, strUsername, strPassword);
        }
    }

    public void SetAudioDataEx(int nType, int nSize, byte[] data) {
        if (this.mAudioCache != null) {
            this.mAudioCache.PutDataEx(data, nSize, 0, nType);
        }
    }

    public void SetAudioData(int nType, int nSize, byte[] data) {
        if (this.mAudioCache != null) {
            this.mAudioCache.PutData(data, 0, nSize, nType);
        }
    }

    private AudioDataObject getAudioData() {
        if (this.mAudioCache == null || !this.mAudioCache.hasData()) {
            return null;
        }
        return this.mAudioCache.getData();
    }

    public void ClearRenderWithFace() {
        if (this.mRenderer != null) {
            this.mRenderer.disableCapture();
            this.isCaptureEnable = false;
            if (this.mRenderer.updateRenderData(Defines._playFaceYUVData, 0, 0)) {
                requestRender();
            }
        }
    }

    public void DisableRender() {
        this.isRenderEnable = false;
    }

    public void EnableRender() {
        this.isRenderEnable = true;
    }

    private static void checkEglError(String prompt, EGL10 egl) {
        do {
        } while (egl.eglGetError() != Defines.PARAM_NONE);
    }

    public void onOreintationChange(int oreintation) {
        if (this.mRenderer != null) {
            this.mRenderer.onOreintationChange(oreintation);
        }
    }

    public GLFrameRenderer getRenderer() {
        return this.mRenderer;
    }

    public void GetHandler(Handler handler) {
        this.hdl = handler;
    }

    public void PassMessage(int WndID, int isShow) {
        if (this.hdl != null) {
            Message msg = this.hdl.obtainMessage();
            if (isShow == 1) {
                msg.arg1 = 1;
                msg.arg2 = WndID;
                this.hdl.sendMessage(msg);
                return;
            }
            msg.arg1 = 0;
            msg.arg2 = WndID;
            this.hdl.sendMessage(msg);
        }
    }

    public boolean SetCamImageOrientation(int orientation) {
        if (this.nCurrentPlayWnd < 0 || this.nCurrentPlayWnd >= 3) {
            return false;
        }
        return LibContext.SetCamImageOrientation(this.nCurrentPlayWnd, orientation);
    }

    public boolean SetAudioParam(boolean isAudioEnable) {
        if (this.nCurrentPlayWnd < 0 || this.nCurrentPlayWnd >= 3) {
            return false;
        }
        this.mPlaySound = isAudioEnable;
        Log.w("ttt", "SetAudioParam: " + this.nCurrentPlayWnd + ", " + isAudioEnable);
        return LibContext.SetAudioParam(this.nCurrentPlayWnd, isAudioEnable, true);
    }

    public boolean FocusIn() {
        if (this.nCurrentPlayWnd < 0 || this.nCurrentPlayWnd >= 3) {
            return false;
        }
        return LibContext.FocuseIn(this.nCurrentPlayWnd, 1);
    }

    public boolean FocusOut() {
        if (this.nCurrentPlayWnd < 0 || this.nCurrentPlayWnd >= 3) {
            return false;
        }
        return LibContext.FocuseOut(this.nCurrentPlayWnd, 1);
    }

    public boolean SendPTZAction(boolean left, boolean right, boolean up, boolean down, int step) {
        if (this.nCurrentPlayWnd < 0 || this.nCurrentPlayWnd >= 3) {
            return false;
        }
        return LibContext.SetPTZParam(this.nCurrentPlayWnd, false, 0, false, 0, left, right, up, down, step);
    }

    public boolean StopPlay() {
        this.isPlaying = false;
        this.isCaptureEnable = false;
        if (this.nCurrentPlayWnd >= 0) {
            LibContext.StopPlay(this.nCurrentPlayWnd, false);
        }
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (this.nSAudioRecorder != null) {
            try {
                this.nSAudioRecorder.StopRecord();
                this.nSAudioRecorder.release();
                this.nSAudioRecorder = null;
            } catch (Exception e) {
            }
        }
        this.nCurrentPlayWnd = -1;
        return true;
    }

    public boolean StartPlay(int nPlayWnd, int nChn, int nStreamType, boolean isAudioEnable, LoginHandle deviceParam) {
        if (nPlayWnd < 0 || nPlayWnd >= 3 || deviceParam == null) {
            return false;
        }
        String strMRServer;
        ClearRenderWithFace();
        if (this.isPlaying) {
            StopPlay();
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
        this.mPlaySound = isAudioEnable;
        this.nCurrentPlayWnd = nPlayWnd;
        this.isPlaying = true;
        this.isCaptureEnable = false;
        boolean isMRMode = deviceParam.isMRMode();
        if (Functions.getIsPanoDevice(deviceParam.getnDeviceID())) {
            strMRServer = Functions._strCurrentPanoMRServer;
        } else {
            strMRServer = Functions._strCurrentMRServer;
        }
        int nMRPort = Functions._nCurrentMRPort;
        if (deviceParam.isSetMRServer()) {
            strMRServer = deviceParam.getStrMRServer();
            nMRPort = deviceParam.getnMRPort();
        }
        boolean playResult = LibContext.StartPlay(nPlayWnd, nChn, deviceParam.getnDeviceID(), deviceParam.getStrDomain(), deviceParam.getStrIP(), deviceParam.getStrLanIP(), deviceParam.getnPort(), deviceParam.getStrUsername(), deviceParam.getStrPassword(), deviceParam.isbInLan(), nStreamType, isAudioEnable, deviceParam.isbAudio(), deviceParam.isbSpeak(), deviceParam.isbPTZ(), isMRMode, strMRServer, nMRPort);
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (!playResult) {
            return playResult;
        }
        try {
            NVMediaPlayer nVMediaPlayer = this;
            this.mAudioPlayer = new AudioPlayerThread();
            this.mAudioPlayer.setStat(1);
            this.mAudioPlayer.start();
        } catch (Exception e2) {
        }
        try {
            this.nSAudioRecorder = new Saudioclient();
            this.nSAudioRecorder.init();
            this.nSAudioRecorder.start();
            return playResult;
        } catch (Exception e3) {
            return playResult;
        }
    }

    private boolean StartPlay(int PlayWnd, int nChn, int nDeviceID, String strDomain, String strIP, String strLanIP, int nPort, String strUsername, String strPassword, boolean isInLan, int nStreamType, boolean isAudioEnable, boolean bAudioPri, boolean bSpeakPri, boolean bPTZPri, boolean isMRMode, String strMRServer, int nMRPort) {
        if (PlayWnd < 0 || PlayWnd >= 3) {
            return false;
        }
        if (this.isPlaying) {
            StopPlay();
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
        this.nCurrentPlayWnd = PlayWnd;
        this.isPlaying = true;
        this.isCaptureEnable = false;
        boolean playResult = LibContext.StartPlay(PlayWnd, nChn, nDeviceID, strDomain, strIP, strLanIP, nPort, strUsername, strPassword, isInLan, nStreamType, isAudioEnable, bAudioPri, bSpeakPri, bPTZPri, isMRMode, strMRServer, nMRPort);
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (!playResult) {
            return playResult;
        }
        try {
            this.mAudioPlayer = new AudioPlayerThread();
            this.mAudioPlayer.setStat(1);
            this.mAudioPlayer.start();
        } catch (Exception e2) {
        }
        try {
            this.nSAudioRecorder = new Saudioclient();
            this.nSAudioRecorder.init();
            this.nSAudioRecorder.start();
            return playResult;
        } catch (Exception e3) {
            return playResult;
        }
    }

    public boolean StartPlayBack(int nPlayWnd, LoginHandle deviceParam, RecordFileInfo recFile, boolean isAudioEnable) {
        if (this.isPlaying) {
            LibContext.StopPlayBack(this.nCurrentPlayWnd, true);
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
        this.mPlaySound = isAudioEnable;
        this.nCurrentPlayWnd = nPlayWnd;
        boolean bResult = false;
        if (this.nCurrentPlayWnd >= 0) {
            bResult = LibContext.StartPlayBack(this.nCurrentPlayWnd, deviceParam.getnDeviceID(), deviceParam.getStrDomain(), deviceParam.getStrIP(), deviceParam.getStrLanIP(), deviceParam.getnPort(), deviceParam.getStrUsername(), deviceParam.getStrPassword(), (int) deviceParam.getlHandle(), recFile.getnFileID(), recFile.getStrFileName(), 0, recFile.getuStartHour(), recFile.getuStartMin(), recFile.getuStartSec(), deviceParam.isMRMode(), Functions._strCurrentMRServer, Functions._nCurrentMRPort);
        }
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (bResult) {
            try {
                NVMediaPlayer nVMediaPlayer = this;
                this.mAudioPlayer = new AudioPlayerThread();
                this.mAudioPlayer.setStat(1);
                this.mAudioPlayer.start();
            } catch (Exception e2) {
            }
        }
        return bResult;
    }

    private boolean StartPlayBack(int nPlayWnd, int nDeviceID, String strDomain, String strIP, String strLanIP, int nPort, String strUsername, String strPassword, int lLoginHandle, int nFileID, String strFileName, int nFileTime, int uStartHour, int uStartMin, int uStartSec, boolean isMRMode, String strMRServer, int nMRPort) {
        if (this.isPlaying) {
            LibContext.StopPlayBack(this.nCurrentPlayWnd, true);
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
        this.nCurrentPlayWnd = nPlayWnd;
        boolean bResult = false;
        if (this.nCurrentPlayWnd >= 0) {
            bResult = LibContext.StartPlayBack(nPlayWnd, nDeviceID, strDomain, strIP, strLanIP, nPort, strUsername, strPassword, lLoginHandle, nFileID, strFileName, nFileTime, uStartHour, uStartMin, uStartSec, isMRMode, strMRServer, nMRPort);
        }
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (bResult) {
            try {
                this.mAudioPlayer = new AudioPlayerThread();
                this.mAudioPlayer.setStat(1);
                this.mAudioPlayer.start();
            } catch (Exception e2) {
            }
        }
        return bResult;
    }

    public boolean StopPlayBack() {
        if (this.nCurrentPlayWnd >= 0) {
            return LibContext.StopPlayBack(this.nCurrentPlayWnd, true);
        }
        return false;
    }

    public boolean SetPlayIndex(int nTimeIndex) {
        if (this.nCurrentPlayWnd >= 0) {
            return LibContext.SetPlayIndex(this.nCurrentPlayWnd, nTimeIndex);
        }
        return false;
    }

    public boolean FinishPlayback() {
        if (this.nCurrentPlayWnd >= 0) {
            return LibContext.FinishPlayback(this.nCurrentPlayWnd);
        }
        return false;
    }

    public boolean CallPTZXLocationID(int nPTZXID, LoginHandle deviceParam) {
        if (this.nCurrentPlayWnd < 0 || this.nCurrentPlayWnd >= 3) {
            return false;
        }
        return LibContext.SetPTZXParam(this.nCurrentPlayWnd, 103, nPTZXID);
    }

    public int SetPTZXLocationID(int nPTZXID, LoginHandle deviceParam, int deviceId) {
        return PTZXCotroller.setPTZXPoint(deviceParam, nPTZXID, 102, deviceId);
    }

    public boolean StartSpeak() {
        if (this.nCurrentPlayWnd < 0 || this.nCurrentPlayWnd >= 3 || !this.isPlaying) {
            return false;
        }
        LibContext.StartSpeak(this.nCurrentPlayWnd);
        this.nSAudioRecorder.StartRecord();
        return true;
    }

    public boolean StopSpeak() {
        if (this.nCurrentPlayWnd < 0 || this.nCurrentPlayWnd >= 3 || !this.isPlaying) {
            return false;
        }
        this.nSAudioRecorder.StopRecord();
        LibContext.StopSpeak(0);
        return true;
    }

    public boolean StartRecord(String strFilePath) {
        if (this.isPlaying) {
            return LibContext.StartRecord(this.nCurrentPlayWnd, strFilePath);
        }
        return false;
    }

    public boolean StopRecord() {
        return LibContext.StopRecord(this.nCurrentPlayWnd);
    }

    public boolean StartCloudPlayBack(int nPlayWnd, int nAccountID, int nDeviceID, String strPrivateToken, String strServerToken, String strIP, int nPort, RecordFileInfo recFile, boolean isAudioEnable) {
        if (this.isPlaying) {
            LibContext.StopCloudPlayBack(this.nCurrentPlayWnd, true);
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
        this.mPlaySound = isAudioEnable;
        this.nCurrentPlayWnd = nPlayWnd;
        boolean bResult = false;
        if (this.nCurrentPlayWnd >= 0) {
            bResult = LibContext.StartCloudPlayBack(this.nCurrentPlayWnd, nAccountID, nDeviceID, strPrivateToken, strServerToken, strIP, nPort, recFile.getnFileID(), recFile.getStrFileName(), 0, recFile.getuStartHour(), recFile.getuStartMin(), recFile.getuStartSec());
        }
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (this.mAudioPlayer != null) {
            this.mAudioPlayer.setStat(-1);
            this.mAudioPlayer = null;
        }
        if (bResult) {
            try {
                NVMediaPlayer nVMediaPlayer = this;
                this.mAudioPlayer = new AudioPlayerThread();
                this.mAudioPlayer.setStat(1);
                this.mAudioPlayer.start();
            } catch (Exception e2) {
            }
        }
        return bResult;
    }

    public boolean StopCloudPlayBack() {
        if (this.nCurrentPlayWnd >= 0) {
            return LibContext.StopCloudPlayBack(this.nCurrentPlayWnd, true);
        }
        return false;
    }
}
