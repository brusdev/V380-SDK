package com.macrovideo.sdk.media;

public interface IDownloadCallback {
    public static final int DSTAT_DOWNLOADING = 0;
    public static final int DSTAT_ERR = -1;
    public static final int DSTAT_FINISH = 1;

    void onDownloadProcess(Object obj, int i, int i2);
}
