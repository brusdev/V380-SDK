package com.macrovideo.sdk.media;

public interface ITimeTextCallback {
    void setTimeText(String str);
}
