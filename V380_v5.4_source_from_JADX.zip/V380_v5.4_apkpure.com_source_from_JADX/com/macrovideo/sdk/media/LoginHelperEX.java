package com.macrovideo.sdk.media;

import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.macrovideo.v380.DialogTipCode;
import com.tencent.android.tpush.common.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.security.Key;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class LoginHelperEX {
    private static final int DEVICDE_HAVE_NEW_VERSION = 2;
    static final int LOGIN_COMMUNICATION_BUFFER_SIZE = 520;
    static final int MR_LOGIN_COMMUNICATION_BUFFER_SIZE = 256;
    private static final int NEW_CMD_CODE = 1168;
    private static final int NEW_USERVERIFY = 1167;
    private static final int RESULT_CODE_FAIL_ID_ERR = 1018;
    private static final int RESULT_CODE_FAIL_USER_NOEXIST = 1011;
    private static int SignForCmd = 0;
    private static final int VERIFY_RESULT_PWD_ERROR = 1012;
    private static byte[] buffer = new byte[520];
    public static String randomkey = "macrovideo+*#!^@";

    public static LoginHandle getDeviceParamEX(DeviceInfo device) {
        LoginHandle deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = LoginFromServerEX(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
                if (SignForCmd == -100) {
                    deviceParam = LoginFromServer(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
                }
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_ID_ERR) {
                deviceParam = LoginFromMRServerEX(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        if (deviceParam != null) {
            if (deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_ID_ERR) {
                deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
            } else if (deviceParam.getnResult() == 256) {
                deviceParam.setnDeviceID(device.getnDevID());
                deviceParam.setStrUsername(device.getStrUsername());
                deviceParam.setStrPassword(device.getStrPassword());
                deviceParam.setStrDomain(device.getStrDomain());
            }
        }
        return deviceParam;
    }

    public static LoginHandle getDeviceParamEX(DeviceInfo device, String strMRServerIP, int nMRPort) {
        LoginHandle deviceParam = LoginFromMRServerEX(device.getStrDomain(), device.getnPort(), strMRServerIP, nMRPort, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
        if (deviceParam != null) {
            if (deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_ID_ERR) {
                deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
            } else if (deviceParam.getnResult() == 256) {
                deviceParam.setnDeviceID(device.getnDevID());
                deviceParam.setStrUsername(device.getStrUsername());
                deviceParam.setStrPassword(device.getStrPassword());
                deviceParam.setStrDomain(device.getStrDomain());
            }
        }
        return deviceParam;
    }

    private static LoginHandle LoginFromServerEX(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        boolean bAudio_PRI = false;
        boolean bPTZ_PRI = false;
        boolean bSpeak_PRI = false;
        boolean bReverse_PRI = false;
        boolean bPTZX_PRI = false;
        int nPTZXCount = 0;
        LoginHandle deviceParam = new LoginHandle();
        deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        boolean isConnectOK = false;
        if (sSocket != null) {
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                }
            } catch (IOException e) {
                isConnectOK = false;
            }
            if (isConnectOK) {
                String strDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(System.currentTimeMillis()));
                int iDeviceID = nDeviceID;
                String randomkey2 = getCharAndNumr(16);
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) NEW_USERVERIFY, buffer, 0);
                Functions.IntToBytes((long) 120, buffer, 4);
                buffer[8] = (byte) 1;
                Functions.IntToBytes((long) 10, buffer, 9);
                Functions.IntToBytes((long) iDeviceID, buffer, 13);
                if (strDateTime != null) {
                    System.arraycopy(strDateTime.getBytes(), 0, buffer, 17, strDateTime.getBytes().length);
                }
                if (strUsername != null) {
                    System.arraycopy(strUsername.getBytes(), 0, buffer, 49, strUsername.getBytes().length);
                }
                System.arraycopy(randomkey2.getBytes(), 0, buffer, 81, randomkey2.getBytes().length);
                try {
                    Object encryptPassbyte2 = encrypt(encrypt(strPassword.getBytes(), randomkey.getBytes()), randomkey2.getBytes());
                    System.arraycopy(encryptPassbyte2, 0, buffer, 97, encryptPassbyte2.length);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
                try {
                    writer.write(buffer, 0, 520);
                    writer.flush();
                } catch (IOException e3) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e4) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e5) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e6) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 5) {
                    try {
                        if (reader.available() >= 256) {
                            reader.read(buffer, 0, 256);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e7) {
                            e7.printStackTrace();
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK) {
                    int nCmd = Functions.BytesToInt(buffer, 0);
                    SignForCmd = nCmd;
                    int nLoginResult = Functions.BytesToInt(buffer, 4);
                    int nResultValue = Functions.BytesToInt(buffer, 8);
                    int nnVersion = buffer[12];
                    long nloginHandle = (long) Functions.BytesToInt(buffer, 13);
                    long session = (long) Functions.BytesToInt(buffer, 17);
                    int nDeviceType = buffer[21];
                    int nCamType = buffer[22];
                    int nProducterID = Functions.BytesToShort(buffer, 23);
                    int nisDomainExist = Functions.BytesToShort(buffer, 25);
                    int nLen = 0;
                    for (i = 0; i < 32; i++) {
                        if (((char) buffer[i + 27]) == '\u0000') {
                            nLen = i;
                            break;
                        }
                    }
                    Object nDomain = new byte[nLen];
                    Arrays.fill(nDomain, (byte) 0);
                    System.arraycopy(buffer, 27, nDomain, 0, nLen);
                    String str = new String(nDomain);
                    int nRec_DeviceID = Functions.BytesToInt(buffer, 59);
                    int nnChannerls = buffer[63];
                    int nnAudio_pri = buffer[64];
                    int nnVideo_pri = buffer[65];
                    int nnSpeaker = buffer[66];
                    int nnPtz_pri = buffer[67];
                    int nnReverse_pri = buffer[68];
                    int nnPtzX_pri = buffer[69];
                    int nnPtzXCount = buffer[70];
                    int mLen = 0;
                    for (i = 0; i < 32; i++) {
                        if (((char) buffer[i + 71]) == '\u0000') {
                            mLen = i;
                            break;
                        }
                    }
                    Object settings_pri_array = new byte[mLen];
                    Arrays.fill(settings_pri_array, (byte) 0);
                    System.arraycopy(buffer, 71, settings_pri_array, 0, mLen);
                    int panoX = Functions.BytesToShort(buffer, 103);
                    int panoY = Functions.BytesToShort(buffer, 105);
                    int panoRad = Functions.BytesToShort(buffer, DialogTipCode.VERIFY_CODE_IS_NOT_STANDARDLIZED);
                    if (nCmd == NEW_CMD_CODE) {
                        if (nLoginResult == 1001) {
                            nResultValue -= (nResultValue / 100) * 100;
                            if (nResultValue == -2) {
                                deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                            } else if (nResultValue == -1) {
                                deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                            } else if (nResultValue == 0) {
                                deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                            } else if (nResultValue == 1) {
                                deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                            }
                            if (nResultValue == 0) {
                                deviceParam.setnResult(256);
                                if ((nResultValue & 2) > 0) {
                                }
                                if ((nResultValue & 8) > 0) {
                                }
                                if ((nResultValue & 16) > 0) {
                                }
                                if ((nResultValue & 32) > 0) {
                                }
                                if (buffer[64] == (byte) 1) {
                                    bAudio_PRI = true;
                                }
                                if (buffer[66] == (byte) 1) {
                                    bSpeak_PRI = true;
                                }
                                if (buffer[67] == (byte) 1) {
                                    bPTZ_PRI = true;
                                }
                                if (buffer[68] == (byte) 1) {
                                    bReverse_PRI = true;
                                }
                                if (buffer[69] == (byte) 1) {
                                    bPTZX_PRI = true;
                                    nPTZXCount = buffer[70];
                                }
                                boolean canUpdateDevice = buffer[112] == (byte) 2;
                                deviceParam.setbAudio(bAudio_PRI);
                                deviceParam.setbPTZ(bPTZ_PRI);
                                deviceParam.setbPTZX(bPTZX_PRI);
                                deviceParam.setbReversePRI(bReverse_PRI);
                                deviceParam.setbSpeak(bSpeak_PRI);
                                deviceParam.setnPTZXCount(nPTZXCount);
                                deviceParam.setbInLan(true);
                                deviceParam.setStrIP(strIP);
                                deviceParam.setStrLanIP(strIP);
                                deviceParam.setnPort(nPort);
                                deviceParam.setDeviceType(nDeviceType);
                                deviceParam.setCamType(nCamType);
                                deviceParam.setlHandle(nloginHandle);
                                deviceParam.setMRMode(false);
                                deviceParam.setPanoX(panoX);
                                deviceParam.setPanoY(panoY);
                                deviceParam.setPanoRad(panoRad);
                                deviceParam.setVersion(nnVersion);
                                deviceParam.setCanUpdateDevice(canUpdateDevice);
                            }
                        } else if (nLoginResult == 1012) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                        } else if (nLoginResult == 1011) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                        } else if (nLoginResult == 1018) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e8) {
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e9) {
                }
            }
            if (sSocket != null) {
                try {
                    sSocket.close();
                } catch (IOException e10) {
                }
            }
        }
        return deviceParam;
    }

    private static LoginHandle LoginFromServer(String strIP, int nPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        boolean bAudio_PRI = false;
        boolean bPTZ_PRI = false;
        boolean bSpeak_PRI = false;
        boolean bReverse_PRI = false;
        boolean bPTZX_PRI = false;
        int nPTZXCount = 0;
        LoginHandle deviceParam = new LoginHandle();
        deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
        boolean isConnectOK = false;
        if (sSocket != null) {
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                }
            } catch (IOException e) {
                isConnectOK = false;
            }
            if (isConnectOK) {
                String strDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(System.currentTimeMillis()));
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) 167, buffer, 0);
                Functions.IntToBytes((long) 120, buffer, 4);
                if (strUsername != null) {
                    System.arraycopy(strUsername.getBytes(), 0, buffer, 8, strUsername.getBytes().length);
                }
                if (strPassword != null) {
                    System.arraycopy(strPassword.getBytes(), 0, buffer, 58, strPassword.getBytes().length);
                }
                Functions.IntToBytes((long) nDeviceID, buffer, 108);
                if (strDateTime != null) {
                    System.arraycopy(strDateTime.getBytes(), 0, buffer, 112, strDateTime.getBytes().length);
                }
                try {
                    writer.write(buffer, 0, 520);
                    writer.flush();
                } catch (IOException e2) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e3) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e4) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e5) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                for (int i = 0; i < 5; i++) {
                    if (reader.available() >= 520) {
                        reader.read(buffer, 0, 520);
                        bReadOK = true;
                        break;
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e6) {
                        try {
                            e6.printStackTrace();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                }
                if (bReadOK) {
                    int nLoginResult = Functions.BytesToInt(buffer, 0);
                    int nResultValue = Functions.BytesToInt(buffer, 8);
                    if (nLoginResult == 168) {
                        nResultValue -= (nResultValue / 100) * 100;
                        if (nResultValue == -2) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_ID_ERR);
                        } else if (nResultValue == -1) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                        } else if (nResultValue == 0) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                        } else if (nResultValue == 1) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                        } else {
                            deviceParam.setnResult(256);
                            if ((nResultValue & 2) > 0) {
                            }
                            if ((nResultValue & 8) > 0) {
                            }
                            if ((nResultValue & 16) > 0) {
                            }
                            if ((nResultValue & 32) > 0) {
                            }
                            if (buffer[48] == (byte) 1) {
                                bAudio_PRI = true;
                            }
                            if (buffer[49] == (byte) 1) {
                                bSpeak_PRI = true;
                            }
                            if (buffer[50] == (byte) 1) {
                                bPTZ_PRI = true;
                            }
                            if (buffer[51] == (byte) 1) {
                                bReverse_PRI = true;
                            }
                            if (buffer[52] == (byte) 1) {
                                bPTZX_PRI = true;
                                nPTZXCount = buffer[53];
                            }
                            deviceParam.setbAudio(bAudio_PRI);
                            deviceParam.setbPTZ(bPTZ_PRI);
                            deviceParam.setbPTZX(bPTZX_PRI);
                            deviceParam.setbReversePRI(bReverse_PRI);
                            deviceParam.setbSpeak(bSpeak_PRI);
                            deviceParam.setnPTZXCount(nPTZXCount);
                            deviceParam.setbInLan(true);
                            deviceParam.setStrIP(strIP);
                            deviceParam.setStrLanIP(strIP);
                            deviceParam.setnPort(nPort);
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e7) {
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e8) {
                }
            }
            if (sSocket != null) {
                try {
                    sSocket.close();
                } catch (IOException e9) {
                }
            }
        }
        return deviceParam;
    }

    private static LoginHandle LoginFromMRServerEX(String strDomain, int nPort, String strMRServerIP, int nMRPort, String strUsername, String strPassword, int nDeviceID) {
        OutputStream writer = null;
        InputStream reader = null;
        boolean bAudio_PRI = false;
        boolean bPTZ_PRI = false;
        boolean bSpeak_PRI = false;
        boolean bReverse_PRI = false;
        boolean bPTZX_PRI = false;
        int nPTZXCount = 0;
        String strIP = Constants.MAIN_VERSION_TAG;
        String strLanIP = Constants.MAIN_VERSION_TAG;
        LoginHandle deviceParam = new LoginHandle();
        deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
        Socket sSocket = Functions.connectToMRServer(strMRServerIP, nMRPort, Defines.CMD_MR_WAIT, nDeviceID);
        boolean isConnectOK = false;
        if (sSocket != null) {
            try {
                if (sSocket.isConnected()) {
                    writer = sSocket.getOutputStream();
                    reader = sSocket.getInputStream();
                    isConnectOK = true;
                }
            } catch (IOException e) {
                isConnectOK = false;
            }
            if (isConnectOK) {
                String randomkey2 = getCharAndNumr(16);
                Arrays.fill(buffer, (byte) 0);
                Functions.IntToBytes((long) NEW_USERVERIFY, buffer, 0);
                Functions.IntToBytes((long) 1002, buffer, 4);
                buffer[8] = (byte) 1;
                Functions.IntToBytes((long) 11, buffer, 9);
                Functions.IntToBytes((long) nDeviceID, buffer, 13);
                if (strDomain != null) {
                    System.arraycopy(strDomain.getBytes(), 0, buffer, 17, strDomain.getBytes().length);
                }
                Functions.IntToBytes((long) nPort, buffer, 67);
                if (strUsername != null) {
                    System.arraycopy(strUsername.getBytes(), 0, buffer, 71, strUsername.getBytes().length);
                }
                System.arraycopy(randomkey2.getBytes(), 0, buffer, 103, randomkey2.getBytes().length);
                try {
                    Object encryptPassbyte2 = encrypt(encrypt(strPassword.getBytes(), randomkey.getBytes()), randomkey2.getBytes());
                    System.arraycopy(encryptPassbyte2, 0, buffer, Defines.NV_IPC_VERSION_INFO_GET_REQUEST, encryptPassbyte2.length);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
                try {
                    writer.write(buffer, 0, 256);
                    writer.flush();
                } catch (IOException e3) {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e4) {
                        }
                    }
                    writer = null;
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e5) {
                        }
                    }
                    reader = null;
                    if (sSocket != null) {
                        try {
                            sSocket.close();
                        } catch (IOException e6) {
                        }
                    }
                    sSocket = null;
                }
                Arrays.fill(buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 5) {
                    try {
                        if (reader.available() >= 256) {
                            reader.read(buffer, 0, 520);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e7) {
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK) {
                    int nLoginCMD = Functions.BytesToInt(buffer, 0);
                    int nResultCode = Functions.BytesToInt(buffer, 4);
                    int nResultValue = Functions.BytesToInt(buffer, 8);
                    int nVersion_num = buffer[12];
                    int nLoginHandle = Functions.BytesToInt(buffer, 13);
                    int nSession = Functions.BytesToInt(buffer, 17);
                    int nDeviceType = buffer[21];
                    int nCamType = buffer[22];
                    int nProducterID = Functions.BytesToShort(buffer, 23);
                    byte bIsInSameLan = buffer[25];
                    int nLen = 0;
                    for (i = 0; i < 32; i++) {
                        if (((char) buffer[i + 26]) == '\u0000') {
                            nLen = i;
                            break;
                        }
                    }
                    Object strServerIP = new byte[nLen];
                    Arrays.fill(strServerIP, (byte) 0);
                    System.arraycopy(buffer, 26, strServerIP, 0, nLen);
                    int nServerPort = Functions.BytesToInt(buffer, 58);
                    nLen = 0;
                    for (i = 0; i < 32; i++) {
                        if (((char) buffer[i + 62]) == '\u0000') {
                            nLen = i;
                            break;
                        }
                    }
                    Object strServerLanIP = new byte[nLen];
                    Arrays.fill(strServerLanIP, (byte) 0);
                    System.arraycopy(buffer, 62, strServerLanIP, 0, nLen);
                    String str = new String(strServerLanIP);
                    long nRecDeviceID = (long) Functions.BytesToInt(buffer, 94);
                    int nnChannerls = buffer[98];
                    int nnAudio_pri = buffer[99];
                    int nnVideo_pri = buffer[100];
                    int nnSpeaker = buffer[101];
                    int nnPtz_pri = buffer[102];
                    int nnReverse_pri = buffer[103];
                    int nnPtzX_pri = buffer[DialogTipCode.PHONE_NUMBER_IS_NOT_STANDARDLIZED];
                    int nnPtzXCount = buffer[105];
                    int mLen = 0;
                    for (i = 0; i < 32; i++) {
                        if (((char) buffer[i + 106]) == '\u0000') {
                            mLen = i;
                            break;
                        }
                    }
                    Object settings_pri_array = new byte[mLen];
                    Arrays.fill(settings_pri_array, (byte) 0);
                    System.arraycopy(buffer, 106, settings_pri_array, 0, mLen);
                    int panoX = Functions.BytesToShort(buffer, Defines.NV_IPC_CUSTOM_TRANSPORT_SEND_REQUEST);
                    int panoY = Functions.BytesToShort(buffer, Defines.NV_IPC_ALIVE);
                    int panoRad = Functions.BytesToShort(buffer, Defines.NV_IPC_IP_CONFIG_GET_REQUEST);
                    if (nLoginCMD == NEW_CMD_CODE) {
                        if (nResultCode != 1001) {
                            switch (nResultValue) {
                                case -11:
                                    deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_OLD_VERSON);
                                    break;
                                case 0:
                                    deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                                    break;
                                case 1:
                                    deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                                    break;
                                case 2:
                                    deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                                    break;
                                default:
                                    break;
                            }
                        }
                        boolean canUpdateDevice;
                        str = new String(strServerIP);
                        str.trim();
                        new String(strServerLanIP).trim();
                        if (buffer[99] == (byte) 1) {
                            bAudio_PRI = true;
                        }
                        if (buffer[101] == (byte) 1) {
                            bSpeak_PRI = true;
                        }
                        if (buffer[102] == (byte) 1) {
                            bPTZ_PRI = true;
                        }
                        if (buffer[103] == (byte) 1) {
                            bReverse_PRI = true;
                        }
                        if (buffer[DialogTipCode.PHONE_NUMBER_IS_NOT_STANDARDLIZED] == (byte) 1) {
                            bPTZX_PRI = true;
                            nPTZXCount = buffer[105];
                        }
                        if (buffer[148] == (byte) 2) {
                            canUpdateDevice = true;
                        } else {
                            canUpdateDevice = false;
                        }
                        if (bIsInSameLan == (byte) 1) {
                        }
                        nResultValue -= (nResultValue / 100) * 100;
                        if (nResultValue == -1) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_VERIFY_FAILED);
                        } else if (nResultValue == 0) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_USER_NOEXIST);
                        } else if (nResultValue == 1) {
                            deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_PWD_ERROR);
                        } else {
                            deviceParam.setnResult(256);
                            if ((nResultValue & 2) > 0) {
                            }
                            if ((nResultValue & 8) > 0) {
                            }
                            if ((nResultValue & 16) > 0) {
                            }
                            if ((nResultValue & 32) > 0) {
                            }
                            deviceParam.setbAudio(bAudio_PRI);
                            deviceParam.setbPTZ(bPTZ_PRI);
                            deviceParam.setbPTZX(bPTZX_PRI);
                            deviceParam.setbReversePRI(bReverse_PRI);
                            deviceParam.setbSpeak(bSpeak_PRI);
                            deviceParam.setnPTZXCount(nPTZXCount);
                            deviceParam.setbInLan(false);
                            deviceParam.setStrIP(str);
                            deviceParam.setStrLanIP(str);
                            deviceParam.setnPort(nPort);
                            deviceParam.setMRMode(true);
                            deviceParam.setDeviceType(nDeviceType);
                            deviceParam.setCamType(nCamType);
                            deviceParam.setlHandle((long) nLoginHandle);
                            deviceParam.setPanoX(panoX);
                            deviceParam.setPanoY(panoY);
                            deviceParam.setPanoRad(panoRad);
                            deviceParam.setVersion(nVersion_num);
                            deviceParam.setCanUpdateDevice(canUpdateDevice);
                            if (sSocket != null) {
                                String strMRServer = sSocket.getInetAddress().getHostAddress();
                                int mrPort = sSocket.getPort();
                                deviceParam.setStrMRServer(strMRServer);
                                deviceParam.setnMRPort(mrPort);
                            }
                        }
                    }
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e8) {
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e9) {
                }
            }
            if (sSocket != null) {
                try {
                    sSocket.close();
                } catch (IOException e10) {
                }
            }
        }
        return deviceParam;
    }

    public static byte[] encrypt(byte[] data, byte[] key) throws Exception {
        Key k = toKey(key);
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(1, k);
        return cipher.doFinal(data);
    }

    public static byte[] decrypt(byte[] data, byte[] key) throws Exception {
        Key k = toKey(key);
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(2, k);
        return cipher.doFinal(data);
    }

    public static Key toKey(byte[] key) throws Exception {
        return new SecretKeySpec(key, "AES");
    }

    public static String byte2hex(byte[] b) {
        StringBuffer sb = new StringBuffer(b.length * 2);
        String tmp = Constants.MAIN_VERSION_TAG;
        for (byte b2 : b) {
            tmp = Integer.toHexString(b2 & 255);
            if (tmp.length() == 1) {
                sb.append("0");
            }
            sb.append(tmp);
        }
        return sb.toString();
    }

    public static String getCharAndNumr(int length) {
        String val = Constants.MAIN_VERSION_TAG;
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            if ("char".equalsIgnoreCase(charOrNum)) {
                val = new StringBuilder(String.valueOf(val)).append((char) (random.nextInt(26) + (random.nextInt(2) % 2 == 0 ? 65 : 97))).toString();
            } else if ("num".equalsIgnoreCase(charOrNum)) {
                val = new StringBuilder(String.valueOf(val)).append(String.valueOf(random.nextInt(10))).toString();
            }
        }
        return val;
    }

    public static LoginHandle getDeviceParamRecordFileEX(DeviceInfo device) {
        LoginHandle deviceParam = null;
        if (device != null && device.getnDevID() > 0 && device.getnPort() > 0) {
            if (Functions.isIpAddress(device.getStrIP())) {
                deviceParam = LoginFromServerEX(device.getStrIP(), device.getnPort(), device.getStrUsername(), device.getStrPassword(), device.getnDevID());
                if (deviceParam != null && (SignForCmd == -100 || (deviceParam.getnResult() == 256 && deviceParam.getVersion() == 0))) {
                    deviceParam = RecordFileHelper.getRecordOPHandle(device);
                }
            }
            if (deviceParam == null || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_ID_ERR) {
                deviceParam = LoginFromMRServerEX(device.getStrDomain(), device.getnPort(), null, 0, device.getStrUsername(), device.getStrPassword(), device.getnDevID());
            }
        }
        if (deviceParam != null) {
            if (deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_COMMUNICAT_FAIL || deviceParam.getnResult() == ResultCode.RESULT_CODE_FAIL_ID_ERR) {
                deviceParam.setnResult(ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL);
            } else if (deviceParam.getnResult() == 256) {
                deviceParam.setnDeviceID(device.getnDevID());
                deviceParam.setStrUsername(device.getStrUsername());
                deviceParam.setStrPassword(device.getStrPassword());
                deviceParam.setStrDomain(device.getStrDomain());
            }
        }
        return deviceParam;
    }
}
