package com.macrovideo.sdk.media;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class LoginHandle implements Parcelable {
    public static final Creator CREATOR = new C02351();
    private boolean bAudio = false;
    private boolean bInLan = false;
    private boolean bPTZ = false;
    private boolean bPTZX = false;
    private boolean bReversePRI = true;
    private boolean bSpeak = false;
    private int camType;
    private boolean canUpdateDevice = false;
    private int deviceType;
    private boolean isMRMode = false;
    private boolean isSetMRServer = false;
    private long lHandle = -1;
    private int mVersion;
    private int nChnCount = 1;
    private int nDeviceID = 0;
    private int nMRPort = 0;
    private int nPTZXCount = 0;
    private int nPort = 5050;
    private int nResult;
    private int panoRad;
    private int panoX;
    private int panoY;
    private String strDomain = "123.nvdvr.net";
    private String strIP = "127.0.0.1";
    private String strLanIP = "127.0.0.1";
    private String strMRServer = null;
    private String strPassword = null;
    private String strUsername = null;

    class C02351 implements Creator {
        C02351() {
        }

        public LoginHandle createFromParcel(Parcel in) {
            return new LoginHandle(in);
        }

        public LoginHandle[] newArray(int size) {
            return new LoginHandle[size];
        }
    }

    public boolean isCanUpdateDevice() {
        return this.canUpdateDevice;
    }

    public void setCanUpdateDevice(boolean canUpdateDevice) {
        this.canUpdateDevice = canUpdateDevice;
    }

    public int getVersion() {
        return this.mVersion;
    }

    public void setVersion(int version) {
        this.mVersion = version;
    }

    public int getDeviceType() {
        return this.deviceType;
    }

    public void setDeviceType(int deviceType) {
        this.deviceType = deviceType;
    }

    public int getCamType() {
        return this.camType;
    }

    public void setCamType(int camType) {
        this.camType = camType;
    }

    public void setPanoX(int panoX) {
        this.panoX = panoX;
    }

    public int getPanoX() {
        return this.panoX;
    }

    public void setPanoY(int panoY) {
        this.panoY = panoY;
    }

    public int getPanoY() {
        return this.panoY;
    }

    public void setPanoRad(int panoRad) {
        this.panoRad = panoRad;
    }

    public int getPanoRad() {
        return this.panoRad;
    }

    boolean isSetMRServer() {
        return this.isSetMRServer;
    }

    public long getlHandle() {
        return this.lHandle;
    }

    public void setlHandle(long lHandle) {
        this.lHandle = lHandle;
    }

    public void setSetMRServer(boolean isSetMRServer) {
        this.isSetMRServer = isSetMRServer;
    }

    String getStrMRServer() {
        return this.strMRServer;
    }

    public void setStrMRServer(String strMRServer) {
        this.strMRServer = strMRServer;
    }

    int getnMRPort() {
        return this.nMRPort;
    }

    public void setnMRPort(int nMRPort) {
        this.nMRPort = nMRPort;
    }

    String getStrUsername() {
        return this.strUsername;
    }

    public void setStrUsername(String strUsername) {
        this.strUsername = strUsername;
    }

    String getStrPassword() {
        return this.strPassword;
    }

    public void setStrPassword(String strPassword) {
        this.strPassword = strPassword;
    }

    public int getnResult() {
        return this.nResult;
    }

    public void setnResult(int nResult) {
        this.nResult = nResult;
    }

    public int getnDeviceID() {
        return this.nDeviceID;
    }

    public void setnDeviceID(int nDeviceID) {
        this.nDeviceID = nDeviceID;
    }

    int getnChnCount() {
        return this.nChnCount;
    }

    void setnChnCount(int nChnCount) {
        this.nChnCount = nChnCount;
    }

    public String getStrDomain() {
        return this.strDomain;
    }

    public void setStrDomain(String strDomain) {
        this.strDomain = strDomain;
    }

    boolean isbInLan() {
        return this.bInLan;
    }

    public void setbInLan(boolean bInLan) {
        this.bInLan = bInLan;
    }

    String getStrIP() {
        return this.strIP;
    }

    public void setStrIP(String strIP) {
        this.strIP = strIP;
    }

    String getStrLanIP() {
        return this.strLanIP;
    }

    public void setStrLanIP(String strLanIP) {
        this.strLanIP = strLanIP;
    }

    int getnPort() {
        return this.nPort;
    }

    public void setnPort(int nPort) {
        this.nPort = nPort;
    }

    public boolean isbAudio() {
        return this.bAudio;
    }

    void setbAudio(boolean bAudio) {
        this.bAudio = bAudio;
    }

    public boolean isbSpeak() {
        return this.bSpeak;
    }

    void setbSpeak(boolean bSpeak) {
        this.bSpeak = bSpeak;
    }

    public boolean isbPTZ() {
        return this.bPTZ;
    }

    void setbPTZ(boolean bPTZ) {
        this.bPTZ = bPTZ;
    }

    public boolean isbPTZX() {
        return this.bPTZX;
    }

    void setbPTZX(boolean bPTZX) {
        this.bPTZX = bPTZX;
    }

    public int getnPTZXCount() {
        return this.nPTZXCount;
    }

    void setnPTZXCount(int nPTZXCount) {
        this.nPTZXCount = nPTZXCount;
    }

    public boolean isbReversePRI() {
        return this.bReversePRI;
    }

    void setbReversePRI(boolean bReversePRI) {
        this.bReversePRI = bReversePRI;
    }

    public LoginHandle(Parcel in) {
        boolean z;
        boolean z2 = true;
        this.lHandle = in.readLong();
        this.nResult = in.readInt();
        this.nDeviceID = in.readInt();
        this.nChnCount = in.readInt();
        this.nPort = in.readInt();
        this.nPTZXCount = in.readInt();
        this.strDomain = in.readString();
        this.strIP = in.readString();
        this.strLanIP = in.readString();
        this.bInLan = in.readByte() == (byte) 1;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bAudio = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bSpeak = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bPTZ = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bPTZX = z;
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.bReversePRI = z;
        this.strMRServer = in.readString();
        this.strUsername = in.readString();
        this.strPassword = in.readString();
        this.nMRPort = in.readInt();
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isMRMode = z;
        if (in.readByte() != (byte) 1) {
            z2 = false;
        }
        this.isSetMRServer = z2;
        this.deviceType = in.readInt();
        this.camType = in.readInt();
        this.panoX = in.readInt();
        this.panoY = in.readInt();
        this.panoRad = in.readInt();
        this.mVersion = in.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        int i;
        int i2 = 1;
        dest.writeLong(this.lHandle);
        dest.writeInt(this.nResult);
        dest.writeInt(this.nDeviceID);
        dest.writeInt(this.nChnCount);
        dest.writeInt(this.nPort);
        dest.writeInt(this.nPTZXCount);
        dest.writeString(this.strDomain);
        dest.writeString(this.strIP);
        dest.writeString(this.strLanIP);
        dest.writeByte((byte) (this.bInLan ? 1 : 0));
        if (this.bAudio) {
            i = 1;
        } else {
            i = 0;
        }
        dest.writeByte((byte) i);
        if (this.bSpeak) {
            i = 1;
        } else {
            i = 0;
        }
        dest.writeByte((byte) i);
        if (this.bPTZ) {
            i = 1;
        } else {
            i = 0;
        }
        dest.writeByte((byte) i);
        if (this.bPTZX) {
            i = 1;
        } else {
            i = 0;
        }
        dest.writeByte((byte) i);
        if (this.bReversePRI) {
            i = 1;
        } else {
            i = 0;
        }
        dest.writeByte((byte) i);
        dest.writeString(this.strMRServer);
        dest.writeString(this.strUsername);
        dest.writeString(this.strPassword);
        dest.writeInt(this.nMRPort);
        if (this.isMRMode) {
            i = 1;
        } else {
            i = 0;
        }
        dest.writeByte((byte) i);
        if (!this.isSetMRServer) {
            i2 = 0;
        }
        dest.writeByte((byte) i2);
        dest.writeInt(this.deviceType);
        dest.writeInt(this.camType);
        dest.writeInt(this.panoX);
        dest.writeInt(this.panoY);
        dest.writeInt(this.panoRad);
        dest.writeInt(this.mVersion);
    }

    public boolean isMRMode() {
        return this.isMRMode;
    }

    public void setMRMode(boolean isMRMode) {
        this.isMRMode = isMRMode;
    }
}
