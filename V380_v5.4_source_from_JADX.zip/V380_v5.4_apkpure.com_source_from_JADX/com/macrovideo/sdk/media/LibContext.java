package com.macrovideo.sdk.media;

import com.macrovideo.sdk.tools.Functions;

public class LibContext {
    static native void ClearEnvParam();

    static native void ClearListEnvParam();

    static native int ConvertYUV2RGB(int i, byte[] bArr, byte[] bArr2, byte[] bArr3, int i2, byte[] bArr4, int i3, int i4);

    static native int EndcodeStringToSound(String str, int i);

    static native boolean FinishPlayback(int i);

    static native boolean FocuseIn(int i, int i2);

    static native boolean FocuseOut(int i, int i2);

    static native boolean InitJNIResuorce();

    static native int InitMRServerIP();

    static native boolean ReleaseJNIResuorce();

    static native int SendSpeakAudioData(int i, byte[] bArr, int i2, int i3, int i4);

    static native boolean SetAudioParam(int i, boolean z, boolean z2);

    static native boolean SetCamImageOrientation(int i, int i2);

    static native void SetEnvParam(Object obj, Object obj2, Object obj3, Object obj4);

    public static native void SetListEnvParam(NVPanoPlayer nVPanoPlayer);

    static native int SetMRServerIP(String str, String str2, String str3);

    static native boolean SetPTZParam(int i, boolean z, int i2, boolean z2, int i3, boolean z3, boolean z4, boolean z5, boolean z6, int i4);

    static native boolean SetPTZXParam(int i, int i2, int i3);

    static native void SetPanoEnvParam(NVPanoPlayer nVPanoPlayer, NVPanoPlayer nVPanoPlayer2, NVPanoPlayer nVPanoPlayer3, NVPanoPlayer nVPanoPlayer4);

    static native boolean SetPlayIndex(int i, int i2);

    static native boolean StartCloudPlayBack(int i, int i2, int i3, String str, String str2, String str3, int i4, int i5, String str4, int i6, int i7, int i8, int i9);

    static native int StartDownloadRecFile(RecFileDownloader recFileDownloader, String str, int i, String str2, String str3, String str4, int i2, String str5, String str6, int i3, int i4, String str7, int i5, int i6, int i7, int i8, boolean z, String str8, int i9);

    static native boolean StartPlay(int i, int i2, int i3, String str, String str2, String str3, int i4, String str4, String str5, boolean z, int i5, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, String str6, int i6);

    static native boolean StartPlayBack(int i, int i2, String str, String str2, String str3, int i3, String str4, String str5, int i4, int i5, String str6, int i6, int i7, int i8, int i9, boolean z, String str7, int i10);

    static native boolean StartRecord(int i, String str);

    static native boolean StartSpeak(int i);

    static native boolean StopCloudPlayBack(int i, boolean z);

    static native boolean StopDownloadRecFile(int i);

    static native int StopEndcodeStringToSound();

    static native void StopPlay(int i, boolean z);

    static native boolean StopPlayBack(int i, boolean z);

    static native boolean StopRecord(int i);

    static native boolean StopSpeak(int i);

    public static native void SwitchPlayingMode(int i, boolean z);

    static {
        System.loadLibrary("faad");
        System.loadLibrary("mp4maker");
        System.loadLibrary("ffmpeg");
        System.loadLibrary("glesplayer");
        InitJNIResuorce();
    }

    public static boolean InitResuorce() {
        return InitJNIResuorce();
    }

    public static boolean ReleaseResuorce() {
        return ReleaseJNIResuorce();
    }

    public static void ClearContext() {
        StopPlay(0, true);
        ClearEnvParam();
    }

    public static void SetPanoContext(NVPanoPlayer player0, NVPanoPlayer player1, NVPanoPlayer player2, NVPanoPlayer player3) {
        SetPanoEnvParam(player0, player1, player2, player3);
    }

    public static void SetContext(Object player0, Object player1, Object player2, Object player3) {
        SetEnvParam(player0, player1, player2, player3);
    }

    public static boolean stopAll() {
        StopPlay(0, true);
        return true;
    }

    public static void SetZoneIndex(int nIndex) {
        Functions.setZoneIndex(nIndex);
    }

    public static int GetZoneIndex() {
        return Functions.getZoneIndex();
    }
}
