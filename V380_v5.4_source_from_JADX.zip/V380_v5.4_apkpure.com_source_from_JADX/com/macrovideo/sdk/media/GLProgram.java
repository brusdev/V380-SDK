package com.macrovideo.sdk.media;

import android.opengl.GLES20;
import com.macrovideo.photo.PhotoViewAttacher;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

class GLProgram {
    private static final String FRAGMENT_SHADER = "varying lowp vec2 TexCoordOut;\nuniform sampler2D SamplerY;\nuniform sampler2D SamplerU;\nuniform sampler2D SamplerV;\nvoid main(void)\n{\nmediump vec3 yuv;\nlowp vec3 rgb;\nyuv.x = texture2D(SamplerY, TexCoordOut).r;\nyuv.y = texture2D(SamplerU, TexCoordOut).r - 0.5;\nyuv.z = texture2D(SamplerV, TexCoordOut).r - 0.5;\nrgb = mat3( 1,   1,   1,\n0,       -0.39465,  2.03211,\n1.13983,   -0.58060,  0) * yuv;\ngl_FragColor = vec4(rgb, 0);\n}\n";
    static final int LAND = 2;
    static final int PORT = 1;
    static final int TEXTURE_ID_0 = 0;
    static final int TEXTURE_ID_1 = 1;
    static final int TEXTURE_ID_2 = 2;
    static final int Texture_0 = 33984;
    static final int Texture_1 = 33985;
    static final int Texture_2 = 33986;
    private static final String VERTEX_SHADER = "attribute vec4 vPosition;\nattribute vec2 a_texCoord;\nvarying vec2 TexCoordOut;\nvoid main() {\ngl_Position = vPosition;\nTexCoordOut = a_texCoord;\n}\n";
    static final float alpha = 0.5f;
    private static float[] coordVertices = new float[]{0.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, 0.0f, 0.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, 0.0f};
    private static final float[] coordVertices_F = new float[]{0.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, 0.0f, 0.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, 0.0f};
    private static float[] coordVertices_reverse = new float[]{0.0f, 0.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, 0.0f, 0.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE};
    private static float[] squareVertices_LAND = new float[]{-1.0f, -1.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, -1.0f, -1.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE};
    private static final float[] squareVertices_LAND_F = new float[]{-1.0f, -1.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, -1.0f, -1.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE};
    private static float[] squareVertices_PORT = new float[]{-1.0f, -1.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, -1.0f, -1.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE};
    private static final float[] squareVertices_PORT_F = new float[]{-1.0f, -1.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, -1.0f, -1.0f, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE, PhotoViewAttacher.DEFAULT_MIN_SCALE};
    private String Tag = "GLProgram";
    private int _coordHandle;
    private Buffer _coord_buffer = null;
    private Buffer _coord_buffer_reverse = null;
    private int _positionHandle;
    private int _program = 0;
    private Buffer _vertice_buffer = null;
    private int _video_height;
    private int _video_width;
    private Buffer[] four_regions;
    boolean isProgBuilt = false;
    private boolean isReverse = false;
    private int orientation;
    private int uHandle;
    private int uTextureID;
    private int vHandle;
    private int vTextureID;
    private int yHandle;
    private int yTextureID;

    public GLProgram(int orien) {
        this.orientation = orien;
    }

    public boolean isProgramBuilt() {
        return this.isProgBuilt;
    }

    public void setReverse(boolean isReverse) {
        this.isReverse = isReverse;
    }

    float scaleXY(float fIn, float fDelta) {
        float fResult = fIn;
        if (((double) fDelta) <= 0.0d || ((double) fDelta) >= 1.0d) {
            return fResult;
        }
        return ((fIn - alpha) * fDelta) + alpha;
    }

    public void scale(float fX, float fY) {
        System.out.println("scale");
        for (int i = 0; i < coordVertices_F.length; i++) {
            coordVertices[i] = scaleXY(coordVertices_F[i], fX);
        }
        this._coord_buffer = ByteBuffer.allocateDirect(coordVertices.length * 4);
        ((ByteBuffer) this._coord_buffer).order(ByteOrder.nativeOrder());
        ((ByteBuffer) this._coord_buffer).asFloatBuffer().put(coordVertices);
        this._coord_buffer.position(0);
    }

    public void buildProgram() {
        if (this._program <= 0) {
            this._program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER);
        }
        this._positionHandle = GLES20.glGetAttribLocation(this._program, "vPosition");
        if (this._positionHandle == -1) {
            throw new RuntimeException("Could not get attribute location for vPosition");
        }
        this._coordHandle = GLES20.glGetAttribLocation(this._program, "a_texCoord");
        if (this._coordHandle == -1) {
            throw new RuntimeException("Could not get attribute location for a_texCoord");
        }
        this.yHandle = GLES20.glGetUniformLocation(this._program, "SamplerY");
        if (this.yHandle == -1) {
            throw new RuntimeException("Could not get uniform location for SamplerY");
        }
        this.uHandle = GLES20.glGetUniformLocation(this._program, "SamplerU");
        checkGlError("glGetUniformLocation SamplerU");
        if (this.uHandle == -1) {
            throw new RuntimeException("Could not get uniform location for SamplerU");
        }
        this.vHandle = GLES20.glGetUniformLocation(this._program, "SamplerV");
        if (this.vHandle == -1) {
            throw new RuntimeException("Could not get uniform location for SamplerV");
        }
        this.isProgBuilt = true;
        createBuffers(squareVertices_PORT, coordVertices, coordVertices_reverse);
    }

    public void genTextures() {
        if (this.yTextureID >= 0) {
            GLES20.glDeleteTextures(1, new int[]{this.yTextureID}, 0);
            checkGlError("glDeleteTextures");
        }
        if (this.uTextureID >= 0) {
            GLES20.glDeleteTextures(1, new int[]{this.uTextureID}, 0);
            checkGlError("glDeleteTextures");
        }
        if (this.vTextureID >= 0) {
            GLES20.glDeleteTextures(1, new int[]{this.vTextureID}, 0);
            checkGlError("glDeleteTextures");
        }
        int[] textures = new int[3];
        GLES20.glGenTextures(3, textures, 0);
        this.yTextureID = textures[0];
        this.uTextureID = textures[1];
        this.vTextureID = textures[2];
    }

    public void buildTextures(Buffer y, Buffer u, Buffer v, int width, int height) {
        boolean videoSizeChanged = (width == this._video_width && height == this._video_height) ? false : true;
        if (videoSizeChanged) {
            this._video_width = width;
            this._video_height = height;
            genTextures();
        }
        GLES20.glActiveTexture(Texture_0);
        GLES20.glBindTexture(3553, this.yTextureID);
        GLES20.glTexImage2D(3553, 0, 6409, this._video_width, this._video_height, 0, 6409, 5121, y);
        GLES20.glTexParameterf(3553, 10241, 9728.0f);
        GLES20.glTexParameterf(3553, 10240, 9729.0f);
        GLES20.glTexParameteri(3553, 10242, 33071);
        GLES20.glTexParameteri(3553, 10243, 33071);
        GLES20.glActiveTexture(Texture_1);
        GLES20.glBindTexture(3553, this.uTextureID);
        GLES20.glTexImage2D(3553, 0, 6409, this._video_width / 2, this._video_height / 2, 0, 6409, 5121, u);
        GLES20.glTexParameterf(3553, 10241, 9728.0f);
        GLES20.glTexParameterf(3553, 10240, 9729.0f);
        GLES20.glTexParameteri(3553, 10242, 33071);
        GLES20.glTexParameteri(3553, 10243, 33071);
        GLES20.glActiveTexture(Texture_2);
        GLES20.glBindTexture(3553, this.vTextureID);
        GLES20.glTexImage2D(3553, 0, 6409, this._video_width / 2, this._video_height / 2, 0, 6409, 5121, v);
        GLES20.glTexParameterf(3553, 10241, 9728.0f);
        GLES20.glTexParameterf(3553, 10240, 9729.0f);
        GLES20.glTexParameteri(3553, 10242, 33071);
        GLES20.glTexParameteri(3553, 10243, 33071);
    }

    public void buildTextures(Buffer y, Buffer u, Buffer v, int width, int height, int region) {
        boolean videoSizeChanged = (width == this._video_width && height == this._video_height) ? false : true;
        if (videoSizeChanged) {
            this._video_width = width;
            this._video_height = height;
            genTextures();
        }
        GLES20.glActiveTexture(Texture_0);
        GLES20.glBindTexture(3553, this.yTextureID);
        GLES20.glTexImage2D(3553, 0, 6409, this._video_width, this._video_height, 0, 6409, 5121, y);
        GLES20.glTexParameterf(3553, 10241, 9728.0f);
        GLES20.glTexParameterf(3553, 10240, 9729.0f);
        GLES20.glTexParameteri(3553, 10242, 33071);
        GLES20.glTexParameteri(3553, 10243, 33071);
        GLES20.glActiveTexture(Texture_1);
        GLES20.glBindTexture(3553, this.uTextureID);
        GLES20.glTexImage2D(3553, 0, 6409, this._video_width / 2, this._video_height / 2, 0, 6409, 5121, u);
        GLES20.glTexParameterf(3553, 10241, 9728.0f);
        GLES20.glTexParameterf(3553, 10240, 9729.0f);
        GLES20.glTexParameteri(3553, 10242, 33071);
        GLES20.glTexParameteri(3553, 10243, 33071);
        GLES20.glActiveTexture(Texture_2);
        GLES20.glBindTexture(3553, this.vTextureID);
        GLES20.glTexImage2D(3553, 0, 6409, this._video_width / 2, this._video_height / 2, 0, 6409, 5121, v);
        GLES20.glTexParameterf(3553, 10241, 9728.0f);
        GLES20.glTexParameterf(3553, 10240, 9729.0f);
        GLES20.glTexParameteri(3553, 10242, 33071);
        GLES20.glTexParameteri(3553, 10243, 33071);
    }

    public void drawFrame() {
        GLES20.glUseProgram(this._program);
        GLES20.glVertexAttribPointer(this._positionHandle, 2, 5126, false, 0, this._vertice_buffer);
        GLES20.glEnableVertexAttribArray(this._positionHandle);
        if (this.isReverse) {
            GLES20.glVertexAttribPointer(this._coordHandle, 2, 5126, false, 0, this._coord_buffer_reverse);
            GLES20.glEnableVertexAttribArray(this._coordHandle);
        } else {
            GLES20.glVertexAttribPointer(this._coordHandle, 2, 5126, false, 0, this._coord_buffer);
            GLES20.glEnableVertexAttribArray(this._coordHandle);
        }
        GLES20.glActiveTexture(Texture_0);
        GLES20.glBindTexture(3553, this.yTextureID);
        GLES20.glUniform1i(this.yHandle, 0);
        GLES20.glActiveTexture(Texture_1);
        GLES20.glBindTexture(3553, this.uTextureID);
        GLES20.glUniform1i(this.uHandle, 1);
        GLES20.glActiveTexture(Texture_2);
        GLES20.glBindTexture(3553, this.vTextureID);
        GLES20.glUniform1i(this.vHandle, 2);
        GLES20.glDrawArrays(5, 0, 4);
        GLES20.glFinish();
        GLES20.glDisableVertexAttribArray(this._positionHandle);
        GLES20.glDisableVertexAttribArray(this._coordHandle);
    }

    public void drawFrame(int region) {
        GLES20.glUseProgram(this._program);
        GLES20.glVertexAttribPointer(this._positionHandle, 2, 5126, false, 0, this.four_regions[region]);
        GLES20.glEnableVertexAttribArray(this._positionHandle);
        if (this.isReverse) {
            GLES20.glVertexAttribPointer(this._coordHandle, 2, 5126, false, 0, this._coord_buffer_reverse);
            GLES20.glEnableVertexAttribArray(this._coordHandle);
        } else {
            GLES20.glVertexAttribPointer(this._coordHandle, 2, 5126, false, 0, this._coord_buffer);
            GLES20.glEnableVertexAttribArray(this._coordHandle);
        }
        GLES20.glActiveTexture(Texture_0);
        GLES20.glBindTexture(3553, this.yTextureID);
        GLES20.glUniform1i(this.yHandle, 0);
        GLES20.glActiveTexture(Texture_1);
        GLES20.glBindTexture(3553, this.uTextureID);
        GLES20.glUniform1i(this.uHandle, 1);
        GLES20.glActiveTexture(Texture_2);
        GLES20.glBindTexture(3553, this.vTextureID);
        GLES20.glUniform1i(this.vHandle, 2);
        GLES20.glDrawArrays(5, 0, 4);
        GLES20.glFinish();
        GLES20.glDisableVertexAttribArray(this._positionHandle);
        GLES20.glDisableVertexAttribArray(this._coordHandle);
    }

    public int createProgram(String vertexSource, String fragmentSource) {
        int vertexShader = loadShader(35633, vertexSource);
        int pixelShader = loadShader(35632, fragmentSource);
        int program = GLES20.glCreateProgram();
        if (program == 0) {
            return program;
        }
        GLES20.glAttachShader(program, vertexShader);
        GLES20.glAttachShader(program, pixelShader);
        GLES20.glLinkProgram(program);
        int[] linkStatus = new int[1];
        GLES20.glGetProgramiv(program, 35714, linkStatus, 0);
        if (linkStatus[0] == 1) {
            return program;
        }
        GLES20.glDeleteProgram(program);
        return 0;
    }

    private int loadShader(int shaderType, String source) {
        int shader = GLES20.glCreateShader(shaderType);
        if (shader == 0) {
            return shader;
        }
        GLES20.glShaderSource(shader, source);
        GLES20.glCompileShader(shader);
        int[] compiled = new int[1];
        GLES20.glGetShaderiv(shader, 35713, compiled, 0);
        if (compiled[0] != 0) {
            return shader;
        }
        GLES20.glDeleteShader(shader);
        return 0;
    }

    private void createBuffers(float[] vert, float[] coord, float[] coord_reverse) {
        if (this._vertice_buffer == null) {
            this._vertice_buffer = ByteBuffer.allocateDirect(vert.length * 4);
            ((ByteBuffer) this._vertice_buffer).order(ByteOrder.nativeOrder());
            ((ByteBuffer) this._vertice_buffer).asFloatBuffer().put(vert);
            this._vertice_buffer.position(0);
        }
        if (this._coord_buffer == null) {
            this._coord_buffer = ByteBuffer.allocateDirect(coord.length * 4);
            ((ByteBuffer) this._coord_buffer).order(ByteOrder.nativeOrder());
            ((ByteBuffer) this._coord_buffer).asFloatBuffer().put(coord);
            this._coord_buffer.position(0);
        }
        if (this._coord_buffer_reverse == null) {
            this._coord_buffer_reverse = ByteBuffer.allocateDirect(coord_reverse.length * 4);
            ((ByteBuffer) this._coord_buffer_reverse).order(ByteOrder.nativeOrder());
            ((ByteBuffer) this._coord_buffer_reverse).asFloatBuffer().put(coord_reverse);
            this._coord_buffer_reverse.position(0);
        }
    }

    public void ResetBuffer(int screen_mod) {
        switch (screen_mod) {
            case 1:
                ((ByteBuffer) this._vertice_buffer).order(ByteOrder.nativeOrder());
                ((ByteBuffer) this._vertice_buffer).asFloatBuffer().put(squareVertices_PORT);
                return;
            case 2:
                ((ByteBuffer) this._vertice_buffer).order(ByteOrder.nativeOrder());
                ((ByteBuffer) this._vertice_buffer).asFloatBuffer().put(squareVertices_LAND);
                return;
            default:
                return;
        }
    }

    private void checkGlError(String op) {
        if (GLES20.glGetError() != 0) {
            System.out.println("------>Error occur");
        }
    }
}
