package com.macrovideo.sdk.media;

import com.macrovideo.sdk.custom.RecordFileInfo;
import com.macrovideo.sdk.tools.Functions;

public class RecFileDownloader {
    private IDownloadCallback iDownloadCallback = null;
    private boolean isDownloading = false;
    private int nIndex = -1;

    public boolean StartDownloadRecFile(IDownloadCallback iDownloadCallback, String strRecFileName, LoginHandle deviceParam, RecordFileInfo recFile) {
        int nResult;
        this.iDownloadCallback = iDownloadCallback;
        if (this.isDownloading) {
            StopDownloadRecFile();
        }
        boolean isPanoDevice = Functions.getIsPanoDevice(deviceParam.getnDeviceID());
        String strMRServer = Functions._strCurrentMRServer;
        int nMRPort = Functions._nCurrentMRPort;
        String strPanoMRServer = Functions._strCurrentPanoMRServer;
        int nPanoMRPort = Functions._nCurrentPanoMRPort;
        if (isPanoDevice) {
            nResult = LibContext.StartDownloadRecFile(this, strRecFileName, deviceParam.getnDeviceID(), deviceParam.getStrDomain(), deviceParam.getStrIP(), deviceParam.getStrLanIP(), deviceParam.getnPort(), deviceParam.getStrUsername(), deviceParam.getStrPassword(), deviceParam.getnResult(), recFile.getnFileID(), recFile.getStrFileName(), 0, recFile.getuStartHour(), recFile.getuStartMin(), recFile.getuStartSec(), deviceParam.isMRMode(), strPanoMRServer, nPanoMRPort);
        } else {
            nResult = LibContext.StartDownloadRecFile(this, strRecFileName, deviceParam.getnDeviceID(), deviceParam.getStrDomain(), deviceParam.getStrIP(), deviceParam.getStrLanIP(), deviceParam.getnPort(), deviceParam.getStrUsername(), deviceParam.getStrPassword(), deviceParam.getnResult(), recFile.getnFileID(), recFile.getStrFileName(), 0, recFile.getuStartHour(), recFile.getuStartMin(), recFile.getuStartSec(), deviceParam.isMRMode(), strMRServer, nMRPort);
        }
        if (nResult >= 0) {
            this.isDownloading = true;
            this.nIndex = nResult;
            return true;
        }
        this.nIndex = -1;
        return false;
    }

    public boolean isDownloading() {
        return this.isDownloading;
    }

    public boolean StopDownloadRecFile() {
        this.isDownloading = false;
        if (this.nIndex >= 0) {
            LibContext.StopDownloadRecFile(this.nIndex);
        }
        this.iDownloadCallback = null;
        return true;
    }

    public void updateDownloadProgress(int nFlag, int nTimeIndex) {
        if (this.iDownloadCallback != null) {
            this.iDownloadCallback.onDownloadProcess(this, nFlag, nTimeIndex);
        }
    }
}
