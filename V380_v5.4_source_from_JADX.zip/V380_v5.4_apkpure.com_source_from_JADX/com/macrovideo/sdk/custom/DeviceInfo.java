package com.macrovideo.sdk.custom;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.macrovideo.sdk.defines.Defines;

@SuppressLint({"ParcelCreator"})
public class DeviceInfo implements Parcelable {
    public static final Creator CREATOR = new C02331();
    boolean bIsMRMode = false;
    boolean canUpdateDevice = false;
    Bitmap faceImage = null;
    int isAlarmOn = 0;
    boolean isCheck = false;
    boolean isRecvMsg = true;
    boolean isReverse = false;
    int isSynchronized = 0;
    long lLastMsgFreshTime = 0;
    long lLastMsgGetTime = 0;
    long lOnLineStatChaneTime = 0;
    int nDevID = 0;
    int nID = -1;
    int nMRPort = 0;
    int nNewMsgCount = 0;
    int nOnLineStat = 0;
    int nPort = 8800;
    int nProductId = 0;
    int nSaveType = Defines.SERVER_SAVE_TYPE_ADD;
    String strDomain = null;
    String strIP = null;
    String strMRServer = null;
    String strMac = null;
    String strName = null;
    String strPassword = null;
    String strUsername = null;

    class C02331 implements Creator {
        C02331() {
        }

        public DeviceInfo createFromParcel(Parcel in) {
            return new DeviceInfo(in);
        }

        public DeviceInfo[] newArray(int size) {
            return new DeviceInfo[size];
        }
    }

    public boolean isCanUpdateDevice() {
        return this.canUpdateDevice;
    }

    public void setCanUpdateDevice(boolean canUpdateDevice) {
        this.canUpdateDevice = canUpdateDevice;
    }

    public int getisSynchronized() {
        return this.isSynchronized;
    }

    public void setisSynchronized(int isSynchronized) {
        this.isSynchronized = isSynchronized;
    }

    public int getnProductId() {
        return this.nProductId;
    }

    public void setnProductId(int nProductId) {
        this.nProductId = nProductId;
    }

    public int getIsAlarmOn() {
        return this.isAlarmOn;
    }

    public void setIsAlarmOn(int isAlarmOn) {
        this.isAlarmOn = isAlarmOn;
    }

    public long getlOnLineStatChaneTime() {
        return this.lOnLineStatChaneTime;
    }

    public void setlOnLineStatChaneTime(long lOnLineStatChaneTime) {
        this.lOnLineStatChaneTime = lOnLineStatChaneTime;
    }

    public int getnOnLineStat() {
        return this.nOnLineStat;
    }

    public void setnOnLineStat(int nOnLineStat) {
        this.nOnLineStat = nOnLineStat;
    }

    public boolean isbIsMRMode() {
        return this.bIsMRMode;
    }

    public boolean isRecvMsg() {
        return this.isRecvMsg;
    }

    public void setRecvMsg(boolean isRecvMsg) {
        this.isRecvMsg = isRecvMsg;
    }

    public boolean isReverse() {
        return this.isReverse;
    }

    public void setReverse(boolean isReverse) {
        this.isReverse = isReverse;
    }

    public String getStrMRServer() {
        return this.strMRServer;
    }

    public void setStrMRServer(String strMRServer) {
        this.strMRServer = strMRServer;
    }

    public int getnMRPort() {
        return this.nMRPort;
    }

    public void setnMRPort(int nMRPort) {
        this.nMRPort = nMRPort;
    }

    public int getnNewMsgCount() {
        return this.nNewMsgCount;
    }

    public void setnNewMsgCount(int nNewMsgCount) {
        this.nNewMsgCount = nNewMsgCount;
    }

    public long getlLastMsgFreshTime() {
        return this.lLastMsgFreshTime;
    }

    public void setlLastMsgFreshTime(long lLastMsgFreshTime) {
        this.lLastMsgFreshTime = lLastMsgFreshTime;
    }

    public long getlLastMsgGetTime() {
        return this.lLastMsgGetTime;
    }

    public void setlLastMsgGetTime(long lLastMsgGetTime) {
        this.lLastMsgGetTime = lLastMsgGetTime;
    }

    public DeviceInfo copyDeviceInfoWithoutImage() {
        DeviceInfo infoCopy = new DeviceInfo();
        infoCopy.nID = this.nID;
        infoCopy.nDevID = this.nDevID;
        infoCopy.bIsMRMode = this.bIsMRMode;
        infoCopy.strName = this.strName;
        infoCopy.strIP = this.strIP;
        infoCopy.nPort = this.nPort;
        infoCopy.strUsername = this.strUsername;
        infoCopy.strPassword = this.strPassword;
        infoCopy.strMac = this.strMac;
        infoCopy.strDomain = this.strDomain;
        infoCopy.nSaveType = this.nSaveType;
        infoCopy.isCheck = this.isCheck;
        infoCopy.isReverse = this.isReverse;
        infoCopy.isRecvMsg = this.isRecvMsg;
        infoCopy.nOnLineStat = this.nOnLineStat;
        infoCopy.lOnLineStatChaneTime = this.lOnLineStatChaneTime;
        infoCopy.nMRPort = this.nMRPort;
        infoCopy.nNewMsgCount = this.nNewMsgCount;
        infoCopy.strMRServer = this.strMRServer;
        infoCopy.lLastMsgFreshTime = this.lLastMsgFreshTime;
        infoCopy.lLastMsgGetTime = this.lLastMsgGetTime;
        infoCopy.canUpdateDevice = this.canUpdateDevice;
        return infoCopy;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strDomain, int nSaveType) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strDomain, int nSaveType, String strMRServer, int nMRPort) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
        this.strMRServer = strMRServer;
        this.nMRPort = nMRPort;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strDomain, int nSaveType, String strMRServer, int nMRPort, Bitmap faceImage) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
        this.strMRServer = strMRServer;
        this.nMRPort = nMRPort;
        this.faceImage = faceImage;
    }

    public Bitmap getFaceImage() {
        return this.faceImage;
    }

    public void setFaceImage(Bitmap faceImage) {
        this.faceImage = faceImage;
    }

    public void releaseImage() {
        if (this.faceImage != null) {
            this.faceImage.recycle();
        }
        this.faceImage = null;
    }

    public int getnID() {
        return this.nID;
    }

    public int getnDevID() {
        return this.nDevID;
    }

    public String getStrName() {
        return this.strName;
    }

    public String getStrIP() {
        return this.strIP;
    }

    public int getnPort() {
        return this.nPort;
    }

    public String getStrUsername() {
        return this.strUsername;
    }

    public String getStrPassword() {
        return this.strPassword;
    }

    public String getStrMac() {
        return this.strMac;
    }

    public String getStrDomain() {
        return this.strDomain;
    }

    public int getnSaveType() {
        return this.nSaveType;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strMac, String strDomain, int nSaveType) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
        this.strMac = strMac;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strMac, String strDomain, int nSaveType, int isSynchronized) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
        this.strMac = strMac;
        this.isSynchronized = isSynchronized;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strDomain, int nSaveType, Bitmap faceImage) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
        this.faceImage = faceImage;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strDomain, int nSaveType, long lLastFreshTime, long lLastGetTime, int nMsgCount, int nOnlineStat, long lOnlineStatTime, Bitmap faceImage) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
        this.faceImage = faceImage;
        this.lLastMsgFreshTime = lLastFreshTime;
        this.lLastMsgGetTime = lLastGetTime;
        this.nNewMsgCount = nMsgCount;
        this.nOnLineStat = nOnlineStat;
        this.lOnLineStatChaneTime = lOnlineStatTime;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strDomain, int isAlarmOn, int nSaveType, long lLastFreshTime, long lLastGetTime, int nMsgCount, int nOnlineStat, long lOnlineStatTime, Bitmap faceImage) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
        this.faceImage = faceImage;
        this.lLastMsgFreshTime = lLastFreshTime;
        this.lLastMsgGetTime = lLastGetTime;
        this.nNewMsgCount = nMsgCount;
        this.nOnLineStat = nOnlineStat;
        this.lOnLineStatChaneTime = lOnlineStatTime;
        this.isAlarmOn = isAlarmOn;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strDomain, int isAlarmOn, int nSaveType, long lLastFreshTime, long lLastGetTime, int nMsgCount, int nOnlineStat, long lOnlineStatTime, Bitmap faceImage, int productId) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
        this.faceImage = faceImage;
        this.lLastMsgFreshTime = lLastFreshTime;
        this.lLastMsgGetTime = lLastGetTime;
        this.nNewMsgCount = nMsgCount;
        this.nOnLineStat = nOnlineStat;
        this.lOnLineStatChaneTime = lOnlineStatTime;
        this.isAlarmOn = isAlarmOn;
        this.nProductId = productId;
    }

    public DeviceInfo(int nID, int nDevID, String strName, String strIP, int nPort, String strUsername, String strPassword, String strDomain, int isAlarmOn, int nSaveType, long lLastFreshTime, long lLastGetTime, int nMsgCount, int nOnlineStat, long lOnlineStatTime, Bitmap faceImage, int productId, int isSynchronized) {
        this.nID = nID;
        this.bIsMRMode = false;
        this.strName = strName;
        this.strIP = strIP;
        this.nPort = nPort;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.strDomain = strDomain;
        this.nSaveType = nSaveType;
        this.nDevID = nDevID;
        this.faceImage = faceImage;
        this.lLastMsgFreshTime = lLastFreshTime;
        this.lLastMsgGetTime = lLastGetTime;
        this.nNewMsgCount = nMsgCount;
        this.nOnLineStat = nOnlineStat;
        this.lOnLineStatChaneTime = lOnlineStatTime;
        this.isAlarmOn = isAlarmOn;
        this.nProductId = productId;
        this.isSynchronized = isSynchronized;
    }

    public boolean isCheck() {
        return this.isCheck;
    }

    public void setCheck(boolean isCheck) {
        this.isCheck = isCheck;
    }

    public void setnID(int nID) {
        this.nID = nID;
    }

    public void setnDevID(int nDevID) {
        this.nDevID = nDevID;
    }

    public void setbIsMRMode(boolean bIsMRMode) {
        this.bIsMRMode = bIsMRMode;
    }

    public void setStrName(String strName) {
        this.strName = strName;
    }

    public void setStrIP(String strIP) {
        this.strIP = strIP;
    }

    public void setnPort(int nPort) {
        this.nPort = nPort;
    }

    public void setStrUsername(String strUsername) {
        this.strUsername = strUsername;
    }

    public void setStrPassword(String strPassword) {
        this.strPassword = strPassword;
    }

    public void setStrMac(String strMac) {
        this.strMac = strMac;
    }

    public void setStrDomain(String strDomain) {
        this.strDomain = strDomain;
    }

    public void setnSaveType(int nSaveType) {
        this.nSaveType = nSaveType;
    }

    public boolean isMatch(int nDevID, String strUsername, String strPassword) {
        if (this.nDevID != nDevID) {
            return false;
        }
        if ((this.strUsername == null || strUsername == null) && (this.strUsername != null || strUsername != null)) {
            return false;
        }
        if ((this.strPassword == null || strPassword == null) && (this.strPassword != null || strPassword != null)) {
            return false;
        }
        if (this.strUsername == null && strUsername == null && this.strPassword == null && strPassword == null) {
            return true;
        }
        if (this.strUsername == null && strUsername == null) {
            if (this.strPassword.equals(strPassword)) {
                return true;
            }
            return false;
        } else if (this.strPassword == null && strPassword == null) {
            if (this.strUsername.equals(strUsername)) {
                return true;
            }
            return false;
        } else if (this.strUsername.equals(strUsername) && this.strPassword.equals(strPassword)) {
            return true;
        } else {
            return false;
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        int i;
        int i2 = 1;
        dest.writeInt(this.nID);
        dest.writeInt(this.nDevID);
        dest.writeByte((byte) (this.bIsMRMode ? 1 : 0));
        dest.writeString(this.strName);
        dest.writeString(this.strIP);
        dest.writeInt(this.nPort);
        dest.writeString(this.strUsername);
        dest.writeString(this.strPassword);
        dest.writeString(this.strMac);
        dest.writeString(this.strDomain);
        dest.writeInt(this.nSaveType);
        if (this.isCheck) {
            i = 1;
        } else {
            i = 0;
        }
        dest.writeByte((byte) i);
        dest.writeValue(this.faceImage);
        if (this.isReverse) {
            i = 1;
        } else {
            i = 0;
        }
        dest.writeByte((byte) i);
        dest.writeInt(this.isAlarmOn);
        dest.writeInt(this.nProductId);
        dest.writeInt(this.isSynchronized);
        if (!this.canUpdateDevice) {
            i2 = 0;
        }
        dest.writeInt(i2);
    }

    public DeviceInfo(Parcel in) {
        boolean z;
        boolean z2 = true;
        this.nID = in.readInt();
        this.nDevID = in.readInt();
        this.bIsMRMode = in.readByte() == (byte) 1;
        this.strName = in.readString();
        this.strIP = in.readString();
        this.nPort = in.readInt();
        this.strUsername = in.readString();
        this.strPassword = in.readString();
        this.strMac = in.readString();
        this.strDomain = in.readString();
        this.nSaveType = in.readInt();
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isCheck = z;
        this.faceImage = (Bitmap) in.readValue(Bitmap.class.getClassLoader());
        if (in.readByte() == (byte) 1) {
            z = true;
        } else {
            z = false;
        }
        this.isReverse = z;
        this.isAlarmOn = in.readInt();
        this.nProductId = in.readInt();
        this.isSynchronized = in.readInt();
        if (in.readInt() != 1) {
            z2 = false;
        }
        this.canUpdateDevice = z2;
    }
}
