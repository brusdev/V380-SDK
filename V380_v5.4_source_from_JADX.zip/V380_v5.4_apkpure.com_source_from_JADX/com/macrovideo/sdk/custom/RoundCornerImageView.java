package com.macrovideo.sdk.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.widget.ImageView;

public class RoundCornerImageView extends ImageView {
    public RoundCornerImageView(Context context) {
        super(context);
        if (VERSION.SDK_INT >= 11) {
            setLayerType(1, null);
        }
    }

    public RoundCornerImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (VERSION.SDK_INT >= 11) {
            setLayerType(1, null);
        }
    }

    public RoundCornerImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        if (VERSION.SDK_INT >= 11) {
            setLayerType(1, null);
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Path clipPath = new Path();
        clipPath.addRoundRect(new RectF(0.0f, 0.0f, (float) getWidth(), (float) getHeight()), 10.0f, 10.0f, Direction.CW);
        canvas.clipPath(clipPath);
    }
}
