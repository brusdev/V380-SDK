package com.macrovideo.sdk.custom;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class RecordFileInfo implements Parcelable {
    public static final Creator CREATOR = new C02341();
    private int nFileDownloadProgress = 0;
    private int nFileID = -1;
    private int nFileSize = 0;
    private int nFileState = 2;
    private String strFileName;
    private int uEndHour = 0;
    private int uEndMin = 0;
    private int uEndSec = 0;
    private int uFileTimeLen = 0;
    private int uStartHour = 0;
    private int uStartMin = 0;
    private int uStartSec = 0;

    class C02341 implements Creator {
        C02341() {
        }

        public RecordFileInfo createFromParcel(Parcel in) {
            return new RecordFileInfo(in);
        }

        public RecordFileInfo[] newArray(int size) {
            return new RecordFileInfo[size];
        }
    }

    public int getnFileState() {
        return this.nFileState;
    }

    public void setnFileState(int nFileState) {
        this.nFileState = nFileState;
    }

    public int getnFileDownloadProgress() {
        return this.nFileDownloadProgress;
    }

    public void setnFileDownloadProgress(int nFileDownloadProgress) {
        this.nFileDownloadProgress = nFileDownloadProgress;
    }

    public int getnFileID() {
        return this.nFileID;
    }

    public void setnFileID(int nFileID) {
        this.nFileID = nFileID;
    }

    public int getnFileSize() {
        return this.nFileSize;
    }

    public void setnFileSize(int nFileSize) {
        this.nFileSize = nFileSize;
    }

    public String getStrFileName() {
        return this.strFileName;
    }

    public void setStrFileName(String strFileName) {
        this.strFileName = strFileName;
    }

    public void setuStartHour(int uStartHour) {
        this.uStartHour = uStartHour;
    }

    public void setuStartMin(int uStartMin) {
        this.uStartMin = uStartMin;
    }

    public void setuStartSec(int uStartSec) {
        this.uStartSec = uStartSec;
    }

    public int getuEndHour() {
        return this.uEndHour;
    }

    public void setuEndHour(int uEndHour) {
        this.uEndHour = uEndHour;
    }

    public int getuEndMin() {
        return this.uEndMin;
    }

    public void setuEndMin(int uEndMin) {
        this.uEndMin = uEndMin;
    }

    public int getuEndSec() {
        return this.uEndSec;
    }

    public void setuEndSec(int uEndSec) {
        this.uEndSec = uEndSec;
    }

    public void setuFileTimeLen(int uFileTimeLen) {
        this.uFileTimeLen = uFileTimeLen;
    }

    public RecordFileInfo(int nFileID, int nFileSize, int uStartHour, int uStartMin, int uStartSec, int uFileTimeLen, String strFileName) {
        this.nFileID = nFileID;
        this.nFileSize = nFileSize;
        this.strFileName = strFileName;
        this.uStartHour = uStartHour;
        this.uStartMin = uStartMin;
        this.uStartSec = uStartSec;
        this.uFileTimeLen = uFileTimeLen;
    }

    public RecordFileInfo(int nFileID, int nFileSize, int uStartHour, int uStartMin, int uStartSec, int uEndHour, int uEndMin, int uEndSec, int uFileTimeLen, String strFileName) {
        this.nFileID = nFileID;
        this.nFileSize = nFileSize;
        this.strFileName = strFileName;
        this.uStartHour = uStartHour;
        this.uStartMin = uStartMin;
        this.uStartSec = uStartSec;
        this.uEndHour = uEndHour;
        this.uEndMin = uEndMin;
        this.uEndSec = uEndSec;
        this.uFileTimeLen = uFileTimeLen;
    }

    public int getuStartHour() {
        return this.uStartHour;
    }

    public int getuStartMin() {
        return this.uStartMin;
    }

    public int getuStartSec() {
        return this.uStartSec;
    }

    public int getuFileTimeLen() {
        return this.uFileTimeLen;
    }

    public RecordFileInfo(Parcel in) {
        this.nFileID = in.readInt();
        this.nFileSize = in.readInt();
        this.strFileName = in.readString();
        this.uStartHour = in.readInt();
        this.uStartMin = in.readInt();
        this.uStartSec = in.readInt();
        this.uEndHour = in.readInt();
        this.uEndMin = in.readInt();
        this.uEndSec = in.readInt();
        this.uFileTimeLen = in.readInt();
        this.nFileState = in.readInt();
        this.nFileDownloadProgress = in.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int arg1) {
        parcel.writeInt(this.nFileID);
        parcel.writeInt(this.nFileSize);
        parcel.writeString(this.strFileName);
        parcel.writeInt(this.uStartHour);
        parcel.writeInt(this.uStartMin);
        parcel.writeInt(this.uStartSec);
        parcel.writeInt(this.uEndHour);
        parcel.writeInt(this.uEndMin);
        parcel.writeInt(this.uEndSec);
        parcel.writeInt(this.uFileTimeLen);
        parcel.writeInt(this.nFileState);
        parcel.writeInt(this.nFileDownloadProgress);
    }

    public String toString() {
        return "nFileID = " + this.nFileID + " nFileSize = " + this.nFileSize + " strFileName = " + this.strFileName + " uStartHour = " + this.uStartHour + " uStartMin = " + this.uStartMin + " uStartSec = " + this.uStartSec + " uEndHour = " + this.uEndHour + " uEndMin = " + this.uEndMin + " uEndSec = " + this.uEndSec + " uFileTimeLen = " + this.uFileTimeLen;
    }
}
