package com.macrovideo.sdk.objects;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.widget.TextView;
import com.macrovideo.photo.PhotoViewAttacher;

public class MarqueeTextView extends TextView {
    private float mCoordinateX;
    private Handler mHandler = new C02361();
    private boolean mStopMarquee;
    private String mText;
    private float mTextWidth;

    class C02361 extends Handler {
        C02361() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    if (Math.abs(MarqueeTextView.this.mCoordinateX) <= MarqueeTextView.this.mTextWidth + 100.0f) {
                        MarqueeTextView marqueeTextView = MarqueeTextView.this;
                        marqueeTextView.mCoordinateX = marqueeTextView.mCoordinateX - PhotoViewAttacher.DEFAULT_MIN_SCALE;
                        MarqueeTextView.this.invalidate();
                        if (!MarqueeTextView.this.mStopMarquee) {
                            sendEmptyMessageDelayed(0, 30);
                            break;
                        }
                    }
                    MarqueeTextView.this.mCoordinateX = 0.0f;
                    MarqueeTextView.this.invalidate();
                    if (!MarqueeTextView.this.mStopMarquee) {
                        sendEmptyMessageDelayed(0, 2000);
                        break;
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    }

    public MarqueeTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setText(String text) {
        this.mText = text;
        this.mTextWidth = getPaint().measureText(this.mText);
        if (this.mHandler.hasMessages(0)) {
            this.mHandler.removeMessages(0);
        }
        this.mHandler.sendEmptyMessageDelayed(0, 2000);
    }

    protected void onAttachedToWindow() {
        this.mStopMarquee = false;
        if (this.mText != null && this.mText.length() > 0) {
            this.mHandler.sendEmptyMessageDelayed(0, 2000);
        }
        super.onAttachedToWindow();
    }

    protected void onDetachedFromWindow() {
        this.mStopMarquee = true;
        if (this.mHandler.hasMessages(0)) {
            this.mHandler.removeMessages(0);
        }
        super.onDetachedFromWindow();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.mText != null && this.mText.length() > 0) {
            canvas.drawText(this.mText, this.mCoordinateX, 15.0f, getPaint());
        }
    }
}
