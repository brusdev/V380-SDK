package com.macrovideo.sdk.objects;

import android.widget.Button;
import android.widget.ImageView;

public class ObjectItemsRecordForMap {
    public Button btnAlarm = null;
    public ImageView imgBtnFace = null;
    public int nDevID = 0;
    public int nId = -1;

    public ObjectItemsRecordForMap(int nId, int nDevID, Button btnAlarm, ImageView imgBtnFace) {
        this.nId = nId;
        this.nDevID = nDevID;
        this.btnAlarm = btnAlarm;
        this.imgBtnFace = imgBtnFace;
    }
}
