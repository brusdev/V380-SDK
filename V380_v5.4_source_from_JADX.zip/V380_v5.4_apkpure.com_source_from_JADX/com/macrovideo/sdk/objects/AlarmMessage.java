package com.macrovideo.sdk.objects;

import android.graphics.Bitmap;

public class AlarmMessage {
    private Bitmap image = null;
    private long lSaveTime;
    private int nAlarmID;
    private int nAlarmLevel;
    private int nAlarmType;
    private int nDevID;
    private int nFloor = 0;
    private int nID = 0;
    private int nRoom = 0;
    private int nSaveID;
    private String strAlarmMsg;
    private String strAlarmTime;

    public AlarmMessage(int nID, int nSaveID, int nAlarmID, int nDevID, int nAlarmType, int nAlarmLevel, int nFloor, int nRoom, String strAlarmMsg, String strAlarmTime, long lSaveTime) {
        this.nID = nID;
        this.nSaveID = nSaveID;
        this.nAlarmID = nAlarmID;
        this.nDevID = nDevID;
        this.nAlarmType = nAlarmType;
        this.nAlarmLevel = nAlarmLevel;
        this.nFloor = nFloor;
        this.nRoom = nRoom;
        this.strAlarmMsg = strAlarmMsg;
        this.strAlarmTime = strAlarmTime;
        this.lSaveTime = lSaveTime;
    }

    public AlarmMessage(int nID, int nSaveID, int nAlarmID, int nDevID, int nAlarmType, int nAlarmLevel, int nFloor, int nRoom, String strAlarmMsg, String strAlarmTime, long lSaveTime, Bitmap image) {
        this.nID = nID;
        this.nSaveID = nSaveID;
        this.nAlarmID = nAlarmID;
        this.nDevID = nDevID;
        this.nAlarmType = nAlarmType;
        this.nAlarmLevel = nAlarmLevel;
        this.nFloor = nFloor;
        this.nRoom = nRoom;
        this.strAlarmMsg = strAlarmMsg;
        this.strAlarmTime = strAlarmTime;
        this.lSaveTime = lSaveTime;
        this.image = image;
    }

    public int getnFloor() {
        return this.nFloor;
    }

    public void setnFloor(int nFloor) {
        this.nFloor = nFloor;
    }

    public int getnRoom() {
        return this.nRoom;
    }

    public void setnRoom(int nRoom) {
        this.nRoom = nRoom;
    }

    public Bitmap getImage() {
        return this.image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public int getnID() {
        return this.nID;
    }

    public int getnSaveID() {
        return this.nSaveID;
    }

    public int getnAlarmID() {
        return this.nAlarmID;
    }

    public int getnDevID() {
        return this.nDevID;
    }

    public int getnAlarmType() {
        return this.nAlarmType;
    }

    public int getnAlarmLevel() {
        return this.nAlarmLevel;
    }

    public String getStrAlarmMsg() {
        return this.strAlarmMsg;
    }

    public String getStrAlarmTime() {
        return this.strAlarmTime;
    }

    public long getLSaveTime() {
        return this.lSaveTime;
    }
}
