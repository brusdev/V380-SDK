package com.macrovideo.sdk.objects;

import java.util.ArrayList;

public class AlarmMessageResult {
    long lLastAlarmTime = 0;
    ArrayList<AlarmMessage> list = null;
    int nReuslt = 0;

    public void addToList(AlarmMessage msg) {
        this.list.add(0, msg);
    }

    public int getnReuslt() {
        return this.nReuslt;
    }

    public void setnReuslt(int nReuslt) {
        this.nReuslt = nReuslt;
    }

    public long getlLastAlarmTime() {
        return this.lLastAlarmTime;
    }

    public void setlLastAlarmTime(long lLastAlarmTime) {
        this.lLastAlarmTime = lLastAlarmTime;
    }

    public ArrayList<AlarmMessage> getList() {
        return this.list;
    }
}
