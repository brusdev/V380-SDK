package com.macrovideo.sdk.objects;

import android.graphics.Bitmap;

public class PTZXPoint {
    private Bitmap faceImage = null;
    private long lSaveTime = 0;
    private int nDevID = 0;
    private int nID = -1;
    private int nPTZXID = 0;

    public PTZXPoint(int nID, int nDevID, int nPTZXID, long lSaveTime, Bitmap faceImage) {
        this.nID = nID;
        this.nDevID = nDevID;
        this.nPTZXID = nPTZXID;
        this.lSaveTime = lSaveTime;
        this.faceImage = faceImage;
    }

    public int getnID() {
        return this.nID;
    }

    public void setnID(int nID) {
        this.nID = nID;
    }

    public int getnDevID() {
        return this.nDevID;
    }

    public void setnDevID(int nDevID) {
        this.nDevID = nDevID;
    }

    public int getnPTZXID() {
        return this.nPTZXID;
    }

    public void setnPTZXID(int nPTZXID) {
        this.nPTZXID = nPTZXID;
    }

    public long getlSaveTime() {
        return this.lSaveTime;
    }

    public void setlSaveTime(long lSaveTime) {
        this.lSaveTime = lSaveTime;
    }

    public Bitmap getFaceImage() {
        return this.faceImage;
    }

    public void setFaceImage(Bitmap faceImage) {
        this.faceImage = faceImage;
    }
}
