package com.macrovideo.sdk.objects;

import android.graphics.Bitmap;

public class ObjectAlarmMessage {
    private boolean bHasPosition;
    private Bitmap image = null;
    private long lSaveTime;
    private int nAlarmID;
    private int nAlarmLevel;
    private int nAlarmType;
    private int nDevID;
    private int nID = 0;
    private int nSaveID;
    private int nVersion;
    private String strAlarmImage;
    private String strAlarmMsg;
    private String strAlarmTime;
    private String strImageIp;

    public ObjectAlarmMessage(int nID, int nSaveID, int nAlarmID, int nDevID, int nAlarmType, int nAlarmLevel, String strAlarmMsg, String strAlarmTime, long lSaveTime, String strAlarmImagae, String strImageIp, boolean bHasPosition, int nVersion) {
        this.nID = nID;
        this.nSaveID = nSaveID;
        this.nAlarmID = nAlarmID;
        this.nDevID = nDevID;
        this.nAlarmType = nAlarmType;
        this.nAlarmLevel = nAlarmLevel;
        this.strAlarmMsg = strAlarmMsg;
        this.strAlarmTime = strAlarmTime;
        this.lSaveTime = lSaveTime;
        this.strAlarmImage = strAlarmImagae;
        this.strImageIp = strImageIp;
        this.bHasPosition = bHasPosition;
        this.nVersion = nVersion;
    }

    public ObjectAlarmMessage(int nID, int nSaveID, int nAlarmID, int nDevID, int nAlarmType, int nAlarmLevel, String strAlarmMsg, String strAlarmTime, long lSaveTime, String strAlarmImagae, String strImageIp, boolean bHasPosition) {
        this.nID = nID;
        this.nSaveID = nSaveID;
        this.nAlarmID = nAlarmID;
        this.nDevID = nDevID;
        this.nAlarmType = nAlarmType;
        this.nAlarmLevel = nAlarmLevel;
        this.strAlarmMsg = strAlarmMsg;
        this.strAlarmTime = strAlarmTime;
        this.lSaveTime = lSaveTime;
        this.strAlarmImage = strAlarmImagae;
        this.strImageIp = strImageIp;
        this.bHasPosition = bHasPosition;
    }

    public ObjectAlarmMessage(int nID, int nSaveID, int nAlarmID, int nDevID, int nAlarmType, int nAlarmLevel, String strAlarmMsg, String strAlarmTime, long lSaveTime, Bitmap image, String strAlarmImagae, String strImageIp, boolean bHasPosition) {
        this.nID = nID;
        this.nSaveID = nSaveID;
        this.nAlarmID = nAlarmID;
        this.nDevID = nDevID;
        this.nAlarmType = nAlarmType;
        this.nAlarmLevel = nAlarmLevel;
        this.strAlarmMsg = strAlarmMsg;
        this.strAlarmTime = strAlarmTime;
        this.lSaveTime = lSaveTime;
        this.image = image;
        this.strAlarmImage = strAlarmImagae;
        this.strImageIp = strImageIp;
        this.bHasPosition = bHasPosition;
    }

    public Bitmap getImage() {
        return this.image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public int getnID() {
        return this.nID;
    }

    public int getnSaveID() {
        return this.nSaveID;
    }

    public int getnAlarmID() {
        return this.nAlarmID;
    }

    public int getnDevID() {
        return this.nDevID;
    }

    public int getnAlarmType() {
        return this.nAlarmType;
    }

    public int getnAlarmLevel() {
        return this.nAlarmLevel;
    }

    public String getStrAlarmMsg() {
        return this.strAlarmMsg;
    }

    public String getStrAlarmTime() {
        return this.strAlarmTime;
    }

    public long getLSaveTime() {
        return this.lSaveTime;
    }

    public String getStrAlarmImage() {
        return this.strAlarmImage;
    }

    public void setStrAlarmImage(String strAlarmImage) {
        this.strAlarmImage = strAlarmImage;
    }

    public String getStrImageIp() {
        return this.strImageIp;
    }

    public boolean getbHasPosition() {
        return this.bHasPosition;
    }

    public int getnVersion() {
        return this.nVersion;
    }

    public void setnVersion(int nVersion) {
        this.nVersion = nVersion;
    }
}
