package com.macrovideo.sdk.objects;

public class ObjectUserInfo {
    private long freshTime = 0;
    private int nUID = 0;
    private String strPassword;
    private String strUsername;

    public long getFreshTime() {
        return this.freshTime;
    }

    public void setFreshTime(long freshTime) {
        this.freshTime = freshTime;
    }

    public int getnUID() {
        return this.nUID;
    }

    public void setnUID(int nUID) {
        this.nUID = nUID;
    }

    public String getStrUsername() {
        return this.strUsername;
    }

    public void setStrUsername(String strUsername) {
        this.strUsername = strUsername;
    }

    public String getStrPassword() {
        return this.strPassword;
    }

    public void setStrPassword(String strPassword) {
        this.strPassword = strPassword;
    }
}
