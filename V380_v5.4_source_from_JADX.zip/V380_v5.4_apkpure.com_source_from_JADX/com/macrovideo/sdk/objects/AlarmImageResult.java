package com.macrovideo.sdk.objects;

import android.graphics.Bitmap;

public class AlarmImageResult {
    private Bitmap aImage = null;
    private int nPCount = 0;
    private int nReuslt = 0;
    private String strPositionSet = null;

    public int getnPCount() {
        return this.nPCount;
    }

    public void setnPCount(int nPCount) {
        this.nPCount = nPCount;
    }

    public String getStrPositionSet() {
        return this.strPositionSet;
    }

    public void setStrPositionSet(String strPositionSet) {
        this.strPositionSet = strPositionSet;
    }

    public int getnReuslt() {
        return this.nReuslt;
    }

    public void setnReuslt(int nReuslt) {
        this.nReuslt = nReuslt;
    }

    public Bitmap getaImage() {
        return this.aImage;
    }

    public void setaImage(Bitmap aImage) {
        this.aImage = aImage;
    }
}
