package com.macrovideo.sdk.stransport;

public class TransData {
    private byte[] data = null;
    private int nResultCode = 0;
    private int nSize = 0;

    TransData(int nResult, byte[] buffer, int nStartIndex, int nEndIndex) {
        this.nResultCode = nResult;
        this.nSize = nEndIndex - nStartIndex;
        if (buffer != null && this.nSize > 0 && buffer.length > 0 && nEndIndex <= buffer.length && nStartIndex >= 0) {
            this.data = new byte[this.nSize];
            System.arraycopy(buffer, nStartIndex, this.data, 0, this.nSize);
        }
    }

    public int getnResultCode() {
        return this.nResultCode;
    }

    public int getnSize() {
        return this.nSize;
    }

    public byte[] getData() {
        return this.data;
    }
}
