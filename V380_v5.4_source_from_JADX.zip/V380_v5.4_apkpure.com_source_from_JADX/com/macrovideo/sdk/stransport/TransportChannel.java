package com.macrovideo.sdk.stransport;

import com.macrovideo.sdk.custom.DeviceInfo;
import com.macrovideo.sdk.defines.Defines;
import com.macrovideo.sdk.defines.ResultCode;
import com.macrovideo.sdk.tools.Functions;
import com.tencent.android.tpush.common.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Arrays;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

class TransportChannel {
    static final int MAX_QUEUE_SIZE = 20;
    private byte[] buffer = new byte[412];
    private boolean isOpen = false;
    private boolean isUse = false;
    private long lHandle = 0;
    private int nCurrentOPID = 0;
    private short nDataID = (short) 0;
    private int nDeviceID = 0;
    private int nPort = 8800;
    private int nThreadID = 0;
    private BlockingQueue<TransData> queue = new ArrayBlockingQueue(20);
    private InputStream reader = null;
    private byte[] recvBuffer = new byte[128];
    private Socket sSocket = null;
    private String strIP = "192.168.0.1";
    private String strPassword = Constants.MAIN_VERSION_TAG;
    private String strUsername = "admin";
    private OutputStream writer = null;

    class Reciever extends Thread {
        int nID = 0;

        Reciever(int nID) {
            this.nID = nID;
        }

        public void run() {
            while (TransportChannel.this.nThreadID == this.nID) {
                Arrays.fill(TransportChannel.this.buffer, (byte) 0);
                boolean bReadOK = false;
                int i = 0;
                while (i < 500 && TransportChannel.this.nThreadID == this.nID) {
                    try {
                        if (TransportChannel.this.reader.available() >= 128) {
                            TransportChannel.this.reader.read(TransportChannel.this.buffer, 0, 128);
                            bReadOK = true;
                            break;
                        }
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        i++;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                if (bReadOK) {
                    int nResultCmd = Functions.BytesToInt(TransportChannel.this.buffer, 0);
                    if (nResultCmd == Defines.NV_IPC_CUSTOM_TRANSPORT_RECV_REQUEST) {
                        int nDataID = Functions.BytesToShort(TransportChannel.this.buffer, 4);
                        int nSize = Functions.BytesToShort(TransportChannel.this.buffer, 6);
                        if (nSize > 0) {
                            TransportChannel.this.PutData(new TransData(256, TransportChannel.this.buffer, 8, nSize + 8));
                        }
                    } else if (nResultCmd == Defines.NV_IPC_ALIVE) {
                        System.out.println("Defines.NV_IPC_ALIVE");
                    }
                }
            }
        }
    }

    private void startRecv() {
        this.nThreadID++;
        new Reciever(this.nThreadID).start();
    }

    private int RebuildChannel() {
        this.nCurrentOPID++;
        if (this.sSocket != null) {
            CloseSocket();
        }
        int nResult = OpenFormServer(this.nDeviceID, this.strIP, this.nPort, this.strUsername, this.strPassword, this.nCurrentOPID);
        if (nResult == 256) {
            this.isOpen = true;
            startRecv();
        }
        return nResult;
    }

    public int Open(DeviceInfo info) {
        this.nCurrentOPID++;
        if (this.sSocket != null) {
            CloseSocket();
        }
        int nOPID = this.nCurrentOPID;
        this.queue.clear();
        int nResult = OpenFormServer(info.getnDevID(), info.getStrIP(), info.getnPort(), info.getStrUsername(), info.getStrPassword(), nOPID);
        if (nResult == 256) {
            this.nDeviceID = info.getnDevID();
            this.strIP = info.getStrIP();
            this.nPort = info.getnPort();
            this.strUsername = info.getStrUsername();
            this.strPassword = info.getStrPassword();
            this.isOpen = true;
            startRecv();
        }
        return nResult;
    }

    private int OpenFormServer(int nDeviceID, String strIP, int nPort, String strUsername, String strPassword, int nOPID) {
        int nResult = 0;
        System.out.println("OpenFormServer: " + this.nCurrentOPID + ", " + nOPID);
        if (this.nCurrentOPID == nOPID) {
            System.out.println("OpenFormServer: " + strIP + ", " + nPort + ", " + nDeviceID);
            this.sSocket = Functions.connectToServer(strIP, nPort, Defines.CMD_MR_WAIT);
            if (this.sSocket == null) {
                System.out.println("OpenFormServer: connect fail");
                return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
            }
            try {
                if (this.sSocket.isConnected()) {
                    this.writer = this.sSocket.getOutputStream();
                    this.reader = this.sSocket.getInputStream();
                } else {
                    nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
            } catch (IOException e) {
                nResult = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                if (this.writer != null) {
                    try {
                        this.writer.close();
                    } catch (IOException e2) {
                    }
                }
                this.writer = null;
                if (this.reader != null) {
                    try {
                        this.reader.close();
                    } catch (IOException e3) {
                    }
                }
                this.reader = null;
                if (this.sSocket != null) {
                    try {
                        this.sSocket.close();
                    } catch (IOException e4) {
                    }
                }
                this.sSocket = null;
            }
            if (this.nCurrentOPID == nOPID && nResult == 0) {
                Arrays.fill(this.buffer, (byte) 0);
                Functions.IntToBytes((long) Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_REQUEST, this.buffer, 0);
                if (strUsername != null && strUsername.length() > 0) {
                    System.arraycopy(strUsername.getBytes(), 0, this.buffer, 4, strUsername.getBytes().length);
                }
                if (strPassword != null && strPassword.length() > 0) {
                    System.arraycopy(strPassword.getBytes(), 0, this.buffer, 36, strPassword.getBytes().length);
                }
                Functions.IntToBytes((long) nDeviceID, this.buffer, 68);
                try {
                    this.writer.write(this.buffer, 0, 412);
                    this.writer.flush();
                    Arrays.fill(this.buffer, (byte) 0);
                    boolean bReadOK = false;
                    int i = 0;
                    while (i < 500) {
                        try {
                            if (this.reader.available() >= 412) {
                                this.reader.read(this.buffer, 0, 412);
                                bReadOK = true;
                                break;
                            }
                            try {
                                Thread.sleep(20);
                            } catch (InterruptedException e5) {
                                e5.printStackTrace();
                            }
                            i++;
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    System.out.println("OpenFormServer recv: " + bReadOK);
                    if (bReadOK) {
                        int nResultCmd = Functions.BytesToInt(this.buffer, 0);
                        int nResultValue = Functions.BytesToInt(this.buffer, 4);
                        if (nResultCmd == Defines.NV_IPC_CUSTOM_TRANSPORT_CREATE_RESPONSE) {
                            System.out.println("OpenFormServer ok nResultValue= " + nResultValue);
                            if (nResultValue == 1001) {
                                nResult = 256;
                            }
                        }
                    }
                } catch (IOException e6) {
                    try {
                        this.writer.close();
                        this.reader.close();
                    } catch (IOException e7) {
                        e7.printStackTrace();
                    }
                    return ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                }
            }
        }
        if (nResult != 256) {
            CloseSocket();
        }
        return nResult;
    }

    public synchronized int SendData(byte[] data, int nSize) {
        int i;
        if (data != null) {
            if (data.length >= nSize) {
                if (nSize >= 120) {
                    i = -103;
                } else if ((this.writer == null || this.sSocket.isInputShutdown() || this.sSocket.isClosed()) && RebuildChannel() != 256) {
                    i = -105;
                } else {
                    i = -1;
                    if (this.writer != null) {
                        this.nDataID = (short) (this.nDataID + 1);
                        short uSize = (short) nSize;
                        Arrays.fill(this.buffer, (byte) 0);
                        Functions.IntToBytes((long) Defines.NV_IPC_CUSTOM_TRANSPORT_SEND_REQUEST, this.buffer, 0);
                        Functions.ShortToBytes(this.nDataID, this.buffer, 4);
                        Functions.ShortToBytes(uSize, this.buffer, 6);
                        System.arraycopy(data, 0, this.buffer, 8, nSize);
                        try {
                            this.writer.write(this.buffer, 0, 128);
                            this.writer.flush();
                            i = nSize;
                        } catch (IOException e) {
                            try {
                                this.writer.close();
                                this.reader.close();
                            } catch (IOException e2) {
                                e2.printStackTrace();
                            }
                            i = ResultCode.RESULT_CODE_FAIL_SERVER_CONNECT_FAIL;
                        }
                    }
                }
            }
        }
        i = -104;
        return i;
    }

    private boolean CloseSocket() {
        if (this.writer != null) {
            try {
                this.writer.close();
            } catch (IOException e) {
            }
            this.writer = null;
        }
        if (this.reader != null) {
            try {
                this.reader.close();
            } catch (IOException e2) {
            }
        }
        if (this.sSocket != null || this.sSocket.isConnected()) {
            try {
                this.sSocket.close();
            } catch (IOException e3) {
            }
        }
        this.writer = null;
        this.reader = null;
        this.sSocket = null;
        return true;
    }

    public boolean Close() {
        this.nThreadID++;
        this.nCurrentOPID++;
        this.isOpen = false;
        CloseSocket();
        return true;
    }

    public long getlHandle() {
        return this.lHandle;
    }

    public void setlHandle(long lHandle) {
        this.lHandle = lHandle;
    }

    public int getnDeviceID() {
        return this.nDeviceID;
    }

    public void setnDeviceID(int nDeviceID) {
        this.nDeviceID = nDeviceID;
    }

    public boolean isUse() {
        return this.isUse;
    }

    public void setUse(boolean isUse) {
        this.isUse = isUse;
    }

    private int PutData(TransData data) {
        if (data == null) {
            return 0;
        }
        try {
            if (this.queue.size() >= 20) {
                this.queue.take();
            }
            this.queue.put(data);
            return 1;
        } catch (InterruptedException e) {
            return 0;
        }
    }

    public TransData getData() {
        if (this.queue.isEmpty()) {
            return null;
        }
        TransData dataOject;
        try {
            dataOject = (TransData) this.queue.take();
        } catch (InterruptedException e) {
            dataOject = null;
        }
        return dataOject;
    }
}
