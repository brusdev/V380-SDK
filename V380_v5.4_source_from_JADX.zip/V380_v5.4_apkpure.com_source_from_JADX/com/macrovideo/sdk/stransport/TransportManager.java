package com.macrovideo.sdk.stransport;

import com.macrovideo.sdk.custom.DeviceInfo;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class TransportManager {
    private static final int LIST_SIZE = 10;
    private static final int PREX_SIZE = 10010;
    public static TransportChannel[] channelList = null;
    private static Lock lock = new ReentrantLock();

    static {
        initChannelList();
    }

    private static void initChannelList() {
        channelList = new TransportChannel[10];
        for (int i = 0; i < 10; i++) {
            channelList[i] = new TransportChannel();
            channelList[i].setUse(false);
        }
    }

    private static int isExist(DeviceInfo info) {
        int isExist = -1;
        lock.lock();
        for (int i = 0; i < 10; i++) {
            TransportChannel channel = channelList[i];
            if (channel != null && channel.isUse() && channel.getnDeviceID() == info.getnDevID()) {
                isExist = i;
                break;
            }
        }
        lock.unlock();
        return isExist;
    }

    public static long CreateTransportChannel(DeviceInfo info) {
        int nIsExist = isExist(info);
        if (nIsExist >= 0) {
            return (long) (nIsExist + PREX_SIZE);
        }
        TransportChannel channel = null;
        lock.lock();
        int i = 0;
        while (i < 10) {
            if (channelList[i] != null && !channelList[i].isUse()) {
                channel = channelList[i];
                nIsExist = i;
                break;
            }
            i++;
        }
        lock.unlock();
        if (channel == null) {
            return -101;
        }
        int nResult = channel.Open(info);
        if (nResult == 256) {
            return (long) (nIsExist + PREX_SIZE);
        }
        return (long) nResult;
    }

    public static void DestroyTransportChannel(long lHandle) {
        int nIndex = (int) (lHandle - 10010);
        if (nIndex >= 0 && nIndex < 10) {
            TransportChannel channel = channelList[nIndex];
            if (channel != null) {
                channel.Close();
                channel.setUse(false);
            }
        }
    }

    public static int SendData(long lHandle, byte[] data, int nSize) {
        int nIndex = (int) (lHandle - 10010);
        if (nIndex < 0 || nIndex >= 10) {
            return 0;
        }
        TransportChannel channel = channelList[nIndex];
        if (channel != null) {
            return channel.SendData(data, nSize);
        }
        return 0;
    }

    public static TransData RecvData(long lHandle, int nTimeout) {
        TransData data = null;
        int nIndex = (int) (lHandle - 10010);
        if (nIndex >= 0 && nIndex < 10) {
            TransportChannel channel = channelList[nIndex];
            if (channel != null) {
                int nTimes = (nTimeout / 20) + 1;
                for (int i = 0; i < nTimes; i++) {
                    data = channel.getData();
                    if (data != null) {
                        break;
                    }
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return data;
    }
}
