package com.macrovideo.media.audio;

public interface PlayState {
    public static final int MPS_PAUSE = 3;
    public static final int MPS_PLAYING = 2;
    public static final int MPS_PREPARE = 1;
    public static final int MPS_UNINIT = 0;
}
