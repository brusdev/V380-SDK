package com.macrovideo.media.audio;

public class AudioDataObject {
    private byte[] m_Data = null;
    private int m_nFrameType = 0;
    private int m_nSize = -1;

    public AudioDataObject(byte[] data, int nStartIndex, int nEndIndex, int nType) {
        this.m_nSize = nEndIndex - nStartIndex;
        this.m_nFrameType = nType;
        if (data != null && this.m_nSize > 0 && data.length > 0 && nEndIndex <= data.length && nStartIndex >= 0) {
            this.m_Data = new byte[this.m_nSize];
            System.arraycopy(data, nStartIndex, this.m_Data, 0, this.m_nSize);
        }
    }

    public int getM_nFrameType() {
        return this.m_nFrameType;
    }

    public byte[] getM_Data() {
        return this.m_Data;
    }
}
