package com.macrovideo.media.audio;

public interface IPlayComplete {
    void onPlayComplete();
}
