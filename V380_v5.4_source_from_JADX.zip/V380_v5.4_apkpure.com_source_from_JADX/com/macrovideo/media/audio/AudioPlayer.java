package com.macrovideo.media.audio;

import android.media.AudioTrack;
import android.os.Handler;

public class AudioPlayer implements IPlayComplete {
    public static final int STATE_MSG_ID = 16;
    private static final String TAG = "AudioPlayer";
    private static final int _STAT_PLAYING = 1;
    private static final int _STAT_PUASE = 3;
    private static final int _STAT_READY = 0;
    private static final int _STAT_STOP = 2;
    private AudioDataCache mAudioCache = new AudioDataCache();
    private AudioParam mAudioParam = new AudioParam();
    private AudioTrack mAudioTrack;
    private Handler mHandler;
    private PlayAudioThread mPlayAudioThread;
    private int nPlayStat = 0;
    int nPlayThreadID = 0;

    class PlayAudioThread extends Thread {
        int nThreadID = 0;

        public PlayAudioThread(int nThreadID) {
            this.nThreadID = nThreadID;
        }

        public void run() {
            AudioPlayer.this.mAudioTrack.play();
            while (AudioPlayer.this.nPlayThreadID == this.nThreadID) {
                if (AudioPlayer.this.nPlayStat != 1) {
                    if (AudioPlayer.this.nPlayStat == 3) {
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        return;
                    }
                } else if (AudioPlayer.this.mAudioCache == null || !AudioPlayer.this.mAudioCache.hasData()) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                } else {
                    AudioDataObject dataOject = AudioPlayer.this.mAudioCache.getData();
                    if (dataOject != null) {
                        byte[] data = dataOject.getM_Data();
                        if (data != null && data.length > 0) {
                            try {
                                System.out.println("mAudioTrack.write: " + data.length);
                                AudioPlayer.this.mAudioTrack.write(data, 0, data.length);
                            } catch (Exception e3) {
                                if (AudioPlayer.this.mAudioTrack.getState() != 3) {
                                    AudioPlayer.this.mAudioTrack.play();
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public AudioPlayer(Handler handler) {
        this.mHandler = handler;
    }

    public AudioPlayer(Handler handler, AudioParam audioParam) {
        this.mHandler = handler;
        setAudioParam(audioParam);
    }

    public void SetAudioData(byte[] data, int nStartIndex, int nEndIndex, int nType) {
        if (this.mAudioCache != null) {
            this.mAudioCache.PutData(data, nStartIndex, nEndIndex, nType);
        }
    }

    public AudioDataObject getAudioData() {
        if (this.mAudioCache == null || !this.mAudioCache.hasData()) {
            return null;
        }
        return this.mAudioCache.getData();
    }

    public void setAudioParam(AudioParam audioParam) {
        if (this.mAudioParam == null) {
            this.mAudioParam = audioParam;
            return;
        }
        this.mAudioParam.setmChannel(audioParam.getmChannel());
        this.mAudioParam.setmFrequency(audioParam.getmFrequency());
        this.mAudioParam.setmSampBit(audioParam.getmSampBit());
    }

    public boolean prepare() {
        try {
            createAudioTrack();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean release() {
        stop();
        releaseAudioTrack();
        return true;
    }

    public boolean play() {
        if (this.nPlayStat == 1) {
            return false;
        }
        if (this.nPlayStat == 3) {
            this.nPlayStat = 1;
            return true;
        }
        this.nPlayStat = 1;
        createAudioTrack();
        this.mAudioCache.clearCache();
        startThread();
        return true;
    }

    public boolean pause() {
        this.mAudioTrack.stop();
        this.mAudioTrack = null;
        this.nPlayStat = 3;
        return true;
    }

    public boolean stop() {
        stopThread();
        return true;
    }

    private void createAudioTrack() {
        if (this.mAudioTrack == null) {
            this.mAudioTrack = new AudioTrack(3, this.mAudioParam.getmFrequency(), this.mAudioParam.getmChannel(), this.mAudioParam.getmSampBit(), AudioTrack.getMinBufferSize(this.mAudioParam.getmFrequency(), this.mAudioParam.getmChannel(), this.mAudioParam.getmSampBit()), 1);
        }
    }

    private void releaseAudioTrack() {
        if (this.mAudioTrack != null) {
            this.mAudioTrack.stop();
            this.mAudioTrack.release();
            this.mAudioTrack = null;
        }
    }

    private void startThread() {
        if (this.mPlayAudioThread == null) {
            this.nPlayThreadID++;
            this.mPlayAudioThread = new PlayAudioThread(this.nPlayThreadID);
            this.mPlayAudioThread.start();
        }
    }

    private void stopThread() {
        if (this.mPlayAudioThread != null) {
            this.nPlayThreadID++;
            this.nPlayStat = 2;
            this.mPlayAudioThread = null;
        }
    }

    public void onPlayComplete() {
        this.mPlayAudioThread = null;
    }
}
