package com.qq.taf.jce;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public final class JceInputStream {
    private ByteBuffer bs;
    protected String sServerEncoding = "GBK";

    public static class HeadData {
        public int tag;
        public byte type;

        public void clear() {
            this.type = (byte) 0;
            this.tag = 0;
        }
    }

    public JceInputStream(ByteBuffer bs) {
        this.bs = bs;
    }

    public JceInputStream(byte[] bs) {
        this.bs = ByteBuffer.wrap(bs);
    }

    public JceInputStream(byte[] bs, int pos) {
        this.bs = ByteBuffer.wrap(bs);
        this.bs.position(pos);
    }

    public void warp(byte[] bs) {
        wrap(bs);
    }

    public void wrap(byte[] bs) {
        this.bs = ByteBuffer.wrap(bs);
    }

    public static int readHead(HeadData hd, ByteBuffer bb) {
        byte b = bb.get();
        hd.type = (byte) (b & 15);
        hd.tag = (b & 240) >> 4;
        if (hd.tag != 15) {
            return 1;
        }
        hd.tag = bb.get() & 255;
        return 2;
    }

    public void readHead(HeadData hd) {
        readHead(hd, this.bs);
    }

    private int peakHead(HeadData hd) {
        return readHead(hd, this.bs.duplicate());
    }

    private void skip(int len) {
        this.bs.position(this.bs.position() + len);
    }

    public boolean skipToTag(int tag) {
        try {
            HeadData hd = new HeadData();
            while (true) {
                int len = peakHead(hd);
                if (hd.type == (byte) 11) {
                    return false;
                }
                if (tag <= hd.tag) {
                    break;
                }
                skip(len);
                skipField(hd.type);
            }
            if (tag == hd.tag) {
                return true;
            }
            return false;
        } catch (JceDecodeException e) {
            return false;
        } catch (BufferUnderflowException e2) {
            return false;
        }
    }

    public void skipToStructEnd() {
        HeadData hd = new HeadData();
        do {
            readHead(hd);
            skipField(hd.type);
        } while (hd.type != (byte) 11);
    }

    private void skipField() {
        HeadData hd = new HeadData();
        readHead(hd);
        skipField(hd.type);
    }

    private void skipField(byte type) {
        int size;
        int i;
        switch (type) {
            case (byte) 0:
                skip(1);
                return;
            case (byte) 1:
                skip(2);
                return;
            case (byte) 2:
                skip(4);
                return;
            case (byte) 3:
                skip(8);
                return;
            case (byte) 4:
                skip(4);
                return;
            case (byte) 5:
                skip(8);
                return;
            case (byte) 6:
                int len = this.bs.get();
                if (len < 0) {
                    len += 256;
                }
                skip(len);
                return;
            case (byte) 7:
                skip(this.bs.getInt());
                return;
            case (byte) 8:
                size = read(0, 0, true);
                for (i = 0; i < size * 2; i++) {
                    skipField();
                }
                return;
            case (byte) 9:
                size = read(0, 0, true);
                for (i = 0; i < size; i++) {
                    skipField();
                }
                return;
            case (byte) 10:
                skipToStructEnd();
                return;
            case (byte) 11:
            case (byte) 12:
                return;
            case (byte) 13:
                HeadData hd = new HeadData();
                readHead(hd);
                if (hd.type != (byte) 0) {
                    throw new JceDecodeException("skipField with invalid type, type value: " + type + ", " + hd.type);
                }
                skip(read(0, 0, true));
                return;
            default:
                throw new JceDecodeException("invalid type.");
        }
    }

    public boolean read(boolean b, int tag, boolean isRequire) {
        if (read((byte) 0, tag, isRequire) != (byte) 0) {
            return true;
        }
        return false;
    }

    public byte read(byte c, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 0:
                    return this.bs.get();
                case (byte) 12:
                    return (byte) 0;
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return c;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public short read(short n, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 0:
                    return (short) this.bs.get();
                case (byte) 1:
                    return this.bs.getShort();
                case (byte) 12:
                    return (short) 0;
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return n;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public int read(int n, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 0:
                    return this.bs.get();
                case (byte) 1:
                    return this.bs.getShort();
                case (byte) 2:
                    return this.bs.getInt();
                case (byte) 12:
                    return 0;
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return n;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public long read(long n, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 0:
                    return (long) this.bs.get();
                case (byte) 1:
                    return (long) this.bs.getShort();
                case (byte) 2:
                    return (long) this.bs.getInt();
                case (byte) 3:
                    return this.bs.getLong();
                case (byte) 12:
                    return 0;
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return n;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public float read(float n, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 4:
                    return this.bs.getFloat();
                case (byte) 12:
                    return 0.0f;
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return n;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public double read(double n, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 4:
                    return (double) this.bs.getFloat();
                case (byte) 5:
                    return this.bs.getDouble();
                case (byte) 12:
                    return 0.0d;
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return n;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public String readByteString(String s, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            int len;
            byte[] ss;
            switch (hd.type) {
                case (byte) 6:
                    len = this.bs.get();
                    if (len < 0) {
                        len += 256;
                    }
                    ss = new byte[len];
                    this.bs.get(ss);
                    return HexUtil.bytes2HexStr(ss);
                case (byte) 7:
                    len = this.bs.getInt();
                    if (len > JceStruct.JCE_MAX_STRING_LENGTH || len < 0) {
                        throw new JceDecodeException("String too long: " + len);
                    }
                    ss = new byte[len];
                    this.bs.get(ss);
                    return HexUtil.bytes2HexStr(ss);
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return s;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public String read(String s, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            int len;
            byte[] ss;
            switch (hd.type) {
                case (byte) 6:
                    len = this.bs.get();
                    if (len < 0) {
                        len += 256;
                    }
                    ss = new byte[len];
                    this.bs.get(ss);
                    try {
                        return new String(ss, this.sServerEncoding);
                    } catch (UnsupportedEncodingException e) {
                        return new String(ss);
                    }
                case (byte) 7:
                    len = this.bs.getInt();
                    if (len > JceStruct.JCE_MAX_STRING_LENGTH || len < 0) {
                        throw new JceDecodeException("String too long: " + len);
                    }
                    ss = new byte[len];
                    this.bs.get(ss);
                    try {
                        return new String(ss, this.sServerEncoding);
                    } catch (UnsupportedEncodingException e2) {
                        return new String(ss);
                    }
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return s;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public String readString(int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            int len;
            byte[] ss;
            switch (hd.type) {
                case (byte) 6:
                    len = this.bs.get();
                    if (len < 0) {
                        len += 256;
                    }
                    ss = new byte[len];
                    this.bs.get(ss);
                    try {
                        return new String(ss, this.sServerEncoding);
                    } catch (UnsupportedEncodingException e) {
                        return new String(ss);
                    }
                case (byte) 7:
                    len = this.bs.getInt();
                    if (len > JceStruct.JCE_MAX_STRING_LENGTH || len < 0) {
                        throw new JceDecodeException("String too long: " + len);
                    }
                    ss = new byte[len];
                    this.bs.get(ss);
                    try {
                        return new String(ss, this.sServerEncoding);
                    } catch (UnsupportedEncodingException e2) {
                        return new String(ss);
                    }
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return null;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public String[] read(String[] s, int tag, boolean isRequire) {
        return (String[]) readArray((Object[]) s, tag, isRequire);
    }

    public Map<String, String> readStringMap(int tag, boolean isRequire) {
        HashMap<String, String> mr = new HashMap();
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 8:
                    int size = read(0, 0, true);
                    if (size >= 0) {
                        for (int i = 0; i < size; i++) {
                            mr.put(readString(0, true), readString(1, true));
                        }
                        break;
                    }
                    throw new JceDecodeException("size invalid: " + size);
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return mr;
    }

    public <K, V> HashMap<K, V> readMap(Map<K, V> m, int tag, boolean isRequire) {
        return (HashMap) readMap(new HashMap(), m, tag, isRequire);
    }

    private <K, V> Map<K, V> readMap(Map<K, V> mr, Map<K, V> m, int tag, boolean isRequire) {
        if (m == null || m.isEmpty()) {
            return new HashMap();
        }
        Entry<K, V> en = (Entry) m.entrySet().iterator().next();
        Object mk = en.getKey();
        Object mv = en.getValue();
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 8:
                    int size = read(0, 0, true);
                    if (size < 0) {
                        throw new JceDecodeException("size invalid: " + size);
                    }
                    for (int i = 0; i < size; i++) {
                        mr.put(read(mk, 0, true), read(mv, 1, true));
                    }
                    return mr;
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return mr;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public List readList(int tag, boolean isRequire) {
        List lr = new ArrayList();
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 9:
                    int size = read(0, 0, true);
                    if (size >= 0) {
                        for (int i = 0; i < size; i++) {
                            HeadData subH = new HeadData();
                            readHead(subH);
                            switch (subH.type) {
                                case (byte) 0:
                                    skip(1);
                                    break;
                                case (byte) 1:
                                    skip(2);
                                    break;
                                case (byte) 2:
                                    skip(4);
                                    break;
                                case (byte) 3:
                                    skip(8);
                                    break;
                                case (byte) 4:
                                    skip(4);
                                    break;
                                case (byte) 5:
                                    skip(8);
                                    break;
                                case (byte) 6:
                                    int len = this.bs.get();
                                    if (len < 0) {
                                        len += 256;
                                    }
                                    skip(len);
                                    break;
                                case (byte) 7:
                                    skip(this.bs.getInt());
                                    break;
                                case (byte) 8:
                                case (byte) 9:
                                    break;
                                case (byte) 10:
                                    try {
                                        JceStruct struct = (JceStruct) Class.forName(JceStruct.class.getName()).getConstructor(new Class[0]).newInstance(new Object[0]);
                                        struct.readFrom(this);
                                        skipToStructEnd();
                                        lr.add(struct);
                                        break;
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        throw new JceDecodeException("type mismatch." + e);
                                    }
                                case (byte) 12:
                                    lr.add(new Integer(0));
                                    break;
                                default:
                                    throw new JceDecodeException("type mismatch.");
                            }
                        }
                        break;
                    }
                    throw new JceDecodeException("size invalid: " + size);
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return lr;
    }

    public boolean[] read(boolean[] l, int tag, boolean isRequire) {
        boolean[] lr = null;
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 9:
                    int size = read(0, 0, true);
                    if (size >= 0) {
                        lr = new boolean[size];
                        for (int i = 0; i < size; i++) {
                            lr[i] = read(lr[0], 0, true);
                        }
                        break;
                    }
                    throw new JceDecodeException("size invalid: " + size);
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return lr;
    }

    public byte[] read(byte[] l, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            int size;
            byte[] lr;
            switch (hd.type) {
                case (byte) 9:
                    size = read(0, 0, true);
                    if (size < 0) {
                        throw new JceDecodeException("size invalid: " + size);
                    }
                    lr = new byte[size];
                    for (int i = 0; i < size; i++) {
                        lr[i] = read(lr[0], 0, true);
                    }
                    return lr;
                case (byte) 13:
                    HeadData hh = new HeadData();
                    readHead(hh);
                    if (hh.type != (byte) 0) {
                        throw new JceDecodeException("type mismatch, tag: " + tag + ", type: " + hd.type + ", " + hh.type);
                    }
                    size = read(0, 0, true);
                    if (size < 0) {
                        throw new JceDecodeException("invalid size, tag: " + tag + ", type: " + hd.type + ", " + hh.type + ", size: " + size);
                    }
                    lr = new byte[size];
                    this.bs.get(lr);
                    return lr;
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return null;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public short[] read(short[] l, int tag, boolean isRequire) {
        short[] lr = null;
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 9:
                    int size = read(0, 0, true);
                    if (size >= 0) {
                        lr = new short[size];
                        for (int i = 0; i < size; i++) {
                            lr[i] = read(lr[0], 0, true);
                        }
                        break;
                    }
                    throw new JceDecodeException("size invalid: " + size);
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return lr;
    }

    public int[] read(int[] l, int tag, boolean isRequire) {
        int[] lr = null;
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 9:
                    int size = read(0, 0, true);
                    if (size >= 0) {
                        lr = new int[size];
                        for (int i = 0; i < size; i++) {
                            lr[i] = read(lr[0], 0, true);
                        }
                        break;
                    }
                    throw new JceDecodeException("size invalid: " + size);
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return lr;
    }

    public long[] read(long[] l, int tag, boolean isRequire) {
        long[] lr = null;
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 9:
                    int size = read(0, 0, true);
                    if (size >= 0) {
                        lr = new long[size];
                        for (int i = 0; i < size; i++) {
                            lr[i] = read(lr[0], 0, true);
                        }
                        break;
                    }
                    throw new JceDecodeException("size invalid: " + size);
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return lr;
    }

    public float[] read(float[] l, int tag, boolean isRequire) {
        float[] lr = null;
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 9:
                    int size = read(0, 0, true);
                    if (size >= 0) {
                        lr = new float[size];
                        for (int i = 0; i < size; i++) {
                            lr[i] = read(lr[0], 0, true);
                        }
                        break;
                    }
                    throw new JceDecodeException("size invalid: " + size);
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return lr;
    }

    public double[] read(double[] l, int tag, boolean isRequire) {
        double[] lr = null;
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 9:
                    int size = read(0, 0, true);
                    if (size >= 0) {
                        lr = new double[size];
                        for (int i = 0; i < size; i++) {
                            lr[i] = read(lr[0], 0, true);
                        }
                        break;
                    }
                    throw new JceDecodeException("size invalid: " + size);
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return lr;
    }

    public <T> T[] readArray(T[] l, int tag, boolean isRequire) {
        if (l != null && l.length != 0) {
            return readArrayImpl(l[0], tag, isRequire);
        }
        throw new JceDecodeException("unable to get type of key and value.");
    }

    public <T> List<T> readArray(List<T> l, int tag, boolean isRequire) {
        if (l == null || l.isEmpty()) {
            return new ArrayList();
        }
        T[] tt = readArrayImpl(l.get(0), tag, isRequire);
        if (tt == null) {
            return null;
        }
        List<T> ll = new ArrayList();
        for (Object add : tt) {
            ll.add(add);
        }
        return ll;
    }

    private <T> T[] readArrayImpl(T mt, int tag, boolean isRequire) {
        if (skipToTag(tag)) {
            HeadData hd = new HeadData();
            readHead(hd);
            switch (hd.type) {
                case (byte) 9:
                    int size = read(0, 0, true);
                    if (size < 0) {
                        throw new JceDecodeException("size invalid: " + size);
                    }
                    Object[] objArr = (Object[]) ((Object[]) Array.newInstance(mt.getClass(), size));
                    for (int i = 0; i < size; i++) {
                        objArr[i] = read((Object) mt, 0, true);
                    }
                    return objArr;
                default:
                    throw new JceDecodeException("type mismatch.");
            }
        } else if (!isRequire) {
            return null;
        } else {
            throw new JceDecodeException("require field not exist.");
        }
    }

    public JceStruct directRead(JceStruct o, int tag, boolean isRequire) {
        JceStruct ref = null;
        if (skipToTag(tag)) {
            try {
                ref = o.newInit();
                HeadData hd = new HeadData();
                readHead(hd);
                if (hd.type != (byte) 10) {
                    throw new JceDecodeException("type mismatch.");
                }
                ref.readFrom(this);
                skipToStructEnd();
            } catch (Exception e) {
                throw new JceDecodeException(e.getMessage());
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return ref;
    }

    public JceStruct read(JceStruct o, int tag, boolean isRequire) {
        JceStruct ref = null;
        if (skipToTag(tag)) {
            try {
                ref = (JceStruct) o.getClass().newInstance();
                HeadData hd = new HeadData();
                readHead(hd);
                if (hd.type != (byte) 10) {
                    throw new JceDecodeException("type mismatch.");
                }
                ref.readFrom(this);
                skipToStructEnd();
            } catch (Exception e) {
                throw new JceDecodeException(e.getMessage());
            }
        } else if (isRequire) {
            throw new JceDecodeException("require field not exist.");
        }
        return ref;
    }

    public JceStruct[] read(JceStruct[] o, int tag, boolean isRequire) {
        return (JceStruct[]) readArray((Object[]) o, tag, isRequire);
    }

    public <T> Object read(T o, int tag, boolean isRequire) {
        if (o instanceof Byte) {
            return Byte.valueOf(read((byte) 0, tag, isRequire));
        }
        if (o instanceof Boolean) {
            return Boolean.valueOf(read(false, tag, isRequire));
        }
        if (o instanceof Short) {
            return Short.valueOf(read((short) 0, tag, isRequire));
        }
        if (o instanceof Integer) {
            return Integer.valueOf(read(0, tag, isRequire));
        }
        if (o instanceof Long) {
            return Long.valueOf(read(0, tag, isRequire));
        }
        if (o instanceof Float) {
            return Float.valueOf(read(0.0f, tag, isRequire));
        }
        if (o instanceof Double) {
            return Double.valueOf(read(0.0d, tag, isRequire));
        }
        if (o instanceof String) {
            return readString(tag, isRequire);
        }
        if (o instanceof Map) {
            return readMap((Map) o, tag, isRequire);
        }
        if (o instanceof List) {
            return readArray((List) o, tag, isRequire);
        }
        if (o instanceof JceStruct) {
            return read((JceStruct) o, tag, isRequire);
        }
        if (!o.getClass().isArray()) {
            throw new JceDecodeException("read object error: unsupport type.");
        } else if ((o instanceof byte[]) || (o instanceof Byte[])) {
            return read((byte[]) null, tag, isRequire);
        } else {
            if (o instanceof boolean[]) {
                return read((boolean[]) null, tag, isRequire);
            }
            if (o instanceof short[]) {
                return read((short[]) null, tag, isRequire);
            }
            if (o instanceof int[]) {
                return read((int[]) null, tag, isRequire);
            }
            if (o instanceof long[]) {
                return read((long[]) null, tag, isRequire);
            }
            if (o instanceof float[]) {
                return read((float[]) null, tag, isRequire);
            }
            if (o instanceof double[]) {
                return read((double[]) null, tag, isRequire);
            }
            return readArray((Object[]) o, tag, isRequire);
        }
    }

    public int setServerEncoding(String se) {
        this.sServerEncoding = se;
        return 0;
    }

    public static void main(String[] args) {
    }

    public ByteBuffer getBs() {
        return this.bs;
    }
}
