package com.qq.taf.jce;

public class JceEncodeException extends RuntimeException {
    public JceEncodeException(String string) {
        super(string);
    }
}
