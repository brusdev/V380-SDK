package com.qq.taf.jce;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class JceOutputStream {
    private ByteBuffer bs;
    protected String sServerEncoding;

    public JceOutputStream(ByteBuffer bs) {
        this.sServerEncoding = "GBK";
        this.bs = bs;
    }

    public JceOutputStream(int capacity) {
        this.sServerEncoding = "GBK";
        this.bs = ByteBuffer.allocate(capacity);
    }

    public JceOutputStream() {
        this(128);
    }

    public ByteBuffer getByteBuffer() {
        return this.bs;
    }

    public byte[] toByteArray() {
        byte[] newBytes = new byte[this.bs.position()];
        System.arraycopy(this.bs.array(), 0, newBytes, 0, this.bs.position());
        return newBytes;
    }

    public void reserve(int len) {
        if (this.bs.remaining() < len) {
            ByteBuffer bs2 = ByteBuffer.allocate((this.bs.capacity() + len) * 2);
            bs2.put(this.bs.array(), 0, this.bs.position());
            this.bs = bs2;
        }
    }

    public void writeHead(byte type, int tag) {
        if (tag < 15) {
            this.bs.put((byte) ((tag << 4) | type));
        } else if (tag < 256) {
            this.bs.put((byte) (type | 240));
            this.bs.put((byte) tag);
        } else {
            throw new JceEncodeException("tag is too large: " + tag);
        }
    }

    public void write(boolean b, int tag) {
        write((byte) (b ? 1 : 0), tag);
    }

    public void write(byte b, int tag) {
        reserve(3);
        if (b == (byte) 0) {
            writeHead((byte) 12, tag);
            return;
        }
        writeHead((byte) 0, tag);
        this.bs.put(b);
    }

    public void write(short n, int tag) {
        reserve(4);
        if (n < (short) -128 || n > (short) 127) {
            writeHead((byte) 1, tag);
            this.bs.putShort(n);
            return;
        }
        write((byte) n, tag);
    }

    public void write(int n, int tag) {
        reserve(6);
        if (n < -32768 || n > 32767) {
            writeHead((byte) 2, tag);
            this.bs.putInt(n);
            return;
        }
        write((short) n, tag);
    }

    public void write(long n, int tag) {
        reserve(10);
        if (n < -2147483648L || n > 2147483647L) {
            writeHead((byte) 3, tag);
            this.bs.putLong(n);
            return;
        }
        write((int) n, tag);
    }

    public void write(float n, int tag) {
        reserve(6);
        writeHead((byte) 4, tag);
        this.bs.putFloat(n);
    }

    public void write(double n, int tag) {
        reserve(10);
        writeHead((byte) 5, tag);
        this.bs.putDouble(n);
    }

    public void writeStringByte(String s, int tag) {
        byte[] by = HexUtil.hexStr2Bytes(s);
        reserve(by.length + 10);
        if (by.length > 255) {
            writeHead((byte) 7, tag);
            this.bs.putInt(by.length);
            this.bs.put(by);
            return;
        }
        writeHead((byte) 6, tag);
        this.bs.put((byte) by.length);
        this.bs.put(by);
    }

    public void writeByteString(String s, int tag) {
        reserve(s.length() + 10);
        byte[] by = HexUtil.hexStr2Bytes(s);
        if (by.length > 255) {
            writeHead((byte) 7, tag);
            this.bs.putInt(by.length);
            this.bs.put(by);
            return;
        }
        writeHead((byte) 6, tag);
        this.bs.put((byte) by.length);
        this.bs.put(by);
    }

    public void write(String s, int tag) {
        byte[] by;
        try {
            by = s.getBytes(this.sServerEncoding);
        } catch (UnsupportedEncodingException e) {
            by = s.getBytes();
        }
        reserve(by.length + 10);
        if (by.length > 255) {
            writeHead((byte) 7, tag);
            this.bs.putInt(by.length);
            this.bs.put(by);
            return;
        }
        writeHead((byte) 6, tag);
        this.bs.put((byte) by.length);
        this.bs.put(by);
    }

    public <K, V> void write(Map<K, V> m, int tag) {
        reserve(8);
        writeHead((byte) 8, tag);
        write(m == null ? 0 : m.size(), 0);
        if (m != null) {
            for (Entry<K, V> en : m.entrySet()) {
                write(en.getKey(), 0);
                write(en.getValue(), 1);
            }
        }
    }

    public void write(boolean[] l, int tag) {
        reserve(8);
        writeHead((byte) 9, tag);
        write(l.length, 0);
        for (boolean e : l) {
            write(e, 0);
        }
    }

    public void write(byte[] l, int tag) {
        reserve(l.length + 8);
        writeHead((byte) 13, tag);
        writeHead((byte) 0, 0);
        write(l.length, 0);
        this.bs.put(l);
    }

    public void write(short[] l, int tag) {
        reserve(8);
        writeHead((byte) 9, tag);
        write(l.length, 0);
        for (short e : l) {
            write(e, 0);
        }
    }

    public void write(int[] l, int tag) {
        reserve(8);
        writeHead((byte) 9, tag);
        write(l.length, 0);
        for (int e : l) {
            write(e, 0);
        }
    }

    public void write(long[] l, int tag) {
        reserve(8);
        writeHead((byte) 9, tag);
        write(l.length, 0);
        for (long e : l) {
            write(e, 0);
        }
    }

    public void write(float[] l, int tag) {
        reserve(8);
        writeHead((byte) 9, tag);
        write(l.length, 0);
        for (float e : l) {
            write(e, 0);
        }
    }

    public void write(double[] l, int tag) {
        reserve(8);
        writeHead((byte) 9, tag);
        write(l.length, 0);
        for (double e : l) {
            write(e, 0);
        }
    }

    public <T> void write(T[] l, int tag) {
        writeArray(l, tag);
    }

    private void writeArray(Object[] l, int tag) {
        reserve(8);
        writeHead((byte) 9, tag);
        write(l.length, 0);
        for (Object e : l) {
            write(e, 0);
        }
    }

    public <T> void write(Collection<T> l, int tag) {
        reserve(8);
        writeHead((byte) 9, tag);
        write(l == null ? 0 : l.size(), 0);
        if (l != null) {
            for (T e : l) {
                write((Object) e, 0);
            }
        }
    }

    public void write(JceStruct o, int tag) {
        reserve(2);
        writeHead((byte) 10, tag);
        o.writeTo(this);
        reserve(2);
        writeHead((byte) 11, 0);
    }

    public void write(Byte o, int tag) {
        write(o.byteValue(), tag);
    }

    public void write(Boolean o, int tag) {
        write(o.booleanValue(), tag);
    }

    public void write(Short o, int tag) {
        write(o.shortValue(), tag);
    }

    public void write(Integer o, int tag) {
        write(o.intValue(), tag);
    }

    public void write(Long o, int tag) {
        write(o.longValue(), tag);
    }

    public void write(Float o, int tag) {
        write(o.floatValue(), tag);
    }

    public void write(Double o, int tag) {
        write(o.doubleValue(), tag);
    }

    public void write(Object o, int tag) {
        if (o instanceof Byte) {
            write(((Byte) o).byteValue(), tag);
        } else if (o instanceof Boolean) {
            write(((Boolean) o).booleanValue(), tag);
        } else if (o instanceof Short) {
            write(((Short) o).shortValue(), tag);
        } else if (o instanceof Integer) {
            write(((Integer) o).intValue(), tag);
        } else if (o instanceof Long) {
            write(((Long) o).longValue(), tag);
        } else if (o instanceof Float) {
            write(((Float) o).floatValue(), tag);
        } else if (o instanceof Double) {
            write(((Double) o).doubleValue(), tag);
        } else if (o instanceof String) {
            write((String) o, tag);
        } else if (o instanceof Map) {
            write((Map) o, tag);
        } else if (o instanceof List) {
            write((List) o, tag);
        } else if (o instanceof JceStruct) {
            write((JceStruct) o, tag);
        } else if (o instanceof byte[]) {
            write((byte[]) o, tag);
        } else if (o instanceof boolean[]) {
            write((boolean[]) o, tag);
        } else if (o instanceof short[]) {
            write((short[]) o, tag);
        } else if (o instanceof int[]) {
            write((int[]) o, tag);
        } else if (o instanceof long[]) {
            write((long[]) o, tag);
        } else if (o instanceof float[]) {
            write((float[]) o, tag);
        } else if (o instanceof double[]) {
            write((double[]) o, tag);
        } else if (o.getClass().isArray()) {
            writeArray((Object[]) o, tag);
        } else if (o instanceof Collection) {
            write((Collection) o, tag);
        } else {
            throw new JceEncodeException("write object error: unsupport type. " + o.getClass());
        }
    }

    public int setServerEncoding(String se) {
        this.sServerEncoding = se;
        return 0;
    }

    public static void main(String[] args) {
        JceOutputStream os = new JceOutputStream();
        os.write(1311768467283714885L, 0);
        System.out.println(HexUtil.bytes2HexStr(os.getByteBuffer().array()));
        System.out.println(Arrays.toString(os.toByteArray()));
    }
}
