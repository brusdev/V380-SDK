package com.example.hyfisheyepano;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.EGLConfigChooser;
import android.opengl.GLSurfaceView.EGLContextFactory;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.OnScaleGestureListener;
import android.view.View;
import android.view.View.OnTouchListener;
import com.macrovideo.photo.PhotoViewAttacher;
import com.macrovideo.sdk.defines.Defines;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.opengles.GL10;

public class GLFisheyeView extends GLSurfaceView implements OnTouchListener, SensorEventListener {
    private static final boolean DEBUG = false;
    private static String TAG = "GL2JNIView";
    private static final int TASK_ADD_IMAGE = 1;
    private static final int TASK_ADD_YUV = 11;
    private static final int TASK_INERTIA_MOVE_VIEW = 2;
    protected static boolean bNewData = false;
    protected static float thrsSpeedX = 2.0f;
    protected float MOVE_LEARN_RATE;
    protected int TIMER_INTERVAL;
    protected volatile boolean bJniImagePassing;
    protected boolean bScale;
    private float fMoveDistX;
    private float fMoveDistY;
    protected float fSpeedX;
    protected float fSpeedX0;
    protected float fSpeedY;
    protected float fSpeedY0;
    protected int height;
    private int imode;
    private long lPrevClickTime;
    private long lScaleTime;
    protected Sensor mAccelerometer;
    public int[] mBuffer;
    public byte[] mByteBuff;
    private GestureDetector mGestureDetector;
    Handler mHandler;
    private float mPrevX;
    private float mPrevY;
    private ScaleGestureDetector mScaleGestureDetector;
    Handler mTimerHandler;
    Runnable mTimerRunable;
    private int nClick;
    protected SensorManager sm;
    protected int width;

    class C02011 extends Handler {
        C02011() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    GLFisheyeView.this.bJniImagePassing = false;
                    break;
                case 11:
                    GL2JNILIb.setYUV(GLFisheyeView.this.mByteBuff, GLFisheyeView.this.width, GLFisheyeView.this.height);
                    GLFisheyeView.this.bJniImagePassing = false;
                    break;
            }
            super.handleMessage(msg);
        }
    }

    class C02022 implements Runnable {
        C02022() {
        }

        public void run() {
            try {
                GLFisheyeView gLFisheyeView;
                GLFisheyeView.this.mTimerHandler.postDelayed(this, (long) GLFisheyeView.this.TIMER_INTERVAL);
                if (Math.abs(GLFisheyeView.this.fSpeedX) > GLFisheyeView.thrsSpeedX) {
                    gLFisheyeView = GLFisheyeView.this;
                    gLFisheyeView.fSpeedX *= PhotoViewAttacher.DEFAULT_MIN_SCALE - GLFisheyeView.this.MOVE_LEARN_RATE;
                }
                gLFisheyeView = GLFisheyeView.this;
                gLFisheyeView.fSpeedY *= PhotoViewAttacher.DEFAULT_MIN_SCALE - GLFisheyeView.this.MOVE_LEARN_RATE;
                if (Math.abs(GLFisheyeView.this.fSpeedX) > 0.05f || Math.abs(GLFisheyeView.this.fSpeedY) > 0.05f) {
                    Message msg = GLFisheyeView.this.mHandler.obtainMessage(2);
                    msg.obj = "Inertia Move View";
                    GLFisheyeView.this.mHandler.sendMessage(msg);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static class ConfigChooser implements EGLConfigChooser {
        private static int EGL_OPENGL_ES2_BIT = 4;
        private static int[] s_configAttribs2 = new int[]{12324, 4, 12323, 4, 12322, 4, 12352, EGL_OPENGL_ES2_BIT, 12344};
        protected int mAlphaSize;
        protected int mBlueSize;
        protected int mDepthSize;
        protected int mGreenSize;
        protected int mRedSize;
        protected int mStencilSize;
        private int[] mValue = new int[1];

        public ConfigChooser(int r, int g, int b, int a, int depth, int stencil) {
            this.mRedSize = r;
            this.mGreenSize = g;
            this.mBlueSize = b;
            this.mAlphaSize = a;
            this.mDepthSize = depth;
            this.mStencilSize = stencil;
        }

        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
            int[] num_config = new int[1];
            egl.eglChooseConfig(display, s_configAttribs2, null, 0, num_config);
            int numConfigs = num_config[0];
            if (numConfigs <= 0) {
                throw new IllegalArgumentException("No configs match configSpec");
            }
            EGLConfig[] configs = new EGLConfig[numConfigs];
            egl.eglChooseConfig(display, s_configAttribs2, configs, numConfigs, num_config);
            return chooseConfig(egl, display, configs);
        }

        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
            for (EGLConfig config : configs) {
                int d = findConfigAttrib(egl, display, config, 12325, 0);
                int s = findConfigAttrib(egl, display, config, 12326, 0);
                if (d >= this.mDepthSize && s >= this.mStencilSize) {
                    int r = findConfigAttrib(egl, display, config, 12324, 0);
                    int g = findConfigAttrib(egl, display, config, 12323, 0);
                    int b = findConfigAttrib(egl, display, config, 12322, 0);
                    int a = findConfigAttrib(egl, display, config, 12321, 0);
                    if (r == this.mRedSize && g == this.mGreenSize && b == this.mBlueSize && a == this.mAlphaSize) {
                        return config;
                    }
                }
            }
            return null;
        }

        private int findConfigAttrib(EGL10 egl, EGLDisplay display, EGLConfig config, int attribute, int defaultValue) {
            if (egl.eglGetConfigAttrib(display, config, attribute, this.mValue)) {
                return this.mValue[0];
            }
            return defaultValue;
        }

        private void printConfigs(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
            Log.w(GLFisheyeView.TAG, String.format("%d configurations", new Object[]{Integer.valueOf(configs.length)}));
            for (EGLConfig printConfig : configs) {
                Log.w(GLFisheyeView.TAG, String.format("Configuration %d:\n", new Object[]{Integer.valueOf(i)}));
                printConfig(egl, display, printConfig);
            }
        }

        private void printConfig(EGL10 egl, EGLDisplay display, EGLConfig config) {
            int[] attributes = new int[]{12320, 12321, 12322, 12323, 12324, 12325, 12326, 12327, 12328, 12329, 12330, 12331, 12332, 12333, 12334, 12335, 12336, 12337, 12338, 12339, 12340, 12343, 12342, 12341, 12345, 12346, 12347, 12348, 12349, 12350, 12351, 12352, 12354};
            String[] names = new String[]{"EGL_BUFFER_SIZE", "EGL_ALPHA_SIZE", "EGL_BLUE_SIZE", "EGL_GREEN_SIZE", "EGL_RED_SIZE", "EGL_DEPTH_SIZE", "EGL_STENCIL_SIZE", "EGL_CONFIG_CAVEAT", "EGL_CONFIG_ID", "EGL_LEVEL", "EGL_MAX_PBUFFER_HEIGHT", "EGL_MAX_PBUFFER_PIXELS", "EGL_MAX_PBUFFER_WIDTH", "EGL_NATIVE_RENDERABLE", "EGL_NATIVE_VISUAL_ID", "EGL_NATIVE_VISUAL_TYPE", "EGL_PRESERVED_RESOURCES", "EGL_SAMPLES", "EGL_SAMPLE_BUFFERS", "EGL_SURFACE_TYPE", "EGL_TRANSPARENT_TYPE", "EGL_TRANSPARENT_RED_VALUE", "EGL_TRANSPARENT_GREEN_VALUE", "EGL_TRANSPARENT_BLUE_VALUE", "EGL_BIND_TO_TEXTURE_RGB", "EGL_BIND_TO_TEXTURE_RGBA", "EGL_MIN_SWAP_INTERVAL", "EGL_MAX_SWAP_INTERVAL", "EGL_LUMINANCE_SIZE", "EGL_ALPHA_MASK_SIZE", "EGL_COLOR_BUFFER_TYPE", "EGL_RENDERABLE_TYPE", "EGL_CONFORMANT"};
            int[] value = new int[1];
            for (int i = 0; i < attributes.length; i++) {
                int attribute = attributes[i];
                String name = names[i];
                if (egl.eglGetConfigAttrib(display, config, attribute, value)) {
                    Log.w(GLFisheyeView.TAG, String.format("  %s: %d\n", new Object[]{name, Integer.valueOf(value[0])}));
                } else {
                    do {
                    } while (egl.eglGetError() != Defines.PARAM_NONE);
                }
            }
        }
    }

    private static class ContextFactory implements EGLContextFactory {
        private static int EGL_CONTEXT_CLIENT_VERSION = 12440;

        private ContextFactory() {
        }

        public EGLContext createContext(EGL10 egl, EGLDisplay display, EGLConfig eglConfig) {
            Log.w(GLFisheyeView.TAG, "creating OpenGL ES 2.0 context");
            GLFisheyeView.checkEglError("Before eglCreateContext", egl);
            EGLContext context = egl.eglCreateContext(display, eglConfig, EGL10.EGL_NO_CONTEXT, new int[]{EGL_CONTEXT_CLIENT_VERSION, 2, 12344});
            GLFisheyeView.checkEglError("After eglCreateContext", egl);
            return context;
        }

        public void destroyContext(EGL10 egl, EGLDisplay display, EGLContext context) {
            egl.eglDestroyContext(display, context);
        }
    }

    class GestureListener extends SimpleOnGestureListener {
        GestureListener() {
        }

        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            if (System.currentTimeMillis() - GLFisheyeView.this.lScaleTime > 500) {
                GLFisheyeView.this.bScale = false;
            }
            if (!GLFisheyeView.this.bScale) {
                GL2JNILIb.moveView(e2.getX(), e2.getY());
            }
            return true;
        }

        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            GL2JNILIb.flipView(velocityX, velocityY);
            return true;
        }

        public boolean onDown(MotionEvent e) {
            return false;
        }
    }

    private static class Renderer implements android.opengl.GLSurfaceView.Renderer {
        private Renderer() {
        }

        public void onDrawFrame(GL10 gl) {
            if (GLFisheyeView.bNewData) {
                GL2JNILIb.render();
            }
        }

        public void onSurfaceChanged(GL10 gl, int width, int height) {
            GL2JNILIb.setViewSize(width, height);
        }

        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GL2JNILIb.create();
        }

        protected void finalize() throws Throwable {
            super.finalize();
            Log.i("view", " Render finalize");
        }
    }

    public class ScaleGestureListener implements OnScaleGestureListener {
        public boolean onScale(ScaleGestureDetector detector) {
            float scale = PhotoViewAttacher.DEFAULT_MIN_SCALE - detector.getScaleFactor();
            if (scale != 0.0f) {
                GL2JNILIb.zoomView(scale);
            }
            GLFisheyeView.this.lScaleTime = System.currentTimeMillis();
            GLFisheyeView.this.bScale = true;
            return false;
        }

        public boolean onScaleBegin(ScaleGestureDetector detector) {
            return true;
        }

        public void onScaleEnd(ScaleGestureDetector detector) {
        }
    }

    public GLFisheyeView(Context context) {
        super(context);
        this.width = 0;
        this.height = 0;
        this.mPrevX = 0.0f;
        this.mPrevY = 0.0f;
        this.imode = 0;
        this.mBuffer = null;
        this.mByteBuff = new byte[3133440];
        this.mScaleGestureDetector = null;
        this.mGestureDetector = null;
        this.bJniImagePassing = false;
        this.TIMER_INTERVAL = 30;
        this.MOVE_LEARN_RATE = 0.05f;
        this.fSpeedX = 0.0f;
        this.fSpeedY = 0.0f;
        this.fSpeedX0 = 0.0f;
        this.fSpeedY0 = 0.0f;
        this.bScale = false;
        this.sm = null;
        this.mAccelerometer = null;
        this.lPrevClickTime = 0;
        this.nClick = 0;
        this.fMoveDistX = 0.0f;
        this.fMoveDistY = 0.0f;
        this.mHandler = new C02011();
        this.lScaleTime = 0;
        this.mTimerHandler = new Handler();
        this.mTimerRunable = new C02022();
        init(false, 0, 0);
        GL2JNILIb.init();
        this.mScaleGestureDetector = new ScaleGestureDetector(context, new ScaleGestureListener());
        this.mGestureDetector = new GestureDetector(context, new GestureListener());
        this.sm = (SensorManager) context.getSystemService("sensor");
        this.mAccelerometer = this.sm.getDefaultSensor(1);
        this.sm.registerListener(this, this.mAccelerometer, 3);
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    public void onPause() {
        super.onPause();
        this.sm.unregisterListener(this);
        bNewData = false;
    }

    public void onResume() {
        super.onResume();
        this.sm.registerListener(this, this.mAccelerometer, 3);
    }

    public GLFisheyeView(Context context, boolean translucent, int depth, int stencil) {
        super(context);
        this.width = 0;
        this.height = 0;
        this.mPrevX = 0.0f;
        this.mPrevY = 0.0f;
        this.imode = 0;
        this.mBuffer = null;
        this.mByteBuff = new byte[3133440];
        this.mScaleGestureDetector = null;
        this.mGestureDetector = null;
        this.bJniImagePassing = false;
        this.TIMER_INTERVAL = 30;
        this.MOVE_LEARN_RATE = 0.05f;
        this.fSpeedX = 0.0f;
        this.fSpeedY = 0.0f;
        this.fSpeedX0 = 0.0f;
        this.fSpeedY0 = 0.0f;
        this.bScale = false;
        this.sm = null;
        this.mAccelerometer = null;
        this.lPrevClickTime = 0;
        this.nClick = 0;
        this.fMoveDistX = 0.0f;
        this.fMoveDistY = 0.0f;
        this.mHandler = new C02011();
        this.lScaleTime = 0;
        this.mTimerHandler = new Handler();
        this.mTimerRunable = new C02022();
        init(translucent, depth, stencil);
        GL2JNILIb.init();
    }

    private void init(boolean translucent, int depth, int stencil) {
        EGLConfigChooser configChooser;
        if (translucent) {
            getHolder().setFormat(-3);
        }
        setEGLContextFactory(new ContextFactory());
        if (translucent) {
            configChooser = new ConfigChooser(8, 8, 8, 8, depth, stencil);
        } else {
            configChooser = new ConfigChooser(5, 6, 5, 0, depth, stencil);
        }
        setEGLConfigChooser(configChooser);
        setRenderer(new Renderer());
    }

    private static void checkEglError(String prompt, EGL10 egl) {
        while (egl.eglGetError() != Defines.PARAM_NONE) {
            Log.e(TAG, String.format("%s: EGL error: 0x%x", new Object[]{prompt, Integer.valueOf(error)}));
        }
    }

    public void setImageParam(int fixtype, int img_cx, int img_cy, int img_rad) {
        GL2JNILIb.setImageParam(fixtype, (float) img_cx, (float) img_cy, (float) img_rad);
    }

    public void setImage(Bitmap bmp) {
        if (!this.bJniImagePassing) {
            synchronized (this) {
                this.bJniImagePassing = true;
                if (this.mBuffer == null) {
                    this.mBuffer = new int[2088960];
                }
                this.width = bmp.getWidth();
                this.height = bmp.getHeight();
                bmp.getPixels(this.mBuffer, 0, this.width, 0, 0, this.width, this.height);
                Message msg = this.mHandler.obtainMessage(1);
                msg.obj = "Add image task";
                this.mHandler.sendMessage(msg);
            }
        }
    }

    public void setYUVImage(byte[] yuvdata, int _width, int _height) {
        if (_width > 0 && _height > 0 && !this.bJniImagePassing) {
            synchronized (this) {
                bNewData = true;
                this.bJniImagePassing = true;
                this.width = _width;
                this.height = _height;
                System.arraycopy(yuvdata, 0, this.mByteBuff, 0, ((this.width * this.height) * 3) / 2);
                Message msg = this.mHandler.obtainMessage(11);
                msg.obj = "Add image task";
                this.mHandler.sendMessage(msg);
            }
        }
    }

    public void setMode(int iMode) {
        GL2JNILIb.setExpandMode(iMode);
        this.nClick = 0;
    }

    public static float pointDistance(float x0, float y0, float x1, float y1) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        return (float) Math.sqrt((double) ((dx * dx) + (dy * dy)));
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent e) {
        long timecur = System.currentTimeMillis();
        float curX;
        float curY;
        switch (e.getAction()) {
            case 0:
                this.fSpeedX = 0.0f;
                this.fSpeedY = 0.0f;
                this.mPrevX = e.getX();
                this.mPrevY = e.getY();
                GL2JNILIb.setTouch(true, this.mPrevX, this.mPrevY);
                break;
            case 1:
                GL2JNILIb.setTouch(false, 0.0f, 0.0f);
                if (timecur - this.lPrevClickTime > 200) {
                    this.nClick = 0;
                }
                if (this.nClick == 0) {
                    this.lPrevClickTime = timecur;
                    this.fMoveDistX = 0.0f;
                    this.fMoveDistY = 0.0f;
                }
                this.nClick++;
                if (this.nClick != 1) {
                    if (this.nClick >= 2) {
                        curX = e.getX();
                        curY = e.getY();
                        if (Math.abs(curX - this.fMoveDistX) < 100.0f && Math.abs(curY - this.fMoveDistY) < 100.0f) {
                            GL2JNILIb.DblClickView(curX, curY);
                        }
                        this.nClick = 0;
                        break;
                    }
                }
                curX = e.getX();
                curY = e.getY();
                this.fMoveDistX = curX;
                this.fMoveDistY = curY;
                break;
                break;
            case 2:
                if (e.getPointerCount() == 1) {
                    curX = e.getX();
                    curY = e.getY();
                    float distanceY = curY - this.mPrevY;
                    this.fSpeedX0 = curX - this.mPrevX;
                    this.fSpeedY0 = distanceY;
                    this.mPrevX = curX;
                    this.mPrevY = curY;
                    break;
                }
                break;
        }
        if (e.getPointerCount() == 1) {
            this.mGestureDetector.onTouchEvent(e);
        }
        this.mScaleGestureDetector.onTouchEvent(e);
        return true;
    }

    public boolean onTouch(View v, MotionEvent event) {
        if (event.getPointerCount() == 1) {
            this.mGestureDetector.onTouchEvent(event);
        }
        this.mScaleGestureDetector.onTouchEvent(event);
        return true;
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    public void onSensorChanged(SensorEvent event) {
    }
}
