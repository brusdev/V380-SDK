package com.example.hyfisheyepano;

public class CircleInfo {

    public static class SPoint {
        public float f3x;
        public float f4y;

        SPoint() {
            this.f3x = 0.0f;
            this.f4y = 0.0f;
            this.f3x = 0.0f;
            this.f4y = 0.0f;
        }

        SPoint(float _x, float _y) {
            this.f3x = 0.0f;
            this.f4y = 0.0f;
            this.f3x = _x;
            this.f4y = _y;
        }

        SPoint(int _x, int _y) {
            this.f3x = 0.0f;
            this.f4y = 0.0f;
            this.f3x = (float) _x;
            this.f4y = (float) _y;
        }
    }

    protected static float ptDistance1(SPoint p1, SPoint p2) {
        float dx = p2.f3x - p1.f3x;
        float dy = p2.f4y - p1.f4y;
        return (float) Math.sqrt((double) ((dx * dx) + (dy * dy)));
    }

    protected static float triangleArea1(SPoint pt0, SPoint pt1, SPoint pt2) {
        return Math.abs(((pt1.f3x - pt0.f3x) * (pt2.f4y - pt0.f4y)) - ((pt1.f4y - pt0.f4y) * (pt2.f3x - pt0.f3x))) / 2.0f;
    }

    protected static void circumcircleOfTriangle1(SPoint ptA, SPoint ptB, SPoint ptC, int[] cx, int[] cy, int[] radius) {
        radius[0] = (int) ((((ptDistance1(ptA, ptB) * ptDistance1(ptB, ptC)) * ptDistance1(ptC, ptA)) / triangleArea1(ptA, ptB, ptC)) / 4.0f);
        float xA = ptA.f3x;
        float yA = ptA.f4y;
        float xB = ptB.f3x;
        float yB = ptB.f4y;
        float xC = ptC.f3x;
        float yC = ptC.f4y;
        float c1 = ((((xA * xA) + (yA * yA)) - (xB * xB)) - (yB * yB)) / 2.0f;
        float c2 = ((((xA * xA) + (yA * yA)) - (xC * xC)) - (yC * yC)) / 2.0f;
        float yt = (((xA - xC) * c1) - ((xA - xB) * c2)) / (((yA - yB) * (xA - xC)) - ((yA - yC) * (xA - xB)));
        cx[0] = (int) ((((yA - yC) * c1) - ((yA - yB) * c2)) / (((xA - xB) * (yA - yC)) - ((xA - xC) * (yA - yB))));
        cy[0] = (int) yt;
    }

    protected static double angle(SPoint pt1, SPoint pt2, SPoint pt0) {
        double dx1 = (double) (pt1.f3x - pt0.f3x);
        double dy1 = (double) (pt1.f4y - pt0.f4y);
        double dx2 = (double) (pt2.f3x - pt0.f3x);
        double dy2 = (double) (pt2.f4y - pt0.f4y);
        return (Math.acos(((dx1 * dx2) + (dy1 * dy2)) / Math.sqrt((((dx1 * dx1) + (dy1 * dy1)) * ((dx2 * dx2) + (dy2 * dy2))) + 1.0E-10d)) / 3.1415927d) * 180.0d;
    }

    protected static boolean PrejudgePts(SPoint pt1, SPoint pt2, SPoint pt0) {
        if (angle(pt0, pt1, pt2) <= 150.0d && angle(pt2, pt0, pt1) <= 150.0d && angle(pt1, pt2, pt0) <= 150.0d) {
            return true;
        }
        return false;
    }

    public static boolean GetCircleInfo(int[] x, int[] y, int[] xcenter, int[] ycenter, int[] radius) {
        SPoint pt0 = new SPoint(x[0], y[0]);
        SPoint pt1 = new SPoint(x[1], y[1]);
        SPoint pt2 = new SPoint(x[2], y[2]);
        if (PrejudgePts(pt0, pt1, pt2)) {
            circumcircleOfTriangle1(pt0, pt1, pt2, xcenter, ycenter, radius);
            return true;
        }
        xcenter[0] = 0;
        ycenter[0] = 0;
        radius[0] = 0;
        return false;
    }
}
