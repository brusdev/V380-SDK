package com.example.hyfisheyepano;

import android.util.Log;

public class GL2JNILIb {
    public static native void DblClickView(float f, float f2);

    public static native void clean();

    public static native void create();

    public static native void flipView(float f, float f2);

    public static native void hoverView(boolean z, float f, float f2, float f3, float f4);

    public static native void init();

    public static native void moveView(float f, float f2);

    public static native void render();

    public static native void setExpandMode(int i);

    public static native void setImageParam(int i, float f, float f2, float f3);

    public static native void setTouch(boolean z, float f, float f2);

    public static native void setViewSize(int i, int i2);

    public static native void setYUV(Object obj, int i, int i2);

    public static native void zoomView(float f);

    static {
        try {
            System.loadLibrary("HYFisheyePano");
        } catch (UnsatisfiedLinkError e) {
            Log.e("HYFisheyePano", "Can't  link the lib.");
        }
    }
}
