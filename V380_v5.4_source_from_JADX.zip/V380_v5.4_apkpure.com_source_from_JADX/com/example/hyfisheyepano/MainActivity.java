package com.example.hyfisheyepano;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.macrovideo.v380.C0470R;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;

public class MainActivity extends ActionBarActivity {
    public Bitmap bitmap;
    public Bitmap bitmap2;
    public int[] bitmapdata = null;
    public int bitmapheight = 0;
    public int bitmapwidth = 0;
    public boolean bthreadexit = false;
    public byte[] byteData = new byte[4177920];
    public int[] data;
    public int fixtype = 1;
    private RelativeLayout frlayout;
    private GLFisheyeView glSurefaceView;
    public int img_cx = 655;
    public int img_cy = 470;
    public int img_rad = 472;
    public ByteBuffer mBuffer;

    class C02031 implements Runnable {
        C02031() {
        }

        public void run() {
            while (!MainActivity.this.bthreadexit) {
                try {
                    MainActivity.this.glSurefaceView.setYUVImage(MainActivity.this.byteData, 1280, 720);
                    Thread.sleep(40);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0470R.layout.activity_nvplayer_fisheye_playview);
        int[] x = new int[3];
        int[] y = new int[3];
        int[] cx = new int[1];
        int[] cy = new int[1];
        int[] rad = new int[]{20};
        x[1] = 20;
        x[2] = 100;
        y[0] = 10;
        y[1] = 100;
        y[2] = 50;
        boolean bok = CircleInfo.GetCircleInfo(x, y, cx, cy, rad);
        this.glSurefaceView = new GLFisheyeView(this);
        this.frlayout = (RelativeLayout) findViewById(2131034173);
        this.frlayout.addView(this.glSurefaceView);
        try {
            this.bitmap = BitmapFactory.decodeStream(getAssets().open("fisheye.jpg"));
            this.bitmapwidth = this.bitmap.getWidth();
            this.bitmapheight = this.bitmap.getHeight();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            this.bitmap2 = Bitmap.createBitmap(1280, 720, Config.ARGB_8888);
            InputStream inputStream = getResources().getAssets().open("yuv_1461947698.yuv420");
            if (inputStream != null) {
                BufferedInputStream bufReader = new BufferedInputStream(inputStream);
                if (bufReader != null) {
                    byte[] bs = new byte[1024];
                    int ncopy = 0;
                    while (bufReader.available() > 0) {
                        int nread = bufReader.read(bs);
                        System.arraycopy(bs, 0, this.byteData, ncopy, nread);
                        ncopy += nread;
                    }
                    Toast.makeText(getApplicationContext(), "ACTIVITYNCOPY:" + ncopy + "/" + 1382400, 0).show();
                    for (int j = 0; j < 720; j++) {
                        for (int i = 0; i < 1280; i++) {
                            byte val = this.byteData[(j * 1280) + i];
                            this.bitmap2.setPixel(i, j, ((val << 24) | (val << 16)) | (val << 8));
                        }
                    }
                }
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        try {
            this.glSurefaceView.setImageParam(this.fixtype, this.img_cx, this.img_cy, this.img_rad);
            new Thread(new C02031()).start();
        } catch (Exception e22) {
            e22.printStackTrace();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(2131492864, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 2131034175) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onDestroy() {
        this.bthreadexit = true;
        super.onDestroy();
    }
}
