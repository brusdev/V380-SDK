package com.tencent.android.tpush;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import com.tencent.android.tpush.common.C0531g;
import com.tencent.android.tpush.common.C0538n;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.service.p017e.C0631h;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.apache.http.protocol.HTTP;

/* compiled from: ProGuard */
public class XGDownloadService extends Service {
    private static final String f35c = XGDownloadService.class.getSimpleName();
    private int f36a = 0;
    private String f37b = Constants.MAIN_VERSION_TAG;
    private File f38d = null;
    private File f39e = null;
    private NotificationManager f40f = null;
    private Notification f41g = null;
    private Intent f42h = null;
    private PendingIntent f43i = null;
    private Handler f44j = new C0520b(this);

    public long m42a(String str, File file, int i) {
        InputStream inputStream;
        HttpURLConnection httpURLConnection;
        Throwable th;
        FileOutputStream fileOutputStream;
        long j = 0;
        try {
            HttpURLConnection httpURLConnection2 = (HttpURLConnection) new URL(str).openConnection();
            try {
                httpURLConnection2.setRequestProperty(HTTP.USER_AGENT, "PacificHttpClient");
                httpURLConnection2.setConnectTimeout(Constants.ERRORCODE_UNKNOWN);
                httpURLConnection2.setReadTimeout(20000);
                int contentLength = httpURLConnection2.getContentLength();
                if (httpURLConnection2.getResponseCode() == 404) {
                    throw new Exception("fail!");
                }
                InputStream inputStream2 = httpURLConnection2.getInputStream();
                try {
                    FileOutputStream fileOutputStream2 = new FileOutputStream(file, false);
                    try {
                        byte[] bArr = new byte[4096];
                        int i2 = 0;
                        while (true) {
                            int read = inputStream2.read(bArr);
                            if (read <= 0) {
                                break;
                            }
                            fileOutputStream2.write(bArr, 0, read);
                            j += (long) read;
                            if (i2 == 0 || ((int) ((100 * j) / ((long) contentLength))) - 10 > i2) {
                                i2 += 10;
                                this.f41g.setLatestEventInfo(this, "正在下载", ((((int) j) * 100) / contentLength) + "%", this.f43i);
                                this.f40f.notify(i, this.f41g);
                            }
                        }
                        if (httpURLConnection2 != null) {
                            httpURLConnection2.disconnect();
                        }
                        if (inputStream2 != null) {
                            inputStream2.close();
                        }
                        if (fileOutputStream2 != null) {
                            fileOutputStream2.close();
                        }
                        return j;
                    } catch (Throwable th2) {
                        inputStream = inputStream2;
                        FileOutputStream fileOutputStream3 = fileOutputStream2;
                        httpURLConnection = httpURLConnection2;
                        th = th2;
                        fileOutputStream = fileOutputStream3;
                        if (httpURLConnection != null) {
                            httpURLConnection.disconnect();
                        }
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                        throw th;
                    }
                } catch (Throwable th22) {
                    httpURLConnection = httpURLConnection2;
                    th = th22;
                    fileOutputStream = null;
                    inputStream = inputStream2;
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    if (fileOutputStream != null) {
                        fileOutputStream.close();
                    }
                    throw th;
                }
            } catch (Throwable th222) {
                Throwable th3 = th222;
                fileOutputStream = null;
                inputStream = null;
                httpURLConnection = httpURLConnection2;
                th = th3;
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                throw th;
            }
        } catch (Throwable th4) {
            th = th4;
            inputStream = null;
            httpURLConnection = null;
            fileOutputStream = null;
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }
            if (inputStream != null) {
                inputStream.close();
            }
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }
            throw th;
        }
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        int i3;
        Throwable th;
        this.f37b = intent.getStringExtra(Constants.FLAG_PACKAGE_DOWNLOAD_URL);
        int a;
        try {
            String str = "NOTIFY_ID";
            a = C0538n.m215a((Context) this, str, 0);
            if (a >= 2147483646) {
                a = 0;
            }
            try {
                C0538n.m220b((Context) this, str, a + 1);
                i3 = a;
            } catch (Throwable th2) {
                th = th2;
                C0503a.m91c(f35c, Constants.MAIN_VERSION_TAG, th);
                i3 = a;
                if (C0631h.m639c()) {
                    this.f38d = new File(Environment.getExternalStorageDirectory(), "app/download/");
                    this.f39e = new File(this.f38d.getPath(), "downloadApp" + i3 + ".apk");
                }
                this.f40f = (NotificationManager) getSystemService("notification");
                this.f41g = new Notification();
                this.f41g.icon = getApplicationInfo().icon;
                this.f41g.tickerText = "开始下载";
                this.f41g.setLatestEventInfo(this, "下载应用", "0%", this.f43i);
                this.f40f.notify(i3, this.f41g);
                C0531g.m193a().m196a(new C0524c(this, intent, i3));
                return super.onStartCommand(intent, i, i2);
            }
        } catch (Throwable th3) {
            Throwable th4 = th3;
            a = 0;
            th = th4;
            C0503a.m91c(f35c, Constants.MAIN_VERSION_TAG, th);
            i3 = a;
            if (C0631h.m639c()) {
                this.f38d = new File(Environment.getExternalStorageDirectory(), "app/download/");
                this.f39e = new File(this.f38d.getPath(), "downloadApp" + i3 + ".apk");
            }
            this.f40f = (NotificationManager) getSystemService("notification");
            this.f41g = new Notification();
            this.f41g.icon = getApplicationInfo().icon;
            this.f41g.tickerText = "开始下载";
            this.f41g.setLatestEventInfo(this, "下载应用", "0%", this.f43i);
            this.f40f.notify(i3, this.f41g);
            C0531g.m193a().m196a(new C0524c(this, intent, i3));
            return super.onStartCommand(intent, i, i2);
        }
        if (C0631h.m639c()) {
            this.f38d = new File(Environment.getExternalStorageDirectory(), "app/download/");
            this.f39e = new File(this.f38d.getPath(), "downloadApp" + i3 + ".apk");
        }
        this.f40f = (NotificationManager) getSystemService("notification");
        this.f41g = new Notification();
        this.f41g.icon = getApplicationInfo().icon;
        this.f41g.tickerText = "开始下载";
        this.f41g.setLatestEventInfo(this, "下载应用", "0%", this.f43i);
        this.f40f.notify(i3, this.f41g);
        C0531g.m193a().m196a(new C0524c(this, intent, i3));
        return super.onStartCommand(intent, i, i2);
    }

    public IBinder onBind(Intent intent) {
        return null;
    }
}
