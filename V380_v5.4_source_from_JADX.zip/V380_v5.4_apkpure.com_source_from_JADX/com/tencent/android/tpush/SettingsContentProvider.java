package com.tencent.android.tpush;

import android.annotation.SuppressLint;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.MatrixCursor.RowBuilder;
import android.net.Uri;
import android.os.Build.VERSION;
import com.tencent.android.tpush.p004a.C0503a;
import java.util.Map.Entry;

/* compiled from: ProGuard */
public class SettingsContentProvider extends ContentProvider {
    public static Uri BASE_URI = null;
    public static final String BOOLEAN_TYPE = "boolean";
    public static final String FLOAT_TYPE = "float";
    public static final String INT_TYPE = "integer";
    public static final String KEY = "key";
    public static final String LONG_TYPE = "long";
    public static final String PREFFERENCE_AUTHORITY = "TPUSH_PROVIDER";
    public static final String STRING_TYPE = "string";
    public static final String TYPE = "type";
    private static UriMatcher f32a;
    private static String f33b = null;
    private SharedPreferences f34c = null;

    private void m32a(Context context) {
        if (f33b == null) {
            f33b = context.getPackageName() + "." + PREFFERENCE_AUTHORITY;
        }
        if (f32a == null) {
            f32a = new UriMatcher(-1);
            f32a.addURI(f33b, "*/*", 65536);
        }
        if (BASE_URI == null) {
            BASE_URI = Uri.parse("content://" + f33b);
        }
        if (this.f34c == null) {
            this.f34c = context.getApplicationContext().getSharedPreferences(".tpns.settings.xml", 0);
        }
    }

    public boolean onCreate() {
        m32a(getContext());
        return true;
    }

    public String getType(Uri uri) {
        return "vnd.android.cursor.item/vnd.TPUSH_PROVIDER.item";
    }

    public int delete(Uri uri, String str, String[] strArr) {
        switch (f32a.match(uri)) {
            case 65536:
                this.f34c.edit().clear().commit();
                break;
            default:
                C0503a.m98h("SettingsContentProvider", "Unsupported uri " + uri);
                break;
        }
        return 0;
    }

    @SuppressLint({"NewApi"})
    public Uri insert(Uri uri, ContentValues contentValues) {
        switch (f32a.match(uri)) {
            case 65536:
                Editor edit = this.f34c.edit();
                for (Entry entry : contentValues.valueSet()) {
                    Object value = entry.getValue();
                    String str = (String) entry.getKey();
                    if (value == null) {
                        edit.remove(str);
                    } else if (value instanceof String) {
                        edit.putString(str, (String) value);
                    } else if (value instanceof Boolean) {
                        edit.putBoolean(str, ((Boolean) value).booleanValue());
                    } else if (value instanceof Long) {
                        edit.putLong(str, ((Long) value).longValue());
                    } else if (value instanceof Integer) {
                        edit.putInt(str, ((Integer) value).intValue());
                    } else if (value instanceof Float) {
                        edit.putFloat(str, ((Float) value).floatValue());
                    } else {
                        C0503a.m98h("SettingsContentProvider", "Unsupported type " + uri);
                    }
                }
                if (VERSION.SDK_INT <= 8) {
                    edit.commit();
                    break;
                }
                edit.apply();
                break;
            default:
                C0503a.m98h("SettingsContentProvider", "Unsupported uri " + uri);
                break;
        }
        return null;
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        String str3;
        switch (f32a.match(uri)) {
            case 65536:
                str3 = (String) uri.getPathSegments().get(0);
                String str4 = (String) uri.getPathSegments().get(1);
                Cursor matrixCursor = new MatrixCursor(new String[]{str3});
                if (this.f34c.contains(str3)) {
                    Object obj;
                    RowBuilder newRow = matrixCursor.newRow();
                    if (!STRING_TYPE.equals(str4)) {
                        if (!BOOLEAN_TYPE.equals(str4)) {
                            if (!LONG_TYPE.equals(str4)) {
                                if (!INT_TYPE.equals(str4)) {
                                    if (!FLOAT_TYPE.equals(str4)) {
                                        C0503a.m98h("SettingsContentProvider", "Unsupported type " + uri);
                                        obj = matrixCursor;
                                        break;
                                    }
                                    obj = Float.valueOf(this.f34c.getFloat(str3, 0.0f));
                                } else {
                                    obj = Integer.valueOf(this.f34c.getInt(str3, 0));
                                }
                            } else {
                                obj = Long.valueOf(this.f34c.getLong(str3, 0));
                            }
                        } else {
                            obj = Integer.valueOf(this.f34c.getBoolean(str3, false) ? 1 : 0);
                        }
                    } else {
                        obj = this.f34c.getString(str3, null);
                    }
                    newRow.add(obj);
                    obj = matrixCursor;
                    break;
                }
                return matrixCursor;
            default:
                C0503a.m98h("SettingsContentProvider", "Unsupported uri " + uri);
                str3 = null;
                break;
        }
        return str3;
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        C0503a.m98h("SettingsContentProvider", "UnsupportedOperation: update!");
        return 0;
    }

    public static String getStringValue(Cursor cursor, String str) {
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                str = cursor.getString(0);
            }
            cursor.close();
        }
        return str;
    }

    public static boolean getBooleanValue(Cursor cursor, boolean z) {
        boolean z2 = false;
        if (cursor == null) {
            return z;
        }
        if (!cursor.moveToFirst()) {
            z2 = z;
        } else if (cursor.getInt(0) > 0) {
            z2 = true;
        }
        cursor.close();
        return z2;
    }

    public static int getIntValue(Cursor cursor, int i) {
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                i = cursor.getInt(0);
            }
            cursor.close();
        }
        return i;
    }

    public static long getLongValue(Cursor cursor, long j) {
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                j = cursor.getLong(0);
            }
            cursor.close();
        }
        return j;
    }

    public static float getFloatValue(Cursor cursor, float f) {
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                f = cursor.getFloat(0);
            }
            cursor.close();
        }
        return f;
    }

    public static final Uri getContentUri(Context context, String str, String str2) {
        if (BASE_URI == null) {
            if (f33b == null) {
                f33b = context.getPackageName() + "." + PREFFERENCE_AUTHORITY;
            }
            BASE_URI = Uri.parse("content://" + f33b);
        }
        return BASE_URI.buildUpon().appendPath(str).appendPath(str2).build();
    }
}
