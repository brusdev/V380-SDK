package com.tencent.android.tpush;

import android.content.Context;

/* compiled from: ProGuard */
public class XGPro {
    private static boolean f79a = false;

    public static void enableXGPro(Context context, boolean z) {
        f79a = z;
    }

    public static boolean isEnableXGPro(Context context) {
        return f79a;
    }
}
