package com.tencent.android.tpush;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.tencent.android.tpush.common.Constants;

/* compiled from: ProGuard */
class C0571n implements OnClickListener {
    final /* synthetic */ Intent f333a;
    final /* synthetic */ XGPushActivity f334b;

    C0571n(XGPushActivity xGPushActivity, Intent intent) {
        this.f334b = xGPushActivity;
        this.f333a = intent;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.f333a.putExtra("action", 5);
        this.f334b.broadcastToTPushService(this.f333a);
        Intent intent = new Intent(this.f334b, XGDownloadService.class);
        intent.putExtras(this.f333a);
        intent.putExtra(Constants.FLAG_PACKAGE_DOWNLOAD_URL, this.f333a.getStringExtra(Constants.FLAG_PACKAGE_DOWNLOAD_URL));
        this.f334b.startService(intent);
        this.f334b.finish();
    }
}
