package com.tencent.android.tpush;

import android.app.Notification;
import android.content.Context;
import org.json.JSONObject;

/* compiled from: ProGuard */
public class XGBasicPushNotificationBuilder extends XGPushNotificationBuilder {
    public Notification buildNotification(Context context) {
        return m67a(context);
    }

    protected void mo1667a(JSONObject jSONObject) {
    }

    protected void mo1668b(JSONObject jSONObject) {
    }

    public String getType() {
        return XGPushNotificationBuilder.BASIC_NOTIFICATION_BUILDER_TYPE;
    }
}
