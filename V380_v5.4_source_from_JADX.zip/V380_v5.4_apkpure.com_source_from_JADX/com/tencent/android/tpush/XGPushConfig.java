package com.tencent.android.tpush;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.jg.EType;
import com.jg.JgClassChecked;
import com.tencent.android.tpush.common.C0529e;
import com.tencent.android.tpush.common.C0531g;
import com.tencent.android.tpush.common.C0538n;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.encrypt.Rijndael;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.p006c.C0521a;
import com.tencent.android.tpush.service.cache.CacheManager;
import com.tencent.android.tpush.service.channel.security.TpnsSecurity;
import com.tencent.android.tpush.service.p017e.C0631h;
import java.util.ArrayList;
import java.util.List;

@JgClassChecked(author = 1, fComment = "确认已进行安全校验", lastDate = "20150316", reviewer = 3, vComment = {EType.RECEIVERCHECK, EType.INTENTCHECK})
/* compiled from: ProGuard */
public class XGPushConfig {
    public static final String TPUSH_ACCESS_ID = "XG_V2_ACCESS_ID";
    public static final String TPUSH_ACCESS_KEY = "XG_V2_ACCESS_KEY";
    private static final String f84a = XGPushConfig.class.getSimpleName();
    private static String f85b = Constants.MAIN_VERSION_TAG;
    private static String f86c = Constants.MAIN_VERSION_TAG;
    private static long f87d = -1;
    private static String f88e = Constants.MAIN_VERSION_TAG;
    public static boolean enableDebug = false;

    public static synchronized long getAccessId(Context context) {
        long j;
        synchronized (XGPushConfig.class) {
            if (context == null) {
                j = f87d;
            } else if (f87d != -1) {
                j = f87d;
            } else if (TpnsSecurity.checkTpnsSecurityLibSo(context)) {
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
                if (defaultSharedPreferences != null) {
                    String string = defaultSharedPreferences.getString(TPUSH_ACCESS_ID, null);
                    if (string != null) {
                        try {
                            f87d = Long.valueOf(Rijndael.decrypt(string)).longValue();
                        } catch (Throwable e) {
                            f87d = -1;
                            C0503a.m86b(f84a, "get accessId error", e);
                        }
                    }
                }
                if (f87d == -1) {
                    Object a = C0529e.m186a(context, TPUSH_ACCESS_ID, null);
                    if (a != null) {
                        try {
                            f87d = Long.valueOf(a.toString()).longValue();
                        } catch (Throwable e2) {
                            C0503a.m86b(Constants.LogTag, "get accessId from getMetaData failed: ", e2);
                            f87d = -1;
                        }
                    }
                }
                if (f87d == -1) {
                    C0503a.m98h(Constants.LogTag, "accessId没有初始化");
                }
                j = f87d;
            } else {
                j = f87d;
            }
        }
        return j;
    }

    public static void setAccessId(Context context, long j) {
        if (context == null) {
            C0503a.m98h(f84a, "null  context");
            return;
        }
        f87d = j;
        C0531g.m193a().m196a(new C0575r(context, j));
    }

    public static synchronized String getAccessKey(Context context) {
        String str = null;
        synchronized (XGPushConfig.class) {
            if (!C0631h.m636b(f88e)) {
                str = f88e;
            } else if (TpnsSecurity.checkTpnsSecurityLibSo(context)) {
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
                if (defaultSharedPreferences != null) {
                    str = defaultSharedPreferences.getString(TPUSH_ACCESS_KEY, null);
                    if (C0631h.m636b(str)) {
                        f88e = Rijndael.decrypt(str);
                    }
                }
                if (C0631h.m636b(f88e)) {
                    Object a = C0529e.m186a(context, TPUSH_ACCESS_KEY, null);
                    if (a != null) {
                        f88e = a.toString();
                    }
                }
                if (C0631h.m636b(f88e)) {
                    C0503a.m98h(f84a, "accessKey is null");
                }
                str = f88e;
            }
        }
        return str;
    }

    public static void setAccessKey(Context context, String str) {
        if (context == null || str == null) {
            C0503a.m98h(Constants.LogTag, "null context or null accessKey");
            return;
        }
        f88e = str;
        C0531g.m193a().m196a(new C0578s(context, str));
    }

    public static String getToken(Context context) {
        if (context != null) {
            return CacheManager.getToken(context);
        }
        C0503a.m98h(Constants.LogTag, "null context");
        return null;
    }

    public static void enableDebug(Context context, boolean z) {
        if (context != null) {
            enableDebug = z;
            C0531g.m193a().m196a(new C0680t(z, context));
        }
    }

    public static boolean isEnableDebug(Context context) {
        return C0538n.m215a(context, new StringBuilder().append("com.tencent.android.tpush.debug,").append(context.getPackageName()).toString(), 0) != 0;
    }

    public static List getAccessidList(Context context) {
        ArrayList arrayList = new ArrayList(2);
        if (context != null) {
            long accessId = getAccessId(context);
            if (accessId > 0) {
                arrayList.add(Long.valueOf(accessId));
            }
            accessId = XGPush4Msdk.getQQAccessId(context);
            if (accessId > 0) {
                arrayList.add(Long.valueOf(accessId));
            }
            Object a = C0529e.m186a(context, TPUSH_ACCESS_ID, null);
            if (a != null) {
                try {
                    accessId = Long.valueOf(a.toString()).longValue();
                    if (!arrayList.contains(Long.valueOf(accessId))) {
                        arrayList.add(Long.valueOf(accessId));
                    }
                } catch (Throwable e) {
                    C0503a.m86b(f84a, "get accessId from getMetaData failed: ", e);
                }
            }
        }
        return arrayList;
    }

    public static void setInstallChannel(Context context, String str) {
        if (context != null && str != null && str.trim().length() != 0) {
            f85b = str;
        }
    }

    public static String getInstallChannel(Context context) {
        return f85b;
    }

    public static void setGameServer(Context context, String str) {
        if (context != null && str != null && str.trim().length() != 0) {
            f86c = str;
        }
    }

    public static String getGameServer(Context context) {
        return f86c;
    }

    public static void setHeartbeatIntervalMs(Context context, int i) {
        if (context != null && i >= 5000 && i < 1800000) {
            try {
                C0538n.m220b(context, "com.tencent.android.xg.wx.HeartbeatIntervalMs", i);
            } catch (Throwable e) {
                C0503a.m91c(f84a, "setHeartbeatIntervalMs", e);
            }
        }
    }

    public static void setReportDebugMode(Context context, boolean z) {
        if (context != null) {
            C0538n.m220b(context, context.getPackageName() + ".report.mode", z ? 1 : 0);
        }
    }

    public static boolean getReportDebugMode(Context context) {
        if (C0538n.m215a(context, context.getPackageName() + ".report.mode", 0) != 0) {
            return true;
        }
        return false;
    }

    public static void setMiPushAppId(Context context, String str) {
        C0521a.m176b(context, str);
    }

    public static void setMiPushAppKey(Context context, String str) {
        C0521a.m179c(context, str);
    }

    public static void setGCMSenderId(Context context, String str) {
        C0521a.m181d(context, str);
    }
}
