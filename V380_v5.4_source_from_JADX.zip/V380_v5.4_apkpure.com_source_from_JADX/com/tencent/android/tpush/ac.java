package com.tencent.android.tpush;

import android.content.Context;

/* compiled from: ProGuard */
final class ac implements XGIOperateCallback {
    final /* synthetic */ Context f1194a;

    ac(Context context) {
        this.f1194a = context;
    }

    public void onSuccess(Object obj, int i) {
        XGPushManager.m53a(this.f1194a);
    }

    public void onFail(Object obj, int i, String str) {
        XGPushManager.m53a(this.f1194a);
    }
}
