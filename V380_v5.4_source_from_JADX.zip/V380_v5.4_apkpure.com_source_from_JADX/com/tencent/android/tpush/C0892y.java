package com.tencent.android.tpush;

import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
final class C0892y implements XGIOperateCallback {
    C0892y() {
    }

    public void onSuccess(Object obj, int i) {
        C0503a.m95e(XGPushManager.f89a, "UnRegisterPush push succeed with token = " + obj + " flag = " + i);
    }

    public void onFail(Object obj, int i, String str) {
        C0503a.m99i(XGPushManager.f89a, "UnRegisterPush push failed with token = " + obj + " , errCode = " + i + " , msg = " + str);
    }
}
