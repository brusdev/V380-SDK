package com.tencent.android.tpush;

import android.app.Notification;
import android.content.Context;
import android.graphics.Bitmap;
import android.widget.RemoteViews;
import com.tencent.android.tpush.common.C0529e;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONObject;

/* compiled from: ProGuard */
public class XGCustomPushNotificationBuilder extends XGPushNotificationBuilder {
    private Integer f1173A = null;
    private Integer f1174B = null;
    private Integer f1175C = null;
    private Bitmap f1176D = null;
    private Integer f1177w = null;
    private Integer f1178x = null;
    private Integer f1179y = null;
    private Integer f1180z = null;

    protected void mo1667a(JSONObject jSONObject) {
        C0529e.m190a(jSONObject, "layoutId", this.f1177w);
        C0529e.m190a(jSONObject, "layoutIconId", this.f1178x);
        C0529e.m190a(jSONObject, "layoutTitleId", this.f1179y);
        C0529e.m190a(jSONObject, "layoutTextId", this.f1180z);
        C0529e.m190a(jSONObject, "layoutIconDrawableId", this.f1173A);
        C0529e.m190a(jSONObject, "statusBarIconDrawableId", this.f1174B);
        C0529e.m190a(jSONObject, "layoutTimeId", this.f1175C);
    }

    protected void mo1668b(JSONObject jSONObject) {
        this.f1177w = (Integer) C0529e.m191b(jSONObject, "layoutId", null);
        this.f1178x = (Integer) C0529e.m191b(jSONObject, "layoutIconId", null);
        this.f1179y = (Integer) C0529e.m191b(jSONObject, "layoutTitleId", null);
        this.f1180z = (Integer) C0529e.m191b(jSONObject, "layoutTextId", null);
        this.f1173A = (Integer) C0529e.m191b(jSONObject, "layoutIconDrawableId", null);
        this.f1174B = (Integer) C0529e.m191b(jSONObject, "statusBarIconDrawableId", null);
        this.f1175C = (Integer) C0529e.m191b(jSONObject, "layoutTimeId", null);
    }

    public Notification buildNotification(Context context) {
        if (this.f1177w == null) {
            return m67a(context);
        }
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), this.f1177w.intValue());
        if (this.f1179y != null) {
            remoteViews.setTextViewText(this.f1179y.intValue(), getTitle(context));
        }
        if (this.f1180z != null) {
            remoteViews.setTextViewText(this.f1180z.intValue(), this.o);
        }
        if (this.f1178x != null) {
            remoteViews.setImageViewResource(this.f1178x.intValue(), this.f1173A.intValue());
        }
        if (this.f1176D != null) {
            remoteViews.setImageViewBitmap(this.f1178x.intValue(), this.f1176D);
        }
        if (this.f1174B != null) {
            remoteViews.setTextViewText(this.f1174B.intValue(), getTitle(context));
        }
        if (this.f1175C != null) {
            remoteViews.setTextViewText(this.f1175C.intValue(), String.valueOf(new SimpleDateFormat("HH:mm").format(new Date(System.currentTimeMillis()))));
        }
        this.c = remoteViews;
        return m67a(context);
    }

    public int getLayoutId() {
        return this.f1177w.intValue();
    }

    public XGCustomPushNotificationBuilder setLayoutId(int i) {
        this.f1177w = Integer.valueOf(i);
        return this;
    }

    public Integer getLayoutIconId() {
        return this.f1178x;
    }

    public XGCustomPushNotificationBuilder setLayoutIconId(int i) {
        this.f1178x = Integer.valueOf(i);
        return this;
    }

    public int getLayoutTitleId() {
        return this.f1179y.intValue();
    }

    public XGCustomPushNotificationBuilder setLayoutTitleId(int i) {
        this.f1179y = Integer.valueOf(i);
        return this;
    }

    public int getLayoutTextId() {
        return this.f1180z.intValue();
    }

    public int getLayoutTimeId() {
        return this.f1175C.intValue();
    }

    public XGCustomPushNotificationBuilder setLayoutTextId(int i) {
        this.f1180z = Integer.valueOf(i);
        return this;
    }

    public XGCustomPushNotificationBuilder setLayoutTimeId(int i) {
        this.f1175C = Integer.valueOf(i);
        return this;
    }

    public int getLayoutIconDrawableId() {
        return this.f1173A.intValue();
    }

    public XGCustomPushNotificationBuilder setLayoutIconDrawableId(int i) {
        this.f1173A = Integer.valueOf(i);
        return this;
    }

    public XGCustomPushNotificationBuilder setLayoutIconDrawableBmp(Bitmap bitmap) {
        this.f1176D = bitmap;
        return this;
    }

    public String getType() {
        return XGPushNotificationBuilder.CUSTOM_NOTIFICATION_BUILDER_TYPE;
    }
}
