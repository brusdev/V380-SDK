package com.tencent.android.tpush;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;

/* compiled from: ProGuard */
class C0566i implements OnClickListener {
    final /* synthetic */ Intent f323a;
    final /* synthetic */ XGPushActivity f324b;

    C0566i(XGPushActivity xGPushActivity, Intent intent) {
        this.f324b = xGPushActivity;
        this.f323a = intent;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.f324b.openIntent(this.f323a);
        this.f324b.finish();
    }
}
