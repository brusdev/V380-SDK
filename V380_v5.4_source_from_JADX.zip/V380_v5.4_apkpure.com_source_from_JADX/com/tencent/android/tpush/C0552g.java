package com.tencent.android.tpush;

import android.app.Activity;
import android.app.Application.ActivityLifecycleCallbacks;
import android.os.Bundle;
import com.tencent.android.tpush.stat.C0668h;

/* compiled from: ProGuard */
final class C0552g implements ActivityLifecycleCallbacks {
    C0552g() {
    }

    public void onActivityStopped(Activity activity) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityResumed(Activity activity) {
        if (activity != null && activity.getComponentName().getClassName() != null && XGPushActivity.mContext != null) {
            C0668h.m900b(XGPushActivity.mContext, activity.getComponentName().getClassName(), XGPushConfig.getAccessId(XGPushActivity.mContext));
        }
    }

    public void onActivityPaused(Activity activity) {
        if (activity != null && activity.getComponentName().getClassName() != null && XGPushActivity.mContext != null) {
            if (activity.getComponentName().getClassName().equals(XGPushActivity.activityName)) {
                C0668h.m906c(XGPushActivity.mContext, activity.getComponentName().getClassName(), XGPushConfig.getAccessId(XGPushActivity.mContext));
            } else {
                C0668h.m890a(XGPushActivity.mContext, activity.getComponentName().getClassName(), XGPushConfig.getAccessId(XGPushActivity.mContext), XGPushActivity.msgId, XGPushActivity.msgBuildId);
            }
        }
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
    }
}
