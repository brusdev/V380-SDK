package com.tencent.android.tpush;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import com.jg.EType;
import com.jg.JgClassChecked;
import com.tencent.android.tpush.p005b.C0845f;

@JgClassChecked(author = 1, fComment = "确认已进行安全校验", lastDate = "20150316", reviewer = 3, vComment = {EType.RECEIVERCHECK, EType.INTENTCHECK})
/* compiled from: ProGuard */
public class XGNotifaction {
    private int f73a = 0;
    private Notification f74b = null;
    private String f75c = null;
    private String f76d = null;
    private String f77e = null;
    private Context f78f = null;

    public XGNotifaction(Context context, int i, Notification notification, C0845f c0845f) {
        this.f78f = context.getApplicationContext();
        this.f73a = i;
        this.f74b = notification;
        this.f75c = c0845f.m117e();
        this.f76d = c0845f.m118f();
        this.f77e = c0845f.m119g();
    }

    public void setNotifyId(int i) {
        this.f73a = i;
    }

    public String toString() {
        return "XGNotifaction [notifyId=" + this.f73a + ", title=" + this.f75c + ", content=" + this.f76d + ", customContent=" + this.f77e + "]";
    }

    public boolean doNotify() {
        if (!(this.f74b == null || this.f78f == null)) {
            NotificationManager notificationManager = (NotificationManager) this.f78f.getSystemService("notification");
            if (notificationManager != null) {
                notificationManager.notify(this.f73a, this.f74b);
                return true;
            }
        }
        return false;
    }

    public int getNotifyId() {
        return this.f73a;
    }

    public Notification getNotifaction() {
        return this.f74b;
    }

    public String getTitle() {
        return this.f75c;
    }

    public String getContent() {
        return this.f76d;
    }

    public String getCustomContent() {
        return this.f77e;
    }
}
