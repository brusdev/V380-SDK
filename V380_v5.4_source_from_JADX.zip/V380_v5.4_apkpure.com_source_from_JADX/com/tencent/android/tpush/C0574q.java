package com.tencent.android.tpush;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;

/* compiled from: ProGuard */
class C0574q implements OnClickListener {
    final /* synthetic */ String f339a;
    final /* synthetic */ Intent f340b;
    final /* synthetic */ XGPushActivity f341c;

    C0574q(XGPushActivity xGPushActivity, String str, Intent intent) {
        this.f341c = xGPushActivity;
        this.f339a = str;
        this.f340b = intent;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.f341c.openUrl(this.f339a, this.f340b);
        this.f341c.finish();
    }
}
