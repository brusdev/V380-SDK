package com.tencent.android.tpush;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import com.tencent.android.tpush.common.C0531g;
import com.tencent.android.tpush.common.C0538n;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.encrypt.Rijndael;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.p005b.C0508b;
import com.tencent.android.tpush.service.p017e.C0631h;

/* compiled from: ProGuard */
public class XGPush4Msdk {
    private static long f80a = 0;
    private static long f81b = 0;
    private static String f82c = Constants.MAIN_VERSION_TAG;

    private static String m45b(Context context) {
        return context.getPackageName() + ":" + "XG_DEBUG_SERVER_INFO";
    }

    public static void setDebugServerInfo(Context context, String str, int i) {
        if (C0631h.m636b(str)) {
            C0531g.m193a().m196a(new C0548d(context));
        } else {
            C0538n.m222b(context, m45b(context), str + "," + i);
        }
    }

    public static String getDebugServerInfo(Context context) {
        return C0538n.m218a(context, m45b(context), null);
    }

    private static boolean m44a(long j, long j2, long j3) {
        return j >= j2 && j < j3;
    }

    public static void setQQAppId(Context context, long j) {
        long j2;
        if (m44a(j, 0, 200000)) {
            j2 = 90000000;
        } else if (m44a(j, 99000000, 100000000)) {
            j2 = 0;
        } else if (m44a(j, 100200000, 100600000)) {
            j2 = -10000000;
        } else if (m44a(j, 101000000, 101400000)) {
            j2 = -10400000;
        } else if (m44a(j, 900000000, 900100000)) {
            j2 = -809000000;
        } else if (m44a(j, 1000000000, 1000100000)) {
            j2 = -908900000;
        } else if (m44a(j, 1101000000, 1104500000)) {
            j2 = -1009800000;
        } else if (m44a(j, 1150000000, 1150100000)) {
            j2 = -1055300000;
        } else if (m44a(j, 100600000, 101000000)) {
            j2 = -5800000;
        } else if (m44a(j, 1104500000, 1109300000)) {
            j2 = -1009300000;
        } else if (m44a(j, 1109300000, 1119300000)) {
            j2 = -1029300000;
        } else if (m44a(j, 1119300000, 1120000000)) {
            j2 = -1049300000;
        } else {
            Log.e(Constants.MSDK_TAG, "手Q的appid：" + j + " 不在固定的范围，请联系msdk和信鸽的同事解决之。");
            j2 = 0;
        }
        j2 = (j2 + 2100000000) + j;
        f80a = j;
        f81b = j2;
        C0538n.m221b(context, "TPUSH_QQ_ACCESS_ID", f81b);
        C0538n.m219a(context, "TPUSH_QQ_APP_ID");
        f82c = "MSDK_" + j;
        C0538n.m222b(context, "__en__TPUSH_QQ_ACCESS_KEY", Rijndael.encrypt(f82c));
        C0538n.m219a(context, "TPUSH_QQ_ACCESS_KEY");
    }

    public static long getQQAccessId(Context context) {
        if (f81b <= 0) {
            f81b = C0538n.m216a(context, "TPUSH_QQ_ACCESS_ID", f81b);
        }
        return f81b;
    }

    public static void setQQAppKey(Context context, String str) {
    }

    public static String getQQAppKey(Context context) {
        if (!TextUtils.isEmpty(f82c)) {
            return f82c;
        }
        Object a = C0538n.m218a(context, "__en__TPUSH_QQ_ACCESS_KEY", f82c);
        if (TextUtils.isEmpty(a)) {
            f82c = C0538n.m218a(context, "TPUSH_QQ_ACCESS_KEY", Constants.MAIN_VERSION_TAG);
            C0538n.m222b(context, "TPUSH_QQ_ACCESS_KEY", Constants.MAIN_VERSION_TAG);
        } else {
            f82c = Rijndael.decrypt(a);
        }
        return f82c;
    }

    public static void setTag(Context context, String str) {
        C0503a.m90c(Constants.MSDK_TAG, "setTag: tagName=" + str + ",qqAppid=" + f80a + ",xg_accessid=" + getQQAccessId(context));
        XGPushManager.m59a(context, str, 1, getQQAccessId(context));
    }

    public static void deleteTag(Context context, String str) {
        if (XGPushConfig.enableDebug) {
            C0503a.m90c(Constants.MSDK_TAG, "deleteTag: tagName=" + str + ",qqAppid=" + f80a + ",xg_accessid=" + getQQAccessId(context));
        }
        XGPushManager.m59a(context, str, 2, getQQAccessId(context));
    }

    public static void registerPush(Context context, String str, XGIOperateCallback xGIOperateCallback) {
        XGIOperateCallback c0847e;
        if (XGPushConfig.enableDebug) {
            C0503a.m93d(Constants.MSDK_TAG, "registerPush: account=" + str + ",qqAppid=" + f80a + ",xg_accessid=" + getQQAccessId(context));
        }
        if (xGIOperateCallback == null) {
            c0847e = new C0847e();
        } else {
            c0847e = xGIOperateCallback;
        }
        if (C0631h.m636b(str)) {
            XGPushManager.m60a(context, null, null, -1, null, c0847e, getQQAccessId(context), getQQAppKey(context));
            return;
        }
        XGPushManager.m60a(context, str, "0", 0, null, c0847e, getQQAccessId(context), getQQAppKey(context));
    }

    public static void unregisterPush(Context context, XGIOperateCallback xGIOperateCallback) {
        if (XGPushConfig.enableDebug) {
            C0503a.m93d(Constants.MSDK_TAG, "unregisterPush,qqAppid=" + f80a + ",xg_accessid=" + getQQAccessId(context));
        }
        if (xGIOperateCallback == null) {
            xGIOperateCallback = new C0848f();
        }
        XGPushManager.m58a(context, xGIOperateCallback, getQQAccessId(context), getQQAppKey(context));
    }

    public static long addLocalNotification(Context context, XGLocalMessage xGLocalMessage) {
        if (XGPushConfig.enableDebug) {
            C0503a.m93d(Constants.MSDK_TAG, "addLocalNotification:msg=" + xGLocalMessage.toString() + ",qqAppid=" + f80a + ",xg_accessid=" + getQQAccessId(context));
        }
        return XGPushManager.m49a(context, xGLocalMessage, getQQAccessId(context));
    }

    public static void setPushNotificationBuilder(Context context, int i, XGPushNotificationBuilder xGPushNotificationBuilder) {
        if (context == null) {
            throw new IllegalArgumentException("context is null.");
        } else if (i < 5000 || i > 6000) {
            throw new IllegalArgumentException("notificationBulderId超过范围[5000, 6000].");
        } else if (xGPushNotificationBuilder != null) {
            C0508b.m124a(context, i, xGPushNotificationBuilder);
        }
    }

    public static void setDefaultNotificationBuilder(Context context, XGPushNotificationBuilder xGPushNotificationBuilder) {
        XGPushManager.setDefaultNotificationBuilder(context, xGPushNotificationBuilder);
    }
}
