package com.tencent.android.tpush;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v4.app.NotificationCompat.BigTextStyle;
import android.support.v4.app.NotificationCompat.Builder;
import android.support.v4.app.NotificationCompat.Style;
import android.widget.RemoteViews;
import com.tencent.android.tpush.common.C0529e;
import com.tencent.android.tpush.common.MessageKey;
import org.json.JSONObject;

/* compiled from: ProGuard */
public abstract class XGPushNotificationBuilder {
    public static final String BASIC_NOTIFICATION_BUILDER_TYPE = "basic";
    public static final String CUSTOM_NOTIFICATION_BUILDER_TYPE = "custom";
    protected Integer f93a = null;
    protected PendingIntent f94b = null;
    protected RemoteViews f95c = null;
    protected RemoteViews f96d = null;
    protected Integer f97e = null;
    protected PendingIntent f98f = null;
    protected Integer f99g = null;
    protected Integer f100h = null;
    protected Integer f101i = null;
    protected Integer f102j = null;
    protected Integer f103k = null;
    protected Integer f104l = null;
    protected Integer f105m = null;
    protected Uri f106n = null;
    protected CharSequence f107o = null;
    protected long[] f108p = null;
    protected Long f109q = null;
    protected Integer f110r = null;
    protected Bitmap f111s = null;
    protected Integer f112t = null;
    protected String f113u;
    protected Integer f114v = null;

    protected abstract void mo1667a(JSONObject jSONObject);

    protected abstract void mo1668b(JSONObject jSONObject);

    public abstract Notification buildNotification(Context context);

    public abstract String getType();

    public void encode(JSONObject jSONObject) {
        mo1667a(jSONObject);
        C0529e.m190a(jSONObject, "audioStringType", this.f93a);
        C0529e.m190a(jSONObject, "defaults", this.f97e);
        C0529e.m190a(jSONObject, "flags", this.f99g);
        C0529e.m190a(jSONObject, MessageKey.MSG_ICON, this.f100h);
        C0529e.m190a(jSONObject, "iconLevel", this.f101i);
        C0529e.m190a(jSONObject, "ledARGB", this.f102j);
        C0529e.m190a(jSONObject, "ledOffMS", this.f103k);
        C0529e.m190a(jSONObject, "ledOnMS", this.f104l);
        C0529e.m190a(jSONObject, "number", this.f105m);
        C0529e.m190a(jSONObject, "sound", this.f106n);
        C0529e.m190a(jSONObject, "smallIcon", this.f110r);
        C0529e.m190a(jSONObject, "notificationLargeIcon", this.f112t);
        if (this.f108p != null) {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < this.f108p.length; i++) {
                stringBuilder.append(String.valueOf(this.f108p[i]));
                if (i != this.f108p.length - 1) {
                    stringBuilder.append(",");
                }
            }
            C0529e.m190a(jSONObject, MessageKey.MSG_VIBRATE, stringBuilder.toString());
        }
        C0529e.m190a(jSONObject, "notificationId", this.f114v);
    }

    public void decode(String str) {
        JSONObject jSONObject = new JSONObject(str);
        mo1668b(jSONObject);
        this.f93a = (Integer) C0529e.m191b(jSONObject, "audioStringType", null);
        this.f97e = (Integer) C0529e.m191b(jSONObject, "defaults", null);
        this.f99g = (Integer) C0529e.m191b(jSONObject, "flags", null);
        this.f100h = (Integer) C0529e.m191b(jSONObject, MessageKey.MSG_ICON, null);
        this.f101i = (Integer) C0529e.m191b(jSONObject, "iconLevel", null);
        this.f102j = (Integer) C0529e.m191b(jSONObject, "ledARGB", null);
        this.f103k = (Integer) C0529e.m191b(jSONObject, "ledOffMS", null);
        this.f104l = (Integer) C0529e.m191b(jSONObject, "ledOnMS", null);
        this.f105m = (Integer) C0529e.m191b(jSONObject, "number", null);
        String str2 = (String) C0529e.m191b(jSONObject, "sound", null);
        this.f110r = (Integer) C0529e.m191b(jSONObject, "smallIcon", null);
        this.f112t = (Integer) C0529e.m191b(jSONObject, "notificationLargeIcon", null);
        if (str2 != null) {
            this.f106n = Uri.parse(str2);
        }
        str2 = (String) C0529e.m191b(jSONObject, MessageKey.MSG_VIBRATE, null);
        if (str2 != null) {
            String[] split = str2.split(",");
            int length = split.length;
            this.f108p = new long[length];
            for (int i = 0; i < length; i++) {
                try {
                    this.f108p[i] = Long.valueOf(split[i]).longValue();
                } catch (NumberFormatException e) {
                }
            }
        }
        this.f114v = (Integer) C0529e.m191b(jSONObject, "notificationId", null);
    }

    public String getTitle(Context context) {
        if (this.f113u == null) {
            this.f113u = (String) context.getApplicationContext().getPackageManager().getApplicationLabel(context.getApplicationInfo());
        }
        return this.f113u;
    }

    public void setTitle(String str) {
        this.f113u = str;
    }

    public int getApplicationIcon(Context context) {
        return context.getApplicationInfo().icon;
    }

    protected Notification m67a(Context context) {
        Notification notification = new Notification();
        if (this.f114v == null) {
            this.f114v = Integer.valueOf(0);
        }
        Builder builder = new Builder(context);
        Style bigTextStyle = new BigTextStyle();
        if (this.f110r != null) {
            builder.setSmallIcon(this.f110r.intValue());
        }
        if (this.f112t != null) {
            try {
                builder.setLargeIcon(BitmapFactory.decodeResource(context.getResources(), this.f112t.intValue()));
            } catch (OutOfMemoryError e) {
            }
        }
        if (this.f111s != null) {
            builder.setLargeIcon(this.f111s);
        }
        if (this.f113u == null) {
            this.f113u = getTitle(context);
        } else {
            builder.setContentTitle(this.f113u);
        }
        if (this.f107o == null || this.f95c != null) {
            builder.setContentText(this.f107o);
            builder.setTicker(this.f107o);
        } else {
            bigTextStyle.bigText(this.f107o);
            builder.setStyle(bigTextStyle);
            builder.setContentText(this.f107o);
            builder.setTicker(this.f107o);
        }
        notification = builder.build();
        if (this.f93a != null) {
            notification.audioStreamType = this.f93a.intValue();
        }
        if (this.f94b != null) {
            notification.contentIntent = this.f94b;
        }
        if (this.f95c != null) {
            notification.contentView = this.f95c;
        }
        if (this.f97e != null) {
            notification.defaults = this.f97e.intValue();
        }
        if (this.f100h != null) {
            notification.icon = this.f100h.intValue();
        }
        if (this.f98f != null) {
            notification.deleteIntent = this.f98f;
        }
        if (this.f99g != null) {
            notification.flags = this.f99g.intValue();
        } else {
            notification.flags = 16;
        }
        if (this.f101i != null) {
            notification.iconLevel = this.f101i.intValue();
        }
        if (this.f102j != null) {
            notification.ledARGB = this.f102j.intValue();
        }
        if (this.f103k != null) {
            notification.ledOffMS = this.f103k.intValue();
        }
        if (this.f104l != null) {
            notification.ledOnMS = this.f104l.intValue();
        }
        if (this.f105m != null) {
            notification.number = this.f105m.intValue();
        }
        if (this.f106n != null) {
            notification.sound = this.f106n;
        }
        if (this.f108p != null) {
            notification.vibrate = this.f108p;
        }
        if (this.f109q != null) {
            notification.when = this.f109q.longValue();
        } else {
            notification.when = System.currentTimeMillis();
        }
        return notification;
    }

    public int getAudioStringType() {
        return this.f93a.intValue();
    }

    public XGPushNotificationBuilder setAudioStringType(int i) {
        this.f93a = Integer.valueOf(i);
        return this;
    }

    public PendingIntent getContentIntent() {
        return this.f94b;
    }

    public XGPushNotificationBuilder setContentIntent(PendingIntent pendingIntent) {
        this.f94b = pendingIntent;
        return this;
    }

    public XGPushNotificationBuilder setContentView(RemoteViews remoteViews) {
        this.f95c = remoteViews;
        return this;
    }

    public XGPushNotificationBuilder setbigContentView(RemoteViews remoteViews) {
        this.f96d = remoteViews;
        return this;
    }

    public int getDefaults() {
        return this.f97e.intValue();
    }

    public XGPushNotificationBuilder setDefaults(int i) {
        if (this.f97e == null) {
            this.f97e = Integer.valueOf(i);
        } else {
            this.f97e = Integer.valueOf(this.f97e.intValue() | i);
        }
        return this;
    }

    public int getFlags() {
        return this.f99g.intValue();
    }

    public XGPushNotificationBuilder setFlags(int i) {
        if (this.f99g == null) {
            this.f99g = Integer.valueOf(i);
        } else {
            this.f99g = Integer.valueOf(this.f99g.intValue() | i);
        }
        return this;
    }

    public Integer getIcon() {
        return this.f100h;
    }

    public XGPushNotificationBuilder setIcon(Integer num) {
        this.f100h = num;
        return this;
    }

    public Integer getSmallIcon() {
        return this.f110r;
    }

    public XGPushNotificationBuilder setSmallIcon(Integer num) {
        this.f110r = num;
        return this;
    }

    public Bitmap getLargeIcon() {
        return this.f111s;
    }

    public XGPushNotificationBuilder setLargeIcon(Bitmap bitmap) {
        this.f111s = bitmap;
        return this;
    }

    public XGPushNotificationBuilder setNotificationLargeIcon(int i) {
        this.f112t = Integer.valueOf(i);
        return this;
    }

    public Integer getNotificationLargeIcon() {
        return this.f112t;
    }

    public int getIconLevel() {
        return this.f101i.intValue();
    }

    public XGPushNotificationBuilder setIconLevel(int i) {
        this.f101i = Integer.valueOf(i);
        return this;
    }

    public int getLedARGB() {
        return this.f102j.intValue();
    }

    public XGPushNotificationBuilder setLedARGB(int i) {
        this.f102j = Integer.valueOf(i);
        return this;
    }

    public int getLedOffMS() {
        return this.f103k.intValue();
    }

    public XGPushNotificationBuilder setLedOffMS(int i) {
        this.f103k = Integer.valueOf(i);
        return this;
    }

    public int getLedOnMS() {
        return this.f104l.intValue();
    }

    public XGPushNotificationBuilder setLedOnMS(int i) {
        this.f104l = Integer.valueOf(i);
        return this;
    }

    public int getNumber() {
        return this.f105m.intValue();
    }

    public XGPushNotificationBuilder setNumber(int i) {
        this.f105m = Integer.valueOf(i);
        return this;
    }

    public Uri getSound() {
        return this.f106n;
    }

    public XGPushNotificationBuilder setSound(Uri uri) {
        this.f106n = uri;
        return this;
    }

    public CharSequence getTickerText() {
        return this.f107o;
    }

    public XGPushNotificationBuilder setTickerText(CharSequence charSequence) {
        this.f107o = charSequence;
        return this;
    }

    public long[] getVibrate() {
        return this.f108p;
    }

    public XGPushNotificationBuilder setVibrate(long[] jArr) {
        this.f108p = jArr;
        return this;
    }

    public long getWhen() {
        return this.f109q.longValue();
    }

    public XGPushNotificationBuilder setWhen(long j) {
        this.f109q = Long.valueOf(j);
        return this;
    }
}
