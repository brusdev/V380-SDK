package com.tencent.android.tpush.p007d;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.os.Build.VERSION;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.common.MessageKey;
import com.tencent.android.tpush.encrypt.Rijndael;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.p007d.p008a.C0546a;
import com.tencent.android.tpush.service.p017e.C0631h;
import java.net.URISyntaxException;
import java.util.ArrayList;

/* compiled from: ProGuard */
public class C0547a {
    private static long f252a = 0;
    private static long f253b = 172800000;
    private static C0546a f254c;

    private static C0546a m270d(Context context) {
        if (f254c == null) {
            synchronized (C0547a.class) {
                if (f254c == null) {
                    f254c = new C0546a(context.getApplicationContext());
                }
            }
        }
        return f254c;
    }

    public static boolean m265a(Context context, Intent intent) {
        boolean z = true;
        long longExtra = intent.getLongExtra(MessageKey.MSG_ID, -1);
        ContentValues contentValues = new ContentValues();
        contentValues.put("msgid", Long.valueOf(longExtra));
        contentValues.put("message", Rijndael.encrypt(intent.toUri(1)));
        contentValues.put("time", Long.valueOf(C0631h.m632b(intent)));
        contentValues.put("busiid", Long.valueOf(intent.getLongExtra(MessageKey.MSG_BUSI_MSG_ID, 0)));
        contentValues.put("showedtime", Integer.valueOf(0));
        contentValues.put("status", Integer.valueOf(0));
        SQLiteDatabase writableDatabase = C0547a.m270d(context).getWritableDatabase();
        try {
            if (writableDatabase.insert("messagetoshow", null, contentValues) <= 0) {
                C0503a.m98h("MessageInfoManager", "addCacheMessage Error! ");
                z = false;
            }
            writableDatabase.close();
            return z;
        } catch (Throwable th) {
            return false;
        }
    }

    public static boolean m263a(Context context, long j) {
        C0547a.m272e(context);
        return C0547a.m264a(context, j, 1);
    }

    public static boolean m267b(Context context, long j) {
        C0547a.m272e(context);
        return C0547a.m264a(context, j, 2);
    }

    public static boolean m269c(Context context, long j) {
        return C0547a.m264a(context, j, 3);
    }

    public static boolean m271d(Context context, long j) {
        return C0547a.m264a(context, j, 4);
    }

    private static boolean m264a(Context context, long j, int i) {
        boolean z = false;
        ContentValues contentValues = new ContentValues();
        if (i == 1 || i == 2) {
            contentValues.put("showedtime", Long.valueOf(System.currentTimeMillis()));
        }
        contentValues.put("status", Integer.valueOf(i));
        SQLiteDatabase writableDatabase = C0547a.m270d(context).getWritableDatabase();
        if (((long) writableDatabase.update("messagetoshow", contentValues, "msgid=?", new String[]{j + Constants.MAIN_VERSION_TAG})) <= 0) {
            C0503a.m98h("MessageInfoManager", "updateCacheMessage Error! msgId:" + j + ", status:" + i);
        } else {
            z = true;
        }
        writableDatabase.close();
        return z;
    }

    private static boolean m272e(Context context) {
        boolean z = false;
        long currentTimeMillis = System.currentTimeMillis();
        if (f252a != 0 && currentTimeMillis - f252a <= 86400000) {
            return true;
        }
        f252a = currentTimeMillis;
        currentTimeMillis -= f253b;
        SQLiteDatabase writableDatabase = C0547a.m270d(context).getWritableDatabase();
        if (writableDatabase.delete("messagetoshow", "status >= ? AND showedtime < ? ", new String[]{"1", currentTimeMillis + Constants.MAIN_VERSION_TAG}) <= 0) {
            C0503a.m98h("MessageInfoManager", "delOldShowedCacheMessage Error! toDelTime: " + currentTimeMillis);
        } else {
            z = true;
        }
        writableDatabase.close();
        return z;
    }

    public static boolean m262a(Context context) {
        SQLiteDatabase writableDatabase = C0547a.m270d(context).getWritableDatabase();
        boolean z = true;
        if (writableDatabase.delete("messagetoshow", null, null) <= 0) {
            C0503a.m96f("MessageInfoManager", "delAllCacheMessage but no mssgage in db");
            z = false;
        }
        writableDatabase.close();
        return z;
    }

    public static boolean m273e(Context context, long j) {
        boolean z = false;
        SQLiteDatabase writableDatabase = C0547a.m270d(context).getWritableDatabase();
        if (writableDatabase.delete("messagetoshow", "busiid=?", new String[]{j + Constants.MAIN_VERSION_TAG}) <= 0) {
            C0503a.m98h("MessageInfoManager", "delCacheMessageByBusiId Error! msgid to delete which busiId = : " + j);
        } else {
            z = true;
        }
        writableDatabase.close();
        return z;
    }

    public static boolean m266b(Context context) {
        SQLiteDatabase writableDatabase = C0547a.m270d(context).getWritableDatabase();
        boolean z = true;
        if (writableDatabase.delete("messagetoshow", "msgid < 0", null) <= 0) {
            C0503a.m98h("MessageInfoManager", "deleteAllLocalCacheMsgIntent Error! ");
            z = false;
        }
        writableDatabase.close();
        return z;
    }

    public static ArrayList m268c(Context context) {
        SQLiteDatabase readableDatabase = C0547a.m270d(context).getReadableDatabase();
        SQLiteQueryBuilder sQLiteQueryBuilder = new SQLiteQueryBuilder();
        sQLiteQueryBuilder.setTables("messagetoshow");
        Cursor query = sQLiteQueryBuilder.query(readableDatabase, new String[]{"message"}, "status=0", null, null, null, null);
        ArrayList arrayList = new ArrayList();
        if (query != null) {
            while (query.moveToNext()) {
                try {
                    Intent parseUri = Intent.parseUri(Rijndael.decrypt(query.getString(0)), 1);
                    parseUri.addCategory("android.intent.category.BROWSABLE");
                    parseUri.setComponent(null);
                    if (VERSION.SDK_INT >= 15) {
                        try {
                            parseUri.getClass().getMethod("setSelector", new Class[]{Intent.class}).invoke(parseUri, new Object[]{null});
                        } catch (Throwable e) {
                            C0503a.m86b(Constants.LogTag, "invoke intent.setComponent error.", e);
                        }
                    }
                    arrayList.add(parseUri);
                } catch (URISyntaxException e2) {
                    C0503a.m98h("MessageInfoManager", "getCacheMessages Error: " + e2);
                }
            }
            query.close();
        }
        readableDatabase.close();
        return arrayList;
    }
}
