package com.tencent.android.tpush.common;

import android.content.ContentValues;
import android.content.Context;
import com.tencent.android.tpush.SettingsContentProvider;
import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
public class C0542r {
    Context f243a;
    private ContentValues f244b;

    private C0542r(Context context) {
        this.f244b = new ContentValues();
        this.f243a = context;
    }

    public void m233a() {
        try {
            this.f243a.getContentResolver().insert(SettingsContentProvider.getContentUri(this.f243a, SettingsContentProvider.KEY, "type"), this.f244b);
        } catch (Throwable th) {
            C0503a.m91c("SettingsPreferences", "apply", th);
        }
    }

    public void m235b() {
        m233a();
    }

    public C0542r m232a(String str, String str2) {
        this.f244b.put(str, str2);
        return this;
    }

    public C0542r m231a(String str, long j) {
        this.f244b.put(str, Long.valueOf(j));
        return this;
    }

    public C0542r m230a(String str, int i) {
        this.f244b.put(str, Integer.valueOf(i));
        return this;
    }

    public void m234a(String str) {
        this.f244b.putNull(str);
    }
}
