package com.tencent.android.tpush.common;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;
import com.tencent.android.tpush.XGPushManager;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.service.C0636n;
import java.util.HashMap;
import java.util.Map;

/* compiled from: ProGuard */
public class C0536l {
    private static final String[] f234a = new String[]{"android.permission.INTERNET", "android.permission.ACCESS_WIFI_STATE", "android.permission.ACCESS_NETWORK_STATE"};
    private static Map f235b = new HashMap(8);

    private static Context m209b() {
        return XGPushManager.getContext() != null ? XGPushManager.getContext() : C0636n.m679f();
    }

    public static boolean m207a(String str) {
        Throwable th;
        boolean z;
        try {
            if (f235b.containsKey(str)) {
                return ((Boolean) f235b.get(str)).booleanValue();
            }
            Context b = C0536l.m209b();
            if (b.getPackageManager().checkPermission(str, b.getPackageName()) == 0) {
                z = true;
            } else {
                z = false;
            }
            try {
                f235b.put(str, Boolean.valueOf(z));
                return z;
            } catch (Throwable th2) {
                th = th2;
                Log.e("XgStat", "checkPermission error", th);
                return z;
            }
        } catch (Throwable th3) {
            Throwable th4 = th3;
            z = false;
            th = th4;
            Log.e("XgStat", "checkPermission error", th);
            return z;
        }
    }

    public static boolean m206a() {
        Context b = C0536l.m209b();
        if (b == null) {
            throw new IllegalArgumentException("The context parameter can not be null!");
        }
        try {
            PackageManager packageManager = b.getPackageManager();
            if (packageManager != null) {
                String[] strArr = packageManager.getPackageInfo(b.getPackageName(), 4096).requestedPermissions;
                if (strArr == null) {
                    return false;
                }
                String[] strArr2 = f234a;
                int length = strArr2.length;
                int i = 0;
                while (i < length) {
                    String str = strArr2[i];
                    boolean a = C0536l.m208a(strArr, str);
                    f235b.put(str, Boolean.valueOf(a));
                    if (a) {
                        i++;
                    } else {
                        C0503a.m99i(Constants.LogTag, "The required permission of <" + str + "> does not found!");
                        return false;
                    }
                }
            }
            return true;
        } catch (Throwable e) {
            C0503a.m91c(Constants.LogTag, "check required permissins exception.", e);
            return false;
        }
    }

    private static boolean m208a(String[] strArr, String str) {
        for (Object equals : strArr) {
            if (str.equals(equals)) {
                return true;
            }
        }
        return false;
    }
}
