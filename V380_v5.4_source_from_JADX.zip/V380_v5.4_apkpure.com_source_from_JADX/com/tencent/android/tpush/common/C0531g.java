package com.tencent.android.tpush.common;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import com.tencent.android.tpush.p004a.C0503a;
import java.lang.Thread.State;

/* compiled from: ProGuard */
public class C0531g {
    private static HandlerThread f231a = null;
    private static Handler f232b = null;

    private C0531g() {
    }

    public static C0531g m193a() {
        C0531g.m194c();
        return C0533i.f233a;
    }

    public boolean m196a(Runnable runnable) {
        if (f232b != null) {
            return f232b.post(runnable);
        }
        return false;
    }

    public boolean m198a(Runnable runnable, long j) {
        if (f232b != null) {
            return f232b.postDelayed(runnable, j);
        }
        return false;
    }

    public boolean m197a(Runnable runnable, int i, long j) {
        if (f232b != null) {
            return f232b.postAtTime(runnable, Integer.valueOf(i), SystemClock.uptimeMillis() + j);
        }
        return false;
    }

    public void m195a(int i) {
        if (f232b != null) {
            f232b.removeCallbacksAndMessages(Integer.valueOf(i));
        }
    }

    public Handler m199b() {
        return f232b;
    }

    private static void m194c() {
        try {
            if (f231a == null || !f231a.isAlive() || f231a.isInterrupted() || f231a.getState() == State.TERMINATED) {
                f231a = new HandlerThread("tpush.working.thread");
                f231a.start();
                Looper looper = f231a.getLooper();
                if (looper != null) {
                    f232b = new Handler(looper);
                } else {
                    C0503a.m98h("CommonWorkingThread", ">>> Create new working thread false, cause thread.getLooper()==null");
                }
            }
        } catch (Throwable th) {
        }
    }
}
