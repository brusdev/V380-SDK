package com.tencent.android.tpush.common;

import android.content.Context;
import com.tencent.android.tpush.encrypt.C0551a;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.service.cache.C0591a;

/* compiled from: ProGuard */
public class C0537m {
    private static String m211a(String str) {
        return C0551a.m284a(str);
    }

    public static boolean m213a(Context context, String str, String str2, boolean z) {
        if (z) {
            try {
                String str3 = (String) C0591a.m496a(str);
                if (str3 != null && str2 != null && str3.equals(str2)) {
                    return true;
                }
                C0591a.m497a(str, str2);
            } catch (Throwable e) {
                C0503a.m91c("PushMd5Pref", "putString", e);
                return false;
            }
        }
        C0538n.m222b(context, C0537m.m211a(str), str2);
        return true;
    }

    public static String m210a(Context context, String str, boolean z) {
        if (!z) {
            return C0538n.m218a(context, C0537m.m211a(str), null);
        }
        try {
            String str2 = (String) C0591a.m496a(str);
            if (str2 != null) {
                return str2;
            }
            str2 = C0538n.m218a(context, C0537m.m211a(str), null);
            C0591a.m497a(str, str2);
            return str2;
        } catch (Throwable e) {
            C0503a.m91c("PushMd5Pref", "getString", e);
            return Constants.MAIN_VERSION_TAG;
        }
    }

    public static boolean m212a(Context context, String str, int i) {
        try {
            C0538n.m220b(context, C0537m.m211a(str), i);
            return true;
        } catch (Throwable e) {
            C0503a.m91c("PushMd5Pref", "putInt", e);
            return false;
        }
    }

    public static int m214b(Context context, String str, int i) {
        try {
            return C0538n.m215a(context, C0537m.m211a(str), i);
        } catch (Throwable e) {
            C0503a.m91c("PushMd5Pref", "getInt", e);
            return 0;
        }
    }
}
