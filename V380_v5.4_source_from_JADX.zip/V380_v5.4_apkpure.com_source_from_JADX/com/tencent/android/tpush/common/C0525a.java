package com.tencent.android.tpush.common;

import android.content.Context;
import android.content.IntentFilter;
import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
public class C0525a {
    private static volatile C0528d f228a = null;

    public static void m185a(Context context) {
        try {
            if (f228a == null) {
                synchronized (C0525a.class) {
                    if (f228a == null) {
                        f228a = new C0528d();
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addDataScheme("package");
                        intentFilter.addAction("android.intent.action.PACKAGE_ADDED");
                        intentFilter.addAction("android.intent.action.PACKAGE_REMOVED");
                        intentFilter.addAction("android.intent.action.PACKAGE_REPLACED");
                        context.getApplicationContext().registerReceiver(f228a, intentFilter);
                    }
                }
            }
        } catch (Throwable e) {
            C0503a.m91c(Constants.LogTag, "AppChangesHandler setupHandler error", e);
        }
    }
}
