package com.tencent.android.tpush.common;

import android.content.Context;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.p006c.C0521a;
import org.json.JSONObject;

/* compiled from: ProGuard */
public class C0539o {
    private static C0539o f237a = null;
    private Context f238b = null;
    private String f239c = null;
    private String f240d = null;

    private C0539o(Context context) {
        this.f238b = context.getApplicationContext();
        this.f239c = C0544t.m255f(context);
        this.f240d = String.valueOf(Constants.PUSH_SDK_VERSION);
    }

    public static synchronized C0539o m223a(Context context) {
        C0539o c0539o;
        synchronized (C0539o.class) {
            if (f237a == null) {
                f237a = new C0539o(context);
            }
            c0539o = f237a;
        }
        return c0539o;
    }

    public String m224a() {
        Object obj = null;
        JSONObject jSONObject = new JSONObject();
        try {
            int i;
            C0529e.m190a(jSONObject, "appVer", this.f239c);
            C0529e.m190a(jSONObject, "appSdkVer", this.f240d);
            C0529e.m190a(jSONObject, "ch", XGPushConfig.getInstallChannel(this.f238b));
            C0529e.m190a(jSONObject, "gs", XGPushConfig.getGameServer(this.f238b));
            if (C0543s.m236a(this.f238b).m239c()) {
                String a = C0521a.m171a();
                Object d = C0521a.m180d(this.f238b);
                C0503a.m95e(Constants.OTHER_PUSH_TAG, "Reservert info: other push token is : " + d + "  other push type: " + a);
                if (!(C0544t.m251b(a) || C0544t.m251b((String) d))) {
                    C0529e.m190a(jSONObject, a, d);
                    obj = 1;
                }
            }
            if (obj == null) {
                C0503a.m95e(Constants.OTHER_PUSH_TAG, "Reservert info: use normal xg token register");
                C0529e.m190a(jSONObject, "gcm", Constants.MAIN_VERSION_TAG);
                C0529e.m190a(jSONObject, "miid", Constants.MAIN_VERSION_TAG);
            }
            int a2 = C0538n.m215a(this.f238b, ".firstregister", 1);
            int a3 = C0538n.m215a(this.f238b, ".usertype", 0);
            long a4 = C0538n.m216a(this.f238b, ".installtime", 0);
            long currentTimeMillis = System.currentTimeMillis();
            if (a4 == 0) {
                C0538n.m221b(this.f238b, ".installtime", currentTimeMillis);
                i = a3;
            } else {
                if (a3 == 0 && a2 != 1) {
                    if (!C0544t.m241a(a4).equals(C0544t.m241a(System.currentTimeMillis()))) {
                        C0538n.m220b(this.f238b, ".usertype", 1);
                        currentTimeMillis = a4;
                        i = 1;
                    }
                }
                currentTimeMillis = a4;
                i = a3;
            }
            jSONObject.put("ut", i);
            if (a2 == 1) {
                jSONObject.put("freg", 1);
            }
            jSONObject.put("it", (int) (currentTimeMillis / 1000));
            if (C0544t.m250b(this.f238b)) {
                jSONObject.put("aidl", 1);
            }
        } catch (Throwable e) {
            C0503a.m91c("RegisterReservedInfo", "toSting", e);
        }
        return jSONObject.toString();
    }
}
