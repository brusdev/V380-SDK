package com.tencent.android.tpush.common;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import com.tencent.android.tpush.p006c.C0521a;

/* compiled from: ProGuard */
public class C0543s {
    private static volatile C0543s f245a = null;
    private boolean f246b;
    private boolean f247c;
    private int f248d;

    private C0543s(Context context) {
        this.f246b = false;
        this.f247c = false;
        this.f248d = -1;
        this.f246b = C0534j.m201a();
        this.f247c = C0521a.m173a(context);
    }

    public static C0543s m236a(Context context) {
        if (f245a == null) {
            synchronized (C0543s.class) {
                if (f245a == null) {
                    f245a = new C0543s(context);
                }
            }
        }
        return f245a;
    }

    public boolean m237a() {
        return this.f246b;
    }

    public boolean m238b() {
        if (this.f248d == -1) {
            Object obj = Build.MANUFACTURER;
            if (!TextUtils.isEmpty(obj)) {
                String toLowerCase = obj.trim().toLowerCase();
                if ("meizu".equals(toLowerCase) || "oppo".equals(toLowerCase) || "xiaomi".equals(toLowerCase) || "vivo".equals(toLowerCase) || "huawei".equals(toLowerCase) || this.f246b) {
                    this.f248d = 1;
                } else {
                    this.f248d = 0;
                }
            }
        }
        if (this.f248d == 1) {
            return true;
        }
        return false;
    }

    public boolean m239c() {
        return this.f247c;
    }
}
