package com.tencent.android.tpush.common;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* compiled from: ProGuard */
class C0528d extends BroadcastReceiver {
    private C0528d() {
    }

    public void onReceive(Context context, Intent intent) {
        if (intent != null && context != null) {
            C0531g.m193a().m196a(new C0527c(context, intent));
        }
    }
}
