package com.tencent.android.tpush.common;

import android.content.Context;
import com.tencent.android.tpush.SettingsContentProvider;
import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
public class C0540p {
    public static volatile C0540p f241a = null;
    private Context f242b;

    public static C0540p m225a(Context context) {
        if (f241a == null) {
            synchronized (C0540p.class) {
                if (f241a == null) {
                    f241a = new C0540p(context);
                }
            }
        }
        return f241a;
    }

    private C0540p(Context context) {
        this.f242b = context.getApplicationContext();
    }

    public C0542r m228a() {
        return new C0542r(this.f242b);
    }

    public String m229a(String str, String str2) {
        try {
            return SettingsContentProvider.getStringValue(this.f242b.getContentResolver().query(SettingsContentProvider.getContentUri(this.f242b, str, SettingsContentProvider.STRING_TYPE), null, null, null, null), str2);
        } catch (Throwable th) {
            C0503a.m91c("SettingsPreferences", "error = ", th);
            return Constants.MAIN_VERSION_TAG;
        }
    }

    public long m227a(String str, long j) {
        try {
            return SettingsContentProvider.getLongValue(this.f242b.getContentResolver().query(SettingsContentProvider.getContentUri(this.f242b, str, SettingsContentProvider.LONG_TYPE), null, null, null, null), j);
        } catch (Throwable th) {
            C0503a.m91c("SettingsPreferences", "error = ", th);
            return 0;
        }
    }

    public int m226a(String str, int i) {
        try {
            return SettingsContentProvider.getIntValue(this.f242b.getContentResolver().query(SettingsContentProvider.getContentUri(this.f242b, str, SettingsContentProvider.INT_TYPE), null, null, null, null), i);
        } catch (Throwable th) {
            C0503a.m91c("SettingsPreferences", "error = ", th);
            return 0;
        }
    }
}
