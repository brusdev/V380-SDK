package com.tencent.android.tpush.common;

import android.content.Context;
import com.tencent.android.tpush.service.C0636n;

/* compiled from: ProGuard */
final class C0545u implements Runnable {
    final /* synthetic */ Context f251a;

    C0545u(Context context) {
        this.f251a = context;
    }

    public void run() {
        if (C0544t.m252c(this.f251a) != 1) {
            try {
                C0636n.m668a(this.f251a);
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }
}
