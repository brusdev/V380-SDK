package com.tencent.android.tpush.common;

import android.net.wifi.ScanResult;
import java.util.Comparator;

/* compiled from: ProGuard */
final class C0530f implements Comparator {
    C0530f() {
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m192a((ScanResult) obj, (ScanResult) obj2);
    }

    public int m192a(ScanResult scanResult, ScanResult scanResult2) {
        int abs = Math.abs(scanResult.level);
        int abs2 = Math.abs(scanResult2.level);
        if (abs > abs2) {
            return 1;
        }
        return abs == abs2 ? 0 : -1;
    }
}
