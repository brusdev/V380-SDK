package com.tencent.android.tpush.common;

import java.lang.reflect.Method;

/* compiled from: ProGuard */
public class C0534j {
    public static String m200a(String str) {
        try {
            Class cls = Class.forName("android.os.SystemProperties");
            Method declaredMethod = cls.getDeclaredMethod("get", new Class[]{String.class});
            declaredMethod.setAccessible(true);
            return (String) declaredMethod.invoke(cls, new Object[]{str});
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean m201a() {
        try {
            return (C0544t.m251b(C0534j.m200a("ro.miui.ui.version.code")) && C0544t.m251b(C0534j.m200a(C0534j.m200a("ro.miui.ui.version.name"))) && C0544t.m251b(C0534j.m200a(C0534j.m200a("ro.miui.internal.storage")))) ? false : true;
        } catch (Throwable th) {
            return false;
        }
    }
}
