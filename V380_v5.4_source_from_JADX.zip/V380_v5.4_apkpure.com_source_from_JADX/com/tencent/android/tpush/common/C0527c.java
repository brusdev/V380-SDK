package com.tencent.android.tpush.common;

import android.content.Context;
import android.content.Intent;
import com.tencent.android.tpush.service.XGWatchdog;

/* compiled from: ProGuard */
class C0527c implements Runnable {
    private Context f229a = null;
    private Intent f230b = null;

    public C0527c(Context context, Intent intent) {
        this.f229a = context;
        this.f230b = intent;
    }

    public void run() {
        String action = this.f230b.getAction();
        if (action != null) {
            if ("android.intent.action.PACKAGE_ADDED".equals(action) || "android.intent.action.PACKAGE_REPLACED".equals(action) || "android.intent.action.PACKAGE_REMOVED".equals(action)) {
                XGWatchdog.getInstance(this.f229a).sendAllLocalXGAppList();
            }
        }
    }
}
