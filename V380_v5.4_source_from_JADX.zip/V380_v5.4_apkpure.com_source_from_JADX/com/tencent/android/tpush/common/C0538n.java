package com.tencent.android.tpush.common;

import android.content.Context;

/* compiled from: ProGuard */
public class C0538n {
    private static C0540p f236a = null;

    static synchronized C0540p m217a(Context context) {
        C0540p c0540p;
        synchronized (C0538n.class) {
            if (f236a == null) {
                f236a = C0540p.m225a(context);
            }
            c0540p = f236a;
        }
        return c0540p;
    }

    public static long m216a(Context context, String str, long j) {
        return C0538n.m217a(context).m227a(str, j);
    }

    public static void m221b(Context context, String str, long j) {
        C0542r a = C0538n.m217a(context).m228a();
        a.m231a(str, j);
        a.m235b();
    }

    public static int m215a(Context context, String str, int i) {
        return C0538n.m217a(context).m226a(str, i);
    }

    public static void m220b(Context context, String str, int i) {
        C0542r a = C0538n.m217a(context).m228a();
        a.m230a(str, i);
        a.m235b();
    }

    public static String m218a(Context context, String str, String str2) {
        return C0538n.m217a(context).m229a(str, str2);
    }

    public static void m222b(Context context, String str, String str2) {
        C0542r a = C0538n.m217a(context).m228a();
        a.m232a(str, str2);
        a.m235b();
    }

    public static void m219a(Context context, String str) {
        if (C0538n.m217a(context) != null) {
            C0542r a = C0538n.m217a(context).m228a();
            a.m234a(str);
            a.m235b();
        }
    }
}
