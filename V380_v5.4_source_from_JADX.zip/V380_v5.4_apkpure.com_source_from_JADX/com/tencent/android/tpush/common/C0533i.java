package com.tencent.android.tpush.common;

/* compiled from: ProGuard */
public class C0533i {
    public static C0531g f233a = new C0531g();
}
