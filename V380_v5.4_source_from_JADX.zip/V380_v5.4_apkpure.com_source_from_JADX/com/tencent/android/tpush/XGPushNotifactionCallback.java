package com.tencent.android.tpush;

/* compiled from: ProGuard */
public interface XGPushNotifactionCallback {
    void handleNotify(XGNotifaction xGNotifaction);
}
