package com.tencent.android.tpush;

import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.service.p017e.C0631h;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import org.json.JSONObject;

/* compiled from: ProGuard */
public class XGLocalMessage {
    private static final String f45a = XGLocalMessage.class.getSimpleName();
    private int f46A = 2592000;
    private long f47B = (System.currentTimeMillis() + (((long) this.f46A) * 1000));
    private int f48b = 1;
    private String f49c = Constants.MAIN_VERSION_TAG;
    private String f50d = Constants.MAIN_VERSION_TAG;
    private String f51e = Constants.MAIN_VERSION_TAG;
    private String f52f = "00";
    private String f53g = "00";
    private int f54h = 1;
    private int f55i = 1;
    private int f56j = 1;
    private int f57k = 0;
    private int f58l = 1;
    private String f59m = Constants.MAIN_VERSION_TAG;
    private String f60n = Constants.MAIN_VERSION_TAG;
    private String f61o = Constants.MAIN_VERSION_TAG;
    private int f62p = 1;
    private String f63q = Constants.MAIN_VERSION_TAG;
    private String f64r = Constants.MAIN_VERSION_TAG;
    private String f65s = Constants.MAIN_VERSION_TAG;
    private String f66t = Constants.MAIN_VERSION_TAG;
    private String f67u = Constants.MAIN_VERSION_TAG;
    private String f68v = "{}";
    private long f69w;
    private int f70x = 0;
    private long f71y = (System.currentTimeMillis() * -1);
    private long f72z = 0;

    public long getExpirationTimeMs() {
        return this.f47B;
    }

    public void setExpirationTimeMs(long j) {
        if (j > System.currentTimeMillis()) {
            this.f46A = (int) ((j - System.currentTimeMillis()) / 1000);
            if (this.f46A < 0) {
                this.f46A = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
            }
            this.f47B = j;
        }
    }

    public int getTtl() {
        return this.f46A;
    }

    public int getType() {
        return this.f48b;
    }

    public void setType(int i) {
        this.f48b = i;
    }

    public String getTitle() {
        return this.f49c;
    }

    public void setTitle(String str) {
        this.f49c = str;
    }

    public String getContent() {
        return this.f50d;
    }

    public void setContent(String str) {
        this.f50d = str;
    }

    public void setCustomContent(HashMap hashMap) {
        this.f68v = new JSONObject(hashMap).toString();
    }

    public String getCustom_content() {
        return this.f68v;
    }

    public String getHour() {
        if (this.f52f.length() < 1) {
            return "00";
        }
        if (this.f52f.length() <= 0 || this.f52f.length() >= 2) {
            return this.f52f;
        }
        return "0" + this.f52f;
    }

    public void setHour(String str) {
        this.f52f = str;
    }

    public String getMin() {
        if (this.f53g.length() < 1) {
            return "00";
        }
        if (this.f53g.length() <= 0 || this.f53g.length() >= 2) {
            return this.f53g;
        }
        return "0" + this.f53g;
    }

    public void setMin(String str) {
        this.f53g = str;
    }

    public long getBuilderId() {
        return this.f69w;
    }

    public void setBuilderId(long j) {
        this.f69w = j;
    }

    public String getDate() {
        if (!C0631h.m636b(this.f51e)) {
            try {
                this.f51e = this.f51e.substring(0, 8);
                Long.parseLong(this.f51e);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
                simpleDateFormat.setLenient(false);
                simpleDateFormat.parse(this.f51e);
            } catch (Throwable e) {
                C0503a.m91c(f45a, "XGLocalMessage.getDate()", e);
                return new SimpleDateFormat("yyyyMMdd").format(new Date());
            } catch (Throwable e2) {
                C0503a.m91c(f45a, "XGLocalMessage.getDate()", e2);
                return new SimpleDateFormat("yyyyMMdd").format(new Date());
            }
        }
        return this.f51e;
    }

    public void setDate(String str) {
        this.f51e = str;
    }

    public void setRing(int i) {
        this.f54h = i;
    }

    public int getRing() {
        return this.f54h;
    }

    public void setVibrate(int i) {
        this.f55i = i;
    }

    public int getVibrate() {
        return this.f55i;
    }

    public void setLights(int i) {
        this.f56j = i;
    }

    public int getLights() {
        return this.f56j;
    }

    public void setIcon_type(int i) {
        this.f57k = i;
    }

    public int getIcon_type() {
        return this.f57k;
    }

    public void setStyle_id(int i) {
        this.f58l = i;
    }

    public int getStyle_id() {
        return this.f58l;
    }

    public void setRing_raw(String str) {
        this.f59m = str;
    }

    public String getRing_raw() {
        return this.f59m;
    }

    public void setIcon_res(String str) {
        this.f60n = str;
    }

    public String getIcon_res() {
        return this.f60n;
    }

    public void setSmall_icon(String str) {
        this.f61o = str;
    }

    public String getSmall_icon() {
        return this.f61o;
    }

    public void setAction_type(int i) {
        this.f62p = i;
    }

    public int getAction_type() {
        return this.f62p;
    }

    public void setActivity(String str) {
        this.f63q = str;
    }

    public String getActivity() {
        return this.f63q;
    }

    public void setUrl(String str) {
        this.f64r = str;
    }

    public String getUrl() {
        return this.f64r;
    }

    public void setIntent(String str) {
        this.f65s = str;
    }

    public String getIntent() {
        return this.f65s;
    }

    public void setPackageDownloadUrl(String str) {
        this.f66t = str;
    }

    public String getPackageDownloadUrl() {
        return this.f66t;
    }

    public void setPackageName(String str) {
        this.f67u = str;
    }

    public String getPackageName() {
        return this.f67u;
    }

    public int getNotificationId() {
        return this.f70x;
    }

    public void setNotificationId(int i) {
        this.f70x = i;
    }

    public long getMsgId() {
        return this.f71y;
    }

    public void setMsgId(long j) {
        this.f71y = j;
    }

    public long getBusiMsgId() {
        return this.f72z;
    }

    public void setBusiMsgId(long j) {
        this.f72z = j;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("XGLocalMessage [type=").append(this.f48b).append(", title=").append(this.f49c).append(", content=").append(this.f50d).append(", date=").append(this.f51e).append(", hour=").append(this.f52f).append(", min=").append(this.f53g).append(", builderId=").append(this.f69w).append(", msgid=").append(this.f71y).append(", busiMsgId=").append(this.f72z).append("]");
        return stringBuilder.toString();
    }
}
