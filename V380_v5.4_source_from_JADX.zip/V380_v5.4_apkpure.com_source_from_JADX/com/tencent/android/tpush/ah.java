package com.tencent.android.tpush;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.tencent.android.tpush.common.C0544t;
import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
class ah implements Runnable {
    Context f162a = null;
    Intent f163b = null;
    XGIOperateCallback f164c = null;
    int f165d = 0;

    public ah(Context context, Intent intent, XGIOperateCallback xGIOperateCallback) {
        this.f162a = context;
        this.f163b = intent;
        this.f164c = xGIOperateCallback;
        this.f165d = intent.getIntExtra("opType", 0);
    }

    public void run() {
        try {
            switch (this.f165d) {
                case 0:
                    XGPushManager.m65c(this.f162a, this.f163b, this.f164c);
                    break;
                case 1:
                    XGPushManager.m66d(this.f162a, this.f163b, this.f164c);
                    break;
                default:
                    C0503a.m98h(XGPushManager.f89a, "TimeoutRunnable error optype:" + this.f165d);
                    break;
            }
            for (BroadcastReceiver a : XGPushManager.f92d.keySet()) {
                C0544t.m247a(this.f162a, a);
            }
            XGPushManager.f92d.clear();
        } catch (Throwable e) {
            C0503a.m91c(XGPushManager.f89a, " RegisterTimeoutRunnable run error", e);
        }
    }
}
