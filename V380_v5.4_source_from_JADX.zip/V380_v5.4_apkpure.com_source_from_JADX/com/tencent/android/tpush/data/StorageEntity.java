package com.tencent.android.tpush.data;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.tencent.android.tpush.common.Constants;

/* compiled from: ProGuard */
public class StorageEntity implements Parcelable {
    public static final Creator CREATOR = new C0549a();
    public String f256a = Constants.MAIN_VERSION_TAG;
    public int f257b = -1;
    public boolean f258c;
    public String f259d;
    public int f260e;
    public float f261f;
    public long f262g;

    public StorageEntity(Parcel parcel) {
        m280a(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f256a);
        parcel.writeInt(this.f257b);
        parcel.writeByte(this.f258c ? (byte) 1 : (byte) 0);
        parcel.writeString(this.f259d);
        parcel.writeInt(this.f260e);
        parcel.writeFloat(this.f261f);
        parcel.writeLong(this.f262g);
    }

    private void m280a(Parcel parcel) {
        boolean z = true;
        this.f256a = parcel.readString();
        this.f257b = parcel.readInt();
        if (parcel.readByte() != (byte) 1) {
            z = false;
        }
        this.f258c = z;
        this.f259d = parcel.readString();
        this.f260e = parcel.readInt();
        this.f261f = parcel.readFloat();
        this.f262g = parcel.readLong();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("StorageEntity[key:").append(this.f256a).append(",type:").append(this.f257b).append(",strValue:").append(this.f259d).append(",boolValue:").append(this.f258c).append(",intValue").append(this.f260e).append(",floatValue:").append(this.f261f).append(",longValue:").append(this.f262g).append("]");
        return stringBuilder.toString();
    }
}
