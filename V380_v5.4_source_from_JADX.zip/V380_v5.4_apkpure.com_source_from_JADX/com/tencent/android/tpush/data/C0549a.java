package com.tencent.android.tpush.data;

import android.os.Parcel;
import android.os.Parcelable.Creator;

/* compiled from: ProGuard */
final class C0549a implements Creator {
    C0549a() {
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m281a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m282a(i);
    }

    public StorageEntity m281a(Parcel parcel) {
        return new StorageEntity(parcel);
    }

    public StorageEntity[] m282a(int i) {
        return new StorageEntity[i];
    }
}
