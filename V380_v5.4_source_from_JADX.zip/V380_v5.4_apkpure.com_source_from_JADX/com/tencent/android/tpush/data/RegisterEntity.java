package com.tencent.android.tpush.data;

import com.tencent.android.tpush.common.C0535k;
import com.tencent.android.tpush.common.Constants;
import java.io.Serializable;

/* compiled from: ProGuard */
public class RegisterEntity implements Serializable {
    public static final byte TYPE_REGISTER = (byte) 0;
    public static final byte TYPE_REMOTE_UNINSTALL = (byte) 4;
    public static final byte TYPE_REMOTE_UNREGISTER = (byte) 3;
    public static final byte TYPE_UNINSTALL = (byte) 2;
    public static final byte TYPE_UNREGISTER = (byte) 1;
    private static final long serialVersionUID = -7991157757568940717L;
    public long accessId;
    public String accessKey;
    public String appVersion;
    public String packageName;
    public int state;
    public long timestamp;
    public String token;
    public float xgSDKVersion = Constants.PUSH_SDK_VERSION;

    public static String m276a(RegisterEntity registerEntity) {
        try {
            return C0535k.m203a((Serializable) registerEntity);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static RegisterEntity m275a(String str) {
        try {
            return (RegisterEntity) C0535k.m202a(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean m277a() {
        return this.state == 0;
    }

    public boolean m278b() {
        return this.state == 1;
    }

    public boolean m279c() {
        return this.state == 2;
    }

    public String toString() {
        return "RegisterEntity [accessId=" + this.accessId + ", accessKey=" + this.accessKey + ", token=" + this.token + ", packageName=" + this.packageName + ", state=" + this.state + ", timestamp=" + this.timestamp + ", xgSDKVersion=" + this.xgSDKVersion + ", appVersion=" + this.appVersion + "]";
    }
}
