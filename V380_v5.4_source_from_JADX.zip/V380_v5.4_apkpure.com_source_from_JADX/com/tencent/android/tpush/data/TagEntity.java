package com.tencent.android.tpush.data;

import com.tencent.android.tpush.common.Constants;
import java.io.Serializable;

/* compiled from: ProGuard */
public class TagEntity implements Serializable {
    private static final long serialVersionUID = 1450594384664278962L;
    public long accessId = 0;
    public int flag = 0;
    public String tag = Constants.MAIN_VERSION_TAG;
}
