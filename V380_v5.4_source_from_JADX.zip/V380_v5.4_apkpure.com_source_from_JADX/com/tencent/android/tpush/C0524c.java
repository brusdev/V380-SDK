package com.tencent.android.tpush;

import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
class C0524c implements Runnable {
    Message f224a = this.f225b.f44j.obtainMessage();
    final /* synthetic */ XGDownloadService f225b;
    private Intent f226c;
    private int f227d;

    public C0524c(XGDownloadService xGDownloadService, Intent intent, int i) {
        this.f225b = xGDownloadService;
        this.f226c = intent;
        this.f227d = i;
    }

    public void run() {
        this.f224a.what = 0;
        this.f224a.arg1 = this.f227d;
        Bundle bundle = new Bundle();
        this.f224a.setData(this.f226c.getExtras());
        try {
            if (!this.f225b.f38d.exists()) {
                this.f225b.f38d.mkdirs();
            }
            if (!this.f225b.f39e.exists()) {
                this.f225b.f39e.createNewFile();
            }
            if (this.f225b.m42a(this.f225b.f37b, this.f225b.f39e, this.f227d) > 0) {
                this.f225b.f44j.sendMessage(this.f224a);
            }
        } catch (Throwable e) {
            C0503a.m91c(XGDownloadService.f35c, "downloadRunnable", e);
            this.f225b.f44j.sendMessage(this.f224a);
        }
    }
}
