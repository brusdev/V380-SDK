package com.tencent.android.tpush;

import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
final class C0847e implements XGIOperateCallback {
    C0847e() {
    }

    public void onSuccess(Object obj, int i) {
        C0503a.m93d(Constants.MSDK_TAG, "xg register push onSuccess. token:" + obj);
    }

    public void onFail(Object obj, int i, String str) {
        C0503a.m98h(Constants.MSDK_TAG, "xg register push onFail. token:" + obj + ", errCode:" + i + ",msg:" + str);
    }
}
