package com.tencent.android.tpush;

import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
final class C0890u implements XGIOperateCallback {
    C0890u() {
    }

    public void onSuccess(Object obj, int i) {
        C0503a.m95e(XGPushManager.f89a, "XG register push success with token : " + obj);
    }

    public void onFail(Object obj, int i, String str) {
        C0503a.m99i(XGPushManager.f89a, "XG register push failed with token : " + obj + ", errCode : " + i + " , msg : " + str);
    }
}
