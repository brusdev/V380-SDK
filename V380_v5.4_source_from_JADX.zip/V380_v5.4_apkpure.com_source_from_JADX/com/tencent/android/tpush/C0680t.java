package com.tencent.android.tpush;

import android.content.Context;
import android.content.Intent;
import com.jg.EType;
import com.jg.JgMethodChecked;
import com.tencent.android.tpush.common.C0538n;
import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
final class C0680t implements Runnable {
    final /* synthetic */ boolean f712a;
    final /* synthetic */ Context f713b;

    C0680t(boolean z, Context context) {
        this.f712a = z;
        this.f713b = context;
    }

    @JgMethodChecked(author = 1, fComment = "确认已进行安全校验", lastDate = "20150316", reviewer = 3, vComment = {EType.RECEIVERCHECK, EType.INTENTCHECK})
    public void run() {
        if (this.f712a) {
            C0503a.m74a(2);
        } else {
            C0503a.m74a(3);
        }
        C0538n.m220b(this.f713b, "com.tencent.android.tpush.debug," + this.f713b.getPackageName(), this.f712a ? 1 : 0);
        Intent intent = new Intent("com.tencent.android.tpush.action.ENABLE_DEBUG.V3");
        intent.putExtra("debugMode", this.f712a);
        this.f713b.sendBroadcast(intent);
    }
}
