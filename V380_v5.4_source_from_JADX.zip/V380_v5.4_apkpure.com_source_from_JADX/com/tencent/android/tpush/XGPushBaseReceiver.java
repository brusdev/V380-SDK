package com.tencent.android.tpush;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.tencent.android.tpush.common.C0544t;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.encrypt.Rijndael;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.p005b.C0519n;
import com.tencent.android.tpush.service.p016d.C0622a;
import com.tencent.android.tpush.service.p017e.C0630g;
import com.tencent.android.tpush.service.p017e.C0631h;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: ProGuard */
public abstract class XGPushBaseReceiver extends BroadcastReceiver {
    public static final int SUCCESS = 0;
    long f83a = 0;

    public abstract void onDeleteTagResult(Context context, int i, String str);

    public abstract void onNotifactionClickedResult(Context context, XGPushClickedResult xGPushClickedResult);

    public abstract void onNotifactionShowedResult(Context context, XGPushShowedResult xGPushShowedResult);

    public abstract void onRegisterResult(Context context, int i, XGPushRegisterResult xGPushRegisterResult);

    public abstract void onSetTagResult(Context context, int i, String str);

    public abstract void onTextMessage(Context context, XGPushTextMessage xGPushTextMessage);

    public abstract void onUnregisterResult(Context context, int i);

    public final void onReceive(Context context, Intent intent) {
        if (context != null && intent != null) {
            try {
                if (C0544t.m240a(context) <= 0) {
                    String action = intent.getAction();
                    if (Constants.ACTION_PUSH_MESSAGE.equals(action)) {
                        m47a(context, intent);
                    } else if (Constants.ACTION_FEEDBACK.equals(action)) {
                        m48b(context, intent);
                    } else {
                        C0503a.m98h(Constants.PushMessageLogTag, "未知的action:" + action);
                    }
                }
            } catch (Throwable th) {
                C0503a.m91c(Constants.PushMessageLogTag, "onReceive handle error.", th);
            }
        }
    }

    private void m47a(Context context, Intent intent) {
        C0519n a = C0519n.m163a(context, intent);
        if (a.m170g().mo1672c() == 2) {
            XGPushTextMessage xGPushTextMessage = new XGPushTextMessage();
            xGPushTextMessage.title = a.m170g().m117e();
            xGPushTextMessage.content = a.m170g().m118f();
            xGPushTextMessage.customContent = a.m170g().m119g();
            xGPushTextMessage.m72a(intent);
            onTextMessage(context, xGPushTextMessage);
        }
    }

    private void m48b(Context context, Intent intent) {
        int intExtra = intent.getIntExtra(Constants.FEEDBACK_TAG, -1);
        int intExtra2 = intent.getIntExtra(Constants.FEEDBACK_ERROR_CODE, -1);
        XGPushRegisterResult xGPushRegisterResult;
        switch (intExtra) {
            case 1:
                xGPushRegisterResult = new XGPushRegisterResult();
                xGPushRegisterResult.parseIntent(intent);
                m46a(context, intExtra2, xGPushRegisterResult, "SdkRegister");
                onRegisterResult(context, intExtra2, xGPushRegisterResult);
                return;
            case 2:
                xGPushRegisterResult = new XGPushRegisterResult();
                xGPushRegisterResult.parseIntent(intent);
                m46a(context, intExtra2, xGPushRegisterResult, "SdkUnRegister");
                onUnregisterResult(context, intExtra2);
                return;
            case 3:
                String decrypt = Rijndael.decrypt(intent.getStringExtra(Constants.FLAG_TAG_NAME));
                if (!C0631h.m636b(decrypt)) {
                    int intExtra3 = intent.getIntExtra(Constants.FLAG_TAG_TYPE, -1);
                    if (intExtra3 == 1) {
                        onSetTagResult(context, intExtra2, decrypt);
                        return;
                    } else if (intExtra3 == 2) {
                        onDeleteTagResult(context, intExtra2, decrypt);
                        return;
                    } else {
                        C0503a.m98h(Constants.PushMessageLogTag, "错误的标签处理类型：" + intExtra3 + " ,标签名：" + decrypt);
                        return;
                    }
                }
                return;
            case 4:
                intent.getIntExtra("action", 2);
                long longExtra = intent.getLongExtra("accId", 0);
                List accessidList = XGPushConfig.getAccessidList(context);
                if (accessidList != null && accessidList.size() > 0 && accessidList.contains(Long.valueOf(longExtra))) {
                    XGPushClickedResult xGPushClickedResult = new XGPushClickedResult();
                    xGPushClickedResult.parseIntent(intent);
                    onNotifactionClickedResult(context, xGPushClickedResult);
                    return;
                }
                return;
            case 5:
                XGPushShowedResult xGPushShowedResult = new XGPushShowedResult();
                xGPushShowedResult.parseIntent(intent);
                onNotifactionShowedResult(context, xGPushShowedResult);
                return;
            default:
                C0503a.m98h(Constants.PushMessageLogTag, "未知的feedbackType:" + intExtra);
                return;
        }
    }

    private void m46a(Context context, int i, XGPushRegisterResult xGPushRegisterResult, String str) {
        JSONObject jSONObject;
        int optInt;
        int optInt2;
        int i2;
        int i3;
        JSONObject toJson;
        JSONArray optJSONArray;
        long currentTimeMillis;
        JSONObject jSONObject2 = new JSONObject();
        String a = C0630g.m618a(context, "register_json", Constants.MAIN_VERSION_TAG);
        if (!C0631h.m636b(a)) {
            try {
                jSONObject = new JSONObject(a);
            } catch (Throwable th) {
                C0503a.m98h(Constants.PushMessageLogTag, "JSONObject" + th);
            }
            optInt = jSONObject.optInt("suc_cnt", 0);
            optInt2 = jSONObject.optInt("failed_cnt", 0);
            if (i != 0) {
                i2 = optInt2;
                i3 = optInt + 1;
            } else {
                i2 = optInt2 + 1;
                i3 = optInt;
            }
            jSONObject.put("suc_cnt", i3);
            jSONObject.put("failed_cnt", i2);
            jSONObject2 = new JSONObject();
            if (xGPushRegisterResult == null) {
                toJson = xGPushRegisterResult.toJson();
            } else {
                toJson = jSONObject2;
            }
            toJson.put("errorCode", i);
            toJson.put("np", C0631h.m650g(context));
            optJSONArray = jSONObject.optJSONArray("details");
            if (optJSONArray == null) {
                optJSONArray = new JSONArray();
            }
            optJSONArray.put(toJson);
            jSONObject.put("details", optJSONArray);
            C0503a.m93d("SdkStat", "new reprot js" + jSONObject.toString());
            currentTimeMillis = System.currentTimeMillis();
            if (this.f83a == 0) {
                this.f83a = C0630g.m616a(context, "register_last_report", 0);
                if (this.f83a == 0) {
                    this.f83a = currentTimeMillis;
                    C0630g.m620b(context, "register_last_report", this.f83a);
                }
            }
            if (i3 + i2 < 10 || currentTimeMillis - this.f83a >= 43200000) {
                C0622a.m584a(context, str, jSONObject);
                C0630g.m621b(context, "register_json", Constants.MAIN_VERSION_TAG);
                this.f83a = currentTimeMillis;
                C0630g.m620b(context, "register_last_report", this.f83a);
            }
            C0630g.m621b(context, "register_json", jSONObject.toString());
            return;
        }
        jSONObject = jSONObject2;
        optInt = jSONObject.optInt("suc_cnt", 0);
        optInt2 = jSONObject.optInt("failed_cnt", 0);
        if (i != 0) {
            i2 = optInt2 + 1;
            i3 = optInt;
        } else {
            i2 = optInt2;
            i3 = optInt + 1;
        }
        try {
            jSONObject.put("suc_cnt", i3);
            jSONObject.put("failed_cnt", i2);
        } catch (JSONException e) {
        }
        jSONObject2 = new JSONObject();
        if (xGPushRegisterResult == null) {
            toJson = jSONObject2;
        } else {
            toJson = xGPushRegisterResult.toJson();
        }
        try {
            toJson.put("errorCode", i);
            toJson.put("np", C0631h.m650g(context));
        } catch (Exception e2) {
        }
        try {
            optJSONArray = jSONObject.optJSONArray("details");
            if (optJSONArray == null) {
                optJSONArray = new JSONArray();
            }
            optJSONArray.put(toJson);
            jSONObject.put("details", optJSONArray);
        } catch (Exception e3) {
        }
        C0503a.m93d("SdkStat", "new reprot js" + jSONObject.toString());
        currentTimeMillis = System.currentTimeMillis();
        if (this.f83a == 0) {
            this.f83a = C0630g.m616a(context, "register_last_report", 0);
            if (this.f83a == 0) {
                this.f83a = currentTimeMillis;
                C0630g.m620b(context, "register_last_report", this.f83a);
            }
        }
        if (i3 + i2 < 10) {
        }
        C0622a.m584a(context, str, jSONObject);
        C0630g.m621b(context, "register_json", Constants.MAIN_VERSION_TAG);
        this.f83a = currentTimeMillis;
        C0630g.m620b(context, "register_last_report", this.f83a);
    }
}
