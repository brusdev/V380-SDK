package com.tencent.android.tpush;

import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.p004a.C0503a;

/* compiled from: ProGuard */
final class C0848f implements XGIOperateCallback {
    C0848f() {
    }

    public void onSuccess(Object obj, int i) {
        C0503a.m93d(Constants.MSDK_TAG, "xg unregisterPush push onSuccess. flag:" + i);
    }

    public void onFail(Object obj, int i, String str) {
        C0503a.m98h(Constants.MSDK_TAG, "xg unregisterPush push onFail. token:" + obj + ", errCode:" + i + ",msg:" + str);
    }
}
