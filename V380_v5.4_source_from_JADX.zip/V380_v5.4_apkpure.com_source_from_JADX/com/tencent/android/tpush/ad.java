package com.tencent.android.tpush;

import android.content.Context;
import android.content.Intent;
import com.tencent.android.tpush.common.C0539o;
import com.tencent.android.tpush.common.C0543s;
import com.tencent.android.tpush.common.C0544t;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.encrypt.Rijndael;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.p006c.C0521a;
import com.tencent.android.tpush.service.C0636n;

/* compiled from: ProGuard */
final class ad implements Runnable {
    final /* synthetic */ Context f144a;
    final /* synthetic */ XGIOperateCallback f145b;
    final /* synthetic */ long f146c;
    final /* synthetic */ String f147d;
    final /* synthetic */ String f148e;
    final /* synthetic */ String f149f;
    final /* synthetic */ String f150g;
    final /* synthetic */ int f151h;

    ad(Context context, XGIOperateCallback xGIOperateCallback, long j, String str, String str2, String str3, String str4, int i) {
        this.f144a = context;
        this.f145b = xGIOperateCallback;
        this.f146c = j;
        this.f147d = str;
        this.f148e = str2;
        this.f149f = str3;
        this.f150g = str4;
        this.f151h = i;
    }

    public void run() {
        try {
            int a = C0544t.m240a(this.f144a);
            if (a == 0) {
                long accessId = this.f146c > 0 ? this.f146c : XGPushConfig.getAccessId(this.f144a);
                String accessKey = C0544t.m251b(this.f147d) ? XGPushConfig.getAccessKey(this.f144a) : this.f147d;
                if (accessId <= 0 || C0544t.m251b(accessKey)) {
                    this.f145b.onFail(null, 10001, "The accessId or accessKey is(are) invalid!@accessId:" + accessId + ", @accessKey:" + accessKey);
                    return;
                }
                if (C0543s.m236a(this.f144a).m239c()) {
                    C0521a.m175b(this.f144a);
                    long currentTimeMillis = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTimeMillis < 30000) {
                        try {
                            String d = C0521a.m180d(this.f144a);
                            if (!C0544t.m251b(d)) {
                                C0503a.m93d(Constants.OTHER_PUSH_TAG, "get otherToken is : " + d);
                                break;
                            }
                            Thread.sleep(200);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } catch (Exception e2) {
                            C0503a.m98h(Constants.OTHER_PUSH_TAG, "OtherPush: call getToken Error!.");
                        }
                    }
                }
                C0544t.m256g(this.f144a);
                Intent intent = new Intent("com.tencent.android.tpush.action.REGISTER.V3");
                intent.putExtra("accId", Rijndael.encrypt(Constants.MAIN_VERSION_TAG + accessId));
                intent.putExtra("accKey", Rijndael.encrypt(accessKey));
                intent.putExtra(Constants.FLAG_PACK_NAME, Rijndael.encrypt(this.f144a.getPackageName()));
                intent.putExtra("appVer", C0544t.m255f(this.f144a));
                if (C0539o.m223a(this.f144a) != null) {
                    intent.putExtra("reserved", Rijndael.encrypt(C0539o.m223a(this.f144a).m224a()));
                }
                if (this.f148e != null) {
                    intent.putExtra(Constants.FLAG_ACCOUNT, Rijndael.encrypt(this.f148e));
                }
                if (this.f149f != null) {
                    intent.putExtra(Constants.FLAG_TICKET, Rijndael.encrypt(this.f149f));
                }
                if (this.f150g != null) {
                    intent.putExtra("qua", Rijndael.encrypt(this.f150g));
                }
                intent.putExtra(Constants.FLAG_TICKET_TYPE, this.f151h);
                intent.putExtra("operation", 100);
                intent.putExtra("aidl", C0544t.m250b(this.f144a));
                intent.putExtra("currentTimeMillis", System.currentTimeMillis());
                intent.putExtra("opType", 0);
                boolean a2 = C0543s.m236a(this.f144a).m237a();
                if (C0544t.m252c(this.f144a) != 1 || a2) {
                    XGPushManager.m56a(this.f144a, intent, this.f145b, a2);
                    return;
                }
                XGPushManager.m65c(this.f144a, intent, this.f145b);
                C0636n.m673b(this.f144a);
            } else if (this.f145b != null) {
                this.f145b.onFail(null, a, Constants.errCodeToMsg(a));
            }
        } catch (Throwable th) {
            C0503a.m91c(XGPushManager.f89a, "register", th);
        }
    }
}
