package com.tencent.android.tpush;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ProviderInfo;
import android.net.Uri;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.data.RegisterEntity;
import com.tencent.android.tpush.encrypt.Rijndael;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.stat.p018a.C0649e;
import com.tencent.android.tpush.stat.p019b.C0656c;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

/* compiled from: ProGuard */
public class C0506a {
    private static Map f140a = new HashMap();

    public static Map m102a(Context context) {
        Map hashMap = new HashMap();
        try {
            for (ProviderInfo providerInfo : context.getPackageManager().queryContentProviders(null, 0, 0)) {
                if (providerInfo.name.equals(XGPushProvider.class.getName()) && providerInfo.authority.equals(C0506a.m101a(providerInfo.packageName))) {
                    hashMap.put(providerInfo.packageName, providerInfo);
                    C0503a.m90c(Constants.LogTag, providerInfo.authority + "," + providerInfo.packageName + "," + providerInfo.name);
                }
            }
            return hashMap;
        } catch (Throwable th) {
            RuntimeException runtimeException = new RuntimeException("Package manager has died", th);
        }
    }

    public static String m101a(String str) {
        return str + XGPushProvider.AUTH_PRIX;
    }

    public static void m104a(Context context, String str, String str2) {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put(SettingsContentProvider.KEY, str2);
            context.getContentResolver().insert(Uri.parse("content://" + str + XGPushProvider.AUTH_PRIX + "/" + "msg"), contentValues);
        } catch (Throwable th) {
        }
    }

    public static void m107b(Context context, String str, String str2) {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("mid", str2);
            context.getContentResolver().insert(Uri.parse("content://" + str + XGPushProvider.AUTH_PRIX + "/" + "insert_mid_new"), contentValues);
        } catch (Throwable th) {
        }
    }

    public static void m109c(Context context, String str, String str2) {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("mid", str2);
            context.getContentResolver().insert(Uri.parse("content://" + str + XGPushProvider.AUTH_PRIX + "/" + "insert_mid_old"), contentValues);
        } catch (Throwable th) {
        }
    }

    public static void m103a(Context context, String str, Intent intent) {
        C0506a.m104a(context, str, intent.toURI());
    }

    public static void m111d(Context context, String str, String str2) {
        Uri parse = Uri.parse("content://" + str + XGPushProvider.AUTH_PRIX + "/" + "feedback");
        ContentValues contentValues = new ContentValues();
        contentValues.put("feedback", Rijndael.encrypt(str2));
        try {
            context.getContentResolver().update(parse, contentValues, null, null);
        } catch (Throwable th) {
            C0503a.m91c("SettingsContentProvider", "error : ", th);
        }
    }

    public static void m106b(Context context) {
        Map a = C0506a.m102a(context);
        if (a != null && a.size() != 0) {
            for (String str : a.keySet()) {
                C0503a.m93d(Constants.LogTag, "heartbeat to " + str);
                String decrypt = Rijndael.decrypt(context.getContentResolver().getType(Uri.parse("content://" + str + XGPushProvider.AUTH_PRIX + "/" + "heart")));
                try {
                    C0503a.m93d(Constants.LogTag, "heartbeat " + str + " " + decrypt);
                    if (C0649e.m743b(decrypt)) {
                        new JSONObject(decrypt).optInt("cnt", 0);
                        f140a.put(str, decrypt);
                    }
                } catch (Throwable th) {
                    th.printStackTrace();
                }
            }
        }
    }

    public static String m100a(Context context, String str) {
        String decrypt = Rijndael.decrypt(context.getContentResolver().getType(Uri.parse("content://" + str + XGPushProvider.AUTH_PRIX + "/" + Constants.FLAG_TOKEN)));
        C0503a.m93d(Constants.LogTag, "get token from pkg:" + str + ", token:" + decrypt);
        return (decrypt == null || decrypt.trim().length() != 40) ? null : decrypt;
    }

    public static Map m108c(Context context) {
        Map a = C0506a.m102a(context);
        Map hashMap = new HashMap();
        if (a == null || a.size() == 0) {
            return hashMap;
        }
        for (String a2 : a.keySet()) {
            String a3 = C0506a.m100a(context, a2);
            if (C0656c.m808a(a3)) {
                Integer num = (Integer) hashMap.get(a3);
                if (num == null) {
                    hashMap.put(a3, Integer.valueOf(1));
                } else {
                    hashMap.put(a3, Integer.valueOf(num.intValue() + 1));
                }
            }
        }
        return hashMap;
    }

    public static String m110d(Context context) {
        String str = null;
        Map c = C0506a.m108c(context);
        if (c != null && c.size() > 0) {
            int i = 0;
            for (Entry entry : c.entrySet()) {
                int intValue;
                String str2;
                if (((Integer) entry.getValue()).intValue() > i) {
                    intValue = ((Integer) entry.getValue()).intValue();
                    str2 = (String) entry.getKey();
                } else {
                    str2 = str;
                    intValue = i;
                }
                str = str2;
                i = intValue;
            }
        }
        return str;
    }

    public static RegisterEntity m105b(Context context, String str) {
        String decrypt = Rijndael.decrypt(context.getContentResolver().getType(Uri.parse("content://" + str + XGPushProvider.AUTH_PRIX + "/" + "register")));
        if (decrypt != null) {
            return RegisterEntity.m275a(decrypt);
        }
        return null;
    }

    public static Map m112e(Context context) {
        Map a = C0506a.m102a(context);
        Map concurrentHashMap = new ConcurrentHashMap();
        if (a == null || a.size() == 0) {
            return concurrentHashMap;
        }
        for (String b : a.keySet()) {
            RegisterEntity b2 = C0506a.m105b(context, b);
            if (b2 != null && b2.accessId > 0) {
                concurrentHashMap.put(Long.valueOf(b2.accessId), b2);
            }
        }
        return concurrentHashMap;
    }
}
