package com.tencent.android.tpush;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.view.MotionEventCompat;
import android.text.TextUtils;
import android.util.Log;
import com.jg.EType;
import com.jg.JgClassChecked;
import com.tencent.android.tpush.common.C0531g;
import com.tencent.android.tpush.common.C0537m;
import com.tencent.android.tpush.common.C0538n;
import com.tencent.android.tpush.common.C0544t;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.common.MessageKey;
import com.tencent.android.tpush.encrypt.C0551a;
import com.tencent.android.tpush.encrypt.Rijndael;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.p005b.C0508b;
import com.tencent.android.tpush.p005b.C0510d;
import com.tencent.android.tpush.p005b.C0514i;
import com.tencent.android.tpush.p005b.C0519n;
import com.tencent.android.tpush.service.C0641s;
import com.tencent.android.tpush.service.XGPushServiceV3;
import com.tencent.android.tpush.service.channel.C0594a;
import com.tencent.android.tpush.service.channel.protocol.TpnsPushMsg;
import com.tencent.android.tpush.service.channel.security.TpnsSecurity;
import com.tencent.android.tpush.service.p016d.C0622a;
import com.tencent.android.tpush.service.p017e.C0631h;
import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

@JgClassChecked(author = 1, fComment = "确认已进行安全校验", lastDate = "20150316", reviewer = 3, vComment = {EType.RECEIVERCHECK, EType.INTENTCHECK})
/* compiled from: ProGuard */
public class XGPushManager {
    public static final String ENABLE_SERVICE_SUFFIX = ".enableService";
    public static final int OPERATION_FAIL = 1;
    public static final int OPERATION_REQ_REGISTER = 100;
    public static final int OPERATION_REQ_UNREGISTER = 101;
    public static final int OPERATION_SUCCESS = 0;
    private static final String f89a = XGPushManager.class.getSimpleName();
    private static Context f90b = null;
    private static XGPushNotifactionCallback f91c = null;
    private static Map f92d = new ConcurrentHashMap();
    public static int enableService = -1;

    private XGPushManager() {
    }

    public static Context getContext() {
        return f90b;
    }

    public static void setContext(Context context) {
        if (f90b == null && context != null) {
            f90b = context.getApplicationContext();
        }
    }

    public static void startPushService(Context context) {
        if (context != null) {
            setContext(context);
            if (XGPushConfig.enableDebug) {
                C0503a.m95e(f89a, context.getPackageName() + "call start Push Service");
            }
            C0544t.m256g(context);
            if (C0544t.m252c(context) == 0) {
                C0544t.m254e(context);
            }
        }
    }

    static void m53a(Context context) {
        if (context != null) {
            if (XGPushConfig.enableDebug) {
                C0503a.m95e(f89a, context.getPackageName() + " call stop Push Service");
            }
            Intent intent = new Intent();
            intent.setClass(context.getApplicationContext(), XGPushServiceV3.class);
            context.stopService(intent);
        }
    }

    public static int getServiceStatus(Context context) {
        if (context != null) {
            return C0544t.m252c(context);
        }
        return 0;
    }

    public static void registerPush(Context context) {
        registerPush(context, new C0890u());
    }

    public static void registerPush(Context context, XGIOperateCallback xGIOperateCallback) {
        if (xGIOperateCallback == null) {
            throw new IllegalArgumentException("The callback parameter can not be null!");
        }
        m60a(context, null, null, -1, null, xGIOperateCallback, -1, null);
    }

    public static void registerPush(Context context, String str, XGIOperateCallback xGIOperateCallback) {
        if (xGIOperateCallback == null) {
            throw new IllegalArgumentException("The callback parameter can not be null!");
        }
        registerPush(context, str, "0", 0, null, xGIOperateCallback);
    }

    public static void registerPush(Context context, String str) {
        if (context == null || str == null) {
            C0503a.m99i(Constants.LogTag, "the parameter context or account of registerPush is invalid.");
        } else {
            registerPush(context, str, new C0891x());
        }
    }

    public static void registerPush(Context context, String str, String str2, int i, String str3, XGIOperateCallback xGIOperateCallback) {
        if (xGIOperateCallback == null) {
            throw new IllegalArgumentException("The callback parameter can not be null!");
        } else if (context == null || C0544t.m251b(str) || C0544t.m251b(str2) || i < 0) {
            xGIOperateCallback.onFail(null, 10001, "The context, account, ticket or ticketType is(are) invalid!");
        } else {
            m60a(context, str, str2, i, str3, xGIOperateCallback, -1, null);
        }
    }

    public static void unregisterPush(Context context) {
        if (context == null) {
            C0503a.m98h(Constants.LogTag, "the context of unregisterPush is null");
        } else {
            unregisterPush(context, new C0892y());
        }
    }

    public static void unregisterPush(Context context, XGIOperateCallback xGIOperateCallback) {
        m58a(context, xGIOperateCallback, XGPushConfig.getAccessId(context), XGPushConfig.getAccessKey(context));
    }

    static void m58a(Context context, XGIOperateCallback xGIOperateCallback, long j, String str) {
        if (context == null) {
            setContext(context);
            if (xGIOperateCallback != null) {
                xGIOperateCallback.onFail(null, 10001, "The context parameter can not be null!");
                return;
            }
            throw new IllegalArgumentException("The context parameter can not be null!");
        }
        C0531g.m193a().m196a(new C0683z(context.getApplicationContext(), xGIOperateCallback, j, str));
    }

    public static void setTag(Context context, String str) {
        if (XGPushConfig.enableDebug) {
            C0503a.m95e(f89a, "Action -> setTag with tag = " + str);
        }
        m59a(context, str, 1, -1);
    }

    public static void setKeyValueTag(Context context, String str, String str2) {
        if (context == null || str == null || str.trim().length() == 0 || str2 == null || str2.trim().length() == 0) {
            C0503a.m99i(f89a, "setKeyValueTag context or tagKey or tagValue invalid.");
            return;
        }
        String str3 = str + "::::" + str2;
        C0503a.m95e(f89a, "Action -> setKeyValueTag with tag = " + str3);
        m59a(context, str3, 3, -1);
    }

    public static void sendCommReport2Service(Context context, String str, String str2) {
        long accessId = XGPushConfig.getAccessId(context);
        Intent intent = new Intent("com.tencent.android.tpush.action.COMM_REPORT.V3");
        intent.putExtra("type", 1);
        intent.putExtra("accessId", Rijndael.encrypt(Constants.MAIN_VERSION_TAG + accessId));
        intent.putExtra(MessageKey.MSG_ID, 1000);
        intent.putExtra("broadcastId", 0);
        intent.putExtra("msgTimestamp", System.currentTimeMillis() / 1000);
        intent.putExtra("clientTimestamp", System.currentTimeMillis() / 1000);
        intent.putExtra("pkgName", context.getPackageName());
        intent.putExtra("msg", Rijndael.encrypt(str));
        intent.putExtra("ext", Rijndael.encrypt(str2));
        context.sendBroadcast(intent);
    }

    public static void deleteKeyValueTag(Context context, String str, String str2) {
        if (context == null || str == null || str.trim().length() == 0) {
            C0503a.m99i(f89a, "deleteKeyValueTag context or tagKey invalid.");
            return;
        }
        String str3 = str + "::::" + str2;
        C0503a.m95e(f89a, "Action -> deleteKeyValueTag with tag = " + str3);
        m59a(context, str3, 4, -1);
    }

    public static void deleteTag(Context context, String str) {
        if (XGPushConfig.enableDebug) {
            C0503a.m95e(f89a, "Action -> deleteTag with tag = " + str);
        }
        if (context == null || str == null || str.trim().length() == 0) {
            C0503a.m99i(f89a, "context is null or tagName invalid.");
        } else {
            m59a(context, str, 2, -1);
        }
    }

    static void m59a(Context context, String str, int i, long j) {
        if (context == null) {
            throw new IllegalArgumentException("The context parameter can not be null!");
        } else if (C0544t.m240a(context) <= 0) {
            if (str == null) {
                throw new IllegalArgumentException("The tagName parameter can not be null!");
            }
            if (j <= 0) {
                j = XGPushConfig.getAccessId(context);
            }
            if (j < 0) {
                throw new IllegalArgumentException("The accessId not set!");
            }
            Intent intent = new Intent("com.tencent.android.tpush.action.TAG.V3");
            intent.putExtra("accId", j);
            intent.putExtra(Constants.FLAG_PACK_NAME, Rijndael.encrypt(context.getPackageName()));
            intent.putExtra(Constants.FLAG_TAG_TYPE, i);
            intent.putExtra(Constants.FLAG_TAG_NAME, Rijndael.encrypt(str));
            context.sendBroadcast(intent);
        }
    }

    static XGPushClickedResult m50a(Activity activity) {
        if (XGPushConfig.enableDebug) {
            C0503a.m95e(Constants.LogTag, ">>> onActivityStarted activity=" + activity);
        }
        if (activity == null || activity.getIntent() == null) {
            return null;
        }
        Intent intent = activity.getIntent();
        String stringExtra = intent.getStringExtra(Constants.TAG_TPUSH_MESSAGE);
        if (stringExtra == null || !stringExtra.equalsIgnoreCase("true") || C0544t.m240a(activity.getApplicationContext()) > 0) {
            return null;
        }
        XGPushClickedResult xGPushClickedResult = new XGPushClickedResult();
        xGPushClickedResult.parseIntent(intent);
        intent.removeExtra(Constants.TAG_TPUSH_MESSAGE);
        C0531g.m193a().m196a(new aa(activity, intent));
        return xGPushClickedResult;
    }

    public static XGPushClickedResult onActivityStarted(Activity activity) {
        if (XGPushConfig.enableDebug) {
            C0503a.m95e(Constants.PushMessageLogTag, ">>> onActivityStarted " + activity);
        }
        if (activity == null || activity.getIntent() == null || !C0544t.m257h(activity)) {
            return null;
        }
        Intent intent = activity.getIntent();
        if (intent != null) {
            try {
                if (intent.hasExtra(Constants.TAG_TPUSH_NOTIFICATION)) {
                    Serializable serializableExtra = intent.getSerializableExtra(Constants.TAG_TPUSH_NOTIFICATION);
                    intent.removeExtra(Constants.TAG_TPUSH_NOTIFICATION);
                    if (serializableExtra != null && (serializableExtra instanceof XGPushClickedResult)) {
                        XGPushClickedResult xGPushClickedResult = (XGPushClickedResult) serializableExtra;
                        xGPushClickedResult.parseIntent(intent);
                        return xGPushClickedResult;
                    }
                }
            } catch (Throwable e) {
                C0503a.m91c(f89a, "onActivityStarted", e);
            }
        }
        return null;
    }

    public static long addLocalNotification(Context context, XGLocalMessage xGLocalMessage) {
        return m49a(context, xGLocalMessage, -1);
    }

    static long m49a(Context context, XGLocalMessage xGLocalMessage, long j) {
        if (context == null || xGLocalMessage == null) {
            try {
                C0503a.m98h(f89a, "addLocalNotification context == null or msg == null");
                return -1;
            } catch (Throwable th) {
                C0503a.m91c(Constants.LogTag, "addLocalNotification ", th);
                return 0;
            }
        } else if (!TpnsSecurity.checkTpnsSecurityLibSo(context)) {
            return -1;
        } else {
            if (j <= 0) {
                j = XGPushConfig.getAccessId(context);
            }
            long currentTimeMillis = System.currentTimeMillis();
            StringBuilder stringBuilder = new StringBuilder(64);
            stringBuilder.append(j).append(xGLocalMessage.getMsgId()).append(context.getPackageName()).append(TextUtils.isEmpty(xGLocalMessage.getTitle()) ? Constants.MAIN_VERSION_TAG : xGLocalMessage.getTitle()).append(TextUtils.isEmpty(xGLocalMessage.getContent()) ? Constants.MAIN_VERSION_TAG : xGLocalMessage.getContent());
            String custom_content = xGLocalMessage.getCustom_content();
            if (TextUtils.isEmpty(custom_content) || new JSONObject(custom_content).length() == 0) {
                custom_content = Constants.MAIN_VERSION_TAG;
            }
            stringBuilder.append(custom_content);
            if (xGLocalMessage.getType() == 1) {
                StringBuilder append = stringBuilder.append(TextUtils.isEmpty(xGLocalMessage.getUrl()) ? Constants.MAIN_VERSION_TAG : xGLocalMessage.getUrl());
                if (TextUtils.isEmpty(xGLocalMessage.getIntent())) {
                    custom_content = Constants.MAIN_VERSION_TAG;
                } else {
                    custom_content = xGLocalMessage.getIntent();
                }
                append = append.append(custom_content);
                if (TextUtils.isEmpty(xGLocalMessage.getActivity())) {
                    custom_content = Constants.MAIN_VERSION_TAG;
                } else {
                    custom_content = xGLocalMessage.getActivity();
                }
                append.append(custom_content);
            }
            custom_content = stringBuilder.toString();
            String str = Constants.LOCAL_MESSAGE_FLAG + C0551a.m284a(custom_content);
            long expirationTimeMs = xGLocalMessage.getExpirationTimeMs();
            C0538n.m221b(context, str, expirationTimeMs);
            C0503a.m93d(Constants.LogTag, custom_content + ",tag:" + str + ",exp:" + expirationTimeMs);
            TpnsPushMsg tpnsPushMsg = new TpnsPushMsg();
            tpnsPushMsg.msgId = xGLocalMessage.getMsgId();
            tpnsPushMsg.accessId = j;
            tpnsPushMsg.appPkgName = context.getPackageName();
            tpnsPushMsg.busiMsgId = xGLocalMessage.getBusiMsgId();
            tpnsPushMsg.timestamp = currentTimeMillis / 1000;
            tpnsPushMsg.serverTime = -currentTimeMillis;
            tpnsPushMsg.ttl = xGLocalMessage.getTtl();
            tpnsPushMsg.type = (long) xGLocalMessage.getType();
            tpnsPushMsg.multiPkg = 0;
            tpnsPushMsg.date = xGLocalMessage.getDate();
            tpnsPushMsg.content = "{\"title\":\"" + xGLocalMessage.getTitle() + "\",\"content\":\"" + m52a(xGLocalMessage.getContent()) + "\",\"builder_id\":" + xGLocalMessage.getBuilderId() + ",\"custom_content\":" + xGLocalMessage.getCustom_content() + ",\"ring\":" + xGLocalMessage.getRing() + ",\"vibrate\":" + xGLocalMessage.getVibrate() + ",\"lights\":" + xGLocalMessage.getLights() + ",\"n_id\":" + xGLocalMessage.getNotificationId() + ",\"ring_raw\":\"" + xGLocalMessage.getRing_raw() + "\",\"icon_type\":" + xGLocalMessage.getIcon_type() + ",\"icon_res\":\"" + xGLocalMessage.getIcon_res() + "\",\"style_id\":" + xGLocalMessage.getStyle_id() + ",\"small_icon\":\"" + xGLocalMessage.getSmall_icon() + "\",\"clearable\":1,\"accept_time\":[{\"start\":{\"hour\":\"" + xGLocalMessage.getHour() + "\",\"min\":\"" + xGLocalMessage.getMin() + "\"},\"end\":{\"hour\":\"23\",\"min\":\"59\"}}],\"action\":{\"action_type\":" + xGLocalMessage.getAction_type() + ",\"activity\":\"" + xGLocalMessage.getActivity() + "\",\"browser\":{\"url\":\"" + xGLocalMessage.getUrl() + "\"},\"intent\":\"" + xGLocalMessage.getIntent() + "\",\"package_name\":{\"packageDownloadUrl\":\"" + xGLocalMessage.getPackageDownloadUrl() + "\",\"packageName\":\"" + xGLocalMessage.getPackageName() + "\"}}}";
            C0594a c0594a = new C0594a(Integer.valueOf(0), "127.0.0.1");
            Intent intent = new Intent(Constants.ACTION_INTERNAL_PUSH_MESSAGE);
            intent.setPackage(tpnsPushMsg.appPkgName);
            intent.putExtra(MessageKey.MSG_ID, tpnsPushMsg.msgId);
            intent.putExtra(MessageKey.MSG_CONTENT, Rijndael.encrypt(tpnsPushMsg.content));
            intent.putExtra(MessageKey.MSG_DATE, tpnsPushMsg.date);
            intent.putExtra("type", tpnsPushMsg.type);
            intent.putExtra("accId", tpnsPushMsg.accessId);
            intent.putExtra(MessageKey.MSG_BUSI_MSG_ID, tpnsPushMsg.busiMsgId);
            intent.putExtra(MessageKey.MSG_CREATE_TIMESTAMPS, tpnsPushMsg.timestamp);
            intent.putExtra(MessageKey.MSG_CREATE_MULTIPKG, tpnsPushMsg.multiPkg);
            intent.putExtra(MessageKey.MSG_SERVER_TIME, tpnsPushMsg.serverTime * 1000);
            intent.putExtra(MessageKey.MSG_TTL, tpnsPushMsg.ttl);
            intent.putExtra(MessageKey.MSG_SERVICE_ACK, true);
            intent.putExtra(MessageKey.MSG_EXTRA_HOST, C0631h.m637c(c0594a.m520d()));
            intent.putExtra(MessageKey.MSG_EXTRA_PORT, c0594a.m521e());
            intent.putExtra(MessageKey.MSG_EXTRA_PACT, C0641s.m695a(c0594a.m518b()));
            intent.putExtra(MessageKey.MSG_EXTRA_PUSHTIME, currentTimeMillis);
            C0514i.m154a(context).m161b(intent);
            return -currentTimeMillis;
        }
    }

    public static XGPushNotifactionCallback getNotifactionCallback() {
        return f91c;
    }

    public static void setNotifactionCallback(XGPushNotifactionCallback xGPushNotifactionCallback) {
        f91c = xGPushNotifactionCallback;
    }

    public static void clearLocalNotifications(Context context) {
        if (context == null) {
            C0503a.m98h(f89a, "clearLocalNotifications  context==null.");
        } else if (C0544t.m240a(context) <= 0) {
            C0531g.m193a().m196a(new ab(context.getApplicationContext()));
        }
    }

    static void m54a(Context context, Intent intent) {
        C0510d.m130a().m147d(context, intent.getLongExtra(MessageKey.MSG_ID, -1));
        Intent intent2 = new Intent("com.tencent.android.tpush.action.PUSH_CLICK.RESULT.V3");
        intent2.putExtras(intent);
        intent2.putExtra(Constants.FLAG_PACK_NAME, context.getPackageName());
        intent2.putExtra(Constants.FLAG_CLICK_TIME, System.currentTimeMillis() / 1000);
        C0622a.m591d(context, intent2);
        context.sendBroadcast(intent2);
    }

    public static void onMessageClicked(Context context, XGPushTextMessage xGPushTextMessage) {
        m57a(context, xGPushTextMessage.m71a(), "com.tencent.android.tpush.action.PUSH_CLICK.RESULT.V3");
    }

    public static void onMessageCleared(Context context, XGPushTextMessage xGPushTextMessage) {
        m57a(context, xGPushTextMessage.m71a(), "com.tencent.android.tpush.action.PUSH_CANCELLED.RESULT.V3");
    }

    private static void m57a(Context context, Intent intent, String str) {
        if (context != null && intent != null && str != null) {
            Intent intent2 = new Intent(str);
            intent2.putExtras(intent);
            if ("com.tencent.android.tpush.action.PUSH_CANCELLED.RESULT.V3".equals(str)) {
                intent2.putExtra("action", 2);
            }
            intent2.putExtra(Constants.FLAG_PACK_NAME, context.getPackageName());
            intent2.putExtra(Constants.FLAG_CLICK_TIME, System.currentTimeMillis() / 1000);
            C0622a.m591d(context, intent2);
            context.sendBroadcast(intent2);
        }
    }

    private static void m64c(Context context, Intent intent) {
        if (intent != null) {
            Intent intent2 = new Intent(Constants.ACTION_FEEDBACK);
            intent2.setPackage(context.getPackageName());
            intent2.putExtra(Constants.FEEDBACK_TAG, 4);
            intent2.putExtra(Constants.FEEDBACK_ERROR_CODE, 0);
            intent2.putExtras(intent);
            context.sendBroadcast(intent2);
        }
    }

    public static void onActivityStoped(Activity activity) {
        if (activity != null) {
        }
    }

    public static void setPushNotificationBuilder(Context context, int i, XGPushNotificationBuilder xGPushNotificationBuilder) {
        if (context == null) {
            throw new IllegalArgumentException("context is null.");
        } else if (i < 1 || i > 4096) {
            throw new IllegalArgumentException("notificationBulderId不在范围[1, 4096].");
        } else if (xGPushNotificationBuilder != null) {
            C0508b.m124a(context, i, xGPushNotificationBuilder);
        }
    }

    public static void setDefaultNotificationBuilder(Context context, XGPushNotificationBuilder xGPushNotificationBuilder) {
        if (context != null && xGPushNotificationBuilder != null) {
            C0508b.m124a(context, 0, xGPushNotificationBuilder);
        }
    }

    public static XGPushNotificationBuilder getDefaultNotificationBuilder(Context context) {
        XGPushNotificationBuilder notificationBuilder = getNotificationBuilder(context, 0);
        if (notificationBuilder == null) {
            C0508b.m121a(context);
        }
        return notificationBuilder;
    }

    public static XGPushNotificationBuilder getNotificationBuilder(Context context, int i) {
        if (context != null) {
            return C0508b.m122a(context, i);
        }
        Log.e(Constants.LogTag, "getNotificationBuilder  context == null");
        return null;
    }

    public static void cancelNotifaction(Context context, int i) {
        try {
            ((NotificationManager) context.getSystemService("notification")).cancel(i);
        } catch (Exception e) {
        }
    }

    public static void cancelAllNotifaction(Context context) {
        try {
            ((NotificationManager) context.getSystemService("notification")).cancelAll();
        } catch (Exception e) {
        }
    }

    public static void msgAck(Context context, C0519n c0519n) {
        if (context != null && c0519n != null) {
            if (XGPushConfig.enableDebug) {
                C0503a.m78a(f89a, "Action -> msgAck(" + context.getPackageName() + "," + c0519n.m165b() + ")");
            }
            C0503a.m75a(3, c0519n.m165b());
            if (c0519n.m165b() > 0) {
                Serializable a = C0510d.m130a().m134a(context, context.getPackageName(), c0519n.m165b());
                if (a == null) {
                    C0503a.m97g(f89a, "Action -> msgAck(" + context.getPackageName() + "," + c0519n.m165b() + ")" + "error, no the id: " + c0519n.m165b());
                    return;
                }
                Intent intent = new Intent("com.tencent.android.tpush.action.MSG_ACK.V3");
                intent.putExtra(MessageKey.MSG_ID, c0519n.m165b());
                intent.putExtra(Constants.FLAG_PACK_NAME, context.getPackageName());
                intent.putExtra("MessageId", a);
                context.sendBroadcast(intent);
            }
        }
    }

    public static String getServiceTag(Context context) {
        if (TpnsSecurity.checkTpnsSecurityLibSo(context)) {
            return Rijndael.encrypt(XGPushConfig.getAccessId(context) + "," + "xg_service_enable");
        }
        return "xg_service_enable";
    }

    public static void enableService(Context context, boolean z) {
        if (context != null) {
            if (!z) {
                C0503a.m98h(Constants.LogTag, "XG is disable.");
                unregisterPush(context, new ac(context));
            }
            enableService = z ? 1 : 0;
            if (XGPushConfig.enableDebug) {
                C0503a.m95e(f89a, "enableService=" + enableService);
            }
            C0537m.m212a(context, context.getPackageName() + ENABLE_SERVICE_SUFFIX, enableService);
        }
    }

    static void m60a(Context context, String str, String str2, int i, String str3, XGIOperateCallback xGIOperateCallback, long j, String str4) {
        setContext(context);
        if (context == null) {
            xGIOperateCallback.onFail(null, 10001, "The context parameter can not be null!");
            return;
        }
        C0531g.m193a().m196a(new ad(context, xGIOperateCallback, j, str4, str, str2, str3, i));
    }

    static void m56a(Context context, Intent intent, XGIOperateCallback xGIOperateCallback, boolean z) {
        C0544t.m254e(context);
        BroadcastReceiver agVar = new ag(context, intent, xGIOperateCallback);
        context.registerReceiver(agVar, new IntentFilter("com.tencent.android.tpush.action.SERVICE_START.V3"));
        Runnable ahVar = new ah(context, intent, xGIOperateCallback);
        try {
            f92d.put(agVar, ahVar);
            C0531g.m193a().m198a(ahVar, 10000);
        } catch (Throwable e) {
            C0503a.m91c(Constants.LogTag, "mapTimeRunnableOfMessage error", e);
        }
    }

    private static synchronized void m65c(Context context, Intent intent, XGIOperateCallback xGIOperateCallback) {
        synchronized (XGPushManager.class) {
            if (XGPushConfig.enableDebug) {
                C0503a.m95e(f89a, "Action -> Register to xinge server");
            }
            if (xGIOperateCallback != null) {
                context.registerReceiver(new ae(xGIOperateCallback), new IntentFilter("com.tencent.android.tpush.action.REGISTER.RESULT.V3"));
            }
            context.sendBroadcast(intent);
        }
    }

    private static void m66d(Context context, Intent intent, XGIOperateCallback xGIOperateCallback) {
        context.registerReceiver(new C0681v(xGIOperateCallback), new IntentFilter("com.tencent.android.tpush.action.UNREGISTER.RESULT.V3"));
        context.sendBroadcast(intent);
    }

    private static String m52a(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            switch (charAt) {
                case '\b':
                    stringBuilder.append("\\b");
                    break;
                case '\t':
                    stringBuilder.append("\\t");
                    break;
                case '\n':
                    stringBuilder.append("\\n");
                    break;
                case '\f':
                    stringBuilder.append("\\f");
                    break;
                case '\r':
                    stringBuilder.append("\\r");
                    break;
                case '\"':
                case MotionEventCompat.AXIS_GENERIC_16 /*47*/:
                case '\\':
                    stringBuilder.append('\\').append(charAt);
                    break;
                default:
                    if (charAt > '\u001f') {
                        stringBuilder.append(charAt);
                        break;
                    }
                    stringBuilder.append(String.format("\\u%04x", new Object[]{Integer.valueOf(charAt)}));
                    break;
            }
        }
        return stringBuilder.toString();
    }
}
