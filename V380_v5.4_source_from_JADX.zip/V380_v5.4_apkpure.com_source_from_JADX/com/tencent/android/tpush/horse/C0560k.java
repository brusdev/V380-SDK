package com.tencent.android.tpush.horse;

import com.tencent.android.tpush.horse.data.StrategyItem;
import java.nio.channels.SocketChannel;

/* compiled from: ProGuard */
public interface C0560k {
    void mo1698a(int i, String str);

    void mo1699a(SocketChannel socketChannel, StrategyItem strategyItem);
}
