package com.tencent.android.tpush.horse;

import android.content.Intent;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.os.Handler;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.common.C0531g;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.horse.data.StrategyItem;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.service.C0636n;
import com.tencent.android.tpush.service.cache.CacheManager;
import com.tencent.android.tpush.service.channel.exception.NullReturnException;
import com.tencent.android.tpush.service.p010a.C0579a;
import com.tencent.android.tpush.service.p017e.C0624a;
import com.tencent.android.tpush.service.p017e.C0631h;
import com.tencent.android.tpush.stat.p018a.C0649e;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;

/* compiled from: ProGuard */
public class C0558g {
    static long f299a = 1;
    static long f300b = 0;
    public static int f301c = -1;
    private static long f302j = 0;
    private static long f303k = 0;
    private static int f304m;
    private final Object f305d;
    private volatile int f306e;
    private volatile boolean f307f;
    private long f308g;
    private C0560k f309h;
    private C0561l f310i;
    private Timer f311l;
    private Handler f312n;
    private C0555b f313o;
    private C0555b f314p;

    public void m359a(C0561l c0561l) {
        this.f310i = c0561l;
    }

    public static C0558g m347a() {
        return C0562m.f316a;
    }

    private C0558g() {
        this.f305d = new Object();
        this.f306e = 0;
        this.f307f = false;
        this.f311l = new Timer();
        this.f312n = null;
        this.f313o = new C0851i(this);
        this.f314p = new C0852j(this);
        this.f312n = C0531g.m193a().m199b();
    }

    public synchronized void m358a(C0560k c0560k) {
        this.f306e = 0;
        this.f309h = c0560k;
        this.f312n.post(new C0559h(this));
    }

    private void m351a(String str) {
        List serverItems;
        List arrayList;
        NullReturnException nullReturnException;
        Exception exception;
        if (str != null) {
            C0649e.m740b().m769d("startHorseTask key:" + str);
        }
        if (!C0624a.m596d(C0636n.m679f())) {
            C0503a.m98h("OptimalLinkSelector", "Network can't reachable");
            m348a((int) Constants.CODE_NETWORK_UNREACHABLE, "network can't reachable!");
        } else if (C0853q.m1385i().m300b() || C0850f.m1378i().m300b()) {
            C0503a.m78a("OptimalLinkSelector", "Horse task running");
        } else {
            if (XGPushConfig.enableDebug) {
                C0503a.m90c("OptimalLinkSelector", "Action -> startHorseTask with key = " + str);
            }
            CacheManager.removeOptStrategyList(C0636n.m679f(), str);
            try {
                int channelType;
                List<StrategyItem> b;
                List list;
                if (str.equals("3") || str.equals("1") || str.equals("2")) {
                    serverItems = CacheManager.getServerItems(C0636n.m679f(), str);
                    if (serverItems == null) {
                        serverItems = new ArrayList();
                    }
                    serverItems.addAll(DefaultServer.m289b());
                    channelType = Tools.getChannelType(C0636n.m679f());
                    C0503a.m90c("OptimalLinkSelector", "Tools.getChannelType = " + channelType);
                    switch (channelType) {
                        case 1:
                            try {
                                serverItems = C0565p.m375a(serverItems, str);
                                C0853q.m1385i().m298a(this.f314p);
                                C0853q.m1385i().m299a(serverItems);
                                C0853q.m1385i().m305g();
                                return;
                            } catch (NullReturnException e) {
                                C0503a.m98h(Constants.HorseLogTag, ">> Can not get strategyItems(create tcp channel fail!) >> " + e.getMessage());
                                m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create tcp channel fail!");
                                return;
                            } catch (Exception e2) {
                                C0503a.m98h(Constants.HorseLogTag, ">> (create tcp channel fail!) >> " + e2.getMessage());
                                m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create tcp channel fail!");
                                return;
                            }
                        case 2:
                            try {
                                serverItems = C0565p.m377b(serverItems, str);
                                C0850f.m1378i().m298a(this.f313o);
                                C0850f.m1378i().m299a(serverItems);
                                C0850f.m1378i().m305g();
                                return;
                            } catch (NullReturnException e3) {
                                C0503a.m98h(Constants.HorseLogTag, ">> Can not get strategyItems(create http channel fail!)>>" + e3.getMessage());
                                m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create http channel fail!");
                                return;
                            } catch (Exception e22) {
                                C0503a.m98h(Constants.HorseLogTag, ">> (create http channel fail!) >> " + e22.getMessage());
                                m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create http channel fail!");
                                return;
                            }
                        case 3:
                            try {
                                b = C0565p.m377b(serverItems, str);
                                arrayList = new ArrayList();
                                for (StrategyItem strategyItem : b) {
                                    if (strategyItem.m336h()) {
                                        arrayList.add(strategyItem);
                                    }
                                }
                                C0850f.m1378i().m298a(this.f313o);
                                C0850f.m1378i().m299a(arrayList);
                                C0850f.m1378i().m305g();
                                return;
                            } catch (NullReturnException e32) {
                                C0503a.m98h(Constants.HorseLogTag, ">> Can not get strategyItems(create wap channel fail!)>>" + e32.getMessage());
                                m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create wap channel fail!");
                                return;
                            } catch (Exception e222) {
                                C0503a.m98h(Constants.HorseLogTag, ">> (create wap channel fail!) >> " + e222.getMessage());
                                m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create wap channel fail!");
                                return;
                            }
                        default:
                            try {
                                arrayList = C0565p.m375a(serverItems, str);
                                try {
                                    list = arrayList;
                                    arrayList = C0565p.m377b(serverItems, str);
                                    serverItems = list;
                                } catch (NullReturnException e322) {
                                    NullReturnException nullReturnException2 = e322;
                                    serverItems = arrayList;
                                    nullReturnException = nullReturnException2;
                                    C0503a.m98h(Constants.HorseLogTag, ">> Can not get strategyItems(create default channel fail!)>>" + nullReturnException.getMessage());
                                    m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create default channel fail!");
                                    arrayList = null;
                                    C0853q.m1385i().m298a(this.f314p);
                                    C0853q.m1385i().m299a(serverItems);
                                    C0853q.m1385i().m305g();
                                    C0850f.m1378i().m298a(this.f313o);
                                    C0850f.m1378i().m299a(arrayList);
                                    C0850f.m1378i().m305g();
                                    return;
                                } catch (Exception e2222) {
                                    Exception exception2 = e2222;
                                    serverItems = arrayList;
                                    exception = exception2;
                                    C0503a.m98h(Constants.HorseLogTag, ">> (create default channel fail!) >> " + exception.getMessage());
                                    m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create default channel fail!");
                                    arrayList = null;
                                    C0853q.m1385i().m298a(this.f314p);
                                    C0853q.m1385i().m299a(serverItems);
                                    C0853q.m1385i().m305g();
                                    C0850f.m1378i().m298a(this.f313o);
                                    C0850f.m1378i().m299a(arrayList);
                                    C0850f.m1378i().m305g();
                                    return;
                                }
                            } catch (NullReturnException e3222) {
                                nullReturnException = e3222;
                                serverItems = null;
                                C0503a.m98h(Constants.HorseLogTag, ">> Can not get strategyItems(create default channel fail!)>>" + nullReturnException.getMessage());
                                m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create default channel fail!");
                                arrayList = null;
                                C0853q.m1385i().m298a(this.f314p);
                                C0853q.m1385i().m299a(serverItems);
                                C0853q.m1385i().m305g();
                                C0850f.m1378i().m298a(this.f313o);
                                C0850f.m1378i().m299a(arrayList);
                                C0850f.m1378i().m305g();
                                return;
                            } catch (Exception e22222) {
                                exception = e22222;
                                serverItems = null;
                                C0503a.m98h(Constants.HorseLogTag, ">> (create default channel fail!) >> " + exception.getMessage());
                                m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create default channel fail!");
                                arrayList = null;
                                C0853q.m1385i().m298a(this.f314p);
                                C0853q.m1385i().m299a(serverItems);
                                C0853q.m1385i().m305g();
                                C0850f.m1378i().m298a(this.f313o);
                                C0850f.m1378i().m299a(arrayList);
                                C0850f.m1378i().m305g();
                                return;
                            }
                            C0853q.m1385i().m298a(this.f314p);
                            C0853q.m1385i().m299a(serverItems);
                            C0853q.m1385i().m305g();
                            C0850f.m1378i().m298a(this.f313o);
                            C0850f.m1378i().m299a(arrayList);
                            C0850f.m1378i().m305g();
                            return;
                    }
                }
                serverItems = DefaultServer.m287a(str);
                if (serverItems == null) {
                    serverItems = new ArrayList();
                }
                serverItems.addAll(DefaultServer.m289b());
                channelType = Tools.getChannelType(C0636n.m679f());
                C0503a.m90c("OptimalLinkSelector", "Tools.getChannelType = " + channelType);
                switch (channelType) {
                    case 1:
                        serverItems = C0565p.m375a(serverItems, str);
                        C0853q.m1385i().m298a(this.f314p);
                        C0853q.m1385i().m299a(serverItems);
                        C0853q.m1385i().m305g();
                        return;
                    case 2:
                        serverItems = C0565p.m377b(serverItems, str);
                        C0850f.m1378i().m298a(this.f313o);
                        C0850f.m1378i().m299a(serverItems);
                        C0850f.m1378i().m305g();
                        return;
                    case 3:
                        b = C0565p.m377b(serverItems, str);
                        arrayList = new ArrayList();
                        for (StrategyItem strategyItem2 : b) {
                            if (strategyItem2.m336h()) {
                                arrayList.add(strategyItem2);
                            }
                        }
                        C0850f.m1378i().m298a(this.f313o);
                        C0850f.m1378i().m299a(arrayList);
                        C0850f.m1378i().m305g();
                        return;
                    default:
                        arrayList = C0565p.m375a(serverItems, str);
                        list = arrayList;
                        arrayList = C0565p.m377b(serverItems, str);
                        serverItems = list;
                        C0853q.m1385i().m298a(this.f314p);
                        C0853q.m1385i().m299a(serverItems);
                        C0853q.m1385i().m305g();
                        C0850f.m1378i().m298a(this.f313o);
                        C0850f.m1378i().m299a(arrayList);
                        C0850f.m1378i().m305g();
                        return;
                }
            } catch (Exception e222222) {
                C0503a.m98h(Constants.HorseLogTag, ">> Can not get local serverItems : " + e222222.getMessage());
                try {
                    serverItems = DefaultServer.m287a(str);
                } catch (Exception e2222222) {
                    C0503a.m98h(Constants.HorseLogTag, ">> Can not get default serverItems : " + e2222222.toString());
                    serverItems = null;
                }
            }
        }
    }

    private void m348a(int i, String str) {
        if (this.f309h != null) {
            this.f309h.mo1698a(i, str);
        }
    }

    public synchronized void m357a(Intent intent) {
        try {
            NetworkInfo networkInfo = (NetworkInfo) intent.getParcelableExtra("networkInfo");
            if (networkInfo != null) {
                if (XGPushConfig.enableDebug) {
                    C0503a.m90c("OptimalLinkSelector", "Connection state changed to - " + networkInfo.toString());
                }
                boolean booleanExtra = intent.getBooleanExtra("noConnectivity", false);
                int type = networkInfo.getType();
                if (booleanExtra) {
                    if (XGPushConfig.enableDebug) {
                        C0503a.m90c("OptimalLinkSelector", "DisConnected with network type " + networkInfo.getTypeName());
                    }
                    C0636n.m676c(C0636n.m679f());
                } else if (State.CONNECTED == networkInfo.getState()) {
                    if (XGPushConfig.enableDebug) {
                        C0503a.m90c("OptimalLinkSelector", "Connected with network type " + networkInfo.getTypeName());
                    }
                    f301c = type;
                    C0636n.m669a(C0636n.m679f(), 2000);
                } else if (State.DISCONNECTED == networkInfo.getState()) {
                    if (XGPushConfig.enableDebug) {
                        C0503a.m90c("OptimalLinkSelector", "NetworkInfo.State.DISCONNECTED with network type = " + networkInfo.getTypeName());
                    }
                    if (f301c == -1 || f301c == type) {
                        C0636n.m676c(C0636n.m679f());
                    }
                } else if (XGPushConfig.enableDebug) {
                    C0503a.m90c("OptimalLinkSelector", "other network state - " + networkInfo.getState() + ". Do nothing.");
                }
            }
        } catch (Throwable th) {
            C0503a.m80a("OptimalLinkSelector", "onNetworkChanged", th);
        }
    }

    public void m360b() {
        f304m++;
        if (f304m < C0579a.m385a(C0636n.m679f()).f378t) {
            C0558g.m347a().m351a(C0631h.m653i(C0636n.m679f()));
        } else {
            m348a((int) Constants.CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED, "create socket err");
        }
    }
}
