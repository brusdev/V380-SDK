package com.tencent.android.tpush.horse;

import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.horse.data.OptStrategyList;
import com.tencent.android.tpush.horse.data.StrategyItem;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.service.C0636n;
import com.tencent.android.tpush.service.cache.CacheManager;
import com.tencent.android.tpush.service.p017e.C0631h;
import java.util.ArrayList;
import java.util.List;

/* compiled from: ProGuard */
class C0559h implements Runnable {
    final /* synthetic */ C0558g f315a;

    C0559h(C0558g c0558g) {
        this.f315a = c0558g;
    }

    public void run() {
        synchronized (this) {
            if (XGPushConfig.enableDebug) {
                C0503a.m90c(Constants.HorseLogTag, "Action ->  createOptimalSocketChannel run");
            }
            if (C0853q.m1385i().m300b() || C0850f.m1378i().m300b()) {
                C0503a.m90c(Constants.HorseLogTag, ">> horse task running");
            } else {
                String str = Constants.MAIN_VERSION_TAG;
                try {
                    str = C0631h.m653i(C0636n.m679f());
                    OptStrategyList optStrategyList = CacheManager.getOptStrategyList(C0636n.m679f(), str);
                    StrategyItem e = optStrategyList.m320e();
                    if (e.m332d() == 1 || e == null || C0557e.m340a(optStrategyList.m322g())) {
                        this.f315a.m351a(str);
                        return;
                    }
                    this.f315a.f308g = System.currentTimeMillis();
                    if (e.m332d() == 0) {
                        if (XGPushConfig.enableDebug) {
                            C0503a.m90c(Constants.HorseLogTag, "Using the optStrategyItem" + e.toString());
                        }
                        this.f315a.f307f = true;
                        List arrayList = new ArrayList();
                        e.m328a(0);
                        arrayList.add(e);
                        C0853q.m1385i().m298a(this.f315a.f314p);
                        C0853q.m1385i().m299a(arrayList);
                        C0853q.m1385i().m305g();
                    } else {
                        if (XGPushConfig.enableDebug) {
                            C0503a.m90c(Constants.HorseLogTag, "Using Http chanel http:" + e.toString());
                        }
                        C0563n c0563n = new C0563n();
                        c0563n.m367a(e);
                        if (c0563n.m365a().isConnected() && this.f315a.f309h != null) {
                            this.f315a.f309h.mo1699a(c0563n.m365a(), e);
                            return;
                        }
                    }
                } catch (Throwable e2) {
                    C0503a.m91c(Constants.HorseLogTag, "createOptimalSocketChannel error", e2);
                    this.f315a.m351a(str);
                } catch (Throwable e22) {
                    C0503a.m91c(Constants.HorseLogTag, "createOptimalSocketChannel error", e22);
                    this.f315a.m360b();
                } catch (Throwable e222) {
                    C0503a.m91c(Constants.HorseLogTag, "createOptimalSocketChannel error", e222);
                    this.f315a.m360b();
                }
            }
        }
    }
}
