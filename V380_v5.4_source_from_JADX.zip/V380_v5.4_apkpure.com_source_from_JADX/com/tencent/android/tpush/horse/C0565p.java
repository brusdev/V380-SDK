package com.tencent.android.tpush.horse;

import com.tencent.android.tpush.common.Constants;
import com.tencent.android.tpush.horse.data.ServerItem;
import com.tencent.android.tpush.horse.data.StrategyItem;
import com.tencent.android.tpush.p004a.C0503a;
import com.tencent.android.tpush.service.C0636n;
import com.tencent.android.tpush.service.cache.CacheManager;
import com.tencent.android.tpush.service.channel.exception.NullReturnException;
import java.util.ArrayList;
import java.util.List;

/* compiled from: ProGuard */
public class C0565p {
    private static StrategyItem m374a(String str, int i, int i2) {
        if (str == null || i == 0) {
            return null;
        }
        return new StrategyItem(str, i, Constants.MAIN_VERSION_TAG, 80, i2, 0);
    }

    private static List m376a(List list, short s, String str) {
        Throwable e;
        StrategyItem strategyItem;
        int i = 0;
        if (list == null) {
            throw new NullReturnException("getStrategyItems return null, because [items] is null");
        }
        StrategyItem e2;
        List arrayList = new ArrayList();
        try {
            e2 = CacheManager.getOptStrategyList(C0636n.m679f(), str).m320e();
            try {
                e2.m328a(0);
                if (e2.m332d() == s) {
                    arrayList.add(e2);
                }
                Object obj = e2;
            } catch (Exception e3) {
                e = e3;
                C0503a.m91c(Constants.ServiceLogTag, "getStrategyItems", e);
                strategyItem = e2;
                while (i < list.size()) {
                    e2 = C0565p.m374a(((ServerItem) list.get(i)).m324a(), ((ServerItem) list.get(i)).m325b(), (int) s);
                    arrayList.add(e2);
                    i++;
                }
                return arrayList;
            }
        } catch (Throwable e4) {
            Throwable th = e4;
            e2 = null;
            e = th;
            C0503a.m91c(Constants.ServiceLogTag, "getStrategyItems", e);
            strategyItem = e2;
            while (i < list.size()) {
                e2 = C0565p.m374a(((ServerItem) list.get(i)).m324a(), ((ServerItem) list.get(i)).m325b(), (int) s);
                arrayList.add(e2);
                i++;
            }
            return arrayList;
        }
        while (i < list.size()) {
            e2 = C0565p.m374a(((ServerItem) list.get(i)).m324a(), ((ServerItem) list.get(i)).m325b(), (int) s);
            if (!(e2 == null || e2.equals(r1))) {
                arrayList.add(e2);
            }
            i++;
        }
        return arrayList;
    }

    public static List m375a(List list, String str) {
        return C0565p.m376a(list, (short) 0, str);
    }

    public static List m377b(List list, String str) {
        return C0565p.m376a(list, (short) 1, str);
    }
}
